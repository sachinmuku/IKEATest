﻿using System.Data;
using System.Net.Http;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Common.Abstractions
{
    public interface INiceLabelUtilities
    {
        IIntegrationEntry CreateNiceLabelIncomingIntegrationEntry(object request, IIntegrationEntry parentIntegration, bool isFlag, string errorMessage, string requestType = "NiceLabelSSCCInfo", string eventName = "NiceLabelSSCCInfo");
        IIntegrationEntry CreateNiceLabelOutgoingIntegrationEntry(INiceLabelIntegrationMessage request, string requestEndpoint, string requestType = "NiceLabelNotifyTrackIn", string eventName = "NiceLabelNotifyTrackIn");
        IIntegrationEntryCollection GetNiceLabelLastIntegrationInQueue(IIntegrationEntryCollection objects);
        IMaterialCollection GetNiceLabelMaterialAlreadyAssociatedForResource(IResource resource);
        DataSet GetNiceLabelMaterialForIntegrationEntry(IIntegrationEntry integrationEntry);
        IIntegrationEntryCollection GetNiceLabelProcessingIntegrationEntries();
        DataSet ResolveNiceLabelContextSmartTable(IResource resource, IProduct product);
        string SendNiceLabelMessage(string serializedMessage, string messageEndpoint);
        string SendNiceLabelMessage(string serializedMessage, string messageEndpoint, HttpMethod httpMethod);
    }
}