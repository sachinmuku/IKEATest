﻿using System;
using System.Collections.Generic;
using System.Xml;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Common.Abstractions
{
    public interface IGenericUtilities
    {
        Dictionary<string, string> DeserializeObject(string message);
        T DeserializeXmlToObject<T>(string xml);
        T DeserializeXmlToObject<T>(XmlNode xml);
        T GetConfigurationValueByPath<T>(string path);
        T GetEntityByName<T>(string name) where T : ICoreBase;
        T IoTManualProcessLossRequest<T>(IMaterial material, decimal? quantity, bool isConfirmation = false);
        T RequestFromIoT<T>(IAutomationControllerInstance controllerInstance, string requestType, object requestData);
        void RetryDirectFeedingCounterPartFinished(IMaterial material, bool loadEntities = false);
        ICurrentEntityState SetEntityStateModelState(IMaterial material, string stateModelValue);
        void ChangeMaterialStateModel(IMaterial material, string stateModelValue);
        IMaterialCollection MaterialStateModelMappingLogic(string action, IMaterialCollection materials);
        void VerifyOrderCounterPart(IMaterial material, IResource resource, bool loadEntities = false);
        bool DirectFeedingIsDirectFeedingAndSecondLine(IResource resource, IMaterial materialMO);
        Tuple<string, string> ResolveAllMaterialFlows(IFacility facility, IProduct product, IResource resource, string moType, string workcenter);
        IFlowCollection GetFlowsInFlowPath(string flowpath, bool loadFlows = false);
        IStep GetStepByFlowPath(string flowPath, bool loadStep = true);
        IFlowStep GetFirstOrLastFlowStepFromFlow(IFlow flow, bool first = true);
        string GetCorrectFlowPath(string flowPath);
        INgpDataSet ResolveBaseProduct(string baseProductName, ISmartTable st, INgpDataRow values, INgpDataSet nds, bool isFirstResolveOrder = false);
        IStep ERPResolveStepForBOMProduct(IProduct product, IFacility facility, IResource resource, string workCenter);
        IEmployeeCollection GetCheckedInEmployees(string resourceName);

    }
}