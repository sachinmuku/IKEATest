﻿using System.Collections.Generic;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Common.Abstractions
{
    public interface IBarcodeUtilities
    {
        Dictionary<string, string> ExtractBarcodeInformation(string barcodeString);
        Dictionary<string, string> ExtractBarcodeInformation(string barcodeString, IResource resource);
        string GetScanningConfiguration(IResource resource);
    }
}