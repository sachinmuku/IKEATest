﻿using System.Collections.Generic;
using Cmf.Custom.IKEA.Common.PLM;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Common.Abstractions
{
    public interface IPLMUtilities
    {
        IProduct CreateProductFromPLM(ProductSyncInput input, bool isRevision);
        IProduct CreateProductVersionFromPLM(ProductSyncInput input, bool isRevision);
        void FullUpdateUnitConversionFactorsFromPLM(IProduct product, Dictionary<string, decimal> newConversions, bool loadUnitConversionFactors = true);
        void NormalizeProductUnitsFromPLM(ProductSyncInput input);
    }
}