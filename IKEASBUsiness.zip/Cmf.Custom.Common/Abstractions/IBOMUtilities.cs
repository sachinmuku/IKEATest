﻿using System.Collections.Generic;
using Cmf.Custom.IKEA.Common.ERP;
using Cmf.Custom.IKEA.Common.Extensions.BOM;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Common.Abstractions
{
    public interface IBOMUtilities
    {
        CustomBOMProductInformationCollection GetBOMFromTemplate(string productName, List<ERPBOMProduct> erpBOMProducts, IResourceCollection resources, IFacility facility, IResource mainFeeder, string areaName = null, string workCenter = null, string resourceName = null, string orderType = null, string structureType = null);
        List<CustomBOMTemplateDetail> GetBOMTemplateDetails(string templateName);
        string ResolveCustomBOMTemplateHandler(string productName, string facilityName = null, string areaName = null, string workCenter = null, string resourceName = null, string orderType = null, string structureType = null);
        bool ValidateERPBOMProductsQuantities(List<ERPBOMProduct> erpBOMProducts, CustomBOMProductInformationCollection bomProductInformations);
    }
}