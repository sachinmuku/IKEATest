﻿using System;
using System.Collections.Generic;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.ERP;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Common.Abstractions
{
    public interface IProductionOrderHandlingUtilities
    {
        void AssociateMaterialBOMs(Dictionary<IMaterial, IBOM> materialBOMs);
        DateTime? ConvertStringToDateTime(string stringDate, string stringTime, string dateFormat = "yyyyMMddHHmmss");
        IIntegrationEntry CreateProductionOrderRequestIntegrationEntry(string groupMOName, NewProductionOrderRequest request);
        IMaterial CreateSingleOrderless(IResource resource, OrderlessCreation orderlessCreation);
        Dictionary<string, IBOM> GetAssociatedOrderBOMs(IEnumerable<IMaterial> materials);
        Dictionary<string, string> GetIntegrationEntryAttributes(string poName);
        IIntegrationEntry RequestERPProductionOrder(IMaterial groupMO, string facilityERPIdentifier, IProduct product, decimal quantity, bool updateGroupState = true);
        bool ValidatePOStatus(string poName, string poStatus, string integrationEntryName);
    }
}