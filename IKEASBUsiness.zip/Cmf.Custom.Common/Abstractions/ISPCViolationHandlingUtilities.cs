﻿using System.Collections.Generic;
using System.Data;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Common.Abstractions
{
    public interface ISPCViolationHandlingUtilities
    {
        void HandleSPCViolation(DataRow row, List<string> actions, IMaterialCollection materialsToBlock, List<string> resourceNames, string logicalChartLink = null, IChartDataPoint chartDataPoint = null);
        DataRow ResolveSmartTableCustomSPCViolationActions(IChartDataPoint chartDataPoint, string ruleName, string resource);
    }
}