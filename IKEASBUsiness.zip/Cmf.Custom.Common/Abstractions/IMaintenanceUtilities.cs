﻿using System;
using System.Collections.Generic;
using Cmf.Custom.IKEA.Common.ERP.Maintenance;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Common.Abstractions
{
    public interface IMaintenanceUtilities
    {
        IIntegrationEntry CreateERPMaintenanceRequest(IMaintenanceActivityOrder maintenanceActivityOrder, string txt1 = "", string txt2 = "", string txt3 = "");
        IIntegrationEntry CreateWorkOrderIntegrationEntry(string maoName, NewWorkOrderRequest request);
        bool GenerateNotificationsForMAOsWithOpenDCAndCheckLists(IMaintenanceActivityOrderCollection maosWithoutClosedChecklists, IMaintenanceActivityOrderCollection maosWithoutFilledDataCollection);
        Tuple<string, string> GetERPType(string mesMaintenanceType);
        IMaintenanceActivityOrderCollection GetMaintenanceActivityOrdersByWorkOrderId(string workOrderId, bool loadEntities = false, bool includeTerminated = false);
        Dictionary<string, MaintenanceExecutionStates> GetMaintenanceActivityOrderStatusByERPStatus(string erpStatus = null);
        IMaintenancePlanInstanceCollection GetMaintenancePlanInstancesForResource(string resourceName, bool loadEntities = false);
        string GetMESMaintenanceTypeByERPMainTypeAndSubType(string erpMainType, string erpSubType);
    }
}