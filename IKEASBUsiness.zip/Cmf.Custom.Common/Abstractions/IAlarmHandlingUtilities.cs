﻿using System;
using System.Collections.Generic;
using System.Data;
using Cmf.Custom.IKEA.BusinessObjects.Abstractions;
using Cmf.Foundation.Security.Abstractions;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Common.Abstractions
{
    public interface IAlarmHandlingUtilities
    {
        void AlarmOccurrenceHandlingUtility(DataRow row, ICustomAlarmOccurrence alarm, string alarmCode, string alarmCategory, string resourceName, string topMostResourceName, string areaName, string facilityName, string adminNotificationDetails);
        List<string> GetCheckedInUserEmails(string resourceName);
        List<ICustomAlarmOccurrence> GetLineActiveAlarms(IResource topMostResource);
        void NotificationsHandling(string resourceName, string topMostResourceName, List<string> checkedInUserEmails, IEmployeeCollection employeesToBeNotified, string topMostAlarmNotificationContent, string subResourceAlarmNotificationContent, DataRow row, IRole role, string adminNotificationDetails, string alarmCode);
        DataRow ResolveCustomAlarmHandlingActions(string alarmCode, string alarmCategory, string topMostResourceName, string areaName, string facilityName);
        bool? ResolveCustomAlarmTrackingConfiguration(string facilityName = null, string areaName = null, string resourceName = null, string alarmCode = null, string category = null);
        void SendEmail(string emailTo, string emailSubject, string emailMessage, bool emailIsBodyHTML);
        void SetAlarmAckDateIfEmpty(ICustomAlarmOccurrence alarmOccurrence, DateTime? ackDateTime);
    }
}