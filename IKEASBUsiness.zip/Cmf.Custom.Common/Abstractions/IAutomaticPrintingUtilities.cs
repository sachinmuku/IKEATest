﻿using System;
using System.Collections.Generic;
using System.Data;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Common.Abstractions
{
    public interface IAutomaticPrintingUtilities
    {
        void GeneratePrintingTimers(List<Tuple<IMaterial, IStep, IResource>> materialsToPrintStep, string triggeringSequence);
        bool HasAutomaticPrinting(IMaterial material, string printingSequence, out bool printSourceMaterial, IResource resource = null);
        void RegisterMaterialLabelPrinted(Dictionary<IMaterial, IStep> materialAndSteps);
        void RegisterMaterialLabelPrinted(IMaterial material, IStep step);
        void ResolveAndPrintAutomaticPrintableDocuments(IMaterial material, IStep step, string printingSequence, IResource resource = null);
        void ResolveAndPrintAutomaticPrintableDocumentsCutting(IMaterial material, IStep step, string printingSequence, IResource resource, IProduct product, IPrintableDocument printableDocument);
        void ResolveAndPrintSplitAutomaticPrintableDocuments(IMaterialCollection materials, IMaterial mainMaterial, string printingSequence);
        DataSet ResolveAutoPrintingContextSmartTable(IMaterial material, string printingSequence, IStep step = null, IResource resource = null);
    }
}