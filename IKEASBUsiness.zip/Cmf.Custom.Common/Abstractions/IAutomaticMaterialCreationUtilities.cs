﻿using System;
using System.Collections.Generic;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Common.Abstractions
{
    public interface IAutomaticMaterialCreationUtilities
    {
        IMaterial CustomCreateScannedDurableAutomaticallyUtility(string materialName, string productName, decimal quantity, IResource resource);
        IMaterial CustomCreateScannedMaterialAutomaticallyUtility(IResource resource, Dictionary<string, string> serviceTokenList);
        void SetMaterialBatch(IMaterial batch, IMaterial pallet);
        void SetMaterialBatch(string batchName, ref IMaterial material);
        Tuple<string, string, decimal> ValidateTokenList(Dictionary<string, string> serviceTokenList);
    }
}