﻿
using Cmf.Custom.IKEA.Common.Enums;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Common.Abstractions
{
    public interface IDirectFeedingUtilities
    {
        decimal CalculateDirectFeedingQuantityAccordingWithBomRatio(IResource resource, IMaterial material, decimal quantity);
        void DirectFeedingMovePalletToCounterPartResource(IMaterial pallet);
        IResource GetDirectFeedingCounterpartResource(IResource resource, bool loadResource = false);
        bool IsDirectFeedingResourceMatchValid(IResource resource, bool loadResource = false);
        void RequestFirstLineToClearDirectFeedingInterlock(IResource firstLineResource);
        void RequestSpecialAttach(IMaterial material, IResource lineResource);
        void RequestVirtualPalletCreation(IProduct product, IResource lineResource, decimal baseUnitConversion, decimal quantity);
        void RequestVirtualToRealPallet(IMaterialCollection materialCollection, IResource lineResource, IAutomationControllerInstance controllerInstance);
        CustomDirectFeedingModeEnum? ResolveCustomDirectFeedingRecipeModeSmartTable(IMaterial material, IResource resource);
        bool SendAttachedData(IAutomationControllerInstance controllerInstance, string requestType, IResource topMostResource, IMaterial material);
        void SendRequestReducePalletQuantityOnOutfeeder(IResource resource, IMaterial material, decimal quantity);
        bool ValidateCounterpartMaterialForPalletization(IMaterial counterpartMaterial, decimal quantity);
        bool VerifyDirectFeedingConsumablesAttachToStart(IMaterial material, bool isSetupCorrectly);
    }
}