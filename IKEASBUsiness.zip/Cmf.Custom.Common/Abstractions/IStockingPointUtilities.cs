﻿using System.Collections.Generic;

using Cmf.Custom.IKEA.BusinessObjects.Abstractions;
using Cmf.Custom.IKEA.Common.Enums;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Common.Abstractions
{
    public interface IStockingPointUtilities
    {
        Dictionary<IProduct, decimal> CalculateOrderNecessities(IMaterial orderMaterial, decimal orderQuantityToProduce);
        void CleanUpReplenishmentRequest(string stockingPoint, IProductCollection products);
        ICustomMaterialReplenishmentRequestTrackerCollection GetCustomMaterialReplenishmentRequestTrackers(string stockingPoint, string product = null);
        ICustomStockingPointResourceCollection GetLineStockingPoint(IResource resource);
        List<MaterialReplenishmentRequestConfiguration> GetMaterialReplenishmentRequestConfiguration();
        ITaskCollection GetMaterialTransferTasks(string stockingPoint, string product);
        bool ReplenishmentRequestExists(string productName, decimal requestedQuantity, string stockingPoint);
        Dictionary<IMaterial, decimal?> RetrieveOrderQuantity(IResource mainLine, CustomMaterialReplenishmentWorkingModeEnum workingMode, decimal? hoursToConsiderInput);
        void TerminateStockingPointTrackersAndTasks(ICustomMaterialReplenishmentRequestTrackerCollection stockingPointTrackersToTerminate, bool terminateTasks = false, bool terminateNotifications = false);
        void UpdateReplenishmentRequest(string stockingPoint, string product, decimal deliveredQuantity);
    }
}