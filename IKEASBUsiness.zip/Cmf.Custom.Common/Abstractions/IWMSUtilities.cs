﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using Cmf.Custom.IKEA.BusinessObjects.Abstractions;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using Cmf.Custom.IKEA.Common.WMS;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Common.Abstractions
{
    public interface IWMSUtilities
    {
        Dictionary<string, Dictionary<string, decimal>> CalculateTotalRequestedQuantities(IMaterialCollection materials, EntityCache entityCache, bool loadAttributes, bool loadReleation);
        IMaterial CreateMaterialFromWMS(IWMSIntegrationMessage wmsMessage, out List<string> errorDetails, string resourceName, string productionOrderName = null);
        WMSIntegrationMessage CreateSetPalletStatusMessage(IMaterial material);
        IIntegrationEntry CreateWMSIntegrationEntry(WMSIntegrationMessage request, string requestEndpoint, string requestType = "WMSOrderRequest", string eventName = "WMSOrderRequest", string factoryAutomationJobId = null, string description = null);
        List<WMSAutomationJobInput> CreateWMSManufacturingOrderJobInputs(CustomWMSOrderRequestType type, IResource sourceResource, IResource targetResource, IMaterial operationMaterial, Dictionary<string, FeedDestinations> feedDestinationsByMainLine = null);
        WMSIntegrationMessage CreateWMSOrderRequestMessage(CustomWMSOrderRequestType type, string productName = null, string materialName = null, string productionOrderName = null, decimal? feedQuantity = null, string sourceResourceName = null, string destinationResourceName = null, long? wmsIOID = null, string batchID = null, string palletID = null, string status = null);
        string GenerateNameForExistingMaterial(IMaterial material, string materialNameStartsWith, string nameGenerator);
        ICustomWMSMaterialTrackerCollection GetCustomWMSMaterialTrackers(IEnumerable<long> inventoryOrderIds, string filterColumnName = "InventoryOrderId", bool includeTerminated = false);
        ICustomWMSMaterialTrackerCollection GetCustomWMSMaterialTrackers(IFilter filter, bool includeTerminated = false);
        ICustomWMSMaterialTrackerCollection GetCustomWMSMaterialTrackers(IFilterCollection filters, bool includeTerminated = false);
        ICustomWMSMaterialTrackerCollection GetCustomWMSMaterialTrackers(IMaterial material, bool includeTerminated = false);
        ICustomWMSMaterialTrackerCollection GetCustomWMSMaterialTrackers(long inventoryOrderId, string filterColumnName = "InventoryOrderId", bool includeTerminated = false);
        ICustomWMSMaterialTrackerCollection GetCustomWMSMaterialTrackers(string filterColumnValue, string filterColumnName = "PalletName", bool includeTerminated = false);
        ICustomWMSMaterialTracker GetJobLatestCustomWMSMaterialTracker(string factoryAutomationJobId, bool includeTerminated = false);
        IResourceCollection GetMainLineFeeders(IResource mainLine, bool loadRelation = true);
        DateTime? GetMaterialSeasoningTime(IMaterial material);
        string GetMESStatus(int wmsStatus);
        int GetWMSStatus(string mesStatus);
        WMSIntegrationMessage SendGetPalletStatusMessageSync(IMaterial material);
        void SendOrderAutomationJobInputs(IEnumerable<WMSAutomationJobInput> jobInputs);
        string SendRequestToFactoryAutomation(IAutomationControllerInstance controllerInstance, long inventoryOrderId, string requestType, bool isFromWMS = false);
        Dictionary<long, string> SendRequestToFactoryAutomation(IEnumerable<long> inventoryOrderIdsList, string requestType);
        string SendRequestToFactoryAutomation(long inventoryOrderId, string requestType, bool isFromWMS = false);
        WMSIntegrationMessage SendWMSMessageWithIntegrationEntry(WMSIntegrationMessage wmsIntegrationMessage, string messageEndpoint, HttpMethod httpMethod);
        IMaterial UpdateMaterialFromWMS(IWMSIntegrationMessage wmsMessage, out List<string> errorDetails, string resourceName = "", string productionOrderName = null);
    }
}