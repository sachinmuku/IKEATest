﻿using System.Collections.Generic;
using Cmf.Custom.IKEA.Common.ERP;
using Cmf.Custom.IKEA.Common.Extensions.BOM;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Common.Abstractions
{
    public interface IERPUtilities
    {
        List<string> GetERPReportableForms();
        string GetMaterialRelatedEntityNameFromMaterial(string contextParameter, string materialName);
        void HandleERPOrderlessUnitCompleteResponse(MESERPCommunication communication, string result);
        void HandleMaterialMovementCommunication(bool isToCreateIntegrationEntry, IMaterialCollection pallets, Dictionary<long, string> palletNewLocation);
        void ReportLeftOvers(IMaterialCollection materialsLeftOver);
        void ReportProductionOrderComplete(IProductionOrder productionOrder);
        void ReportUnitComplete(IMaterialCollection materials, bool isNiceLabelReport, bool force = false);
        string SendERPMessage(Dictionary<string, string> message, string messageEndpoint);
    }
}