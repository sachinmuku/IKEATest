﻿

using Cmf.Custom.IKEA.Common.Enums;

namespace Cmf.Custom.IKEA.Common
{
    public class MaterialReplenishmentRequestConfiguration
    {

        /// <summary>
        /// Smart Table - CustomMaterialReplenishmentRequestConfiguration - Stocking Point
        /// </summary>
        public string StockingPoint { get; set; }

        /// <summary>
        /// Smart Table - CustomMaterialReplenishmentRequestConfiguration - Product
        /// </summary>
        public string Product { get; set; }

        /// <summary>
        /// Smart Table - CustomMaterialReplenishmentRequestConfiguration - Product Type
        /// </summary>
        public string ProductType { get; set; }

        /// <summary>
        /// Smart Table - CustomMaterialReplenishmentRequestConfiguration - Working Mode
        /// </summary>
        public CustomMaterialReplenishmentWorkingModeEnum WorkingMode { get; set; }

        /// <summary>
        /// Smart Table - CustomMaterialReplenishmentRequestConfiguration - Hours To Consider
        /// </summary>
        public decimal? HoursToConsider { get; set; }

        /// <summary>
        /// Smart Table - CustomMaterialReplenishmentRequestConfiguration - Request Mode
        /// </summary>
        public CustomMaterialReplenishmentRequestModeEnum RequestMode { get; set; }

        /// <summary>
        /// Smart Table - CustomMaterialReplenishmentRequestConfiguration - Quantity To Request
        /// </summary>
        public decimal? QuantityToRequest { get; set; }

        /// <summary>
        /// Smart Table - CustomMaterialReplenishmentRequestConfiguration - Threshold
        /// </summary>
        public decimal? Threshold { get; set; }

        /// <summary>
        /// Smart Table - CustomMaterialReplenishmentRequestConfiguration - Facility
        /// </summary>
        public string Facility { get; set; }

        /// <summary>
        /// Smart Table - CustomMaterialReplenishmentRequestConfiguration - Area
        /// </summary>
        public string Area { get; set; }


    }
}
