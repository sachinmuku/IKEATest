﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Common
{
    /// <summary>
    /// This class contains constants part of facility
    /// </summary>
    public static partial class IKEAConstants
    {
        #region Attributes

        /// <summary>
        /// Attribute that contains the ERP Identifier
        /// </summary>
        public const string CustomFacilityAttributeERPIdentifier = "ERPIdentifier";

        /// <summary>
        /// Attribute that contains the ERP WareHouse Location
        /// </summary>
        public const string CustomFaciltyAttributeERPWarehouseLocation = "ERPWarehouseLocation";

        /// <summary>
        /// Attribute that contains the ERP Replenishment Warehouse
        /// </summary>
        public const string CustomFaciltyAttributeERPReplenishmentWarehouse = "ERPReplenishmentWarehouse";

        /// <summary>
        /// Attribute that contains the ERP Maintenance Facility Code
        /// </summary>
        public const string CustomERPMaintenanceFacilityCode = "ERPMaintenanceFacilityCode";

        /// <summary>
        /// Logopak Factory identification code to be shown on the generated ULL Labels
        /// </summary>
        public const string CustomFactoryCode = "FactoryCode";

        /// <summary>
        /// Logopak Supplier identification code to be shown on the generated ULL Labels
        /// </summary>
        public const string CustomSupplierCode = "SupplierCode";

        /// <summary>
        /// Logopak International AB Prefix to be shown on the generated ULL Labels
        /// </summary>
        public const string CustomInternationalABPrefix = "InternationalABPrefix";

        /// <summary>
        /// Logopak Name of unit/country to be shown on the generated ULL Labels
        /// </summary>
        public const string CustomNameOfUnit = "NameOfUnit";
        #endregion
    }
}
