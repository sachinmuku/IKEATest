﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Common
{
    /// <summary>
    /// This file contains constants related with DB Access
    /// </summary>
    public partial class IKEAConstants
    {

        /// <summary>
        /// Schema and name of the stored procedure responsible for retrieving feeder and consuming materials
        /// </summary>
        public const string CustomGetFeederConsumerInformationSP = "[Custom].[P_GetFeederConsumerInformation]";

        /// <summary>
        /// parameter MaterialId of procedure {CustomGetFeederConsumerInformationSP}
        /// </summary>
        public const string CustomGetFeederConsumerInformationSPMaterialIdParam = "MaterialId";

        /// <summary>
        /// parameter RestrictToForm of procedure {CustomGetFeederConsumerInformationSP}
        /// </summary>
        public const string CustomGetFeederConsumerInformationSPRestrictToFormParam = "RestrictToForm";

        /// <summary>
        /// Schema and name of the stored procedure responsible for retrieving resource state history
        /// </summary>
        public const string CustomGetResourceStateHistory = "[Custom].[P_GetResourceStateHistory]";

        /// <summary>
        /// Parameter UserId of procedure {P_GetReourceStateHistory}
        /// </summary>
        public const string CustomGetResourceStateHistoryUserId = "UserId";

        /// <summary>
        /// Parameter ResourceId of procedure {P_GetReourceStateHistory}
        /// </summary>
        public const string CustomGetResourceStateHistoryResourceId = "ResourceId";

        /// <summary>
        /// Schema and name of the stored procedure responsible resolving the resource state reclassification permissions for all roles of an user
        /// </summary>
        public const string CustomResolveCustomResourceStateReclassificationPermissionsForAllRolesOfUser = "[Custom].[P_ResolveCustomResourceStateReclassificationPermissionsForAllRolesOfUser]";

        /// <summary>
        /// Parameter UserId of procedure {P_ResolveCustomResourceStateReclassificationPermissionsForAllRolesOfUser}
        /// </summary>
        public const string CustomResolveCustomResourceStateReclassificationPermissionsForAllRolesOfUserUserId = "UserId";

        /// <summary>
        /// Parameter StateModelName of procedure {P_ResolveCustomResourceStateReclassificationPermissionsForAllRolesOfUser}
        /// </summary>
        public const string CustomResolveCustomResourceStateReclassificationPermissionsForAllRolesOfUserStateModelName = "StateModelName";

        /// <summary>
        /// Parameter StateModelName of procedure {P_ResolveCustomResourceStateReclassificationPermissionsForAllRolesOfUser}
        /// </summary>
        public const string CustomResolveCustomResourceStateReclassificationPermissionsForAllRolesOfUserStateModelStateName = "StateModelStateName";

        /// <summary>
        /// Parameter Reason of procedure {P_ResolveCustomResourceStateReclassificationPermissionsForAllRolesOfUser}
        /// </summary>
        public const string CustomResolveCustomResourceStateReclassificationPermissionsForAllRolesOfUserReason = "Reason";

        /// <summary>
        /// Schema and name of the stored procedure responsible for retrieving resource stop state history for reclassification.
        /// </summary>
        public const string CustomGetResourceStateHistoryForStopReclassification = "[Custom].[P_GetResourceStateHistoryForStopReclassification]";

        /// <summary>
        /// Schema and name of the table type for the State Model State attributes filters.
        /// </summary>
        public const string CustomGetResourceStateHistoryForStopReclassificationStateModelStateAttributeFiltersTableType = "[Custom].[GetResourceStateHistoryForStopReclassificationStateModelStateAttributeFiltersType]";

        /// <summary>
        /// Name of the attribute name column for the State Model State attribute filters table.
        /// </summary>
        public const string CustomGetResourceStateHistoryForStopReclassificationStateModelStateAttributeFiltersTableTypeAttributeNameColumn = "StateModelStateAttributeName";

        /// <summary>
        /// Name of the attribute value column for the State Model State attribute filters table.
        /// </summary>
        public const string CustomGetResourceStateHistoryForStopReclassificationStateModelStateAttributeFiltersTableTypeAttributeValueColumn = "StateModelStateAttributeValue";

        /// <summary>
        /// Parameter FromDate of stored procedure {P_GetResourceStateHistoryForStopReclassification}.
        /// </summary>
        public const string CustomGetResourceStateHistoryForStopReclassificationFromDateParameter = "FromDate";

        /// <summary>
        /// Parameter ToDate of stored procedure {P_GetResourceStateHistoryForStopReclassification}.
        /// </summary>
        public const string CustomGetResourceStateHistoryForStopReclassificationToDateParameter = "ToDate";

        /// <summary>
        /// Parameter ResourceId of stored procedure {P_GetResourceStateHistoryForStopReclassification}.
        /// </summary>
        public const string CustomGetResourceStateHistoryForStopReclassificationResourceIdParameter = "ResourceId";

        /// <summary>
        /// Parameter MicrostopFilter of stored procedure {P_GetResourceStateHistoryForStopReclassification}.
        /// </summary>
        public const string CustomGetResourceStateHistoryForStopReclassificationMicrostopFilterParameter = "MicrostopFilter";

        /// <summary>
        /// Parameter StateModelStateAttributeFilters of stored procedure {P_GetResourceStateHistoryForStopReclassification}.
        /// </summary>
        public const string CustomGetResourceStateHistoryForStopReclassificationStateModelStateAttributeFiltersParameter = "StateModelStateAttributeFilters";

    }
}
