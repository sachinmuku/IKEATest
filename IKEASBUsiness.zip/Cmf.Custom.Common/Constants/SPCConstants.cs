﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Common
{
    public static partial class IKEAConstants
    {
        #region Constants

        /// <summary>
        /// Notify
        /// </summary>
        public const string Notify = "Notify";

        /// <summary>
        /// Block
        /// </summary>
        public const string Block = "Block";

        /// <summary>
        /// Block MO
        /// </summary>
        public const string BlockMO = "BlockMO";

        /// <summary>
        /// Step
        /// </summary>
        public const string Step = "Step";

        /// <summary>
        /// Chart
        /// </summary>
        public const string Chart = "Chart";
        
        /// <summary>
        /// Parameter
        /// </summary>
        public const string Parameter = "Parameter";

        /// <summary>
        /// RuleName
        /// </summary>
        public const string RuleName = "Rule_Name";

        /// <summary>
        /// ChartDataPoint
        /// </summary>
        public const string ChartDataPoint = "ChartDataPoint";

        /// <summary>
        /// Role
        /// </summary>
        public const string Role = "Role";

        /// <summary>
        /// Employee
        /// </summary>
        public const string Employee = "Employee";

        /// <summary>
        /// Severity
        /// </summary>
        public const string Severity = "Warning";

        /// <summary>
        /// NotificationType
        /// </summary>
        public const string NotificationType = "System";

        #endregion

        #region Localized Messages

        /// <summary>
        /// SPC violation occurred on Resource {0}.
        /// </summary>
        public const string CustomSPCViolationNotificationHeader = "CustomSPCViolationNotificationHeader";

        /// <summary>
        /// It was not possible to find the values for Chart Name and Parameter Name.
        /// </summary>
        public const string CustomSPCViolationParameterChartNotFound = "CustomSPCViolationParameterChartNotFound";

        /// <summary>
        /// Missing Mandatory Properties.
        /// </summary>
        public const string CustomWE1SpcViolationRule = "CustomWE1SpcViolationRule";

        /// <summary>
        /// SPC Violation didn't create a new MAO
        /// </summary>
        public const string CustomTitleSPCViolation = "CustomTitleSPCViolation";

        /// <summary>
        /// SPC Violation didn't create a new MAO because there is a MAO already created in the system. MAO name = {0}
        /// </summary>
        public const string CustomDetailsSPCViolation = "CustomDetailsSPCViolation";

        #endregion

        #region Configuration

        /// <summary>
        /// SPCDefaultHoldReason 
        /// </summary>
        public const string SPCDefaultHoldReason = "/Cmf/Custom/SPC/HoldReason";

        /// <summary>
        /// Role to notify 
        /// </summary>
        public const string RoleToNotify = "/Cmf/Custom/SPC/Role";
        #endregion
    }
}
