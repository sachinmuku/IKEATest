﻿
namespace Cmf.Custom.IKEA.Common
{
    public static partial class IKEAConstants
    {

        #region General

        /// <summary>
        /// System ERP
        /// </summary>
        public const string NiceLabelSystem = "NiceLabel";

        /// <summary>
        /// NiceLabelNotifyTrackIn message type
        /// </summary>
        public const string NiceLabelNotifyTrackInMessageType = "NiceLabelNotifyTrackIn";

        /// <summary>
        /// NiceLabelNotifyStop message type
        /// </summary>
        public const string NiceLabelNotifyStopMessageType = "NiceLabelNotifyStop";

        /// <summary>
        ///NiceLabelNotifyTrackIn - Event Name
        /// </summary>
        public const string NiceLabelNotifyTrackInEventName = "NiceLabelNotifyTrackIn";

        /// <summary>
        ///NiceLabelNotifyStop - Event Name
        /// </summary>
        public const string NiceLabelNotifyStopEventName = "NiceLabelNotifyStop";

        /// <summary>
        /// NiceLabelSSCCInfo message type
        /// </summary>
        public const string NiceLabelSSCCInfoMessageType = "NiceLabelSSCCInfo";

        /// <summary>
        /// NiceLabelSSCCInfo - Event Name
        /// </summary>
        public const string NiceLabelSSCCInfoEventName = "NiceLabelSSCCInfo";

        /// <summary>
        /// NiceLabelNotifyStop endpoint
        /// </summary>
        public const string NiceLabelNotifyStopEndpoint = "NiceLabelNotifyStop";

        #endregion

        #region Localized Messages

        /// <summary>
        /// Unable to obtain a access token from NiceLabel
        /// </summary>
        public const string CustomNiceLabelUnableToObtainTokenLocalizedMessage = "CustomNiceLabelUnableToObtainToken";

        /// <summary>
        /// No Base Endpoint was configured for NiceLabel
        /// </summary>
        public const string CustomNiceLabelMissingBaseEndpointLocalizedMessage = "CustomNiceLabelMissingBaseEndpoint";

        /// <summary>
        /// Exception returned by NiceLabel: {0}
        /// </summary>
        public const string CustomNiceLabelExceptionLocalizedMessage = "CustomNiceLabelException";

        /// <summary>
        /// Some of the NiceLabel configurations are missing
        /// </summary>
        public const string CustomNiceLabelMissingConfigurationsLocalizedMessage = "CustomNiceLabelMissingConfigurations";

        /// <summary>
        /// NiceLabel Request/Response is not in the correct format: {0}.
        /// </summary>
        public const string CustomNiceLabelInvalidResponseLocalizedMessage = "CustomNiceLabelInvalidResponse";

        /// <summary>
        /// No endpoint found on Configuration: {0}.
        /// </summary>
        public const string CustomNiceLabelMissingEndpointConfigLocalizedMessage = "CustomNiceLabelMissingEndpointConfig";

        /// <summary>
        /// No API/Message was found.
        /// </summary>
        public const string CustomNiceLabelNoApiMessageFoundLocalizedMessage = "CustomNiceLabelNoApiMessageFound";

        /// <summary>
        /// NiceLabel Request/Response deserialization failed, variable is null.
        /// </summary>
        public const string CustomNiceLabelDeserializationFailedLocalizedMessage = "CustomNiceLabelDeserializationFailed";

        /// <summary>
        /// The recipeID for {0} and {1} is not present in CustomNiceLabelContext smart table.
        /// </summary>
        public const string CustomNiceLabelRecipeIDNotConfiguredLocalizedMessage = "CustomNiceLabelRecipeIDNotConfigured";

        /// <summary>
        /// The printing queue Resource {0} has the attribute {1} set to {2}, but should be {3} instead.
        /// </summary>
        public const string CustomNiceLabelInvalidPrintingQueueSystemLocalizedMessage = "CustomNiceLabelInvalidPrintingQueueSystem";

        /// <summary>
        /// No resource associated to material {0}.
        /// </summary>
        public const string CustomNiceLabelNoResourceAssociatedToMaterial = "CustomNiceLabelNoResourceAssociatedToMaterial";

        /// <summary>
        /// Error message to be thrown when a Nice Label Integration Entry was not on the NiceLabelIntegrationEntries Generic Table
        /// The {0} Integration Entry was not present in the CustomNiceLabelIntegrationEntries Generic Table.
        /// </summary>
        public const string CustomNiceLabelIntegrationEntryIntegrationEntryNotOnGenericTable = "CustomNiceLabelIntegrationEntryIntegrationEntryNotOnGenericTable";

        /// <summary>
        /// Message to de displayed in a notification title - NiceLabel error Handler
        /// NiceLabel integration entry failed
        /// </summary>
        public const string CustomNotificationTitleForNiceLabelErrorHandler = "CustomNotificationTitleForNiceLabelErrorHandler";

        /// <summary>
        /// Message to de displayed in a notification details - NiceLabel error Handler
        /// Integration Entry {0} with type {1} has failed due to the following reason: {2}"
        /// </summary>
        public const string CustomNotificationDetailsForNiceLabelErrorHandler = "CustomNotificationDetailsForNiceLabelErrorHandler";

        #endregion

        #region Configurations

        /// <summary>
        /// NiceLabel - Token
        /// </summary>
        public const string NiceLabelToken = "/Cmf/Custom/NiceLabel/Token";

        /// <summary>
        /// NiceLabel - Username
        /// </summary>
        public const string NiceLabelUsername = "/Cmf/Custom/NiceLabel/Username";

        /// <summary>
        /// NiceLabel - Password
        /// </summary>
        public const string NiceLabelPassword = "/Cmf/Custom/NiceLabel/Password";

        /// <summary>
        /// M3 - Token Endpoint
        /// </summary>
        public const string NiceLabelTokenEndpoint = "/Cmf/Custom/NiceLabel/TokenEndpoint";

        /// <summary>
        /// NiceLabel - Base Endpoint
        /// </summary>
        public const string NiceLabelBaseEndpoint = "/Cmf/Custom/NiceLabel/BaseEndpoint";

        /// <summary>
        /// NiceLabel - Endpoint base path
        /// </summary>
        public const string NiceLabelEndpoint = "/Cmf/Custom/NiceLabel/Endpoint/";

        /// <summary>
        /// NiceLabel - Authentication required flag
        /// </summary>
        public const string NiceLabelIsToAuthenticate = "/Cmf/Custom/NiceLabel/Authentication/IsToAuthenticate";

        /// <summary>
        /// NiceLabel - Is Enabled
        /// </summary>
        public const string NiceLabelIsEnabled = "/Cmf/Custom/NiceLabel/IsEnabled";

        #endregion

        #region Tables

        #endregion

        #region Smart Tables

        /// <summary>
        ///  Smart Table CustomNiceLabelContext name
        /// </summary>
        public const string CustomNiceLabelContextSmartTable = "CustomNiceLabelContext";

        /// <summary>
        /// Name of the column Resource in Smart Table{CustomNiceLabelContext}
        /// </summary>
        public const string CustomNiceLabelContextResourceColumn = "Resource";

        /// <summary>
        /// Name of the column Product in Smart Table{CustomNiceLabelContext}
        /// </summary>
        public const string CustomNiceLabelContextProductColumn = "Product";

        /// <summary>
        /// Name of the column RecipeID in Smart Table{CustomNiceLabelContext}
        /// </summary>
        public const string CustomNiceLabelContextRecipeIDColumn = "RecipeID";

        /// <summary>
        /// Name of the message type for the messages that are sent from NiceLabel with the SSCC information
        /// </summary>
        public const string CustomNiceLabelMessageTypeSSCC = "NiceLabelSSCCInfo";

        #endregion

        #region GenericTables

        /// <summary>
        ///  Generic Table CustomNiceLabelIntegrationEntries name
        /// </summary>
        public const string CustomNiceLabelIntegrationEntries = "CustomNiceLabelIntegrationEntries";

        /// <summary>
        /// Name of the column Resource in Generic Table{CustomNiceLabelIntegrationEntries}
        /// </summary>
        public const string CustomNiceLabelIntegrationEntriesResourceColumn = "Resource";

        /// <summary>
        /// Name of the column Material in Generic Table{CustomNiceLabelIntegrationEntries}
        /// </summary>
        public const string CustomNiceLabelIntegrationEntriesMaterialColumn = "Material";

        /// <summary>
        /// Name of the column Integration Entry in Generic Table{CustomNiceLabelIntegrationEntries}
        /// </summary>
        public const string CustomNiceLabelIntegrationEntriesIntegrationEntryColumn = "IntegrationEntry";

        #endregion

        #region Integration Entry Attributes

        /// <summary>
        /// The current number of retries for the integration entry
        /// </summary>
        public const string IntegrationEntryAttributeNiceLabelCurrentNumberOfRetries = "CurrentNumberOfRetries";

        #endregion
    }
}
