﻿namespace Cmf.Custom.IKEA.Common
{
    public static partial class IKEAConstants
    {
        #region Constants

        /// <summary>
        /// Alarm Code
        /// </summary>
        public const string AlarmCode = "AlarmCode";

        /// <summary>
        /// Alarm Category
        /// </summary>
        public const string AlarmCategory = "AlarmCategory";

        /// <summary>
        /// TopMost Resource
        /// </summary>
        public const string TopMostResource = "TopMostResource";

        /// <summary>
        /// Area
        /// </summary>
        public const string Area = "Area";

        /// <summary>
        /// Facility
        /// </summary>
        public const string Facility = "Facility";

        /// <summary>
        /// MESNotification 
        /// </summary>
        public const string MESNotification = "MESNotification";

        /// <summary>
        /// EmailNotification 
        /// </summary>
        public const string EmailNotification = "EmailNotification";

        /// <summary>
        /// DistributionList 
        /// </summary>
        public const string DistributionList = "DistributionList";

        /// <summary>
        /// NotifyCheckedInEmployees 
        /// </summary>
        public const string NotifyCheckedInEmployees = "NotifyCheckedInEmployees";

        /// <summary>
        /// NotificatonRole
        /// </summary>
        public const string NotificatonRole = "NotificationRole";

        /// <summary>
        /// BlockFeeder 
        /// </summary>
        public const string BlockFeeder = "BlockFeeder";

        /// <summary>
        /// BlockProducedUnits 
        /// </summary>
        public const string BlockProducedUnits = "BlockProducedUnits";

        /// <summary>
        /// AdministratorRoleName 
        /// </summary>
        public const string AdministratorRoleName = "Administrators";

        /// <summary>
        /// AlarmNotificationNameGeneratorName 
        /// </summary>
        public const string AlarmNotificationNameGeneratorName = "CustomAlarmOccurrenceNameGenerator";

        /// <summary>
        /// MaintenanceActivity 
        /// </summary>
        public const string MaintenanceActivity = "MaintenanceActivity";

        #endregion

        #region Localized Messages

        /// <summary>
        /// 
        /// The following alarm was logged:
        /// Alarm Code: {0}
        /// Category: {1}
        /// Resource: {2}
        /// Area: {3}
        /// Facility: {4}
        /// 
        /// </summary>
        public const string CustomTopMostResourceAlarmLoggedLocalizedMessage = "CustomTopMostResourceAlarmLoggedLocalizedMessage";

        /// <summary>
        /// 
        /// The following alarm was logged:
        /// Alarm Code: {0}
        /// Category: {1}
        /// Resource: {2}
        /// Subresource: {3}
        /// Area: {4}
        /// Facility: {5}
        /// 
        /// </summary>
        public const string CustomSubResourceAlarmLoggedLocalizedMessage = "CustomSubResourceAlarmLoggedLocalizedMessage";

        /// <summary>
        /// Alarm {0} was logged but could not be checked for additional actions.
        /// </summary>
        public const string CustomAlarmLoggedButNotCheckedLocalizedMessage = "CustomAlarmLoggedButNotCheckedLocalizedMessage";

        /// <summary>
        /// An Alarm of type '{0}', Category '{1}' and Severity {2} was logged. Details: {3}.
        /// </summary>
        public const string CustomAlarmLoggedAndCheckedLocalizedMessage = "CustomAlarmLoggedAndCheckedLocalizedMessage";

        /// <summary>
        /// An Alarm of type '{0}', Category '{1}' and Severity {2} was logged, but no Details were found.
        /// </summary>
        public const string CustomAlarmLoggedAndCheckedNoDetailsLocalizedMessage = "CustomAlarmLoggedAndCheckedNoDetailsLocalizedMessage";

        /// <summary>
        /// Resource {0} alarm notification.
        /// </summary>
        public const string CustomAlarmLoggedTitle = "CustomAlarmLoggedTitle";

        /// <summary>
        /// SPC Rule {0} violation detected on Chart {1}
        /// </summary>
        public const string CustomSPCViolationEmailTitle = "CustomSPCViolationEmailTitle";

        /// <summary>
        /// Data for Hold reason {0} was not found in the system. 
        /// </summary>
        public const string CustomNoHoldReasonDefined = "CustomNoHoldReasonDefined";

        /// <summary>
        /// Error sending the email. 
        /// </summary>
        public const string CustomEmailSendError = "CustomEmailSendError";

        /// <summary>
        /// Data for alarm {0} was not found in the system.
        /// </summary>
        public const string CustomAlarmNotFound = "CustomAlarmNotFound";

        /// <summary>
        /// The resource {0} was not found in the system.
        /// </summary>
        public const string CustomResourceNotFound = "CustomResourceNotFound";

        /// <summary>
        /// The micro stop alarm occurrence was not logged because either the start or end date is not filled or end date is before start date.
        /// </summary>
        public const string CustomLogMicroStopAlarmOccurrenceError = "CustomLogMicroStopAlarmOccurrenceError";

        #endregion

        #region Configuration

        /// <summary>
        /// AlarmHandlingHoldReason 
        /// </summary>
        public const string AlarmHandlingHoldReason = "/Cmf/Custom/AlarmHandling/HoldReason";

        /// <summary>
        /// Alarm Code Micro Stop Identifier
        /// </summary>
        public const string MicroStopIdentifier = "/Cmf/Custom/AlarmHandling/MicroStopIdentifier";

        /// <summary>
        /// OEE State to be forced when alarm required configuration
        /// </summary>
        public const string OEEStateToBeForcedWhenAlarmRequiredConfig = "/Cmf/Custom/AlarmHandling/OEEStateToBeForcedWhenAlarmRequired/";

        /// <summary>
        /// Maintenance Management Source automation configuration
        /// </summary>
        public const string AutomationMaintenanceSource = "/Cmf/Custom/MaintenanceManagement/MaintenanceSourceTypes/Automation";

        /// <summary>
        /// Maintenance Management Source SPC configuration
        /// </summary>
        public const string SPCMaintenanceSource = "/Cmf/Custom/MaintenanceManagement/MaintenanceSourceTypes/SPC";

        /// <summary>
        /// Maintenance Management Source manual configuration
        /// </summary>
        public const string ManualMaintenanceSource = "/Cmf/Custom/MaintenanceManagement/MaintenanceSourceTypes/Manual";

        #endregion

        #region Localized Messages

        /// <summary>
        /// Source: {0}.
        /// </summary>
        public const string CustomRequestMAORequestComment = "CustomRequestMAORequestComment";

        /// <summary>
        /// Cannot terminate the CustomAlarmOccurrence, because the alarm exists in IoT persistence
        /// </summary>
        public const string CustomAlarmTerminateNotAllowed = "CustomAlarmTerminateNotAllowed";

        /// <summary>
        /// Failed to terminate CustomAlarmOccurrence. Please ensure the IoT for resource '{0}' is running.
        /// </summary>
        public const string CustomAlarmTerminateFailToValidate = "CustomAlarmTerminateFailToValidate";

        #endregion
    }
}
