﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Common
{
    public static partial class IKEAConstants
    {

        #region BOMProduct Attributes

        /// <summary>
        /// BOM Product
        /// </summary>
        public const string BomProduct= "BOMProduct";

        /// <summary>
        /// BOM Product - ProcessSegment
        /// </summary>
        public const string BomProductProcessSegmentAttribute = "ProcessSegment";

        /// <summary>
        /// BOM Product - SubProcessSegment
        /// </summary>
        public const string BomProductSubProcessSegmentAttribute = "SubProcessSegment";

        /// <summary>
        /// BOM Product - SubProcessSegment
        /// </summary>
        public const string BomProductIsByProductSegmentAttribute = "IsByProductSegment";

        /// <summary>
        /// BOM Product - ERPBOMOperationSequence
        /// </summary>
        public const string BomProductERPBOMOperationSequenceAttribute = "ERPBOMOperationSequence";

        /// <summary>
        /// BOM Product - CustomSourceStep
        /// </summary>
        public const string BomProductCustomSourceStepAttribute = "CustomSourceStep";

        #endregion

        #region BOM Attributes

        /// <summary>
        /// Attribute that indicates if the bom is orderless
        /// </summary>
        public const string CustomBOMIsOrderlessAttribute = "IsOrderlessBOM";
        
        /// <summary>
        /// Attribute that indicates the bom structure type. (Only contains information when orderless)
        /// </summary>
        public const string CustomBOMStructureTypeAttribute = "StructureType";

        #endregion

        #region LocalizedMessages

        /// <summary>
        /// Durable product {0} is not part of any of the following BOMs of the orders in the resource: {1}.
        /// </summary>
        public const string CustomDurableProductNotFoundInBomsLocalizedMessage = "CustomDurableProductNotFoundInBoms";

        /// <summary>
        /// Durable product {0} BOM positions were all already occupied: {1}.
        /// </summary>
        public const string CustomDurableProductConfiguredPositionsTakenLocalizedMessage = "CustomDurableProductConfiguredPositionsTaken";

        /// <summary>
        /// No free durable positions in this resource {0}.
        /// </summary>
        public const string CustomNoFreeDurablePositionsInResourceLocalizedMessage = "CustomNoFreeDurablePositionsInResource";

        /// <summary>
        /// BOM {0} is not a valid orderless BOM for the Product {1} and Resource {2} combination.
        /// </summary>
        public const string CustomCouldntResolveOrderlessBOMs = "CustomCouldntResolveOrderlessBOMs";

        /// <summary>
        /// No resource has been found for BOM {0} with Process segment {1}.
        /// </summary>
        public const string CustomCouldntResolveBOMResourceLocalizedMessage = "CustomCouldntResolveBOMResource";

        #endregion

        #region Configurations
        /// <summary>
        /// Indicates if custom assemble is enabled
        /// </summary>
        public const string CustomAssembleEnabled = "/Cmf/Custom/Assemble/IsEnabled";
        #endregion
    }
}
