﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Common
{
    public static partial class IKEAConstants
    {
        #region Constants

        /// <summary>
        /// Rule name to handle the timer for manual data posting notifications:
        /// </summary>
        public const string CustomManualDataPostingNotification = "CustomManualDataPostingNotification";

        #endregion

        #region Configuration

        /// <summary>
        /// Configuration path containing the notification type for the replenishment
        /// </summary>
        public const string CustomMaterialTransferTargetCompletionTimePath = "/Cmf/Custom/MaterialTracking/MaterialTransferTargetCompletionTime";

        /// <summary>
        /// Configuration path containing the notification type for the material movement request
        /// </summary>
        public const string CustomMaterialTransferRequestTypePath = "/Cmf/Custom/MaterialTracking/MaterialTransferRequestType";
 
        /// <summary>
        /// Config containin the time for manual data posting notifications frequency
        /// </summary>
        public const string CustomManualDataPostingNotificationTimerFrequency = "/Cmf/Custom/Notifications/ManualDataPosting/NotificationTimerFrequency";

        /// <summary>
        /// Resource Manual Data Posting Notification Severity
        /// </summary>
        public const string CustomManualDataPostingNotificationSeverity = "/Cmf/Custom/Notifications/ManualDataPosting/NotificationSeverity";

        /// <summary>
        /// Resource Manual Data Posting Notification Type
        /// </summary>
        public const string CustomManualDataPostingNotificationType = "/Cmf/Custom/Notifications/ManualDataPosting/NotificationType";

        /// <summary>
        /// Manual Data Posting Notification create tasks after crearing the notification
        /// </summary>
        public const string CustomManualDataPostingNotificationCreateTasks = "/Cmf/Custom/Notifications/ManualDataPosting/CreateTasks";

        /// <summary>
        /// Manual Data Posting Notification create tasks even if there are previous open tasks for the same logical chart
        /// </summary>
        public const string CustomManualDataPostingNotificationStackTasks = "/Cmf/Custom/Notifications/ManualDataPosting/StackTasks";

        /// <summary>
        /// The time that the task should be completed
        /// </summary>
        public const string CustomManualDataPostingNotificationTaskCompletionTime = "/Cmf/Custom/Notifications/ManualDataPosting/TaskCompletionTime";


        #endregion

        #region Attributes

        /// <summary>
        /// Indicates if the name of the logical chart that triggered this notification
        /// </summary>
        public const string CustomNotificationLogicalChartName = "LogicalChartName";

        #endregion

        #region Localized Messages

        /// <summary>
        /// A Task could not be generated due to missing attributes in the following notification: {0}
        /// </summary>
        public const string CustomMaterialTransferAttributesErrorMessageLocalizedMessage = "CustomMaterialTransferAttributesErrorMessage";

        /// <summary>
        /// The default severity for the notifications created by the manual data posting timer is not defined in the configuration '{0}'.
        /// </summary>
        public const string CustomManualDataPostingNotificationSeverityMissingLocalizedMessage = "CustomManualDataPostingNotificationSeverityMissing";

        /// <summary>
        /// Timer name for for manual data posting notifications:
        /// </summary>
        public const string CustomManualDataPostingNotificationTimerName = "CustomNotifyLogicalChartsManualDataPosting";

        /// <summary>
        /// The description for the timer that will handle the manual data posting.
        /// </summary>
        public const string CustomManualDataPostingNotificationTimerDescriptionLocalizedMessage = "CustomManualDataPostingNotificationTimerDescription";

        /// <summary>
        /// Manual Data Posting Required on Logical Chart
        /// </summary>
        public const string CustomManualDataPostingNotificationTitleLocalizedMessage = "CustomManualDataPostingNotificationTitle";

        /// <summary>
        /// Logical Chart: '{0}'. The frequency for this operation is every {1} minutes.
        /// </summary>
        public const string CustomManualDataPostingNotificationDetailsLocalizedMessage = "CustomManualDataPostingNotificationDetails";

        /// <summary>
        /// Manual Data Posting Required on Logical Chart {0}
        /// </summary>
        public const string CustomManualDataPostingNotificationEmailTitleLocalizedMessage = "CustomManualDataPostingNotificationEmailTitle";

        /// <summary>
        /// The frequency for this operation is every {1} minutes.
        /// </summary>
        public const string CustomManualDataPostingNotificationEmailDetailsLocalizedMessage = "CustomManualDataPostingNotificationEmailDetails";

        /// <summary>
        /// Atleast one Palletize Resource needs to be selected.
        /// </summary>
        public const string CustomPalletizeNotSelectedNotificationLocalizedMessage = "CustomPalletizeNotSelectedNotification";
        #endregion
    }
}
