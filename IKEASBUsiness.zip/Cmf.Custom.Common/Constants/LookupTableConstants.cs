﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Common
{
    public static partial class IKEAConstants
    {

        /// <summary>
        /// Lookup table containing all material types defined as 'Good'
        /// </summary>
        public const string CustomMaterialGoodQualityTypes = "CustomMaterialGoodQualityTypes";

        /// <summary>
        /// Lookup table containing Notification Severity
        /// </summary>
        public const string NotificationSeverityLookupTableName = "NotificationSeverity";
        /// <summary>
        /// Lookup table containing all the ERP reportable forms
        /// </summary>
        public const string CustomERPReportableForms = "CustomERPReportableForms";

        /// <summary>
        /// Lookup table containing the printer codes for Unit Loading Labels for Manual Printing
        /// </summary>
        public const string CustomUnitLoadingPrinterCodeLookupTable = "UnitLoadingPrinterCode";

        /// <summary>
        /// Lookup table containing the pallet types for Unit Loading Labels for Manual Printing
        /// </summary>
        public const string CustomUnitLoadingPalletTypeLookupTable = "UnitLoadingPalletType";
    }
}
