﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Common
{
    /// <summary>
    /// This class contains constants part of material tracking
    /// </summary>
    public static partial class IKEAConstants
    {
        #region general

        /// <summary>
        /// Material request MaterialTransferFromArea attribute
        /// </summary>
        public const string MaterialTransferFromArea = "MaterialTransferFromArea";
        
        /// <summary>
        /// Material request MaterialTransferFromLocation attribute
        /// </summary>
        public const string MaterialTransferFromLocation = "MaterialTransferFromLocation";
       
        /// <summary>
        /// Material request MaterialTransferFromFacility attribute
        /// </summary>
        public const string MaterialTransferFromFacility = "MaterialTransferFromFacility";
        
        /// <summary>
        /// Material request MaterialTransferRequiredProduct attribute
        /// </summary>
        public const string MaterialTransferRequiredProduct = "MaterialTransferRequiredProduct";
        
        /// <summary>
        /// Material request MaterialTransferRequiredQuantity attribute
        /// </summary>
        public const string MaterialTransferRequiredQuantity = "MaterialTransferRequiredQuantity";
        
        /// <summary>
        /// Material request MaterialTransferRequiredMaterial attribute
        /// </summary>
        public const string MaterialTransferRequiredMaterial = "MaterialTransferRequiredMaterial";
        
        /// <summary>
        /// Material request MaterialTransferToArea attribute
        /// </summary>
        public const string MaterialTransferToArea = "MaterialTransferToArea";
        
        /// <summary>
        /// Material request MaterialTransferToLocation attribute
        /// </summary>
        public const string MaterialTransferToLocation = "MaterialTransferToLocation";
        
        /// <summary>
        /// Material request MaterialTransferToFacility attribute
        /// </summary>
        public const string MaterialTransferToFacility = "MaterialTransferToFacility";

        /// <summary>
        /// Material request SourceMaterialRequestId attribute
        /// </summary>
        public const string SourceMaterialRequestId = "SourceMaterialRequestId";

        /// <summary>
        /// DEE Context for TerminateStockingPointTrackersAndTasks TerminateNotifications
        /// </summary>
        public const string TerminateStockingPointTrackersAndTasksTerminateNotifications = "TerminateStockingPointTrackersAndTasks_TerminateNotifications";

        #endregion

        #region Configuration

        /// <summary>
        /// Configuration path from where the default completed material form is extracted
        /// </summary>
        public const string CustomCompletedMaterialFormPath = "/Cmf/Custom/MaterialTracking/CompletedMaterialForm";

        /// <summary>
        /// Configuration path from where the production order generated material form is extracted
        /// </summary>
        public const string IKEAOrderMaterialFormPath = "/Cmf/Custom/MaterialTracking/OrderMaterialForm";

        /// <summary>
        /// Configuration path from where the production order generated material form is extracted
        /// </summary>
        public const string IKEACompletedMaterialDefaultTypePath = "/Cmf/Custom/MaterialTracking/CompletedMaterialDefaultType";

        /// <summary>
        /// Configuration path from where the default ReRun Material Type extracted
        /// </summary>
        public const string CustomReRunMaterialDefaultTypePath = "/Cmf/Custom/MaterialTracking/ReRunMaterialType";

        /// <summary>
        /// Configuration path from where the default LeftOver Material Type extracted
        /// </summary>
        public const string CustomLeftOverMaterialDefaultTypePath = "/Cmf/Custom/MaterialTracking/LeftOverMaterialType";

        /// <summary>
        /// Configuration path from where the default DirectRepair Material Type extracted
        /// </summary>
        public const string CustomDirectRepairMaterialDefaultTypePath = "/Cmf/Custom/MaterialTracking/DirectRepairMaterialType";

        /// <summary>
        /// Configuration path from where the default ProcessLoss Material Type extracted
        /// </summary>
        public const string CustomProcessLossMaterialDefaultTypePath = "/Cmf/Custom/MaterialTracking/Types/DefaultProcessLossType/";
        
        /// <summary>
        /// Configuration path from where the default Outsorted Material Type extracted
        /// </summary>
        public const string CustomOutsortedMaterialDefaultTypePath = "/Cmf/Custom/MaterialTracking/Types/DefaultOutsortedType/";

        /// <summary>
        /// Configuration path that indicates the Loss Reason for a Process Loss
        /// </summary>
        public const string MaterialTrackingProcessLossReason = "/Cmf/Custom/MaterialTracking/ProcessLossReason";

        /// <summary>
        /// Configuration path that indicates if prefixes can be used in the name generator
        /// </summary>
        public const string UseNameGeneratorPrefixes = "/Cmf/Custom/MaterialTracking/UseNameGeneratorPrefixes";

        /// <summary>
        /// Indicates if the validation of workcenter has to be done at dispatch
        /// </summary>
        public const string ValidateWorkCenterAtDispatch = "/Cmf/Custom/MaterialTracking/ValidateWorkCenterAtDispatch";
        #endregion

        #region Name Generators

        /// <summary>
        /// Default IKEA Material name generator
        /// </summary>
        public const string IKEAMaterialNameGeneratorName = "CustomMaterialNameGenerator";

        /// <summary>
        /// base for IKEA form name generators
        /// </summary>
        public const string IKEAMaterialFormNameGeneratorBase = "Custom{0}MaterialNameGenerator";

        /// <summary>
        /// Group MO name generator name
        /// </summary>
        public const string CustomGroupMOMaterialNameGenerator = "CustomGroupMOMaterialNameGenerator";

        /// <summary>
        /// Durable name generator name
        /// </summary>
        public const string CustomDurableMaterialNameGenerator = "CustomDurableMaterialNameGenerator";

        /// <summary>
        /// Ull Label name generator name
        /// </summary>
        public const string CustomUllLabelNameGenerator = "CustomUllLabelNameGenerator";

        /// <summary>
        /// WMS new material name generator name
        /// </summary>
        public const string CustomWMSMaterialNameGenerator = "CustomWMSMaterialNameGenerator";

        /// <summary>
        /// Product Order name generator name
        /// </summary>
        public const string CustomProductOrderlessNameGenerator = "CustomProductOrderlessNameGenerator";

        /// <summary>
        /// Material Order name generator name
        /// </summary>
        public const string CustomMaterialOrderlessNameGenerator = "CustomMaterialOrderlessNameGenerator";

        /// <summary>
        /// Outsorted Pallet name generator name
        /// </summary>
        public const string CustomOutsortedPalletNameGenerator = "CustomOutsortedPalletNameGenerator";

        /// <summary>
        /// WMS tracker name generator name
        /// </summary>
        public const string CustomWMSMaterialTrackerNameGenerator = "CustomWMSMaterialTrackerNameGenerator";

        #endregion

        #region Recipe Selection

        /// <summary>
        /// Name of the operation attribute for the alternative sub resources at track in
        /// </summary>
        public const string OperationAttributeAlternativeSubResources = "AlternativeSubResources";

        /// <summary>
        /// Name of the operation attribute for the default completion quantity at track in
        /// </summary>
        public const string OperationAttributeDefaultCompletionQuantity = "DefaultCompletionQuantity";

        /// <summary>
        /// Name of the operation attribute for the selected recipe at track in
        /// </summary>
        public const string OperationAttributeSelectedRecipe = "SelectedRecipe";

        /// <summary>
        /// Name of the operation attribute for the main feeder name at track in
        /// </summary>
        public const string OperationAttributeMainFeederName = "MainFeederName";

        /// <summary>
        /// Name of the operation attribute for the update dimension attributes flag at track in
        /// </summary>
        public const string OperationAttributeUpdateDimensionAttributes = "UpdateDimensionAttributes";

        /// <summary>
        /// Name of the operation attribute for the length dimension at track in
        /// </summary>
        public const string OperationAttributeLength = "Length";

        /// <summary>
        /// Name of the operation attribute for the width dimension at track in
        /// </summary>
        public const string OperationAttributeWidth = "Width";

        /// <summary>
        /// Name of the operation attribute for the thickness dimension at track in
        /// </summary>
        public const string OperationAttributeThickness = "Thickness";

        /// <summary>
        /// Name of the operation attribute for the weight dimension at track in
        /// </summary>
        public const string OperationAttributeWeight = "Weight";

        #endregion

        #region Palletization

        /// <summary>
        /// Name of the data collection parameter that identifies the need for the generation a new material in the palletization process
        /// </summary>
        public const string CustomUnitCompletionDataCollectionParameterName = "MOCompletedQuantity";

        /// <summary>
        /// Name of the operation attribute for the completed quantity
        /// </summary>
        public const string OperationAttributeCompletedQuantity = "CompletedQuantity";

        /// <summary>
        /// Name of the operation attribute for the material type
        /// </summary>
        public const string OperationAttributeType = "Type";

        /// <summary>
        /// Name of the operation attribute for the outsorter resource selected by the operator
        /// </summary>
        public const string OperationAttributePalletizeResource = "PalletizeResource";
        
        /// <summary>
        /// Name of the operation attribute for the flag identifying if the TrackOut comes from the GUI
        /// </summary>
        public const string OperationAttributeGUISource = "GUISource";

        #endregion

        #region Localized Message Names

        /// <summary>
        /// Localized message name containing the information that material is not in the expected systemstate
        /// Message: The Material {0} is not in the expected SystemState: {1}
        /// </summary>
        public const string CustomStopMaterialWrongSystemStateMessage = "CustomMaterialAbortWrongSystemState";

        /// <summary>
        /// Localized message name containing the information that material is not in the expected statemodel state
        /// Message: The Material {0} is not in the expected Statemodel State: {1}
        /// </summary>
        public const string CustomStopMaterialWrongStatemodelStateMessage = "CustomMaterialAbortWrongStatemodelState";

        /// <summary>
        /// Localized message name containing the information that resource is not in the expected automation mode
        /// Message: The Resource {0} is not in the expected Automation Mode: {1}
        /// </summary>
        public const string CustomStopMaterialWrongAutomationModeMessage = "CustomMaterialAbortWrongAutomationMode";

        /// <summary>
        /// Localized message name containing the information that the last processed resource was not found
        /// Message: Could not determine the resource for the Material {0}
        /// </summary>
        public const string CustomStopMaterialResourceNotFoundMessage = "CustomMaterialAbortResourceNotFound";

        /// <summary>
        /// Localized message name containing the information that a relation between material and resource was not found
        /// Message: Could not find a valid relation between the Material {0} and the resource {1}
        /// </summary>
        public const string CustomStopMaterialRelationNotFoundMessage = "CustomMaterialAbortRelationNotFound";

        /// <summary>
        /// Localized message name containing the information that no reason to abort was supplied
        /// Message: Connect IOT / Line Controller Error
        /// </summary>
        public const string CustomStopMaterialNoReasonSuppliedMessage = "CustomMaterialAbortNoReasonSupplied";

        /// <summary>
        /// Localized message name containing the information that no automation controller to abort was found on the resource
        /// Message: Could not find automation controller for resource {0} while trying to abort
        /// </summary>
        public const string CustomStopMaterialNoAutomationControllerInstanceFoundMessage = "CustomMaterialAbortNoAutomationControllerInstanceFound";

        /// <summary>
        /// Localized message name containing the information that no automation controller to abort was found on the resource
        /// Message: Could not find automation controller for resource {0} while validation completion conditions
        /// </summary>
        public const string CustomValidateCompletionConditionsNoAutomationControllerInstanceFoundMessage = "CustomValidateCompletionConditionsNoAutomationControllerInstanceFoundMessage";

        /// <summary>
        /// Localized message name containing the information that source material form being palletized is not valid
        /// Message: Cannot perform operation. Provided Source Material {0} is not of form {1}
        /// </summary>
        public const string CustomUnitCompleteInvalidSourceMaterialFormMessage = "CustomUnitCompleteInvalidSourceMaterialForm";

        /// <summary>
        /// Localized message containing error message to be displayed when Order Material Form is not configured
        /// Message: Cannot perform operation. Order Material Form is not configured in the System. Please contact your System Administrator.
        /// </summary>
        public const string CustomOrderMaterialFormNotSetMessage = "CustomOrderMaterialFormNotSet";

        /// <summary>
        /// Localized message containing error message to be displayed when Completed Material Form could not be determined
        /// Message: Cannot perform operation. Completed Material Form could not be determined. Please contact your System Administrator
        /// </summary>
        public const string CustomCompletedUnitFormNotSetMessage = "CustomCompletedUnitFormNotSet";

        /// <summary>
        /// Exception message to be displayed to the user when trying to perform a material completion based on an order material that is not in process
        /// Message: Operation could not be completed. Order Material {0} is not in process.
        /// </summary>
        public const string CustomOrderMaterialNotInProcessMessage = "CustomOrderMaterialNotInProcess";

        /// <summary>
        /// Exception message to be displayed to the user when trying to palletize with quantities equal to or less than zero
        /// Message: Operation could not be completed. Completed quantity is invalid.
        /// </summary>
        public const string CustomUnitCompleteInvalidQuantityMessage = "CustomUnitCompleteInvalidQuantityMessage";

        /// <summary>
        /// Exception message to be displayed when trying to create a completed unit under a type that is not allowed for the resolved completed unit form
        /// Message: Operation could not be completed. Type {0} is not valid for the resolved Material Form {1}
        /// </summary>
        public const string CustomUnitCompleteInvalidTypeMessage = "CustomUnitCompleteInvalidType";

        /// <summary>
        /// Exception message to be displayed when trying to ManualOutsort a ReRun pallet when the pallet is in its final iteration
        /// Message: Cannot Declare ReRun Pallet because Pallet is in final Iteration.
        /// </summary>
        public const string CustomUnitCompleteReRunWrongIterationMessage = "CustomUnitCompleteReRunWrongIteration";

        /// <summary>
        /// Exception message to be displayed when trying to ManualOutsort a Good pallet when the pallet is NOT in its final iteration
        /// Message: Cannot Declare Good Pallet because Pallet is in iteration {0} out of {1}.
        /// </summary>
        public const string CustomUnitCompleteGoodWrongIterationMessage = "CustomUnitCompleteGoodWrongIteration";

        /// <summary>
        /// Material Transfer Notification title
        /// </summary>
        public const string CustomMaterialTransferMovementRequestNotificationTitle = "CustomMaterialTransferMovementRequestNotificationTitle";

        /// <summary>
        ///  Material Transfer Notification Message when there is a Material to be transfered is defined
        ///  Message: Please move {Material.Form} {Material.Name} at {0 - PreBuilt Source location information} to {1 - PreBuild Target Location information}
        /// </summary>
        public const string CustomMaterialTransferMovementRequestMaterialMovementMessage = "CustomMaterialTransferMovementRequestMaterialMovementMessage";

        /// <summary>
        ///  Material Transfer Notification Message when no Material to be transfered is defined but there is a Product and a Quantity
        ///  Message: Please move {MaterialTransferQuantity} {MaterialTransferProduct.DefaultUnits} of {RequiredProduct} to {0 - PreBuilt Target location information}
        /// </summary>
        public const string CustomMaterialTransferMovementRequestMaterialReplenishmentMessage = "CustomMaterialTransferMovementRequestMaterialReplenishmentMessage";

        /// <summary>
        /// Exception message to be displayed when performing manual trackout having UnitCompletionMode  set to Automation
        /// Message: Operation could not be completed. The Resource {0} is set with UnitCompletionMode attribute '{1}', the operation cannot be performed manually since resource is under automation control.
        /// </summary>
        public const string CustomTrackoutMaterialManuallyUnitCompleteModeAutomation = "CustomTrackoutMaterialManuallyUnitCompleteModeAutomation";

        /// <summary>
        /// Exception message to be displayed when performing a TrackOut of Outsorted quantity with more quantity than the MO allows
        /// Message: Selected quantity surpasses the maximum quantity of outsorted allowed for the Material {0}
        /// </summary>
        public const string CustomTrackoutMaterialOutsortedQuantityExceeded = "CustomTrackoutMaterialOutsortedQuantityExceeded";

        /// <summary>
        /// Exception message to be displayed when performing a TrackOut of Outsorted quantity and parse of the quantity fails
        /// Message: It is not possible to validate outsorted quantity. Outsorted quantities from the line controller could not be parsed.
        /// </summary>
        public const string CustomCurrentKnownOutsortedQuantityParseError = "CustomCurrentKnownOutsortedQuantityParseError";

        /// <summary>
        /// Exception message to be displayed when performing a TrackOut of Outsorted quantity and automation controller instance not found
        /// Message: It is not possible to validate outsorted quantity. No Automation Controller Instance could be found, outsorted quantities from the line controller could not be obtained.
        /// </summary>
        public const string CustomCurrentKnownOutsortedQuantityAutomationControllerInstanceNotFound = "CustomCurrentKnownOutsortedQuantityAutomationControllerInstanceNotFound";

        /// <summary>
        /// Exception message to be displayed when clear interlock fails because there is no materials in process
        /// Message: Operation could not be completed. There are no Order Material in process in the Resource {0}.
        /// </summary>
        public const string CustomClearInterlockNoMaterialsMessage = "CustomClearInterlockNoMaterialsMessage";

        /// <summary>
        /// Exception message to be displayed when clear interlock fails because there are no consumables
        /// Message: Operation could not be completed. Please check consumables in the Resource {0}.
        /// </summary>
        public const string CustomClearInterlockNoConsumablesMessage = "CustomClearInterlockNoConsumablesMessage";

        /// <summary>
        /// Exception message to be displayed when clear interlock fails because it is missing a cheklist
        /// Message: Operation could not be completed. There is a CheckList that must be completed.
        /// </summary>
        public const string CustomClearInterlockMissingCheckListMessage = "CustomClearInterlockMissingCheckListMessage";

        /// <summary>
        /// Exception message to be displayed when clear interlock fails because there there are no durables
        /// Message: Operation could not be completed. Please check durables in the Resource {0}.
        /// </summary>
        public const string CustomClearInterlockNoDurablesMessage = "CustomClearInterlockNoDurablesMessage";

        /// <summary>
        /// Exception message to be displayed when trackout fails because there are undefined pieces to report
        /// Message: Trying to report pieces that were not consumed.
        /// </summary>
        public const string CustomAutomationFailedTrackoutUndefinedPieces = "CustomAutomationFailedTrackoutUndefinedPiecesMessage";

        /// <summary>
        /// Exception message to be displayed when there are undefined pieces in the explicit queue, during manual outsorting
        /// Message: There are {} undefined pieces in the explicit tracking queue of resource {0}. Please consume the necessary pieces and press the Reload Pending Trackouts button.
        /// </summary>
        public const string CustomManualOutsortingExplicitTrackingUndefinedPieces = "CustomManualOutsortingExplicitTrackingUndefinedPieces";

        /// <summary>
        /// Exception message to be displayed when there are no orders with the necessary conditions to be cleared, during clear interlock
        /// Message: There are no orders that meet the required conditions to try and clear the infeeder or outfeeder interlock
        /// </summary>
        public const string CustomClearInterlockNoOrdersMeetConditions = "CustomClearInterlockNoOrdersMeetConditions";

        /// <summary>
        /// Exception message to be displayed when material is tracked in at resource with main infeeder and with process segment but no BOM defined
        /// Message: No BOM context defined for this material.
        /// </summary>
        public const string CustomTrackInAutomationMaterialHasNoBomMessage = "CustomTrackInAutomationMaterialHasNoBom";

        /// <summary>
        /// Exception message displayed during track in if the Operator selected an alternative Sub-Resource for a BOM Product, but the tracked in material has no BOM setup.
        /// Message: Trying to set alternative resources, but no BOM is available for MO "{0}".
        /// </summary>
        public const string CustomTrackInAlternativeSubResourcesNoBomMessage = "CustomTrackInAlternativeSubResourcesNoBom";

        /// <summary>
        /// Exception message displayed during track in if the Operator selected an alternative Sub-Resource for a BOM Product that does not exist on the BOM
        /// Message: Trying to set alternative resource "{0}" for BOM Product Id {1}, but no such BOM Product is available in BOM "{2}" for MO "{3}".
        /// </summary>
        public const string CustomTrackInAlternativeSubResourcesNoBomProductMessage = "CustomTrackInAlternativeSubResourcesNoBomProduct";

        /// <summary>
        /// Exception message displayed during track in if the Operator selected an alternative Sub-Resource for a BOM Product that does have any resource originally associated.
        /// Message: Trying to set alternative resource "{0}" for BOM Product Id {1} of BOM "{2}" for MO "{3}", but there is no Original resource configured for that BOMProduct.
        /// </summary>
        public const string CustomTrackInAlternativeSubResourcesBomProductNoOriginalResourceMessage = "CustomTrackInAlternativeSubResourcesBomProductNoOriginalResource";

        /// <summary>
        /// Exception message displayed during track in if the Operator selected an alternative Sub-Resource for a BOM Product whose original resource does not have alternatives configured.
        /// Message: Trying to set alternative resource "{0}" for BOM Product Id {1} of BOM "{2}" for MO "{3}", but it's original resource "{4}" does not have any alternative resources configured in the Generic Table {5}.
        /// </summary>
        public const string CustomTrackInAlternativeSubResourcesBomProductAlternativesMessage = "CustomTrackInAlternativeSubResourcesBomProductAlternatives";

        /// <summary>
        /// Exception message displayed during track in if the Operator selected an alternative Sub-Resource for a BOM Product whose original resource does not have the requested alternative configured.
        /// Message: Trying to set alternative resource "{0}" for BOM Product Id {1} of BOM "{2}" for MO "{3}", but it's original resource "{4}" only has the following alternativesconfigured in Generic Table {5}: {6}.
        /// </summary>
        public const string CustomTrackInAlternativeSubResourcesBomProductNoAlternativesMatchMessage = "CustomTrackInAlternativeSubResourcesBomProductNoAlternativesMatch";

        /// <summary>
        /// Exception message displayed when resolving alternative sub resources for a material with an unexpected form.
        /// Message: Invalid material {0}: expected form {1}, got {2} instead.
        /// </summary>
        public const string CustomResolveAlternativeSubResourcesInvalidMaterialFormMessage = "CustomResolveAlternativeSubResourcesInvalidMaterialForm";

        /// <summary>
        /// Exception message displayed when resolving alternative sub resources for a material with an unexpected system state.
        /// Message: Invalid material {0}: expected system state {1}, got {2} instead.
        /// </summary>
        public const string CustomResolveAlternativeSubResourcesInvalidMaterialSystemStateMessage = "CustomResolveAlternativeSubResourcesInvalidMaterialSystemState";

        /// <summary>
        /// Exception message displayed when resolving alternative sub resources for a material with an unexpected system state.
        /// Message: Invalid material {0}: expected system state {1}, got {2} instead.
        /// </summary>
        public const string CustomAbortingNoAutomation = "CustomResolveAlternativeSubResourcesInvalidMaterialSystemState";

        /// <summary>
        /// Localized message containing error message to be displayed when there is not an available state transition defined in the state model
        /// Message: There are no available transitions in the {0} state model from state {1} to {2}.
        /// </summary>
        public const string CustomStateTransitionNoValidTransitionMessage = "CustomStateTransitionNoValidTransition";

        #endregion

        #region Tables

        #region SmartTables

        #region CustomCompletedMaterialForm Smart Table

        /// <summary>
        /// Name of the smart table from where the completed material form during palletization will be extracted from
        /// on a primary case (falls back to default config in case of failure)
        /// </summary>
        public const string CustomCompletedMaterialFormSmartTable = "CustomCompletedMaterialForm";

        /// <summary>
        /// Name of the column Facility in SmartTable {CustomCompletedMaterialFormSmartTable}
        /// </summary>
        public const string CustomCompletedMaterialFormSmartTableFacility = "Facility";

        /// <summary>
        /// Name of the column Area in SmartTable {CustomCompletedMaterialFormSmartTable}
        /// </summary>
        public const string CustomCompletedMaterialFormSmartTableArea = "Area";

        /// <summary>
        /// Name of the column Step in SmartTable {CustomCompletedMaterialFormSmartTable}
        /// </summary>
        public const string CustomCompletedMaterialFormSmartTableStep = "Step";

        /// <summary>
        /// Name of the column ProductGroup in SmartTable {CustomCompletedMaterialFormSmartTable}
        /// </summary>
        public const string CustomCompletedMaterialFormSmartTableProductGroup = "ProductGroup";

        /// <summary>
        /// Name of the column Product in SmartTable {CustomCompletedMaterialFormSmartTable}
        /// </summary>
        public const string CustomCompletedMaterialFormSmartTableProduct = "Product";

        /// <summary>
        /// Name of the column Form in SmartTable {CustomCompletedMaterialFormSmartTable}
        /// </summary>
        public const string CustomCompletedMaterialFormSmartTableForm = "Form";

        #endregion CustomCompletedMaterialForm Smart Table

        #endregion SmartTables

        #region GenericTables


        #region CustomMaterialFormAllowedTypes Generic Table

        /// <summary>
        /// Name of the generic table where it is defined the allowed material types per material form
        /// </summary>
        public const string CustomMaterialFormAllowedTypesGenericTable = "CustomMaterialFormAllowedTypes";

        /// <summary>
        /// Name of the column MaterialForm in GenericTable{CustomMaterialFormAllowedTypesGenericTable}
        /// </summary>
        public const string CustomMaterialFormAllowedTypesGenericTableMaterialForm = "MaterialForm";

        /// <summary>
        /// Name of the column MaterialType in GenericTable{IKEAMaterialFormAllowedTypesGenericTable}
        /// </summary>
        public const string CustomMaterialFormAllowedTypesGenericTableMaterialType = "MaterialType";

        #endregion CustomMaterialFormAllowedTypes Generic Table


        #region CustomMaterialTypeStepType Generic Table

        /// <summary>
        /// Name of the generic table where it is defined the step types based on material types
        /// </summary>
        public const string CustomMaterialTypeStepTypeGenericTable = "CustomMaterialTypeStepType";

        /// <summary>
        /// Name of the column MaterialType in GenericTable{CustomMaterialTypeStepTypeGenericTable}
        /// </summary>
        public const string CustomMaterialTypeStepTypeGenericTableMaterialType = "MaterialType";

        #endregion CustomMaterialTypeStepType Generic Table


        #endregion GenericTables

        #endregion Tables

    }
}
