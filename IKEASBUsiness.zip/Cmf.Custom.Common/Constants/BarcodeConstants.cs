﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Common
{
    /// <summary>
    /// This file contains constants related with the barcode scanning
    /// </summary>
    public partial class IKEAConstants
    {

        #region Generic

        public static string TokenNameKey = "TokenName";

        public static string StandardTokenKey = "ScanningConfigurationKey";

        public static string BarcodeKey = "StandardToken";

        #endregion

        #region Smart Tables and Generic Tables

        /// <summary>
        /// Smart table that resolves the configuration to be used in the barcode scanning
        /// </summary>
        public const string CustomScanningConfigurationSmartTable = "CustomScanningConfigurationResolution";

        /// <summary>
        /// Lookup table that resolves the configuration to be used in the barcode scanning
        /// </summary>
        public const string CustomScanningConfigurationsLookupTable = "CustomScanningConfigurations";

        /// <summary>
        /// Generic table that contains configuration to be used in the barcode scanning
        /// </summary>
        public const string CustomScanningConfigurationGenericTable = "CustomScanningConfiguration";

        /// <summary>
        /// Generic Table - CustomScanningConfigurationToken
        /// </summary>
        public const string CustomScanningConfigurationTokenGenericTable = "CustomScanningConfigurationToken";

        /// <summary>
        /// Smart Table - CustomScanningConfiguration - ScanningConfiguration
        /// </summary>
        public const string CustomScanningConfigurationScanningConfigurationColumn = "ScanningConfiguration";

        /// <summary>
        /// Generic Table - CustomScanningConfiguration - Format
        /// </summary>
        public const string CustomScanningConfigurationFormatColumn = "Format";

        /// <summary>
        /// Generic Table - CustomScanningConfiguration - Separator
        /// </summary>
        public const string CustomScanningConfigurationSeparatorColumn = "Separator";

        /// <summary>
        /// Generic Table - CustomScanningConfiguration - LeadFiller
        /// </summary>
        public const string CustomScanningConfigurationLeadFillerColumn = "LeadFiller";

        /// <summary>
        /// Generic Table - CustomScanningConfigurationToken - Position
        /// </summary>
        public const string CustomScanningConfigurationPositionColumn = "Position";

        /// <summary>
        /// Generic Table - CustomScanningConfigurationToken - Name
        /// </summary>
        public const string CustomScanningConfigurationNameColumn = "Name";

        /// <summary>
        /// Generic Table - CustomScanningConfigurationToken - StandardToken
        /// </summary>
        public const string CustomScanningConfigurationStandardTokenColumn = "StandardToken";

        /// <summary>
        /// Generic Table - CustomScanningConfigurationToken - Length
        /// </summary>
        public const string CustomScanningConfigurationLengthColumn = "Length";

        /// <summary>
        /// Generic Table - CustomScanningConfigurationToken - LeadFiller
        /// </summary>
        public const string CustomScanningConfigurationTokenLeadFillerColumn = "LeadFiller";

        /// <summary>
        /// Generic Table - CustomScanningConfigurationToken - ParserRule
        /// </summary>
        public const string CustomScanningConfigurationTokenParserRuleColumn = "ParserRule";

        #endregion

        #region Localized Messages

        /// <summary>
        /// There is no scanning configuration for the Resource {0}.\nPlease configure the following Tables before proceeding:\nGeneric Tables: CustomScanningConfiguration and CustomScanningConfigurationToken\nSmart Table: CustomScanningConfigurationResolution.
        /// </summary>
        public const string CustomBarcodeExceptionsNoScanningConfigurationFoundLocalizedMessage = "CustomBarcodeExceptionsNoScanningConfigurationFound";

        /// <summary>
        /// There is no scanning configuration tokens configured for the Resource {0}.\nPlease configure the Generic table CustomScanningConfigurationToken.
        /// </summary>
        public const string CustomBarcodeExceptionsNoScanningConfigurationTokenFoundLocalizedMessage = "CustomBarcodeExceptionsNoScanningConfigurationTokenFound";

        /// <summary>
        /// The scanning configuration {0} does not contain a Token for the position {1}.
        /// </summary>
        public const string CustomBarcodeExceptionsTokenWithPositionDoesNotExistLocalizedMessage = "CustomBarcodeExceptionsTokenWithPositionDoesNotExist";

        /// <summary>
        /// The received barcode does not contain the expected length configured in the tokens.
        /// </summary>
        public const string CustomBarcodeExceptionsWrongBarcodeLengthLocalizedMessage = "CustomBarcodeExceptionsWrongBarcodeLength";

        /// <summary>
        /// The char code set in the separator cannot be converted to a char.
        /// </summary>
        public const string CustomBarcodeExceptionsWrongSeparatorCharCodeLocalizedMessage = "CustomBarcodeExceptionsWrongSeparatorCharCode";

        /// <summary>
        /// Feature not available.
        /// </summary>
        public const string CustomBarcodeExceptionsFeatureNotAvailableLocalizedMessage = "CustomBarcodeExceptionsFeatureNotAvailable";

        /// <summary>
        ///  Material {0} was successfully attached to the Resource {1}.
        /// </summary>
        public const string CustomBarcodeSuccessMessageLocalizedMessage = "CustomBarcodeSuccessMessage";

        /// <summary>
        /// Material {0} was not found in MES. 
        /// </summary>
        public const string CustomBarcodeExceptionsMaterialNotFoundLocalizedMessage = "CustomBarcodeExceptionsMaterialNotFound";

        /// <summary>
        /// ScanningConfigurations for the Resource {0} does not contain the token Material configured.\nPlease check the Generic table CustomScanningConfigurationToken.
        /// </summary>
        public const string CustomBarcodeExceptionsMaterialTokenNotFoundLocalizedMessage = "CustomBarcodeExceptionsMaterialTokenNotFound";

        /// <summary>
        /// Resource: {0} was not found in MES. 
        /// </summary>
        public const string CustomBarcodeExceptionsResourceNotFoundLocalizedMessage= "CustomBarcodeExceptionsResourceNotFound";

        /// <summary>
        /// The Standard Tokens for the configuration {0} where not found in the barcode or are in the wrong Position.
        /// </summary>
        public const string CustomBarcodeExceptionsNoMatchingStandardTokenLocalizedMessage = "CustomBarcodeExceptionsNoMatchingStandardToken";

        /// <summary>
        /// The defined Scanning Configuration {0} is not a recognized Standard.
        /// </summary>
        public const string CustomBarcodeExceptionsNotRecognizedStandardLocalizedMessage = "CustomBarcodeExceptionsNotRecognizedStandard";

        /// <summary>
        /// The scanned batch material {0} does not exist.
        /// </summary>
        public const string CustomTrackoutMaterialAutomaticBatchMaterialDoesNotExistLocalizedMessage = "CustomTrackoutMaterialAutomaticBatchMaterialDoesNotExist";

        /// <summary>
        /// Batch material does not exist
        /// </summary>
        public const string CustomTrackoutMaterialAutomaticBatchMaterialDoesNotExistTitleLocalizedMessage = "CustomTrackoutMaterialAutomaticBatchMaterialDoesNotExistTitle";

        /// <summary>
        /// The Rule {0} could not extract information on Token {1}.
        /// </summary>
        public const string CustomBarcodeExceptionsUnableToParseTokenLocalizedMessage = "CustomBarcodeExceptionsUnableToParseToken";
       
        #endregion

        #region Barcode Standards

        /// <summary>
        /// Barcode Standard - GS1-128
        /// </summary>
        public const string BarcodeStandardGS1128 = "GS1-128";

        #endregion
    }
}
