﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Common
{
    public static partial class IKEAConstants
    {

        #region Attributes

        /// <summary>
        /// Attribute that indicates the Base Product of a Revision
        /// </summary>
        public const string CustomProductAttributeBaseProduct = "BaseProduct";

        /// <summary>
        /// Attribute that indicates if the changes to the revision are breaking changes
        /// </summary>
        public const string CustomProductAttributeIsBreakingChanges = "IsBreakingChanges";

        /// <summary>
        /// Attribute that indicates the Revision of the Product
        /// </summary>
        public const string CustomProductAttributeRevision = "CustomRevision";

        /// <summary>
        /// Attribute that indicates if the Product Revision was already processed
        /// </summary>
        public const string CustomProductAttributeRevisionProcessed = "RevisionProcessed";
        
        /// <summary>
        /// Attribute that indicates the Finished Width of a product
        /// </summary>
        public const string CustomProductAttributeFinishedWidth = "FinishedWidth";

        /// <summary>
        /// Attribute that indicates the Finished Length of a product
        /// </summary>
        public const string CustomProductAttributeFinishedLength = "FinishedLength";

        /// <summary>
        /// Attribute that indicates the Thickness of a product
        /// </summary>
        public const string CustomProductAttributeThickness = "Thickness";

        /// <summary>
        /// Attribute that indicates the total quantity to create a pallet
        /// </summary>
        public const string CustomPalletQuantity = "PalletQuantity";

        /// <summary>
        /// Attribute that indicates the total quantity to create a pallet
        /// </summary>
        public const string CustomTaktTime = "CustomTaktTime";

        /// <summary>
        /// Number of decimals places to be used when generating quantity GS1 AI tag
        /// </summary>
        public const string GS1DecimalPlaces = "GS1DecimalPlaces";

        /// <summary>
        /// Attribute that indicates if the product is generated from a group MO
        /// </summary>
        public const string CustomProductAttributeIsGroupMOProduct = "IsGroupMOProduct";

        /// <summary>
        /// Attribute that stores the ItemGroup that comes from PLM
        /// </summary>
        public const string CustomProductAttributeItemGroup = "M3ItemGroup";

        /// <summary>
        /// Attribute that stores the ProductGroup that comes from PLM
        /// </summary>
        public const string CustomProductAttributeProductGroup = "M3ProductGroup";

        /// <summary>
        /// Attribute that stores the ItemType that comes from PLM
        /// </summary>
        public const string CustomProductAttributeItemType = "M3ItemType";

        /// <summary>
        /// The number of decimal places when reporting quantities of this Product to the ERP
        /// </summary>
        public const string CustomProductAttributeDecimalPlaces = "M3DecimalPlaces";

        /// <summary>
        /// Attribute that indicates the width of the unit load for ULL printing
        /// </summary>
        public const string CustomUnitLoadFootPrintWidth = "UnitLoadFootPrintWidth";

        /// <summary>
        /// Attribute that indicates the depth of the unit load for ULL printing
        /// </summary>
        public const string CustomUnitLoadFootPrintDepth = "UnitLoadFootPrintDepth";

        /// <summary>
        /// Attribute that indicates The permissible Unit Load on storage and transport, in kilograms to be used on ULL Labels
        /// </summary>
        public const string CustomUnitLoadStackingCapacity = "UnitLoadStackingCapacity";

        /// <summary>
        /// Attribute that indicates the unit weight in kilograms to be used on ULL Labels
        /// </summary>
        public const string CustomUnitWeight = "UnitWeight";

        #endregion

        #region ChangeSets

        /// <summary>
        /// ChangeSetType lookup table
        /// </summary>
        public const string ChangeSetTypeLookupTable = "ChangeSetType";

        #endregion

        #region Config
        
        /// <summary>
        /// Product Revision Separator
        /// </summary>
        public const string CustomProductRevisionSeparator = "/Cmf/Custom/ProductRevision/ProductRevisionSeparator";

        /// <summary>
        /// Product Revision Separator
        /// </summary>
        public const string CustomEnforceLabelPrint = "/Cmf/Custom/Print/EnforceLabelPrint";

        /// <summary>
        /// Report Unit Complete
        /// </summary>
        public const string CustomReportUnitComplete = "/Cmf/Custom/ERP/ReportUnitComplete";

        /// <summary>
        /// ReworkCountTracking
        /// </summary>
        public const string CustomReworkCountTracking = "/Cmf/Custom/ReworkCountTracking/Enable";

        /// <summary>
        /// CustomReworkHoldReason
        /// </summary>
        public const string CustomReworkHoldReason = "/Cmf/Custom/ReworkCountTracking/HoldReason";

        /// <summary>
        /// CustomFinishGoodProductType
        /// </summary>
        public const string CustomFinishGoodProductType = "/Cmf/Custom/Product/DefaultFinishedGoodProductType";

        /// <summary>
        /// CustomSemiFinishGoodProductType
        /// </summary>
        public const string CustomSemiFinishGoodProductType = "/Cmf/Custom/Product/DefaultSemiFinishedGoodProductType";

        /// <summary>
        /// CustomConsumableProductType
        /// </summary>
        public const string CustomConsumableProductType = "/Cmf/Custom/Product/DefaultConsumableProductType";

        /// <summary>
        /// CustomCreateSubstitutesForConsumableProducts
        /// </summary>
        public const string CustomCreateSubstitutesForConsumableProducts = "/Cmf/Custom/ERP/CreateSubstitutesForConsumableProducts";

        #endregion

        #region Localized Messages

        /// <summary>
        /// Product Revision Separator is not configured.
        /// </summary>
        public const string CustomProductRevsionSeparatorNotSetLocalizedMessage = "CustomProductRevsionSeparatorNotSet";

        /// <summary>
        /// Product {0} doesn't contain the separator {1} in the name.
        /// </summary>
        public const string CustomProductNameDoesNotContainSeparatorLocalizedMessage = "CustomProductNameDoesNotContainSeparator";

        /// <summary>
        /// The name of the Product {0} doesn't contain the revision part after the separator.
        /// </summary>
        public const string CustomProductNameDoesNotContainRevisionLocalizedMessage = "CustomProductNameDoesNotContainRevision";

        /// <summary>
        /// The Product {0} doesn't exist in MES.
        /// </summary>
        public const string CustomExceptionProductNotFoundLocalizedMessage = "CustomExceptionProductNotFound";

        /// <summary>
        /// The Product {0} Type is not Durable.
        /// </summary>
        public const string CustomExceptionProductNotDurableLocalizedMessage = "CustomExceptionProductNotDurable";

        #endregion

        #region

        /// <summary>
        /// Xpath ProcessItemMaster
        /// </summary>
        public const string ProcessItemMaster = "//*[local-name()='ProcessItemMaster']";

        #endregion
    }
}
