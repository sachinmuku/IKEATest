﻿namespace Cmf.Custom.IKEA.Common
{
    public partial class IKEAConstants
    {

        #region DEE Actions

        /// <summary>
        /// DEE action - CustomSendMaintenanceManagementNotificationMail
        /// </summary>
        public const string CustomSendMaintenanceManagementNotificationMail = "CustomSendMaintenanceManagementNotificationMail";

        #endregion

        #region Localized Messages

        /// <summary>
        /// {0} {1} maintenance plan alert
        /// </summary>
        public const string MaoStatusMailSubjectLocalizedMessage = "MaoStatusMailSubject";

        /// <summary>
        /// At {0} the maintenance activity {1} for the {2} {3} has reached the {4} state.
        /// </summary>
        public const string MaoStatusMailTextLocalizedMessage = "MaoStatusMailText";

        /// <summary>
        /// Next state {0} will be reached at {1}
        /// </summary>
        public const string MaoStatusMailExtraTextTimeBasedLocalizedMessage = "MaoStatusMailExtraTextTimeBased";

        /// <summary>
        /// Next state {0} will be reached when counter reaches {1}.
        /// </summary>
        public const string MaoStatusMailExtraTextUsageBasedLocalizedMessage = "MaoStatusMailExtraTextUsageBased";

        /// <summary>
        /// A new maintenance activity of the type {0} was created for the Equipment {1} with the Due Date {2}.
        /// </summary>
        public const string CustomAdHocMaoCreatedLocalizedMessage = "CustomAdHocMaoCreated";

        /// <summary>
        /// Work Order Requested by TimeBased Maintenance
        /// </summary>
        public const string CustomTimeBasedWorkOrderRequestedDefaultComment = "CustomTimeBasedWorkOrderRequestedDefaultComment";

        /// <summary>
        /// Work Order Requested by UsageBased Maintenance
        /// </summary>
        public const string CustomUsageBasedWorkOrderRequestedDefaultComment = "CustomUsageBasedWorkOrderRequestedDefaultComment";

        /// <summary>
        /// The Maintenance Plan {0} does not contain a Maintenance Activity of the type {1}.
        /// </summary>
        public const string CustomERPMaintenanceIntegrationMATypeDoesNotExistLocalizedMessage = "CustomERPMaintenanceIntegrationMATypeDoesNotExist";

        /// <summary>
        /// There are no Maintenance Plans configured in the SmartTable CustomERPMaintenancePlansConfiguration for the resource {0}.
        /// </summary>
        public const string CustomERPMaintenanceIntegrationMaintenancePlanNotConfiguredLocalizedMessage = "CustomERPMaintenanceIntegrationMaintenancePlanNotConfigured";

        /// <summary>
        /// No Maintenance Role is configured, please check the configuration /Cmf/Custom/ERP/ERPMaintenanceRole.
        /// </summary>
        public const string CustomERPMaintenanceIntegrationMaintenanceRoleNotConfiguredLocalizedMessage = "CustomERPMaintenanceIntegrationMaintenanceRoleNotConfigured";

        /// <summary>
        /// It was not possible to find a valid MES activity state for the work order status '{0}', mapped in the generic table 'CustomERPStatusMapping'.
        /// </summary>
        public const string CustomERPMaintenanceMissingERPStatusMappingLocalizedMessage = "CustomERPMaintenanceMissingERPStatusMapping";

        /// <summary>
        /// The action {0} is not allowed to be used by ERP Integration.
        /// </summary>
        public const string CustomERPMaintenanceIntegrationNotAllowedActionsLocalizedMessage = "CustomERPMaintenanceIntegrationNotAllowedActions";
        
        /// <summary>
        /// No resource was found for the following equipment Ids: {0}.
        /// </summary>
        public const string CustomERPMaintenanceIntegrationNoResourceFoundLocalizedMessage = "CustomERPMaintenanceIntegrationNoResourceFound";

        /// <summary>
        /// There are no configurations for the Type {0} and SubType {1} coming from ERP. Please check the GenericTable CustomERPMaintenanceTypesMapping.
        /// </summary>
        public const string CustomERPMaintenanceIntegrationNoConfigurationForERPTypeLocalizedMessage = "CustomERPMaintenanceIntegrationNoConfigurationForERPType";
        
        /// <summary>
        /// Header:
        /// </summary>
        public const string CustomERPMaintenanceIntegrationCommentsHeaderLocalizedMessage = "CustomERPMaintenanceIntegrationCommentsHeader";

        /// <summary>
        /// Description: {0}
        /// </summary>
        public const string CustomERPMaintenanceIntegrationCommentsDescriptionLocalizedMessage = "CustomERPMaintenanceIntegrationCommentsDescription";

        /// <summary>
        /// Notes: {0}
        /// </summary>
        public const string CustomERPMaintenanceIntegrationCommentsNotesLocalizedMessage = "CustomERPMaintenanceIntegrationCommentsNotes";
        
        /// <summary>
        /// Operation:
        /// </summary>
        public const string CustomERPMaintenanceIntegrationCommentsOperationLocalizedMessage = "CustomERPMaintenanceIntegrationCommentsOperation";

        /// <summary>
        /// The following Maintenance Activity Orders cannot be completed due to missing actions:
        /// </summary>
        public const string CustomERPMaintenanceIntegrationCannotCompleteMissingActionLocalizedMessage = "CustomERPMaintenanceIntegrationCannotCompleteMissingAction";

        /// <summary>
        /// Maintenance Activity Orders with not performed Checklists: {0}
        /// </summary>
        public const string CustomERPMaintenanceIntegrationCannotCompleteActiveCheckListLocalizedMessage = "CustomERPMaintenanceIntegrationCannotCompleteActiveCheckList";

        /// <summary>
        /// Maintenance Activity Orders with not completed Data Collections: {0}
        /// </summary>
        public const string CustomERPMaintenanceIntegrationCannotCompleteActiveDataCollectionLocalizedMessage = "CustomERPMaintenanceIntegrationCannotCompleteActiveDataCollection";

        /// <summary>
        /// Maintenance Activity Orders cannot be completed due to missing actions
        /// </summary>
        public const string CustomERPMaintenanceIntegrationCannotCompleteTitleLocalizedMessage = "CustomERPMaintenanceIntegrationCannotCompleteTitle";

        #endregion

        #region Attributes

        /// <summary>
        /// Attribute that contains the MAO ERP WorkRequestId
        /// </summary>
        public const string CustomWorkRequestIdAttribute = "WorkRequestId";

        /// <summary>
        /// Attribute that contains the MAO ERP WorkOrderId
        /// </summary>
        public const string CustomWorkOrderIdAttribute = "WorkOrderId";

        /// <summary>
        /// Attribute that contains the MAO ERP ERPEquipmentId
        /// </summary>
        public const string CustomERPEquipmentIdAttribute = "ERPEquipmentId";

        /// <summary>
        /// Attribute that contains the MAO Operation Number
        /// </summary>
        public const string CustomWorkOrderOperationNumberAttribute = "OperationNumber";

        /// <summary
        /// Attribute that contains the MAO Begin owner
        /// </summary>
        public const string CustomMaoStartedByOperatorAttribute = "StartedByOperator";

        #endregion

        #region Generic Tables

        #region CustomERPMaintenanceTypesMapping

        /// <summary>
        ///  Smart Table CustomERPMaintenanceTypesMapping name
        /// </summary>
        public const string CustomERPMaintenanceTypesMappingGenericTable = "CustomERPMaintenanceTypesMapping";

        /// <summary>
        ///  Smart Table CustomERPMaintenanceTypesMapping ERPMainType column name
        /// </summary>
        public const string CustomERPMaintenanceTypesMappingERPMainTypeColumn = "ERPMainType";

        /// <summary>
        ///  Smart Table CustomERPMaintenanceTypesMapping ERPSubType column name
        /// </summary>
        public const string CustomERPMaintenanceTypesMappingERPSubTypeColumn = "ERPSubType";

        /// <summary>
        ///  Smart Table CustomERPMaintenanceTypesMapping MESType column name
        /// </summary>
        public const string CustomERPMaintenanceTypesMappingMESTypeColumn = "MESType";

        /// <summary>
        ///  Smart Table CustomERPMaintenanceTypesMapping ErrorCode1 column name
        /// </summary>
        public const string CustomERPMaintenanceTypesMappingErrorCode1Column = "ErrorCode1";

        /// <summary>
        ///  Smart Table CustomERPMaintenanceTypesMapping ErrorCode2 column name
        /// </summary>
        public const string CustomERPMaintenanceTypesMappingErrorCode2Column = "ErrorCode2";

        /// <summary>
        ///  Smart Table CustomERPMaintenanceTypesMapping ErrorCode3 column name
        /// </summary>
        public const string CustomERPMaintenanceTypesMappingErrorCode3Column = "ErrorCode3";

        #endregion

        #region CustomERPStatusMapping

        /// <summary>
        ///  Smart Table CustomERPStatusMapping name
        /// </summary>
        public const string CustomERPStatusMappingGenericTable = "CustomERPStatusMapping";

        /// <summary>
        ///  Smart Table CustomERPStatusMapping ERPStatus column name
        /// </summary>
        public const string CustomERPStatusMappingERPStatusColumn = "ERPStatus";

        /// <summary>
        ///  Smart Table CustomERPStatusMapping MESActivityState column name
        /// </summary>
        public const string CustomERPStatusMappingMESActivityStateColumn = "MESActivityState";
        #endregion

        #endregion

        #region Relations
        /// <summary>
        ///  MaintenanceActivityOrderEmployee relation name
        /// </summary>
        public const string MaintenanceActivityOrderEmployeeRelationName = "MaintenanceActivityOrderEmployee";

        #endregion

        #region Integration

        /// <summary>
        /// Xpath SyncServiceOrder
        /// </summary>
        public const string SyncServiceOrder = "//*[local-name()='SyncServiceOrder']";


        #endregion

        #region Generic
        /// <summary>
        /// To prevent to report back to the ERP when the MAO is changed by the ERP
        /// </summary>
        public const string CustomPreventReportingMaoChangesToERPOnFullUpdateObject = "PreventSendingMaoChangesToERPOnFullUpdateObject";
        /// <summary>
        /// To prevent to report the close of the MAO back to the ERP when the MO was already closed
        /// </summary>
        public const string CustomPreventReportingMaoCloseToERPOnCompleteMAO = "CustomPreventReportingMaoCloseToERPOnCompleteMAO";

        /// <summary>
        /// MAO comments when Schedule Type is Adhoc
        /// </summary>
        public const string CustomMaoAdhocComment = "AdhocComment";

		/// <summary>
		/// MAO notes
		/// </summary>
		public const string CustomMaoNotes = "Notes";

        /// <summary>
		/// Entity Type Name 'CustomERPMaintenanceHandleActivityProgress'
		/// </summary>
        public const string EntityTypeNameCustomERPMaintenanceHandleActivityProgress = "CustomERPMaintenanceHandleActivityProgress";
        #endregion
    }
}
