﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Common
{
    public static partial class IKEAConstants
    {

        #region General

        /// <summary>
        /// Unknow message type
        /// </summary>
        public const string Unknown = "Unknown";

        /// <summary>
        /// System ERP
        /// </summary>
        public const string ERPSystem = "ERP";

        /// <summary>
        /// System MES
        /// </summary>
        public const string MESSystem = "MES";

        /// <summary>
        /// CustomERPColumnsMapping
        /// </summary>
        public const string CustomERPColumnsMapping = "CustomERPColumnsMapping";

        /// <summary>
        /// CustomWorkCenterResourceMapping
        /// </summary>
        public const string CustomWorkCenterResourceMapping = "CustomWorkCenterResourceMapping";

        /// <summary>
        /// CustomERPMaintenanceTypesMapping
        /// </summary>
        public const string CustomERPMaintenanceTypesMapping = "CustomERPMaintenanceTypesMapping";

        /// <summary>
        /// CustomERPColumnsMapping - SourceEntity - ProductionOrder
        /// </summary>
        public const string CustomERPColumnsMappingProductionOrder = "ProductionOrder";

        /// <summary>
        /// CustomERPColumnsMapping - SourceEntity - Material
        /// </summary>
        public const string CustomERPColumnsMappingMaterial = "Material";

        /// <summary>
        /// CustomERPColumnsMapping - SourceColumn - Type
        /// </summary>
        public const string CustomERPColumnsMappingType = "Type";

        /// <summary>
        /// CustomERPColumnsMapping - SourceColumn - Priority
        /// </summary>
        public const string CustomERPColumnsMappingPriority = "Priority";

        /// <summary>
        /// Event Name
        /// </summary>
        public const string EventNameIONMessageReceived = "IONMessageReceived";

        /// <summary>
        /// ERP Workcenter Dispatch MessageType
        /// </summary>
        public const string ERPWorkCenterDispatchMessage = "ERPWorkCenterDispatch";

        /// <summary>
        /// ERP Workcenter Dispatch EventType
        /// </summary>
        public const string ERPWorkCenterDispatchEvent = "ERPDispatchMessageSent";

        /// <summary>
        /// Name of the Input parameter
        /// </summary>
        public const string IntegrationInput = "ERPInfo";

        /// <summary>
        /// Name of the IntegrationEntry 
        /// </summary>
        public const string IntegrationInputName = "ERPName";

        /// <summary>
        /// Xpath DisplayID
        /// </summary>
        public const string DisplayID = "//*[local-name()='SyncProductionOrder']/*[local-name()='DataArea']/*[local-name()='ProductionOrder']/*[local-name()='ProductionOrderHeader']/*[local-name()='DisplayID']";

        /// <summary>
        /// Xpath Description
        /// </summary>
        public const string PODescription = "//*[local-name()='SyncProductionOrder']/*[local-name()='DataArea']/*[local-name()='ProductionOrder']/*[local-name()='ProductionOrderHeader']/*[local-name()='Description']";

        /// <summary>
        /// Xpath POFacility
        /// </summary>
        public const string POFacility = "//*[local-name()='SyncProductionOrder']/*[local-name()='DataArea']/*[local-name()='ProductionOrder']/*[local-name()='ProductionOrderHeader']/*[local-name()='UserArea']/*[local-name()='Property']/*[local-name()='Facility']";

        /// <summary>
        /// Xpath Priority
        /// </summary>
        public const string Priority = "//*[local-name()='SyncProductionOrder']/*[local-name()='DataArea']/*[local-name()='ProductionOrder']/*[local-name()='ProductionOrderHeader']/*[local-name()='UserArea']/*[local-name()='Property']/*[local-name()='PRIO']";

        /// <summary>
        /// Xpath DueDate
        /// </summary>
        public const string DueDate = "//*[local-name()='SyncProductionOrder']/*[local-name()='DataArea']/*[local-name()='ProductionOrder']/*[local-name()='ProductionOrderHeader']/*[local-name()='UserArea']/*[local-name()='Property']/*[local-name()='DUED']";

        /// <summary>
        /// Xpath Resource
        /// </summary>
        public const string Resource = "//*[local-name()='SyncProductionOrder']/*[local-name()='DataArea']/*[local-name()='ProductionOrder']/*[local-name()='ProductionOrderDetail']/*[local-name()='BillOfResources']/*[local-name()='Operations']/*[local-name()='OutputItem']/*[local-name()='UserArea']/*[local-name()='Property']/*[local-name()='NameValue'][@name='PLGR']";

        /// <summary>
        /// Xpath Resource
        /// </summary>
        public const string AdhocResource = "//*[local-name()='SyncProductionOrder']/*[local-name()='DataArea']/*[local-name()='ProductionOrder']/*[local-name()='ProductionOrderDetail']/*[local-name()='BillOfResources']/*[local-name()='Operations']/*[local-name()='OutputItem']/*[local-name()='UserArea']/*[local-name()='Property']/*[local-name()='NameValue'][@name='WCLN']";

        /// <summary>
        /// Xpath WorkCenter
        /// </summary>
        public const string WorkCenterPath = "//*[local-name()='SyncProductionOrder']/*[local-name()='DataArea']/*[local-name()='ProductionOrder']/*[local-name()='ProductionOrderDetail']/*[local-name()='BillOfResources']/*[local-name()='Operations']/*[local-name()='OutputItem']/*[local-name()='UserArea']/*[local-name()='Property']/*[local-name()='NameValue'][@name='PLG1']";

        /// <summary>
        /// Xpath OrderBaseUOMQuantity
        /// </summary>
        public const string OrderBaseUOMQuantity = "//*[local-name()='SyncProductionOrder']/*[local-name()='DataArea']/*[local-name()='ProductionOrder']/*[local-name()='ProductionOrderHeader']/*[local-name()='OrderBaseUOMQuantity']";

        /// <summary>
        /// Xpath PlannedQuantity
        /// </summary>
        public const string PlannedQuantity = "//*[local-name()='SyncProductionOrder']/*[local-name()='DataArea']/*[local-name()='ProductionOrder']/*[local-name()='ProductionOrderDetail']/*[local-name()='BillOfResources']/*[local-name()='Operations']/*[local-name()='OutputItem']/*[local-name()='OrderBaseUOMQuantity']";

        /// <summary>
        /// Xpath StartDateTime
        /// </summary>
        public const string StartDateTime = "//*[local-name()='SyncProductionOrder']/*[local-name()='DataArea']/*[local-name()='ProductionOrder']/*[local-name()='ProductionOrderHeader']/*[local-name()='ForecastedTimePeriod']/*[local-name()='StartDateTime']";

        /// <summary>
        /// Xpath EndDateTime
        /// </summary>
        public const string EndDateTime = "//*[local-name()='SyncProductionOrder']/*[local-name()='DataArea']/*[local-name()='ProductionOrder']/*[local-name()='ProductionOrderHeader']/*[local-name()='ForecastedTimePeriod']/*[local-name()='EndDateTime']";

        /// <summary>
        /// Xpath ProductionOrderHeader
        /// </summary>
        public const string ProductionOrderHeader = "//*[local-name()='SyncProductionOrder']/*[local-name()='DataArea']/*[local-name()='ProductionOrder']/*[local-name()='ProductionOrderHeader']";

        /// <summary>
        /// Xpath Description
        /// </summary>
        public const string Description = "//*[local-name()='SyncProductionOrder']/*[local-name()='DataArea']/*[local-name()='ProductionOrder']/*[local-name()='ProductionOrderDetail']/*[local-name()='BillOfResources']/*[local-name()='Operations']/*[local-name()='Description']";

        /// <summary>
        /// Xpath DocumentID
        /// </summary>
        public const string DocumentID = "//*[local-name()='SyncProductionOrder']/*[local-name()='DataArea']/*[local-name()='ProductionOrder']/*[local-name()='ProductionOrderHeader']/*[local-name()='DocumentID']/*[local-name()='ID']";

        /// <summary>
        /// Xpath SyncProductionOrder
        /// </summary>
        public const string SyncProductionOrder = "//*[local-name()='SyncProductionOrder']";

        /// <summary>
        /// Xpath BillOfResources
        /// </summary>
        public const string BillOfResources = "//*[local-name()='SyncProductionOrder']/*[local-name()='DataArea']/*[local-name()='ProductionOrder']/*[local-name()='ProductionOrderDetail']/*[local-name()='BillOfResources']";

        /// <summary>
        /// Xpath For Operations
        /// </summary>
        public const string Operations = "//*[local-name()='SyncProductionOrder']/*[local-name()='DataArea']/*[local-name()='ProductionOrder']/*[local-name()='ProductionOrderDetail']/*[local-name()='BillOfResources']/*[local-name()='Operations']";

        /// <summary>
        /// Xpath For UserArea
        /// </summary>
        public const string UserArea = "//*[local-name()='SyncProductionOrder']/*[local-name()='DataArea']/*[local-name()='ProductionOrder']/*[local-name()='ProductionOrderHeader']/*[local-name()='UserArea']";

        /// <summary>
        /// Xpath For ReportingWarehouse
        /// </summary>
        public const string ReportingWarehouse = "//*[local-name()='SyncProductionOrder']/*[local-name()='DataArea']/*[local-name()='Sync']/*[local-name()='LocationID']";

        /// <summary>
        /// Xpath For Product
        /// </summary>
        public const string Product = "//*[local-name()='SyncProductionOrder']/*[local-name()='DataArea']/*[local-name()='ProductionOrder']/*[local-name()='ProductionOrderDetail']/*[local-name()='BillOfResources']/*[local-name()='Operations']/*[local-name()='OutputItem']/*[local-name()='ItemID']/*[local-name()='ID']";

        /// <summary>
        /// Xpath For Error Message node
        /// </summary>
        public const string ErrorMessage = "//*[local-name()='ErrorMessage']";

        /// <summary>
        /// Xpath For Error Message content
        /// </summary>
        public const string ErrorMessageContent = "//*[local-name()='ErrorMessage']/*[local-name()='Message']";

        /// <summary>
        /// Field Name for Operations Code
        /// </summary>
        public const string OperationCode = "ID";

        /// <summary>
        /// Field Name for ORTY Code
        /// </summary>
        public const string ORTYCode = "ORTY";

        /// <summary>
        /// Field Name for Facility Code
        /// </summary>
        public const string FacilityCode = "Facility";

        /// <summary>
        /// Field Name for PRIO Code
        /// </summary>
        public const string PRIOCode = "PRIO";
        
        /// <summary>
        /// Field Name for DUED Code
        /// </summary>
        public const string DUEDCode = "DUED";

        /// <summary>
        /// Field Name for CTCD Code
        /// </summary>
        public const string CTCD = "CTCD";

        /// <summary>
        /// Field Name for iPTUN Code
        /// </summary>
        public const string iPTUN = "iPTUN";

        /// <summary>
        /// Field Name for PITI Code
        /// </summary>
        public const string PITI = "PITI";

        /// <summary>
        /// Field Name for MSTI Code
        /// </summary>
        public const string MSTI = "MSTI";

        /// <summary>
        /// Field Name for STDT Code
        /// </summary>
        public const string STDT = "STDT";

        /// <summary>
        /// Field Name for FIDT Code
        /// </summary>
        public const string FIDT = "FIDT";
        
        /// <summary>
        /// Field Name for MFTI Code
        /// </summary>
        public const string MFTI = "MFTI";

        /// <summary>
        /// Field Name for ORQA Code
        /// </summary>
        public const string ORQA = "ORQA";

        /// <summary>
        /// Field Name for Resource
        /// </summary>
        public const string PLGR = "PLGR";

        /// <summary>
        /// DueDate Format
        /// </summary>
        public const string DueDateFormat = "yyyyMMdd";

        /// <summary>
        /// Field Name for WHST Code
        /// </summary>
        public const string WHSTCode = "WHST";

        /// <summary>
        /// Field Name for SCHN Code
        /// </summary>
        public const string SCHNCode = "SCHN";

        /// <summary>
        /// Field Name for TXT1 Code
        /// </summary>
        public const string TXT1Code = "TXT1";

        /// <summary>
        /// Field Name for TXT2 Code
        /// </summary>
        public const string TXT2Code = "TXT2";

        /// <summary>
        /// Field Name for TXT3 Code
        /// </summary>
        public const string TXT3Code = "TXT3";

        /// <summary>
        /// Field Name for STRT Code
        /// </summary>
        public const string STRTCode = "STRT";

        /// <summary>
        /// Field Name for WCLN
        /// </summary>
        public const string WCLN = "WCLN";

		/// <summary>
		/// Field Name for MAUN
		/// </summary>
		public const string MAUNCode = "MAUN";

        /// <summary>
        /// Field Name for Resource
        /// </summary>
        public const string OperationResource = "Description";

        /// <summary>
        /// Configuration path from where the maximum number of retries is extracted
        /// </summary>
        public const string MaxNumberOfRetriesPath = "/Cmf/System/Configuration/Integration/MaxNumberOfRetries";

        /// <summary>
        /// Configuration path from where the administration role is extracted
        /// </summary>
        public const string AdministrationRole = "/Cmf/System/Configuration/AdministrationRole";

        /// <summary>
        /// Configuration path from where the local support email is extracted
        /// </summary>
        public const string LocalSupport = "/Cmf/System/Configuration/Mail/LocalSupport";

        /// <summary>
        /// Configuration path for LineAssignmentCommunication
        /// </summary>
        public const string LineAssignmentCommunication = "/Cmf/Custom/ERP/LineAssignmentCommunication";

        /// <summary>
        /// Localized Message to be displayed when in a notification title - ERP error Handler
        /// </summary>
        public const string CustomNotificationTitleForERPErrorHandler = "CustomNotificationTitleForERPErrorHandler";

        /// <summary>
        /// Localized Message to be displayed when in a notification details - ERP error Handler
        /// </summary>
        public const string CustomNotificationDetailsForERPErrorHandler = "CustomNotificationDetailsForERPErrorHandler";

        /// <summary>
        /// Localized message to be displayed when message type doesn't existe - ERP integration
        /// </summary>
        public const string CustomERPUnknownMessageType = "CustomERPUnknownMessageType";

        /// <summary>
        /// Consumption Report - Event Name
        /// </summary>
        public const string ERPConsumptionReportEventName = "ERPConsumptionReport";

        /// <summary>
        /// Material movement - Event Name
        /// </summary>
        public const string ERPMaterialMovementEventName = "ERPReportMaterialMovement";

        /// <summary>
        /// Material movement - Message Type
        /// </summary>
        public const string ERPMaterialMovementMessageType = "ERPReportMaterialMovement";

        /// <summary>
        /// Consumption Report - Message Type
        /// </summary>
        public const string ERPConsumptionReportMessageType = "ERPReportConsumption";

        /// <summary>
        /// ERP Unit Complete - Message Type
        /// </summary>
        public const string ERPUnitCompleteMessageType = "ERPReportUnitComplete";

        /// <summary>
        /// ERP Left Over Unit Complete - Message Type
        /// </summary>
        public const string ERPLeftOverUnitCompleteMessageType = "ERPReportLeftOverUnitComplete";

        /// <summary>
        /// ERP Unit Complete Event Name
        /// </summary>
        public const string ERPPalletizationUnitCompleteEventName = "ERPPalletizationUnitComplete";

        /// <summary>
        /// ERP Production Order Complete Event Name
        /// </summary>
        public const string ERPProductionOrderCompleteEventName = "ERPProductionOrderComplete";

        /// <summary>
        /// ERP Left Overs Event Name
        /// </summary>
        public const string ERPPalletizationLeftOversEventName = "ERPPalletizationLeftOvers";

        /// <summary>
        /// Change Type Report - Event Name
        /// </summary>
        public const string ERPChangeTypeReportEventName = "ERPChangeTypeReport";

        /// <summary>
        /// Change Type Report - Message Type
        /// </summary>
        public const string ERPChangeTypeReportMessageType = "ERPReportQualityChange";

        /// <summary>
        /// Handle Maintenance Work Orders: Close Work Order - Event Name
        /// </summary>
        public const string ERPMaintenanceUpdateWorkOrderEventName = "ERPMaintenanceUpdateWorkOrder";

        /// <summary>
        /// Handle Maintenance Work Orders: Close Work Order - Event Name
        /// </summary>
        public const string ERPMaintenanceCloseWorkOrderEventName = "ERPMaintenanceCloseWorkOrder";

        /// <summary>
        /// ERP Default ManualCompletionFlag value
        /// </summary>
        public const string ERPDefaultManualCompletionFlag = "1";

        /// <summary>
        /// Handle Maintenance Work Orders - Message Type
        /// </summary>
        public const string ERPMaintenanceHandleWorkOrderMessageType = "ERPMaintenanceHandleWorkOrder";

        /// <summary>
        /// Defect Report - Event Name
        /// </summary>
        public const string ERPDefectReportEventName = "ERPDefectReport";

        /// <summary>
        /// Defect Report - Message Type
        /// </summary>
        public const string ERPDefectReportMessageType = "ERPReportPoorQuality";

        /// <summary>
        /// Material Split - Event Name
        /// </summary>
        public const string ERPReportMaterialSplitEventName = "ERPReportMaterialSplit";

        /// <summary>
        /// Material Merge - Event Name
        /// </summary>
        public const string ERPReportMaterialMergeEventName = "ERPReportMaterialMerge";

        /// <summary>
        /// Material Split - Message Type
        /// </summary>
        public const string ERPReportMaterialSplitMessageType = "ERPReportMaterialSplit";

        /// <summary>
        /// Material Merge - Message Type
        /// </summary>
        public const string ERPReportMaterialMergeMessageType = "ERPReportMaterialMerge";

        /// <summary>
        /// Material Scrap - Event Name
        /// </summary>
        public const string ERPReportMaterialScrapEventName = "ERPReportMaterialScrap";

        /// <summary>
        /// Order Closure - Event Name
        /// </summary>
        public const string ERPReportOrderClosureEventName = "ERPReportOrderClosure";

        /// <summary>
        /// Material Scrap - Message Type
        /// </summary>
        public const string ERPReportMaterialScrapMessageType = "ERPReportMaterialScrap";

        /// <summary>
        /// Order Closure - Message Type
        /// </summary>
        public const string ERPReportOrderClosureMessageType = "ERPReportOrderClosure";

        /// <summary>
        /// Material Replenishment - Message Type
        /// </summary>
        public const string ERPReportDistributionOrderMessageType = "ERPReportDistributionOrder";

        /// <summary>
        /// Material Replenishment - Event Name
        /// </summary>
        public const string ERPReportDistributionOrderEventName = "ERPReportDistributionOrder";

        /// <summary>
        /// Request Work Order - Message Type
        /// </summary>
        public const string ERPRequestWorkOrderMessageType = "ERPRequestWorkOrder";

        /// <summary>
        /// Request Work Order - Event Name
        /// </summary>
        public const string ERPRequestWorkOrderEventName = "ERPRequestWorkOrder";

        /// <summary>
        /// Request Production Order - Message Type
        /// </summary>
        public const string ERPRequestProductionOrderMessageType = "ERPRequestProductionOrder";

        /// <summary>
        /// Request Production Order - Event Name
        /// </summary>
        public const string ERPRequestProductionOrderEventName = "ERPRequestProductionOrder";




        /// <summary>
        /// Localized message to be displayed in notifications for when a Production Order cannot be update from ERP
        /// 
        ///     Production Order {0} could not be updated from ERP
        /// 
        /// </summary>
        public const string CustomERPOrderCannotBeChangedSubject = "CustomERPOrderCannotBeChangedSubject";

        /// <summary>
        /// Localized message to be displayed in notifications for when a Production Order cannot be update from ERP
        /// 
        ///     Production Order {0} could not be updated from ERP as it is in a state that allows changes.
        ///
        ///     ERP Integration Engine Message Name: {1}
        ///     Current Production Order State: {2}
        /// 
        /// </summary>
        public const string CustomERPOrderCannotBeChangedMessage = "CustomERPOrderCannotBeChangedMessage";


        /// <summary>
        /// ERP - BOMProduct Identifier
        /// </summary>
        public const string ERP_MSEQ = "MSEQ";

        /// <summary>
        /// ERP - BOMProduct: Product Name
        /// </summary>
        public const string ERP_MTNO = "MTNO";

        /// <summary>
        /// ERP - Identifies a resource
        /// </summary>
        public const string ERP_ACTS = "ACTS"; 

        /// <summary>
        /// ERP - BOMProduct: Product quantity
        /// </summary>
        public const string ERP_CNQT = "CNQT";

        /// <summary>
        /// ERP - BOMProduct: Product units
        /// </summary>
        public const string ERP_PEUN = "PEUN";

        /// <summary>
        /// ERP - BOMProduct: consumption should be or not reported
        /// </summary>
        public const string ERP_SPMT = "SPMT";

        /// <summary>
        /// ERP - Identifies a subresource
        /// </summary>
        public const string ERP_FMT2 = "FMT2";

        /// <summary>
        /// ERP - Identifies if the BOM Product is a by-product
        /// If true send the left overs to ERP
        /// </summary>
        public const string ERP_BYPR = "BYPR";

        /// <summary>
        /// Custom ERP Operation Tracking EntityType - Relation
        /// </summary>
        public const string CustomERPOperationTracking = "CustomERPOperationTracking";

        /// <summary>
        /// Order Operation - Event Name
        /// </summary>
        public const string ERPConsumptionOrderOperationEventName = "ERPReportOrderOperation";

        /// <summary>
        /// Order Operation - Message Type
        /// </summary>
        public const string ERPConsumptionOrderOperationMessageType = "ERPReportOrderOperation";

        #endregion

        #region Localized Messages
        /// <summary>
        /// The IonMessage property is mandatory
        /// </summary>
        public const string CustomIkeaIonMessageEmptyLocalizedMessage = "CustomIkeaIonMessageEmpty";

        /// <summary>
        /// Unable to obtain a access token
        /// </summary>
        public const string CustomERPUnableToObtainTokenLocalizedMessage = "CustomERPUnableToObtainToken";

        /// <summary>
        /// No Base Endpoint was configured
        /// </summary>
        public const string CustomERPMissingBaseEndpointLocalizedMessage = "CustomERPMissingBaseEndpoint";

        /// <summary>
        /// Exception returned by ERP: {0}
        /// </summary>
        public const string CustomERPExceptionLocalizedMessage = "CustomERPException";

        /// <summary>
        /// Some of the ERP configurations are missing
        /// </summary>
        public const string CustomERPMissingConfigurationsLocalizedMessage = "CustomERPMissingConfigurations";

        /// <summary>
        /// Process Segments could not be found in ERP message, please set the configuration {0} to True so BOM template is used.
        /// </summary>
        public const string CustomERPProcessSegmentNotDefinedLocalizedMessage = "CustomERPProcessSegmentNotDefined";

        /// <summary>
        /// The BOM Product field '{0}' is required and was not found in the BOM Sequence {1}.
        /// </summary>
        public const string CustomERPOrderMissingFieldErrorLocalizedMessage = "CustomERPOrderMissingFieldError";

        /// <summary>
        /// The Ion Message received could not be loaded. Verify if configuration /Cmf/Custom/ERP/EscapeCharacters/ value is set to false
        /// </summary>
        public const string CustomIonMessageErrorAndEscapeCharacterConfigValueSetToFalseLocalizedMessage = "CustomIonMessageErrorAndEscapeCharacterConfigValueSetToFalse";

        /// <summary>
        /// The Ion Message received could not be loaded.
        /// </summary>
        public const string CustomIonMessageCouldNotBeLoadedLocalizedMessage = "CustomIonMessageCouldNotBeLoaded";


        #endregion

        #region Configurations

        /// <summary>
        /// Indicates if reports the Material Change Type to ERP
        /// </summary>
        public const string ChangeTypeCommunication = "/Cmf/Custom/ERP/ChangeTypeCommunication";

        /// <summary>
        /// Indicates if reports the Material Consumption to ERP
        /// </summary>
        public const string MaterialConsumptionCommunication = "/Cmf/Custom/ERP/MaterialConsumptionCommunication";

        /// <summary>
        /// Indicates if reports the Material Defect to ERP
        /// </summary>
        public const string MaterialDefectCommunication = "/Cmf/Custom/ERP/MaterialDefectCommunication";

        /// <summary>
        /// Default configuration to Indicates when report operation to ERP
        /// </summary>
        public const string DefaultERPReportOperationAt = "/Cmf/Custom/ERP/DefaultERPReportOperationAt";

        /// <summary>
        /// Default configuration to Indicates when report Palletization to ERP
        /// </summary>
        public const string DefaultERPReportPalletizationAt = "/Cmf/Custom/ERP/DefaultERPReportPalletizationAt";

        /// <summary>
        /// Path to role to be notified on Order Handling events
        /// </summary>
        public const string OrderHandlingNotificationRole = "/Cmf/Custom/ERP/OrderHandlingNotificationRole";

        /// <summary>
        /// API default SCRAP Location
        /// </summary>
        public const string DefaultScrapERPLocationConfig = "/Cmf/Custom/ScrapManagement/DefaultScrapERPLocation";

        /// <summary>
        /// M3 - Username
        /// </summary>
        public const string ERPM3Username = "/Cmf/Custom/ERP/M3/Username";

        /// <summary>
        /// M3 - Password
        /// </summary>
        public const string ERPM3Password = "/Cmf/Custom/ERP/M3/Password";

        /// <summary>
        /// M3 - Client Id
        /// </summary>
        public const string ERPM3ClientId = "/Cmf/Custom/ERP/M3/ClientId";

        /// <summary>
        /// M3 - Client Secret
        /// </summary>
        public const string ERPM3ClientSecret = "/Cmf/Custom/ERP/M3/ClientSecret";

        /// <summary>
        /// M3 - Token Endpoint
        /// </summary>
        public const string ERPM3TokenEndpoint = "/Cmf/Custom/ERP/M3/TokenEndpoint";

        /// <summary>
        /// M3 - Base Endpoint
        /// </summary>
        public const string ERPM3BaseEndpoint = "/Cmf/Custom/ERP/M3/BaseEndpoint";

        /// <summary>
        /// M3 - Endpoint base path
        /// </summary>
        public const string ERPM3Endpoint = "/Cmf/Custom/ERP/M3/Endpoint/";

        /// <summary>
        /// M3 - Company Code config
        /// </summary>
        public const string CompanyCodeConfig = "/Cmf/Custom/ERP/M3/CompanyCode";

        /// <summary>
        /// M3 - Supplier Code config
        /// </summary>
        public const string SupplierCodeConfig = "/Cmf/Custom/ERP/M3/SupplierCode";

        /// <summary>
        /// M3 - Message Type Code Config
        /// </summary>
        public const string MessageTypeCodeConfig = "/Cmf/Custom/ERP/M3/MessageTypeCode";

        /// <summary>
        /// M3 - ERP Report Quality Change Endpoint Config
        /// </summary>
        public const string ErpReportQualityChangeEndpointConfig = "/Cmf/Custom/ERP/M3/Endpoint/ERPReportQualityChange";

        /// <summary>
        /// M3 - ERP Maintenance Employee number to which all effert should be declared
        /// </summary>
        public const string ERPWorkOrderEmployeeNumber = "/Cmf/Custom/ERP/WorkOrderEmployeeNumber";
        
        /// <summary>
        /// M3 - ERP Maintenance Role
        /// </summary>
        public const string ERPMaintenanceRoleConfig = "/Cmf/Custom/ERP/ERPMaintenanceRole";

        /// <summary>
        /// M3 - Responsible config
        /// </summary>
        public const string ErpResponsibleConfig = "/Cmf/Custom/ERP/M3/Responsible";

        /// <summary>
        /// M3 - OrderType config
        /// </summary>
        public const string ERPOrderTypeConfig = "/Cmf/Custom/ERP/M3/OrderType";

        /// <summary>
        /// M3 - Request new Production Order OrderType config
        /// </summary>
        public const string ERPRequestOrderTypeConfig = "/Cmf/Custom/ERP/M3/RequestOrderType";

        /// <summary>
        /// M3 - Request new Production Order StructureType config
        /// </summary>
        public const string ERPRequestOrderProductStructureTypeConfig = "/Cmf/Custom/ERP/M3/RequestOrderProductStructureType";

        /// <summary>
        /// M3 - Request new Production Order Status config
        /// </summary>
        public const string ERPRequestOrderStatusConfig = "/Cmf/Custom/ERP/M3/RequestOrderStatus";

        /// <summary>
        /// M3 - RejectionReason
        /// </summary>
        public const string ERPM3RejectionReason = "/Cmf/Custom/ERP/M3/RejectionReason";

        /// <summary>
        /// ERPReportOrderless
        /// </summary>
        public const string ERPReportOrderlessConfig = "/Cmf/Custom/ERP/ERPReportOrderless";

        /// <summary>
        /// ERPOrderlessPOType
        /// </summary>
        public const string ERPOrderlessPOTypeConfig = "/Cmf/Custom/ERP/ERPOrderlessPOType";

        /// <summary>
        /// StartTimeTakenAsCurrentTimeInWMSOrderRequestEnable
        /// </summary>
        public const string StartTimeTakenAsCurrentTimeInWMSOrderRequestEnable = "/Cmf/Custom/WMS/StartTimeTakenAsCurrentTimeInWMSOrderRequestEnable";

        /// <summary>
        /// M3 - UnitComplete Endpoint
        /// </summary>
        public const string ERPM3EndpointUnitComplete = "ERPReportUnitComplete";

        /// <summary>
        /// M3 - LeftOver Endpoint
        /// </summary>
        public const string ERPM3EndpointERPLeftOverUnitComplete = "ERPReportLeftOverUnitComplete";

        /// <summary>
        /// M3 - UnitComplete Endpoint
        /// </summary>
        public const string ERPM3EndpointOrderlessUnitComplete = "ERPReportOrderlessUnitComplete";

        /// <summary>
        /// ERPReportConsumption Endpoint
        /// </summary>
        public const string ERPReportConsumption = "ERPReportConsumption";

        /// <summary>
        /// ERPReportDetach Endpoint
        /// </summary>
        public const string ERPReportDetach = "ERPReportDetach";

        /// <summary>
        /// ERPReportOrderOperation Endpoint
        /// </summary>
        public const string ERPReportOrderOperation = "ERPReportOrderOperation";

        /// <summary>
        /// ERPReportMaterialMovement Endpoint
        /// </summary>
        public const string ERPReportMaterialMovement = "ERPReportMaterialMovement";

        /// <summary>
        /// ERPReportQualityChange Endpoint
        /// </summary>
        public const string ERPReportQualityChange = "ERPReportQualityChange";

        /// <summary>
        /// ERPReportMaterialSplit Endpoint
        /// </summary>
        public const string ERPReportMaterialSplit = "ERPReportMaterialSplit";

        /// <summary>
        /// ERPReportMaterialMerge Endpoint
        /// </summary>
        public const string ERPReportMaterialMerge = "ERPReportMaterialMerge";

        /// <summary>
        /// ERPReportMaterialScrap Endpoint
        /// </summary>
        public const string ERPReportMaterialScrap = "ERPReportMaterialScrap";

        /// <summary>
        /// ERPReportOrderClosure Endpoint
        /// </summary>
        public const string ERPReportOrderClosure = "ERPReportOrderClosure";

        /// <summary>
        /// ERPReportMaterialScrap Endpoint
        /// </summary>
        public const string ERPReportDistributionOrder = "ERPReportDistributionOrder";

        /// <summary>
        /// ERPRequestWorkOrder Endpoint
        /// </summary>
        public const string ERPMaintenanceRequestWorkOrder = "ERPMaintenanceRequestWorkOrder";
        
        /// ERPMaintenanceUpdateWorkOrder Endpoint
        /// </summary>
        public const string ERPMaintenanceUpdateWorkOrder = "ERPMaintenanceUpdateWorkOrder";

        /// <summary>
        /// ERPMaintenanceCloseWorkOrder Endpoint
        /// </summary>
        public const string ERPMaintenanceCloseWorkOrder = "ERPMaintenanceCloseWorkOrder";

        /// <summary>
        /// ERPRequestProductionOrder Endpoint
        /// </summary>
        public const string ERPRequestProductionOrder = "ERPRequestProductionOrder";

        /// <summary>
        /// ERPDefaultEmptyProcessSegment 
        /// </summary>
        public const string ERPDefaultEmptyProcessSegment = "000";

        /// <summary>
        /// MaterialScrapCommunication ProcessFlag Field Configuration Path
        /// </summary>
        public const string MaterialScrapCommunicationProcessFlag = "/Cmf/Custom/ERP/M3/MaterialScrapCommunication/FieldValues/ProcessFlag";

        /// <summary>
        /// MaterialScrapCommunication OrderType Field Configuration Path
        /// </summary>
        public const string MaterialScrapCommunicationOrderType = "/Cmf/Custom/ERP/M3/MaterialScrapCommunication/FieldValues/OrderType";

        /// <summary>
        /// ChangeQualityTypeCommunication ProcessFlag Field Configuration Path
        /// </summary>
        public const string ChangeQualityTypeCommunicationProcessFlag = "/Cmf/Custom/ERP/M3/ChangeQualityTypeCommunication/FieldValues/ProcessFlag";

        /// <summary>
        /// DistributionOrderCommunication ProcessFlag Field Configuration Path
        /// </summary>
        public const string DistributionOrderCommunicationProcessFlag = "/Cmf/Custom/ERP/M3/DistributionOrderCommunication/FieldValues/ProcessFlag";

        /// <summary>
        /// DistributionOrderCommunication UTCMode Field Configuration Path
        /// </summary>
        public const string DistributionOrderCommunicationUTCMode = "/Cmf/Custom/ERP/M3/DistributionOrderCommunication/FieldValues/UTCMode";   

        /// <summary>
        /// MaterialSplitCommunication ProcessFlag Field Configuration Path
        /// </summary>
        public const string MaterialSplitCommunicationProcessFlag = "/Cmf/Custom/ERP/M3/MaterialSplitCommunication/FieldValues/ProcessFlag";

        /// <summary>
        /// MaterialMergeCommunication ProcessFlag Field Configuration Path
        /// </summary>
        public const string MaterialMergeCommunicationProcessFlag = "/Cmf/Custom/ERP/M3/MaterialMergeCommunication/FieldValues/ProcessFlag";

        /// <summary>
        /// MaterialSplitCommunication Integration Retries Configuration Path
        /// </summary>
        public const string MaterialSplitCommunicationIntegrationEntryRetries = "/Cmf/Custom/ERP/M3/MaterialSplitCommunication/MaterialSplitCommunicationIntegrationEntryRetries";

        /// <summary>
        /// MaterialMergeCommunication Integration Retries Configuration Path
        /// </summary>
        public const string MaterialMergeCommunicationIntegrationEntryRetries = "/Cmf/Custom/ERP/M3/MaterialMergeCommunication/MaterialMergeCommunicationIntegrationEntryRetries";

        /// <summary>
        /// ERP - The ERP Language Configuration Path
        /// </summary>
        public const string LanguageERP = "/Cmf/System/Configuration/ERP/SAP/Language/";


        /// <summary>
        /// Config to verify if IonMessage characters can/need to be escaped
        /// </summary>
        public const string IonMessageEscapeCharactersInXMLConfig = "/Cmf/Custom/ERP/IonMessageEscapeCharactersInXML/";

        #endregion

        #region Tables

        /// <summary>
        /// Lookup table with the material types that are allowed to be reported to the ERP upon pallet creation
        /// </summary>
        public const string CustomERPReportableTypes = "CustomERPReportableTypes";

        /// <summary>
        /// smart table for the mapping between ordertype and structure type
        /// </summary>
        public const string CustomERPOrderTypeStructureTypeMapping = "CustomERPOrderTypeStructureTypeMapping";

        /// <summary>
        /// Product Column name for smart table for the mapping between ordertype and structure type
        /// </summary>
        public const string CustomERPOrderTypeStructureTypeMappingProductColumn = "Product";

        /// <summary>
        /// Resource Column name for smart table for the mapping between ordertype and structure type
        /// </summary>
        public const string CustomERPOrderTypeStructureTypeMappingResourceColumn = "Resource";

        /// <summary>
        /// StructureType column name for smart table for the mapping between ordertype and structure type
        /// </summary>
        public const string CustomERPOrderTypeStructureTypeMappingStructureTypeColumn = "StructureType";

        /// <summary>
        /// OrderType column name for smart table for the mapping between ordertype and structure type
        /// </summary>
        public const string CustomERPOrderTypeStructureTypeMappingOrderTypeColumn = "OrderType";

        #region CustomERPMaintenancePlansConfiguration

        /// <summary>
        /// Smart Table CustomERPMaintenancePlansConfiguration name
        /// </summary>
        public const string CustomERPMaintenancePlansConfigurationSmartTable = "CustomERPMaintenancePlansConfiguration";

        /// <summary>
        /// Smart Table CustomERPMaintenancePlansConfiguration Facility column name
        /// </summary>
        public const string CustomERPMaintenancePlansConfigurationFacilityColumn = "Facility";

        /// <summary>
        /// Smart Table CustomERPMaintenancePlansConfiguration Area column name
        /// </summary>
        public const string CustomERPMaintenancePlansConfigurationAreaColumn = "Area";

        /// <summary>
        /// Smart Table CustomERPMaintenancePlansConfiguration ResourceType column name
        /// </summary>
        public const string CustomERPMaintenancePlansConfigurationResourceTypeColumn = "ResourceType";

        /// <summary>
        /// Smart Table CustomERPMaintenancePlansConfiguration Resource column name
        /// </summary>
        public const string CustomERPMaintenancePlansConfigurationResourceColumn = "Resource";

        /// <summary>
        /// Smart Table CustomERPMaintenancePlansConfiguration MaintenancePlan column name
        /// </summary>
        public const string CustomERPMaintenancePlansConfigurationMaintenancePlanColumn = "MaintenancePlan";

		#endregion

		#endregion

		#region Integration Entry Attributes

		/// <summary>
		/// The name of the Ad-Hoc PO that MES requested to ERP
		/// </summary>
		public const string IntegrationEntryAttributeERPRequestPOName = "ERPRequestPOName";

		/// <summary>
		/// The name of the Resource requesting the Ad-Hoc PO
		/// </summary>
		public const string IntegrationEntryAttributeERPRequestResourceName = "ERPRequestResourceName";

		#endregion
	}
}
