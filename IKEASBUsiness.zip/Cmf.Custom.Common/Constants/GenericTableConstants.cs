﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cmf.Custom.IKEA.Common
{
    /// <summary>
    /// To hold all the related constants for WMS integration
    /// </summary>
    public partial class IKEAConstants
    {

        #region Configurations

        #endregion

        #region General

        #endregion

        #region Localized Messages
        /// <summary>
        /// A logical chart or a chart or a parameter has to be specified
        /// </summary>
        public const string CustomGenericTableMissingValueLocalizedMessage = "CustomGenericTableMissingValue";

        /// <summary>
        /// {0} causes conflicts with the existing configuration {1}.
        /// </summary>
        public const string CustomGenericTableAlreadyExistingConfigurationLocalizedMessage = "CustomGenericTableAlreadyExistingConfiguration";

        /// <summary>
        /// Mixing Length dimension and Weight is not allowed.
        /// </summary>
        public const string CustomGenericTableMixingUnitsNotAllowedLocalizedMessage = "CustomGenericTableMixingUnitsNotAllowed";



        #endregion

        #region Attributes

        #endregion

        #region Generic Table

        #endregion

        #region CustomUnitDimensions

        /// <summary>
        /// Generic Table -  CustomUnitDimensions
        /// </summary>
        public const string CustomUnitDimensions = "CustomUnitDimensions";

        /// <summary>
        /// Generic Table -  CustomUnitDimensions - Unit Column
        /// </summary>
        public const string CustomUnitDimensionsUnitColumn = "Unit";

        /// <summary>
        /// Generic Table -  CustomUnitDimensions - Length Column
        /// </summary>
        public const string CustomUnitDimensionsLengthColumn = "Length";

        /// <summary>
        /// Generic Table -  CustomUnitDimensions - Width Column
        /// </summary>
        public const string CustomUnitDimensionsWidthColumn = "Width";

        /// <summary>
        /// Generic Table -  CustomUnitDimensions - Thickness Column
        /// </summary>
        public const string CustomUnitDimensionsThicknessColumn = "Thickness";

        /// <summary>
        /// Generic Table -  CustomUnitDimensions - Weight Column
        /// </summary>
        public const string CustomUnitDimensionsWeightColumn = "Weight";

        #endregion

    }
}
