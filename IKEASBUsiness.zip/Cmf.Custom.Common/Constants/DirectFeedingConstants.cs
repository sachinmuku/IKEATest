﻿namespace Cmf.Custom.IKEA.Common
{
    public static partial class IKEAConstants
    {

        #region Config

        /// <summary>
        /// Enable Direct Feeding
        /// </summary>
        public const string EnableDirectFeedingConfig = "/Cmf/Custom/DirectFeeding/EnableDirectFeeding";

        #endregion

        #region General

        /// <summary>
        /// DirectFeedingCounterpartFinished IoT request type
        /// </summary>
        public const string DirectFeedingCounterpartFinished = "DirectFeedingCounterpartFinished";

        /// <summary>
        /// CustomDirectFeedingResolveMOModeAtTrackInContextKey for DEE to store resource
        /// </summary>
        public const string CustomDirectFeedingResolveMOModeAtTrackInResourceContextKey = "CustomDirectFeedingResolveMOModeAtTrackInResourceContextKey";

        /// <summary>
        /// CustomDirectFeedingResolveMOModeAtTrackInMaterialsContextKey for DEE to store material list
        /// </summary>
        public const string CustomDirectFeedingResolveMOModeAtTrackInMaterialsContextKey = "CustomDirectFeedingResolveMOModeAtTrackInMaterialsContextKey";

        /// <summary>
        /// CustomDirectFeedingResolveMOModeAtTrackInMaterialsContextKey for DEE to store feedingMode
        /// </summary>
        public const string CustomDirectFeedingResolveMOModeAtTrackInFeedingModeContextKey = "CustomDirectFeedingResolveMOModeAtTrackInFeedingModeContextKey";

        /// <summary>
        /// CustomDirectFeedingValidateModeOnAttachResourceContextKey for DEE to store resource
        /// </summary>
        public const string CustomDirectFeedingValidateModeOnAttachResourceContextKey = "CustomDirectFeedingValidateModeOnAttachResourceContextKey";

        #endregion

        #region Localized Messages

        /// <summary>
        /// Exception message displayed during order download when the order has DirectFeedingMode disabled, but the Resource DirectFeedingEnabled is ON.
        /// Message: Cannot download order. DirectFeeding is enabled on the resource, but the order is not set to directFeeding.
        /// </summary>
        public const string CustomDirectFeedingDownloadFailNoOrderModeMessage = "CustomDirectFeedingDownloadFailNoOrderModeMessage";

        /// <summary>
        /// Exception message displayed during order download when the order has DirectFeedingMode enabled, but the Resource DirectFeedingEnabled is OFF.
        /// Message: Cannot download order. DirectFeeding is disabled on the resource, but the order is set to directFeeding.
        /// </summary>
        public const string CustomDirectFeedingDownloadFailDirectFeedingDisabledMessage = "CustomDirectFeedingDownloadFailDirectFeedingDisabledMessage";

        /// <summary>
        /// Exception message displayed when the DirectFeedingMode of the MO that is being tracked-in is not equal to its counter part.
        /// Message: Cannot track-in MO {0}: The DirectFeedingMode of MO {0} and its counter part {1} are not equal.
        /// </summary>
        public const string CustomTrackInMOAndCounterPartDirectFeedingModesAreNotEqualMessage = "CustomTrackInMOAndCounterPartDirectFeedingModesAreNotEqualMessage";

        /// <summary>
        /// Exception message displayed when the resources' attributes are not setup correctly for direct feeding.
        /// Message: The resource {0} is not correctly setup for Direct Feeding. Attributes aren't correctly defined.
        /// </summary>
        public const string CustomTrackInResourceAttributesNotSetupCorrectlyMessage = "CustomTrackInResourceAttributesNotSetupCorrectlyMessage";

        /// <summary>
        /// Exception message displayed when the Default Completed Quantity of the MO on the second line is not equal to one in the first line.
        /// Message: Cannot track-in MO {0}: The Default Completed Quantity of counter part MO {1} is not equal to the current MO {0}.
        /// </summary>
        public const string CustomTrackInMOFirstLineDefaultCompletedQuantityIsNotEqualOrHigherMessage = "CustomTrackInMOFirstLineDefaultCompletedQuantityIsNotEqualOrHigherMessage";

        /// <summary>
        /// Exception message displayed when the Default Completed Quantity of the MO on the first line is not higher or equal to the one in the second line.
        /// Message: Cannot track-in MO {0}: The Quantity of counter part MO {1} is lower than the current MO {0}.
        /// </summary>
        public const string CustomTrackInMOSecondLineQuantityIsNotEqualOrHigherMessage = "CustomTrackInMOSecondLineQuantityIsNotEqualOrHigherMessage";

        /// <summary>
        /// Exception message displayed when the first line is not setup.
        /// Message: Cannot track-in MO {0}: The first line {1} is not setup.
        /// </summary>
        public const string CustomTrackInMOFirstLineNotSetUp = "CustomTrackInMOFirstLineNotSetUp";

        /// <summary>
        /// Exception message displayed when the attribute DirectFeedingSendRequestTo of the second line is not defined.
        /// Message: Cannot track-in MO {0}: Missing configuration of DirectFeedingSendRequestTo attribute.
        /// </summary>
        public const string CustomTrackInMODirectFeedingSendRequestToNotDefined = "CustomTrackInMODirectFeedingSendRequestToNotDefined";

        /// <summary>
        /// Exception message displayed when a consumable (pallet) is attached manually on a direct feeding.
        /// Message: Cannot attach pallet on resource {0}: Attach process not valid for DirectFeeding mode
        /// </summary>
        public const string CustomAttachConsumableNotValidInDirectFeedingMode = "CustomAttachConsumableNotValidInDirectFeedingMode";

        /// <summary>
        /// The direct feeding counterpart for resource {0} doesn't exist or name isn't configured correctly.
        /// </summary>
        public const string CustomDirectFeedingResourceCounterPartNoValid = "CustomDirectFeedingResourceCounterPartNoValid";
        /// <summary>
        /// Second Line DirectFeedingCounterPart order hasn't been finished yet.
        /// </summary>
        public const string CustomDirectFeedingCounterPartUnfinished = "CustomDirectFeedingCounterPartUnfinished";

        /// <summary>
        /// The direct feeding counterpart for order {0} in second line doesn't exist or name isn't configured correctly.
        /// </summary>
        public const string CustomDirectFeedingSecondLineCounterPartNotValid = "CustomDirectFeedingSecondLineCounterPartNotValid";

        /// <summary>
        /// The resource for material {0} was not found.
        /// </summary>
        public const string CustomDirectFeedingResourceNotFound = "CustomDirectFeedingResourceNotFound";

        /// <summary>
        /// Cannot start order {0}: The resource {1} still has an order in process.
        /// </summary>
        public const string CustomDirectFeedingOrderStillInProcess = "CustomDirectFeedingOrderStillInProcess";

        /// <summary>
        /// Cannot perform palletization on counterpart material {0}: The material does not have the necessary quantity, it needs {1} in order to palletize.
        /// </summary>
        public const string CustomDirectFeedingCounterpartMaterialDoesNotHaveEnoughQuantity = "CustomDirectFeedingCounterpartMaterialDoesNotHaveEnoughQuantity";

        #endregion

        #region Error Messages

        /// <summary>
        /// Error requesting DirectFeedingCounterpartFinished retry: AutomationControllerInstance is null
        /// </summary>
        public const string CustomErrorMessageRequestingVirtualPalletAutomationControllerInstanceIsNull = "Error requesting DirectFeedingCounterpartFinished: AutomationControllerInstance is null.";

        /// <summary>
        /// Exception message displayed when the first line is not setup correctly.
        /// Message: Cannot palletize MO: The first line {1} does not have any materials in process.
        /// </summary>
        public const string CustomPalletizeMaterialFirstLineNotSetUp = "CustomPalletizeMaterialFirstLineNotSetUp";

        /// <summary>
        /// Exception message displayed when there is a problem on the palletization on the first line.
        /// Message: There was a problem in request of palletization of first Line: {0}.
        /// </summary>
        public const string CustomPalletizeNotSuccessfulOnFirstLine = "CustomPalletizeNotSuccessfulOnFirstLine";

        /// <summary>
        /// Error in Second line requesting first line to clear interlock: Resource Match not valid
        /// </summary>
        public const string CustomErrorMessageDFClearInterlockNotValid = "Error requesting first line to clear interlock. Resource Match not valid.";

        /// <summary>
        /// Error in Second line requesting first line to clear interlock: {0}' is null.
        /// </summary>
        public const string CustomErrorMessageDFClearInterlockNullValue = "Error requesting first line to clear interlock. '{0}' is null.";

        /// <summary>
        /// Error in Second line requesting first line to clear interlock: first line failed to clear interlock.
        /// </summary>
        public const string CustomErrorMessageDFClearInterlockNoReply = "Error requesting first line to clear interlock. IoT reply is null.";

        #endregion

        #region AutomationConstants

        /// <summary>
        /// Automation DirectFeeding value for interlock
        /// </summary>
        public const string CustomDirectFeeding = "DirectFeeding";

        #endregion

        #region Request Types

        /// <summary>
        /// Request Type - ClearDirectFeedingInterlock
        /// </summary>
        public const string AutomationRequestClearDirectFeedingInterlock = "ClearDirectFeedingInterlock";

        #endregion

        #region Generic

        /// <summary>
        /// To identify when it is to do special attach or normal process
        /// </summary>
        public const string CustomDirectFeedingIsToSpecialAttach = "DirectFeedingIsToSpecialAttach";

        /// <summary>
        /// To identify when attach is from normal process from first line to second line and not manual
        /// </summary>
        public const string CustomDirectFeedingAutomaticAttach = "DirectFeedingAutomaticAttach";

        #endregion
    }
}

