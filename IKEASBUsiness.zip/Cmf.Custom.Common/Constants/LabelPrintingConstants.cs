﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Common
{
    /// <summary>
    /// This class contains constants part of material tracking
    /// </summary>
    public static partial class IKEAConstants
    {
        #region Label Printing

        /// <summary>
        /// IKEA CustomMaterialLoss EntityType
        /// </summary>
        public const string CustomMaterialLoss = "CustomMaterialLoss";

        /// <summary>
        /// IKEA ItemDescription product attribute
        /// </summary>
        public const string ItemDescription = "ItemDescription";

        /// <summary>
        /// IKEA step attribute PrintOptions
        /// </summary>
        public const string CustomPrintOptions = "PrintOptions";

        /// <summary>
        /// Material Form to be ignored on label print
        /// </summary>
        public const string CustomPrintMOType = "MO";


        /// <summary>
        /// Material Form to be ignored on label print
        /// </summary>
        public const string CustomPrintBatchType = "Batch";

        /// <summary>
        /// String Format for "6-digit" GS1 format (Nx+N6)
        /// </summary>
        public const string GS1StringFormatN6 = "D6";

        #endregion

        #region CmfTimer

        /// <summary>
        /// Cmf Timer Name prefix to be used when creating timers to print material labels
        /// </summary>
        public const string CustomExecutePrintingTask = "CustomExecutePrintingTask";
        
        /// <summary>
        /// Cmf Timer Attribute to customize the resource used for resolving the printing smart table
        /// </summary>
        public const string CmfTimerAttributePrintCustomResource = "PrintCustomResource";

        #endregion


        #region Configurations

        /// <summary>
        /// Indicates the GS1 Product Token
        /// </summary>
        public const string GS1ProductToken = "/Cmf/Custom/LabelPrinting/ProductToken/";

        /// <summary>
        /// Indicates the GS1 Pallet Id Token
        /// </summary>
        public const string GS1PalletIdToken = "/Cmf/Custom/LabelPrinting/PalletIdToken/";

        /// <summary>
        /// Indicates the GS1 Pallet Name Token
        /// </summary>
        public const string GS1PalletNameToken = "/Cmf/Custom/LabelPrinting/PalletNameToken/";

        /// <summary>
        /// Indicates the GS1 Quantity Token
        /// </summary>
        public const string GS1QuantityToken = "/Cmf/Custom/LabelPrinting/QuantityToken/";

        /// <summary>
        /// Indicates the length of the factory code in the pallet number
        /// </summary>
        public const string FactoryCodeLength = "/Cmf/Custom/UllLabelPrinting/FactoryCodeLength";

        /// <summary>
        /// Indicates the length of the printer code in the pallet number
        /// </summary>
        public const string PrinterCodeLength = "/Cmf/Custom/UllLabelPrinting/PrinterCodeLength";

        /// <summary>
        /// Indicates the length of the counter part of the pallet number for short form codes
        /// </summary>
        public const string PalletNumberShortFormCounterLength = "/Cmf/Custom/UllLabelPrinting/PalletNumberShortFormCounterLength";

        /// <summary>
        /// Indicates how to consider the first week of hte year. Possible values: FirstDay, FirstFullWeek, FirstFourDayWeek.
        /// </summary>
        public const string DateStampFormatFirstWeekOfYear = "/Cmf/Custom/UllLabelPrinting/DateStampFormatFirstWeekOfYear";

        /// <summary>
        /// Indicates the first day of the week to be considered when printing the ULL label.
        /// </summary>
        public const string DateStampFormatFirstDayOfWeek = "/Cmf/Custom/UllLabelPrinting/DateStampFormatFirstDayOfWeek";

        /// <summary>
        /// PalletType Recipe Parameter Name
        /// </summary>
        public const string PalletTypeRecipeParameterName = "/Cmf/Custom/UllLabelPrinting/PalletTypeRecipeParameterName";

        #endregion

        #region Localized Messages

        /// <summary>
        /// The configuration for printing was not found on the smart table {0}
        /// </summary>
        public const string CustomLabelPrintingConfigNotFoundLocalizedMessage = "CustomLabelPrintingConfigNotFound";

        /// <summary>
        /// The configuration for printing was not found on the smart table {0}
        /// </summary>
        public const string CustomLabelPrintingSuccessLocalizedMessage = "CustomLabelPrintingSuccess";

        /// <summary>
        /// Date stamp must have the following format: 4 digits YYWW, the first two representing the year, and the last two the week.
        /// </summary>
        public const string CustomLabelPrintingDateStampIncorrectFormatLocalizedMessage = "CustomLabelPrintingDateStampIncorrectFormat";

        /// <summary>
        /// The {0} value cannot be less than {1}.
        /// </summary>
        public const string CustomLabelPrintingFieldLessThanValueLocalizedMessage = "CustomLabelPrintingFieldLessThanValue";

        /// <summary>
        /// The {0} value {1} is was not found on the Lookup Table {2}.
        /// </summary>
        public const string CustomValueNotInLookupTableLocalizedMessage = "CustomValueNotInLookupTable";

        /// <summary>
        /// Missing attribute {0} in {1} "{2}".
        /// </summary>
        public const string CustomMissingAttributeInEntityLocalizedMessage = "CustomMissingAttributeInEntity";

        /// <summary>
        /// No material was found in the printing queue resource '{0}'.
        /// </summary>
        public const string CustomLabelPrintingMissingMaterialInQueueLocalizedMessage = "CustomLabelPrintingMissingMaterialInQueue";

        /// <summary>
        /// The value for the Facility attribute FactoryCode must be an integer {0}.
        /// </summary>
        public const string CustomLabelPrintingErrorParseFactoryCodeLocalizedMessage = "CustomLabelPrintingErrorParseFactoryCode";

        /// <summary>
        /// The value for the Resource attribute PrinterCode must be an integer {0}.
        /// </summary>
        public const string CustomLabelPrintingErrorParsePrinterCodeLocalizedMessage = "CustomLabelPrintingErrorParsePrinterCode";

        /// <summary>
        /// No printing system was found in the printing queue resource {0}.
        /// </summary>
        public const string CustomLabelPrintingErrorParsePrintingSystemCodeLocalizedMessage = "CustomLabelPrintingErrorParsePrintingSystemCode";

        // <summary>
        /// '{0}' material was found in the system.
        /// </summary>
        public const string CustomLabelPalletIdErrorLocalizedMessage = "CustomLabelPalletIdError";

        // <summary> 
        /// '{0}' material was not found in the printing queue resource '{1}' or MO '{2}'.
        /// </summary>
        public const string CustomLabelPalletIdErrorforResourceLocalizedMessage = "CustomLabelPalletIdErrorforResource";

        // <summary>
        /// Unexcepected error at step : '{0}'. Original Error Message: '{1}'.
        /// </summary>
        public const string CustomLabelDeadlockLocalizedMessage = "CustomLabelDeadlockLocalizedMessage";

        #endregion
    }
}
