﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Common
{
    public static partial class IKEAConstants
    {

        #region General

        /// <summary>
        /// Resource unit complete mode automation
        /// </summary>
        public const string ResourceUnitCompleteModeModeAutomation = "Automation";

        /// <summary>
        /// Resource unit complete mode ManualOutsorting 
        /// </summary>
        public const string ResourceUnitCompleteModeModeManualOutsorting = "ManualOutsorting";

        /// <summary>
        /// Resource Type - Consumable
        /// </summary>
        public const string ResourceTypeConsumable = "Consumable";

        /// <summary>
        /// Resource Type - Outsorter
        /// </summary>
        public const string ResourceTypeOutsorter = "Outsorter";

        /// <summary>
        /// Resource Type - Outfeeder
        /// </summary>
        public const string ResourceTypeOutfeeder = "Outfeeder";

        /// <summary>
        /// Resource Type - Printing Queue
        /// </summary>
        public const string ResourceTypePrintingQueue = "Printing Queue";

        /// <summary>
        /// Resource Type - Printer
        /// </summary>
        public const string ResourceTypePrinter = "Printer";

        /// <summary>
        /// Message Bus Message prefix to be used when publishing messages to refresh all Operator Cockpit GUIs open a given resource
        /// </summary>
        public const string MessageBusResourceAndMaterialEventsPrefix = "Cmf.Custom.ResourceAndMaterialEvents.";

        /// <summary>
        /// Message Bus Message prefix to be used when publishing messages to refresh all Operator Cockpit GUIs open a given resource
        /// </summary>
        public const string MessageBusPrintingQueueEventsPrefix = "Cmf.Custom.PrintingQueueEvents.";

        /// <summary>
        /// Context Parameter that holds all resources already handled by the event publisher DEE to avoid duplicate reporting and refresh
        /// </summary>
        public const string CustomResourceMaterialEventsPublisherProcessedResourceEvents = "CustomResourceMaterialEventsPublisherProcessedResourceEvents";

        /// <summary>
        /// Service Message indicating that the resource state was changed by IoT
        /// </summary>
        public const string CustomResourceEnforceCommentOnChangeStateServiceMessageIoT = "Resource state changed by IoT (action {0})";

        /// <summary>
        /// Service Message indicating that the resource state was changed automatically
        /// </summary>
        public const string CustomResourceEnforceCommentOnChangeStateServiceMessageAuto = "Resource state changed automatically by action {0}";
        #endregion

        /// <summary>
        /// Resource Property - Name
        /// </summary>
        public const string ResourceName = "ResourceName";

        /// <summary>
        /// Resource Property - OutfeederName
        /// </summary>
        public const string OutfeederName = "OutfeederName";

        #region Consumable Attachment Validations

        /// <summary>
        /// The following materials cannot be attached to the resource because they are not compatible with the BOM: '{0}'.
        /// </summary>
        public const string CustomConsumableAttachmentValidationsInvalidMaterialLocalizedMessage = "CustomConsumableAttachmentValidationsInvalidMaterial";
        #endregion

        #region ERP

        /// <summary>
        /// The type {0}, provided on the message does not exist on the table CustomERPColumnsMapping.
        /// </summary>
        public const string CustomERPProductionOrderErrorType = "CustomERPProductionOrderErrorType";

        /// <summary>
        /// The facility with ERPIdentifier {0}, provided on the message does not exist on the system.
        /// </summary>
        public const string CustomERPProductionOrderFacilityError = "CustomERPProductionOrderFacilityError";

        /// <summary>
        /// The product {0}, provided on the message either does not exist on the system or is not the Base Product.
        /// </summary>
        public const string CustomERPProductionOrderProductError = "CustomERPProductionOrderProductError";

        /// <summary>
        /// The resource {0}, provided on the message does not exist on the system.
        /// </summary>
        public const string CustomERPProductionOrderResourceError = "CustomERPProductionOrderResourceError";

        /// <summary>
        /// The path doesn't exist on the message.
        /// </summary>
        public const string CustomERPProductionOrderXmlError = "CustomERPProductionOrderXmlError";

        /// <summary>
        /// In the resource {0} there is no subresource with ProcessSegmentSequence = {1} and SubProcessSegmentName = {2} .
        /// </summary>
        public const string CustomERPSubResourcesDoesntMatchError = "CustomERPSubResourcesDoesntMatchError";

        /// <summary>
        /// No flow was found for product {0}.
        /// </summary>
        public const string CustomERPNOFlowFoundForProductError = "CustomERPNOFlowFoundForProductError";

        /// <summary>
        /// Cannot find the Flow with ERPOperationCode {0}
        /// </summary>
        public const string CustomFindFlowWithERPOperationCode = "CustomFindFlowWithERPOperationCode";

        /// <summary>
        /// The following Products define in the BOM do not exist: {0}
        /// </summary>
        /// <remarks>
        ///     {0} - Product Names
        /// </remarks>
        public const string CustomERPBomResolutionMissingProductsLocalizedMessage = "CustomERPBomResolutionMissingProducts";

        #endregion

        #region Config

        /// <summary>
        /// Product Revision Separator
        /// </summary>
        public const string ConsumableAttachmentValidationEnable = "/Cmf/Custom/Actions/ConsumableAttachmentValidation/Enable";

        /// <summary>
        /// Resource State Reclassification Notification Timer Frequency
        /// </summary>
        public const string ResourceStateReclassificationNotificationTimerFrequency = "/Cmf/Custom/Resources/StateReclassifications/Notifications/TimerFrequency";

        /// <summary>
        /// Resource State Reclassification Notification Timeframe
        /// </summary>
        public const string ResourceStateReclassificationNotificationTimeframe = "/Cmf/Custom/Resources/StateReclassifications/Notifications/Timeframe";

        /// <summary>
        /// Resource State Reclassification Notification Severity
        /// </summary>
        public const string ResourceStateReclassificationsNotificationSeverity = "/Cmf/Custom/Resources/StateReclassifications/Notifications/Severity";


        /// <summary>
        /// Resource ByPassDurableValidation
        /// </summary>
        public const string ResourceByPassDurableValidation = "/Cmf/Custom/Resources/ByPassDurableValidation";
        #endregion

        #region Features

        /// <summary>
        /// Feature that holds the role with permissions for requesting an Ad-Hoc PO for type Rework or Repair,
        /// from the Operator Cockpit of a Resource
        /// </summary>
        public const string CreateProductionOrder = "Custom.CreateProductionOrder";

        #endregion

        #region Localized Messages

        /// <summary>
        /// Insuficient materials
        /// </summary>
        public const string CustomConsumableFeedsBelowLimitTitleLocalizedMessage = "CustomConsumableFeedsBelowLimitTitle";

        /// <summary>
        /// Resource: {0} has insuficient materials of the product {1} according to the minimum limit defined of {2} pallets. Actual quantity: {3}. Minimum quantity: {4}. 
        /// </summary>
        public const string CustomConsumableFeedsBelowLimitDetailLocalizedMessage = "CustomConsumableFeedsBelowLimitDetail";

        /// <summary>
        /// Resource: {0} has changed from {1}
        /// </summary>
        public const string CustomResourceStateChangesNotificationHasChangedMessageLocalizedMessage = "CustomResourceStateChangesNotificationHasChangedMessage";

        /// <summary>
        /// The Resource {0} has changed from <b>{1}</b> on <b>{3}</b>, by user <b>{2}</b>
        /// </summary>
        public const string CustomResourceStateChangesNotificationHasChangedOnMessageLocalizedMessage = "CustomResourceStateChangesNotificationHasChangedOnMessage";

        /// <summary>
        /// For the following reason: <b>{0}</b>
        /// </summary>
        public const string CustomResourceStateChangesNotificationFollowingReasonMessageLocalizedMessage = "CustomResourceStateChangesNotificationFollowingReasonMessage";

        /// <summary>
        /// <p><b>This email was automatically generated by the system.</b></p>
        /// </summary>
        public const string CustomResourceStateChangesNotificationEmailMessageLocalizedMessage = "CustomResourceStateChangesNotificationEmailMessage";

        /// <summary>
        /// With the following service comments: <b>{0}</b>
        /// </summary>
        public const string CustomResourceStateChangesNotificationServiceCommentsMessageLocalizedMessage = "CustomResourceStateChangesNotificationServiceCommentsMessage";

        /// <summary>
        /// The Resource {0} is has been in the state {1} for the past {2} seconds
        /// </summary>
        public const string CustomResourceDownNotificationTitleLocalizedMessage = "CustomResourceDownNotificationTitle";

        /// <summary>
        /// Timer to send a notification indicating that the Resource {0} as been in the same state for the past {1} seconds
        /// </summary>
        public const string CustomResourceDownNotificationTimerDescriptionLocalizedMessage = "CustomResourceDownNotificationTimerDescription";

        /// <summary>
        /// The resource {0} needs to be of a processing type Storage or ConsumableFeed to allow a material movement.
        /// </summary>
        /// <remarks>
        ///     {0} - Resource Name
        /// </remarks>
        public const string CustomLogMaterialMovementWrongProcessingTypeLocalizedMessage = "CustomLogMaterialMovementWrongProcessingType";

        /// <summary>
        /// The following reclassifications cannot be performed because lack of permissions to do it:
        /// </summary>
        public const string CustomResourceStateReclassificationNotAllowedReclassificationsLocalizedMessage = "CustomResourceStateReclassificationNotAllowedReclassifications";

        /// <summary>
        /// Form State Model {0}, State {1} and Reason {2}
        /// </summary>
        public const string CustomResourceStateReclassificationNotAllowedReclassificationsFromStatesLocalizedMessage = "CustomResourceStateReclassificationNotAllowedReclassificationsFromStates";

        /// <summary>
        /// Reclassification from Form State Model {0}, State {1} and Reason {2} to Form State Model {3}, State {4} and Reason {5} is missing a mandatory comment
        /// </summary>
        public const string CustomResourceStateReclassificationAllowedReclassificationMissingMandotoryCommentLocalizedMessage = "CustomResourceStateReclassificationAllowedReclassificationMissingMandotoryComment";

        /// <summary>
        ///  To State Model {0}, State {1} and Reason {2}
        /// </summary>
        public const string CustomResourceStateReclassificationNotAllowedReclassificationsToStatesLocalizedMessage = "CustomResourceStateReclassificationNotAllowedReclassificationsToStates";

        /// <summary>
        /// MES request {0} to Connect IOT timed out. Please contact Local MES Support to validate if IOT Controller and Automation Manager are set up and running for this equipment.
        /// </summary>
        /// <remarks>
        ///     {0} - Request type
        /// </remarks>
        public const string CustomIOTConnectionTimeoutLocalizedMessage = "CustomIOTConnectionTimeout";

        /// <summary>
        /// Timer used for executing the {0} rule.
        /// </summary>
        /// <remarks>
        ///     {0} - Rule
        /// </remarks>
        public const string CustomResourceStopReclassificationNotificationTimerDescriptionLocalizedMessage = "CustomResourceStopReclassificationNotificationTimerDescription";

        /// <summary>
        /// Resource Stop Reclassification Notification
        /// </summary>
        public const string CustomResourceStopReclassificationNotificationTitleLocalizedMessage = "CustomResourceStopReclassificationNotificationTitle";

        /// <summary>
        /// The resource {0} was previously in the '{1}' state from {2} to {3}, for the reason '{4}'. This is longer than the threshold of {5} seconds. Please, consider classifying this state.
        /// </summary>
        /// <remarks>
        ///     {0} - Resource
        ///     {1] - StateModelState
        ///     {2} - StartDate
        ///     {3} - EndDate
        ///     {4} - StateModelStateReason
        ///     {5} - Threshold
        /// </remarks>
        public const string CustomResourceStopReclassificationNotificationDetailsLocalizedMessage = "CustomResourceStopReclassificationNotificationDetails";

        /// <summary>
        /// It is necessary to add a comment to justify the resource change state.
        /// </summary>
        public const string CustomResourceEnforceCommentOnChangeStateCommentNecessaryLocalizedMessage = "CustomResourceEnforceCommentOnChangeStateCommentNecessary";

        /// <summary>
        /// The selected resource '{0}' is not of the processing type Consumable Feed.
        /// </summary>
        public const string CustomResourceWrongProcessingTypeLocalizedMessage = "CustomResourceWrongProcessingType";

        /// <summary>
        /// The selected Consumption Provider '{0}' is already a Feeder of another resource.
        /// </summary>
        public const string CustomResourceProviderHasParentResourceLocalizedMessage = "CustomResourceProviderHasParentResource";

        /// <summary>
        /// At least one of the selected distributed consumption providers is not of the processing type Consumable Feed.
        /// </summary>
        public const string CustomDistributedResourceWrongProcessingTypeLocalizedMessage = "CustomDistributedResourceWrongProcessingType";

        /// <summary>
        /// The distributed consumable feed is not a consumable feede of the same line that the selected main feeder.
        /// </summary>
        public const string CustomDistributedResourceProviderHasDifferentParentResourceLocalizedMessage = "CustomDistributedResourceProviderHasDifferentParentResource";

        /// <summary>
        /// Only resources that are specified as DistributedConsumption in the feeder relation are able to join as a distributed feeder!
        /// </summary>
        public const string CustomDistributedResourceProviderWrongConsumptionModeLocalizedMessage = "CustomDistributedResourceProviderWrongConsumptionMode";

        /// <summary>
        /// All feeders must have the same consumption mode than the Main feeder. Expected: {0}.
        /// </summary>
        public const string CustomDistributedResourceProviderIncompatibleConsumptionModeLocalizedMessage = "CustomDistributedResourceProviderIncompatibleConsumptionMode";

        /// <summary>
        /// There is not enough quantity in all distributed feeders. Available: {0}. Necessary: {1}.
        /// </summary>
        public const string CustomDistributedResourceProviderNotEnoughQuantityLocalizedMessage = "CustomDistributedResourceProviderNotEnoughQuantity";

        /// <summary>
        /// It is not possible to change the distributed feeders configuration when there are orders in process.
        /// </summary>
        public const string CustomDistributedResourceProviderChangeWhenOrdersInProcessLocalizedMessage = "CustomDistributedResourceProviderChangeWhenOrdersInProcess";

        /// <summary>
        /// The BOM is targeting a Process Segment and SubProcess Segment (Resource '{0}') that it is part of a distributed feeder configuration.
        /// </summary>
        public const string CustomDistributedResourceProviderErrorInBOMLocalizedMessage = "CustomDistributedResourceProviderErrorInBOM";

        /// <summary>
        /// The selected Consumable Feed '{0}' does not belong to a parent resource.
        /// </summary>
        public const string CustomResourceFeederDoesNotHaveParentResourceLocalizedMessage = "CustomResourceFeederDoesNotHaveParentResource";

        /// <summary>
        /// For manual attachment of materials, it is mandatory to have at least one Order in process in the resource '{0}'.
        /// </summary>
        public const string CustomValidateMaterialsinProcessLocalizedMessage = "CustomValidateMaterialsinProcess";

        /// <summary>
        /// The resource {0} is not configured to use Manual loading. Check Table CustomManualLoadingConfiguration.
        /// </summary>
        public const string CustomManualLoadingNotAllowedForResourceLocalizedMessage = "CustomManualLoadingNotAllowedForResource";

        /// <summary>
        /// The resource {0} is not configured to use outsorting in the line. Check Table CustomFeederOutSortingConfiguration.
        /// </summary>
        public const string CustomFeederOutsortingNotAllowedForResourceLocalizedMessage = "CustomFeederOutsortingNotAllowedForResource";

        /// <summary>
        /// There are no storage resource configured in the feeder {0}.
        /// </summary>
        public const string CustomNoStorageResourceConfiguredLocalizedMessage = "CustomNoStorageResourceConfigured";

        /// <summary>
        /// The resource specified in the feeder attribute '{0}' does not represent a valid resource name: '{1}'.
        /// </summary>
        public const string CustomStorageResourceNotFoundLocalizedMessage = "CustomStorageResourceNotFound";

        /// <summary>
        /// The process type of the storage resource is '{0}'. It must be of type 'Storage'.
        /// </summary>
        public const string CustomStorageResourceIncorrectProcessingTypeLocalizedMessage = "CustomStorageResourceIncorrectProcessingType";

        /// <summary>
        /// There is more than one pallet in the storage resource '{0}'.
        /// </summary>
        public const string CustomStorageResourceMultiplePalletsFoundLocalizedMessage = "CustomStorageResourceMultiplePalletsFound";

        /// <summary>
        /// There is not enough quantity in the consumables to split the outsorted pieces. Available quantity: {0}, necessary quantity: {1}.
        /// </summary>
        public const string CustomStorageResourceNotEnoughQuantityInFeederLocalizedMessage = "CustomStorageResourceNotEnoughQuantityInFeeder";

        /// <summary>
        /// An outsorted pallet was not found in the storage resource '{0}'.
        /// </summary>
        public const string CustomStorageResourceEmptyLocalizedMessage = "CustomStorageResourceEmpty";

        /// <summary>
        /// A new outsorted pallet cannot be stored because another pallet was already in the storage resource '{0}'.
        /// </summary>
        public const string CustomStorageResourcePalletCannotBeStoredLocalizedMessage = "CustomStorageResourcePalletCannotBeStored";

        /// <summary>
        /// It was not possible to resolve a valid Step and Flow from the FlowPath configured in the smart table 'CustomFeederOutsortingFlowResolution'. FlowPath: '{0}'.
        /// </summary>
        public const string CustomStorageFlowPathNotValidLocalizedMessage = "CustomStorageFlowPathNotValid";

        /// <summary>
        /// It was not possible to resolve a valid FlowPath in the smart table 'CustomFeederOutsortingFlowResolution'.
        /// </summary>
        public const string CustomStorageFlowPathNotFoundLocalizedMessage = "CustomStorageFlowPathNotFound";

        /// <summary>
        /// No Resources were found that match the ProcessSegment '{0}' / SubProcessSegment '{1}' specified in the BOM '{2}'. (Check smart table BOMContext).
        /// </summary>
        public const string CustomResourceNotFoundForProcessSegmentInBOMLocalizedMessage = "CustomResourceNotFoundForProcessSegmentInBOM";

        /// <summary>
        /// Could not find a relation to the feeder where the material '{0}', or it's source material '{1}', was attached.
        /// </summary>
        public const string CustomFeederNotFoundForTheSpecifiedAttachedMaterialLocalizedMessage = "CustomFeederNotFoundForTheSpecifiedAttachedMaterial";

        /// <summary>
        /// Invalid Main Feeder resource for line {0} without operator selection enabled in Generic Table {1}. Got {2}, but expected {3}.
        /// </summary>
        public const string CustomResourceMainFeederInvalidInputLocalizedMessage = "CustomResourceMainFeederInvalidInput";

        /// <summary>
        /// Cannot track-in at Resource {0} with Main Feeder {1}. The Resource currently has InProcess Materials using {2} as Main Feeder, and only one Main feeder at a time is allowed per Main Line Resource.
        /// </summary>
        public const string CustomResourceMainFeederCurrentInProcessMismatchLocalizedMessage = "CustomResourceMainFeederCurrentInProcessMismatch";

        /// <summary>
        /// Missing input {0}. Resource {1} has a row in the Generic Table {2}, which means a Main Feeder must be provided at every track-in.
        /// </summary>
        public const string CustomResourceMainFeederMissingInputLocalizedMessage = "CustomResourceMainFeederMissingInput";

        /// <summary>
        /// Invalid Main Feeder name: The resource {0} is either not a sub-resource of main line {1}, not a consumable feed, or has no automation mode online.
        /// </summary>
        public const string CustomResourceMainFeederSubResourceNotFoundLocalizedMessage = "CustomResourceMainFeederSubResourceNotFound";

        /// <summary>
        /// Resource entity doesn't have the PalletizeErrorHandleEnabled attribute configured.
        /// </summary>
        public const string CustomResourcePalletizeErrorHandleEnabledAttributeNotFoundLocalizedMessage = "CustomResourcePalletizeErrorHandleEnabledAttributeNotFoundLocalizedMessage";

        /// <summary>
        /// Resource {0} does not have any materials currently in process.
        /// </summary>
        public const string CustomResourceNoMaterialsInProcessLocalizedMessage = "CustomResourceNoMaterialsInProcess";

        /// <summary>
        /// IoT was not able to reload pending Track-Outs
        /// </summary>
        public const string CustomReloadPendingTrackOutsIotErrorLocalizedMessage = "CustomReloadPendingTrackOutsIotErrorLocalizedMessage";

        /// <summary>
        /// Storage Resource {0} has no materials stored
        /// </summary>
        public const string CustomStorageResourceNoMaterials = "CustomStorageResourceNoMaterials";

        /// <summary>
        /// Label Storage Resource {0} is empty, therefore no materials can be retrieved
        /// </summary>
        public const string CustomStorageResourceNoMaterialsNotificationDetails = "CustomStorageResourceNoMaterialsNotificationDetails";

        /// <summary>
        /// Label Storage Resource {0} does not exist or isn't defined correctly
        /// </summary>
        public const string CustomStorageResourceDoesNotExistLocalizedMessage = "CustomStorageResourceDoesNotExistLocalizedMessage";

        ///<summary>
        /// Resource's OEE State cannot be empty because there is an alarm active or there's data in the table CustomMAOHandlingOEEState
        /// </summary>
        public const string CustomBlockOEEStateChangeOnBeginLocalizedMessage = "CustomBlockOEEStateChangeOnBeginLocalizedMessage";

        ///<summary>
        /// Resource's OEE State cannot be empty because the new state was calculated by IoT
        /// </summary>
        public const string CustomBlockOEEStateChangeOnCompleteLocalizedMessage = "CustomBlockOEEStateChangeOnCompleteLocalizedMessage";

        ///<summary>
        /// Material {0} has no defined Production Order
        /// </summary>
        public const string CustomNoMaterialProductionOrderLocalizedMessage = "CustomNoMaterialProductionOrderLocalizedMessage";

		///<summary>
		/// {0}[{1}] is incorrect.Correct value is [{2}]
		/// </summary
		public const string CustomDisplayCorrectFlowPathLocalizedMessage = "CustomDisplayCorrectFlowPath";

		#endregion

		#region Contexts

		/// <summary>
		/// CustomResourceDownNotifications - Context
		/// </summary>
		public const string CustomResourceDownNotificationsContext = "CustomResourceDownNotifications";

        #endregion

        #region Attributes

        /// <summary>
        /// Attribute with the last time the resource state has changed
        /// </summary>
        public const string LastStateChangeTimestampAttribute = "LastStateChangeTimestamp";

        /// <summary>
        /// Attribute with Process Segment Sequence code that comes from ERP
        /// </summary>
        public const string ProcessSegmentSequence = "ProcessSegmentSequence";

        /// <summary>
        /// Attribute with Sub Process Segment Name code that comes from ERP
        /// </summary>
        public const string SubProcessSegmentName = "SubProcessSegmentName";

        /// <summary>
        /// Attribute with Parent resource line name
        /// </summary>
        public const string ParentResourceLineName = "AutomationParentResourceLineName";

        /// <summary>
        /// Attribute with Inventory Location for the resource
        /// </summary>
        public const string CustomResourceAttributeInventoryLocation = "ERPInventoryLocation";

        /// <summary>
        /// Attribute with Parent resource line name
        /// </summary>
        public const string AutomationLineSpeedSubResourceController = "AutomationLineSpeedSubResourceController";

        /// <summary>
        /// Attribute with associated WorkCenter of the resource
        /// </summary>
        public const string CustomResourceAttributeWorkCenter = "WorkCenter";

        /// <summary>
        /// Attribute UnitCompletionMode of resource
        /// </summary>
        public const string CustomResourceAttributeUnitCompletionMode = "UnitCompletionMode";

        /// <summary>
        /// Attribute UnitCompletionMode of resource
        /// </summary>
        public const string CustomResourceAttributeInterlockAdmissionState = "InterlockAdmissionState";

        /// <summary>
        /// Attribute AutomaticDispatch of resource
        /// </summary>
        public const string CustomAutomaticDispatch = "AutomaticDispatch";

        /// <summary>
        /// Attribute EnableManualProcessLoss of resource
        /// </summary>
        public const string CustomEnableManualProcessLoss = "EnableManualProcessLoss";

        /// <summary>
        /// Attribute AutomationTrackingMode of resource
        /// </summary>
        public const string CustomAutomationTrackingMode = "AutomationTrackingMode";

        /// <summary>
        /// Attribute interlock state
        /// </summary>
        public const string CustomInterlockAdmissionState = "InterlockAdmissionState";

        /// <summary>
        /// Flag that indicates if materials attached to the resource should have communication enabled
        /// </summary>
        public const string CustomResourceAttributeIsReportingBlocked = "ERPIsReportingBlocked";

        /// <summary>
        /// Attribute containing the type of consumption of the feeder
        /// </summary>
        public const string CustomResourceAttributeFeederConsumptionMode = "FeederConsumptionMode";

        /// <summary>
        /// Flag that indicates if the material in the resource is being tracked in terms of minimum quantity:
        /// </summary>
        public const string CustomResourceAttributeMinimumQuantityTracking = "MinimumQuantityTracking";

        /// <summary>
        /// Attribute containing the equipment identifiers for ERP.
        /// </summary>
        public const string CustomResourceERPEquipmentIdentifiers = "ERPEquipmentIdentifiers";

        /// <summary>
        /// Attribute containing the name of the user requesting maintenance from ERP.
        /// </summary>
        public const string CustomResourceERPMaintenanceRequestUser = "ERPMaintenanceRequestUser";

        /// <summary>
        /// Attribute containing an array of equipment Ids.
        /// </summary>
        public const string CustomResourceAttributeERPEquipmentIdentifiers = "ERPEquipmentIdentifiers";

        /// <summary>
        /// Attribute identifying the name of the dummy feeder queue for this line.
        /// </summary>
        public const string CustomResourceAttributePrintingQueueResource = "PrintingQueueResource";

        /// <summary>
        /// Attribute containing the name of the storage resource to be used for the outsorted pieces at the line.
        /// </summary>
        public const string CustomOutsortingStorageResource = "OutsortingStorageResource";

        /// <summary>
        /// Attribute containing the numeric value that represents the parameter data type on OPC.
        /// </summary>
        public const string CustomOPCDataType = "OPCDataType";

        /// <summary>
        /// For maintenance, this attribute contains the facility where the resource belongs.
        /// </summary>
        public const string CustomERPMaintenanceFacility = "ERPMaintenanceFacility";

        /// <summary>
        /// For maintenance, this attribute contains the facility where the resource belongs.
        /// </summary>
        public const string CustomFabLiveMainStateModel = "FabLiveMainStateModel";

        /// <summary>
        /// Attribute with Automation Pallet Out Mode
        /// </summary>
        public const string AutomationPalletOutMode = "AutomationPalletOutMode";

        /// <summary>
        /// Logopak Name of FactorySignature to be shown on the generated ULL Labels
        /// </summary>
        public const string CustomFactorySignature = "FactorySignature";

        /// <summary>
        /// Logopak PrinterCode to be shown on the generated ULL Labels
        /// </summary>
        public const string CustomPrinterCode = "PrinterCode";

        /// <summary>
        /// Attribute that indicates the warehouse code
        /// </summary>
        public const string CustomResourceERPWarehouseLocationAttribute = "ERPWarehouseLocation";

        /// <summary>
        /// Attribute that indicates if the resource allows orderless production
        /// </summary>
        public const string CustomResourceAllowOrderlessProductionAttribute = "AllowOrderlessProduction";

        /// <summary>
        /// Attribute that indicates if the OverProduction delta quantity or Losses Delta Quantity should be rounded or not
        /// </summary>
        public const string CustomRoundOverProductionAndLossQuantity = "RoundOverProductionAndLossQuantity";

        /// <summary>
        /// Attribute that indicates the PrintingSystem used
        /// </summary>
        public const string CustomResourcePrintingSystemAttribute = "PrintingSystem";

        /// <summary>
        /// Attribute that indicates when a partial TrackOut has failed, indicating that IoT might need to refresh it's counters and queues
        /// </summary>
        public const string CustomResourcePalletizeErrorHandleEnabledAttribute = "PalletizeErrorHandleEnabled";

        /// <summary>
        /// Stores the storage resource name that will be used for the materials scanned to be retrieved from when the label is taken out
        /// </summary>
        public const string CustomLabelStorageResourceAttribute = "LabelStorageResource";

        /// <summary>
        /// Attribute that indicates if MAO is Required for resource
        /// </summary>
        public const string CustomMAORequired = "MAORequired";

        /// <summary>
        /// Attribute that indicates if Alarm is Required for resource
        /// </summary>
        public const string CustomAlarmRequired = "AlarmRequired";

        /// <summary>
        /// Attribute that indicates if resource is using direct feeding
        /// </summary>
        public const string CustomResourceDirectFeedingEnabled = "DirectFeedingEnabled";

        /// <summary>
        /// Attribute that indicates if resource first line in the direct feeding
        /// </summary>
        public const string CustomResourceDirectFeedingIsFirstLine = "DirectFeedingIsFirstLine";
        
        /// <summary>
        /// Attribute that indicates resource direct feeding counterpart to check if is also using direct feeding
        /// </summary>
        public const string CustomResourceDirectFeedingSendRequestTo = "DirectFeedingSendRequestTo";

        /// <summary>
        /// Attribute that indicates resource direct feeding outfeeder
        /// </summary>
        public const string CustomDirectFeedingOutfeederResource = "DirectFeedingOutfeederResource";

        /// <summary>
        /// Attribute that determines the maximum number of order slots to be used by the line
        /// </summary>
        public const string CustomNumberOfOrderSlots = "NumberOfOrderSlots";

        /// <summary>
        /// Attribute that determines InitialShiftQuantity value of the Outfeeder Resource
        /// </summary>
        public const string CustomInitialShiftQuantity = "CustomInitialShiftQuantity";

        /// <summary>
        /// Attribute that determines whether alternate overproduction is active
        /// </summary>
        public const string CustomAllowAlternativeOverproduction = "AllowAlternativeOverproduction";

        /// <summary>
        /// Attribute that decides if the pallet name created by a sub rescource should be send to Line controller
        /// </summary>
        public const string CustomSendPalletIDToLCEnabled = "SendPalletIDToLCEnabled";

        #endregion

        #region Rules

        /// <summary>
        /// CustomResourceDownNotificationTimer - Rule
        /// </summary>
        public const string CustomResourceDownNotificationTimer = "CustomResourceDownNotificationTimer";

        /// <summary>
        /// CustomResourceStopReclassificationNotification - Rule
        /// </summary>
        public const string CustomResourceStopReclassificationNotification = "CustomResourceStopReclassificationNotification";

        #endregion

        #region Smart Table

        /// <summary>
        /// Smart Table - CustomResourceDownNotifications
        /// </summary>
        public const string CustomResourceDownNotificationsSmartTable = "CustomResourceDownNotifications";

        /// <summary>
        /// Smart Table Property - CustomResourceDownNotifications - ResourceType
        /// </summary>
        public const string CustomResourceDownNotificationsResourceType = "ResourceType";

        /// <summary>
        /// Smart Table Property - CustomResourceDownNotifications - State
        /// </summary>
        public const string CustomResourceDownNotificationsState = "State";

        /// <summary>
        /// Smart Table Property - CustomResourceDownNotifications - TimeThreshold
        /// </summary>
        public const string CustomResourceDownNotificationsTimeThreshold = "TimeThreshold";

        /// <summary>
        /// Smart Table Property - CustomResourceDownNotifications - Role
        /// </summary>
        public const string CustomResourceDownNotificationsRole = "Role";

        /// <summary>
        /// Smart Table Property - CustomResourceDownNotifications - DistributionList
        /// </summary>
        public const string CustomResourceDownNotificationsDistributionList = "DistributionList";

        /// <summary>
        /// Smart Table Property - CustomResourceDownNotifications - MaintenanceActivity
        /// </summary>
        public const string CustomResourceDownNotificationsMaintenanceActivity = "MaintenanceActivity";

        /// <summary>
        /// Smart table that indicates the automation mode of a Order
        /// </summary>
        public const string CustomReRouteOrderSmartTable = "CustomReRouteOrder";

        /// <summary>
        /// CustomReRouteOrder - Facility
        /// </summary>
        public const string CustomReRouteOrderFacility = "Facility";

        /// <summary>
        /// CustomReRouteOrder - Area
        /// </summary>
        public const string CustomReRouteOrderArea = "Area";

        /// <summary>
        /// CustomReRouteOrder - Original Resource
        /// </summary>
        public const string CustomReRouteOrderOriginalResource = "OriginalResource";

        /// <summary>
        /// CustomReRouteOrder - WorkCenter
        /// </summary>
        public const string CustomReRouteOrderWorkCenter = "WorkCenter";

        /// <summary>
        /// CustomReRouteOrder - ProductGroup
        /// </summary>
        public const string CustomReRouteOrderProductGroup = "ProductGroup";

        /// <summary>
        /// CustomReRouteOrder - Product
        /// </summary>
        public const string CustomReRouteOrderProduct = "Product";

        /// <summary>
        /// CustomReRouteOrder - Target Resource
        /// </summary>
        public const string CustomReRouteOrderTargetResource = "TargetResource";

        /// <summary>
        /// Service Context SmartTable
        /// </summary>
        public const string ServiceContextSmartTable = "ServiceContext";

        #endregion

        #region Generic Table

        ///<summary>
        /// Generic Table - CustomResourceStateChanges
        /// </summary>
        public const string CustomResourceStateChangesGenericTable = "CustomResourceStateChanges";

        /// <summary>
        /// Generic Table - CustomDefaultMainFeederConfiguration
        /// </summary>
        public const string CustomDefaultMainFeederConfigurationGenericTable = "CustomDefaultMainFeederConfiguration";

        /// <summary>
        /// Generic Table Property - CustomDefaultMainFeederConfiguration - MainLine
        /// </summary>
        public const string CustomDefaultMainFeederConfigurationMainLine = "MainLine";

        /// <summary>
        /// Generic Table Property - CustomDefaultMainFeederConfiguration - DefaultFeeder
        /// </summary>
        public const string CustomDefaultMainFeederConfigurationDefaultFeeder = "DefaultFeeder";

        /// <summary>
        /// Generic Table Property - CustomDefaultMainFeederConfiguration - AlternativeFeeder
        /// </summary>
        public const string CustomDefaultMainFeederConfigurationAlternativeFeeder = "AlternativeFeeder";

        /// <summary>
        /// Generic Table Property - CustomDefaultMainFeederConfiguration - EnableOperatorSelection
        /// </summary>
        public const string CustomDefaultMainFeederConfigurationEnableOperatorSelection = "EnableOperatorSelection";


        /// <summary>
        /// Generic Table - CustomAlternativeSubResources
        /// </summary>
        public const string CustomAlternativeSubResourcesGenericTable = "CustomAlternativeSubResources";

        /// <summary>
        /// Generic Table Property - CustomAlternativeSubResources - OriginalResource
        /// </summary>
        public const string CustomAlternativeSubResourcesOriginalResource = "OriginalResource";

        /// <summary>
        /// Generic Table Property - CustomAlternativeSubResources - AlternativeResource
        /// </summary>
        public const string CustomAlternativeSubResourcesAlternativeResource = "AlternativeResource";

        #endregion

        #region Result Messages

        /// <summary>
        /// CustomResourceDownNotification - Result - Notification Created
        /// </summary>
        public const string CustomResourceDownNotificationResultNotificationCreated = "Notification for the Resource {0} was created.";

        /// <summary>
        /// CustomResourceDownNotification - Result - No Role or Distribution List defined
        /// </summary>
        public const string CustomResourceDownNotificationResultNoRoleDistributionList = "No Role or Distribution List defined.";

        /// <summary>
        /// CustomResourceDownNotification - Result - State of the Resource Changed
        /// </summary>
        public const string CustomResourceDownNotificationResultStateOfResourceChanged = "State of the Resource {0} was change since the timer was created.";

        /// <summary>
        /// CustomResourceDownNotification - Result - Resource doesn't have a LastStateChangeTimestamp defined
        /// </summary>
        public const string CustomResourceDownNotificationResultResourceDoesNotHaveAttribute = "The Resource {0} doesn't have a LastStateChangeTimestamp defined.";

        /// <summary>
        /// CustomResourceDownNotification - Result - The Resource doesn't exist
        /// </summary>
        public const string CustomResourceDownNotificationResultResourceDoesNotExist = "The Resource {0} doesn't exist.";
        /// <summary>
        /// CustomResourceDownNotification - Result - Wrong Timer Name
        /// </summary>
        public const string CustomResourceDownNotificationResultWrongTimerName = "Wrong timer name.";
        /// <summary>
        /// IoT Error Message - Direct Feeding Match is not configured correctly
        /// </summary>
        public const string CustomResourceDirectFeedingMatchNotValid = "Direct Feeding Match is not configured correctly.";
        /// <summary>
        /// IoT Error Message - No subresources
        /// </summary>
        public const string CustomResourceMessageMissingSubResourceRelations = "Resource has no SubResource Relations.";

        #endregion

        #region State Models

        /// <summary>
        /// State Model - OEE
        /// </summary>
        public const string StateModelOEE = "OEE";

        /// <summary>
        /// State Model State - WAITING TIME
        /// </summary>
        public const string StateModelStateWaitingTime = "WAITING TIME";

        /// <summary>
        /// State Model State - WAITING TIME - Reason: Quality Stops
        /// </summary>
        public const string StateModelStateWaitingTimeQualityStops = "430-Quality Stops";

        /// <summary>
        /// State Model State - WAITING TIME - Reason: Waiting time
        /// </summary>
        public const string StateModelStateWaitingTimeWaitingTime = "400-Waiting time";

        /// <summary>
        /// State Model State - WAITING TIME - Reason: Maintenance Stop
        /// </summary>
        public const string StateModelStateWaitingTimeMaintenanceStop = "450-Maintenance Stop";

        /// <summary>
        /// State Model State - WAITING TIME - Reason: Setup
        /// </summary>
        public const string StateModelStateWaitingTimeSetup = "410-Setup";

        /// <summary>
        /// State Model State - Un-planned - Reason: Un-planned time
        /// </summary>
        public const string StateModelStateUnplannedUnplannedTime = "200-Un-planned time";

        /// <summary>
        /// State Model State - Un-planned - Reason: R&D
        /// </summary>
        public const string StateModelStateUnplannedRD = "220-R&D";

        /// <summary>
        /// State Model State - Un-planned - Reason: No orders
        /// </summary>
        public const string StateModelStateUnplannedNoOrders = "210-No orders";

        /// <summary>
        /// State Model State - Running Time Normal - Reason: Normal speed
        /// </summary>
        public const string StateModelStateRunningTimeNormalSpeed = "300-Normal speed";

        /// <summary>
        /// State Model State - Attribute - TimeClassCode
        /// </summary>
        public const string StateModelStateTimeClassCode = "TimeClassCode";

        /// <summary>
        /// State Model State - Attribute - Speed
        /// </summary>
        public const string StateModelStateSpeed = "Speed";

        /// <summary>
        /// State Model State - Attribute - Speed - Running Time Normal code
        /// </summary>
        public const string StateModelStateSpeedRunningTimeNormal = "NORMAL";

        /// <summary>
        /// State Model State - Attribute - Speed - Running Time Reduced code
        /// </summary>
        public const string StateModelStateSpeedRunningTimeReduced = "REDUCED";

        /// <summary>
        /// State Model State - Attribute - TimeClassCode - Not Planned Time code
        /// </summary>
        public const string StateModelStateTimeClassCodeNotPlanned = "10";

        /// <summary>
        /// State Model State - Attribute - TimeClassCode - Unplanned code
        /// </summary>
        public const string StateModelStateTimeClassCodeUnplanned = "20";

        /// <summary>
        /// State Model State - Attribute - TimeClassCode - Running Time - Normal
        /// </summary>
        public const string StateModelStateTimeClassCodeRunningTimeNormal = "30";

        /// <summary>
        /// State Model State - Attribute - TimeClassCode - Running Time - Reduced
        /// </summary>
        public const string StateModelStateTimeClassCodeRunningTimeReduced = "31";

        /// <summary>
        /// State Model State - Attribute - TimeClassCode - Waiting Time code
        /// </summary>
        public const string StateModelStateTimeClassCodeWaitingTime = "40";

        /// <summary>
        /// State Model State - Attribute - TimeClassCode - Breakdown Time Machine code
        /// </summary>
        public const string StateModelStateTimeClassCodeBreakdownTimeMachine = "50";

        /// <summary>
        /// State Model State - Attribute - TimeClassCode - Breakdown Time Facility code
        /// </summary>
        public const string StateModelStateTimeClassCodeBreakdownTimeFacility = "90";

        #endregion

        #region Timers

        /// <summary>
        /// Name of the Timer responsible for executing the 'CustomResourceStopReclassificationNotification' Rule.
        /// </summary>
        public const string CustomResourceStopReclassificationNotificationTimer = "CustomResourceStopReclassificationNotificationTimer";

        #endregion

    }
}
