﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Common
{
    public static partial class IKEAConstants
    {
        #region Constants

        /// <summary>
        /// Replenishment Of Stocking Points CmfTimer and Rule
        /// </summary>
        public const string CustomReplenishmentOfStockingPoints = "CustomReplenishmentOfStockingPoints";

        #endregion

        #region Localized Messages

        /// <summary>
        /// Calculates and creates Replenishment requirements for a stocking point
        /// </summary>
        public const string CustomReplenishmentOfStockingPointsTimerDescriptionMessage = "CustomReplenishmentOfStockingPointsTimerDescriptionMessage";

        #endregion

        #region Configuration

        /// <summary>
        /// Stocking Point Replenishment Timer Frequency
        /// </summary>
        public const string StockingPointReplenishmentTimerFrequencyConfig = "/Cmf/Custom/StockingPointReplenishment/TimerFrequency";

        #endregion

        #region Smart Tables

        /// <summary>
        /// Smart Table - CustomMaterialReplenishmentRequestConfiguration
        /// </summary>
        public const string CustomMaterialReplenishmentRequestConfigurationSmartTable = "CustomMaterialReplenishmentRequestConfiguration";

        /// <summary>
        /// Smart Table - CustomMaterialReplenishmentRequestConfiguration - Stocking Point
        /// </summary>
        public const string CustomMaterialReplenishmentRequestConfigurationStockingPoint = "StockingPoint";

        /// <summary>
        /// Smart Table - CustomMaterialReplenishmentRequestConfiguration - Product
        /// </summary>
        public const string CustomMaterialReplenishmentRequestConfigurationProduct = "Product";

        /// <summary>
        /// Smart Table - CustomMaterialReplenishmentRequestConfiguration - Product Type
        /// </summary>
        public const string CustomMaterialReplenishmentRequestConfigurationProductType = "ProductType";

        /// <summary>
        /// Smart Table - CustomMaterialReplenishmentRequestConfiguration - Working Mode
        /// </summary>
        public const string CustomMaterialReplenishmentRequestConfigurationWorkingMode = "WorkingMode";

        /// <summary>
        /// Smart Table - CustomMaterialReplenishmentRequestConfiguration - Hours To Consider
        /// </summary>
        public const string CustomMaterialReplenishmentRequestConfigurationHoursToConsider = "HoursToConsider";

        /// <summary>
        /// Smart Table - CustomMaterialReplenishmentRequestConfiguration - Request Mode
        /// </summary>
        public const string CustomMaterialReplenishmentRequestConfigurationRequestMode = "RequestMode";

        /// <summary>
        /// Smart Table - CustomMaterialReplenishmentRequestConfiguration - Quantity To Request
        /// </summary>
        public const string CustomMaterialReplenishmentRequestConfigurationQuantityToRequest = "QuantityToRequest";

        /// <summary>
        /// Smart Table - CustomMaterialReplenishmentRequestConfiguration - Threshold
        /// </summary>
        public const string CustomMaterialReplenishmentRequestConfigurationThreshold = "Threshold";

        /// <summary>
        /// Smart Table - CustomMaterialReplenishmentRequestConfiguration - Facility
        /// </summary>
        public const string CustomMaterialReplenishmentRequestConfigurationFacility = "Facility";

        /// <summary>
        /// Smart Table - CustomMaterialReplenishmentRequestConfiguration - Area
        /// </summary>
        public const string CustomMaterialReplenishmentRequestConfigurationArea = "Area";

        #endregion
    }
}
