﻿namespace Cmf.Custom.IKEA.Common
{
    public static partial class IKEAConstants
    {
        #region Constants

        /// <summary>
        /// Name for CmfTimer and Rule
        /// </summary>
        public const string CustomNotifyCertificationExpiration = "CustomNotifyCertificationExpiration";

        /// <summary>
        /// Smart Table resolve order column name
        /// </summary>
        public const string ResolveOrderName = "resolvedOrder";

        /// <summary>
        /// DEE context parameter indicating pallet generated type to be used on name generator
        /// </summary>
        public const string CustomUnitCompletePalletTypeContextKey = "CustomUnitComplete_GeneratedPalletType";

        /// <summary>
        /// DEE context parameter indicating that we are resetting the MO quantity to the original value
        /// </summary>
        public const string CustomUnitCompleteDoNotUpdateScheduledQuantityContextKey = "CustomUnitComplete_DoNotUpdateScheduledQauntity";

        /// <summary>
        /// DEE context parameter indicating that label printing on split should not occur on CustomUnitComplete
        /// </summary>
        public const string CustomUnitCompletePalletizationSplitContextKey = "CustomUnitComplete_PalletizationSplit";

        /// <summary>
        /// DEE context parameter with the collection of resources that should have the enable handle palletization error attribute removed
        /// </summary>
        public const string CustomAutomationClearOrderResourcesDisableErrorHandleContextKey = "CustomAutomationClearOrder_ResourcesDisableErrorHandle";

        /// <summary>
        /// DEE context parameter indicating that the material is being attached manually. This must be handled in the CustomAutomationSendAttachInformation DEE.
        /// </summary>
        public const string CustomLogMaterialMovementManuallyAttachedPalletContextKey = "CustomLogMaterialMovement_ManuallyAttachedPallet";

        /// <summary>
        /// DEE context parameter indicating that the data fro a group MO is being changed in the Group MO page
        /// </summary>
        public const string CustomHandleGroupManufacturingOrdersEditGroupMOContextKey = "CustomHandleGroupManufacturingOrders_EditGroupMO";

        /// <summary>
        /// DEE context parameter indicating that the quantity is being updated from a palletize and not from native Change Quantity
        /// </summary>
        public const string CustomUnitCompleteHandlerUpdateGroupMOQuantityContextKey = "CustomUnitCompleteHandler_UpdateGroupMOQuantity";

        /// <summary>
        /// DEE context parameter indicating that the quantity is being updated from a overproduction and not from native Change Quantity
        /// </summary>
        public const string UpdateGroupMOPrimaryQuantityOverProductionContextKey = "UpdateGroupMOPrimaryQuantityOverProduction_UpdateQuantity";


        /// <summary>
        /// Context to know if a material stored ou attached to a feeder was shipped
        /// </summary>
        public const string CustomMaterialIsToShip = "CustomMaterialIsToShip";

        /// <summary>
        /// DEE context parameter saving the associated Printing Queue resources for each material
        /// </summary>
        public const string CustomAutomaticPrintingDocumentsRetrievePrintingResourcesContextKey = "CustomAutomaticPrintingDocuments_RetrievePrintingResourcesContextKey";

        /// <summary>
        /// DEE context parameter saving the associated Steps for each material before the operation is executed
        /// </summary>
        public const string CustomMaterialProcessingHandlerPreviousStepsByMaterialContextKey = "CustomMaterialProcessingHandler_PreviousStepsByMaterial";

        /// <summary>
        /// DEE context parameter saving the associated Resources for each material before the operation is executed
        /// </summary>
        public const string CustomMaterialProcessingHandlerResourcesByMaterialContextKey = "CustomMaterialProcessingHandler_ResourcesByMaterial";

        /// <summary>
        /// DEE context parameter to flag when not to send a BeginMaintenanceActivityOrdersInput Order, that was just created, to the ERP
        /// </summary>
        public const string CustomERPRequestMaintenanceSkipRequestsToERPContextKey = "CustomERPRequestMaintenance_SkipRequestsToERP";

        /// <summary>
        /// DEE context parameter that saves which materials are in which feeders before assembling, to check the iterations of materials in the same feeders
        /// </summary>
        public const string CustomMaterialAssembleReworkMaterialFeedersRelationContextKey = "CustomMaterialAssembleRework_MaterialFeedersRelation";

        /// <summary>
        /// DEE context parameter that saves the previous AutomationMode
        /// </summary>
        public const string CustomAutomationReleaseInterlockInitialAutomationModeContext = "CustomAutomationReleaseInterlock_InitialAutomationModeContext";

        /// <summary>
        /// DEE context parameter holding an HashSet of Ids of BOM Version Instances to be set as effective after a TrackIn is finalized
        /// </summary>
        public const string CustomRevertOriginalMaterialBOMVersionsAfterTrackInContextKey = "CustomRevertOriginalMaterialBOMVersionsAfterTrackIn";

        /// <summary>
        /// DEE Service context to identify if terminate alarm is from IoT
        /// </summary>
        public const string CustomTerminateAlarmFromAutomation = "TerminateAlarmFromAutomation";

        /// <summary>
        /// DEE Service context to identify Group MO Initial Shift Quantity
        /// </summary>
        public const string GmoInitialShiftQuantity = "GmoInitialShiftQuantity";

        /// <summary>
        /// DEE context parameter indicating that the abort process was started by a Stop Operation
        /// </summary>
        public const string DirectFeedingAbortByStopOperationContextKey = "AbortProcessStartedByStopOperation";

        /// <summary>
        /// DEE context parameter indicating the materials loaded for dispatch
        /// </summary>
        public const string CustomLoadMaterialsForDispatchContext = "CustomLoadMaterialsForDispatch";

        /// <summary>
        /// DEE action - CustomAddToPrintingQueueResource
        /// </summary>
        public const string CustomAddToPrintingQueueResource = "CustomAddToPrintingQueueResource";

        #endregion

        #region Localized Messages

        /// <summary>
        /// Verify if there is any certification about to expire.
        /// </summary>
        public const string CustomTimerDescriptionMessage = "CustomTimerDescriptionMessage";

        /// <summary>
        /// There are some Certifications that are about to expire!
        /// </summary>
        public const string CustomNotificationTitleForCertifications = "CustomNotificationTitleForCertifications";

        /// <summary>
        /// The Certification {0} will expire at {1} ({2} days remaining)
        /// </summary>
        public const string CustomNotificationDetailsForCertifications = "CustomNotificationDetailsForCertifications";

        /// <summary>
        /// Could not extract Process Segment from BOM {0}.
        /// </summary>
        public const string CustomValidateSetupCantFindProcessSegment = "CustomValidateSetupCantFindProcessSegment";

        /// <summary>
        /// Default Notification Severity not defined
        /// Message: Could not create Notification because there is no default Notification Severity defined in the configuration {0}.
        /// </summary>
        public const string CustomDefaultNotificationSeverityConfigNotDefined = "CustomDefaultNotificationSeverityConfigNotDefined";

        /// <summary>
        /// Default Notification Role not defined
        /// Message: Could not create Notification because there is no default Role defined in the configuration {0}.
        /// </summary>
        public const string CustomDefaultNotificationRoleConfigNotDefined = "CustomDefaultNotificationRoleConfigNotDefined";

        /// <summary>
        /// Service comments are mandatory. Please provide comments.
        /// </summary>
        public const string CustomMandatoryServiceCommentsMessage = "CustomMandatoryServiceCommentsMessage";

        #endregion

        #region Configuration

        /// <summary>
        /// Indicates if the feature to verify if there is a certification about to expired is enable or disable
        /// </summary>
        public const string CertificationExpirationNotificationEnable = "/Cmf/Custom/CertificationExpirationNotification/Enable";

        /// <summary>
        /// Indicates from when is it to notify (threshold in days)
        /// </summary>
        public const string CertificationExpirationNotification = "/Cmf/Custom/CertificationExpirationNotification/ThresholdInDays";

        /// <summary>
        /// Default Notification Severity
        /// </summary>
        public const string DefaultNotificationSeverityConfig = "/Cmf/Custom/Notifications/DefaultNotificationSeverity";

        /// <summary>
        /// Notification Alert Severity
        /// </summary>
        public const string NotificationAlertSeverity = "/Cmf/Custom/Notifications/NotificationAlertSeverity";

        /// <summary>
        /// Default Material transfer Notification Severity
        /// </summary>
        public const string DefaultMaterialTransferNotificationSeverityConfig = "/Cmf/Custom/Notifications/DefaultMaterialTransferNotificationSeverity";

        /// <summary>
        /// Default Forklift role
        /// </summary>
        public const string DefaultForkliftRoleConfig = "/Cmf/Custom/Forklift/DefaultRole";

        /// <summary>
        /// Configuration to handle offset between actual shift start and the time of DEE call
        /// </summary>
        public const string CustomShiftChangeOffsetTime = "/Cmf/Custom/Shift/CustomShiftChangeOffsetTime/";

        #endregion
    }
}
