﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Common
{
    public static partial class IKEAConstants
    {

        #region Attributes

        /// <summary>
        /// Custom attribute that holds the ERP OperationCode on short structures
        /// </summary>
        public const string CustomERPOperationCodeOverride = "ERPOperationCodeOverride";

        /// <summary>
        /// Custom attribute that holds the Default WorkCenter
        /// </summary>
        public const string CustomProductionOrderAttributeDefaultWorkCenter = "DefaultWorkCenter";

        /// <summary>
        /// Attribute describing the Reporting Warehouse of this Production Order
        /// </summary>
        public const string CustomProductionOrderAttributeReportingWarehouse = "ReportingWarehouse";

        /// <summary>
        /// Attribute describing the Structure Type of this Production Order
        /// </summary>
        public const string CustomProductionOrderAttributeStructureType = "StructureType";

        /// <summary>
        /// Attribute that indicates if product order is orderless
        /// </summary>
        public const string CustomProductionOrderIsOrderlessAttribute = "IsOrderless";

        #endregion

        #region Relations

        /// <summary>
        /// Custom PO Operation Resource EntityType - Relation
        /// </summary>
        public const string CustomPOOperationResource = "CustomPOOperationResource";

        /// <summary>
        /// Custom relation for a shared Feeder (Tank) - Relation
        /// </summary>
        public const string CustomResourceConsumptionProvider = "CustomResourceConsumptionProvider";

        #endregion

        #region Contexts

        /// <summary>
        /// DEE Context indicating that a PO is being canceled by ERP
        /// </summary>
        public const string ValidatePOStatusCancelingPO = "ValidatePOStatus_CancelingPO";

        #endregion

        #region Localized Messages

        /// <summary>
        /// Error message: Production Order {0} has no default flow path assigned.
        /// </summary>
        public const string CustomProductionOrderAutoCreateMOMaterial = "CustomProductionOrderAutoCreateMOMaterial";

        /// <summary>
        /// Localized Message to be displayed in a notification body - Auto Dispatch
        /// </summary>
        public const string CustomMaterialCouldNotBeAutoDispatched = "CustomMaterialCouldNotBeAutoDispatched";

        /// <summary>
        /// Localized Message to be displayed in a notification title - Auto Dispatch
        /// </summary>
        public const string CustomMaterialCouldNotBeAutoDispatchedTitle = "CustomMaterialCouldNotBeAutoDispatchedTitle";

        /// <summary>
        ///  Cannot terminate the Production Order since it still have materials associated.
        /// </summary>
        public const string CustomProductionOrderMaterialsAssociatedErrorMessage = "CustomProductionOrderMaterialsAssociatedErrorMessage";

		/// <summary>
		/// Localized Message title to be displayed in notification, when it's not possible to automatically dispatch material of Ad hoc order
		/// </summary>
		public const string CustomAdhocMaterialCouldNotBeAutomaticallyDispatchedTitle = "CustomAdhocMaterialCouldNotBeAutomaticallyDispatchedTitle";

		/// <summary>
		/// Localized Message to be displayed in notification, when it's not possible to automatically dispatch material of Ad hoc order
		/// The requested material {0} (system state: {1}) could not be automatically dispatched to resource {2} (system state: {3}).
		/// </summary>
		public const string CustomAdhocMaterialCouldNotBeAutomaticallyDispatched = "CustomAdhocMaterialCouldNotBeAutomaticallyDispatched";

		#endregion
	}
}
