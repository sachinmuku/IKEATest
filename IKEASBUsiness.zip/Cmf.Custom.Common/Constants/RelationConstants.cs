﻿namespace Cmf.Custom.IKEA.Common
{
    public static partial class IKEAConstants
    {

        #region Attributes

        /// <summary>
        /// CustomResourceConsumptionProvider Attribute. Indicates if the relation is enable or not
        /// </summary>
        public const string IsEnabledResourceConsumptionProvider = "IsEnabled";

        #endregion

        #region Entities Relations

        /// <summary>
        /// Resource ResourceService relation
        /// </summary>
        public const string ResourceResourceServiceRelation = "ResourceService";

        #endregion

    }
}
