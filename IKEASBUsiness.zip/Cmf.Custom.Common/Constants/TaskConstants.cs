﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Common
{
    public static partial class IKEAConstants
    {
        #region Attributes

        /// <summary>
        /// MaterialTransferFromArea attribute
        /// </summary>
        public const string CustomTaskAttributeTaskType = "TaskType";

        /// <summary>
        /// Indicates if the name of the logical chart that triggered this task
        /// </summary>
        public const string CustomTaskLogicalChartName = "LogicalChartName";

        #endregion
    }
}
