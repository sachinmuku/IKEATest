﻿namespace Cmf.Custom.IKEA.Common
{
    public static partial class IKEAConstants
    {

        #region Attributes

        /// <summary>
        /// Attribute that contains direct feeding mode
        /// </summary>
        public const string CustomMaterialAttributeDirectFeedingMode = "DirectFeedingMode";

        /// <summary>
        /// Attribute that contains Direct Feeding MO Counterpart
        /// </summary>
        public const string CustomMaterialAttributeDirectFeedingCounterPart = "DirectFeedingCounterPart";

        /// <summary>
        /// Attribute that contains the number of times a material was marked as rework
        /// </summary>
        public const string CustomMaterialAttributeReworkCounter = "ReworkCounter";

        /// <summary>
        /// Attribute that contains the number of times a material was been postponed
        /// </summary>
        public const string CustomMaterialAttributePostponeCount = "PostponeCount";

        /// <summary>
        /// Attribute that contains the base material
        /// </summary>
        public const string CustomMaterialAttributeBaseMaterial = "BaseMaterial";

        /// <summary>
        /// Indicates if the label or rfid has been printed
        /// </summary>
        public const string CustomIsRfidOrLabelPrinted = "IsRfidOrLabelPrinted";

        /// <summary>
        /// Flag that indicates if the consumption of the material was already reported to the ERP
        /// </summary>
        public const string CustomMaterialAttributeIsReported = "ERPIsConsumptionReported";

        /// <summary>
        /// Flag that indicates if material communication to ERP should not be made
        /// </summary>
        public const string CustomMaterialAttributeIsReportingBlocked = "ERPIsReportingBlocked";

        /// <summary>
        /// Attribute with Inventory Location for the Material
        /// </summary>
        public const string CustomMaterialAttributeERPInventoryLocation = "ERPInventoryLocation";

        /// <summary>
        /// Attribute with the Material ERP Original Name
        /// </summary>
        public const string CustomMaterialAttributeERPOriginalName = "ERPOriginalName";

        /// <summary>
        /// Attribute that contains the Area where the material was completed  
        /// </summary>
        public const string CustomMaterialAttributeCreationArea = "CreationArea";

        /// <summary>
        /// Attribute that contains the quantity completed on a Material 
        /// </summary>
        public const string CustomMaterialAttributeCompletedQuantity = "CompletedQuantity";

        /// <summary>
        /// If the material is an MO, this Attribute contains the number of pallets produced 
        /// </summary>
        public const string CustomMaterialAttributeProducedPallets = "ProducedPallets";

        /// <summary>
        /// If the material is an MO, this Attribute contains the number of pallets of types other than 'Good' produced 
        /// </summary>
        public const string CustomMaterialAttributeCompletedOutsortedQuantity = "CompletedOutsortedQuantity";

        /// <summary>
        /// Attribute that contains the message from PO downloaded to LineController status
        /// </summary>
        public const string CustomMaterialAttributeOrderDownloadMessage = "OrderDownloadMessage";

        /// <summary>
        /// Attribute that contains the status from PO downloaded to LineController
        /// </summary>
        public const string CustomMaterialAttributeOrderDownloadStatus = "OrderDownloadStatus";

        /// <summary>
        /// Attribute that indicates if a material is ready for production
        /// </summary>
        public const string CustomMaterialAttributeIsReadyForProduction = "IsReadyForProduction";

        /// <summary>
        /// Attribute that indicates if the creation of the pallet was already reported to ERP
        /// </summary>
        public const string CustomMaterialAttributeERPIsCreationReported = "ERPIsCreationReported";

        /// <summary>
        /// Attribute that indicates the active run of an MO or the run where the pallet was created
        /// </summary>
        public const string CustomMaterialAttributeOrderRunNumber = "OrderRunNumber";

        /// <summary>
        /// Attribute that indicates the initial track in of a Pallet
        /// </summary>
        public const string CustomMaterialAttributeInternalTrackInDate = "InternalTrackInDate";

        /// <summary>
        /// Attribute that indicates the last known ERP Operation Code of a material
        /// </summary>
        public const string CustomMaterialAttributeLastKnownERPOperation = "LastKnownERPOperation";

        /// <summary>
        /// Attribute that indicates if material can be reported to ERP
        /// </summary>
        public const string CustomMaterialAttributeERPBlockedMovementReport = "ERPBlockedMovementReport";

        /// <summary>
        /// Attribute InternalQualityCode 
        /// </summary>
        public const string CustomInternalQualityCode = "InternalQualityCode";

        /// <summary>
        /// Attribute InternalQualityCode 
        /// </summary>
        public const string CustomSourceConsumptionMaterial = "SourceConsumptionMaterial";

        /// <summary>
        /// Attribute that indicates the current known Outsorted quantity
        /// </summary>
        public const string CustomMaterialAttributeCurrentKnownOutsortedQuantity = "CurrentKnownOutsortedQuantity";

        /// <summary>
        /// Attribute that indicates the current processed Outsorted quantity
        /// </summary>
        public const string CustomMaterialAttributeCurrentProcessedOutsortedQuantity = "CurrentProcessedOutsortedQuantity";

        /// <summary>
        /// Attribute name that indicates the maximum quantity that can be completed in the palletization process
        /// </summary>
        public const string CustomMaterialAttributeDefaultCompletedQuantity = "DefaultCompletedQuantity";

        /// <summary>
        /// Attribute name that indicates the IsInLineDirectRepair flag
        /// </summary>
        public const string MaterialAttributeIsInLineDirectRepair = "IsInLineDirectRepair";

        /// <summary>
        /// Attribute name for the resource loss pieces classified on MO
        /// </summary>
        public const string CustomMaterialAttributeResourceLossPiecesClassified = "ResourceLossPiecesClassified";

        /// <summary>
        /// Attribute name for In Completion state of MO
        /// </summary>
        public const string CustomMaterialAttributeInCompletion = "InCompletion";

        /// <summary>
        /// Attribute name for ForceOrderCompletionAllowed that contains the stop reason linked to InCompletion attribute
        /// </summary>
        public const string CustomMaterialAttributeForceOrderCompletionAllowed = "ForceOrderCompletionAllowed";

        /// <summary>
        /// Attribute name for ProcessLossMotive attribute
        /// </summary>
        public const string CustomMaterialAttributeProcessLossMotive = "ProcessLossMotive";

        /// <summary>
        /// Attribute name for order target quantity
        /// </summary>
        public const string CustomMaterialAttributeOrderTargetQuantity = "OrderTargetQuantity";

        /// <summary>
        /// Attribute name that indicates if the material DirectRepair mode is set to Inline
        /// </summary>
        public const string CustomMaterialAttributeIsInLineDirectRepair = "IsInLineDirectRepair";

        /// <summary>
        /// Attribute name that indicates the number of iterations that the material will perform to complete a process
        /// </summary>
        public const string CustomMaterialAttributeMaxIterations = "MaxIterations";

        /// <summary>
        /// Attribute name for order target quantity
        /// </summary>
        public const string CustomMaterialAttributeCurrentIteration = "CurrentIteration";

        /// <summary>
        /// Attribute name keeping the original quantity at Trackin
        /// </summary>
        public const string CustomMaterialAttributeOriginalQuantity = "OriginalQuantity";

        /// <summary>
        /// Attribute that contains the Consumption Per Unit Produced Quantity
        /// </summary>
        public const string CustomMaterialAttributeConsumptionPerUnitProduced = "ConsumptionPerUnitProduced";

        /// <summary>
        /// Attribute that contains the Unit Load Label Pallet Type
        /// </summary>
        public const string CustomMaterialAttributeUnitLoadPalletType = "UnitLoadPalletType";

        /// <summary>
        /// Attribute that indicates that the material must increase the MO quantity if reattached to the line:
        /// </summary>
        public const string CustomMaterialAttributeIncreasesMOQuantity = "IncreasesMOQuantity";

        /// <summary>
        /// Attribute that indicates the minimum number of pallets to have in the feeder before notifying the operator:
        /// </summary>
        public const string CustomMaterialAttributeNumberOfPallets = "NumberOfPallets";

        /// <summary>
        /// Attribute that indicates if the manual completion is already in progress
        /// </summary>
        public const string CustomMaterialAttributeManualCompletionInProgress = "ManualCompletionInProgress";

        /// <summary>
        /// Attribute that indicates, when applicable, if any Checklist needs to be executed for Setup
        /// </summary>
        public const string CustomMaterialAttributeCheckListCorrectlySetup = "CheckListCorrectlySetup";

        /// <summary>
        /// Attribute that indicates, when applicable, if the consumables are validated for Setup
        /// </summary>
        public const string CustomMaterialAttributeConsumablesCorrectlySetup = "ConsumablesCorrectlySetup";

        /// <summary>
        /// Attribute that indicates, when applicable, if the durables are validated for Setup
        /// </summary>
        public const string CustomMaterialAttributeDurablesCorrectlySetup = "DurablesCorrectlySetup";

        /// <summary>
        /// Attribute that indicates, when applicable, if the Material is the Parent MO
        /// </summary>
        public const string CustomMaterialAttributeIsGroupMO = "IsGroupMO";

        /// <summary>
        /// Attribute that indicates the requested orders from ERP in the case of an optimized GroupMO
        /// </summary>
        public const string CustomGroupMOERPRequestedOrders = "ERPRequestedOrders";

        /// <summary>
        /// Attribute that indicate the state of group Material
        /// </summary>
        public const string CustomMaterialAttributeGroupOrderState = "GroupOrderState";

        /// <summary>
        /// Attribute that indicates the resource name for optimizer
        /// </summary>
        public const string CustomMaterialAttributeGroupOrderResource = "GroupOrderResource";

        /// <summary>
        /// Attribute that indicates if the Group MO is using the HPO
        /// </summary>
        public const string CustomMaterialAttributeGroupOrderHPOEnabled = "GroupOrderHPOEnabled";

        /// <summary>
        /// Attribute that contains the latest IoT Reported Quantity
        /// </summary>
        public const string CustomMaterialAttributeIoTReportedQuantity = "IoTReportedQuantity";

        /// <summary>
        /// Attribute that indicates if material is orderless
        /// </summary>
        public const string CustomMaterialIsOrderlessAttribute = "IsOrderless";

        /// <summary>
        /// Attribute that indicates the material ERP order name
        /// </summary>
        public const string CustomMaterialERPOrderNameAttribute = "ERPOrderName";

        /// <summary>
        /// Attribute that indicates the material Serial Shipping Container Code used to print it's label
        /// </summary>
        public const string CustomMaterialSSCCAttribute = "SSCC";

        /// Attribute that indicates the length of the material
        /// </summary>
        public const string CustomMaterialLengthAttribute = "Length";
        /// <summary>
        /// Attribute that indicates the width of the material
        /// </summary>
        public const string CustomMaterialWidthAttribute = "Width";
        /// <summary>
        /// Attribute that indicates the thickness of the material
        /// </summary>
        public const string CustomMaterialThicknessAttribute = "Thickness";
        /// <summary>
        /// Attribute that indicates the weight of the material
        /// </summary>
        public const string CustomMaterialWeightAttribute = "Weight";

        /// <summary>
        /// Attribute that contains the value of left-overs by cycle calculated by MES
        /// </summary>
        public const string CustomMaterialMESLeftOversByCycleAttribute = "MESLeftOversByCycle";

        /// <summary>
        /// Attribute that contains the MO used to report the left over to ERP
        /// </summary>
        public const string CustomMaterialMOReportLeftOverAttribute = "MOReportLeftOver";

        /// <summary>
        /// Attribute that contains the value of the initial shift quantity of CustomManufacturingOrderOutFeeder relation
        /// </summary>
        public const string CustomMaterialAttributeInitialShiftQuantity = "CustomInitialShiftQuantity";

        #endregion

        #region Localized Messages

        /// <summary>
        /// The material {0} can not leave the step {1} because there are defects that must be classified
        /// </summary>
        public const string CustomStepDefectsValidationLocalizedMessage = "CustomStepDefectsValidation";

        /// <summary>
        /// The material has already reach the maximum number of postpones allowed
        /// </summary>
        public const string CustomMaterialMaxAllowedPostponeLocalizedMessage = "CustomMaterialMaxAllowedPostpone";

        /// <summary>
        /// Only the materials in the first position of the dispatched list can be postponed
        /// </summary>
        public const string CustomMaterialNotAllowedPostponeLocalizedMessage = "CustomMaterialNotAllowedPostpone";

        /// <summary>
        /// Material cannot be postpone because there are no more materials dispatched in the resource
        /// </summary>
        public const string CustomMaterialPostponeNotEnoughMaterialsLocalizedMessage = "CustomMaterialPostponeNotEnoughMaterials";

        /// <summary>
        /// The material is not in the dispatched state
        /// </summary>
        public const string CustomMaterialNotInDispatchStateLocalizedMessage = "CustomMaterialNotInDispatchState";

        /// <summary>
        /// Configured start Flow {0} and Step {1} could not be used for {2} {3} since required Service {4} is not provided by the designated Resource {5}
        /// </summary>
        public const string CustomValidateFlowPathAtPreDispatchFlowPathNotChanged = "CustomValidateFlowPathAtPreDispatchFlowPathNotChanged";

        /// <summary>
        /// The {0} {1} was modified to start at Flow {2} and Step {3} in accordance with the resolved configuration
        /// </summary>
        public const string CustomValidateFlowPathAtPreDispatchFlowPathChanged = "CustomValidateFlowPathAtPreDispatchFlowPathChanged";

        /// <summary>
        /// The material(s) {0} can only be allocated to one Production Order
        /// </summary>
        public const string CustomValidateMaterialAllocationsMessage = "CustomValidateMaterialAllocationsMessage";

        /// <summary>
        /// Could not complete operation. The following problems were found: 
        /// </summary>
        public const string CustomValidateConsumablesTrackInMaterialCouldNotCompleteOperationLocalizedMessage = "CustomValidateConsumablesTrackInMaterialCouldNotCompleteOperation";

        /// <summary>
        /// Material {0} found in Resource {1} is not valid for the {2} {3}
        /// </summary>
        public const string CustomValidateConsumablesTrackInMaterialMaterialInErrorLocalizedMessage = "CustomValidateConsumablesTrackInMaterialMaterialInError";

        /// <summary>
        /// The following materials cannot be attached because they are not allocation to the Materials in progress: {0}.
        /// </summary>
        public const string CustomMaterialAllocationMaterialNotAllocatedLocalizedMessage = "CustomMaterialAllocationMaterialNotAllocated";

        /// <summary>
        /// The following materials are allocated to Production Orders that are not in progress in the current Resource: {0}.
        /// </summary>
        public const string CustomMaterialAllocationMaterialAllocatedInAnotherPOLocalizedMessage = "CustomMaterialAllocationMaterialAllocatedInAnotherPO";

        /// <summary>
        /// Label or RFID have not been print for the material {0}
        /// </summary>
        public const string CustomValidateIfLabelOrRfidPrinted = "CustomValidateIfLabelOrRfidPrinted";

        /// <summary>
        /// It's not possible to perform the move next operation because the materials type and step type are not defined as compatible
        /// </summary>
        public const string CustomValidateMaterialAndStepTypeAtMoveNext = "CustomValidateMaterialAndStepTypeAtMoveNext";

        /// <summary>
        /// The material {0} does not allow the consumption of the following types of the materials: {1}.
        /// </summary>
        public const string CustomMaterialTypesNotAllowedInMOLocalizedMessage = "CustomMaterialTypesNotAllowedInMO";

        /// <summary>
        /// The material {0} already exists and cannot be created.
        /// </summary>
        public const string CustomAutoMaterialCreationMaterialAlreadyExists = "CustomAutoMaterialCreateMaterialAlreadyExists";

        /// <summary>
        /// The Product {0} does not exist in MES.
        /// </summary>
        public const string CustomAutoMaterialCreationInvalidProduct = "CustomAutoMaterialCreationInvalidProduct";

        /// <summary>
        /// The Product {0} does not have DefaultUnits configured.
        /// </summary>
        public const string CustomAutoMaterialCreationInvalidProductDefaultUnits = "CustomAutoMaterialCreationInvalidProductDefaultUnits";

        /// <summary>
        /// It was not possible to find a FlowPath for the specified Resrouce: {0} or specified Facility: {1}, in the table CustomMaterialFlowResolution.
        /// </summary>
        public const string CustomAutoMaterialCreationFlowPathNotFound = "CustomAutoMaterialCreationFlowPathNotFound";

        /// <summary>
        /// The Token list is missing one of the settings: {0}, {1} or {2}. Please check the generic table CustomScanningConfigurationToken.
        /// </summary>
        public const string CustomAutoMaterialCreationInvalidTokenList = "CustomAutoMaterialCreationInvalidTokenList";

        /// <summary>
        /// The MES Configuration is missing one of the entries: {0} or {1}.
        /// </summary>
        public const string CustomAutoMaterialCreationInvalidConfiguration = "CustomAutoMaterialCreationInvalidConfiguration";

        /// <summary>
        ///  Material {0} of Product {1} with Quantity {2} was successfully created!
        /// </summary>
        public const string CustomAutoMaterialCreationSuccessMessage = "CustomAutoMaterialCreationSuccessMessage";

        /// <summary>
        /// Cannot perform record loss for secondary unit {0} in material {1}, because this unit is configured to store the loss quantity in this material.
        /// </summary>
        public const string CustomMaterialLossSetRejectQuantityError = "CustomMaterialLossSetRejectQuantityError";

        /// <summary>
        /// Missing Token '{0}' in Token list
        /// </summary>
        public const string CustomAutoMaterialCreationTokenNotFound = "CustomAutoMaterialCreationTokenNotFound";

        /// <summary>
        /// Invalid data in Token '{0}'
        /// </summary>
        public const string CustomAutoMaterialCreationInvalidToken = "CustomAutoMaterialCreationInvalidToken";

        /// <summary>
        /// {0} {1} cannot be started because its checklist has not been completed.
        /// </summary>
        public const string CustomStartMaterialActiveLongRunningChecklistLocalizedMessage = "CustomStartMaterialActiveLongRunningChecklist";

        /// <summary>
        /// {0} {1} cannot be started as it is not ready for Production. Please ensure that all tool changes are performed, consumables attached and checklists are performed.
        /// </summary>
        public const string CustomStartMaterialNotReadyForProductionMessage = "CustomStartMaterialNotReadyForProduction";

        /// <summary>
        /// {0} {1} is not in Setup mode
        /// </summary>
        public const string CustomStartMaterialNotSetupStateLocalizedMessage = "CustomStartMaterialNotSetupState";

        /// <summary>
        /// The resource {0} is not Online.
        /// </summary>
        public const string CustomStartMaterialResourceNotOnlineLocalizedMessage = "CustomStartMaterialResourceNotOnline";

        /// <summary>
        /// {0} {1} cannot be started manually because {2} is under automation control.
        /// </summary>
        public const string CustomStartMaterialManualStartNotAllowedLocalizedMessage = "CustomStartMaterialManualStartNotAllowed";

        /// <summary>
        /// Completion of {0} {1} cannot be performed manually since {2} is under automation control.
        /// </summary>
        public const string CustomTrackoutMaterialManualStartNotAllowed = "CustomTrackoutMaterialManualStartNotAllowed";

        /// <summary>
        /// Completion of {0} {1} cannot be performed automatically since {2} is under manual control.
        /// </summary>
        public const string CustomTrackoutMaterialAutomaticStartNotAllowed = "CustomTrackoutMaterialAutomaticStartNotAllowed";

        /// <summary>
        /// Cannot change the material state model to {0} because the material system state is {1}.
        /// </summary>
        public const string CustomValidateMaterialStateModelChangeNotAllowed = "CustomValidateMaterialStateModelChangeNotAllowed";

        /// <summary>
        /// Cannot create Batch Material. Default {0} is not defined in the config {1}.
        /// </summary>
        public const string CustomCreateBatchConfigNotDefinedLocalizedMessage = "CustomCreateBatchConfigNotDefinedLocalizedMessage";

        /// <summary>
        /// Cannot create Batch Material. Default FlowPath defined in the config {0} is not a valid FlowPath.
        /// </summary>
        public const string CustomCreateBatchInvalidFlowPathLocalizedMessage = "CustomCreateBatchInvalidFlowPathLocalizedMessage";

        /// <summary>
        /// The Material cannot be dipatched. The Workcenters of the PO '{0}' and the Resource '{1}' do not match.
        /// </summary>
        public const string CustomValidateResourceWorkCenterWorkCentersDoNotMatchLocalizedMessage = "CustomValidateResourceWorkCenterWorkCentersDoNotMatch";

        /// <summary>
        /// No resource with the process segment {0} was found.
        /// </summary>
        public const string CustomPerformAutomaticAssembleCantFindResource = "CustomPerformAutomaticAssembleCantFindResource";

        /// <summary>
        /// There is not enough quantity to consume in {0} (BOM Sequence: {1}, Process Segment: {2}, SubProcessSegment: {3}) to fulfill the assemble operation. Required Quantity: {4} {5}. Actual Quantity: {6} {5}.
        /// </summary>
        public const string CustomPerformAutomaticAssembleNotEnoughQuantity = "CustomPerformAutomaticAssembleNotEnoughQuantity";

        /// <summary>
        /// Material {0} is not setup correctly.
        /// </summary>
        public const string CustomMaterialNotCorrectlySetup = "CustomMaterialNotCorrectlySetup";

        /// <summary>
        /// Cannot move {0} quantities into split materials. 
        /// </summary>
        public const string CustomSplitRejectUnitErrorMessage = "CustomSplitRejectUnitErrorMessage";

        /// <summary>
        /// The {0} {1} cannot be consumed because the resource with Process Segment {2} and Sub Process Segment {3} does not match the BOM configuration.
        /// </summary>
        public const string CustomAssembleDirectConsumptionMismatchBOMProductLocalizedMessage = "CustomAssembleDirectConsumptionMismatchBOMProduct";

        /// <summary>
        /// The material change type from '{0}' to '{1}' is not possible.
        /// </summary>
        public const string CustomMaterialChangeTypeTransitionIsNotPossibleLocalizedMessage = "CustomMaterialChangeTypeTransitionIsNotPossible";

        /// <summary>
        /// It is not possible to generate a new material with a total quantity of zero units..
        /// </summary>
        public const string CustomMaterialZeroQuantityNotPossibleLocalizedMessage = "CustomMaterialZeroQuantityNotPossible";

        /// <summary>
        /// It is not possible to split a material with zero quantity.
        /// </summary>
        public const string CustomMaterialZeroQuantitySplitNotPossibleLocalizedMessage = "CustomMaterialZeroQuantitySplitNotPossible";

        /// <summary>
        /// It is not possible to split a material that is attached to an automatic consumable feed.
        /// </summary>
        public const string CustomConsumableFeedMaterialSplitNotPossibleLocalizedMessage = "CustomConsumableFeedMaterialSplitNotPossible";

        /// <summary>
        /// {0} was generated with Form {1} and Primary Quantity {2}
        /// </summary>
        public const string CustomMaterialSplitCreatedNewMaterial = "CustomMaterialSplitCreatedNewMaterial";

        /// <summary>
        /// The {0} {1} cannot be consumed because it's not attached to the resource with Process Segment {2} and Sub Process Segment {3}.
        /// </summary>
        public const string CustomAssembleDirectConsumptionWrongMaterialToConsumeLocalizedMessage = "CustomAssembleDirectConsumptionWrongMaterialToConsume";

        /// <summary>
        /// Cannot perform dispatch because no Resources with State: Up are available
        /// </summary>
        public const string CustomNoResourcesUpAvailable = "CustomNoResourcesUpAvailable";

        /// <summary>
        /// The material {0} does not exist.
        /// </summary>
        /// <remarks>
        ///     {0} - Material Name
        /// </remarks>
        public const string MaterialDoesNotExist = "MaterialDoesNotExist";

        /// <summary>
        /// A manual completion request is already in progress for the {0} {1}.
        /// <remarks>
        ///     {0} - Material Form
        ///     {1} - Material Name
        /// </remarks>
        /// </summary>
        public const string CustomForceUnitCompletionManualCompletionRequestedLocalizedMessage = "CustomForceUnitCompletionManualCompletionRequested";

        /// <summary>
        /// It is not possible to attach the material. The material '{0}' is already attached to a different Resource: '{1}'.
        /// </summary>
        public const string CustomMaterialAlreadyAttachedToDifferentResourceLocalizedMessage = "CustomMaterialAlreadyAttachedToDifferentResource";

        /// <summary>
        /// It was not possible to determine the correct Order for the material '{0}'.
        /// </summary>
        public const string CustomNotPossibleToDetermineMaterialOrderQueueLocalizedMessage = "CustomNotPossibleToDetermineMaterialOrderQueue";

        /// <summary>
        /// It was not possible to send the updated queue list to the IOT layer.
        /// </summary>
        public const string CustomNotPossibleToSendQueueListToIOTLocalizedMessage = "CustomNotPossibleToSendQueueListToIOT";

        /// <summary>
        /// A new Outsorting Pallet will be created.
        /// </summary>
        public const string CustomNewOutsortingPalletWillBeCreatedLocalizedMessage = "CustomNewOutsortingPalletWillBeCreated";

        /// <summary>
        /// A MO that belongs to a Group MO cannot be aborted!
        /// </summary>
        public const string CustomGroupMOChildCannotBeAbortedLocalizedMessage = "CustomGroupMOChildCannotBeAborted";

        /// <summary>
        /// It is not possible to dispatch an MO that belongs to a group.
        /// </summary>
        public const string CustomGroupMOChildCannotBeDispatchedLocalizedMessage = "CustomGroupMOChildCannotBeDispatched";

        /// <summary>
        /// It is not possible to undispatch an MO that belongs to a group.
        /// </summary>
        public const string CustomGroupMOChildCannotBeUndispatchedLocalizedMessage = "CustomGroupMOChildCannotBeUndispatched";

        /// <summary>
        ///The operation '{0}' cannot be executed on a MO material that belongs to a group
        /// </summary>
        public const string CustomGroupMOUnsupportedMESOperationLocalizedMessage = "CustomGroupMOUnsupportedMESOperation";

        /// <summary>
        /// the number of cycles must be greater than zero
        /// </summary>
        public const string CustomGroupMOCompletionNumberOfCyclesGreaterThanZeroLocalizedMessage = "CustomGroupMODefaultCompletionNumberOfCyclesGreatedThanZero";

        /// <summary>
        /// A group has to have at least two members
        /// </summary>
        public const string CustomAtLeastTwoMembersInGroupMOLocalizedMessage = "CustomAtLeastTwoMembersInGroupMO";

        /// <summary>
        /// A group has to have at least one member for HPO Line
        /// </summary>
        public const string CustomAtLeastOneMemberInGroupMOForHPOLocalizedMessage = "CustomAtLeastOneMemberInGroupMOForHPO";

        /// <summary>
        /// The material {0} is already linked to a group.
        /// </summary>
        public const string CustomMaterialAlreadyInGroupMOLocalizedMessage = "CustomMaterialAlreadyInGroupMO";

        /// <summary>
        /// The material {0} is a Group MO.
        /// </summary>
        public const string CustomMaterialIsGroupMOLocalizedMessage = "CustomMaterialIsGroupMO";

        /// <summary>
        /// Group Order cannot be dispatched to this resource because it requires optimization, while the configured one does not.
        /// </summary>
        public const string CustomMaterialGroupMOResourceOptimizationMismatchLocalizedMessage = "CustomMaterialGroupMOResourceOptimizationMismatch";

        /// <summary>
        /// Group Order cannot be dispatched to a different resource than the configured one.
        /// </summary>
        public const string CustomMaterialGroupMOResourceMismatchLocalizedMessage = "CustomMaterialGroupMOResourceMismatch";

        /// <summary>
        /// The given orders in NCL file have different group MOs.
        /// </summary>
        public const string CustomMaterialDifferentsGroupMOLocalizedMessage = "CustomMaterialDifferentsGroupMO";

        /// <summary>
        /// The group MO does not exist.
        /// </summary>
        public const string CustomMaterialGroupMODontExistLocalizedMessage = "CustomMaterialGroupMODontExist";

        /// <summary>
        /// Group Order cannot be dispatched to this recource until it is ready.
        /// </summary>
        public const string CustomMaterialGroupMOWrongDispatchStateLocalizedMessage = "CustomMaterialGroupMOWrongDispatchState";

        /// <summary>
        /// Group Order {0} cannot be TrackedIn in state {1}, must be Ready instead.
        /// </summary>
        public const string CustomMaterialGroupMOWrongTrackInStateLocalizedMessage = "CustomMaterialGroupMOWrongTrackInState";

        /// <summary>
        /// Only Optimized Group Orders can be dispatched to this resource.
        /// </summary>
        public const string CustomMaterialMustBeGroupMOLocalizedMessage = "CustomMaterialMustBeGroupMO";

        /// <summary>
        /// Could not find a BOM associated with child MO {0} to send to the optimizer.
        /// </summary>
        public const string CustomMaterialNoBomForOptimizerLocalizedMessage = "CustomMaterialNoBomForOptimizer";

        /// <summary>
        /// Could not find Production Order associated with child MO {0} to send to the optimizer.
        /// </summary>
        public const string CustomMaterialNoProductionOrderForOptimizerLocalizedMessage = "CustomMaterialNoProductionOrderForOptimizer";

        /// <summary>
        /// Could not find raw material product to send to the optimizer in child MO {0}.
        /// </summary>
        public const string CustomMaterialNoSourceProductForOptimizerLocalizedMessage = "CustomMaterialNoSourceProductForOptimizer";

        /// <summary>
        /// Child Manufacturing Order {0} has different source product {1}, expected {2}.
        /// </summary>
        public const string CustomMaterialDifferentSourceProductsOptimizerLocalizedMessage = "CustomMaterialDifferentSourceProductsOptimizer";

        /// <summary>
        /// Cannot create HPO importer file because there already exists one for this order at {0}.
        /// </summary>
        public const string CustomMaterialFileAlreadyExistsOptimizerLocalizedMessage = "CustomMaterialFileAlreadyExistsOptimizer";

        /// <summary>
        /// The parts per cycle is higher than the quantity order
        /// </summary>
        public const string CustomPartsPerCycleLargerThanOrderQuantityLocalizedMessage = "CustomPartsPerCycleLargerThanOrderQuantity";

        /// <summary>
        /// The quantities and parts per cycle are not compatible with the chosen pattern.
        /// </summary>
        public const string CustomPartsPerCycleNotCompatibleWithPatternLocalizedMessage = "CustomPartsPerCycleNotCompatibleWithPattern";

        /// <summary>
        /// The material {0} is not in Queued state.
        /// </summary>
        public const string CustomMaterialNotQueuedGroupMOLocalizedMessage = "CustomMaterialNotQueuedGroupMO";

        /// <summary>
        /// All flow paths of child material products should be identical.
        /// </summary>
        public const string CustomDifferentChildFlowPathProductGroupMOLocalizedMessage = "CustomDifferentChildFlowPathProductGroupMO";

        /// <summary>
        /// All attribute IsOrderless of child material products should be identical.
        /// </summary>
        public const string CustomDifferentChildOrderlessAttributeLocalizedMessage = "CustomDifferentChildOrderlessAttribute";

        /// <summary>
        /// Resource {0} does not have any printing queue configured.
        /// </summary>
        public const string CustomNoPrintingQueueConfiguredForResourceLocalizedMessage = "CustomNoPrintingQueueConfiguredForResource";

        /// <summary>
        /// There is no material in the printing queue of resource {0}.
        /// </summary>
        public const string CustomNoMaterialInPrintingQueueLocalizedMessage = "CustomNoMaterialInPrintingQueue";

        /// <summary>
        /// Material {0} is already in printing queue.
        /// </summary>
        public const string CustomMaterialAlreadyInPrintingQueueLocalizedMessage = "CustomMaterialAlreadyInPrintingQueue";

        /// <summary>
        /// Expected material {0} to be removed from the printing queue, but the last material is {1}.
        /// </summary>
        public const string CustomUnexpectedMaterialRemovedFromPrintingQueueLocalizedMessage = "CustomUnexpectedMaterialRemovedFromPrintingQueue";

        /// <summary>
        /// Cannot add a material processed in resource {0} to the printing queue of {1}.
        /// </summary>
        public const string CustomProcessedResourceNoMatchPrintingQueueLocalizedMessage = "CustomProcessedResourceNoMatchPrintingQueue";

        /// <summary>
        /// Material form should be {0} to be added to the printing queue, but is {1} instead.
        /// </summary>
        public const string CustomMaterialFormNotCompletedForPrintingQueueLocalizedMessage = "CustomMaterialFormNotCompletedForPrintingQueue";

        /// <summary>
        /// The product being attached is not compatible with the ones that already exist in the distributed feeder group.
        /// </summary>
        public const string CustomDistributedConsumptionIncompatibleProductLocalizedMessage = "CustomDistributedConsumptionIncompatibleProduct";

        /// <summary>
        /// One of the feeders being enabled, has a product that is different that the ones that already exist in the distributed feeder group.
        /// </summary>
        public const string CustomDistributedConsumptionAddFeederIncompatibleProductLocalizedMessage = "CustomDistributedConsumptionAddFeederIncompatibleProduct";

        /// <summary>
        /// The group MO has an invalid system State to be terminated
        /// </summary>
        public const string CustomTerminateInvalidGroupMOSystemStateLocalizedMessage = "CustomTerminateInvalidGroupMOSystemState";

        /// <summary>
        /// The group MO has an invalid group order State to be terminated
        /// </summary>
        public const string CustomTerminateInvalidGroupOrderStateLocalizedMessage = "CustomTerminateInvalidGroupOrderState";

        /// <summary>
        /// The group MO has an invalid group order State to be updated
        /// </summary>
        public const string CustomUpdateInvalidGroupOrderStateLocalizedMessage = "CustomUpdateInvalidGroupOrderState";

        /// <summary>
        /// Enabling HPO for Group MOs is mandatory on this resource.
        /// </summary>
        public const string CustomGroupOrderRequiredHPOLocalizedMessage = "CustomGroupOrderRequiredHPO";

        /// <summary>
        /// Group MO : {0} is ready to be dispatched.
        /// </summary>
        public const string CustomGroupOrderReadyNotificationTitleLocalizedMessage = "CustomGroupOrderReadyNotificationTitle";

        /// <summary>
        /// All MOs for the group MO {0} have been created. The group MO is ready to be dispatched.
        /// </summary>
        public const string CustomGroupOrderReadyNotificationDetailLocalizedMessage = "CustomGroupOrderReadyNotificationDetail";


        /// <summary>
        /// Multiple Orders Pallet Out mode is not compatible with the given order: GroupMO has no sub-orders
        /// </summary>
        public const string CustomMultiplePalletOutGroupMOHasNoSubOrdersMessage = "CustomMultiplePalletOutGroupMOHasNoSubOrdersMessage";

        /// <summary>
        /// Multiple Orders Pallet Out mode is not compatible with the given order: order is not a group MO
        /// </summary>
        public const string CustomMultiplePalletOutOrderNotGroupMOMessage = "CustomMultiplePalletOutOrderNotGroupMOMessage";

        /// <summary>
        /// The expiration date is mandatory
        /// </summary>
        public const string CustomMaterialExpirationDateIsMandatoryLocalizedMessage = "CustomMaterialExpirationDateIsMandatory";

        /// Attached
        /// </summary>
        public const string CustomSetupViewIoTPalletStatusAttachedMessage = "CustomSetupViewIoTPalletStatusAttached";

        /// <summary>
        /// Process
        /// </summary>
        public const string CustomSetupViewIoTPalletStatusProcessMessage = "CustomSetupViewIoTPalletStatusProcess";

        /// <summary>
        /// Finished
        /// </summary>
        public const string CustomSetupViewIoTPalletStatusFinishedMessage = "CustomSetupViewIoTPalletStatusFinished";

        /// <summary>
        /// The Default Completion Quantity value cannot be less than {0}.
        /// </summary>
        public const string CustomInvalidNegativeDefaultCompletionQuantityLocalizedMessage = "CustomInvalidNegativeDefaultCompletionQuantity";

        /// <summary>
        /// Changing the Default Completion Quantity of a material expects System State to be {0}, got {1} instead.
        /// </summary>
        public const string CustomChangeDefaultCompletionQuantityInvalidSystemStateLocalizedMessage = "CustomChangeDefaultCompletionQuantityInvalidSystemState";

        /// <summary>
        /// The new Default Completion Quantity should be greater than or equal to the quantity already on the pallet.
        /// </summary>
        public const string CustomChangeDefaultCompletionQuantityTooSmallLocalizedMessage = "CustomChangeDefaultCompletionQuantityTooSmall";

        /// <summary>
        /// Invalid Resource, {0} has dispatched regular orders.
        /// </summary>
        public const string CustomCanProcessOrderlessLocalizedMessage = "CustomCanProcessOrderless";

        /// <summary>
        /// Cannot update the MO {0}, because it is not orderless.
        /// </summary>
        public const string CustomCannotUpdateNotOrderlessLocalizedMessage = "CustomCannotUpdateNotOrderless";

        /// <summary>
        /// Cannot update the MO {0}, because it is not a Group Order.
        /// </summary>
        public const string CustomCannotUpdateOrderlessNotGroupOrderLocalizedMessage = "CustomCannotUpdateOrderlessNotGroupOrder";

        /// <summary>
        /// Cannot update the MO {0}, because it's GroupOrderState should be {1}, but is {2} instead.
        /// </summary>
        public const string CustomCannotUpdateGroupOrderInvalidStateLocalizedMessage = "CustomCannotUpdateGroupOrderInvalidState";

        /// <summary>
        /// Cannot set the BOM of child order {0}, because it is not a child of the group order {1}.
        /// </summary>
        public const string CustomCannotUpdateOrderlessBOMNotChildOfGroupLocalizedMessage = "CustomCannotUpdateOrderlessBOMNotChildOfGroup";

        /// <summary>
        /// Cannot set the BOM of child order {0} to {1}, because it is already associated with {2}.
        /// </summary>
        public const string CustomCannotUpdateOrderlessBOMAlreadySetLocalizedMessage = "CustomCannotUpdateOrderlessBOMAlreadySet";

        /// <summary>
        /// {0} is not in the list ProductionOrderType
        /// </summary>
        public const string CustomOrderlessIsNotOnProductionOrderTypeMessage = "CustomOrderlessIsNotOnProductionOrderType";

        /// <summary>
        /// {0} cannot be dispatched. Resource has materials with mistmatched orderless attribute.
        /// </summary>
        public const string CustomMOOrderlessCannotBeDispatchedMessage = "CustomMOOrderlessCannotBeDispatchedMessage";

        /// <summary>
        /// {0} cannot be converted into {1}. Please check Unit Conversion Factor Generic Table.
        /// </summary>
        public const string CustomUnitsAndConversionFactorsNotDefinedLocalizedMessage = "CustomUnitsAndConversionFactorsNotDefined";

        /// <summary>
        /// All child MOs must have the same units of measure
        /// </summary>
        public const string CustomChildMOsDifferentUnitsOfMeasureMessage = "CustomChildMOsDifferentUnitsOfMeasure";

        /// <summary>
        /// Cannot assemble material {0}, because Feeder {1}'s materials ({2}) have different current iterations ({3}).
        /// </summary>
        public const string CustomCustomAssembleIterationsDifferentMessageLocalizedMessage = "CustomAssembleIterationsDifferentMessage";

        /// <summary>
        /// Cannot use an alternative ideal cycle time for material {0} in Resource {1}, no rows that apply to it were found on smart table {2}.
        /// </summary>
        public const string CustomCannotSetAlternativeCycleTimeNoRowsFoundLocalizedMessage = "CustomCannotSetAlternativeCycleTimeNoRowsFound";

        /// <summary>
        /// Combination of material {0} and Resource {1} require an alternative ideal cycle time, but no such time is configured for this order's structure type.
        /// </summary>
        public const string CustomRequiredAlternativeIdealCycleTimeNoMatchForStructureTypeLocalizedMessage = "CustomRequiredAlternativeIdealCycleTimeNoMatchForStructureType";

        /// <summary>
        /// Combination of material {0} and Resource {1} conflict with the ideal cycle time of orders {2}, which are already in process.
        /// </summary>
        public const string CustomRequiredAlternativeIdealCycleTimeConflictsWithInProcessOrdersLocalizedMessage = "CustomRequiredAlternativeIdealCycleTimeConflictsWithInProcessOrders";

        /// <summary>
        /// Combination of material {0} and Resource {1} conflicts with the ideal cycle time of another order being tracked in as well.
        /// </summary>
        public const string CustomRequiredAlternativeIdealCycleTimeConflictsWithTrackInOrderLocalizedMessage = "CustomRequiredAlternativeIdealCycleTimeConflictsWithTrackInOrder";

        /// <summary>
        /// A palletization resource must be chosen
        /// </summary>
        public const string CustomRequiredPalletizeResourceManualOutsortGroupMO = "CustomRequiredPalletizeResourceManualOutsortGroupMO";

        /// <summary>
        /// CustomMaterialProcessingHandler - Exception
        /// Cannot find resource to attach for material {0}, it doesn't exist or isn't correctly configured on smart table CustomMaterialMovementConfiguration
        /// </summary>
        public const string CustomMaterialProcessingHandlerResourceToAttachException = "CustomMaterialProcessingHandlerResourceToAttachException";

        /// <summary>
        /// CustomMaterialProcessingHandler - Exception
        /// Cannot find resolve flow path for material {0}, isn't correctly configured on smart table CustomMaterialFlowResolution.
        /// </summary>
        public const string CustomMaterialProcessingHandlerFlowPathException = "CustomMaterialProcessingHandlerFlowPathException";

        /// <summary>
        /// CustomScanSubstituteProductFromSFG - Exception
        /// Cannot create a new material for a substitute product of a Semi-Finished Good. BOMs: {0}.
        /// </summary>
        public const string CustomScanSubstituteProductFromSFG = "CustomScanSubstituteProductFromSFG";

        /// <summary>
        /// CustomOrderCouldNotBeRetrievedFromConsumable - Exception
        /// Could not retrieve order in process with attached consumable '{0}'.
        /// </summary>
        public const string CustomOrderCouldNotBeRetrievedFromConsumable = "CustomOrderCouldNotBeRetrievedFromConsumable";

        /// <summary>
        /// Cannot create batch {0}, pallet material with the same name already exists in the system.
        /// </summary>
        public const string CustomBatchCreationFailedPalletExistsWithSameNameLocalizedMessage = "CustomBatchCreationFailedPalletExistsWithSameName";

        #region ForceOrderCompletion

        /// <summary>
        /// Cannot complete Force Order {0}, because the System State of Order Material {1} should be {2}, but it is {3} instead.
        /// </summary>
        /// <remarks>
        ///     {0} - Force Order Type
        ///     {1} - Material Name
        ///     {2} - Expected Material System State
        ///     {3} - Material System State
        /// </remarks>
        public const string CustomForceOrderCompletionInvalidMaterialSystemStateLocalizedMessage = "CustomForceOrderCompletionInvalidMaterialSystemState";

        /// <summary>
        /// Cannot complete Force Order {0}, because the Form of Order Material {1} should be {2}, but it is {3} instead.
        /// </summary>
        /// <remarks>
        ///     {0} - Force Order Type
        ///     {1} - Material Name
        ///     {2} - Expected Material Form
        ///     {3} - Material Form
        /// </remarks>
        public const string CustomForceOrderCompletionInvalidMaterialFormStateLocalizedMessage = "CustomForceOrderCompletionInvalidMaterialFormState";

        /// <summary>
        /// Cannot complete Force Order {0}, because the Current State of Order Material {1} should be {2}, but it is {3} instead.
        /// </summary>
        /// <remarks>
        ///     {0} - Force Order Type
        ///     {1} - Material Name
        ///     {2} - Expected Material Current State
        ///     {3} - Material Current State
        /// </remarks>
        public const string CustomForceOrderCompletionInvalidMaterialStateModelLocalizedMessage = "CustomForceOrderCompletionInvalidMaterialStateModel";

        /// <summary>
        /// Cannot complete Force Order {0}, because the Attribute {1} of Order Material {2} should be {3}, but it is {4} instead.
        /// </summary>
        /// <remarks>
        ///     {0] - Type of Force Order
        ///     {1} - Attribute Name
        ///     {2} - Material Name
        ///     {3} - Expected Material Attribute Value
        ///     {4} - Material Attribute Value
        /// </remarks>
        public const string CustomForceOrderCompletionInvalidMaterialAttributeValueLocalizedMessage = "CustomForceOrderCompletionInvalidMaterialAttributeValue";

        /// <summary>
        /// Cannot complete Force Order {0}, because the Automation Mode of the Process Resource {1} should be {2}, but it is {3} instead.
        /// </summary>
        /// <remarks>
        ///     {0} - Force Order Type
        ///     {1} - Resource Name
        ///     {2} - Expected Resource Automation Value
        ///     {3} - Resource Automation Value
        /// </remarks>
        public const string CustomForceOrderCompletionInvalidResourceAutomationModeLocalizedMessage = "CustomForceOrderCompletionInvalidResourceAutomationMode";

        /// <summary>
        /// Cannot complete Force Order {0}, because the Process Resource {1} has no Automation Controller Instance available.
        /// </summary>
        /// <remarks>
        ///     {0} - Force Order Type
        ///     {1} - Resource Name
        /// </remarks>
        public const string CustomForceOrderCompletionInvalidResourceMissingControllerInstanceLocalizedMessage = "CustomForceOrderCompletionInvalidResourceMissingControllerInstance";

        /// <summary>
        /// Cannot complete Force Order {0}, because the IoT Automation Instance Controller {1} has returned an error.
        /// </summary>
        /// <remarks>
        ///     {0} - Force Order Type
        ///     {1} - Resource Name
        /// </remarks>
        public const string CustomForceOrderCompletionInvalidResourceControllerInstanceErrorLocalizedMessage = "CustomForceOrderCompletionInvalidResourceControllerInstanceError";

        #endregion

        #region Material Transfer

        /// <summary>
        /// Area
        /// </summary>
        public const string CustomMaterialTransferAreaTokenNameLocalizedMessage = "CustomMaterialTransferAreaTokenName";

        /// <summary>
        /// Location
        /// </summary>
        public const string CustomMaterialTransferLocationTokenNameLocalizedMessage = "CustomMaterialTransferLocationTokenName";

        /// <summary>
        /// Facility
        /// </summary>
        public const string CustomMaterialTransferFacilityTokenNameLocalizedMessage = "CustomMaterialTransferFacilityTokenName";

        /// <summary>
        /// Product
        /// </summary>
        public const string CustomMaterialTransferProductTokenNameLocalizedMessage = "CustomMaterialTransferProductTokenName";

        /// <summary>
        /// Quantity
        /// </summary>
        public const string CustomMaterialTransferQuantityTokenNameLocalizedMessage = "CustomMaterialTransferQuantityTokenName";

        /// <summary>
        /// Please move {0} {1} at {2} to {3}
        /// </summary>
        /// <remarks>
        ///     {0} - Material.Form
        ///     {1} - Material.Name
        ///     {2} - PreBuilt Source location information
        ///     {3} - PreBuild Target Location information
        /// </remarks>
        public const string CustomMaterialTransferMovementRequestMaterialMovementMessageLocalizedMessage = "CustomMaterialTransferMovementRequestMaterialMovementMessage";

        /// <summary>
        /// Please move {0} {1} to {2}
        /// </summary>
        /// <remarks>
        ///     {0} - MaterialTransferQuantity
        ///     {1} - MaterialTransferProduct.DefaultUnits
        ///     {2} - PreBuilt Target location information
        /// </remarks>
        public const string CustomMaterialTransferMovementRequestMaterialReplenishmentMessageLocalizedMessage = "CustomMaterialTransferMovementRequestMaterialReplenishmentMessage";

        /// <summary>
        /// Material Transfer Request
        /// </summary>
        public const string CustomMaterialTransferMovementRequestNotificationTitleLocalizedMessage = "CustomMaterialTransferMovementRequestNotificationTitle";

        /// <summary>
        /// The requested quantity {0} surpasses the allowed quantity {1} for {2} {3}.
        /// </summary>
        /// <remarks>
        ///     {0} - Requested quantity
        ///     {1} - Primary quantity in the material
        ///     {2} - Form of the material
        ///     {3} - Material name
        /// </remarks>
        public const string CustomMaterialTransferMovementInsufficientQuantityLocalizedMessage = "CustomMaterialTransferMovementInsufficientQuantity";


        /// <summary>
        /// The inserted quantity of {0} for material {1} is not allowed.
        /// </summary>
        /// <remarks>
        ///     {0} - Inserted quantity
        ///     {1} - Material name
        /// </remarks>
        public const string CustomMaterialTransferMovementInvalidQuantity = "CustomMaterialTransferMovementInvalidQuantity";

        /// <summary>
        /// The following materials to merge do not match either the type, form, iteration or area where generated of the material being transfered: {0}.
        /// </summary>
        /// <remarks>
        ///     {0} - Name of the materials that do no match
        /// </remarks>
        public const string CustomMaterialTransferInvalidMergeMaterialsLocalizedMessage = "CustomMaterialTransferInvalidMergeMaterials";

        /// <summary>
        /// The following material to merge must be attached before merging: {0}.
        /// </summary>
        /// <remarks>
        ///     {0} - Name of the material
        /// </remarks
        public const string CustomMaterialTransferMovementAttachMaterialLocalizedMessage = "CustomMaterialTransferMovementAttachMaterial";


        /// <summary>
        /// Pallet of type ReRun must be in the right step before being attached to the consumable feed.
        /// </summary>
        public const string CustomMaterialTransferMovementAttachMaterialReRunWrongStepMessage = "CustomMaterialTransferMovementAttachMaterialReRunWrongStep";

        #endregion

        #region Scrap Management

        /// <summary>
        /// The following materials don't have the type {0} and cannot be move to a step of the type {1}: {2}
        /// </summary>
        /// <remarks>
        ///     {0} - Configured Scrap Material Type
        ///     {1} - Configured Scrap Step Type
        ///     {2} - Materials with wrong type
        /// </remarks>
        public const string ScrapRoomMaterialWrongTypeLocalizedMessage = "ScrapRoomMaterialWrongType";

        /// <summary>
        /// The following materials are not of a completed form and cannot be move to a step of the type {0}: {1}
        /// </summary>
        /// <remarks>
        ///     {0} - Configured Scrap Step Type
        ///     {1} - Materials with wrong type
        /// </remarks>
        public const string ScrapRoomMaterialWrongFormLocalizedMessage = "ScrapRoomMaterialWrongForm";

        /// <summary>
        /// The following materials need to have the Primary Quantity at 0 to be move to a step of the type {0}: {1}
        /// </summary>
        /// <remarks>
        ///     {0} - Configured Scrap Step Type
        ///     {1} - Materials with wrong type
        /// </remarks>
        public const string ScrapRoomMaterialWrongPrimaryQuantityLocalizedMessage = "ScrapRoomMaterialWrongPrimaryQuantity";

        /// <summary>
        /// The following materials don't have a Secondary Unit of {0} and cannot be move to a step of the type {1}: {2}
        /// </summary>
        /// <remarks>
        ///     {0} - Configured Reject Unit
        ///     {1} - Configured Scrap Step Type
        ///     {2} - Materials with wrong type
        /// </remarks>
        public const string ScrapRoomMaterialWrongSecondaryUnitLocalizedMessage = "ScrapRoomMaterialWrongSecondaryUnit";

        /// <summary>
        /// The following materials don't match the Secondary Quantity with the material losses quantity and cannot be move to a step of the type {0}: {1}
        /// </summary>
        /// <remarks>
        ///     {0} - Configured Scrap Step Type
        ///     {1} - Materials with wrong type
        /// </remarks>
        public const string ScrapRoomMaterialWrongSecondaryQuantityLocalizedMessage = "ScrapRoomMaterialWrongSecondaryQuantity";

        /// <summary>
        /// The loss reason configured in {0} does not exist.
        /// </summary>
        /// <remarks>
        ///     {0} - Configured Path for Scrap loss reason
        /// </remarks>
        public const string ScrapRoomScrapLossDoesNotExistLocalizedMessage = "ScrapRoomScrapLossDoesNotExist";

        /// <summary>
        /// No loss reason is configured in {0}.
        /// </summary>
        /// <remarks>
        ///     {0} - Configured Path for Scrap loss reason
        /// </remarks>
        public const string ScrapRoomNoScrapLossConfiguredLocalizedMessage = "ScrapRoomNoScrapLossConfigured";

        /// <summary>
        /// Command Not Found
        /// </summary>
        public const string CommandNotFoundLocalizedMessage = "CommandNotFound";

        #endregion

        #region Outsorted Cockpit

        /// <summary>
        /// The following Pallets were generated: 
        /// </summary>
        public const string CustomOutsortedPalletizeSuccessMessageLocalizedMessage = "CustomOutsortedPalletizeSuccessMessage";

        #endregion

        #endregion

        #region General
        /// <summary>
        /// Material Type Field
        /// </summary>
        public const string MaterialTypeField = "MaterialType";

        /// <summary>
        /// Automatic Scanning Material Creation - Quantity Token
        /// </summary>
        public const string Quantity = "Quantity";

        /// <summary>
        /// FlowPath constant
        /// </summary>
        public const string CustomCreateBatchFlowPathConstant = "FlowPath";

        /// <summary>
        /// Form constant
        /// </summary>
        public const string CustomCreateBatchFormConstant = "Form";

        /// <summary>
        /// WorkCenter constant
        /// </summary>
        public const string WorkCenter = "WorkCenter";

        /// <summary>
        /// Constant to define if ResolveNameGenerator DEE is being called from AutomaticAssemble
        /// </summary>
        public const string CustomPerformAutomaticAssemble_SplitAndConsume = "CustomPerformAutomaticAssemble_SplitAndConsume";

        /// <summary>
        /// Constant to define if it is allowed to split materials that are atached to automatic feeders.
        /// </summary>
        public const string CustomAllowAutomaticFeederMaterialSplit = "CustomAllowAutomaticFeederMaterialSplit";


        /// <summary>
        /// Is BOM Setup Valid
        /// </summary>
        public const string MaterialIsBOMSetupValid = "IsBOMSetupValid";

        /// <summary>
        /// Millimeters Units
        /// </summary>
        public const string MillimetersUnits = "mm";

        #endregion

        #region Configurations

        /// <summary>
        /// Indicates if the postpone feature is enabled
        /// </summary>
        public const string PostponeTracking = "/Cmf/Custom/Postpone/PostponeTracking";

        /// <summary>
        /// Configuration path from where the auto dispatch bool value will be extracted
        /// </summary>
        public const string AutoDispatchEnable = "/Cmf/Custom/AutoDispatch/Enable/";

        /// <summary>
        /// Configuration path from where the auto dispatch role value will be extracted
        /// </summary>
        public const string AutoDispatchRole = "/Cmf/Custom/AutoDispatch/Role/";

        /// <summary>
        /// Indicates if the validations of allowed material types in materials feature is enabled
        /// </summary>
        public const string ValidateAllowedMaterialTypesInMO = "/Cmf/Custom/MaterialValidations/ValidateAllowedMaterialsInMO/";

        /// <summary>
        /// Indicates the units to be used as Reject Unit
        /// </summary>
        public const string ScrapManagementRejectUnit = "/Cmf/Custom/ScrapManagement/RejectUnit";

        /// <summary>
        /// Indicates if the material is automatically created when it does not exists when a label is scanned
        /// </summary>
        public const string AutomaticMaterialCreationEnable = "/Cmf/Custom/AutomaticMaterialCreation/Enabled";

        /// <summary>
        /// Indicates the default form of the material when it is automatically created
        /// </summary>
        public const string AutomaticMaterialCreationDefaultForm = "/Cmf/Custom/AutomaticMaterialCreation/DefaultForm";

        /// <summary>
        /// Indicates the default type of the material when it is automatically created
        /// </summary>
        public const string AutomaticMaterialCreationDefaultType = "/Cmf/Custom/AutomaticMaterialCreation/DefaultType";

        /// <summary>
        /// Indicates the default form of the durable when it is automatically created
        /// </summary>
        public const string AutomaticDurableCreationDefaultForm = "/Cmf/Custom/AutomaticDurableCreation/DefaultForm";

        /// <summary>
        /// Indicates the default type of the durable when it is automatically created
        /// </summary>
        public const string AutomaticDurableCreationDefaultType = "/Cmf/Custom/AutomaticDurableCreation/DefaultType";

        /// <summary>
        /// Indicates the Refresh rate for the list of running MOs in FabLive
        /// </summary>
        public const string RunningMOsRefreshRate = "/Cmf/Custom/MaterialTracking/RunningMOsRefreshRate/";

        /// <summary>
        /// Indicates the Material Type for Batches
        /// </summary>
        public const string BatchMaterialType = "/Cmf/Custom/MaterialTracking/BatchMaterialDefaultType/";

        /// <summary>
        /// Indicates the Material Form for Batches
        /// </summary>
        public const string BatchMaterialForm = "/Cmf/Custom/MaterialTracking/BatchMaterialForm/";

        /// <summary>
        /// Indicates the Material Form for Pallets
        /// </summary>
        public const string PalletMaterialForm = "/Cmf/Custom/MaterialTracking/PalletMaterialForm/";

        /// <summary>
        /// Unterminate Justification (value from lookupTable UnterminateJustification) to Convert MO to Batch Form
        /// </summary>
        public const string UnterminateJustificationForMaterial = "/Cmf/Custom/Batches/UnterminateJustification/";

        /// <summary>
        /// Indicates the Hold Reason for a complete batch Hold
        /// </summary>
        public const string BatchCompleteHoldReason = "/Cmf/Custom/Batches/CompleteBatchHoldReason/";

        /// <summary>
        /// Indicates the default flowpath for batch creation
        /// </summary>
        public const string BatchDefaultFlowPath = "/Cmf/Custom/Batches/DefaultFlowPath/";

        /// <summary>
        /// Config for SampleTesting
        /// </summary>
        public const string MaterialTypeSampleTestingConfig = "/Cmf/Custom/MaterialTracking/Types/SampleTesting";

        /// <summary>
        /// Config for Intermediate Change Type
        /// </summary>
        public const string MaterialTypeIntermediateChangeTypeConfig = "/Cmf/Custom/MaterialTracking/Types/IntermediateChangeType";

        /// <summary>
        /// Config for DefaultGoodType
        /// </summary>
        public const string DefaultGoodTypeConfig = "/Cmf/Custom/MaterialTracking/Types/DefaultGoodType";

        /// <summary>
        /// Config for Scrap Type
        /// </summary>
        public const string MaterialTypeScrapConfig = "/Cmf/Custom/MaterialTracking/Types/Scrap";

        /// <summary>
        /// Config for Scrap Loss Reason
        /// </summary>
        public const string MaterialLossReasonScrap = "/Cmf/Custom/ScrapManagement/DefaultScrapReason";

        /// <summary>
        /// Config for Allow Dispatch Group Mo To Any Resource
        /// </summary>
        public const string AllowDispatchGroupMoToAnyResource = "/Cmf/Custom/MaterialTracking/AllowDispatchGroupMoToAnyResource";

        /// <summary>
        /// Config for HPO import/export file encoding
        /// </summary>
        public const string HpoFilesEncoding = "/Cmf/Custom/MaterialTracking/HpoFilesEncoding";

        /// <summary>
        /// Config for default unit for attributes Length, Width, and Thickness
        /// </summary>
        public const string DefaultLengthUnitConfig = "/Cmf/Custom/MaterialTracking/DefaultLengthUnit";

        /// <summary>
        /// Config for default unit for attribute Weight
        /// </summary>
        public const string DefaultWeightUnitConfig = "/Cmf/Custom/MaterialTracking/DefaultWeightUnit";
        /// <summary>
        /// Config for default StructureType for custom alternative ideal cycle time.
        /// </summary>
        public const string DefaultCustomAlternativeIdealCycleTimeStructureTypeConfig = "/Cmf/Custom/Material/DefaultCustomAlternativeIdealCycleTimeStructureType";

        #endregion

        #region Generic Tables

        /// <summary>
        /// Generic Table - CustomMOAllowedMaterialTypes
        /// </summary>
        public const string CustomMOAllowedMaterialTypes = "CustomMOAllowedMaterialTypes";

        /// <summary>
        /// Generic Table - CustomMOAllowedMaterialTypes
        /// </summary>
        public const string CustomMaterialTypeColorMapping = "CustomMaterialTypeColorMapping";

        /// <summary>
        /// Generic Table - CustomManualLoadingConfiguration
        /// </summary>
        public const string CustomManualLoadingConfiguration = "CustomManualLoadingConfiguration";

        /// <summary>
        /// Generic Table - CustomManualLoadingConfiguration - AllowManualLoading field
        /// </summary>
        public const string CustomManualLoadingConfigurationAllowManualLoading = "AllowManualLoading";

        /// <summary>
        /// Generic Table - CustomFeederOutsortingConfiguration
        /// </summary>
        public const string CustomFeederOutsortingConfiguration = "CustomFeederOutsortingConfiguration";

        /// <summary>
        /// Generic Table - CustomFeederOutsortingConfiguration - AllowFeederOutsorting field
        /// </summary>
        public const string CustomFeederOutsortingConfigurationAllowFeederOutsorting = "AllowFeederOutsorting";

        /// <summary>
        /// Generic Table -  CustomOptimizerResourcesConfiguration
        /// </summary>
        public const string CustomOptimizerResourcesConfiguration = "CustomOptimizerResourcesConfiguration";

        /// <summary>
        /// Generic Table -  CustomChartContextTranslator
        /// </summary>
        /// <remarks>Used to map rules (DEEs) that automate the resolution of chart contexts for the user.</remarks>
        public const string CustomChartContextTranslator = "CustomChartContextTranslator";

        #endregion

        #region Smart Tables

        /// <summary>
        /// Smart Table Property - CustomMaterialFlowResolution - FlowPath
        /// </summary>
        public const string CustomMaterialFlowResolutionFlowPath = "FlowPath";
        /// <summary>
        /// Smart Table Property - CustomMaterialFlowResolution - ConsumptionFlowPath
        /// </summary>
        public const string CustomMaterialFlowResolutionConsumptionFlowPath = "ConsumptionFlowPath";

        /// <summary>
        /// Smart table that resolves the configuration for automatic moving a material
        /// </summary>
        public const string CustomMaterialMovementConfigurationSmartTable = "CustomMaterialMovementConfiguration";

        /// <summary>
        /// Smart table - CustomMaterialMovementConfiguration - EventAction
        /// </summary>
        public const string CustomMaterialMovementConfigurationEventAction = "EventAction";

        /// <summary>
        /// Smart table - CustomMaterialMovementConfiguration - Request
        /// </summary>
        public const string CustomMaterialMovementConfigurationMovementRequest = "MovementRequest";

        /// <summary>
        /// Smart table - CustomMaterialMovementConfiguration - WMSRequest
        /// </summary>
        public const string CustomMaterialMovementConfigurationWMSRequest = "WMSRequest";

        /// <summary>
        /// Smart table - CustomMaterialMovementConfiguration - DestinationResource
        /// </summary>
        public const string CustomMaterialMovementConfigurationDestinationResource = "DestinationResource";

        /// <summary>
        /// CustomMaterialMovementConfiguration - Result - ResourceToAttach
        /// </summary>
        public const string CustomMaterialMovementConfigurationResourceToAttach = "ResourceToAttach";

        /// <summary>
        /// CustomMaterialMovementConfigurationEventAction - Result - None
        /// </summary>
        public const string CustomMaterialMovementConfigurationNone = "None";

        /// <summary>
        /// CustomMaterialMovementConfigurationEventAction - Result - MoveNext
        /// </summary>
        public const string CustomMaterialMovementConfigurationMoveNext = "MoveNext";

        /// <summary>
        /// CustomMaterialMovementConfigurationEventAction - Result - MoveNextAndStore
        /// </summary>
        public const string CustomMaterialMovementConfigurationMoveNextAndStore = "MoveNextAndStore";

        /// <summary>
        /// CustomMaterialMovementConfiguration - Result - Store
        /// </summary>
        public const string CustomMaterialMovementConfigurationStore = "Store";

        /// <summary>
        /// CustomMaterialMovementConfiguration - Result - ChangeFlowStepAndAttach
        /// </summary>
        public const string CustomMaterialMovementConfigurationChangeFlowStepAndAttach = "ChangeFlowStepAndAttach";

        /// <summary>
        /// Smart table that indicates the automation mode of a Order
        /// </summary>
        public const string CustomOrderAutomationModeSmartTable = "CustomOrderAutomationMode";

        /// <summary>
        /// CustomOrderAutomationMode - Facility
        /// </summary>
        public const string CustomOrderAutomationModeFacility = "Facility";

        /// <summary>
        /// CustomOrderAutomationMode - Area
        /// </summary>
        public const string CustomOrderAutomationModeArea = "Area";

        /// <summary>
        /// CustomOrderAutomationMode - Resource
        /// </summary>
        public const string CustomOrderAutomationModeResource = "Resource";

        /// <summary>
        /// CustomOrderAutomationMode - WorkCenter
        /// </summary>
        public const string CustomOrderAutomationModeWorkCenter = "WorkCenter";

        /// <summary>
        /// CustomOrderAutomationMode - ProductGroup
        /// </summary>
        public const string CustomOrderAutomationModeProductGroup = "ProductGroup";

        /// <summary>
        /// CustomOrderAutomationMode - Product
        /// </summary>
        public const string CustomOrderAutomationModeProduct = "Product";

        /// <summary>
        /// CustomOrderAutomationMode - FullAutomation
        /// </summary>
        public const string CustomOrderAutomationModeFullAutomation = "FullAutomation";








        /// <summary>
        /// Smart table that indicates the flowpath for the feeder outsorted pallets
        /// </summary>
        public const string CustomFeederOutsortingFlowResolutionSmartTable = "CustomFeederOutsortingFlowResolution";

        /// <summary>
        /// CustomFeederOutsortingFlowResolution - Facility
        /// </summary>
        public const string CustomFeederOutsortingFlowResolutionFacility = "Facility";

        /// <summary>
        /// CustomFeederOutsortingFlowResolution - Area
        /// </summary>
        public const string CustomFeederOutsortingFlowResolutionArea = "Area";

        /// <summary>
        /// CustomFeederOutsortingFlowResolution - Resource
        /// </summary>
        public const string CustomFeederOutsortingFlowResolutionResource = "Resource";

        /// <summary>
        /// CustomFeederOutsortingFlowResolution - Product
        /// </summary>
        public const string CustomFeederOutsortingFlowResolutionProduct = "Product";

        /// <summary>
        /// CustomFeederOutsortingFlowResolution - FlowPath
        /// </summary>
        public const string CustomFeederOutsortingFlowResolutionFlowPath = "FlowPath";

        #endregion

        #region Contexts

        /// <summary>
        /// Auto Dispatch Utility - Ignore Label Printing Validation
        /// </summary>
        public const string PreDispatchUtilityIgnoreLabelPrintingValidation = "PreDispatch_IgnoreLabelPrintingValidation";

        /// <summary>
        /// ERP Change Type Report - Ignore during Unit Completion
        /// </summary>
        public const string ERPChangeTypeReportUnitCompletion = "CustomERPChangeTypeReport_UnitCompletion";

        /// <summary>
        /// Unit Complete - Ignore Printing of new label because is a Process Loss
        /// </summary>
        public const string CustomUnitCompleteIsProcessLossContext = "CustomUnitComplete_IsProcessLossContext";

        #endregion

        #region State Model

        /// <summary>
        /// Material State Model
        /// </summary>
        public const string MaterialStateModel = "MSM";

        /// <summary>
        /// Material State Model - Setup
        /// </summary>
        public const string MaterialStateModelSetup = "SETUP";

        /// <summary>
        /// Material State Model - InProcess
        /// </summary>
        public const string MaterialStateModelInProcess = "INPROCESS";

        /// <summary>
        /// Material State Model - Queued
        /// </summary>
        public const string MaterialStateModelQueued = "QUEUED";

        /// <summary>
        /// Material State Model - Dispatched
        /// </summary>
        public const string MaterialStateModelDispatched = "DISPATCHED";

        /// <summary>
        /// Material State Model - Aborting
        /// </summary>
        public const string MaterialStateModelAborting = "ABORTING";

        /// <summary>
        /// Material State Model - Aborted
        /// </summary>
        public const string MaterialStateModelAborted = "ABORTED";

        /// <summary>
        /// Material State Model - Completing
        /// </summary>
        public const string MaterialStateModelCompleting = "COMPLETING";

        /// <summary>
        /// Material State Model - Completed
        /// </summary>
        public const string MaterialStateModelCompleted = "COMPLETED";

        /// <summary>
        /// Material State Model - Suspending
        /// </summary>
        public const string MaterialStateModelSuspending = "SUSPENDING";

        /// <summary>
        /// Material State Model - Suspended
        /// </summary>
        public const string MaterialStateModelSuspended = "SUSPENDED";

        /// <summary>
        /// Material State Model - Unsuspending
        /// </summary>
        public const string MaterialStateModelUnsuspending = "UNSUSPENDING";

        #endregion

        #region Relations

        /// <summary>
        /// Relation between Material and Batch Material
        /// </summary>
        public const string CustomMaterialBatchRelation = "CustomMaterialBatch";

        /// <summary>
        /// Relation between group Material and Material
        /// </summary>
        public const string CustomGroupMaterialManufacturingOrder = "CustomGroupMaterialManufacturingOrder";

        /// <summary>
        /// Relation between Material MO and outfeeders and outsorters
        /// </summary>
        public const string CustomManufacturingOrderOutFeeder = "CustomManufacturingOrderOutFeeder";

        /// <summary>
        /// Attribute that contains the value of the current quantity of CustomManufacturingOrderOutFeeder relation
        /// </summary>
        public const string CustomManufacturingOrderOutFeederCurrentQuantity = "CustomCurrentQuantity";

        /// <summary>
        /// Attribute that contains the value of the initial shift quantity of CustomManufacturingOrderOutFeeder relation
        /// </summary>
        public const string CustomManufacturingOrderOutFeederInitialShiftQuantity = "CustomInitialShiftQuantity";

        #endregion

        #region Scan Tokens

        /// <summary>
        /// Automatic Scanning Material Creation - Batch Token
        /// </summary>
        public const string AutomaticScanningMaterialCreationBatchToken = "Batch";

        #endregion

        #region Reasons

        /// <summary>
        /// Loss Reason - ERPTerminated
        /// </summary>
        public const string ERPTerminatedDefaultReason = "ERPTerminated";

        /// <summary>
        /// ProcessLossMotive - RegularCompletion
        /// </summary>
        public const string RegularCompletion = "RegularCompletion";

        /// <summary>
        /// ProcessLossMotive - ForceOrderCompletion
        /// </summary>
        public const string ForceOrderCompletion = "ForceOrderCompletion";

        #endregion

        #region Type

        /// <summary>
        /// Material Type - Outsorted
        /// </summary>
        public const string MaterialTypeOutsorted = "Outsorted";

        /// <summary>
        /// Material Type - Direct Repair
        /// </summary>
        public const string MaterialTypeDirectRepair = "DirectRepair";

        /// <summary>
        /// Material Type - ReRun
        /// </summary>
        public const string MaterialTypeReRun = "ReRun";
        #endregion

        #region Properties

        /// <summary>
        /// Property that contains the Last Processed Resource
        /// </summary>
        public const string MaterialPropertyLastProcessedResource = "LastProcessedResource";

        /// <summary>
        /// Property that contains the Last Processed Resource
        /// </summary>
        public const decimal CustomAssembleMinimumAssumedQuantity = 0.0000001m;

        #endregion

        #region NameGenerators
        public const string DefaultMaterialNameGenerator = "MaterialNameGenerator";
        #endregion
    }
}
