﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Common
{
    public static partial class IKEAConstants
    {
        #region Configuration

        /// <summary>
        /// Forklift scanning configuration path
        /// </summary>
        public const string CustomForkliftScanningConfigurationPath = "/Cmf/Custom/Forklift/ScanningConfiguration/";

        #endregion

        #region Localized Messages

        /// <summary>
        /// Error message to be displayed when no configuration is found under /Cmf/Custom/Forklift/ScanningConfiguration
        /// Message: No default scanning configuration found on config {0}.
        /// </summary>
        public const string CustomInvalidDefaultScanningConfigurationFound = "CustomInvalidDefaultScanningConfigurationFound";

        /// <summary>
        /// Error message to be displayed then there is a missmatch between value on a configuration and on a Lookup Table
        /// Message: Configuration found on {0} do not match anty entry on Lookup Table {1}.
        /// </summary>
        public const string CustomMismatchOnConfigurationAndLookupTable = "CustomMismatchOnConfigurationAndLookupTable";

        /// <summary>
        /// Error message to be displayed when no configuration is found on the Generic Table CustomScanningConfiguration
        /// Message: No valid configuration found on Generic Table {0}.
        /// </summary>
        public const string CustomInvalidConfigurationOnGenericTable = "CustomInvalidConfigurationOnGenericTable";

        #endregion


        #region MessageBus Message Prefixes

        /// <summary>
        /// Message Bus Message prefix to be used when publishing messages to refresh all Forklitft Operator Cockpit GUIs subscribed 
        /// to a given area event
        /// </summary>
        public const string MessageBusForkliftAreaEvent = "Cmf.Custom.ForkliftAreaEvent.";

        #endregion  
    }
}
