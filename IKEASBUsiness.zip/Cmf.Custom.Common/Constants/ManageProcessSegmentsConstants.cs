﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Common
{
    public static partial class IKEAConstants
    {

        #region Lookup Tables

        /// <summary>
        /// Lookup Table that contains the BOM Template Names
        /// </summary>
        public const string CustomBOMTemplatesLookupTable = "CustomBOMTemplates";

        #endregion

        #region Generic Tables

        /// <summary>
        /// Generic table that contains the details of the BOM Template
        /// </summary>
        public const string CustomBOMTemplateDetailsGenericTable = "CustomBOMTemplateDetails";

        /// <summary>
        /// CustomBOMTemplateDetails - Template
        /// </summary>
        public const string CustomBOMTemplateDetailsTemplate = "Template";

        /// <summary>
        /// CustomBOMTemplateDetails - Process Segment
        /// </summary>
        public const string CustomBOMTemplateDetailsProcessSegment = "ProcessSegment";

        /// <summary>
        /// CustomBOMTemplateDetails - Sub-Process Segment
        /// </summary>
        public const string CustomBOMTemplateDetailsSubProcessSegment = "SubProcessSegment";

        /// <summary>
        /// CustomBOMTemplateDetails - Product
        /// </summary>
        public const string CustomBOMTemplateDetailsProduct = "Product";

        /// <summary>
        /// CustomBOMTemplateDetails - Ratio
        /// </summary>
        public const string CustomBOMTemplateDetailsRatio = "Ratio";

        /// <summary>
        /// CustomBOMTemplateDetails - Numerator
        /// </summary>
        public const string CustomBOMTemplateDetailsNumerator = "Numerator";

        /// <summary>
        /// CustomBOMTemplateDetails - Denominator
        /// </summary>
        public const string CustomBOMTemplateDetailsDenominator = "Denominator";

        #endregion

        #region Smart Tables

        /// <summary>
        /// Smart table to determined what BOM Template to be used
        /// </summary>
        public const string CustomBOMTemplateHandlerSmartTable = "CustomBOMTemplateHandler";

        /// <summary>
        /// CustomBOMTemplateHandler - Facility
        /// </summary>
        public const string CustomBOMTemplateHandlerFacility = "Facility";

        /// <summary>
        /// CustomBOMTemplateHandler - Area
        /// </summary>
        public const string CustomBOMTemplateHandlerArea = "Area";

        /// <summary>
        /// CustomBOMTemplateHandler - WorkCenter
        /// </summary>
        public const string CustomBOMTemplateHandlerWorkCenter = "WorkCenter";

        /// <summary>
        /// CustomBOMTemplateHandler - Resource
        /// </summary>
        public const string CustomBOMTemplateHandlerResource = "Resource";

        /// <summary>
        /// CustomBOMTemplateHandler - OrderType
        /// </summary>
        public const string CustomBOMTemplateHandlerOrderType = "OrderType";

        /// <summary>
        /// CustomBOMTemplateHandler - Structure Type
        /// </summary>
        public const string CustomBOMTemplateHandlerStructureType = "StructureType";

        /// <summary>
        /// CustomBOMTemplateHandler - Product
        /// </summary>
        public const string CustomBOMTemplateHandlerProduct = "Product";

        /// <summary>
        /// CustomBOMTemplateHandler - Template
        /// </summary>
        public const string CustomBOMTemplateHandlerTemplate = "Template";

        #endregion

        #region Configurations

        /// <summary>
        /// Flag to indicate if the system should calculate process segments
        /// </summary>
        public const string CalculateProcessSegmentsConfig = "/Cmf/Custom/ERP/CalculateProcessSegments";

        #endregion

        #region Localized Messages

        /// <summary>
        /// The BOM Products coming form ERP do not match the configured BOM Template ({0}).
        /// </summary>
        /// <remarks>
        ///     {0} - BOM Template name
        /// </remarks>
        public const string CustomValidateBOMMismatchBOMProductsLocalizedMessage = "CustomValidateBOMMismatchBOMProducts";

        /// <summary>
        /// There are no BOM Template configured for the Product {0}.
        /// </summary>
        /// <remarks>
        ///     {0} - Product Name
        /// </remarks>
        public const string CustomValidateBOMTemplateMissingConfigurationLocalizedMessage = "CustomValidateBOMTemplateMissingConfiguration";

        /// <summary>
        /// Resolved BOM Template '{0}' for this order contains no distribution details. Please check configuration of BOM Templare details in Table CustomBOMTemplateDetails.
        /// </summary>
        /// <remarks>
        ///     {0} - BOM Template
        /// </remarks>
        public const string CustomValidateBOMTemplateDetailsMissingConfigurationLocalizedMessage = "CustomValidateBOMTemplateDetailsMissingConfiguration";

        /// <summary>
        /// The Resource {0} does not contain a sub resource with the Process Segment {1} and Sub Process Segment {2}.
        /// </summary>
        /// <remarks>
        ///     {0} - Main Line
        ///     {1} - Process Segment
        ///     {2} - Sub Process Segment
        /// </remarks>
        public const string CustomValidateBOMSubResourceDoesNotExistLocalizedMessage = "CustomValidateBOMSubResourceDoesNotExist";


        /// <summary>
        /// The Non-Reference BOM Product '{0}' has an invalid quantity of '0' in the BOM Sequence {1}
        /// </summary>
        /// <remarks>
        ///     {0} - Product Name
        ///     {1} - ERP Operation Sequence
        /// </remarks>
        public const string CustomValidateBOMProductWithZeroQuantityLocalizedMessage = "CustomValidateBOMProductWithZeroQuantity";

        #endregion

    }
}
