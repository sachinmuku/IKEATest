﻿namespace Cmf.Custom.IKEA.Common
{
    /// <summary>
    /// To hold all the related constants for WMS integration
    /// </summary>
    public partial class IKEAConstants
    {

        #region Configurations

        /// <summary>
        /// WMS - Username
        /// </summary>
        public const string WMSUsername = "/Cmf/Custom/WMS/Username";

        /// <summary>
        /// WMS - Password
        /// </summary>
        public const string WMSPassword = "/Cmf/Custom/WMS/Password";

        /// <summary>
        /// WMS - Token Endpoint
        /// </summary>
        public const string WMSTokenEndpoint = "/Cmf/Custom/WMS/TokenEndpoint";

        /// <summary>
        /// WMS - Base Endpoint
        /// </summary>
        public const string WMSBaseEndpoint = "/Cmf/Custom/WMS/BaseEndpoint";

        /// <summary>
        /// WMS - Endpoint
        /// </summary>
        public const string WMSEndPoint = "/Cmf/Custom/WMS/Endpoint/";

        /// <summary>
        /// WMS - OrderRequest Endpoint
        /// </summary>
        public const string WMSOrderRequestEndpoint = "WMSOrderRequest";

        /// <summary>
        /// WMS - OrderRequest Endpoint
        /// </summary>
        public const string WMSOrderCancelEndpoint = "WMSOrderCancel";

        /// <summary>
        /// WMS - GetPalletStatus Endpoint
        /// </summary>
        public const string WMSGetPalletStatusEndpoint = "WMSGetPalletStatus";

        /// <summary>
        /// WMS - SetPalletStatus Endpoint
        /// </summary>
        public const string WMSSetPalletStatusEndpoint = "WMSSetPalletStatus";

        /// <summary>
        /// WMS - Enable or disable the material creation in MES if WMS delivers a not requested material
        /// </summary>
        public const string WMSCreateNotRequestedMaterials = "/Cmf/Custom/WMS/CreateNotRequestedMaterials";

        /// <summary>
        /// WMS - Enable or disable the material change type reporting to DEE
        /// </summary>
        public const string WMSEnableMaterialChangeTypeReporting = "/Cmf/Custom/WMS/EnableMaterialChangeTypeReporting";

        /// <summary>
        /// WMS - String to parse WMS response and continue with cancelation of jobs
        /// </summary>
        public const string WMSContinueCancelWithResponse = "/Cmf/Custom/WMS/ContinueCancelWithResponse";

        #endregion

        #region General

        /// <summary>
        /// System WMS
        /// </summary>
        public const string WMSSystem = "WMS";

        /// <summary>
        /// WMS Order Request
        /// </summary>
        public const string WMSOrderRequest = "WMSOrderRequest";

        /// <summary>
        /// WMS Order Request - Message Type
        /// </summary>
        public const string WMSOrderRequestMessageType = "WMSOrderRequest";

        /// <summary>
        /// WMS Order Request - Event Name
        /// </summary>
        public const string WMSOrderRequestEventName = "WMSOrderRequest";

        /// <summary>
        /// WMS SetPalletStatus - MessageType 
        /// </summary>
        public const string WMSSetPalletStatusMessageType = "WMSSetPalletStatus";

        /// <summary>
        /// WMS GetPalletStatus - MessageType 
        /// </summary>
        public const string WMSGetPalletStatusMessageType = "WMSGetPalletStatus";

        /// <summary>
        /// WMS Order Update
        /// </summary>
        public const string WMSOrderUpdate = "WMSOrderUpdate";

        /// <summary>
        /// WMS Order Update - Message Type
        /// </summary>
        public const string WMSOrderUpdateMessageType = "WMSOrderUpdate";

        /// <summary>
        /// WMS Order Update - Event Name
        /// </summary>
        public const string WMSOrderUpdateEventName = "WMSOrderUpdate";

        /// <summary>
        /// IoT Event Definition - WMSOrderRequest
        /// </summary>
        public const string EventDefinitionWMSOrderRequest = "WMSOrderRequestEvent";

        /// <summary>
        /// WMS Factory Automation - Config Path for IoT Resource Name for Factory Automation Controller
        /// </summary>
        public const string FactoryAutomationWMSHandler = "/Cmf/Custom/WMS/FactoryAutomationWMSHandler";

        /// <summary>
        /// WMS Factory Automation - Config Path for Max Concurrent Jobs for Factory Automation Worker Controller
        /// </summary>
        public const string FactoryAutomationMaxConcurrentJobs = "/Cmf/Custom/WMS/FactoryAutomationMaxConcurrentJobs";

        /// <summary>
        /// WMS Factory Automation Resource Name 
        /// </summary>
        public const string WMSFactoryAutomationRequestTypeCancel = "CancelJob";

        /// <summary>
        /// WMS Factory Automation Resource Name 
        /// </summary>
        public const string WMSFactoryAutomationRequestTypeComplete = "CompleteJob";

        /// <summary>
        /// WMS Factory Automation ControllerFailure Error Code
        /// </summary>
        public const string WMSFactoryAutomationControllerFailureErrorCode = "ControllerFailure";

        /// <summary>
        /// WMS Factory Automation Unkown State After Restart Error Code
        /// </summary>
        public const string AutomationJobUnknownStateAfterRestart = "FE0002";

        /// <summary>
        /// WMS Factory Automation Feed Request Default Status
        /// </summary>
        public const int WMSAutomationJobFeedDefaulStatus = 1;

        /// <summary>
        /// WMS Material Detach Name 
        /// </summary>
        public const string WMSDetach = "Detach";

        /// <summary>
        /// WMS Material Attach Name 
        /// </summary>
        public const string WMSAttach = "Attach";

        #endregion

        #region Localized Messages
        /// <summary>
        /// A FlowPath could not be found while creating a material from WMS. Resource: '{0}', Facility: '{1}', Product: '{2}'.
        /// </summary>
        public const string CustomWMSMaterialCreationFlowPathNotFoundLocalizedMessage = "CustomWMSMaterialCreationFlowPathNotFound";

        /// <summary>
        /// A Resource with the name '{0}' could not be found in MES.
        /// </summary>
        public const string CustomWMSMaterialCreationResourceNotFoundLocalizedMessage = "CustomWMSMaterialCreationResourceNotFound";

        /// <summary>
        /// A Product with the name '{0}' could not be found in MES.
        /// </summary>
        public const string CustomWMSMaterialCreationProductNotFoundLocalizedMessage = "CustomWMSMaterialCreationProductNotFound";

        /// <summary>
        /// The message Status field is not valid. received status: '{0}'.
        /// </summary>
        public const string CustomWMSStatusFieldNotValidLocalizedMessage = "CustomWMSStatusFieldNotValid";

        /// <summary>
        /// The BatchId field is not valid: '{0}'.
        /// </summary>
        public const string CustomWMSBatchIdFieldNotValidLocalizedMessage = "CustomWMSBatchIdFieldNotValid";

        /// <summary>
        /// A ProductionOrder with the name '{0}' could not be found in MES.
        /// </summary>
        public const string CustomWMSMaterialCreationProductionOrderNotFoundLocalizedMessage = "CustomWMSMaterialCreationProductionOrderNotFound";

        /// <summary>
        /// The material is not in a state that can be changed.Current state: '{0}'."
        /// </summary>
        public const string CustomWMSMaterialUpdateNotAllowedStateLocalizedMessage = "CustomWMSMaterialUpdateNotAllowedState";

        /// <summary>
        /// The Destination field is not valid: '{0}'.
        /// </summary>
        public const string CustomWMSResourceNotValidLocalizedMessage = "CustomWMSMaterialCreationResourceNotValid";

        /// <summary>
        /// The DeliveredQuantity field is not valid: '{0}'.
        /// </summary>
        public const string CustomWMSDeliveredQuantityFieldNotValidLocalizedMessage = "CustomWMSDeliveredQuantityFieldNotValid";

        /// <summary>
        /// The type supplied is not valid: '{0}'.
        /// </summary>
        public const string CustomWMSIOTypeFieldNotValidLocalizedMessage = "CustomWMSIOTypeFieldNotValid";

        /// <summary>
        /// It was not possible to create a WMS message with the data specified.
        /// </summary>
        public const string CustomWMSErrorCreatingMessageLocalizedMessage = "CustomWMSErrorCreatingMessage";

        /// <summary>
        /// The ItemId field is not valid: '{0}'.
        /// </summary>
        public const string CustomWMSItemIdFieldNotValidLocalizedMessage = "CustomWMSItemIdFieldNotValid";

        /// <summary>
        /// The PalletQuantity field is not valid: '{0}'.
        /// </summary>
        public const string CustomWMSPalletQuantityFieldNotValidLocalizedMessage = "CustomWMSPalletQuantityFieldNotValid";

        /// <summary>
        /// Some of the WMS configurations are missing
        /// </summary>
        public const string CustomWMSMissingConfigurationsLocalizedMessage = "CustomWMSMissingConfigurations";

        /// <summary>
        /// Exception returned by WMS: {0}
        /// </summary>
        public const string CustomWMSExceptionLocalizedMessage = "CustomWMSException";

        /// <summary>
        /// Unable to obtain a access token
        /// </summary>
        public const string CustomWMSUnableToObtainTokenLocalizedMessage = "CustomWMSUnableToObtainToken";

        /// <summary>
        /// No Base Endpoint was configured
        /// </summary>
        public const string CustomWMSMissingBaseEndpointLocalizedMessage = "CustomWMSMissingBaseEndpoint";

        /// <summary>
        /// WMS Request/Response is not in the correct format: {0}.
        /// </summary>
        public const string CustomWMSInvalidResponseLocalizedMessage = "CustomWMSInvalidResponse";

        /// <summary>
        /// WMS Request/Response deserialization failed, variable is null.
        /// </summary>
        public const string CustomWMSDeserializationFailedLocalizedMessage = "CustomWMSDeserializationFailed";

        /// <summary>
        /// No endpoint found on Configuration: {0}.
        /// </summary>
        public const string CustomWMSMissingEndpointConfigLocalizedMessage = "CustomWMSMissingEndpointConfig";

        /// <summary>
        /// No API/Message was found.
        /// </summary>
        public const string CustomWMSNoApiMessageFoundLocalizedMessage = "CustomWMSNoApiMessageFound";

        /// <summary>
        /// Created {0} automation jobs for WMS requests.
        /// </summary>
        public const string CustomWMSJobsCreatedLocalizedMessage = "CustomWMSJobsCreated";

        /// <summary>
        /// WMS FEED: MO = {0}, BOM Product = {1}, Quantity = {2}, Destination = {3}.
        /// </summary>
        public const string CustomWMSJobFeedPropertiesLocalizedMessage = "CustomWMSJobFeedProperties";

        /// <summary>
        /// Invalid inventory Id: {0}.
        /// </summary>
        public const string CustomWMSInvalidInventoryIdReceivedLocalizedMessage = "CustomWMSInvalidInventoryIdReceived";

        /// <summary>
        /// Invalid RequestType: '{0}'
        /// </summary>
        public const string CustomWMSInvalidRequestTypeReceivedLocalizedMessage = "CustomWMSInvalidRequestTypeReceived";

        /// <summary>
        /// "The specified resource '{0}' that contains the controller for Factory Automation could not be found in MES."
        /// </summary>
        public const string CustomWMSFactoryAutomationInvalidResourceLocalizedMessage = "CustomWMSFactoryAutomationInvalidResource";

        /// <summary>
        /// "A controller instance could not be found in the specified Factory Automation resource '{0}'."
        /// </summary>
        public const string CustomWMSFactoryAutomationInvalidResourceControllerLocalizedMessage = "CustomWMSFactoryAutomationInvalidResourceController";

        /// <summary>
        /// A mapping for status {1} couldn't be found on generic table {0}.
        /// </summary>
        public const string CustomWMSMaterialStatusMappingNotFoundLocalizedMessage = "CustomWMSMaterialStatusMappingNotFound";

        /// <summary>
        /// Invalid Order Type, expected {0} but got {1} instead.
        /// </summary>
        public const string CustomWMSInvalidOrderTypeLocalizedMessage = "CustomWMSInvalidOrderType";

        /// <summary>
        /// Cannot create WMS Feed request, because Products {0} do not have a destination resource set.
        /// </summary>
        public const string CustomWMSFeedProductMissingDestinationLocalizedMessage = "CustomWMSFeedProductMissingDestination";

        /// <summary>
        /// Product quantity {0} can not be larger than {1}. 
        /// </summary>
        public const string CustomWMSCalculatedQuantityCanNotBeLargerThenCalculatedLocalizedMessage = "CustomWMSCalculatedQuantityCanNotBeLargerThenCalculated";

        #endregion

        #region Attributes

        /// <summary>
        /// WMSInventoryOrderId material attribute (to keep track of the IOID used to create the materials)
        /// </summary>
        public const string CustomWMSInventoryOrderId = "WMSInventoryOrderId";

        /// <summary>
        /// WMSOriginalMaterial material attribute 
        /// Stores the original material name sent by WMS. Indicates that the material was created but with a different name because it already existed in MES.
        /// </summary>
        public const string CustomWMSOriginalMaterial = "WMSOriginalMaterial";

        /// <summary>
        /// WMSOriginalMaterial attribute 
        /// Stores the material atttribute name.
        /// </summary>
        public const string WMSBatchIDAttributeName = "BatchID";
        /// <summary>
        ///  WMSOriginalMaterial attribute 
        /// Stores the material atttribute name.
        /// </summary>
        public const string WMSStatusAttributeName = "Status";

        #endregion

        #region Properties
        /// <summary>
        /// TriggerEventId property 
        /// Stores the material property name.
        /// </summary>
        public const string AutomationJobTriggerEventIdColumnName = "TriggerEventId";

        /// <summary>
        /// SystemState property 
        /// Stores the material property name.
        /// </summary>
        public const string AutomationJobSystemStateColumnName = "SystemState";

        /// <summary>
        /// SchedulingState property 
        /// Stores the material property name.
        /// </summary>
        public const string AutomationJobSchedulingStateColumnName = "SchedulingState";
        #endregion

        #region Generic Table

        /// <summary>
        ///  Generic Table CustomWMSMaterialTypeMapping name
        /// </summary>
        public const string CustomWMSMaterialTypeMappingGenericTable = "CustomWMSMaterialTypeMapping";

        /// <summary>
        /// Name of the column MESStatus in GenericTable{CustomWMSMaterialTypeMappingGenericTable}
        /// </summary>
        public const string CustomWMSMaterialTypeMappingGenericTableMESStatus = "MESStatus";

        /// <summary>
        /// Name of the column WMSStatus in GenericTable{CustomWMSMaterialTypeMappingGenericTable}
        /// </summary>
        public const string CustomWMSMaterialTypeMappingGenericTableWMSStatus = "WMSStatus";

        #endregion

        #region Smart Tables

        /// <summary>
        ///  Smart Table CustomConsumableFeedsDirectDelivery name
        /// </summary>
        public const string CustomConsumableFeedsDirectDeliverySmartTable = "CustomConsumableFeedsDirectDelivery";

        /// <summary>
        /// Name of the column MainLine in Smart Table CustomConsumableFeedsDirectDelivery
        /// </summary>
        public const string CustomConsumableFeedsDirectDeliverySmartTableMainLine = "MainLine";

        /// <summary>
        /// Name of the column Feeder in Smart Table CustomConsumableFeedsDirectDelivery
        /// </summary>
        public const string CustomConsumableFeedsDirectDeliverySmartTableFeeder = "Feeder";

        /// <summary>
        /// Name of the column IsDirectDelivery in Smart Table CustomConsumableFeedsDirectDelivery
        /// </summary>
        public const string CustomConsumableFeedsDirectDeliverySmartTableIsDirectDelivery = "IsDirectDelivery";

        /// <summary>
		/// Smart Table CustomWMSOverDeliveryResolution name
		/// </summary>
		public const string CustomWMSOverDeliveryResolutionSmartTable = "CustomWMSOverDeliveryResolution";

        /// <summary>
        /// Name of the column Facility in Smart Table CustomWMSOverDeliveryResolution name
        /// </summary>
        public const string CustomWMSOverDeliveryResolutionSmartTableFacility = "Facility";

        /// <summary>
        /// Name of the column Area in Smart Table CustomWMSOverDeliveryResolution name
        /// </summary>
        public const string CustomWMSOverDeliveryResolutionSmartTableArea = "Area";

        /// <summary>
        /// Name of the column Resource in Smart Table CustomWMSOverDeliveryResolution name
        /// </summary>
        public const string CustomWMSOverDeliveryResolutionSmartTableResource = "Resource";

        /// <summary>
        /// Name of the column WorkCenter in Smart Table CustomWMSOverDeliveryResolution name
        /// </summary>
        public const string CustomWMSOverDeliveryResolutionSmartTableWorkCenter = "WorkCenter";

        /// <summary>
        /// Name of the column ProductGroup in Smart Table CustomWMSOverDeliveryResolution name
        /// </summary>
        public const string CustomWMSOverDeliveryResolutionSmartTableProductGroup = "ProductGroup";

        /// <summary>
        /// Name of the column Product in Smart Table CustomWMSOverDeliveryResolution name
        /// </summary>
        public const string CustomWMSOverDeliveryResolutionSmartTableProduct = "Product";

        /// <summary>
        /// Name of the column OverDeliveryPercentage in Smart Table CustomWMSOverDeliveryResolution name
        /// </summary>
        public const string CustomWMSOverDeliveryResolutionSmartTableOverDeliveryPercentage = "OverDeliveryPercentage";

        /// <summary>
        /// Name of the column MaxOverDeliveryQuantity in Smart Table CustomWMSOverDeliveryResolution name
        /// </summary>
        public const string CustomWMSOverDeliveryResolutionSmartTableMaxOverDeliveryQuantity = "MaxOverDeliveryQuantity";

        /// <summary>
        /// Name of the column OverRequestPercentage in Smart Table CustomWMSOverDeliveryResolution name
        /// </summary>
        public const string CustomWMSOverDeliveryResolutionSmartTableOverRequestPercentage = "OverRequestPercentage";

        /// <summary>
        /// Name of the column MaxOverRequestQuantity in Smart Table CustomWMSOverDeliveryResolution name
        /// </summary>
        public const string CustomWMSOverDeliveryResolutionSmartTableMaxOverRequestQuantity = "MaxOverRequestQuantity";
        #endregion

        #region Features

        /// <summary>
        /// Feature that holds the role(s) with permissions for making Manual Feed Requests to WMS,
        /// from the Operator Cockpit of a Resource
        /// </summary>
        public const string OperatorWarehouseOrderRequestsFeature = "Custom.Operator.WarehouseOrderRequests";

        #endregion

        #region Localized Messages

        /// <summary>
        /// Localized Message title to be displayed in notification,  when WMS tries to deliver a consumable quantity that exceeds the OverDelivery Threshold set up in ST CustomWMSOverDeliveryResolution
        /// </summary>
        public const string CustomWMSOverDeliveryExceededTitle = "CustomWMSRequestOverDeliveryThresholdSurpassedTitle";

        /// <summary>
        /// Localized Message to be displayed in notification,  when WMS tries to deliver a consumable quantity that exceeds the OverDelivery Threshold set up in ST CustomWMSOverDeliveryResolution
        /// WMS tried to deliver a quantity ({0}) that exceeds the maximum threshold for over delivery ({1}), according to the set up laid down in Smart Table CustomWMSOverDeliveryResolution. The delivery was, therefore, rejected.
        /// </summary>
        public const string CustomWMSOverDeliveryExceeded = "CustomWMSRequestOverDeliveryThresholdSurpassedMessage";


        #endregion

    }
}
