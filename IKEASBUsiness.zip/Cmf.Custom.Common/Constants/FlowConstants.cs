﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Common
{
    public static partial class IKEAConstants
    {
        /// <summary>
        /// Attribute that contains the ERP Operation Code
        /// </summary>
        public const string ERPOperationCode = "ERPOperationCode";

        /// <summary>
        /// Localized Message to be displayed when the flow path in smart table CustomMaterialFlowResolution is not valid
        /// </summary>
        public const string CustomFlowPathNotValidMessage = "CustomFlowPathNotValid";

        /// <summary>
        /// Localised message to be displayed as feedback message when a flow is set effective
        /// </summary>
        public const string CustomVerifyFlowPathsInSmartTable = "CustomVerifyFlowPathsInSmartTable";
    }
}
