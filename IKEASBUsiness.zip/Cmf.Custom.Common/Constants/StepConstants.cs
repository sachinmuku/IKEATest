﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Common
{
    public static partial class IKEAConstants
    {
        #region Properties

        /// <summary>
        /// Property that contains the Processed Storage Service for the step
        /// </summary>
        public const string StepPropertyProcessedStorageService = "ProcessedStorageService";

        /// <summary>
        /// Property that contains the Processed Storage Service for the step
        /// </summary>
        public const string StepPropertyQueuedStorageService = "QueuedStorageService";

        #endregion

        #region Configurations

        /// <summary>
        /// Step Type - Scrap Room
        /// </summary>
        public const string ScrapRoomType = "/Cmf/Custom/Step/Types/ScrapRoom";

        #endregion

    }
}
