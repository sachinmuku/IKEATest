﻿using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Common
{
    public static partial class IKEAConstants
    {
        #region Attributes

        /// <summary>
        /// Operation tracking consumption log attribute that indicates the resource where the consumption took place:
        /// </summary>
        public const string CustomConsumptionLogAttributeConsumptionResource = "ConsumptionResource";

        /// <summary>
        /// Operation tracking consumption log attribute that indicates the resource where the consumption took place:
        /// </summary>
        public const string CustomAlternativeIdealCycleTime = "AlternativeIdealCycleTime";

        /// <summary>
        /// CustomERPOperationTracking attribute that indicates the quantity reportable to ERP:
        /// </summary>
        public const string CustomERPOperationTrackingAttributeOrderReportableQuantity = "OrderReportableQuantity";

        #endregion

        #region ReportOperationAt 

        /// <summary>
        /// Operation Tracking Report Operation At None
        /// </summary>
        public const string CustomERPReportOperationAtNone = "None";

        /// <summary>
        /// Operation Tracking Report Operation At OrderAbortOrStop
        /// </summary>
        public const string CustomERPReportOperationAtOrderAbortOrStop = "OrderAbortOrStop";

        /// <summary>
        /// Operation Tracking Report Operation At TrackOut
        /// </summary>
        public const string CustomERPReportOperationAtTrackOut = "TrackOut";
        /// <summary>
        /// Operation Tracking Report Operation At MoveNext
        /// </summary>
        public const string CustomERPReportOperationAtMoveNext = "MoveNext";

        /// <summary>
        /// Operation Tracking Report Palletization At MoveNext
        /// </summary>
        public const string CustomERPReportPalletizationAtMoveNext = "MoveNext";

        /// <summary>
        /// Operation Tracking Report Palletization At TrackOut
        /// </summary>
        public const string CustomERPReportPalletizationAtTrackOut = "TrackOut";

        #endregion

        #region LookupTable

        /// <summary>
        /// CustomERPReportOperationAt Lookup Table Name
        /// </summary>
        public const string CustomERPReportOperationAtLookupTable = "CustomERPReportOperationAt";

        /// <summary>
        /// CustomERPReportPalletizationAt Lookup Table Name
        /// </summary>
        public const string CustomERPReportPalletizationAtLookupTable = "CustomERPReportPalletizationAt";

        #endregion

    }
}
