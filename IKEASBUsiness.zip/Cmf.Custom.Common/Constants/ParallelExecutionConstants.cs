﻿namespace Cmf.Custom.IKEA.Common
{
    public static partial class IKEAConstants
    {

        #region Configs

        /// <summary>
        /// Separator used when sending multiple parallel product through recipe parameter
        /// </summary>
        public const string ParallelExecutionParallelProductSeparator = "/Cmf/Custom/ParallelExecution/ParallelProductSeparator";


        #endregion


        #region Constants

        /// <summary>
        /// Parallel Mode recipe parameter
        /// </summary>
        public const string ParallelModeRecipeParameter = "ParallelMode";

        /// <summary>
        /// Parallel Product recipe parameter
        /// </summary>
        public const string ParallelProductRecipeParameter = "ParallelProduct";

        #endregion

    }
}
