﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Common
{
    public static partial class IKEAConstants
    {

        #region General

        /// <summary>
        /// System PLM
        /// </summary>
        public const string PLMSystem = "PLM";

        /// <summary>
        /// DEE context parameter with the loaded XmlDocument to avoid having to parse the XML string twice
        /// </summary>
        public const string CustomPLMSyncProductXmlDocumentContextKey = "CustomPLMSyncProduct_XmlDocument";

        #endregion

        #region Localized Messages

        /// <summary>
        /// The message body did not contain a facility code for product creation/update.
        /// </summary>
        public const string CustomPLMMissingFacilityCodeProvidedLocalizedMessage = "CustomPLMMissingFacilityCodeProvided";

        /// <summary>
        /// The facility code {0} in the message body did not match any facility in MES.
        /// </summary>
        public const string CustomPLMInvalidFacilityCodeProvidedLocalizedMessage = "CustomPLMInvalidFacilityCodeProvided";

        /// <summary>
        /// No existing unit found with name \"{0}\" on Lookup Table {1}
        /// </summary>
        public const string CustomPLMInvalidUnitNameLocalizedMessage = "CustomPLMInvalidUnitName";
        #endregion

        #region Configurations

        /// <summary>
        /// Indicates if the PLM is active
        /// </summary>
        public const string CustomPLMIsActiveConfiguration = "/Cmf/Custom/PLM/IsActive";

        #endregion

        #region Tables

        /// <summary>
        /// Lookup table with the document types that can be imported by PLM
        /// </summary>
        public const string CustomPLMImportDocumentType = "CustomPLMImportDocumentType";

        /// <summary>
        /// Lookup table with the possible Document sources
        /// </summary>
        public const string CustomPLMImportDocumentSource = "CustomPLMImportDocumentSource";

        /// <summary>
        /// Generic table that lists the document types and if a conversion to pdf is needed while importing it into MES.
        /// </summary>
        public const string CustomPLMImportDocumentDefinitionGenericTable = "CustomPLMImportDocumentDefinition";

        /// <summary>
        /// Column name for document type in CustomPLMImportDocumentDefinition generic table.
        /// </summary>
        public const string CustomPLMImportDocumentDefinitionDocumentTypeColumn = "DocumentType";

        /// <summary>
        /// flag that indicates if the file type needs to be converted to Pdf
        /// </summary>
        public const string CustomPLMImportDocumentDefinitionConvertToPdfColumn = "ConvertToPdf";

        /// <summary>
        /// Smart table that allows to resolve the documents in MES.
        /// </summary>
        public const string CustomDocumentsContextSmartTable = "CustomDocumentsContext";

        /// <summary>
        /// Column name for Facility.
        /// </summary>
        public const string CustomDocumentsContextFacilityColumn = "Facility";

        /// <summary>
        /// Column name for Area.
        /// </summary>
        public const string CustomDocumentsContextAreaColumn = "Area";

        /// <summary>
        /// Column name for Area.
        /// </summary>
        public const string CustomDocumentsContextStepColumn = "Step";

        /// <summary>
        /// Column name for Resource.
        /// </summary>
        public const string CustomDocumentsContextResourceColumn = "Resource";

        /// <summary>
        /// Column name for ProductGroup.
        /// </summary>
        public const string CustomDocumentsContextProductGroupColumn = "ProductGroup";

        /// <summary>
        /// Column name for Product.
        /// </summary>
        public const string CustomDocumentsContextProductColumn = "Product";

        /// <summary>
        /// Column name for BOM.
        /// </summary>
        public const string CustomDocumentsContextBOMColumn = "BOM";

        /// <summary>
        /// Column name for Document.
        /// </summary>
        public const string CustomDocumentsContextDocumentColumn = "Document";

        /// <summary>
        /// Column name for DocumentSource.
        /// </summary>
        public const string CustomDocumentsContextDocumentSourceColumn = "DocumentSource";

        #endregion
    }
}
