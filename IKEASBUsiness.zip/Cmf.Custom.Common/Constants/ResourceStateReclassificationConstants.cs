﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cmf.Custom.IKEA.Common
{
    /// <summary>
    /// Contains the constants associated with the Cmf.Custom.IKEA.BusinessObjects.CustomResourceStateReclassification entity.
    /// </summary>
    public static class ResourceStateReclassificationConstants
    {
        #region Attributes

        /// <summary>
        ///  Name of the attribute that holds the state reclassification comment.
        /// </summary>
        public const string CustomCommentAttribute = "Comment";

        /// <summary>
        /// Name of the attribute that holds the detail of State Reclassification
        /// </summary>
        public const string StateReasonDetails = "StateReasonDetails";

        /// <summary>
        /// Name of the attribute that holds the working order of State Reclassification
        /// </summary>
        public const string WO = "WO";
        #endregion
    }
}
