﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Common
{
    public static partial class IKEAConstants
    {

        #region General

        /// <summary>
        /// Smart Table - LastServiceHistoryId
        /// </summary>
        public const string CustomSmartTableLastServiceHistoryId = "LastServiceHistoryId";

        /// <summary>
        /// Smart Table - LastOperationHistorySeq
        /// </summary>
        public const string CustomSmartTableLastOperationHistorySeq = "LastOperationHistorySeq";

        #endregion

        #region BOM Context

        /// <summary>
        /// Name of the Smart Table BOMContext
        /// </summary>
        public const string CustomSmartTableBOMContext = "BOMContext";

        /// <summary>
        /// Name of the Smart Table MaterialDurablesContext
        /// </summary>
        public const string MaterialDurablesContext = "MaterialDurablesContext";

        /// <summary>
        /// Name of the Smart Table MaterialDurablesContext
        /// </summary>
        public const string CustomMinimumConsumableQuantity = "CustomMinimumConsumableQuantity";

        /// <summary>
        /// Smart Table BOMContext - Product
        /// </summary>
        public const string CustomSmartTableBOMContextProduct = "Product";

        /// <summary>
        /// Smart Table BOMContext - BOM Context Id 
        /// </summary>
        public const string CustomSmartTableBOMContextId = "BOMContextId";

        #endregion

        #region CustomAutomaticPrintableDocumentContext

        /// <summary>
        /// Name of the smart table CustomAutomaticPrintableDocumentContext
        /// </summary>
        public const string CustomAutomaticPrintableDocumentContext = "CustomAutomaticPrintableDocumentContext";

        /// <summary>
        /// CustomAutomaticPrintableDocumentContext - Column - PrintingSequence
        /// </summary>
        public const string CustomAutomaticPrintableDocumentContextPrintingSequenceCol = "PrintingSequence";

        /// <summary>
        /// CustomAutomaticPrintableDocumentContext - Column - IsEnabled
        /// </summary>
        public const string CustomAutomaticPrintableDocumentContextIsEnabledCol = "IsEnabled";

        /// <summary>
        /// CustomAutomaticPrintableDocumentContext - Column - PrintableDocument
        /// </summary>
        public const string CustomAutomaticPrintableDocumentContextPrintableDocumentCol = "PrintableDocument";

        /// <summary>
        /// CustomAutomaticPrintableDocumentContext - Column - PrintSourceSplitMaterial
        /// </summary>
        public const string CustomAutomaticPrintableDocumentContextPrintSourceSplitMaterialCol = "PrintSourceSplitMaterial";

        /// <summary>
        /// CustomAutomaticPrintableDocumentContext - Column - Printer
        /// </summary>
        public const string CustomAutomaticPrintableDocumentContextPrinterCol = "Printer";

        /// <summary>
        /// Indicator to run the action after shipping
        /// </summary>
        public const string AutomaticPrintingSequenceAfterShipping = "AfterShipping";

        /// <summary>
        /// Indicator to run the action Before shipping
        /// </summary>
        public const string AutomaticPrintingSequenceBeforeShipping = "BeforeShipping";

        /// <summary>
        /// Indicator to run the action on Track Out
        /// </summary>
        public const string AutomaticPrintingSequenceOnTrackOut = "OnTrackOut";

        /// <summary>
        /// Indicator to run the action on Split
        /// </summary>
        public const string AutomaticPrintingSequenceOnSplit = "OnSplit";


        /// <summary>
        /// Indicator to run the action on Create
        /// </summary>
        public const string AutomaticPrintingSequenceOnCreate = "OnCreate";

        /// <summary>
        /// Indicator to run the action on Material ChangeType
        /// </summary>
        public const string AutomaticPrintingSequenceOnChangeType = "OnChangeType";


        /// <summary>
        /// Indicator to run the action on MaterialMerge
        /// </summary>
        public const string AutomaticPrintingSequenceOnMerge = "OnMerge";

        /// <summary>
        /// Indicator to run the action on MaterialMerge
        /// </summary>
        public const string AutomaticPrintingSequenceOnRetrieve = "OnRetrieve";

        /// <summary>
        /// Indicator to run the action on Detach
        /// </summary>
        public const string AutomaticPrintingSequenceOnDetach = "OnDetach";



        #endregion

        /// <summary>
        /// Name of the smart Table CustomMaterialFlowResolution
        /// </summary>
        public const string CustomMaterialFlowResolution = "CustomMaterialFlowResolution";

        /// <summary>
        /// Name of the smart table IntegrationHandlerResolution
        /// </summary>
        public const string IntegrationHandlerResolution = "IntegrationHandlerResolution";

        #region CustomNotificationResourcesChangeState

        /// <summary>
        /// Smart Table Name
        /// </summary>
        public const string CustomNotificationResourcesChangeState = "CustomNotificationResourcesChangeState";

        /// <summary>
        /// CustomNotificationResourcesChangeState - Facility
        /// </summary>
        public const string CustomNotificationResourcesChangeStateFacility = "Facility";

        /// <summary>
        /// CustomNotificationResourcesChangeState - Area
        /// </summary>
        public const string CustomNotificationResourcesChangeStateArea = "Area";

        /// <summary>
        /// CustomNotificationResourcesChangeState - Resource
        /// </summary>
        public const string CustomNotificationResourcesChangeStateResource = "Resource";

        /// <summary>
        /// CustomNotificationResourcesChangeState - ResourceType
        /// </summary>
        public const string CustomNotificationResourcesChangeStateResourceType = "ResourceType";

        /// <summary>
        /// CustomNotificationResourcesChangeState - Model
        /// </summary>
        public const string CustomNotificationResourcesChangeStateModel = "Model";

        /// <summary>
        /// CustomNotificationResourcesChangeState - InitialStateTransition
        /// </summary>
        public const string CustomNotificationResourcesChangeStateInitialStateTransition = "InitialStateTransition";

        /// <summary>
        /// CustomNotificationResourcesChangeState - FinalStateTransition
        /// </summary>
        public const string CustomNotificationResourcesChangeStateFinalStateTransition = "FinalStateTransition";

        /// <summary>
        /// CustomNotificationResourcesChangeState - Role
        /// </summary>
        public const string CustomNotificationResourcesChangeStateRole = "Role";

        /// <summary>
        /// CustomNotificationResourcesChangeState - DistributionList
        /// </summary>
        public const string CustomNotificationResourcesChangeStateDistributionList = "DistributionList";

        #endregion

        #region CustomValidateMaterialReplenishmentRequestConfiguration
        /// <summary>
        /// Smart Table Name
        /// </summary>
        public const string CustomValidateMaterialReplenishmentRequestConfiguration = "CustomValidateMaterialReplenishmentRequestConfiguration";

        #endregion

        /// <summary>
        /// Name of the smart table CustomAutoDispatchExceptionBehavior
        /// </summary>
        public const string CustomAutoDispatchExceptionBehavior = "CustomAutoDispatchExceptionBehavior";

        /// <summary>
        /// Column Behavior in smart table CustomAutoDispatchExceptionBehavior
        /// </summary>
        public const string BehaviorColumn = "Behavior";

        /// <summary>
        /// Column Eventin smart table CustomMaterialMovementConfiguration
        /// </summary>
        public const string EventColumn = "Event";

        #region CustomMaximumAllowedPostpone

        /// <summary>
        /// Smart Table Name
        /// </summary>
        public const string CustomMaximumAllowedPostpone = "CustomMaximumAllowedPostpone";

        /// <summary>
        /// CustomMaximumAllowedPostpone - Facility
        /// </summary>
        public const string CustomMaximumAllowedPostponeFacility = "Facility";

        /// <summary>
        /// CustomMaximumAllowedPostpone - Area
        /// </summary>
        public const string CustomMaximumAllowedPostponeArea = "Area";

        /// <summary>
        /// CustomMaximumAllowedPostpone - Step
        /// </summary>
        public const string CustomMaximumAllowedPostponeStep = "Step";

        /// <summary>
        /// CustomMaximumAllowedPostpone - Resource
        /// </summary>
        public const string CustomMaximumAllowedPostponeResource = "Resource";

        /// <summary>
        /// CustomMaximumAllowedPostpone - Maximum Allowed Postpone
        /// </summary>
        public const string CustomMaximumAllowedPostponeMaximumAllowedPostpone = "MaximumAllowedPostpone";

        #endregion

        #region MaximumAllowedRework

        /// <summary>
        /// CustomMaximumAllowedReworks - Maximum allowed Rework value 
        /// </summary>
        public const string CustomMaximumAllowedReworks = "MaximumAllowedRework";

        /// <summary>
        /// CustomMaximumAllowedRework - Table Name
        /// </summary>
        public const string CustomMaximumAllowedReworkSmartTable = "CustomMaximumAllowedReworks";

        #endregion

        #region SPC SmartTable

        /// <summary>
        /// Name of the smart table CustomSPCNotifications
        /// </summary>
        public const string CustomSPCNotifications = "CustomSPCNotifications";

        /// <summary>
        /// Name of the smart table CustomSPCViolationActions
        /// </summary>
        public const string CustomSPCViolationActions = "CustomSPCViolationActions";

        #endregion

        #region Localized Messages

        /// <summary>
        /// At least one of the fields '{0}' and '{1}' must be specified.
        /// </summary>
        public const string CustomValidateMaterialReplenishmentRequestMissingFieldsLocalizedMessage = "CustomValidateMaterialReplenishmentRequestMissingFields";


        /// <summary>
        /// It's not possible to create/update this record due to have a match record on Custom Alternative Ideal Cycle Times table.
        /// </summary>
        public const string CustomPreventUpdateResourceIdealCycleTimeDirectlyErrorLocalizedMessage = "CustomPreventUpdateResourceIdealCycleTimeDirectlyError";

        /// <summary>
        /// No data retrieved in {0} smart table with the following parameter(s) {1}.
        /// </summary>
        public const string CustomNoDataRetrievedSmartTableParametersLocalizedMessage = "CustomNoDataRetrievedSmartTableParameters";



        #endregion

        #region CustomDefaultCompletionQuantity

        /// <summary>
        /// Name of the smart table responsible for determining default capacity per pallets upon palletization
        /// </summary>
        public const string CustomDefaultCompletionQuantitySmartTable = "CustomDefaultCompletionQuantity";

        /// <summary>
        /// Smart Table CustomDefaultCompletionQuantity Column Product
        /// </summary>
        public const string CustomDefaultCompletionQuantityProductColumn = "Product";

        /// <summary>
        /// Smart Table CustomDefaultCompletionQuantity Column Facility
        /// </summary>
        public const string CustomDefaultCompletionQuantityFacilityColumn = "Facility";

        /// <summary>
        /// Smart Table CustomDefaultCompletionQuantity Column Resource
        /// </summary>
        public const string CustomDefaultCompletionQuantityResourceColumn = "Resource";

        /// <summary>
        /// Smart Table CustomDefaultCompletionQuantity Column DefaultQuantity
        /// </summary>
        public const string CustomDefaultCompletionQuantityDefaultQuantityColumn = "DefaultQuantity";


        #endregion CustomDefaultCompletionQuantity

        #region CustomDirectRepairResolution

        /// <summary>
        /// Name of the smart table responsible for determining the DirectRepair mode for the line
        /// </summary>
        public const string CustomDirectRepairResolutionSmartTable = "CustomDirectRepairResolution";

        /// <summary>
        /// Smart Table CustomDirectRepairResolution Column Facility
        /// </summary>
        public const string CustomDirectRepairResolutionFacilityColumn = "Facility";

        /// <summary>
        /// Smart Table CustomDirectRepairResolution Column Area
        /// </summary>
        public const string CustomDirectRepairResolutionAreaColumn = "Area";

        /// <summary>
        /// Smart Table CustomDirectRepairResolution Column Resource
        /// </summary>
        public const string CustomDirectRepairResolutionResourceColumn = "Resource";

        /// <summary>
        /// Smart Table CustomDirectRepairResolution Column InLine
        /// </summary>
        public const string CustomDirectRepairResolutionInLineColumn = "InLine";

        /// <summary>
        /// Smart Table CustomDirectRepairResolution Column ConsumptionStep
        /// </summary>
        public const string CustomDirectRepairResolutionConsumptionStepColumn = "ConsumptionStep";

        #endregion CustomDirectRepairResolution

        #region CustomProductIterationHandler

        /// <summary>
        /// Name of the smart table responsible for determining the number pf iterations that a product must perform for completing a process
        /// </summary>
        public const string CustomProductIterationHandlerSmartTable = "CustomProductIterationHandler";

        /// <summary>
        /// Smart Table CustomProductIterationHandler Column Facility
        /// </summary>
        public const string CustomProductIterationHandlerFacilityColumn = "Facility";

        /// <summary>
        /// Smart Table CustomProductIterationHandler Column Area
        /// </summary>
        public const string CustomProductIterationHandlerAreaColumn = "Area";

        /// <summary>
        /// Smart Table CustomProductIterationHandler Column Resource
        /// </summary>
        public const string CustomProductIterationHandlerResourceColumn = "Resource";

        /// <summary>
        /// Smart Table CustomProductIterationHandler Column ProductGroup
        /// </summary>
        public const string CustomProductIterationHandlerProductGroupColumn = "ProductGroup";

        /// <summary>
        /// Smart Table CustomProductIterationHandler Column Product
        /// </summary>
        public const string CustomProductIterationHandlerProductColumn = "Product";

        /// <summary>
        /// Smart Table CustomProductIterationHandler Column MaxIterations
        /// </summary>
        public const string CustomProductIterationHandlerMaxIterationsColumn = "MaxIterations";

        /// <summary>
        /// Smart Table CustomProductIterationHandler Column ConsumptionStep
        /// </summary>
        public const string CustomProductIterationHandlerConsumptionStepColumn = "ConsumptionStep";

        #endregion CustomDirectRepairResolution

        #region CustomForceOrderCompletionResolution
        /// <summary>
        /// Name of the smart table responsible for determining process loss on ForceOrderCompletion
        /// </summary>
        public const string CustomProcessLossForceOrderCompleteExceptionBehaviorSmartTable = "CustomProcessLossForceOrderCompleteExceptionBehavior";
        #endregion

        #region CustomOverProductionResolution

        /// <summary>
        /// Name of the smart table responsible for determining overproduction quantity and percentage
        /// </summary>
        public const string CustomOverProductionResolutionSmartTable = "CustomOverProductionResolution";

        #endregion

        #region CustomResourceStateReclassificationPermissions

        /// <summary>
        /// Name of the smart table responsible for determining the allowed state reclassifications
        /// </summary>
        public const string CustomResourceStateReclassificationPermissionsSmartTable = "CustomResourceStateReclassificationPermissions";

        /// <summary>
        /// Smart Table CustomResourceStateReclassificationPermissionsSmartTable Column Role
        /// </summary>
        public const string CustomResourceStateReclassificationPermissionsRoleColumn = "Role";

        /// <summary>
        /// Smart Table CustomResourceStateReclassificationPermissionsSmartTable Column StateModel
        /// </summary>
        public const string CustomResourceStateReclassificationPermissionsStateModelColumn = "StateModel";

        /// <summary>
        /// Smart Table CustomResourceStateReclassificationPermissionsSmartTable Column StateFrom
        /// </summary>
        public const string CustomResourceStateReclassificationPermissionsStateFromColumn = "StateFrom";

        /// <summary>
        /// Smart Table CustomResourceStateReclassificationPermissionsSmartTable Column ReasonFrom
        /// </summary>
        public const string CustomResourceStateReclassificationPermissionsReasonFromColumn = "ReasonFrom";

        /// <summary>
        /// Smart Table CustomResourceStateReclassificationPermissionsSmartTable Column StateTo
        /// </summary>
        public const string CustomResourceStateReclassificationPermissionsStateToColumn = "StateTo";

        /// <summary>
        /// Smart Table CustomResourceStateReclassificationPermissionsSmartTable Column ReasonTo
        /// </summary>
        public const string CustomResourceStateReclassificationPermissionsReasonToColumn = "ReasonTo";

        /// <summary>
        /// Smart Table CustomResourceStateReclassificationPermissionsSmartTable Column AllowsPastReclassifications
        /// </summary>
        public const string CustomResourceStateReclassificationPermissionsAllowsPastReclassificationsColumn = "AllowsPastReclassifications";

        /// <summary>
        /// Smart Table CustomResourceStateReclassificationPermissionsSmartTable Column EnforceComment
        /// </summary>
        public const string CustomResourceStateReclassificationPermissionsEnforceCommentColumn = "EnforceComment";

        /// <summary>
        /// Smart Table CustomResourceStateReclassificationPermissionsSmartTable Column TimeAtState
        /// </summary>
        public const string CustomResourceStateReclassificationPermissionsTimeAtStateColumn = "TimeAtState";

        #endregion

        #region CustomMinimumConsumableQuantity

        /// <summary>
        /// Name of the smart table responsible for determining if there are minimum quantities to ensure in the feeders
        /// </summary>
        public const string CustomMinimumConsumableQuantitySmartTable = "CustomMinimumConsumableQuantity";

        /// <summary>
        /// Smart Table CustomMinimumConsumableQuantity Column ProductType
        /// </summary>
        public const string CustomMinimumConsumableQuantityProductTypeColumn = "ProductType";

        /// <summary>
        /// Smart Table CustomMinimumConsumableQuantity Column NumberOfPallets
        /// </summary>
        public const string CustomMinimumConsumableQuantityNumberOfPalletsColumn = "NumberOfPallets";

        #endregion

        #region CustomAlarmCategoryBreakdown

        /// <summary>
        /// Name of the smart table responsible for determining if there are minimum quantities to ensure in the feeders
        /// </summary>
        public const string CustomAlarmCategoryBreakdownSmartTable = "CustomAlarmCategoryBreakdown";

        /// <summary>
        /// Smart Table CustomAlarmCategoryBreakdown Column Facility
        /// </summary>
        public const string CustomAlarmCategoryBreakdownFacilityColumn = "Facility";

        /// <summary>
        /// Smart Table CustomAlarmCategoryBreakdown Column Area
        /// </summary>
        public const string CustomAlarmCategoryBreakdownAreaColumn = "Area";

        /// <summary>
        /// Smart Table CustomAlarmCategoryBreakdown Column ResourceType
        /// </summary>
        public const string CustomAlarmCategoryBreakdownResourceTypeColumn = "ResourceType";

        /// <summary>
        /// Smart Table CustomAlarmCategoryBreakdown Column Resource
        /// </summary>
        public const string CustomAlarmCategoryBreakdownResourceColumn = "Resource";

        /// <summary>
        /// Smart Table CustomAlarmCategoryBreakdown Column LineControllerCategory
        /// </summary>
        public const string CustomAlarmCategoryBreakdownLineControllerCategoryColumn = "LineControllerCategory";

        /// <summary>
        /// Smart Table CustomAlarmCategoryBreakdown Column Category
        /// </summary>
        public const string CustomAlarmCategoryBreakdownCategoryColumn = "Category";

        /// <summary>
        /// Smart Table CustomAlarmCategoryBreakdown Column Type
        /// </summary>
        public const string CustomAlarmCategoryBreakdownTypeColumn = "Type";

        /// <summary>
        /// Smart Table CustomAlarmCategoryBreakdown Column Severity
        /// </summary>
        public const string CustomAlarmCategoryBreakdownSeverityColumn = "Severity";

        #endregion

        #region CustomStepDefectsValidation

        /// <summary>
        /// Name of the smart table responsible for efore allowing the material to go to the next step, the DEE will check if the smart table has any configuration that indicates if the material should be validated before going to the next step.
        /// </summary>
        public const string CustomStepDefectsValidationSmartTable = "CustomStepDefectsValidation";

        /// <summary>
        /// Smart Table CustomStepDefectsValidation Column Facility
        /// </summary>
        public const string CustomStepDefectsValidationFacilityColumn = "Facility";

        /// <summary>
        /// Smart Table CustomStepDefectsValidation Column Area
        /// </summary>
        public const string CustomStepDefectsValidationAreaColumn = "Area";

        /// <summary>
        /// Smart Table CustomStepDefectsValidation Column Resource
        /// </summary>
        public const string CustomStepDefectsValidationResourceColumn = "Resource";

        /// <summary>
        /// Smart Table CustomStepDefectsValidation Column StepType
        /// </summary>
        public const string CustomStepDefectsValidationStepTypeColumn = "StepType";

        /// <summary>
        /// Smart Table CustomStepDefectsValidation Column Step
        /// </summary>
        public const string CustomStepDefectsValidationStepColumn = "Step";

        /// <summary>
        /// Smart Table CustomStepDefectsValidation Column MaterialType
        /// </summary>
        public const string CustomStepDefectsValidationMaterialTypeColumn = "MaterialType";

        /// <summary>
        /// Smart Table CustomStepDefectsValidation Column EnforceClassification
        /// </summary>
        public const string CustomStepDefectsValidationEnforceClassificationColumn = "EnforceClassification";

        #endregion

        #region CustomERPReportingResolution

        /// <summary>
        /// Name of the smart table that sets the automatic reporting of consumption, operations and pallet completion to the ERP.
        /// </summary>
        public const string CustomERPReportingResolutionSmartTable = "CustomERPReportingResolution";

        /// <summary>
        /// Smart Table CustomERPReportingResolution Column Facility
        /// </summary>
        public const string CustomERPReportingResolutionFacilityColumn = "Facility";

        /// <summary>
        /// Smart Table CustomERPReportingResolution Column Area
        /// </summary>
        public const string CustomERPReportingResolutionAreaColumn = "Area";

        /// <summary>
        /// Smart Table CustomERPReportingResolution Column Resource
        /// </summary>
        public const string CustomERPReportingResolutionResourceColumn = "Resource";

        /// <summary>
        /// Smart Table CustomERPReportingResolution Column Step
        /// </summary>
        public const string CustomERPReportingResolutionStepColumn = "Step";

        /// <summary>
        /// Smart Table CustomERPReportingResolution Column ReportConsumption
        /// </summary>
        public const string CustomERPReportingResolutionReportConsumptionColumn = "ReportConsumption";

        /// <summary>
        /// Smart Table CustomERPReportingResolution Column ReportOperation
        /// </summary>
        public const string CustomERPReportingResolutionReportOperationColumn = "ReportOperation";

        /// <summary>
        /// Smart Table CustomERPReportingResolution Column ReportOperationAt
        /// </summary>
        public const string CustomERPReportingResolutionReportOperationAtColumn = "ReportOperationAt";

        /// <summary>
        /// Smart Table CustomERPReportingResolution Column ReportPalletization
        /// </summary>
        public const string CustomERPReportingResolutionReportPalletizationColumn = "ReportPalletization";

        /// <summary>
        /// Smart Table CustomERPReportingResolution Column ReportPalletizationAt
        /// </summary>
        public const string CustomERPReportingResolutionReportPalletizationAtColumn = "ReportPalletizationAt";

        #endregion

        #region CustomExpirationDateRequirementContextSmartTable

        /// <summary>
        /// Name of the smart table that indicates if the expiration date is mandatory or not.
        /// </summary>
        public const string CustomExpirationDateRequirementContextSmartTable = "CustomExpirationDateRequirementContext";

        /// <summary>
        /// Smart Table CustomExpirationDateRequirementContext Column Facility
        /// </summary>
        public const string CustomExpirationDateRequirementContextFacilityColumn = "Facility";

        /// <summary>
        /// Smart Table CustomExpirationDateRequirementContext Column Area
        /// </summary>
        public const string CustomExpirationDateRequirementContextAreaColumn = "Area";

        /// <summary>
        /// Smart Table CustomExpirationDateRequirementContext Column Resource
        /// </summary>
        public const string CustomExpirationDateRequirementContextResourceColumn = "Resource";

        /// <summary>
        /// Smart Table CustomExpirationDateRequirementContext Column Product
        /// </summary>
        public const string CustomExpirationDateRequirementContextProductColumn = "Product";

        /// <summary>
        /// Smart Table CustomExpirationDateRequirementContext Column IsMandatory
        /// </summary>
        public const string CustomExpirationDateRequirementContextIsMandatoryColumn = "IsMandatory";

        #endregion

        #region CustomAlarmTrackingConfigurationSmartTable

        /// <summary>
        /// Name of the smart table responsible for determining if it is necessary to keep a log of an alarm sent by the IoT.
        /// </summary>
        public const string CustomAlarmTrackingConfigurationSmartTable = "CustomAlarmTrackingConfiguration";

        /// <summary>
        /// Smart Table CustomAlarmTrackingConfiguration Column Facility
        /// </summary>
        public const string CustomAlarmTrackingConfigurationFacilityColumn = "Facility";

        /// <summary>
        /// Smart Table CustomAlarmTrackingConfiguration Column Area
        /// </summary>
        public const string CustomAlarmTrackingConfigurationAreaColumn = "Area";

        /// <summary>
        /// Smart Table CustomAlarmTrackingConfiguration Column Resource
        /// </summary>
        public const string CustomAlarmTrackingConfigurationResourceColumn = "Resource";

        /// <summary>
        /// Smart Table CustomAlarmTrackingConfiguration Column AlarmCode
        /// </summary>
        public const string CustomAlarmTrackingConfigurationAlarmCodeColumn = "AlarmCode";

        /// <summary>
        /// Smart Table CustomAlarmTrackingConfiguration Column Category
        /// </summary>
        public const string CustomAlarmTrackingConfigurationCategoryColumn = "Category";

        /// <summary>
        /// Smart Table CustomAlarmTrackingConfiguration Column Log
        /// </summary>
        public const string CustomAlarmTrackingConfigurationLogColumn = "Log";

        #endregion

        #region CustomAlarmHandlingActionsSmartTable

        /// <summary>
        /// Name of the smart table CustomAlarmHandlingActions
        /// </summary>
        public const string CustomAlarmHandlingActionsSmartTable = "CustomAlarmHandlingActions";

        /// <summary>
        /// Name of CustomAlarmHandlingActions Column Facility.
        /// </summary>
        public const string CustomAlarmHandlingActionsFacilityColumn = "Facility";

        /// <summary>
        /// Name of CustomAlarmHandlingActions Column Area.
        /// </summary>
        public const string CustomAlarmHandlingActionsAreaColumn = "Area";

        /// <summary>
        /// Name of CustomAlarmHandlingActions Column Resource.
        /// </summary>
        public const string CustomAlarmHandlingActionsResourceColumn = "Resource";

        /// <summary>
        /// Name of CustomAlarmHandlingActions Column AlarmCode.
        /// </summary>
        public const string CustomAlarmHandlingActionsAlarmCodeColumn = "AlarmCode";

        /// <summary>
        /// Name of CustomAlarmHandlingActions Column Category.
        /// </summary>
        public const string CustomAlarmHandlingActionsCategoryColumn = "Category";

        /// <summary>
        /// Name of CustomAlarmHandlingActions Column MESNotification.
        /// </summary>
        public const string CustomAlarmHandlingActionsMESNotificationColumn = "MESNotification";

        /// <summary>
        /// Name of CustomAlarmHandlingActions Column EmailNotification.
        /// </summary>
        public const string CustomAlarmHandlingActionsEmailNotificationColumn = "EmailNotification";

        /// <summary>
        /// Name of CustomAlarmHandlingActions Column NotifyCheckedInEmployees.
        /// </summary>
        public const string CustomAlarmHandlingActionsNotifyCheckedInEmployeesColumn = "NotifyCheckedInEmployees";

        /// <summary>
        /// Name of CustomAlarmHandlingActions Column NotificationRole.
        /// </summary>
        public const string CustomAlarmHandlingActionsNotificationRoleColumn = "NotificationRole";

        /// <summary>
        /// Name of CustomAlarmHandlingActions Column BlockFeeder.
        /// </summary>
        public const string CustomAlarmHandlingActionsBlockFeederColumn = "BlockFeeder";

        /// <summary>
        /// Name of CustomAlarmHandlingActions Column BlockProducedUnits.
        /// </summary>
        public const string CustomAlarmHandlingActionsBlockProducedUnitsColumn = "BlockProducedUnits";

        /// <summary>
        /// Name of CustomAlarmHandlingActions Column MaintenanceActivity.
        /// </summary>
        public const string CustomAlarmHandlingActionsMaintenanceActivityColumn = "MaintenanceActivity";

        /// <summary>
        /// Name of the column OEEState of smart table CustomAlarmHandlingActions
        /// </summary>
        public const string CustomAlarmHandlingActionsOEEStateColumn = "OEEState";

        /// <summary>
        /// Name of the column OEEStateReason of smart table CustomAlarmHandlingActions
        /// </summary>
        public const string CustomAlarmHandlingActionsOEEStateReasonColumn = "OEEStateReason";

        #endregion

        #region CustomAlternativeIdealCycleTimesSmartTable

        /// <summary>
        /// Name of the smart table to resove the custom alternative ideal cycle times
        /// </summary>
        public const string CustomAlternativeIdealCycleTimesSmartTable = "CustomAlternativeIdealCycleTimes";

        /// <summary>
        /// Smart Table CustomAlternativeIdealCycleTimes Column Resource
        /// </summary>
        public const string CustomAlternativeIdealCycleTimesResourceColumn = "Resource";

        /// <summary>
        /// Smart Table CustomAlternativeIdealCycleTimes Column ResourceType
        /// </summary>
        public const string CustomAlternativeIdealCycleTimesResourceTypeColumn = "ResourceType";

        /// <summary>
        /// Smart Table CustomAlternativeIdealCycleTimes Column Model
        /// </summary>
        public const string CustomAlternativeIdealCycleTimesModelColumn = "Model";

        /// <summary>
        /// Smart Table CustomAlternativeIdealCycleTimes Column Step
        /// </summary>
        public const string CustomAlternativeIdealCycleTimesStepColumn = "Step";

        /// <summary>
        /// Smart Table CustomAlternativeIdealCycleTimes Column Product
        /// </summary>
        public const string CustomAlternativeIdealCycleTimesProductColumn = "Product";

        /// <summary>
        /// Smart Table CustomAlternativeIdealCycleTimes Column ProductGroup
        /// </summary>
        public const string CustomAlternativeIdealCycleTimesProductGroupColumn = "ProductGroup";

        /// <summary>
        /// Smart Table CustomAlternativeIdealCycleTimes Column StructureType
        /// </summary>
        public const string CustomAlternativeIdealCycleTimesStructureTypeColumn = "StructureType";

        /// <summary>
        /// Smart Table CustomAlternativeIdealCycleTimes Column AlternativeTimeScale
        /// </summary>
        public const string CustomAlternativeIdealCycleTimesAlternativeTimeScaleColumn = "AlternativeTimeScale";

        /// <summary>
        /// Smart Table CustomAlternativeIdealCycleTimes Column AlternativeTimePerUnit
        /// </summary>
        public const string CustomAlternativeIdealCycleTimesAlternativeTimePerUnitColumn = "AlternativeTimePerUnit";

        #endregion

        #region ResourceIdealCycleTimeSmartTable

        /// <summary>
        /// Name of the smart table to resove the Resource Ideal CycleTime
        /// </summary>
        public const string ResourceIdealCycleTimeSmartTable = "ResourceIdealCycleTime";

        /// <summary>
        /// Smart Table ResourceIdealCycleTime Column Resource
        /// </summary>
        public const string ResourceIdealCycleTimeIdColumn = "ResourceIdealCycleTimeId";

        /// <summary>
        /// Smart Table ResourceIdealCycleTime Column Resource
        /// </summary>
        public const string ResourceIdealCycleTimeResourceColumn = "Resource";

        /// <summary>
        /// Smart Table ResourceIdealCycleTime Column ResourceType
        /// </summary>
        public const string ResourceIdealCycleTimeResourceTypeColumn = "ResourceType";

        /// <summary>
        /// Smart Table ResourceIdealCycleTime Column Model
        /// </summary>
        public const string ResourceIdealCycleTimeModelColumn = "Model";

        /// <summary>
        /// Smart Table ResourceIdealCycleTime Column Step
        /// </summary>
        public const string ResourceIdealCycleTimeStepColumn = "Step";

        /// <summary>
        /// Smart Table ResourceIdealCycleTime Column Product
        /// </summary>
        public const string ResourceIdealCycleTimeProductColumn = "Product";

        /// <summary>
        /// Smart Table ResourceIdealCycleTime Column ProductGroup
        /// </summary>
        public const string ResourceIdealCycleTimeProductGroupColumn = "ProductGroup";

        /// <summary>
        /// Smart Table ResourceIdealCycleTime Column TimeScale
        /// </summary>
        public const string ResourceIdealCycleTimeTimeScaleColumn = "TimeScale";

        /// <summary>
        /// Smart Table ResourceIdealCycleTime Column TimePerUnit
        /// </summary>
        public const string ResourceIdealCycleTimeTimePerUnitColumn = "TimePerUnit";

        /// <summary>
        /// Smart Table ResourceIdealCycleTime Column IsReference
        /// </summary>
        public const string ResourceIdealCycleTimeIsReferenceColumn = "IsReference";

        #endregion

        #region CustomMAOHandlingOEEStateSmartTable

        /// <summary>
        /// Name of the smart table CustomMAOHandlingOEEState
        /// </summary>
        public const string CustomMAOHandlingOEEState = "CustomMAOHandlingOEEState";

        /// <summary>
        /// Name of the column facility of smart table CustomMAOHandlingOEEState
        /// </summary>
        public const string CustomMAOHandlingOEEStateFacilityColumn = "Facility";

        /// <summary>
        /// Name of the column Area of smart table CustomMAOHandlingOEEState
        /// </summary>
        public const string CustomMAOHandlingOEEStateAreaColumn = "Area";

        /// <summary>
        /// Name of the column Resource of smart table CustomMAOHandlingOEEState
        /// </summary>
        public const string CustomMAOHandlingOEEStateResourceColumn = "Resource";

        /// <summary>
        /// Name of the column MAOType of smart table CustomMAOHandlingOEEState
        /// </summary>
        public const string CustomMAOHandlingOEEStateMAOType = "MAOType";

        /// <summary>
        /// Name of the column OEEState of smart table CustomMAOHandlingOEEState
        /// </summary>
        public const string CustomMAOHandlingOEEStateOEEStateColumn = "OEEState";

        /// <summary>
        /// Name of the column OEEStateReason of smart table CustomMAOHandlingOEEState
        /// </summary>
        public const string CustomMAOHandlingOEEStateOEEStateReasonColumn = "OEEStateReason";

        #endregion

        #region CustomDirectFeedingRecipeModeSmartTable

        /// <summary>
        /// Name of the smart table responsible for determining if there are minimum quantities to ensure in the feeders
        /// </summary>
        public const string CustomDirectFeedingRecipeModeSmartTable = "CustomDirectFeedingRecipeMode";

        /// <summary>
        /// Smart Table CustomDirectFeedingRecipeMode Column Resource
        /// </summary>
        public const string CustomDirectFeedingRecipeModeColumnResource = "Resource";

        /// <summary>
        /// Smart Table CustomDirectFeedingRecipeMode Column Recipe
        /// </summary>
        public const string CustomDirectFeedingRecipeModeColumnRecipe = "Recipe";

        /// <summary>
        /// Smart Table CustomDirectFeedingRecipeMode Column DirectFeedingMode
        /// </summary>
        public const string CustomDirectFeedingRecipeModeColumnDirectFeedingMode = "DirectFeedingMode";


        #endregion CustomDirectFeedingRecipeMode

        #region CustomResourceStateModelAndReason

        /// <summary>
        /// Name of the Smart Table responsible for determining the available States and Reasons for a given Facility/Area/Resource
        /// </summary>
        public const string CustomResourceStateModelAndReasonSmartTable = "CustomResourceStateModelAndReason";

        /// <summary>
        /// Smart Table CustomResourceStateModelAndReason column 'Facility'
        /// </summary>
        public const string CustomResourceStateModelAndReasonColumnFacility = "Facility";

        /// <summary>
        /// Smart Table CustomResourceStateModelAndReason column 'Area'
        /// </summary>
        public const string CustomResourceStateModelAndReasonColumnArea = "Area";

        /// <summary>
        /// Smart Table CustomResourceStateModelAndReason column 'Resource'
        /// </summary>
        public const string CustomResourceStateModelAndReasonColumnResource = "Resource";

        /// <summary>
        /// Smart Table CustomResourceStateModelAndReason column 'State'
        /// </summary>
        public const string CustomResourceStateModelAndReasonColumnState = "State";

        /// <summary>
        /// Smart Table CustomResourceStateModelAndReason column 'Reason'
        /// </summary>
        public const string CustomResourceStateModelAndReasonColumnReason = "Reason";

        #endregion

        #region CustomParallelExecutionRecipeMode

        /// <summary>
        /// Name of the smart table responsible for determining the products ready for parallel execution and its linked products
        /// </summary>
        public const string CustomParallelExecutionRecipeModeSmartTable = "CustomParallelExecutionRecipeMode";

        /// <summary>
        /// Smart Table CustomParallelExecutionRecipeMode Column Resource
        /// </summary>
        public const string CustomParallelExecutionRecipeModeColumnResource = "Resource";

        /// <summary>
        /// Smart Table CustomParallelExecutionRecipeMode Column Product
        /// </summary>
        public const string CustomParallelExecutionRecipeModeColumnProduct = "Product";

        /// <summary>
        /// Smart Table CustomParallelExecutionRecipeMode Column Recipe
        /// </summary>
        public const string CustomParallelExecutionRecipeModeColumnRecipe = "Recipe";

        /// <summary>
        /// Smart Table CustomParallelExecutionRecipeMode Column ParallelProduct
        /// </summary>
        public const string CustomParallelExecutionRecipeModeColumnParallelProduct = "ParallelProduct";

        #endregion CustomParallelExecutionRecipeMode

        #region CustomERPReportablePalletTypes

        /// <summary>
        /// Name of the smart table responsible for determining what pallet types should be reported to ERP
        /// </summary>
        public const string CustomERPReportablePalletTypesSmartTable = "CustomERPReportablePalletTypes";

        /// <summary>
        /// Smart Table CustomERPReportablePalletTypes Column Facility
        /// </summary>
        public const string CustomERPReportablePalletTypesCollumnFacility = "Facility";

        /// <summary>
        /// Smart Table CustomERPReportablePalletTypes Column Area
        /// </summary>
        public const string CustomERPReportablePalletTypesCollumnArea = "Area";

        /// <summary>
        /// Smart Table CustomERPReportablePalletTypes Column Resource
        /// </summary>
        public const string CustomERPReportablePalletTypesCollumnResource = "Resource";

        /// <summary>
        /// Smart Table CustomERPReportablePalletTypes Column MaterialType
        /// </summary>
        public const string CustomERPReportablePalletTypesCollumnMaterialType = "MaterialType";

        /// <summary>
        /// Smart Table CustomERPReportablePalletTypes Column IsOperationTrackingReportable
        /// </summary>
        public const string CustomERPReportablePalletTypesCollumnOperationTracking = "IsOperationTrackingReportable";

        /// <summary>
        /// Smart Table CustomERPReportablePalletTypes Column IsERPUnitCompleteReportable
        /// </summary>
        public const string CustomERPReportablePalletTypesCollumnUnitComplete = "IsERPUnitCompleteReportable";


        #endregion CustomERPReportablePalletTypes

        /// <summary>
        /// DEE context parameter indicating the validation on CustomPreventUpdateResourceIdealCycleTimeDirectly will be not taken in place
        /// </summary>
        public const string CustomPreventUpdateResourceIdealCycleTimeDirectlyContextKey = "CustomPreventUpdateResourceIdealCycleTimeDirectly_SkipValidation";
    }
}
