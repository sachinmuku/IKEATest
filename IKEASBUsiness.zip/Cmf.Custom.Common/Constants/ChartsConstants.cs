﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cmf.Custom.IKEA.Common
{
    public static partial class IKEAConstants
    {

        #region Attributes

        /// <summary>
        /// LogicalChart - LastNotificationDate
        /// </summary>
        public const string LogicalChartLastNotificationDateAttribute = "LastNotificationDate";

        #endregion

        #region Generic tables

        /// <summary>
        /// Generic Table Name -  CustomManualDataPostingNotifications
        /// </summary>
        public const string CustomManualDataPostingNotifications = "CustomManualDataPostingNotifications";

        #endregion
    }
}
