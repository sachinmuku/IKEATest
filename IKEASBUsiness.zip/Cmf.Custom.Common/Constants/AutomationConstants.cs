﻿namespace Cmf.Custom.IKEA.Common
{
    /// <summary>
    /// This file contains constants related with the automation
    /// </summary>
    public partial class IKEAConstants
    {

        #region Json Fields

        /// <summary>
        /// MO Name (Id)
        /// </summary>
        public const string DownloadOrderToAutomationMOName = "MOID";

        /// <summary>
        /// Base Product
        /// </summary>
        public const string DownloadOrderToAutomationBaseProduct = "REFERENZ";

        /// <summary>
        /// Primary Quantity
        /// </summary>
        public const string DownloadOrderToAutomationPrimaryQuantity = "STUECK";

        /// <summary>
        /// Date
        /// </summary>
        public const string DownloadOrderToAutomationDate = "DATUM";

        /// <summary>
        /// User Name
        /// </summary>
        public const string DownloadOrderToAutomationUserName = "BENUTZER";

        /// <summary>
        /// Comment 1
        /// </summary>
        public const string DownloadOrderToAutomationComment1 = "KOMMENTAR1";

        /// <summary>
        /// Comment 2
        /// </summary>
        public const string DownloadOrderToAutomationComment2 = "KOMMENTAR2";

        /// <summary>
        /// Finished Length
        /// </summary>
        public const string DownloadOrderToAutomationFinishedLength = "FL";

        /// <summary>
        /// Finished Width
        /// </summary>
        public const string DownloadOrderToAutomationFinishedWidth = "FB";

        /// <summary>
        /// Thickness
        /// </summary>
        public const string DownloadOrderToAutomationThickness = "H";

        /// <summary>
        /// Material Id
        /// </summary>
        public const string ReadyToStartMaterialName = "MaterialName";

        /// <summary>
        /// Material Id
        /// </summary>
        public const string ReadyToStartIsReadyForProduction = "IsReadyForProduction";

        /// <summary>
        /// OEE State
        /// </summary>
        public const string OEEStateToChangeOnResource = "State";

        /// <summary>
        /// OEE State Reason
        /// </summary>
        public const string OEEStateReasonToChangeOnResource = "Reason";

        #endregion

        #region Json Field Types

        /// <summary>
        /// Field Type - String
        /// </summary>
        public const string DownloadOrderToAutomationTypeString = "String";

        /// <summary>
        /// Field Type - Decimal
        /// </summary>
        public const string DownloadOrderToAutomationTypeDecimal = "Decimal";

        /// <summary>
        /// Field Type - DateTime
        /// </summary>
        public const string DownloadOrderToAutomationTypeDateTime = "DateTime";

        #endregion

        #region Tags

        /// <summary>
        /// Tags - Header Tag
        /// </summary>
        public const string DownloadOrderToAutomationHeaderTag = "_";

        /// <summary>
        /// Tags - Header Tag
        /// </summary>
        public const string DownloadOrderToAutomationDetailsTag = "__";

        #endregion

        #region Configurations

        /// <summary>
        /// Default timeout when sending the request when downloading order to automation
        /// </summary>
        public const string DownloadOrderToAutomationSendRequestDefaultTimeout = "/Cmf/Custom/DownloadOrderToAutomation/SendRequestDefaultTimeout";

        /// <summary>
        /// Indicates if the request should be sent Synchronously
        /// </summary>
        public const string DownloadOrderToAutomationSendRequestSynchronously = "/Cmf/Custom/DownloadOrderToAutomation/SendRequestSynchronously";

        /// <summary>
        /// Indicates the request type to be sent
        /// </summary>
        public const string DownloadOrderToAutomationRequestOrderToken = "/Cmf/Custom/DownloadOrderToAutomation/RequestOrderToken";

        /// <summary>
        /// Default timeout when sending the request for the ReadyToStart
        /// </summary>
        public const string ReadyToStartSendRequestDefaultTimeout = "/Cmf/Custom/Automation/ReadyToStart/SendRequestDefaultTimeout";

        /// <summary>
        /// Reason to terminate materials on order complete
        /// </summary>
        public const string OrderCompletionReason = "/Cmf/Custom/MaterialTracking/OrderCompletionReason";

        /// <summary>
        /// Duration of the Interlock Notification
        /// </summary>
        public const string InterlockNotificationDuration = "/Cmf/Custom/Automation/InterlockNotificationDuration";

        /// <summary>
        /// Definition of the account used to execute automation
        /// </summary>
        public const string AutomationExecutionAccount = "/Cmf/Custom/Automation/ExecutionAccount";

        /// <summary>
        /// Indicates if it restores the automation consumable queue by sending the consumables list before downloading the order to automation:
        /// </summary>
        public const string RestoreConsumableQueue = "/Cmf/Custom/DownloadOrderToAutomation/RestoreConsumableQueue";

        /// <summary>
        /// Config for HPO files order identifier
        /// </summary>
        public const string OptimizerOrderRowIdentifier = "/Cmf/Custom/MaterialTracking/OptimizerOrderRowIdentifier";

        /// <summary>
        /// Config for keep alive counter timeout
        /// </summary>
        public const string KeepAliveCounterTimeout = "/Cmf/Custom/Automation/KeepAliveCounterTimeout";

        /// <summary>
        /// Default timeout when sending the request for printing a ULL label to Logopak
        /// </summary>
        public const string PrintLabelToLogopakSendRequestDefaultTimeout = "/Cmf/Custom/UllLabelPrinting/SendRequestDefaultTimeout";

        #endregion

        #region Localized Messages

        /// <summary>
        /// Request {0} failed to be executed.
        /// </summary>
        public const string CustomDownloadOrderToAutomationRequestFailedLocalizedMessage = "CustomDownloadOrderToAutomationRequestFailed";

        /// <summary>
        /// Cannot clear interlock on resource {0} because the order {1} is suspended.
        /// </summary>
        public const string CustomClearInterlockFailOrderSuspendedLocalizedMessage = "CustomClearInterlockFailOrderSuspended";

        /// <summary>
        /// Order Download/ Track In failed:
        /// </summary>
        public const string CustomTrackInFailedMessage = "CustomTrackInFailedMessage";

        /// <summary>
        /// Connection lost for line {0}
        /// </summary>
        public const string CustomConnectionLostNotification = "CustomConnectionLostNotification";

        /// <summary>
        /// Keep Alive counter is not running. Please check the OPC connection.
        /// </summary>
        public const string CustomKeepAliveCounterNotRunning = "CustomIoT010Message";

        /// <summary>
        /// No request order token was configured in the configurations.
        /// </summary>
        public const string CustomDownloadOrderToAutomationRequestOrderTokenNotDefinedLocalizedMessage = "CustomDownloadOrderToAutomationRequestOrderTokenNotDefined";

        /// <summary>
        /// Material {0} cannot be detached because it was already consumed.
        /// </summary>
        public const string CustomAutomationDetachConsumableConsumedLocalizedMessage = "CustomAutomationDetachConsumableConsumed";

        /// <summary>
        /// It is not possible to split from the material '{0}' the quantity '{1}', because it was already consumed. The available quantity is '{2}'.
        /// </summary>
        public const string CustomAutomationManualLoadingSplitConsumableConsumedLocalizedMessage = "CustomAutomationManualLoadingSplitConsumableConsumed";

        /// <summary>
        /// A problem occurred while clearing the interlock for {0}
        /// </summary>
        public const string CustomClearInterlockErrorTitleMessageLocalizedMessage = "CustomClearInterlockErrorTitleMessage";

        /// <summary>
        /// A problem occurred while attaching a consumable on {0}
        /// </summary>
        public const string CustomAutomationAttachErrorTitleMessageLocalizedMessage = "CustomAutomationAttachErrorTitleMessage";

        /// <summary>
        /// There are no Localized Messages configured for the Response Code {0}.
        /// </summary>
        public const string CustomClearInterlockErrorNoLocalizedMessageLocalizedMessage = "CustomClearInterlockErrorNoLocalizedMessage";

        /// <summary>
        /// Order {0} was aborted on Line {1}
        /// </summary>
        public const string CustomStopMaterialIoTAbortNotification = "CustomStopMaterialIoTAbortNotification";

        /// <summary>
        /// Failed to download the order to the equipment.
        /// </summary>
        public const string CustomStopMaterialIoTReasonNotification = "CustomStopMaterialIoTReasonNotification";

        /// <summary>
        /// Unable to read variable '{0}' from source '{1}'.
        /// </summary>
        public const string CustomAutomationVariableNotFoundMessage = "CustomAutomationVariableNotFoundMessage";

        /// <summary>
        /// Please check configuration for variable '{0}' from source '{1}' using IdentifierProperty={2} and ValueProperty={3}.
        /// </summary>
        public const string CustomAutomationVariableCheckConfigurationMessage = "CustomAutomationVariableCheckConfigurationMessage";

        /// <summary>
        /// Failed to set the interlock to {0} on equipment {1}: {2}
        /// </summary>
        public const string CustomNotificationMessageOnInterlockFail = "CustomNotificationMessageOnInterlockFail";

        /// <summary>
        /// Interlock failed to update on line {0}
        /// </summary>
        public const string CustomNotificationTitleOnInterlockFail = "CustomNotificationTitleOnInterlockFail";

        /// <summary>
        /// Error while sending data to the Logopak printer '{0}'.
        /// </summary>
        public const string CustomAutomationErrorPrintingToLogopakLocalizedMessage = "CustomAutomationErrorPrintingToLogopak";

        /// <summary>
        /// Did not update the resource interlock status. Status is already '{0}'.
        /// </summary>
        public const string CustomNotificationDidNotUpdateInterlockStatus = "CustomNotificationDidNotUpdateInterlockStatus";

        /// <summary>
        /// Did not update the resource interlock status. Alarm '{0}' with BlockFeeder is still active.
        /// </summary>
        public const string CustomAlarmBlockFeederStillActiveRemainsInterlock = "CustomAlarmBlockFeederStillActiveRemainsInterlock";


        #endregion

        #region Error Messages

        /// <summary>
        /// Error loading GenericInterfaceControllerConfigurations
        /// </summary>
        public const string CustomAutomationLoadConfigurationFailed = "Failed to load Automation Configurations. Input '{0}' is missing.";

        /// <summary>
        /// Error loading HPO configurations
        /// </summary>
        public const string CustomAutomationMissingMandatoryConfiguration = "Missing the mandatory configurations to start the file handler process for resource {1}";

        /// <summary>
        /// No DefaultMainFeeder set in the table CustomDefaultMainFeederConfiguration
        /// </summary>
        public const string CustomAutomationMissingDefaultMainFeeder = "Missing data in the table CustomDefaultMainFeederConfiguration for line '{0}'.";

        /// <summary>
        /// No MainFeeder attribute is null or resource does not exist 
        /// </summary>
        public const string CustomAutomationNullOrMissingMainFeeder = "MESAutomationInFeederSubResourceController is null or Resource does not exist.";

        /// <summary>
        /// Error requesting virtual pallet creation
        /// </summary>
        public const string CustomErrorMessageRequestingVirtualPallet = "Error requesting Virtual Pallet Creation: Input '{0}' is null.";

        /// <summary>
        /// Error requesting SpecialAttach
        /// </summary>
        public const string CustomErrorMessageRequestingSpecialAttach = "Error requesting SpecialAttach: Input '{0}' is null.";

        /// <summary>
        /// Error requesting reduction of pallet quantity on outfeeder
        /// </summary>
        public const string CustomErrorMessageRequestingReductionQuantityOutfeeder = "Error requesting reduction of pallet quantity on outfeeder: Input '{0}' is null.";

        /// <summary>
        /// Error requesting reduction of pallet quantity on outfeeder, not defined correctly
        /// </summary>
        public const string CustomErrorMessageRequestingReductionQuantityOutfeederNotDefined = "Error requesting reduction of pallet quantity on outfeeder: Outfeeder for resource {0} is not defined correctly.";

        /// <summary>
        /// Error requesting virtual pallet creation
        /// </summary>
        public const string CustomErrorMessageVirtualCreationNoReply = "Failed to send request ti IOT for reset pallet'.";

        /// <summary>
        /// Error on request response for virtual pallet to real pallet
        /// </summary>
        public const string CustomErrorMessageFailedToConvertVirtualToReal = "Failed to convert virtual pallet {0} into a real pallet";

        /// <summary>
        /// Error on request response for special attach
        /// </summary>
        public const string CustomErrorMessageFailedToSpecialAttach = "Failed to special attach pallet {0} to line {1}.";

        /// <summary>
        /// Error requesting virtual pallet to real pallet
        /// </summary>
        public const string CustomErrorMessageRequestingVirtualToRealPallet = "Error requesting Virtual Pallet to Real Pallet: Input '{0}' is null.";

        /// <summary>
        /// Error requesting virtual pallet creation resource name empty
        /// </summary>
        public const string CustomErrorMessageEmptyResourceName = "Error during service call: Resource Name is empty.";

        /// <summary>
        /// Error requesting virtual pallet creation resource does not exist
        /// </summary>
        public const string CustomErrorMessageResourceNotExists = "Error during service call: Resource does not exist.";

        /// <summary>
        /// Error requesting virtual pallet creation counterpart resource name empty
        /// </summary>
        public const string CustomErrorMessageEmptyCounterpartResourceName = "Error during service call: Counterpart Resource Name is empty.";

        /// <summary>
        /// Error requesting virtual pallet creation counterpart resource does not exist
        /// </summary>
        public const string CustomErrorMessageCounterpartResourceNotExists = "Error during service call: Counterpart Resource does not exist.";

        /// <summary>
        /// Error requesting virtual pallet creation no mo InProcess in Resource
        /// </summary>
        public const string CustomErrorMessageNoMOInProcess = "Error requesting Virtual Pallet Creation: No MO InProcess in Resource '{0}'.";

        /// <summary>
        /// Error requesting second line MO State, resource not valid
        /// </summary>
        public const string CustomErrorMessageDFValidateSecondLineMO = "Error requesting second line MO State, resource not valid.";

        /// <summary>
        /// Error requesting second line MO State, resource not valid
        /// </summary>
        public const string CustomErrorMessageDFNotFirstLine = "Error requesting second line MO State, request was not made from first line.";

        #endregion Error Messages

        #region Request Types

        /// <summary>
        /// Track in request
        /// </summary>
        public const string TrackIn = "TrackIn";

        /// <summary>
        /// Request Type - ReadyToStart
        /// </summary>
        public const string AutomationRequestTypeReadyToStart = "ReadyToStart";

        /// <summary>
        /// Request Type - OutSortedRequest
        /// </summary>
        public const string AutomationRequestTypeGetOrder = "OutSortedRequest";

        /// <summary>
        /// Request Type - CustomRetrieveConsumedQuantitiesInFeeder
        /// </summary>
        public const string AutomationRequestTypeGetConsumedQuantity = "CustomRetrieveConsumedQuantitiesInFeeder";

        /// <summary>
        /// Request Type - OutsorterRequestConfirmation
        /// </summary>
        public const string AutomationRequestTypeOutsorterRequestConfirmation = "OutsortedRequestConfirmation";

        /// <summary>
        /// Request Type - OutsorterExplicitPalletsRequest     
        /// </summary>
        public const string AutomationRequestTypeOutsorterExplicitPalletsRequest = "OutsorterExplicitPalletsRequest";

        /// <summary>
        /// Request Type - SaveAttributesOnResource  
        /// </summary>
        public const string AutomationRequestTypeSaveAttributesOnResource = "SaveAttributesOnResourceAfterManualOutsorting";

        /// <summary>
        /// Request field - reply
        /// </summary>
        public const string AutomationRequestReplyField = "reply";

        /// <summary>
        /// Request field - message
        /// </summary>
        public const string AutomationRequestMessageField = "message";

        /// <summary>
        /// Request field - processLosses
        /// </summary>
        public const string AutomationRequestProcessLossesField = "processLosses";

        /// <summary>
        /// Request Type - StopMaterial
        /// </summary>
        public const string AutomationRequestTypeStopMaterial = "StopMaterial";

        /// <summary>
        /// WMS Order cancel
        /// </summary>
        public const string WMSCancelJob = "CancelJob";

        /// <summary>
        /// Request Type - ChangeDefaultCompletionQuantity
        /// </summary>
        public const string AutomationRequestChangeDefaultCompletionQuantity = "ChangeDefaultCompletionQuantity";

        /// <summary>
        /// Request Type - ConsumableAttach
        /// </summary>
        public const string AutomationRequestTypeConsumableAttach = "ConsumableAttach";

        /// <summary>
        /// Request Type - ConsumableManualAttach
        /// </summary>
        public const string AutomationRequestTypeConsumableManualAttach = "ConsumableManualAttach";

        /// <summary>
        /// Request Type - ForceUnitCompletion
        /// </summary>
        public const string AutomationRequestForceUnitCompletion = "ForceUnitCompletion";

        /// <summary>
        /// Request Type - ForceOrderCompletionGetQuantity
        /// </summary>
        public const string AutomationRequestForceOrderCompletionGetQuantity = "ForceOrderCompletionGetQuantity";

        /// <summary>
        /// Request Type - ForceOrderCompletionNoProcessLoss
        /// </summary>
        public const string AutomationRequestForceOrderCompletionNoProcessLoss = "ForceOrderCompletionNoProcessLoss";

        /// <summary>
        /// Publish Type - ForceOrderCompletionProcessLossTrigger
        /// </summary>
        public const string AutomationPublishForceOrderCompletionProcessLossTrigger = "ForceOrderCompletion_ProcessLossTrigger";

        /// <summary>
        /// Request Type - ForceOrderAbortGetQuantity
        /// </summary>
        public const string AutomationRequestForceOrderAbortGetQuantity = "ForceOrderAbortGetQuantity";

        /// <summary>
        /// Request Type - ForceOrderAbortNoProcessLoss
        /// </summary>
        public const string AutomationRequestForceOrderAbortNoProcessLoss = "ForceOrderAbortNoProcessLoss";

        /// <summary>
        /// Publish Type - ForceOrderAbortFinish
        /// </summary>
        public const string AutomationPublishForceOrderAbortProcessLossTrigger = "ForceOrderAbort_ProcessLossTrigger";

        /// <summary>
        /// Request Type - Suspend
        /// </summary>
        public const string AutomationRequestTypeSuspendMaterial = "Suspend";

        /// <summary>
        /// Request Type - ReloadPendingTrackOuts
        /// </summary>
        public const string AutomationRequestReloadPendingTrackOuts = "ReloadPendingTrackOuts";

        /// <summary>
        /// Request Type - Unsuspend
        /// </summary>
        public const string AutomationRequestTypeUnsuspendMaterial = "Unsuspend";

        /// <summary>
        /// Request Type - CustomAlarmOccurrenceExistsById
        /// </summary>
        public const string AutomationRequestCustomAlarmOccurrenceExistsById = "CustomAlarmOccurrenceExistsById";

        /// <summary>
        /// Request field - ClearMaterial
        /// </summary>
        public const string AutomationRequestClearMaterial = "ClearMaterial";

        /// <summary>
        /// Request field - ClearInterlock
        /// </summary>
        public const string AutomationRequestClearInterlock = "ClearInterlock";

        /// <summary>
        /// Request field - ReleaseInterlockOnAutomationModeChange
        /// </summary>
        public const string AutomationRequestReleaseInterlockOnAutomationModeChange = "ReleaseInterlockOnAutomationModeChange";

        /// <summary>
        /// Request field - ClearInterlock Completing
        /// </summary>
        public const string AutomationRequestClearInterlockCompleting = "ClearInterlockCompleting";

        /// <summary>
        /// Request field - ClearInterlock Aborting
        /// </summary>
        public const string AutomationRequestClearInterlockAborting = "ClearInterlockAborting";

        /// <summary>
        /// Request field - MaterialName
        /// </summary>
        public const string AutomationRequestMaterialName = "MaterialName";

        /// <summary>
        /// Request field - ResponseCode
        /// </summary>
        public const string AutomationRequestResponseCodeField = "ResponseCode";

        ///<summary>
        /// Request field - BlockOEEStateField
        /// </summary>
        public const string AutomationRequestBlockOEEStateField = "BlockOEEState";

        /// <summary>
        /// Request field - MaterialName
        /// </summary>
        public const string AutomationRequestResourceName = "ResourceName";

        /// <summary>
        /// Request Type - GetAutomationVariables
        /// </summary>
        public const string AutomationRequestGetAutomationVariables = "GetAutomationVariables";

        /// Request field - RestoreIoTConsumableQueue
        /// </summary>
        public const string AutomationRequestTypeRestoreConsumableQueue = "RestoreIoTConsumableQueue";

        /// Request field - ProcessLossReport
        /// </summary>
        public const string AutomationRequestTypeProcessLossReport = "ProcessLossReport";

        /// <summary>
        /// Request field - CalculateOEEStateAndReason
        /// </summary>
        public const string AutomationRequestTypeCalculateOEEStateAndReason = "CalculateOEEStateAndReason";

        /// <summary>
        /// Request field - BlockOEEStateCalculation
        /// </summary>
        public const string AutomationRequestTypeBlockOEEStateCalculation = "BlockOEEStateCalculation";

        /// <summary>
        /// Request field - HPO File logs
        /// </summary>
        public const string AutomationRequestTypeHPOFile = "HPOFileLog";

        /// <summary>
        /// Request Type - GetRemainingQuantities
        /// </summary>
        public const string AutomationRequestTypeGetRemainingQuantities = "GetRemainingQuantities";

        /// <summary>
        /// Request Type - CreateVirtualPallet
        /// </summary>
        public const string AutomationRequestCreateVirtualPallet = "CreateVirtualPallet";

        /// <summary>
        /// Request Type - VirtualToRealPallet
        /// </summary>
        public const string AutomationRequestVirtualToRealPallet = "VirtualToRealPallet";

        /// <summary>
        /// Request Type - SpecialAttach
        /// </summary>
        public const string AutomationRequestSpecialAttach = "SpecialAttach";

        /// <summary>
        /// Request Type - ReducePalletQuantityOutfeeder
        /// </summary>
        public const string AutomationRequestReducePalletQuantityOutfeeder = "ReducePalletQuantityOutfeeder";

        /// <summary>
        /// Request Type - GetOrderStateOnEquipment
        /// </summary>
        public const string AutomationRequestGetOrderStateOnEquipment = "GetOrderStateOnEquipment";

        /// <summary>
        /// Request field - SendOEEStateToLC
        /// </summary>
        public const string AutomationRequestSendOEEStateToLC = "SendOEEStateToLC";

        public const string AutomationRequestSendPalletIDToLC = "SendPalletIDToLC";
        #endregion

        #region Constants

        /// <summary>
        /// AutomationControllerInstance
        /// </summary>
        public const string AutomationControllerInstance = "AutomationControllerInstance";

        /// <summary>
        /// AutomationResourceTagBaseName
        /// </summary>
        public const string AutomationResourceTagBaseName = "AutomationResourceTagBaseName";

        /// <summary>
        /// MESAutomationInFeederSubResourceController
        /// </summary>
        public const string MESAutomationInFeederSubResourceController = "MESAutomationInFeederSubResourceController";

        /// <summary>
        /// AutomationScanInFeeder
        /// </summary>
        public const string AutomationScanInFeeder = "AutomationScanInFeeder";

        /// <summary>
        /// AutomationInFeederPosition
        /// </summary>
        public const string AutomationInFeederPosition = "AutomationInFeederPosition";

        /// <summary>
        /// AutomationInFeederPosition
        /// </summary>
        public const string AutomationProductionCounterPosition = "AutomationProductionCounterPosition";


        /// <summary>
        /// AutomationAlarmBufferSize
        /// </summary>
        public const string AutomationAlarmBufferSize = "AutomationAlarmBufferSize";

        /// <summary>
        /// KeepAliveCounterTimeout
        /// </summary>
        public const string KeepAliveCounterTimeoutProperty = "KeepAliveCounterTimeout";

        /// <summary>
        /// Security Mode
        /// </summary>
        public const string SecurityMode = "SecurityMode";

        /// <summary>
        /// Security Policy
        /// </summary>
        public const string SecurityPolicy = "SecurityPolicy";

        /// <summary>
        /// OPCUA Configuration Parent Path
        /// </summary>
        public const string OPCUAParentPath = "/Cmf/Custom/Automation/OPCUAServer/";
        /// <summary>
        /// Reset Pallet Queue action group Name
        /// </summary>
        public const string AutomationRequestSendPalletDetailsOnResetPallet = "ResetPalletQueue";

        /// <summary>
        /// Respomnse from IOT failure
        /// </summary>
        public const string CustomErrorMessageResetPalletIDReply = "The Process timed out to get a response from IOT, recieved {0} as response";

        /// <summary>
        /// Error handling of empty material
        /// </summary>
        public const string CustomErrorMessageMaterialNamenotavailableforResetReply = "No Material name is provided as input";

        /// <summary>
        /// 
        /// </summary>
        public const string CustomErrorMessageControllerInstancenotavailableforResetReply = "No Constrolletr name is provided as input";

        #endregion

        #region Generic Tables

        /// <summary>
        /// Generic Table - CustomIoTResponseCodes
        /// </summary>
        public const string CustomIoTResponseCodesGenericTable = "CustomIoTResponseCodes";

        /// <summary>
        /// CustomIoTResponseCodes - ResponseCode
        /// </summary>
        public const string CustomIoTResponseCodesResponseCode = "ResponseCode";

        /// <summary>
        /// CustomIoTResponseCodes - Description
        /// </summary>
        public const string CustomIoTResponseCodesDescription = "Description";

        /// <summary>
        /// CustomIoTResponseCodes - LocalizedMessage
        /// </summary>
        public const string CustomIoTResponseCodesLocalizedMessage = "LocalizedMessage";

        /// <summary>
        /// Generic Table - CustomAutomationVariableReadingsConfiguration
        /// </summary>
        public const string CustomAutomationVariableReadingsConfigurationGenericTable = "CustomAutomationVariableReadingsConfiguration";

        /// <summary>
        /// Generic Table Property - CustomAutomationVariableReadingsConfiguration - Resource
        /// </summary>
        public const string CustomAutomationVariableReadingsConfigurationResource = "Resource";

        /// <summary>
        /// Generic Table Property - CustomAutomationVariableReadingsConfiguration - Source
        /// </summary>
        public const string CustomAutomationVariableReadingsConfigurationSource = "Source";

        /// <summary>
        /// Generic Table Property - CustomAutomationVariableReadingsConfiguration - Variable
        /// </summary>
        public const string CustomAutomationVariableReadingsConfigurationVariable = "Variable";

        /// <summary>
        /// Generic Table Property - CustomAutomationVariableReadingsConfiguration - LocalizedMessage
        /// </summary>
        public const string CustomAutomationVariableReadingsConfigurationLocalizedMessage = "LocalizedMessage";

        /// <summary>
        /// Generic Table Property - CustomAutomationVariableReadingsConfiguration - IdentifierProperty
        /// </summary>
        public const string CustomAutomationVariableReadingsConfigurationIdentifierProperty = "IdentifierProperty";

        /// <summary>
        /// Generic Table Property - CustomAutomationVariableReadingsConfiguration - ValueProperty
        /// </summary>
        public const string CustomAutomationVariableReadingsConfigurationValueProperty = "ValueProperty";

        /// <summary>
        /// Generic Table Property - CustomAutomationVariableReadingsConfiguration - FilterValue
        /// </summary>
        public const string CustomAutomationVariableReadingsConfigurationFilterValue = "FilterValue";

        /// <summary>
        /// Generic Table Property - CustomAutomationVariableReadingsConfiguration - DataType
        /// </summary>
        public const string CustomAutomationVariableReadingsConfigurationDataType = "DataType";

        /// <summary>
        /// Generic Table Property - CustomAutomationVariableReadingsConfiguration - Order
        /// </summary>
        public const string CustomAutomationVariableReadingsConfigurationOrder = "Order";

        /// <summary>
        /// Generic Table Property - CustomAutomationVariableReadingsConfiguration - DisplayUnit
        /// </summary>
        public const string CustomAutomationVariableReadingsConfigurationDisplayUnit = "DisplayUnit";

        #endregion
    }
}
