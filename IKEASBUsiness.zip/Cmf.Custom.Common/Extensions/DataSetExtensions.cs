﻿using Cmf.Foundation.BusinessObjects;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Common.CustomActionUtilities;


namespace Cmf.Custom.IKEA.Common
{
    /// <summary>
    /// this class contains extension methods to manipulate NgpDataSet, DataSet, DataTable and DataRow type objects
    /// </summary>
    public static class DataSetExtensions
    {
        #region DataSet

        /// <summary>
        /// Creates a data set copy with all data. If provided, overrides the values of the defined columns to override,
        /// with the configured overriding values
        /// </summary>
        /// <param name="dataSet"></param>
        /// <param name="overrideValues"></param>
        /// <returns></returns>
        public static DataSet Copy(this DataSet dataSet, Dictionary<String, Object> overrideValues)
        {
            DataSet returnDataSet = null;
            if (dataSet != null)
            {
                returnDataSet = dataSet.Clone();
                if (dataSet.Tables.Count > 0)
                {
                    returnDataSet.Tables.Clear();
                    foreach (DataTable dtSourceTable in dataSet.Tables)
                    {
                        returnDataSet.Tables.Add(dtSourceTable.Copy(overrideValues));
                    }
                }
            }

            return returnDataSet;
        }

        ///// <summary>
        ///// Determines if a given dataset has data defined
        ///// </summary>
        ///// <param name="dataSet"></param>
        ///// <returns></returns>
        //public static Boolean HasData(this DataSet dataSet)
        //{
        //    if (dataSet != null)
        //    {
        //        foreach (DataTable dt in dataSet.Tables)
        //        {
        //            if (dt.HasData())
        //                return true;
        //        }
        //    }
        //    return false;
        //}

        /// <summary>
        /// Indicates if a given record with the same passed columns and values exists in the current data set
        /// </summary>
        /// <param name="dataSet"></param>
        /// <param name="tableName"></param>
        /// <param name="rowToCheck"></param>
        /// <returns></returns>
        public static Boolean ExactRecordExists(this DataSet dataSet, Dictionary<String, Object> rowToCheck)
        {
            foreach (DataTable table in dataSet.Tables)
            {
                if (dataSet.ExactRecordExists(table.TableName, rowToCheck))
                    return true;
            }

            return false;
        }

        /// <summary>
        /// Indicates if a given record with the same passed columns and values exists in the current data set
        /// </summary>
        /// <param name="dataSet"></param>
        /// <param name="tableName"></param>
        /// <param name="rowToCheck"></param>
        /// <returns></returns>
        public static Boolean ExactRecordExists(this DataSet dataSet, String tableName, Dictionary<String, Object> rowToCheck)
        {
            if (dataSet.Tables.Contains(tableName))
            {
                return dataSet.Tables[tableName].ExactRecordExists(rowToCheck);
            }

            return false;
        }

        /// <summary>
        /// Tries to look for a record with the same values defined for the key columns indicated
        /// </summary>
        /// <param name="dataSet"></param>
        /// <param name="dataToLookFor"></param>
        /// <param name="keyColumns"></param>
        /// <returns></returns>
        public static DataRow TryGetRecord(this DataSet dataSet, Dictionary<String, Object> dataToLookFor, Collection<String> keyColumns)
        {
            foreach (DataTable table in dataSet.Tables)
            {
                DataRow dr = dataSet.TryGetRecord(table.TableName, dataToLookFor, keyColumns);

                if (dr != null)
                    return dr;
            }

            return null;
        }

        /// <summary>
        /// Tries to look for a record with the same values defined for the key columns indicated
        /// </summary>
        /// <param name="dataSet"></param>
        /// <param name="tableName"></param>
        /// <param name="dataToLookFor"></param>
        /// <param name="keyColumns"></param>
        /// <returns></returns>
        public static DataRow TryGetRecord(this DataSet dataSet, String tableName, Dictionary<String, Object> dataToLookFor, Collection<String> keyColumns)
        {
            if (dataSet.Tables.Contains(tableName))
            {
                return dataSet.Tables[tableName].TryGetRecord(dataToLookFor, keyColumns);
            }

            return null;
        }

        /// <summary>
        /// Creates a new row based on the table schema and populates it with incoming values
        /// </summary>
        /// <param name="table"></param>
        /// <param name="values"></param>
        /// <param name="overrideValues"></param>
        /// <returns></returns>
        public static DataRow GetNewRow(this DataSet dataSet, Dictionary<String, Object> values = null, Dictionary<String, Object> overrideValues = null)
        {
            foreach (DataTable table in dataSet.Tables)
            {
                DataRow dr = dataSet.GetNewRow(table.TableName, values, overrideValues);

                if (dr != null)
                    return dr;
            }

            return null;
        }

        /// <summary>
        /// Creates a new row based on the table schema and populates it with incoming values
        /// </summary>
        /// <param name="table"></param>
        /// <param name="values"></param>
        /// <param name="overrideValues"></param>
        /// <returns></returns>
        public static DataRow GetNewRow(this DataSet dataSet, String tableName, Dictionary<String, Object> values = null, Dictionary<String, Object> overrideValues = null)
        {
            if (dataSet.Tables.Contains(tableName))
            {
                return dataSet.Tables[tableName].GetNewRow(values, overrideValues);
            }

            return null;
        }

        /// <summary>
        /// Imports a data row to the data set
        /// </summary>
        /// <param name="dataSet"></param>
        /// <param name="dataRow"></param>
        public static void ImportRow(this DataSet dataSet, String tableName, DataRow dataRow)
        {
            if (dataSet != null && dataSet.Tables.Contains(tableName))
            {
                DataRow newRow = dataSet.Tables[tableName].NewRow();
                newRow.CopyFrom(dataRow);

                dataSet.Tables[tableName].Rows.Add(newRow);
                dataSet.Tables[tableName].AcceptChanges();
                dataSet.AcceptChanges();
            }
        }

        /// <summary>
        /// Merges two data sets based on the key data only
        /// </summary>
        /// <param name="dataSet"></param>
        /// <param name="dataSetToMerge"></param>
        /// <param name="keyColumns"></param>
        public static void Merge(this DataSet dataSet, DataSet dataSetToMerge, Collection<String> keyColumns)
        {
            if (dataSet == null || dataSetToMerge == null)
                return;

            // get common table names
            Collection<String> curTables = new Collection<String>(dataSet.Tables.Cast<DataTable>().Select(E => E.TableName).ToList());
            Collection<String> sourceTables = new Collection<String>(dataSetToMerge.Tables.Cast<DataTable>().Select(E => E.TableName).ToList());

            foreach (String commonTable in curTables.Intersect(sourceTables))
            {
                dataSet.Tables[commonTable].Merge(dataSetToMerge.Tables[commonTable], keyColumns);
            }
        }

        ///// <summary>
        ///// Converts DataSet into NgpDataSet
        ///// </summary>
        ///// <param name="instance"></param>
        ///// <returns></returns>
        //public static INgpDataSet ToNgpDataSet(this DataSet instance)
        //{
        //    INgpDataSet returnObj = null;

        //    if (instance != null)
        //    {
        //        returnObj = NgpDataSet.FromDataSet(instance);
        //    }

        //    return returnObj;
        //}

        #endregion

        #region DataTable

        /// <summary>
        /// Creates a copy from the current data table (Data Included)
        /// </summary>
        /// <param name="table"></param>
        /// <param name="overrideValues"></param>
        /// <returns></returns>
        public static DataTable Copy(this DataTable table, Dictionary<String, Object> overrideValues)
        {
            DataTable returnTable = null;

            if (table != null)
            {
                overrideValues = overrideValues ?? new Dictionary<String, Object>();
                Dictionary<String, Object> innerOverrideValues = new Dictionary<String, Object>();
                foreach (DataColumn dc in table.Columns)
                {
                    innerOverrideValues.Add(dc.ColumnName, overrideValues.ContainsKey(dc.ColumnName) ? overrideValues[dc.ColumnName] : (Object)DBNull.Value);
                }

                returnTable = table.Clone();
                foreach (DataRow sourceRow in table.Rows)
                {
                    DataRow newRow = returnTable.NewRow();
                    foreach (DataColumn column in table.Columns)
                    {
                        String columnName = column.ColumnName;
                        newRow[columnName] = (innerOverrideValues[columnName] == ((Object)DBNull.Value) ? sourceRow[columnName] : innerOverrideValues[columnName]);
                    }
                    returnTable.Rows.Add(newRow);
                }
                returnTable.AcceptChanges();
            }

            return returnTable;
        }

        ///// <summary>
        ///// Creates a new row based on the table schema and populates it with incoming values
        ///// </summary>
        ///// <param name="table"></param>
        ///// <param name="values"></param>
        ///// <param name="overrideValues"></param>
        ///// <returns></returns>
        //public static DataRow GetNewRow(this DataTable table, Dictionary<String, Object> values = null, Dictionary<String, Object> overrideValues = null)
        //{
        //    DataRow returnRow = null;

        //    if (table != null)
        //    {
        //        overrideValues = overrideValues ?? new Dictionary<String, Object>();
        //        values = values ?? new Dictionary<String, Object>();

        //        Dictionary<String, Object> innerOverrideValues = new Dictionary<String, Object>();
        //        foreach (DataColumn dc in table.Columns)
        //        {
        //            innerOverrideValues.Add(dc.ColumnName, overrideValues.ContainsKey(dc.ColumnName) ? overrideValues[dc.ColumnName] : (values.ContainsKey(dc.ColumnName) ? values[dc.ColumnName] : (Object)DBNull.Value));
        //        }

        //        returnRow = table.NewRow();
        //        foreach (DataColumn column in table.Columns)
        //        {
        //            String columnName = column.ColumnName;
        //            returnRow[columnName] = (innerOverrideValues[columnName] == (Object)DBNull.Value) ? returnRow[columnName] : innerOverrideValues[columnName];
        //        }
        //    }

        //    return returnRow;
        //}

        /// <summary>
        /// Applies a filter on given data table, returning the set of rows mathing that filter
        /// </summary>
        /// <param name="table"></param>
        /// <param name="filter"></param>
        /// <returns></returns>
        public static DataRow[] GetDataByFilter(this DataTable table, String filter)
        {
            return table.Select(filter);
        }

        ///// <summary>
        ///// Determines if a given datatable has data defined
        ///// </summary>
        ///// <param name="dataTable"></param>
        ///// <returns></returns>
        //public static Boolean HasData(this DataTable dataTable)
        //{
        //    return dataTable.Rows.Count > 0;
        //}

        /// <summary>
        /// Indicates if a given record with the same passed columns and values exists in the current datatable
        /// </summary>
        /// <param name="dataTable"></param>
        /// <param name="rowToCheck"></param>
        /// <returns></returns>
        public static bool ExactRecordExists(this DataTable dataTable, Dictionary<String, Object> rowToCheck)
        {
            if (rowToCheck != null && rowToCheck.Count > 0)
            {
                // check if all columns passed exist
                IEnumerable<String> columnNames = rowToCheck.Keys.Select(Key => Key);
                IEnumerable<String> existingNames = dataTable.Columns.Cast<DataColumn>().Select(DataColumn => DataColumn.ColumnName);

                // we can only proceed if all columns exist
                if (columnNames.Intersect(existingNames).Count() == columnNames.Count())
                {
                    // iterate through the data table rows
                    foreach (DataRow dataRow in dataTable.Rows)
                    {
                        // by default, assume the record was found if got to this part...
                        Boolean internalVeridict = true;

                        // iterate through the columns
                        foreach (String columnName in columnNames)
                        {
                            String dataTableValue = Convert.ToString(dataRow[columnName]);

                            Object receivedValue = null;
                            rowToCheck.TryGetValue(columnName, out receivedValue);
                            String newValue = Convert.ToString(receivedValue);

                            internalVeridict = String.Equals(newValue, dataTableValue, StringComparison.InvariantCultureIgnoreCase);
                            if (!internalVeridict)
                                break;
                        }

                        // if record is found, no need to continue iterations. exit with true
                        if (internalVeridict) return true;
                    }
                }
            }

            // if got here, no data was found
            return false;
        }

        /// <summary>
        /// Tries to look for a record with the same values defined for the key columns indicated
        /// </summary>
        /// <param name="sourceDataTable"></param>
        /// <param name="dataToLookFor"></param>
        /// <param name="keyColumns"></param>
        /// <returns></returns>
        public static DataRow TryGetRecord(this DataTable sourceDataTable, Dictionary<String, Object> dataToLookFor, Collection<String> keyColumns)
        {
            // input parameters validations
            if (sourceDataTable == null || sourceDataTable.Rows.Count == 0 || dataToLookFor == null || dataToLookFor.Count == 0 || keyColumns == null || keyColumns.Count == 0)
                return null;

            // DataRow to be returned
            DataRow returnDataRow = null;

            // prepare list of actual columns to look for...
            Dictionary<String, Object> actualColumns = dataToLookFor.Where(E => keyColumns.Contains(E.Key)).ToDictionary(E => E.Key, E => E.Value);

            // look for given data
            foreach (DataRow dr in sourceDataTable.Rows)
            {
                Boolean isFound = true;
                foreach (String keyColumn in keyColumns)
                {
                    // if any of the key column values is different, pass to next one
                    String dataTableValue = Convert.ToString(dr[keyColumn]);

                    Object receivedValue = null;
                    dataToLookFor.TryGetValue(keyColumn, out receivedValue);
                    String newValue = Convert.ToString(receivedValue);

                    isFound = (newValue == dataTableValue);
                    if (!isFound)
                        break;
                }

                if (isFound)
                {
                    returnDataRow = dr;
                    break;
                }
            }

            return returnDataRow;
        }

        /// <summary>
        /// Merges two data tables based on the key data only
        /// </summary>
        /// <param name="dataTable"></param>
        /// <param name="dataTableToMerge"></param>
        /// <param name="keyColumns"></param>
        public static void Merge(this DataTable dataTable, DataTable dataTableToMerge, Collection<String> keyColumns)
        {
            if (dataTableToMerge == null || dataTable == null || keyColumns == null || keyColumns.Count == 0)
                return;

            if (!dataTableToMerge.HasData())
                return;

            // get list of columns that match key columns
            Collection<String> currentTableColumns = new Collection<String>(dataTable.Columns.Cast<DataColumn>().Where(E => keyColumns.Contains(E.ColumnName)).Select(E => E.ColumnName).ToList());
            Collection<String> sourceTableColumns = new Collection<String>(dataTableToMerge.Columns.Cast<DataColumn>().Where(E => keyColumns.Contains(E.ColumnName)).Select(E => E.ColumnName).ToList());

            if (currentTableColumns.Count == 0 || currentTableColumns.Count != sourceTableColumns.Count)
                throw new Exception("Cannot perform merge as key columns are not found in both tables");

            DataTable tempDataTable = dataTable.Clone();

            // iterate through the source data table rows
            foreach (DataRow sourceRow in dataTableToMerge.Rows)
            {
                // by default, assume the record is not found, in case table has no rows... ...
                Boolean internalVeridict = false;

                foreach (DataRow dataRow in dataTable.Rows)
                {
                    // by default, assume the record is found ...
                    internalVeridict = true;

                    // iterate through the columns
                    foreach (String columnName in currentTableColumns)
                    {
                        internalVeridict = Object.Equals(dataRow[columnName], sourceRow[columnName]);

                        if (!internalVeridict)
                            break;
                    }

                    // record is found. break
                    if (internalVeridict)
                        break;
                }

                // if source row is not found, add it for merge...
                if (!internalVeridict)
                {
                    DataRow newRow = tempDataTable.NewRow();
                    newRow.CopyFrom(sourceRow);
                    tempDataTable.Rows.Add(newRow);
                }
            }

            // if there is data to merge, do it
            if (tempDataTable.HasData())
            {
                dataTable.Merge(tempDataTable);
            }
        }

        /// <summary>
        /// Adds a copy of the given row to this table. This method is useful when we want to add rows that already belong to other tables,
        /// and need to be copied to be able to do so (since each DataRow can only belong to one DataTable).
        /// </summary>
        /// <param name="table"></param>
        /// <param name="row"></param>
        /// <param name="overrideValues"></param>
        public static void AddCopyRow(this DataTable table, DataRow row, Dictionary<string, object> overrideValues = null)
        {
            DataRow copyRow = table.NewRow();
            copyRow.CopyFrom(row);

            if (overrideValues != null)
            {
                foreach (var pair in overrideValues)
                {
                    copyRow[pair.Key] = pair.Value;
                }
            }

            table.Rows.Add(copyRow);
        }

        /// <summary>
        /// Creates a DataSet from a single DataTable instance
        /// </summary>
        /// <param name="dataTable"></param>
        /// <returns></returns>
        public static DataSet ToDataSet(this DataTable dataTable)
        {
            DataSet dataSet = new DataSet();

            dataSet.Tables.Add(dataTable);

            return dataSet;
        }

        #endregion

        #region DataRow

        ///// <summary>
        ///// 
        ///// </summary>
        ///// <param name="dataRow"></param>
        ///// <param name="sourceDataRow"></param>
        //public static void CopyFrom(this DataRow dataRow, DataRow sourceDataRow)
        //{
        //    for (Int32 iPos = 0; iPos < dataRow.Table.Columns.Count; iPos++)
        //    {
        //        dataRow[iPos] = sourceDataRow[iPos];
        //    }
        //}

        /// <summary>
        /// 
        /// </summary>
        /// <param name="dataRow"></param>
        /// <returns></returns>
        public static Dictionary<String, Object> GetKeyValueDictionary(this DataRow dataRow)
        {
            if (dataRow == null)
                return null;

            return dataRow.Table.Columns.Cast<DataColumn>().ToDictionary(E => E.ColumnName, E => dataRow[E.ColumnName]);
        }

        ///// <summary>
        ///// Retrieves a value for a given field in a data row
        ///// </summary>
        ///// <typeparam name="T"></typeparam>
        ///// <param name="dr"></param>
        ///// <param name="fieldName"></param>
        ///// <param name="defaultValue"></param>
        ///// <returns></returns>
        //public static T GetValue<T>(this DataRow dr, string fieldName, T defaultValue = default(T))
        //{
        //    T returnObject = defaultValue;

        //    if (dr.Table.Columns.Contains(fieldName))
        //    {
        //        if (dr[fieldName] != DBNull.Value && dr[fieldName] is T)
        //        {
        //            returnObject = (T)dr[fieldName];
        //        }
        //    }

        //    return returnObject;
        //}

        #endregion

    }
}
