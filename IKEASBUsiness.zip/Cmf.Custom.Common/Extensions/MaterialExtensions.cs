﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using Cmf.Common.CustomActionUtilities;
using Cmf.Custom.IKEA.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessObjects.QueryObject;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Foundation.Common;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects;
using Microsoft.Extensions.DependencyInjection;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Navigo.BusinessOrchestration.Abstractions;

using Cmf.Custom.IKEA.Common.Exceptions;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;

namespace Cmf.Custom.IKEA.Common.Extensions
{
    public static class MaterialExtensions
    {
        private static IEntityFactory entityFactory => ApplicationContext.CurrentServiceProvider.GetService<IEntityFactory>();
        private static IIKEAUtilities ikeaUtilities => ApplicationContext.CurrentServiceProvider.GetService<IIKEAUtilities>();
        private static IGenericUtilities genericUtilities => ApplicationContext.CurrentServiceProvider.GetService<IGenericUtilities>();
        private static IDeeContextUtilities deeContextUtilities => ApplicationContext.CurrentServiceProvider.GetService<IDeeContextUtilities>();
        private static IMaterialOrchestration materialOrchestration => ApplicationContext.CurrentServiceProvider.GetService<IMaterialOrchestration>();

        public static IFlow GetCurrentFlow(this IMaterial instance)
        {
            IFlow returnFlow = null;

            if (instance != null && !String.IsNullOrEmpty(instance.FlowPath))
            {
                string[] splitTokens = instance.FlowPath.Split('/');
                if (splitTokens.Length >= 2)
                {
                    string[] lastFlowTokens = splitTokens[splitTokens.Length - 2].Split(':');
                    if (lastFlowTokens.Length == 3)
                    {
                        string flowName = lastFlowTokens[0];

                        returnFlow = entityFactory.Create<IFlow>();
                        returnFlow.Load(flowName);
                    }
                }
            }

            return returnFlow;
        }

        public static string GetCurrentERPOperationCode(this IMaterial instance)
        {
            string returnValue = null;

            if (instance != null)
            {
                IFlow currentFlow = instance.GetCurrentFlow();
                if (currentFlow != null)
                {
                    returnValue = currentFlow.GetERPOperationCode();
                }
            }

            return returnValue;
        }

        public static string GetERPOperationCode(this IFlow instance)
        {
            string returnvalue = null;

            if (instance != null)
            {
                returnvalue = instance.GetRelatedAttributeValueOrDefault<string>(Cmf.Custom.IKEA.Common.IKEAConstants.ERPOperationCode, true);
            }

            return returnvalue;
        }

        /// <summary>
        /// Get Material Parent Batch
        /// </summary>
        /// <param name="material">Material from where to get the batch</param>
        /// <returns>Parent Batch Material</returns>
        public static IMaterial GetMaterialParentBatch(this IMaterial material)
        {
            IMaterial batch = null;

            // Check if the batch relation exists
            if (material.HasRelations(IKEAConstants.CustomMaterialBatchRelation, true))
            {
                // Get all material batches
                long batchMaterialId = material.RelationCollection[IKEAConstants.CustomMaterialBatchRelation].Select(mb => mb as ICustomMaterialBatch)
                                                                                                                .Where(bm => bm.IsParentBatch.HasValue && bm.IsParentBatch.Value)
                                                                                                                .Select(mb => mb.GetNativeValue<long>("TargetEntity"))
                                                                                                                .FirstOrDefault();

                if (batchMaterialId > 0)
                {
                    // Load the material batches
                    batch = entityFactory.Create<IMaterial>();
                    batch.Load(batchMaterialId);
                }
            }

            return batch;
        }

        /// <summary>
        /// Retrieves order material name for the current material. If Material is an Order material, then self is returned, otherwise it will look for the base material name
        /// </summary>
        /// <param name="instance"></param>
        /// <returns>Order material name if found</returns>
        public static string GetOrderMaterialName(this IMaterial instance)
        {
            string returnValue = null;

            if (instance != null)
            {
                string orderForm = ikeaUtilities.GetOrderMaterialForm();
                string batchForm = ikeaUtilities.GetOrderMaterialBatch();

                if (String.Equals(instance.Form, orderForm, StringComparison.InvariantCultureIgnoreCase))
                {
                    returnValue = instance.Name;
                }
                else if (!String.Equals(instance.Form, batchForm, StringComparison.InvariantCultureIgnoreCase))
                {
                    returnValue = instance.GetAttributeValueOrDefault<string>(IKEAConstants.CustomMaterialAttributeBaseMaterial, true);
                }
            }

            return returnValue;
        }

        /// <summary>
        /// Returns the first resource related to this material of ProcessingType == Process
        /// Returns null if no match is found
        /// </summary>
        /// <param name="instance"></param>
        /// <param name="loadRelations"></param>
        /// <returns></returns>
        public static IResource GetProcessResource(this IMaterial instance, bool loadRelations = false)
        {
            if (loadRelations)
            {
                instance.LoadRelations(Cmf.Navigo.Common.Constants.MaterialResource);
            }

            return instance.MaterialResourceRelations
                .FirstOrDefault(mr => mr.TargetEntity.ProcessingType == ProcessingType.Process)
                ?.TargetEntity;
        }

        /// <summary>
        /// Split a material
        /// </summary>
        /// <param name="instance">Material to be split</param>
        /// <param name="splitInputParameters">Split Parameters</param>
        /// <param name="primaryQuantity">Quantity to split</param>
        /// <param name="terminateOnZeroQuantity">Terminate on Zero Quantity?</param>
        /// <param name="toCopyFutureHolds">Copy Future Holds?</param>
        /// <param name="splitMode">Split Mode</param>
        /// <returns></returns>
        public static IMaterialCollection SplitMaterial(this IMaterial instance,
                                                        ISplitInputParametersCollection splitInputParameters = null,
                                                        decimal? primaryQuantity = null,
                                                        bool terminateOnZeroQuantity = true,
                                                        bool toCopyFutureHolds = true,
                                                        MaterialSplitMode splitMode = MaterialSplitMode.SplitNotAssembled,
                                                        bool allowAutomaticFeederMaterialSplit = true)
        {
            IMaterialCollection splitMaterials = entityFactory.CreateCollection<IMaterialCollection>();

            // If no split parameter were defined use the given primary quantity to split the material
            if (splitInputParameters.IsNullOrEmpty() && primaryQuantity != null)
            {
                // Prepare split settings
                splitInputParameters = new SplitInputParametersCollection();
                ISplitInputParameters sipCompletedSettingParameters = new SplitInputParameters()
                {
                    PrimaryQuantity = primaryQuantity.GetValueOrDefault(),
                    SecondaryQuantity = 0
                };
                splitInputParameters.Add(sipCompletedSettingParameters);
            }

            // Check if there are any parameters defined for the split
            if (!splitInputParameters.IsNullOrEmpty())
            {

                // This context variable allows the split to happen on materials atached to automatic feeders.
                deeContextUtilities.SetContextParameter(IKEAConstants.CustomAllowAutomaticFeederMaterialSplit, allowAutomaticFeederMaterialSplit);

                // perform split and update source material
                SplitMaterialOutput splitMaterialOutput = materialOrchestration.SplitMaterial(new SplitMaterialInput()
                {
                    ChildMaterials = splitInputParameters,
                    Material = instance,
                    TerminateOnZeroQuantity = terminateOnZeroQuantity,
                    ToCopyFutureHolds = toCopyFutureHolds,
                    SplitMode = splitMode
                });

                deeContextUtilities.SetContextParameter(IKEAConstants.CustomAllowAutomaticFeederMaterialSplit, null);

                splitMaterials = splitMaterialOutput.ChildMaterials;
            }

            return splitMaterials;
        }

        /// <summary>
        /// Store Materials
        /// </summary>
        /// <param name="materials">Material to Store</param>
        /// <param name="resource">Resource</param>
        public static void StoreMaterials(this IMaterialCollection materials, IResource resource)
        {
            Dictionary<IMaterial, IStoreParameters> materialsToStore = materials.ToDictionary(m => m, m => (IStoreParameters)new StoreParameters());

            StoreMaterialsInput input = new StoreMaterialsInput()
            {
                Materials = materialsToStore,
                Resource = resource
            };

            // Store the materials
            materialOrchestration.StoreMaterials(input);
        }

        /// <summary>
        /// Complex Move Materials to Next Step using Orchestration
        /// </summary>
        /// <param name="materials">Materials</param>
        /// <param name="materialFlowPaths">Dictionary with the materials and the respective flow paths to send the material</param>
        public static void ComplexMoveMaterialsToNextStep(this IMaterialCollection materials, Dictionary<IMaterial, string> materialFlowPaths)
        {
            ComplexMoveMaterialsToNextStepInput input = new ComplexMoveMaterialsToNextStepInput()
            {
                Materials = materialFlowPaths
            };

            ComplexMoveMaterialsToNextStepOutput output = materialOrchestration.ComplexMoveMaterialsToNextStep(input);

            // Reload the material Collection
            materials.Load();
        }


        #region Group MOs
        /// <summary>
        /// Extension method allow to check if the material is a group mo.
        /// </summary>
        /// <param name="material"></param>
        /// <param name="loadAttributes"></param>
        /// <param name="loadRelations"></param>
        /// <returns></returns>
        public static bool IsGroupMO(this IMaterial material, bool loadAttributes = true, bool loadRelations = true)
        {
            bool result = false;

            // Validate if this is a group mo by checking the attribute:
            if (material.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomMaterialAttributeIsGroupMO, loadAttributes))
            {
                result = true;
            }

            // Not necessary: This should be deleted after real tests

            // if not, check if there are relations of the type CustomGroupMaterialManufacturingOrder:
            //else
            //{
            //    if (loadRelations)
            //    {
            //        // Get relations from group mo:
            //        material.LoadRelations(IKEAConstants.CustomGroupMaterialManufacturingOrder);
            //    }

            //    // If the relations are not  empty, get child materials:
            //    if (material.RelationCollection != null &&
            //        material.RelationCollection.ContainsKey(IKEAConstants.CustomGroupMaterialManufacturingOrder) &&
            //        material.RelationCollection[IKEAConstants.CustomGroupMaterialManufacturingOrder] != null)
            //    {
            //        if (material.RelationCollection[IKEAConstants.CustomGroupMaterialManufacturingOrder].Where(RC => (RC as CustomGroupMaterialManufacturingOrder).SourceEntity.Id == material.Id)
            //            .Any())
            //        {
            //            result = true;
            //        }
            //    }
            //}
            return result;
        }

        /// <summary>
        /// Extension method allow to check if the material is a child of a specific or any group mo.
        /// </summary>
        /// <param name="material"></param>
        /// <param name="groupMo"></param>
        /// <returns></returns>
        public static bool IsChildOfGroupMO(this IMaterial material, IMaterial groupMo = null)
        {

            IQueryObject query = new QueryObject();
            query.Description = "";
            query.EntityTypeName = IKEAConstants.CustomGroupMaterialManufacturingOrder;
            query.Name = "CustomRelationMaterialMaterial";
            query.Query = new Query();
            query.Query.Distinct = false;
            query.Query.Filters = new FilterCollection()
            {
                new Filter()
                {
                    Name = "Name",
                    ObjectName = "Material",
                    ObjectAlias = "CustomGroupMaterialManufacturingOrder_TargetEntity_2",
                    Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                    Value = material.Name,
                    LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND,
                    FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                },
                new Filter()
                {
                    Name = "UniversalState",
                    ObjectName = IKEAConstants.CustomGroupMaterialManufacturingOrder,
                    ObjectAlias = "CustomGroupMaterialManufacturingOrder_1",
                    Operator = Cmf.Foundation.Common.FieldOperator.IsNotEqualTo,
                    Value = 4,
                    LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND,
                    FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                },

            };

            if (groupMo != null)
            {
                query.Query.Filters.Add(
                    new Filter()
                    {
                        Name = "Name",
                        ObjectName = "Material",
                        ObjectAlias = "CustomGroupMaterialManufacturingOrder_SourceEntity_2",
                        Operator = Cmf.Foundation.Common.FieldOperator.Contains,
                        Value = groupMo.Name,
                        LogicalOperator = Cmf.Foundation.Common.LogicalOperator.Nothing,
                        FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                    });
            }

            query.Query.Fields = new FieldCollection()
            {
                new Field()
                {
                    Alias = "Id",
                    ObjectName = "CustomGroupMaterialManufacturingOrder",
                    ObjectAlias = "CustomGroupMaterialManufacturingOrder_1",
                    IsUserAttribute = false,
                    Name = "Id",
                    Position = 0,
                    Sort = Cmf.Foundation.Common.FieldSort.NoSort
                },
                new Field()
                {
                    Alias = "SourceEntityName",
                    ObjectName = "Material",
                    ObjectAlias = "CustomGroupMaterialManufacturingOrder_SourceEntity_2",
                    IsUserAttribute = false,
                    Name = "Name",
                    Position = 1,
                    Sort = Cmf.Foundation.Common.FieldSort.NoSort
                }
            };
            query.Query.Relations = new RelationCollection()
            {
                new Relation()
                {
                    Alias = "",
                    IsRelation = false,
                    Name = "",
                    SourceEntity = "CustomGroupMaterialManufacturingOrder",
                    SourceEntityAlias = "CustomGroupMaterialManufacturingOrder_1",
                    SourceJoinType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.JoinType.InnerJoin,
                    SourceProperty = "TargetEntityId",
                    TargetEntity = "Material",
                    TargetEntityAlias = "CustomGroupMaterialManufacturingOrder_TargetEntity_2",
                    TargetJoinType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.JoinType.InnerJoin,
                    TargetProperty = "Id"
                },
                new Relation()
                {
                    Alias = "",
                    IsRelation = false,
                    Name = "",
                    SourceEntity = "CustomGroupMaterialManufacturingOrder",
                    SourceEntityAlias = "CustomGroupMaterialManufacturingOrder_1",
                    SourceJoinType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.JoinType.InnerJoin,
                    SourceProperty = "SourceEntityId",
                    TargetEntity = "Material",
                    TargetEntityAlias = "CustomGroupMaterialManufacturingOrder_SourceEntity_2",
                    TargetJoinType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.JoinType.InnerJoin,
                    TargetProperty = "Id"
                }
            };

            DataSet resultDataSet = query.Execute(false, new QueryParameterCollection());
            return resultDataSet.HasData();
        }

        /// <summary>
        /// Extension that allow to get the GroupMO (parent) from a child MO
        /// </summary>
        /// <param name="material"></param>
        /// <param name="loadMaterial"></param>
        /// <returns></returns>
        public static IMaterial GetGroupMOFromChild(this IMaterial material, bool loadMaterial = true)
        {
            IMaterial groupMO = null;

            IQueryObject query = new QueryObject();
            query.Description = "";
            query.EntityTypeName = IKEAConstants.CustomGroupMaterialManufacturingOrder;
            query.Name = "CustomRelationMaterialMaterial";
            query.Query = new Query();
            query.Query.Distinct = false;
            query.Query.Filters = new FilterCollection()
            {
                new Filter()
                {
                    Name = "Name",
                    ObjectName = "Material",
                    ObjectAlias = "CustomGroupMaterialManufacturingOrder_TargetEntity_2",
                    Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                    Value = material.Name,
                    LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND,
                    FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                },
                new Filter()
                {
                    Name = "UniversalState",
                    ObjectName = "CustomGroupMaterialManufacturingOrder",
                    ObjectAlias = "CustomGroupMaterialManufacturingOrder_1",
                    Operator = Cmf.Foundation.Common.FieldOperator.IsNotEqualTo,
                    Value = 4,
                    LogicalOperator = Cmf.Foundation.Common.LogicalOperator.Nothing,
                    FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                }
            };

            query.Query.Fields = new FieldCollection()
            {
                new Field()
                {
                    Alias = "Id",
                    ObjectName = "CustomGroupMaterialManufacturingOrder",
                    ObjectAlias = "CustomGroupMaterialManufacturingOrder_1",
                    IsUserAttribute = false,
                    Name = "Id",
                    Position = 0,
                    Sort = Cmf.Foundation.Common.FieldSort.NoSort
                },
                new Field()
                {
                    Alias = "SourceEntityName",
                    ObjectName = "Material",
                    ObjectAlias = "CustomGroupMaterialManufacturingOrder_SourceEntity_2",
                    IsUserAttribute = false,
                    Name = "Name",
                    Position = 1,
                    Sort = Cmf.Foundation.Common.FieldSort.NoSort
                }
            };
            query.Query.Relations = new RelationCollection()
            {
                new Relation()
                {
                    Alias = "",
                    IsRelation = false,
                    Name = "",
                    SourceEntity = "CustomGroupMaterialManufacturingOrder",
                    SourceEntityAlias = "CustomGroupMaterialManufacturingOrder_1",
                    SourceJoinType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.JoinType.InnerJoin,
                    SourceProperty = "TargetEntityId",
                    TargetEntity = "Material",
                    TargetEntityAlias = "CustomGroupMaterialManufacturingOrder_TargetEntity_2",
                    TargetJoinType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.JoinType.InnerJoin,
                    TargetProperty = "Id"
                },
                new Relation()
                {
                    Alias = "",
                    IsRelation = false,
                    Name = "",
                    SourceEntity = "CustomGroupMaterialManufacturingOrder",
                    SourceEntityAlias = "CustomGroupMaterialManufacturingOrder_1",
                    SourceJoinType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.JoinType.InnerJoin,
                    SourceProperty = "SourceEntityId",
                    TargetEntity = "Material",
                    TargetEntityAlias = "CustomGroupMaterialManufacturingOrder_SourceEntity_2",
                    TargetJoinType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.JoinType.InnerJoin,
                    TargetProperty = "Id"
                }
            };

            DataSet resultDataSet = query.Execute(false, new QueryParameterCollection());
            if (resultDataSet.HasData())
            {
                string groupMoName = resultDataSet.Tables[0].Rows[0].Field<string>("SourceEntityName");
                groupMO = entityFactory.Create<IMaterial>();
                groupMO.Name = groupMoName;
                if (loadMaterial)
                {
                    groupMO.Load();
                }
            }

            return groupMO;
        }


        /// <summary>
        /// Retrieves the Optimizer configuration associated with the resource stored in the material attributes "GroupOrderResource"
        /// </summary>
        /// <param name="material"></param>
        /// <returns></returns>
        public static OptimizerResourceStructure GetHPOConfiguration(this IMaterial material)
        {
            string resourceName = material.GetAttributeValueOrDefault<string>(IKEAConstants.CustomMaterialAttributeGroupOrderResource, null);

            if (resourceName == null)
            {
                return null;
            }

            IResource resource = entityFactory.Create<IResource>();
            resource.Name = resourceName;
            resource.Load();

            return resource.GetHPOConfiguration();
        }
        #endregion

        #region Dimension Attributes
        /// <summary>
        /// set Dimension attributes on the material
        /// </summary>
        /// <param name="material"></param>
        /// <returns></returns>
        public static void SetDimensionAttributes(this IMaterial material, decimal length = 0, decimal width = 0, decimal thickness = 0, decimal weight = 0, bool loadAttributes = false)
        {
            IAttributeCollection attributeCollection = new AttributeCollection();
            Collection<string> attributesToRemove = new Collection<string>();

            if (loadAttributes)
            {
                // Load any dimensions that might already exist in the material
                material.LoadAttributes(new Collection<string>
                {
                    IKEAConstants.CustomMaterialLengthAttribute,
                    IKEAConstants.CustomMaterialWidthAttribute,
                    IKEAConstants.CustomMaterialThicknessAttribute,
                    IKEAConstants.CustomMaterialWeightAttribute
                });
            }

            // Length attribute
            decimal previousLength = material.GetAttributeValueOrDefault(IKEAConstants.CustomMaterialLengthAttribute, 0m);

            if (length > 0 && length != previousLength)
            {
                attributeCollection.Add(IKEAConstants.CustomMaterialLengthAttribute, length);
            }
            else if (length == 0 && previousLength > 0)
            {
                attributesToRemove.Add(IKEAConstants.CustomMaterialLengthAttribute);
            }

            // Width Attribute
            decimal previousWidth = material.GetAttributeValueOrDefault(IKEAConstants.CustomMaterialWidthAttribute, 0m);

            if (width > 0 && width != previousWidth)
            {
                attributeCollection.Add(IKEAConstants.CustomMaterialWidthAttribute, width);
            }
            else if (width == 0 && previousWidth > 0)
            {
                attributesToRemove.Add(IKEAConstants.CustomMaterialWidthAttribute);
            }

            // Thickness attribute
            decimal previousThickness = material.GetAttributeValueOrDefault(IKEAConstants.CustomMaterialThicknessAttribute, 0m);

            if (thickness > 0 && thickness != previousThickness)
            {
                attributeCollection.Add(IKEAConstants.CustomMaterialThicknessAttribute, thickness);
            }
            else if (thickness == 0 && previousThickness > 0)
            {
                attributesToRemove.Add(IKEAConstants.CustomMaterialThicknessAttribute);
            }

            // Weight attribute
            decimal previousWeight = material.GetAttributeValueOrDefault(IKEAConstants.CustomMaterialWeightAttribute, 0m);

            if (weight > 0 && weight != previousWeight)
            {
                attributeCollection.Add(IKEAConstants.CustomMaterialWeightAttribute, weight);
            }
            else if (length == 0 && previousWeight > 0)
            {
                attributesToRemove.Add(IKEAConstants.CustomMaterialWeightAttribute);
            }

            // Only save the attributes if there are any changes to them
            if (attributeCollection.Any())
            {
                material.SaveAttributes(attributeCollection);
            }

            // Only remove attributes if there are any to remove
            if (attributesToRemove.Any())
            {
                material.RemoveAttributes(attributesToRemove);
            }
        }

        /// <summary>
        /// set Dimension attributes on the material
        /// </summary>
        /// <param name="materialCollections"></param>
        /// <returns></returns>
        public static void SetDimensionAttributes(this IMaterialCollection materialCollection, decimal length = 0, decimal width = 0, decimal thickness = 0, decimal weight = 0, bool loadAttributes = false)
        {
            IAttributeCollection attributeCollection = new AttributeCollection();
            Collection<string> attributesToRemove = new Collection<string>();

            if (loadAttributes)
            {
                // Load any dimensions that might already exist in the material
                materialCollection[0].LoadAttributes(new Collection<string>
                {
                    IKEAConstants.CustomMaterialLengthAttribute,
                    IKEAConstants.CustomMaterialWidthAttribute,
                    IKEAConstants.CustomMaterialThicknessAttribute,
                    IKEAConstants.CustomMaterialWeightAttribute
                });
            }

            // Length attribute
            decimal previousLength = materialCollection[0].GetAttributeValueOrDefault(IKEAConstants.CustomMaterialLengthAttribute, 0m);

            if (length > 0 && length != previousLength)
            {
                attributeCollection.Add(IKEAConstants.CustomMaterialLengthAttribute, length);
            }
            else if (length == 0 && previousLength > 0)
            {
                attributesToRemove.Add(IKEAConstants.CustomMaterialLengthAttribute);
            }

            // Width Attribute
            decimal previousWidth = materialCollection[0].GetAttributeValueOrDefault(IKEAConstants.CustomMaterialWidthAttribute, 0m);

            if (width > 0 && width != previousWidth)
            {
                attributeCollection.Add(IKEAConstants.CustomMaterialWidthAttribute, width);
            }
            else if (width == 0 && previousWidth > 0)
            {
                attributesToRemove.Add(IKEAConstants.CustomMaterialWidthAttribute);
            }

            // Thickness attribute
            decimal previousThickness = materialCollection[0].GetAttributeValueOrDefault(IKEAConstants.CustomMaterialThicknessAttribute, 0m);

            if (thickness > 0 && thickness != previousThickness)
            {
                attributeCollection.Add(IKEAConstants.CustomMaterialThicknessAttribute, thickness);
            }
            else if (thickness == 0 && previousThickness > 0)
            {
                attributesToRemove.Add(IKEAConstants.CustomMaterialThicknessAttribute);
            }

            // Weight attribute
            decimal previousWeight = materialCollection[0].GetAttributeValueOrDefault(IKEAConstants.CustomMaterialWeightAttribute, 0m);

            if (weight > 0 && weight != previousWeight)
            {
                attributeCollection.Add(IKEAConstants.CustomMaterialWeightAttribute, weight);
            }
            else if (length == 0 && previousWeight > 0)
            {
                attributesToRemove.Add(IKEAConstants.CustomMaterialWeightAttribute);
            }

            // Only save the attributes if there are any changes to them
            if (attributeCollection.Any())
            {
                materialCollection.SaveAttributes(attributeCollection);
            }

            // Only remove attributes if there are any to remove
            if (attributesToRemove.Any())
            {
                materialCollection.RemoveAttributes(attributesToRemove);
            }
        }

        /// <summary>
        /// Return BOMProducts for a specific ProcessSegment and SubProcessSegment
        /// </summary>
        /// <returns> BOMProducts </returns>
        public static IBOMProductCollection GetBOMProductsForSubResource(this IMaterial manufacturingOrder, IResource subResource)
        {
            subResource.Load();

            Collection<string> attributesToLoad = new Collection<string>() {
                IKEAConstants.ProcessSegmentSequence,
                IKEAConstants.SubProcessSegmentName
            };

            subResource.LoadAttributes(attributesToLoad);
            string feederProcessSegment = subResource.GetAttributeValueOrDefault<string>(IKEAConstants.ProcessSegmentSequence, false);
            string feederSubProcessSegment = subResource.GetAttributeValueOrDefault<string>(IKEAConstants.SubProcessSegmentName, false);

            manufacturingOrder.Load();
            IBOMProductCollection filteredBOMProducts = entityFactory.CreateCollection<IBOMProductCollection>();
            IResolveBomContextsResult bomContext = manufacturingOrder.Product.ResolveBomContexts(manufacturingOrder);
            if (bomContext != null && bomContext.Bom != null)
            {
                IBOM bom = bomContext.Bom;
                bom.Load();
                IBOMProductCollection bOMProducts = bom.GetBOMProducts();
                foreach (IBOMProduct bOMProduct in bOMProducts)
                {
                    string bOMProductProcessSegment = bOMProduct.GetAttributeValueOrDefault<string>(IKEAConstants.BomProductProcessSegmentAttribute, true);
                    string bOMProductSubProcessSegment = bOMProduct.GetAttributeValueOrDefault<string>(IKEAConstants.BomProductSubProcessSegmentAttribute, true);

                    if (bOMProductProcessSegment == feederProcessSegment && bOMProductSubProcessSegment == feederSubProcessSegment)
                    {
                        filteredBOMProducts.Add(bOMProduct);
                    }
                }
            }
            return filteredBOMProducts;
        }
        #endregion

        /// <summary>
        /// Updates the CustomManufacturingOrderOutFeederRelation if the current main line has the completion mode set to ManualOutsorting
        /// </summary>
        /// <param name="material"></param>
        /// <param name="mainLineResource"></param>
        /// <param name="type"></param>
        /// <param name="palletizeResource"></param>
        /// <param name="quantity"></param>
        /// <exception cref="CmfBaseException"></exception>
        public static void UpdateCustomManufacturingOrderOutFeederRelation(this IMaterial material, IResource mainLineResource, string type, IResource palletizeResource, decimal quantity)
        {
            decimal processedOutsortedQuantity = 0;

            if (mainLineResource == null)
            {
                throw new IKEAException(IKEAConstants.CustomPalletizeNotSelectedNotificationLocalizedMessage);
            }

            CustomUnitCompletionModeEnum unitCompletionMode = mainLineResource.GetAttributeValueOrDefault<CustomUnitCompletionModeEnum>(IKEAConstants.CustomResourceAttributeUnitCompletionMode, true);

            string processLossMaterialType = genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.CustomProcessLossMaterialDefaultTypePath);

            bool isProcessLoss = String.Equals(type, processLossMaterialType, StringComparison.InvariantCultureIgnoreCase);

            // Valitdate and update Outsorted completed quantity
            if (unitCompletionMode == CustomUnitCompletionModeEnum.ManualOutsorting && !isProcessLoss)
            {
                if (palletizeResource == null)
                {
                    throw new IKEAException(IKEAConstants.CustomRequiredPalletizeResourceManualOutsortGroupMO);
                }

                var eiReply = ikeaUtilities.GetOutsortedQuantityFromEI(mainLineResource, material.Name);

                if (!eiReply.IsNullOrEmpty())
                {
                    // Get the relation for this specific resource:
                    ICustomManufacturingOrderOutFeeder resourceRelation = ikeaUtilities.GetManufacturingOrderOutFeederRelation(material, palletizeResource);
                    if (resourceRelation != null)
                    {
                        // Get current values:
                        decimal eiCurrentKnownOutsortedQuantity = eiReply.Where(R => R.Name.CompareStrings(palletizeResource.Name)).FirstOrDefault().TotalQuantity;
                        decimal currentProcessedOutsortedQuantity = resourceRelation.CurrentProcessedOutsortedQuantity.Value;

                        // Calculate the values to include the actual value out-sorting:
                        processedOutsortedQuantity = quantity + currentProcessedOutsortedQuantity;

                        // Do not allow TrackOut if completed quantity surpasses queue outsorted quantity on the line
                        if (processedOutsortedQuantity > eiCurrentKnownOutsortedQuantity)
                        {
                            throw new IKEAException(IKEAConstants.CustomTrackoutMaterialOutsortedQuantityExceeded,
                            material.Name);
                        }

                        // Update the current values:
                        resourceRelation.CurrentProcessedOutsortedQuantity = processedOutsortedQuantity;
                        resourceRelation.CurrentKnownOutsortedQuantity = eiCurrentKnownOutsortedQuantity;
                        resourceRelation.Save();
                    }
                }
                else
                {
                    //Equipment integration parse failed, could not validate
                    throw new IKEAException(IKEAConstants.CustomCurrentKnownOutsortedQuantityParseError);
                }
            }
        }

    }
}
