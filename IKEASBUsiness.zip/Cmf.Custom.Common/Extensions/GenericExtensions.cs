﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.IO;
using System.Linq;
using System.Xml;
using System.Xml.Serialization;
using Cmf.Common.CustomActionUtilities;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessObjects.QueryObject;
using Cmf.Foundation.BusinessOrchestration;
using Cmf.Foundation.BusinessOrchestration.Abstractions;
using Cmf.Foundation.BusinessOrchestration.ChangeSetManagement.InputObjects;
using Cmf.Foundation.BusinessOrchestration.GenericServiceManagement.InputObjects;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Foundation.Common.Base;
using Cmf.Foundation.Configuration;
using Cmf.Foundation.Configuration.Abstractions;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using Namotion.Reflection;
using Newtonsoft.Json;
using OtherConstants = Cmf.Navigo.Common.Constants;

namespace Cmf.Custom.IKEA.Common
{
    /// <summary>
    /// This class contains generic extension methods
    /// </summary>
    public static class GenericExtensions
    {
        #region Collection Utilities
        private static IGenericServiceOrchestration genericServiceOrchestration => ApplicationContext.CurrentServiceProvider.GetService<IGenericServiceOrchestration>();
        private static IChangeSetOrchestration changeSetOrchestration => ApplicationContext.CurrentServiceProvider.GetService<IChangeSetOrchestration>();
        private static IIKEAUtilities ikeaUtilities => ApplicationContext.CurrentServiceProvider.GetService<IIKEAUtilities>();
        private static IEntityFactory entityFactory => ApplicationContext.CurrentServiceProvider.GetService<IEntityFactory>();
        /// <summary>
        /// Removes the instance from cache
        /// </summary>
        /// <param name="entity">The entity to remove from cache</param>
        public static void RemoveFromInstanceCache(this IEntityBase entity)
        {
            EntityInstanceCacheObject entityInstanceCacheObject = new EntityInstanceCacheObject(entity);
            entityInstanceCacheObject.RemoveFromCache();
        }

        /// <summary>
        /// Loads a given set of IDs of the same base type in collection
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="instances">Collection instance. Cleared during load and populated with loaded items</param>
        /// <param name="idsToLoad">Collection of IDs to be loaded</param>
        public static void LoadByIDs<T, U>(this ICoreBaseCollection<T> instances, IEnumerable<long> idsToLoad, bool isDefinitionId = false, bool isEffective = false, int levelsToLoad = 0) where T : ICoreBase where U : CoreBase
        {
            if (instances != null && idsToLoad != null)
            {
                instances.Clear();

                List<long> validIds = idsToLoad.Distinct().Where(E => E > 0).ToList();
                if (validIds.Count > 0)
                {
                    FilterCollection filters = new FilterCollection();

                    if (!isDefinitionId)
                    {
                        filters.Add(
                        new Filter()
                        {
                            Name = "Id"
                            ,
                            Operator = FieldOperator.In
                            ,
                            Value = validIds
                        });
                    }
                    else
                    {
                        filters.Add(
                        new Filter()
                        {
                            Name = "DefinitionId",
                            Operator = FieldOperator.In,
                            Value = validIds
                        });

                        if (isEffective)
                        {
                            filters.Add(
                                new Filter()
                                {
                                    Name = "UniversalState"
                                    ,
                                    Operator = FieldOperator.IsEqualTo
                                    ,
                                    Value = 3
                                });
                            filters.Add(
                                new Filter()
                                {
                                    Name = "IsDefaultRevision"
                                    ,
                                    Operator = FieldOperator.IsEqualTo
                                    ,
                                    Value = true
                                });
                            filters.Add(
                                new Filter()
                                {
                                    Name = "Version"
                                    ,
                                    Operator = FieldOperator.GreaterThan
                                    ,
                                    Value = 0
                                });
                        }
                    }
                    var entityInstance = entityFactory.Create<T>();
                    Collection<object> foundObjects = genericServiceOrchestration.GetObjectsByFilter(new GetObjectsByFilterInput()
                    {
                        Filter = filters,
                        Type = entityInstance,
                        LevelsToLoad = levelsToLoad
                    }).Instance;

                    if (foundObjects != null && foundObjects.Count > 0)
                    {
                        foreach (object loadedObject in foundObjects)
                        {
                            instances.Add((T)loadedObject);
                        }
                    }
                }
            }
        }

        #endregion Collection Utilities

        #region Strings

        public static bool CompareStrings(this string stringA, string stringB)
        {
            return String.Equals(stringA, stringB, StringComparison.InvariantCultureIgnoreCase);
        }

        ///// <summary>
        ///// Trim a string from the start of another
        ///// </summary>
        ///// <param name="target">String to be trimmed</param>
        ///// <param name="trimString">String to be removed from the target string</param>
        ///// <returns>Trimmed string</returns>
        //public static string TrimStart(this string target, string trimString, bool trimFirstOccurrence = false)
        //{
        //    if (string.IsNullOrEmpty(trimString)) return target;

        //    string result = target;
        //    while (result.StartsWith(trimString))
        //    {
        //        result = result.Substring(trimString.Length);
        //        if (trimFirstOccurrence)
        //        {
        //            break;
        //        }
        //    }

        //    return result;
        //}

        #endregion

        /// <summary>
        /// Creates an Entity Type, assigning a new ChangeSet
        /// </summary>
        /// <param name="entity">The entity to be created</param>
        /// <param name="requestApproval">Whether or not to request approval for this entity type [Default: true]</param>
        /// <param name="isEffectiveOnApproval">Should the created ChangeSet be made effective on Approval [Default: true]</param>
        public static void CreateNewEntityVersion(this IEntityVersion entity, bool requestApproval = true, bool isEffectiveOnApproval = true)
        {
            if (entity.ChangeSet == null)
            {
                entity.ChangeSet = ikeaUtilities.CreateChangeSet(isEffectiveOnApproval);
            }
            entity.Revision = "A";
            if (!entity.ObjectExists())
            {
                genericServiceOrchestration.CreateObject(new CreateObjectInput
                {
                    
                    Object = entity
                });
            }
            else
            {
                entity.CreateVersion();
            }

            if (requestApproval)
            {
                changeSetOrchestration.RequestChangeSetApproval(new RequestChangeSetApprovalInput
                {
                    ChangeSet = entity.ChangeSet
                });
            }
        }

        /// <summary>
        /// Get all BOM products from a BOM
        /// </summary>
        /// <param name="bOM"></param>
        /// <returns></returns>
        public static IBOMProductCollection GetBOMProducts(this IBOM bOM, int levelsToLoad = 0)
        {
            bOM.LoadRelations(OtherConstants.BOMProduct, levelsToLoad);
            IBOMProductCollection bOMProducts = entityFactory.CreateCollection<IBOMProductCollection>();
            if (bOM.RelationCollection.ContainsKey(OtherConstants.BOMProduct))
            {
                bOMProducts.AddRange(bOM.RelationCollection[OtherConstants.BOMProduct].Cast<IBOMProduct>());
            }

            return bOMProducts;
        }

        /// <summary>
        /// Full Update Objects
        /// </summary>
        /// <param name="entities">dictionary with the entity and the parameters to update</param>
        /// <param name="attachmentsToAdd">Attachments To Add</param>
        /// <param name="attachmentsToRemove">Attachments To Remove</param>
        /// <returns></returns>
        public static Collection<object> FullUpdateObjects<T>(this Dictionary<T, FullUpdateParameters> entities,
                                                                List<IEntityDocumentationFullFileNamePair> attachmentsToAdd = null,
                                                                IEntityDocumentationCollection attachmentsToRemove = null) where T : IEntity
        {
            Dictionary<object, FullUpdateParameters> objects = entities.ToDictionary(E => E.Key as object, E => E.Value);

            // Update Entities
            FullUpdateObjectsInput fullUpdateObjectInput = new FullUpdateObjectsInput()
            {
                Objects = objects,
                AttachmentsToAdd = attachmentsToAdd,
                AttachmentsToRemove = attachmentsToRemove
            };

            return genericServiceOrchestration.FullUpdateObjects(fullUpdateObjectInput).Objects;
        }

        /// <summary>
        /// Returns the element in an enumeration with the highest value as returned by the getter function
        /// </summary>
        /// <typeparam name="T">The type of the elements</typeparam>
        /// <typeparam name="V">The type used for comparison</typeparam>
        /// <param name="items">The sequence of items to conside</param>
        /// <param name="getter">The comparison value getter</param>
        /// <returns></returns>
        public static T MaxBy<T, V>(this IEnumerable<T> items, Func<T, V> getter) where V : IComparable
        {
            return items.Aggregate((item1, item2) => getter(item1).CompareTo(getter(item2)) > 0 ? item1 : item2);
        }

        /// <summary>
        /// Returns the element in an enumeration with the highest value as returned by the getter function
        /// </summary>
        /// <typeparam name="T">The type of the elements</typeparam>
        /// <typeparam name="V">The type used for comparison</typeparam>
        /// <param name="items">The sequence of items to conside</param>
        /// <param name="getter">The comparison value getter</param>
        /// <returns></returns>
        public static T MaxBy<T, V>(this IEnumerable<T> items, Func<T, V?> getter) where V : struct
        {
            return items.Aggregate((item1, item2) => Nullable.Compare(getter(item1), getter(item2)) > 0 ? item1 : item2);
        }

        /// <summary>
        /// Returns the element in an enumeration with the lowest value as returned by the getter function
        /// </summary>
        /// <typeparam name="T">The type of the elements</typeparam>
        /// <typeparam name="V">The type used for comparison</typeparam>
        /// <param name="items">The sequence of items to conside</param>
        /// <param name="getter">The comparison value getter</param>
        /// <returns></returns>
        public static T MinBy<T, V>(this IEnumerable<T> items, Func<T, V> getter) where V : IComparable
        {
            return items.Aggregate((item1, item2) => getter(item1).CompareTo(getter(item2)) < 0 ? item1 : item2);
        }

        /// <summary>
        /// Returns the element in an enumeration with the lowest value as returned by the getter function
        /// </summary>
        /// <typeparam name="T">The type of the elements</typeparam>
        /// <typeparam name="V">The type used for comparison</typeparam>
        /// <param name="items">The sequence of items to conside</param>
        /// <param name="getter">The comparison value getter</param>
        /// <returns></returns>
        public static T MinBy<T, V>(this IEnumerable<T> items, Func<T, V?> getter) where V : struct
        {
            return items.Aggregate((item1, item2) => Nullable.Compare(getter(item1), getter(item2)) < 0 ? item1 : item2);
        }

        /// <summary>
        /// Filters out from this enumerable any child of group MOs, keeping only Regular MOs and Parent Group MOs
        /// </summary>
        /// <param name="items"></param>
        /// <returns></returns>
        public static IEnumerable<IMaterial> FilterChildMOsFromList(this IEnumerable<IMaterial> manufacturingOrders)
        {
            List<string> names = manufacturingOrders.Select(mo => mo.Name).Distinct().ToList();

            // If no orders in the list, return an empty material enumerable
            if (names.Count == 0)
            {
                return new IMaterial[] { };
            }

            #region Create Query to get Group MOs Parent of all materials
            IQueryObject query = new QueryObject();
            query.Description = "";
            query.EntityTypeName = IKEAConstants.CustomGroupMaterialManufacturingOrder;
            query.Name = "CustomRelationMaterialMaterial";
            query.Query = new Foundation.BusinessObjects.QueryObject.Query();
            query.Query.Distinct = false;
            query.Query.Filters = new FilterCollection()
            {
                new Filter()
                {
                    Name = "Name",
                    ObjectName = "Material",
                    ObjectAlias = "CustomGroupMaterialManufacturingOrder_TargetEntity_2",
                    Operator = Cmf.Foundation.Common.FieldOperator.In,
                    Value = names,
                    LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND,
                    FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                },
                new Filter()
                {
                    Name = "UniversalState",
                    ObjectName = IKEAConstants.CustomGroupMaterialManufacturingOrder,
                    ObjectAlias = "CustomGroupMaterialManufacturingOrder_1",
                    Operator = Cmf.Foundation.Common.FieldOperator.IsNotEqualTo,
                    Value = 4,
                    LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND,
                    FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                },
            };

            query.Query.Fields = new FieldCollection()
            {
                new Field()
                {
                    Alias = "Id",
                    ObjectName = "CustomGroupMaterialManufacturingOrder",
                    ObjectAlias = "CustomGroupMaterialManufacturingOrder_1",
                    IsUserAttribute = false,
                    Name = "Id",
                    Position = 0,
                    Sort = Cmf.Foundation.Common.FieldSort.NoSort
                },
                new Field()
                {
                    Alias = "TargetEntityName",
                    ObjectName = "Material",
                    ObjectAlias = "CustomGroupMaterialManufacturingOrder_TargetEntity_2",
                    IsUserAttribute = false,
                    Name = "Name",
                    Position = 1,
                    Sort = Cmf.Foundation.Common.FieldSort.NoSort
                }
            };
            query.Query.Relations = new RelationCollection()
            {
                new Relation()
                {
                    Alias = "",
                    IsRelation = false,
                    Name = "",
                    SourceEntity = "CustomGroupMaterialManufacturingOrder",
                    SourceEntityAlias = "CustomGroupMaterialManufacturingOrder_1",
                    SourceJoinType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.JoinType.InnerJoin,
                    SourceProperty = "TargetEntityId",
                    TargetEntity = "Material",
                    TargetEntityAlias = "CustomGroupMaterialManufacturingOrder_TargetEntity_2",
                    TargetJoinType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.JoinType.InnerJoin,
                    TargetProperty = "Id"
                },
            };

            #endregion

            // Hash set containing the child order names. Any MO with their name in here will be excluded from the Enumeration
            HashSet<string> childOrders = new HashSet<string>();

            System.Data.DataSet resultDataSet = query.Execute(false, new QueryParameterCollection());

            if (resultDataSet.HasData())
            {
                foreach (DataRow row in resultDataSet.Tables[0].Rows)
                {
                    string childName = row.Field<string>("TargetEntityName");

                    childOrders.Add(childName);
                }
            }

            return manufacturingOrders.Where(mo => !childOrders.Contains(mo.Name));
        }

        /// <summary>
        /// Converts a single entity to its MessageBus JSON string representation
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public static string ToMdbJsonString(this IEntity entity)
        {
            return entity.ConvertToMdbMessage().ToJsonString();
        }

        /// <summary>
        /// Converts a sequence of entities to theirs MessageBus JSON string representation
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public static string ToMdbJsonString(this IEnumerable<IEntity> entities)
        {
            return entities.Select(entity => entity.ConvertToMdbMessage()).ToJsonString();
        }

        /// <summary>
        /// Creates a new cloned instance of this Filter. The filter's value is not cloned but just copied by reference.
        /// </summary>
        /// <param name="instance"></param>
        /// <returns></returns>
        public static IFilter Clone(this IFilter instance)
        {
            if (instance == null)
            {
                return null;
            }

            return new Filter()
            {
                EntityTypeId = instance.EntityTypeId,
                EntityTypePropertyId = instance.EntityTypePropertyId,
                FilterType = instance.FilterType,
                IsOptional = instance.IsOptional,
                LogicalOperator = instance.LogicalOperator,
                Name = instance.Name,
                Operator = instance.Operator,
                Value = instance.Value,
                InnerFilters = instance.InnerFilters?.Clone(),
                ObjectType = instance.ObjectType,
                ObjectAlias = instance.ObjectAlias,
                ObjectName = instance.ObjectName,
            };
        }

        /// <summary>
        /// Creates a new cloned instance of this Filter Collection. Each filter in the collection is also recursively cloned.
        /// </summary>
        /// <param name="instance"></param>
        /// <returns></returns>
        public static IFilterCollection Clone(this IFilterCollection instance)
        {
            if (instance == null)
            {
                return null;
            }

            IFilterCollection collection = new FilterCollection();

            collection.AddRange(instance.Select(filter => filter.Clone()));

            return collection;
        }

        #region Attributes

        /// <summary>
        /// Add range of attributes
        /// </summary>
        /// <param name="entity">Entity to load the attribute</param>
        /// <param name="attributeName">Name of the attribute being loaded</param>
        public static void AddRange(this IAttributeCollection attributes, Dictionary<string, object> attributesToAdd)
        {
            foreach (KeyValuePair<string, object> attribute in attributesToAdd)
            {
                attributes.Add(attribute);
            }
        }

        ///// <summary>
        ///// Load a single attribute
        ///// </summary>
        ///// <param name="entity">Entity to load the attribute</param>
        ///// <param name="attributeName">Name of the attribute being loaded</param>
        //public static void LoadAttribute(this IEntityInstance entity, string attributeName)
        //{
        //    entity.LoadAttributes(new Collection<string>() { attributeName });
        //}

        ///// <summary>
        ///// Load a single attribute
        ///// </summary>
        ///// <param name="entity">Entity to load the attribute</param>
        ///// <param name="attributeName">Name of the attribute being loaded</param>
        //public static void LoadAttribute(this IEntityVersion entity, string attributeName)
        //{
        //    entity.LoadAttributes(new Collection<string>() { attributeName });
        //}

        #endregion

        #region Generic

        ///// <summary>
        ///// Method to check if a value is within a range of values
        ///// </summary>
        ///// <typeparam name="T">Object</typeparam>
        ///// <param name="obj">Value to check if withing range</param>
        ///// <param name="args">Range of values</param>
        ///// <returns></returns>
        //public static bool In<T>(this T obj, params T[] args)
        //{
        //    return args.Contains(obj);
        //}

        /// <summary>
        /// Get Configuration Value By Path
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="path">Configuration Path</param>
        /// <returns>Configuration Value</returns>
        public static T GetConfigurationValueByPath<T>(string path)
        {
            T returnValue = default(T);
            if (!String.IsNullOrEmpty(path))
            {
                IConfig config = null;
                if (Config.TryGetConfig(path, out config) && config != null)
                {
                    if (config.ValueType == typeof(System.Security.SecureString).FullName)
                    {
                        returnValue = (T)Convert.ChangeType(config.GetDecryptedConfigValue(), typeof(T));
                    }
                    else
                    {
                        returnValue = (T)Convert.ChangeType(config.Value, typeof(T));
                    }
                }
            }

            return returnValue;
        }

        #endregion

        #region Attributes

        /// <summary>
        /// Get Attribute Value of an Entity if the attribute exists
        /// </summary>
        /// <typeparam name="T">Type of the Attribute</typeparam>
        /// <param name="entity">Entity to obtain the attribute</param>
        /// <param name="attributeName">Name of the attribute to obtain</param>
        /// <param name="loadAttribute">Should it load the attribute?</param>
        /// <returns>Value of the Attribute</returns>
        //public static T GetAttributeValueOrDefault<T>(this IEntity entity, string attributeName, T defaultValue, bool loadAttribute = false)
        //{
        //    T attributeValue = defaultValue;

        //    if (entity.HasProperty(attributeName))
        //    {
        //        attributeValue = (T)entity.TryGetPropertyValue(attributeName, defaultValue);
        //    }

        //    return attributeValue;
        //}

        /// <summary>
        /// Get Attribute Value of an Entity if the attribute exists
        /// </summary>
        /// <typeparam name="T">Type of the Attribute</typeparam>
        /// <param name="entity">Entity to obtain the attribute</param>
        /// <param name="attributeName">Name of the attribute to obtain</param>
        /// <param name="loadAttribute">Should it load the attribute?</param>
        /// <returns>Value of the Attribute</returns>
        //public static T GetAttributeValueOrDefault<T>(this IEntity entity, string attributeName, bool loadAttribute = false)
        //{
        //    return entity.GetAttributeValueOrDefault<T>(attributeName, default(T), loadAttribute);
        //}

        /// <summary>
        /// Get Related Attribute Value of an Entity if the attribute exists
        /// </summary>
        /// <typeparam name="T">Type of the Attribute</typeparam>
        /// <param name="entity">Entity to obtain the attribute</param>
        /// <param name="attributeName">Name of the attribute to obtain</param>
        /// <param name="loadAttribute">Should it load the attribute?</param>
        /// <returns>Value of the Attribute</returns>
        //public static T GetRelatedAttributeValueOrDefault<T>(this IEntityVersion entity, string attributeName, bool loadAttribute = false)
        //{
        //    T attributeValue = default(T);

        //    if (entity.HasProperty(attributeName))
        //    {
        //        attributeValue = (T)entity.RelatedAttributes[attributeName];
        //    }

        //    return attributeValue;
        //}

        /// <summary>
        /// Get Attribute Value of an EntityRelation if the attribute exists
        /// </summary>
        /// <typeparam name="T">Type of the Attribute</typeparam>
        /// <param name="entity">EntityRelation to obtain the attribute</param>
        /// <param name="attributeName">Name of the attribute to obtain</param>
        /// <param name="loadAttribute">Should it load the attribute?</param>
        /// <returns>Value of the Attribute</returns>
        //public static T GetAttributeValueOrDefault<T>(this IEntityRelation entity, string attributeName, bool loadAttribute = false)
        //{
        //    T attributeValue = default(T);

        //    if (loadAttribute && (entity.Attributes == null || !entity.Attributes.ContainsKey(attributeName)))
        //    {
        //        entity.LoadAttributes(new Collection<string>() { attributeName });
        //    }

        //    if (entity.Attributes != null && entity.Attributes.ContainsKey(attributeName))
        //    {
        //        attributeValue = (T)entity.Attributes[attributeName];
        //    }

        //    return attributeValue;
        //}

        #endregion

       
    }
}
