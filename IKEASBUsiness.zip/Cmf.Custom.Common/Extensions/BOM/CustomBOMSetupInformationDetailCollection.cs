﻿using Cmf.Navigo.BusinessObjects;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Common.Extensions.BOM
{
    /// <summary>
    /// Collection Class for CustomBOMSetupInformationDetail
    /// </summary>
    public class CustomBOMSetupInformationDetailCollection : Collection<CustomBOMSetupInformationDetail>
    {

    }
}
