﻿using Cmf.Foundation.Common;
using Cmf.Navigo.BusinessObjects;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Common.CustomActionUtilities;
using Cmf.Foundation.Common.Abstractions;
using Microsoft.Extensions.DependencyInjection;

namespace Cmf.Custom.IKEA.Common.Extensions.BOM
{
    /// <summary>
    /// Class that extends BOMProduct, getting and setting attributes ProcessSegment, SubProcessSegment and ERPBOMOperationSequence from base class
    /// </summary>
    public class CustomBOMProductInformation
    {
        IBOMProduct _BOMProduct;
        private static IEntityFactory entityFactory => ApplicationContext.CurrentServiceProvider.GetService<IEntityFactory>();


        private IBOMProduct BOMProduct
        {
            get
            {
                return (_BOMProduct != null) ? _BOMProduct : _BOMProduct = entityFactory.Create<IBOMProduct>();
            }
            set
            {
                _BOMProduct = value;
            }
        }

        //
        // Summary:
        //     BOMProduct Order
        public int? Order
        {
            get
            {
                return BOMProduct.Order;
            }
            set
            {
                BOMProduct.Order = value;
            }
        }

        //
        // Summary:
        //     BOMProduct Target Entity
        public IProduct TargetEntity
        {
            get
            {
                return BOMProduct.TargetEntity;
            }
            set
            {
                BOMProduct.TargetEntity = value;
            }
        }

        public long TargetEntityId
        {
            get
            {
                return BOMProduct.GetNativeValue<long>("TargetEntity");
            }
        }

        //
        // Summary:
        //     ParentId where this BOM Product can be one substitute
        public IBOMProduct Parent
        {
            get
            {
                return BOMProduct.Parent;
            }
            set
            {
                BOMProduct.Parent = value;
            }
        }

        public long ParentId
        {
            get
            {
                return BOMProduct.GetNativeValue<long>("Parent");
            }
        }

        //
        // Summary:
        //     Gets or sets the Unique Id
        //
        // Remarks:
        //     Unique Id can only be set inside the Pipeline
        public string UniqueId
        {
            get
            {
                return BOMProduct.UniqueId;
            }
            set
            {
                BOMProduct.UniqueId = value;
            }
        }
        //
        // Summary:
        //     Gets or sets the units.
        public string Units
        {
            get
            {
                return BOMProduct.Units;
            }
            set
            {
                BOMProduct.Units = value;
            }
        }
        //
        // Summary:
        //     BOMProduct Position
        public int? Position
        {
            get
            {
                return BOMProduct.Position;
            }
            set
            {
                BOMProduct.Order = value;
            }
        }

        //
        // Summary:
        //     The lower tolerance, as a percentage Note: value must be interpreted as a percentage,
        //     e.g.: 10,3 -> 10,3%
        public decimal? LowerTolerance
        {
            get
            {
                return BOMProduct.LowerTolerance;
            }
            set
            {
                BOMProduct.LowerTolerance = value;
            }
        }
        //
        // Summary:
        //     The upper tolerance, as a percentage Note: value must be interpreted as a percentage,
        //     e.g.: 10,3 -> 10,3%
        public decimal? UpperTolerance
        {
            get
            {
                return BOMProduct.UpperTolerance;
            }
            set
            {
                BOMProduct.UpperTolerance = value;
            }
        }
        //
        // Summary:
        //     Step where the assembly will take place
        public IStep AssemblyStep
        {
            get
            {
                return BOMProduct.AssemblyStep;
            }
            set
            {
                BOMProduct.AssemblyStep = value;
            }
        }

        public long AssemblyStepId
        {
            get
            {
                return BOMProduct.GetNativeValue<long>("AssemblyStep");
            }
        }

        //
        // Summary:
        //     IsOptional
        public bool IsOptional
        {
            get
            {
                return BOMProduct.IsOptional;
            }
            set
            {
                BOMProduct.IsOptional = value;
            }
        }
        //
        // Summary:
        //     BOMProduct Whether the Source Product is consumed in the system or if it is only
        //     used as a reference
        public bool? IsReference
        {
            get
            {
                return BOMProduct.IsReference;
            }
            set
            {
                BOMProduct.IsReference = value;
            }
        }
        //
        // Summary:
        //     BOMProduct Is Product Mix Allowed
        public bool? IsProductMixAllowed
        {
            get
            {
                return BOMProduct.IsProductMixAllowed;
            }
            set
            {
                BOMProduct.IsProductMixAllowed = value;
            }
        }
        //
        // Summary:
        //     BOMProduct Source Entity
        public Cmf.Navigo.BusinessObjects.Abstractions.IBOM SourceEntity
        {
            get
            {
                return BOMProduct.SourceEntity;
            }
            set
            {
                BOMProduct.SourceEntity = value;
            }
        }

        public long SourceEntityId
        {
            get
            {
                return BOMProduct.GetNativeValue<long>("SourceEntity");
            }
        }

        //
        // Summary:
        //     BOMProductVersion Necessary quantity of the source product. It must be greater
        //     or equal to zero (zero is allowed)
        public decimal? Quantity
        {
            get
            {
                return BOMProduct.Quantity;
            }
            set
            {
                BOMProduct.Quantity = value;
            }
        }
        //
        // Summary:
        //     BOMProduct Source Step to gather material for the source Product
        public IStep Step
        {
            get
            {
                return BOMProduct.Step;
            }
            set
            {
                BOMProduct.Step = value;
            }
        }

        public long StepId
        {
            get
            {
                return BOMProduct.GetNativeValue<long>("Step");
            }
        }

        /// <summary>
        /// Collection of Substitute BOM Products
        /// </summary>
        public CustomBOMProductInformationCollection Substitutes { get; set; } = new CustomBOMProductInformationCollection();

        public CustomBOMProductInformation()
        {
        }

        public CustomBOMProductInformation(KeyValuePair<IBOMProduct, List<IBOMProduct>> product)
        {
            this.BOMProduct = product.Key;

            // CHeck if BOM Product has Substitutes
            if (!product.Value.IsNullOrEmpty())
            {
                this.Substitutes.AddRange(product.Value.Select(bp => new CustomBOMProductInformation(new KeyValuePair<IBOMProduct, List<IBOMProduct>>(bp, null))));
            }
        }

        /// <summary>
        /// Process segment attribute from BOMProduct
        /// </summary>
        public string ProcessSegment
        {
            get
            {
                if (!BOMProduct.Attributes.ContainsKey("ProcessSegment"))
                {
                    BOMProduct.LoadAttributes(new Collection<string>() { "ProcessSegment" });
                }

                return BOMProduct.Attributes.ContainsKey("ProcessSegment") && BOMProduct.Attributes["ProcessSegment"] != null ? BOMProduct.Attributes["ProcessSegment"].ToString() : null;
            }
            set
            {
                BOMProduct.Attributes["ProcessSegment"] = value;
            }
        }
        /// <summary>
        /// SubProcess segment from BOMProduct
        /// </summary>
        public string SubProcessSegment
        {
            get
            {
                if (!BOMProduct.Attributes.ContainsKey("SubProcessSegment"))
                {
                    BOMProduct.LoadAttributes(new Collection<string>() { "SubProcessSegment" });
                }

                return BOMProduct.Attributes.ContainsKey("SubProcessSegment") && BOMProduct.Attributes["SubProcessSegment"] != null ? BOMProduct.Attributes["SubProcessSegment"].ToString() : null;
            }
            set
            {
                BOMProduct.Attributes["SubProcessSegment"] = value;
            }
        }
        /// <summary>
        /// ERPBOM operation sequence from BOMProduct
        /// </summary>
        public string ERPBOMOperationSequence
        {
            get
            {
                if (!BOMProduct.Attributes.ContainsKey("ERPBOMOperationSequence"))
                {
                    BOMProduct.LoadAttributes(new Collection<string>() { "ERPBOMOperationSequence" });
                }

                return BOMProduct.Attributes.ContainsKey("ERPBOMOperationSequence") && BOMProduct.Attributes["ERPBOMOperationSequence"] != null ? BOMProduct.Attributes["ERPBOMOperationSequence"].ToString() : null;
            }
            set
            {
                BOMProduct.Attributes["ERPBOMOperationSequence"] = value;
            }
        }

        /// <summary>
        /// IsByProduct segment from BOMProduct
        /// </summary>
        public bool IsByProductSegment
        {
            get
            {
                if (!BOMProduct.Attributes.ContainsKey(IKEAConstants.BomProductIsByProductSegmentAttribute))
                {
                    BOMProduct.LoadAttributes(new Collection<string>() { IKEAConstants.BomProductIsByProductSegmentAttribute });
                }

                return BOMProduct.Attributes.ContainsKey(IKEAConstants.BomProductIsByProductSegmentAttribute)
                    && BOMProduct.Attributes[IKEAConstants.BomProductIsByProductSegmentAttribute] != null
                    ? (bool)BOMProduct.Attributes[IKEAConstants.BomProductIsByProductSegmentAttribute]
                    : false;
            }
            set
            {
                BOMProduct.Attributes[IKEAConstants.BomProductIsByProductSegmentAttribute] = value;
            }
        }

        public IBOMProduct GetBase()
        {
            return this.BOMProduct;
        }

        //
        // Summary:
        //     Gets or sets the custom source step of the bom product.
        public string SourceStep
        {
            get
            {
                if (!BOMProduct.Attributes.ContainsKey(IKEAConstants.BomProductCustomSourceStepAttribute))
                {
                    BOMProduct.LoadAttributes(new Collection<string>() { IKEAConstants.BomProductCustomSourceStepAttribute });
                }
                return BOMProduct.GetAttributeValueOrDefault<string>(IKEAConstants.BomProductCustomSourceStepAttribute);
            }
            set
            {
                BOMProduct.Attributes[IKEAConstants.BomProductCustomSourceStepAttribute] = value;
            }
        }

    }


}
