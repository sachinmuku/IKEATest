﻿using System;
using System.Collections.Generic;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Common.Extensions.BOM
{
    /// <summary>
    /// CustomBOMConsumptionInformation Class 
    /// </summary>
    public class CustomBOMConsumptionInformation
    {
        #region Public Properties

        /// <summary>
        /// Resoure Attribute
        /// </summary>
        public string ProcessSegment { get; set; }

        /// <summary>
        /// Resoure Attribute
        /// </summary>
        public string SubProcessSegment { get; set; }

        /// <summary>
        /// ERP BOM operation sequence
        /// </summary>
        public string ERPBOMOperationSequence { get; set; }

        /// <summary>
        /// Sub resource
        /// </summary>
        public IResource Resource { get; set; }

        /// <summary>
        /// Quantity to assemble
        /// </summary>
        public Decimal QuantityToAssemble { get; set; }

        /// <summary>
        /// Dictionary of materials to consume and its quantity
        /// </summary>
        public Dictionary<IMaterial, Decimal> MaterialsToConsume { get; set; }

        #endregion
    }
}
