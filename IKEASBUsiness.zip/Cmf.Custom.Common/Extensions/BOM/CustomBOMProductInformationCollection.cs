﻿using Cmf.Navigo.BusinessObjects;
using System.Collections.ObjectModel;
using System.Linq;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Common.CustomActionUtilities;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Foundation.Common;
using Microsoft.Extensions.DependencyInjection;

namespace Cmf.Custom.IKEA.Common.Extensions.BOM
{

    /// <summary>
    /// Collection class for CustomBOMProductInformation
    /// </summary>
    public class CustomBOMProductInformationCollection : Collection<CustomBOMProductInformation>
    {
        private static IEntityFactory entityFactory => ApplicationContext.CurrentServiceProvider.GetService<IEntityFactory>();

        /// <summary>
        /// Method to compare two CustomBOMProductInformation Entities
        /// </summary>
        /// <param name="customBOMProductInformation"></param>
        /// <returns>areEqual</returns>
        public bool AreEqual(CustomBOMProductInformationCollection customBOMProductInformation)
        {
            bool areEqual = false;

            if (this != null
                && customBOMProductInformation != null)
            {
                var source = this.Select(E => new { E.TargetEntityId, E.StepId, E.Quantity, E.IsReference, E.Units, E.ProcessSegment, E.SubProcessSegment, E.ERPBOMOperationSequence, E.IsByProductSegment });
                var target = customBOMProductInformation.Select(E => new { E.TargetEntityId, E.StepId, E.Quantity, E.IsReference, E.Units, E.ProcessSegment, E.SubProcessSegment, E.ERPBOMOperationSequence, E.IsByProductSegment });

                int sourceVsTarget = source.Intersect(target).Count();
                int targetVsSource = target.Intersect(source).Count();

                if (this.Count == customBOMProductInformation.Count
                    && sourceVsTarget == this.Count
                    && sourceVsTarget == targetVsSource)
                {
                    // Go through all the BOM Products to compare its substitutes
                    foreach (var sourceItem in source)
                    {
                        // Get source BOM Product
                        CustomBOMProductInformation sourceBomProduct = this.First(t => t.TargetEntityId == sourceItem.TargetEntityId
                                                                                        && t.StepId == sourceItem.StepId
                                                                                        && t.Quantity == sourceItem.Quantity
                                                                                        && t.IsReference == sourceItem.IsReference
                                                                                        && t.Units == sourceItem.Units
                                                                                        && t.ProcessSegment == sourceItem.ProcessSegment
                                                                                        && t.SubProcessSegment == sourceItem.SubProcessSegment
                                                                                        && t.ERPBOMOperationSequence == sourceItem.ERPBOMOperationSequence
                                                                                        && t.IsByProductSegment == sourceItem.IsByProductSegment);

                        // Get target BOM Product
                        CustomBOMProductInformation targetBomProduct = customBOMProductInformation.First(t => t.TargetEntityId == sourceItem.TargetEntityId
                                                                                                                && t.StepId == sourceItem.StepId
                                                                                                                && t.Quantity == sourceItem.Quantity
                                                                                                                && t.IsReference == sourceItem.IsReference
                                                                                                                && t.Units == sourceItem.Units
                                                                                                                && t.ProcessSegment == sourceItem.ProcessSegment
                                                                                                                && t.SubProcessSegment == sourceItem.SubProcessSegment
                                                                                                                && t.ERPBOMOperationSequence == sourceItem.ERPBOMOperationSequence
                                                                                                                && t.IsByProductSegment == sourceItem.IsByProductSegment);

                        // Get source Substitutes BOM Products
                        var sourceSubstitute = sourceBomProduct.Substitutes.Select(E => new { A = E.TargetEntityId, B = E.StepId, C = E.Quantity, D = E.IsReference, X = E.Units, Y = E.ProcessSegment, Z = E.SubProcessSegment, K = E.ERPBOMOperationSequence, I = E.IsByProductSegment });
                        // Get target Substitutes BOM Products
                        var targetSubstitute = targetBomProduct.Substitutes.Select(E => new { A = E.TargetEntityId, B = E.StepId, C = E.Quantity, D = E.IsReference, X = E.Units, Y = E.ProcessSegment, Z = E.SubProcessSegment, K = E.ERPBOMOperationSequence, I = E.IsByProductSegment });

                        // For them to be equal, either are both empty or, have the same number of records and the records have the same values
                        if (sourceSubstitute.IsNullOrEmpty()
                            && targetSubstitute.IsNullOrEmpty())
                        {
                            areEqual = true;
                        }
                        else if (sourceSubstitute.Count() == targetSubstitute.Count())
                        {
                            int sourceSubstituteVsTargetSubstitute = sourceSubstitute.Intersect(targetSubstitute).Count();
                            int targetSubstituteVsSourceSubstitute = targetSubstitute.Intersect(sourceSubstitute).Count();

                            if (sourceSubstituteVsTargetSubstitute == targetSubstituteVsSourceSubstitute)
                            {
                                areEqual = true;
                            }
                        }
                    }
                }
            }

            return areEqual;
        }

        /// <summary>
        /// Method to return BOMProductCollection from CustomBOMProductInformationCollection
        /// </summary>
        /// <returns>BOMProductCollection</returns>
        public IBOMProductCollection GetBase()
        {
            IBOMProductCollection bOMProducts = entityFactory.CreateCollection<IBOMProductCollection>();

            bOMProducts.AddRange(this.Select(bp => bp.GetBase()));
            bOMProducts.AddRange(this.Where(bp => !bp.Substitutes.IsNullOrEmpty()).SelectMany(bp => bp.Substitutes.Select(bps => bps.GetBase())));

            return bOMProducts;
        }
    }
}
