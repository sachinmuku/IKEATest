﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Common.Extensions.BOM
{
    public class CustomBOMTemplateDetail
    {
        /// <summary>
        /// Internal ratio value
        /// </summary>
        private decimal ratio = 0;

        /// <summary>
        /// Template Name
        /// </summary>
        public string Template { get; set; }

        /// <summary>
        /// Process Segment
        /// </summary>
        public string ProcessSegment { get; set; }

        /// <summary>
        /// Sub Process Segment
        /// </summary>
        public string SubProcessSegment { get; set; }

        /// <summary>
        /// Product
        /// </summary>
        public string Product { get; set; }

        /// <summary>
        /// Ratio
        /// NOTE: If no ratio is defined in the smart table 
        /// it will calculate it based on the Numerator / Denominator
        /// </summary>
        public decimal Ratio 
        { 
            get
            {
                // If a numerator and denominator are defined then calculate the ratio based on does values
                if (Numerator.HasValue 
                    && Denominator.GetValueOrDefault() > 0)
                {
                    ratio = (decimal)Numerator.GetValueOrDefault() / Denominator.GetValueOrDefault();
                }

                return ratio;
            }
            set
            {
                ratio = value;
            }
        }

        /// <summary>
        /// Numerator
        /// </summary>
        public int? Numerator { get; set; }

        /// <summary>
        /// Denominator
        /// </summary>
        public int? Denominator { get; set; }

    }
}
