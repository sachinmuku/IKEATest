﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Foundation.Common;
using Cmf.Navigo.BusinessObjects;
using NavigoConstants = Cmf.Navigo.Common;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Custom.IKEA.BusinessObjects.Abstractions;
using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessOrchestration.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using Cmf.Custom.IKEA.Common.Exceptions;
using Cmf.Custom.IKEA.Common.Enums;

namespace Cmf.Custom.IKEA.Common.Extensions.BOM
{
    /// <summary>
    /// Class with the information for BOM Setup
    /// </summary>
    public class CustomBOMSetupInformation
    {
        private static IIKEAUtilities ikeaUtilities => ApplicationContext.CurrentServiceProvider.GetService<IIKEAUtilities>();
        private static IGenericUtilities genericUtilities => ApplicationContext.CurrentServiceProvider.GetService<IGenericUtilities>();
        private static IMaterialOrchestration materialOrchestration => ApplicationContext.CurrentServiceProvider.GetService<IMaterialOrchestration>();
        private static IDeeContextUtilities deeContextUtilities => ApplicationContext.CurrentServiceProvider.GetService<IDeeContextUtilities>();

        private static IEntityFactory entityFactory => ApplicationContext.CurrentServiceProvider.GetService<IEntityFactory>();

        /// <summary>
        /// Name of the action
        /// </summary>
        private static string objectTypeName = typeof(CustomBOMSetupInformation).FullName;

        #region Private Properties

        /// <summary>
        /// private collection of CustomBOMSetupInformationDetail
        /// </summary>
        private CustomBOMSetupInformationDetailCollection _CustomBOMSetupInformationDetailCollection;

        /// <summary>
        /// private collection of CustomBOMProductInformation
        /// </summary>
        private CustomBOMProductInformationCollection _CustomBOMProductInformationCollection;

        /// <summary>
        /// private BOM
        /// </summary>
        private Cmf.Navigo.BusinessObjects.Abstractions.IBOM _BOM;

        /// <summary>
        /// Private Resource
        /// </summary>
        private IResource _Resource;

        #endregion

        #region Public Properties

        /// <summary>
        /// BOM
        /// </summary>
        public Cmf.Navigo.BusinessObjects.Abstractions.IBOM BOM { get { return _BOM; } }

        /// <summary>
        /// Top Most Resource
        /// </summary>
        public IResource Resource { get { return _Resource; } }

        /// <summary>
        /// Collection of CustomBOMSetupInformationDetail
        /// </summary>
        public CustomBOMSetupInformationDetailCollection CustomBOMSetupInformationDetails { get { return _CustomBOMSetupInformationDetailCollection; } }

        /// <summary>
        /// Collection of CustomBOMProductInformation
        /// </summary>
        public CustomBOMProductInformationCollection CustomBOMProductInformations { get { return _CustomBOMProductInformationCollection; } }

        #endregion

        #region Methods

        /// <summary>
        /// CustomBOMSetupInformation Constructor
        /// </summary>
        /// <param name="bom"></param>
        /// <param name="resource"></param>
        public CustomBOMSetupInformation(Cmf.Navigo.BusinessObjects.Abstractions.IBOM bom, IResource resource)
        {
			this._CustomBOMSetupInformationDetailCollection = new CustomBOMSetupInformationDetailCollection();

            if (bom != null && resource != null)
            {
                // Check if received resource is the Top Most Resource. If it isn't updates reference to the Top Most
                IResource topMostResource = resource.GetTopMostResource();
                if (topMostResource != null && !topMostResource.Name.CompareStrings(resource.Name))
                {
                    resource = topMostResource;
                }

                this._BOM = bom;
                this._Resource = resource;
                this._CustomBOMProductInformationCollection = bom.GetCustomBOMProductInformation();

                // Get all childs from Top Most Resource
                IResourceCollection resources = resource.GetResourceSubResources();

                if (!resources.IsNullOrEmpty())
                {
                    // Load ProcessSegmentSequence and SubProcessSegmentName resource attributes
                    resources.LoadAttributes(new Collection<string>() { IKEAConstants.ProcessSegmentSequence, IKEAConstants.SubProcessSegmentName });

                    List<Tuple<string, string, IResource>> tuples = resources.Select(t =>
                        new Tuple<string, string, IResource>(
                                t.GetAttributeValueOrDefault<string>(IKEAConstants.ProcessSegmentSequence),
                                t.GetAttributeValueOrDefault<string>(IKEAConstants.SubProcessSegmentName),
                                t)
                    ).ToList();


                    // Get the all resources that eventually belong to a distributed consumption group in this main line:
                    IResourceCollection distFeeders = resource.GetDistributedFeedersFromMainLine();

                    // Fill some CustomBomProductInformation properties and collect eligible resources
                    IResourceCollection eligibleResources = entityFactory.CreateCollection<IResourceCollection>();
                    foreach (CustomBOMProductInformation productInformation in this._CustomBOMProductInformationCollection)
                    {
                        if (ikeaUtilities.IsBOMProductReference(productInformation) && !string.IsNullOrWhiteSpace(productInformation.ProcessSegment))
                        {
                            CustomBOMSetupInformationDetail detail = new CustomBOMSetupInformationDetail()
                            {
                                ProcessSegment = productInformation.ProcessSegment,
                                SubProcessSegment = productInformation.SubProcessSegment,
                                ERPBOMOperationSequence = productInformation.ERPBOMOperationSequence,
                            };

                            // Add the resource to detail.Resource
                            IResource matchedResourceForSegmentValues = tuples.Where(t =>
                                            t.Item1.CompareStrings(productInformation.ProcessSegment) &&
                                            t.Item2.CompareStrings(productInformation.SubProcessSegment)
                            ).Select(t => t.Item3).FirstOrDefault();


                            if (matchedResourceForSegmentValues != null)
                            {

                                // Validate that the BOM is not requiring material directly from a feeder that belongs to a distributed configuration:
                                if (distFeeders.Any(DF => DF.Id == matchedResourceForSegmentValues.Id))
                                {
                                    var res = distFeeders.Where(DF => DF.Id == matchedResourceForSegmentValues.Id).FirstOrDefault();
                                    res.Load();
                                    throw new IKEAException(IKEAConstants.CustomDistributedResourceProviderErrorInBOMLocalizedMessage, res.Name);
                                }

                                // Distributed Consumption feeders:
                                ICustomResourceConsumptionProviderCollection customDistributedConsumptionProviders = ikeaUtilities.GetDistributedProvidersFromFeeder(matchedResourceForSegmentValues);

                                // If we have more than one feeder in the line:
                                if (!customDistributedConsumptionProviders.IsNullOrEmpty())
                                {
                                    IResourceCollection distributedResources = entityFactory.CreateCollection<IResourceCollection>();

                                    // Add the main feeder:
                                    distributedResources.Add(matchedResourceForSegmentValues);

                                    // Add distributed feeders:
                                    distributedResources.AddRange(customDistributedConsumptionProviders.Select(DCP => DCP.TargetEntity));

                                    eligibleResources.AddRange(distributedResources);
                                    detail.Resources = distributedResources;
                                    detail.ConsumptionMode = (CustomConsumptionModeEnum)customDistributedConsumptionProviders.FirstOrDefault().ConsumptionMode;
                                }
                                else
                                {
                                    // If the resource under defined process segment has a relation to a 'Tank', it should be replaced by that one (relation Target)
                                    ICustomResourceConsumptionProvider customResourceConsumptionProvider = ikeaUtilities.GetActiveSharedProviderFromFeeder(matchedResourceForSegmentValues);

                                    if (customResourceConsumptionProvider != null)
                                    {
                                        eligibleResources.Add(customResourceConsumptionProvider.TargetEntity);
                                        detail.Resources = entityFactory.CreateCollection<IResourceCollection>();
                                        detail.Resources.Add(customResourceConsumptionProvider.TargetEntity);
                                        detail.ConsumptionMode = (CustomConsumptionModeEnum)customResourceConsumptionProvider.ConsumptionMode;
                                    }

                                    // If not shared provider was found, keep using the original feeder:
                                    if (detail.Resources.IsNullOrEmpty())
                                    {
                                        matchedResourceForSegmentValues.LoadRelations(NavigoConstants.Constants.MaterialResource);
                                        eligibleResources.Add(matchedResourceForSegmentValues);
                                        detail.Resources = entityFactory.CreateCollection<IResourceCollection>();
                                        detail.Resources.Add(matchedResourceForSegmentValues);
                                    ;
                                    }
                                }
                            }
                            _CustomBOMSetupInformationDetailCollection.Add(detail);

                        }
                    }

                    eligibleResources.Load();
                    eligibleResources.LoadRelations(NavigoConstants.Constants.MaterialResource);

                    IMaterialResourceCollection materialResources = entityFactory.CreateCollection<IMaterialResourceCollection>();
                    materialResources.AddRange(eligibleResources
                        .Where(mr => mr.RelationCollection.ContainsKey(NavigoConstants.Constants.MaterialResource))
                        .SelectMany(mr => mr.RelationCollection[NavigoConstants.Constants.MaterialResource]
                        .Select(x => x as IMaterialResource)));

                    if (!materialResources.IsNullOrEmpty())
                    {

                        // Fill the AttachedMaterials information
                        foreach (CustomBOMSetupInformationDetail setupInformation in _CustomBOMSetupInformationDetailCollection)
                        {

                            setupInformation.AttachedMaterials = new Dictionary<long, Dictionary<int, IMaterial>>();

                            foreach (IResource setupInformationResource in setupInformation.Resources)
                            {
                                IMaterialCollection materials = entityFactory.CreateCollection<IMaterialCollection>();

                                // Get materials in the feeders ordered
                                IResourceMaterialInformationCollection resourceInformationCollection = setupInformationResource.GetResourceMaterialInformation(false);

                                if (!resourceInformationCollection.IsNullOrEmpty())
                                {
                                    materials.AddRange(resourceInformationCollection.OrderBy(RMI => RMI.Order).Select(m => m.Material));

                                    Dictionary<int, IMaterial> attachedMaterials = new Dictionary<int, IMaterial>();
                                    int counter = 1;
                                    foreach (IMaterial material in materials)
                                    {
                                        attachedMaterials.Add(counter, material);
                                        counter++;
                                    }

                                    setupInformation.AttachedMaterials[setupInformationResource.Id] = attachedMaterials;
                                }
                                else
                                {
                                    setupInformation.AttachedMaterials[setupInformationResource.Id] = new Dictionary<int, IMaterial>();
                                }
                            }
                        }
                    }
                }
            }
		}

        /// <summary>
        /// Validates information for Setup
        /// </summary>
        /// <returns></returns>
        public bool CustomIsSetUpValid()
        {
            CustomOperationExecutionSettings res = new CustomOperationExecutionSettings();

            res.Output = new Dictionary<String, Object>() { { IKEAConstants.MaterialIsBOMSetupValid, false } };

            // Log method start
            Cmf.Foundation.Common.Utilities.StartMethod(objectTypeName,
                                    "CustomIsSetUpValid",
                                    new KeyValuePair<String, Object>("CustomOperationExecutionSettings", res));

            // Does previous actions override this one
            if (!res.IsOverride)
            {
                // Validate if key exists in the dictionary
                if (!res.Output.ContainsKey(IKEAConstants.MaterialIsBOMSetupValid))
                {
                    res.Output = new Dictionary<String, Object>() { { IKEAConstants.MaterialIsBOMSetupValid, false } };
                }

                if (!_CustomBOMProductInformationCollection.IsNullOrEmpty())
                {
                    foreach (CustomBOMProductInformation productInformation in _CustomBOMProductInformationCollection)
                    {
                        if (ikeaUtilities.IsBOMProductReference(productInformation))
                        {
                            CustomBOMSetupInformationDetail customBOMSetupInformationDetail = _CustomBOMSetupInformationDetailCollection.FirstOrDefault(setupD => setupD.ProcessSegment.CompareStrings(productInformation.ProcessSegment) &&
                                                                                       setupD.SubProcessSegment.CompareStrings(productInformation.SubProcessSegment));


                            if (customBOMSetupInformationDetail == null || customBOMSetupInformationDetail.Resources.IsNullOrEmpty())
                            {
                                throw new IKEAException(IKEAConstants.CustomResourceNotFoundForProcessSegmentInBOMLocalizedMessage, productInformation.ProcessSegment, productInformation.SubProcessSegment, productInformation.SourceEntity.Name);
                            }

                            // Because we can have multiple feeders: 
                            foreach (IResource resource in customBOMSetupInformationDetail.Resources)
                            {
                                if (customBOMSetupInformationDetail != null
                                    && !customBOMSetupInformationDetail.Resources.IsNullOrEmpty()
                                    && !customBOMSetupInformationDetail.AttachedMaterials.IsNullOrEmpty()
                                    && !customBOMSetupInformationDetail.AttachedMaterials[resource.Id].IsNullOrEmpty())
                                {

                                    // Get the consumption mode of the feeder
                                    CustomFeederConsumptionModeEnum feederConsumptionMode = resource.GetAttributeValueOrDefault<CustomFeederConsumptionModeEnum>(IKEAConstants.CustomResourceAttributeFeederConsumptionMode, true);

                                    switch (feederConsumptionMode)
                                    {
                                        // ProductSequenceBased takes into account the Product
                                        // It will try to find the first a material in the feeder that contains the same product as the BOM
                                        case CustomFeederConsumptionModeEnum.ProductSequenceBased:
                                            {

                                                res.Output[IKEAConstants.MaterialIsBOMSetupValid] = customBOMSetupInformationDetail.AttachedMaterials[resource.Id].Values.Any(m => m.GetNativeValue<long>(NavigoConstants.Constants.Product) == productInformation.TargetEntityId
                                                                                                                                                                || productInformation.Substitutes.Any(bp => bp.TargetEntityId == m.GetNativeValue<long>(NavigoConstants.Constants.Product)));
                                                break;
                                            }
                                        // SequenceBased does not take into account the Product
                                        // It will validate the product of the first material in the feeder with the on in the BOM
                                        default:
                                        case CustomFeederConsumptionModeEnum.SequenceBased:
                                            {
                                                var material = customBOMSetupInformationDetail.AttachedMaterials[resource.Id][1];
                                                long materialProductId = material.GetNativeValue<long>(NavigoConstants.Constants.Product);

                                                if (productInformation.TargetEntityId == materialProductId
                                                    || productInformation.Substitutes.Any(bp => bp.TargetEntityId == materialProductId))
                                                {
                                                    res.Output[IKEAConstants.MaterialIsBOMSetupValid] = true;
                                                }
                                                else
                                                {
                                                    res.Output[IKEAConstants.MaterialIsBOMSetupValid] = false;
                                                }

                                                break;
                                            }
                                    }

                                    // If at this point the setup is already valid there is no need to validate the other distributed feeders:
                                    if (Convert.ToBoolean(res.Output[IKEAConstants.MaterialIsBOMSetupValid]) == true)
                                    {
                                        break;
                                    }
                                }
                                else
                                {
                                    res.Output[IKEAConstants.MaterialIsBOMSetupValid] = false;
                                }
                            }

                            // If at this point the setup is already not valid there is no need to validate any other material
                            if (Convert.ToBoolean(res.Output[IKEAConstants.MaterialIsBOMSetupValid]) == false)
                            {
                                break;
                            }

                        }
                    }
                }
            }

            // log method exit
            long objectInstanceId = -1;
            long objectTypeId = -1;
            Cmf.Foundation.Common.Utilities.EndMethod(objectTypeId, objectInstanceId, new KeyValuePair<String, Object>("CustomOperationExecutionSettings", res));

            return (bool)res.Output[IKEAConstants.MaterialIsBOMSetupValid];
        }


        #endregion

    }
}
