﻿
using System.Collections.Generic;
using Cmf.Custom.IKEA.Common.Enums;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Common.Extensions.BOM
{
    /// <summary>
    /// BOM Setup Information
    /// </summary>
    public class CustomBOMSetupInformationDetail
    {
        /// <summary>
        /// ProcessSegment from resource attribute ProcessSegment
        /// </summary>
        public string ProcessSegment { get; set; }

        /// <summary>
        /// SubProcessSegment from resource attribute SubProcessSegmentName
        /// </summary>
        public string SubProcessSegment { get; set; }

        /// <summary>
        /// Indicates the sequence number of a given consumable feed
        /// </summary>
        public string ERPBOMOperationSequence { get; set; }

        /// <summary>
        /// Resource where a certains BOMProduct will be used
        /// </summary>
        public IResourceCollection Resources { get; set; }

        /// <summary>
        /// All materials attached in the consumable feed and its order
        /// Key: Resource(feeder) / Value: consumable order and consumable Material
        /// </summary>
        public Dictionary<long, Dictionary<int, IMaterial>> AttachedMaterials { get; set; }

        /// <summary>
        /// Material Consumption mode
        /// </summary>
        public CustomConsumptionModeEnum ConsumptionMode { get; set; }

    }
}
