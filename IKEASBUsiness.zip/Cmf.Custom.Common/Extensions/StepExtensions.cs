﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Navigo.BusinessObjects;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Foundation.Common;
using Microsoft.Extensions.DependencyInjection;
using Namotion.Reflection;
using Cmf.Custom.IKEA.Common.Abstractions;

namespace Cmf.Custom.IKEA.Common.Extensions
{
    /// <summary>
    /// This class contains flow extension methods
    /// </summary>
    public static class StepExtensions
    {
        private static IEntityFactory entityFactory => ApplicationContext.CurrentServiceProvider.GetService<IEntityFactory>();

        /// <summary>
        /// Retrieves in which area the current step is assigned regarding the provided facility
        /// </summary>
        /// <param name="instance">Step instance for which the area will be determined</param>
        /// <param name="facility">Facility under which the area of the step is to be searched</param>
        /// <returns>Area containing the step within the provided facility. Null otherwise</returns>
        public static IArea GetFacilityArea(this IStep instance, IFacility facility)
        {
            IArea returnObject = null;

            if (instance != null && facility != null && instance.Id > 0 && facility.Id > 0)
            {
                // load all step areas
                instance.LoadStepAreas(0);

                // try to find area that is withing targeted facility for this step
                if (instance.StepAreas != null && instance.StepAreas.Count > 0)
                {
                    // collect all different areas and load them in bulk
                    Collection<long> areaIDs = new Collection<long>(instance.StepAreas.Select(StepArea => StepArea.GetNativeValue<long>("TargetEntity")).ToList());

                    // load areas in bulk
                    IAreaCollection allAreaObjects = entityFactory.CreateCollection<IAreaCollection>();
                    allAreaObjects.LoadByIDs<IArea, Area>(areaIDs);

                    // get first (and only by design) occurence
                    long facilityId = facility.Id;
                    returnObject = allAreaObjects.FirstOrDefault(Area => Area.GetNativeValue<long>("Facility") == facilityId);
                }
            }

            return returnObject;
        }

    }
}
