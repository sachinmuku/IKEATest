﻿using Cmf.Foundation.BusinessObjects;
using System;
using System.Data;
using System.Linq;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Common.CustomActionUtilities;

namespace Cmf.Custom.IKEA.Common.Extensions
{
    public static class SmartTableExtensions
    {

        public static INgpDataSet FirstResolveOrder(this ISmartTable smartTable, INgpDataRow dataRow)
        {
            INgpDataSet ngpDSet = null;
            if (smartTable != null && (smartTable.Id > 0 || !string.IsNullOrEmpty(smartTable.Name)) && dataRow != null && dataRow.Count > 0)
            {
                smartTable.Load();
                INgpDataSet resultSet = smartTable.Resolve(dataRow, false);
                DataSet resultDataSet = NgpDataSet.ToDataSet(resultSet);
                if (resultDataSet.HasData())
                {
                    DataTable resultsTable = resultDataSet.Tables[0];
                    int order = resultsTable.Rows.Cast<DataRow>().Min(E => Convert.ToInt32(E[IKEAConstants.ResolveOrderName]));

                    DataSet dSet = resultDataSet.Clone();
                    foreach (DataRow dr in resultsTable.Rows)
                    {
                        if ((int)dr[IKEAConstants.ResolveOrderName] == order)
                        {
                            dSet.Tables[0].ImportRow(dr);
                        }
                    }
                    dSet.AcceptChanges();
                    ngpDSet = NgpDataSet.FromDataSet(dSet);
                }
            }
            return ngpDSet;
        }



    }
}
