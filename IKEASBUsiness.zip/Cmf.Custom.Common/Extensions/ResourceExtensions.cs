﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using Cmf.Common.CustomActionUtilities;
using Cmf.Custom.IKEA.BusinessObjects;
using Cmf.Custom.IKEA.BusinessObjects.Abstractions;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessObjects.GenericTables;
using Cmf.Foundation.BusinessObjects.QueryObject;
using Cmf.Foundation.BusinessOrchestration.Abstractions;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Foundation.Security;
using Cmf.Foundation.Security.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.Abstractions;
using Cmf.Navigo.BusinessOrchestration.DispatchManagement;
using Cmf.Navigo.BusinessOrchestration.DispatchManagement.InputObjects;
using Cmf.Navigo.BusinessOrchestration.DispatchManagement.OutputObjects;
using Cmf.Navigo.BusinessOrchestration.ResourceManagement;
using Cmf.Navigo.BusinessOrchestration.ResourceManagement.InputObjects;
using Cmf.Navigo.BusinessOrchestration.ResourceManagement.OutputObjects;
using Microsoft.Extensions.DependencyInjection;

namespace Cmf.Custom.IKEA.Common.Extensions
{

    /// <summary>
    /// This class contains resource extension methods
    /// </summary>
    public static class ResourceExtensions
    {
        private static IEntityFactory entityFactory => ApplicationContext.CurrentServiceProvider.GetService<IEntityFactory>();
        private static IIKEAUtilities ikeaUtilities => ApplicationContext.CurrentServiceProvider.GetService<IIKEAUtilities>();
        private static IResourceOrchestration resourceOrchestration => ApplicationContext.CurrentServiceProvider.GetService<IResourceOrchestration>();
        private static IDispatchOrchestration dispatchOrchestration => ApplicationContext.CurrentServiceProvider.GetService<IDispatchOrchestration>();

        /// <summary>
        /// Change Dispatch List order of a resource
        /// </summary>
        /// <param name="resource">Resource</param>
        /// <param name="materialOrder">New order of materials</param>
        public static IResource ChangeDispatchListOrder(this IResource resource, Dictionary<IMaterial, int> materialOrder)
        {
            if (resource != null && !materialOrder.IsNullOrEmpty())
            {
                IResourceMaterialManageCollection resourceMaterialManage = new ResourceMaterialManageCollection();

                foreach (var item in materialOrder)
                {
                    resourceMaterialManage.Add(new ResourceMaterialManage()
                    {
                        Material = item.Key,
                        Order = item.Value
                    });
                }

                ManageResourceMaterialOrderInput input = new ManageResourceMaterialOrderInput()
                {
                    Resource = resource,
                    ResourceMaterialManageCollection = resourceMaterialManage
                };

                ManageResourceMaterialOrderOutput output = resourceOrchestration.ManageResourceMaterialOrder(input);

                // Update the resource
                return output.Resource;
            }

            return resource;
        }

        /// <summary>
        /// Get the Dispatch List of the resource
        /// NOTE: It returns all materials that can be or already are dispatch in the resource
        /// </summary>
        /// <param name="resource">Resource</param>
        /// <param name="levelsToLoad">Levels to load</param>
        /// <returns>Dispatch List</returns>
        public static IMaterialCollection GetDispatchList(this IResource resource, int levelsToLoad = 0)
        {
            IMaterialCollection materials = null;

            if (resource != null)
            {
                GetDispatchListForResourceInput input = new GetDispatchListForResourceInput()
                {
                    Resource = resource,
                    LevelsToLoad = levelsToLoad
                };

                GetDispatchListForResourceOutput output = dispatchOrchestration.GetDispatchListForResource(input);

                materials = output.Materials;
            }

            return materials;
        }

        /// <summary>
        /// Get a resource collection with all sub resource of a certain processing type (if defined. if it is not define gets all subresources)
        /// First Run resource.GetDescendentResources(-1);
        /// </summary>
        /// <param name="resource">The resource to find all sub resources beneath him</param>
        /// <param name="order">The order of the sub resources</param>
        /// <param name="processingType">The processing type of the sub resources to collect</param>
        /// <returns>A dictionary with the order of the sub resources and the sub resource</returns>
        public static Dictionary<int, IResource> GetResourceSubResources(this IResource resource, ref int order, string processingType = null)
        {
            Dictionary<int, IResource> subResources = new Dictionary<int, IResource>();

            if (resource != null)
            {
                if (!resource.SubResources.IsNullOrEmpty())
                {
                    foreach (IResource r in resource.SubResources)
                    {
                        if (processingType != null)
                        {
                            if (processingType.CompareStrings(r.ProcessingType.ToString()))
                            {
                                subResources.Add(order, r);
                                order++;
                            }
                        }
                        else
                        {
                            subResources.Add(order, r);
                            order++;
                        }

                        subResources.AddRange(r.GetResourceSubResources(ref order, processingType));
                    }
                }
            }

            return subResources;
        }

        /// <summary>
        /// Get a resource collection with all sub resource of a Resource
        /// </summary>
        /// <param name="resource">The resource to find all sub resources beneath him</param>
        /// <returns>Sub resources of a resource</returns>
        public static IResourceCollection GetResourceSubResources(this IResource resource)
        {
            IResourceCollection subResources = entityFactory.CreateCollection<IResourceCollection>();

            if (resource != null)
            {
                SqlParameter sqlResourceId = new SqlParameter("@ResourceId", SqlDbType.BigInt) { Value = resource.Id };

                DataSet dataSet = ikeaUtilities.ExecuteReader("[Custom].[P_GetResourceSubResources]",
                                                                CommandType.StoredProcedure,
                                                                sqlResourceId);

                if (dataSet.HasData())
                {
                    Collection<long> subResourceIds = new Collection<long>(dataSet.Tables[0].AsEnumerable().Select(r => r.Field<long>("ResourceId")).ToList());

                    subResources.Load(subResourceIds);
                }

            }

            return subResources;
        }

        /// <summary>
        /// Get all materials attached to a resource
        /// </summary>
        /// <param name="resource">Resource where it is wanted to search for attached materials</param>
        /// <param name="loadMaterials">If it is to load the materials information</param>
        /// <returns>return a material collection with all the materials attached to the consumable feed</returns>
        public static IMaterialCollection GetAttachedMaterials(this IResource resource, bool loadRelation = true)
        {
            IResourceCollection resources = entityFactory.CreateCollection<IResourceCollection>();
            resources.Add(resource);

            return resources.GetAttachedMaterials(loadRelation);
        }

        /// <summary>
        /// Get all materials attached to all the resources
        /// </summary>
        /// <param name="resources">Resource Collection where it is wanted to search for attached materials</param>
        /// <param name="loadMaterials">If it is to load the materials information</param>
        /// <returns>Return a material collection with all the materials attached to the consumable feed</returns>
        public static IMaterialCollection GetAttachedMaterials(this IResourceCollection resources, bool loadRelation = true)
        {
            if (loadRelation)
            {
                resources.LoadRelations(Navigo.Common.Constants.MaterialResource);
            }

            IMaterialCollection materials = entityFactory.CreateCollection<IMaterialCollection>();
            Collection<long> materialIds = new Collection<long>(resources
                                                .Where(r => !r.ResourceMaterials.IsNullOrEmpty())
                                                .SelectMany(r => r.ResourceMaterials
                                                                .Select(rm => rm.GetNativeValue<long>("SourceEntity")))
                                                .ToList());
            
            materials.Load(materialIds);

            return materials;
        }

        /// <summary>
        /// Get all durables attached to a line
        /// </summary>
        /// <param name="resource"></param>
        /// <param name="loadMaterials"></param>
        /// <returns></returns>
        public static Dictionary<int, IMaterial> GetAttachedDurables(this IResource resource)
        {
            resource.LoadRelations(Navigo.Common.Constants.ResourceDurable);
            if (resource.RelationCollection.ContainsKey(Navigo.Common.Constants.ResourceDurable))
            {
                List<IResourceDurable> relations = resource.RelationCollection[Navigo.Common.Constants.ResourceDurable]
                    .Cast<IResourceDurable>()
                    .ToList();

                Dictionary<int, IMaterial> attachedDurables = relations
                    .Where(relation => relation.Position != null)
                    .ToDictionary(relation => relation.Position.Value, relation => relation.TargetEntity);

                IMaterialCollection durableMaterials = entityFactory.CreateCollection<IMaterialCollection>();
                durableMaterials.AddRange(attachedDurables.Values);
                durableMaterials.Load();

                return attachedDurables;
            }

            return new Dictionary<int, IMaterial>();
        }

        /// <summary>
        /// Resolves the durables BOM for the given material and resource. Returns null if no such BOM is found
        /// </summary>
        /// <param name="resource"></param>
        /// <param name="material"></param>
        /// <returns></returns>
        public static Cmf.Navigo.BusinessObjects.Abstractions.IBOM GetDurableBom(this IResource resource, IMaterial material)
        {
            Cmf.Navigo.BusinessObjects.Abstractions.IBOM bom = null;

            // All Process Resources from Line
            ISmartTable durablesContext = new Foundation.BusinessObjects.SmartTables.SmartTable();
            durablesContext.Load(IKEAConstants.MaterialDurablesContext);

            //Create NgpDataRow with the configuration to be tested against the SmartTable
            INgpDataRow values = new NgpDataRow();
            values.Add("Step", material.Step);
            values.Add("Product", material.Product);
            values.Add("Flow", material.Flow);
            values.Add("Material", material);
            values.Add("MaterialType", material.Type);
            values.Add("Resource", resource);
            values.Add("ResourceType", resource.Type);

            //Resolve the smartTable
            INgpDataSet nds = durablesContext.ResolveObjects(values, true);

            if (nds != null)
            {
                //If the configuration was successfully found on the SmartTable
                DataSet ds = NgpDataSet.ToDataSet(nds);
                if (ds.HasData())
                {
                    //Resolving SmartTable return only one row so we can access the Row[0]
                    bom = entityFactory.Create<IBOM>();
                    bom.Name = ds.Tables[0].Rows[0]["BOM"].ToString();
                    bom.Load();
                }
            }

            return bom;
        }

        /// <summary>
        /// Returns a dictionary with all the BOM Products and their positions as keys
        /// </summary>
        /// <param name="bom"></param>
        /// <returns></returns>
        public static Dictionary<string, List<int>> GetPositionsDictionary(this Cmf.Navigo.BusinessObjects.Abstractions.IBOM bom)
        {
            // Each product can have multiple positions (if it appears multiple times in the BOM, for example
            Dictionary<string, List<int>> productPositions = new Dictionary<string, List<int>>();

            // Get bom Products
            bom.Load();
            IBOMProductCollection bOMProducts = bom.GetBOMProducts(1);

            // We want the non-substitute products before the susbtitute ones. And OrderBy puts false first, and true later
            // As such, we need an expression that is false for non-substitutes
            foreach (IBOMProduct product in bOMProducts.AsEnumerable().OrderBy(p => p.Parent != null))
            {
                if (product.Position != null)
                {
                    List<int> positions = null;

                    if (!productPositions.TryGetValue(product.TargetEntity.Name, out positions))
                    {
                        positions = new List<int>();

                        productPositions[product.TargetEntity.Name] = positions;
                    }

                    positions.Add(product.Position.Value);
                }
            }

            return productPositions;
        }

        /// <summary>
        /// Returns a collection of the currently in-process orders
        /// </summary>
        /// <param name="resource"></param>
        /// <returns></returns>
        public static IMaterialCollection GetProcessingManufacturingOrders(this IResource resource)
        {
            // Get Dispatch List of the resource
            Dictionary<IMaterial, decimal> materialOrders = ikeaUtilities.GetMaterialsFromResourceByState(resource.Id, true, new MaterialSystemState[] { MaterialSystemState.Dispatched, MaterialSystemState.InProcess });

            IMaterialCollection materials = entityFactory.CreateCollection<IMaterialCollection>();
            materials.AddRange(materialOrders.OrderBy(mo => mo.Value).Select(mo => mo.Key));

            return materials;
        }

        /// <summary>
        /// Finds a free durable position in any of the BOMs of the currently processing orders
        /// First tries to find a matching BOM Position for this product in any of the Durable BOMs
        /// of the Dispatched or InProcess orders in the resource.
        /// 
        /// If there are BOMs, but none mentioned this product, or the ones that do, have their positions already
        /// occupied by other attached durables, then throws an exception.
        /// 
        /// On the other hand, if there are no BOMs configured for the MOs in the resource, tries to find any free 
        /// durabel position between 1 and Resource.DurablePositions (including). If no free position is found,
        /// throws an exception as well.
        /// </summary>
        /// <param name="resource"></param>
        /// <param name="durableProduct"></param>
        /// <param name="noMatchInBom"></param>
        /// <returns></returns>
        public static int FindProductDurablePosition(this IResource resource, IProduct durableProduct)
        {
            IMaterialCollection processingOrders = resource.GetProcessingManufacturingOrders();

            Dictionary<int, IMaterial> attachedDurables = resource.GetAttachedDurables();

            int? position = null;

            // Assume that by default no Durable BOMs are configured for any of the orders in this resource
            bool hasBomsConfigured = false;

            // By default we set the flag, that no matches in any BOM were found for this durable, to true
            bool noMatchInBom = true;

            // To avoid checking for positions on repeated BOMs, keep a list of their names
            HashSet<string> bomNames = new HashSet<string>();

            // A collection of all the durable positions that were matches in any BOM for this product
            // but that were already occupied by another durable already attached to the resource
            // We use a list here to preserve the order in which the positions should be attached
            List<int> unavailablePositions = new List<int>();

            foreach (IMaterial order in processingOrders)
            {
                Cmf.Navigo.BusinessObjects.Abstractions.IBOM bom = resource.GetDurableBom(order);

                // Check if there is any durable BOM configured for this material order, in this resource
                if (bom != null)
                {
                    hasBomsConfigured = true;

                    if (!bomNames.Contains(bom.Name))
                    {
                        bomNames.Add(bom.Name);

                        // For each order, we fetch the list of positions grouped per Product Name
                        Dictionary<string, List<int>> productPositions = bom.GetPositionsDictionary();

                        if (productPositions.ContainsKey(durableProduct.Name))
                        {
                            noMatchInBom = false;

                            foreach (int bomPosition in productPositions[durableProduct.Name])
                            {
                                // If the position is free (no attached durables there yet)
                                if (!attachedDurables.ContainsKey(bomPosition))
                                {
                                    position = bomPosition;

                                    break;
                                }
                                else
                                {
                                    unavailablePositions.Add(bomPosition);
                                }
                            }
                        }

                        if (position != null)
                        {
                            break;
                        }
                    }
                }
            }

            if (hasBomsConfigured)
            {
                // If the resource has BOMs configured (for the in-process MOs), but none of these BOMs include this product
                if (noMatchInBom)
                {
                    throw ikeaUtilities.LocalizedException(IKEAConstants.CustomDurableProductNotFoundInBomsLocalizedMessage, durableProduct.Name, string.Join(", ", bomNames));
                }

                // If there are BOMs configured, there were matches in the BOMs, but are all already occupied
                if (position == null)
                {
                    throw ikeaUtilities.LocalizedException(IKEAConstants.CustomDurableProductConfiguredPositionsTakenLocalizedMessage, durableProduct.Name, string.Join(", ", unavailablePositions));
                }

                return position.Value;
            }
            else
            {
                // If there are no BOMs available, use whatever free position we can find
                if (position == null)
                {
                    for (int i = 1; i <= (resource.DurablePositions ?? 0); i++)
                    {
                        if (!attachedDurables.ContainsKey(i))
                        {
                            position = i;
                            break;
                        }
                    }

                    // If the position remains null after trying to find any free position, it means no position was found
                    if (position == null)
                    {
                        throw ikeaUtilities.LocalizedException(IKEAConstants.CustomNoFreeDurablePositionsInResourceLocalizedMessage, resource.Name);
                    }
                }

                return position.Value;
            }
        }

        /// <summary>
        /// Change resource state
        /// </summary>
        /// <param name="instance">The Resource</param>
        /// <param name="smTransition">StateModelTransition</param>
        /// <param name="reason">Reason</param>
        /// <returns></returns>
        public static IResource ChangeState(this IResource instance, IStateModelTransition smTransition, string reason, string serviceComments = null)
        {
            ComplexLogResourceEventInput input = new ComplexLogResourceEventInput()
            {
                Resource = instance,
                StateModel = instance.CurrentMainState.StateModel,
                StateModelTransition = smTransition,
                Reason = reason
            };

            if (!serviceComments.IsNullOrEmpty())
            {
                input.ServiceComments = serviceComments;
            }

            ComplexLogResourceEventOutput output = resourceOrchestration.ComplexLogResourceEvent(input);

            return output.Resource;
        }

        /// <summary>
        /// Attach a single consumable To Resource
        /// </summary>
        /// <param name="instance">Resource</param>
        /// <param name="material">Material to attach</param>
        public static void AttachConsumableToResource(this IResource instance, IMaterial material, int order = 0)
        {
            if (material != null)
            {
                IServiceProvider serviceProvider = ApplicationContext.CurrentServiceProvider;
                IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();

                IMaterialCollection materials = entityFactory.CreateCollection<IMaterialCollection>();
                materials.Add(material);
                instance.AttachConsumablesToResource(materials, order);
            }
        }

        /// <summary>
        /// Attach Consumables To Resource
        /// </summary>
        /// <param name="instance">Resource</param>
        /// <param name="materials">Materials to attach</param>
        public static void AttachConsumablesToResource(this IResource instance, IMaterialCollection materials, int order = 0)
        {
            Dictionary<IMaterial, IAttachConsumableParameters> materialToAttach = new Dictionary<IMaterial, IAttachConsumableParameters>();

            foreach (IMaterial material in materials)
            {
                var materialResource = entityFactory.Create<IMaterialResource>();
                materialResource.SourceEntity = material;
                materialResource.TargetEntity = instance;
                IAttachConsumableParameters consumableParameters = new AttachConsumableParameters()
                {
                    Order = order,
                    ResourceContainers = null,
                    ResourceMaterial = materialResource
                };

                materialToAttach.Add(material, consumableParameters);
            }

            // Attach the materials
            if (materialToAttach.Count > 0)
            {
                AttachConsumablesToResourceInput input = new AttachConsumablesToResourceInput()
                {
                    Resource = instance,
                    Materials = materialToAttach
                };

                resourceOrchestration.AttachConsumablesToResource(input);
            }
        }

        /// <summary>
        /// Detach Consumables from Resource
        /// </summary>
        /// <param name="instance">Resource</param>
        /// <param name="materials">Materials to attach</param>
        public static void DetachConsumablesFromResource(this IResource instance, IMaterialCollection materials)
        {

            // Detatch the materials
            if (!materials.IsNullOrEmpty())
            {
                DetachConsumablesFromResourceInput input = new DetachConsumablesFromResourceInput()
                {
                    Resource = instance,
                    Materials = materials
                };

                resourceOrchestration.DetachConsumablesFromResource(input);

            }
        }

        /// <summary>
        /// Validates if this Resource has a Consumable Feed SubResource with the given name
        /// </summary>
        /// <param name="instance"></param>
        /// <param name="consumableFeedName"></param>
        /// <param name="online">When true, the sub-resource must be automation mode online</param>
        /// <param name="loadRelations"></param>
        /// <returns></returns>
        public static bool HasConsumableFeed(this IResource instance, string consumableFeedName, bool online = false, bool loadRelations = false)
        {
            // Load the SubResource Relations
            if (loadRelations)
            {
                instance.LoadRelations("SubResource", 1);
            }

            // If has no SubResource relations, then for sure cannot have a consumable feed
            if (!instance.RelationCollection.ContainsKey("SubResource"))
            {
                return false;
            }

            // Finds the sub-resource with the given name
            IResource subResourceInstance = instance.RelationCollection["SubResource"]
               ?.OfType<ISubResource>()
               ?.Select(subResource => subResource.TargetEntity)
               ?.FirstOrDefault(subResource => subResource.Name == consumableFeedName);

            // When null, indicates no sub-resource with the given name was found
            if (subResourceInstance == null)
            {
                return false;
            }

            // Consumable Feeds for IKEA, by convention, must have this types. If not, they aren't consumable feeds
            if (subResourceInstance.ProcessingType != ProcessingType.ConsumableFeed || subResourceInstance.Type != IKEAConstants.ResourceTypeConsumable)
            {
                return false;
            }

            // Validates if the consumable feed sub-resource has automation mode Online
            if (online && subResourceInstance.AutomationMode != ResourceAutomationMode.Online)
            {
                return false;
            }

            return true;
        }

        /// <summary>
        /// Reclassify previous resource states if possible
        /// </summary>
        /// <param name="resourceStateChanges">Resource state transition </param>
        public static void ReclassifyResourcePreviousStates(this IResource resource, ResourceStateChangesStructure resourceStateChanges)
        {
            IUser currentUser = new User();
            currentUser.Load(Cmf.Foundation.Common.Utilities.DomainUserName);

            IRoleCollection roles = currentUser.GetAllRolesForUser();

            // Check if the use has any roles
            if (!roles.IsNullOrEmpty())
            {
                List<ResourceReclassificationAllowedStates> allowedStates = ikeaUtilities.ResolveResourceStateReclassificationPermissionsForAllUserRoles(currentUser,
                                                                                                                                                            resourceStateChanges.ResourceMainStateModel.Name,
                                                                                                                                                            resourceStateChanges.InitialStateModelState.Name,
                                                                                                                                                            resourceStateChanges.InitialStateReason);
                // Check if there are any allowed state transitions
                if (!allowedStates.IsNullOrEmpty())
                {
                    bool resourcePastReclassifications = allowedStates.Any(a => a.AllowsPastReclassifications
                                                                                && (a.StateModel == null || a.StateModel == resourceStateChanges.ResourceMainStateModel.Name)
                                                                                && (a.StateModelState == null || a.StateModelState == resourceStateChanges.FinalStateModelState.Name)
                                                                                && (a.Reason == null || a.Reason == resourceStateChanges.FinalStateReason));

                    // Check if the state transition allows past reclassifications
                    if (resourcePastReclassifications)
                    {
                        // Get Resource History
                        DataSet resourceStateHistory = ikeaUtilities.GetResourceStateHistoryDataSet(currentUser, resource);

                        // Check if there are any state history
                        if (resourceStateHistory.HasData())
                        {
                            // The -2 is because the action is done after the change state and we need to look to the previous one
                            int numberOfRecords = resourceStateHistory.Tables[0].Rows.Count - 2;

                            // Get the last available resource state history row 
                            DataRow historyRow = resourceStateHistory.Tables[0].Rows[numberOfRecords >= 0 ? numberOfRecords : 0];

                            // Get the state identifiers
                            long mainStateModelId = historyRow.Field<long>("MainStateModelId");
                            long mainStateModelStateId = historyRow.Field<long>("MainStateModelStateId");
                            string mainStateModelStateReason = historyRow.Field<string>("MainStateModelStateReason");

                            if (resourceStateChanges.ResourceMainStateModel.Id == mainStateModelId
                                && resourceStateChanges.InitialStateModelState.Id == mainStateModelStateId
                                && resourceStateChanges.InitialStateReason.CompareStrings(mainStateModelStateReason))
                            {
                                ICustomResourceStateReclassification resourceStateReclassification = entityFactory.Create<ICustomResourceStateReclassification>();
                                resourceStateReclassification.Name = DateTime.Now.ToFileTime().ToString();
                                resourceStateReclassification.ResourceId = resource.Id;
                                resourceStateReclassification.ServiceHistoryIdStart = historyRow.Field<long>("StartServiceHistoryId");
                                resourceStateReclassification.OperationHistorySequenceStart = historyRow.Field<long>("StartOperationHistorySeq");
                                resourceStateReclassification.ServiceHistoryIdEnd = historyRow.Field<long>("EndServiceHistoryId");
                                resourceStateReclassification.OperationHistorySequenceEnd = historyRow.Field<long>("EndOperationHistorySeq");
                                resourceStateReclassification.StateModelId = resourceStateChanges.ResourceMainStateModel.Id;
                                resourceStateReclassification.StateModelStateId = resourceStateChanges.FinalStateModelState.Id;
                                resourceStateReclassification.StateModelStateReason = resourceStateChanges.FinalStateReason;

                                // Create a new reclassification
                                resourceStateReclassification.Create();
                                resourceStateReclassification.Terminate();
                            }
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Retrieves the ERPMaintenanceRequestUser attribute by recursively traversing up the Resource hierarchy.
        /// </summary>
        /// <param name="resource">Instance of Resource</param>
        /// <returns>The Resource hierarchy's ERPMaitenanceRequestUser's attribute value.</returns>
        public static string GetERPMaintenanceRequestUser(this IResource resource)
        {
            string maintenanceRequestUser = resource.GetAttributeValueOrDefault<string>(IKEAConstants.CustomResourceERPMaintenanceRequestUser, true);

            if (string.IsNullOrEmpty(maintenanceRequestUser) && resource.ParentResourcesCount > 0)
            {
                resource.GetAscendentResources(1);
                resource.ParentResources.Load();

                foreach (IResource parentResource in resource.ParentResources)
                {
                    string parentMaintenanceRequest = parentResource.GetERPMaintenanceRequestUser();

                    if (!string.IsNullOrEmpty(parentMaintenanceRequest))
                    {
                        return parentMaintenanceRequest.Trim();
                    }
                }
            }


            return maintenanceRequestUser;
        }

        public static ICustomResourceConsumptionProviderCollection GetRelationFromDistributedFeederTarget(this IResource resource, bool loadEntities = true)
        {
            ICustomResourceConsumptionProviderCollection provider = null;

            IQueryObject query = new QueryObject();
            query.Description = "";
            query.EntityTypeName = "CustomResourceConsumptionProvider";
            query.Name = "GetRelations";
            query.Query = new Query();
            query.Query.Distinct = false;
            query.Query.Filters = new FilterCollection() {
                new Filter()
                {
                    Name = "Name",
                    ObjectName = "Resource",
                    ObjectAlias = "CustomResourceConsumptionProvider_TargetEntity_2",
                    Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                    Value = resource.Name,
                    LogicalOperator = Cmf.Foundation.Common.LogicalOperator.Nothing,
                    FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                },
                new Filter()
                {
                    Name = "IsEnabled",
                    ObjectName = "CustomResourceConsumptionProvider",
                    ObjectAlias = "CustomResourceConsumptionProvider_1",
                    Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                    Value = true,
                    LogicalOperator = Cmf.Foundation.Common.LogicalOperator.Nothing,
                    FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                }
            };
            query.Query.Fields = new FieldCollection() {
                new Field()
                {
                    Alias = "Id",
                    ObjectName = "CustomResourceConsumptionProvider",
                    ObjectAlias = "CustomResourceConsumptionProvider_1",
                    IsUserAttribute = false,
                    Name = "Id",
                    Position = 0,
                    Sort = Cmf.Foundation.Common.FieldSort.NoSort
                },
                new Field()
                {
                    Alias = "Name",
                    ObjectName = "CustomResourceConsumptionProvider",
                    ObjectAlias = "CustomResourceConsumptionProvider_1",
                    IsUserAttribute = false,
                    Name = "Name",
                    Position = 1,
                    Sort = Cmf.Foundation.Common.FieldSort.NoSort
                },
                new Field()
                {
                    Alias = "SourceEntityName",
                    ObjectName = "Resource",
                    ObjectAlias = "CustomResourceConsumptionProvider_SourceEntity_2",
                    IsUserAttribute = false,
                    Name = "Name",
                    Position = 2,
                    Sort = Cmf.Foundation.Common.FieldSort.NoSort
                }
            };
            query.Query.Relations = new RelationCollection() {
                new Relation()
                {
                    Alias = "",
                    IsRelation = false,
                    Name = "",
                    SourceEntity = "CustomResourceConsumptionProvider",
                    SourceEntityAlias = "CustomResourceConsumptionProvider_1",
                    SourceJoinType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.JoinType.InnerJoin,
                    SourceProperty = "TargetEntityId",
                    TargetEntity = "Resource",
                    TargetEntityAlias = "CustomResourceConsumptionProvider_TargetEntity_2",
                    TargetJoinType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.JoinType.InnerJoin,
                    TargetProperty = "Id"
                },
                new Relation()
                {
                    Alias = "",
                    IsRelation = false,
                    Name = "",
                    SourceEntity = "CustomResourceConsumptionProvider",
                    SourceEntityAlias = "CustomResourceConsumptionProvider_1",
                    SourceJoinType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.JoinType.InnerJoin,
                    SourceProperty = "SourceEntityId",
                    TargetEntity = "Resource",
                    TargetEntityAlias = "CustomResourceConsumptionProvider_SourceEntity_2",
                    TargetJoinType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.JoinType.InnerJoin,
                    TargetProperty = "Id"
                }
            };

            DataSet resultDataSet = query.Execute(false, new QueryParameterCollection());

            if (resultDataSet.HasData())
            {
                provider = entityFactory.CreateCollection<ICustomResourceConsumptionProviderCollection>();

                foreach (DataRow row in resultDataSet.Tables[0].Rows)
                {
                    var customResourceConsumptionProvider = entityFactory.Create<ICustomResourceConsumptionProvider>();
                    customResourceConsumptionProvider.Name = row.Field<string>("Name");
                    provider.Add(customResourceConsumptionProvider);
                }

                if (loadEntities && !provider.IsNullOrEmpty())
                {
                    provider.Load();
                }
            }

            return provider;
        }

        /// <summary>
        /// This method gets a collection of all feeders that are enabled as distributed feeders in a given main line
        /// </summary>
        /// <param name="mainLine"></param>
        /// <param name="loadRelations"></param>
        /// <returns></returns>
        public static IResourceCollection GetDistributedFeedersFromMainLine(this IResource mainLine, bool loadRelations = true)
        {
            ICustomResourceConsumptionProviderCollection consumptionProviders = entityFactory.CreateCollection<ICustomResourceConsumptionProviderCollection>();
            IResourceCollection feeders = entityFactory.CreateCollection<IResourceCollection>();

            // Get all subresources from main line:
            IResourceCollection resources = mainLine.GetResourceSubResources();
            if (!resources.IsNullOrEmpty())
            {
                // Load resource relations to check if there are any shared resources:
                if (loadRelations)
                {
                    resources.LoadRelations(IKEAConstants.CustomResourceConsumptionProvider);
                }

                foreach (IResource resource in resources)
                {
                    if (!resource.RelationCollection.IsNullOrEmpty())
                    {
                        if (resource.RelationCollection.ContainsKey(IKEAConstants.CustomResourceConsumptionProvider))
                        {
                            // Load attribute to check if any of the consumptionproviders is enabled:
                            resource.RelationCollection[IKEAConstants.CustomResourceConsumptionProvider].LoadAttributes(new Collection<string> { IKEAConstants.IsEnabledResourceConsumptionProvider });


                            if (resource.RelationCollection[IKEAConstants.CustomResourceConsumptionProvider]
                                      .Where(RCP => RCP.GetAttributeValueOrDefault<bool>(IKEAConstants.IsEnabledResourceConsumptionProvider) &&
                                            (RCP as ICustomResourceConsumptionProvider).ConsumptionMode.Value == (int)CustomConsumptionModeEnum.DistributedConsumption)
                                      .Any())
                            {

                                consumptionProviders = entityFactory.CreateCollection<ICustomResourceConsumptionProviderCollection>();
                                consumptionProviders.AddRange(resource.RelationCollection[IKEAConstants.CustomResourceConsumptionProvider]
                                                              .Where(RCP => RCP.GetAttributeValueOrDefault<bool>(IKEAConstants.IsEnabledResourceConsumptionProvider) &&
                                                                    (RCP as ICustomResourceConsumptionProvider).ConsumptionMode.Value == (int)CustomConsumptionModeEnum.DistributedConsumption)
                                                              .Select(ER => ER as ICustomResourceConsumptionProvider));

                                foreach (ICustomResourceConsumptionProvider consumptionProvider in consumptionProviders)
                                {
                                    if (!feeders.Any(f => f.Id == consumptionProvider.Id))
                                    {
                                        feeders.Add(consumptionProviders.FirstOrDefault().TargetEntity);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return feeders;
        }

        /// <summary>
        /// This method evaluates if the feeder supplied is a parent of a distributed feeder group
        /// </summary>
        /// <param name="feeder"></param>
        /// <param name="loadRelations"></param>
        /// <returns></returns>
        public static bool IsParentOfDistributedFeederGroup(this IResource feeder, bool loadRelations = true)
        {
            bool result = false;

            // Load resource relations to check if there are any shared resources:
            if (loadRelations)
            {
                feeder.LoadRelations(IKEAConstants.CustomResourceConsumptionProvider);
            }

            if (feeder.RelationCollection != null)
            {
                if (feeder.RelationCollection.ContainsKey(IKEAConstants.CustomResourceConsumptionProvider))
                {
                    // Load attribute to check if any of the consumptionproviders is enabled:
                    feeder.RelationCollection[IKEAConstants.CustomResourceConsumptionProvider].LoadAttributes(new Collection<string> { IKEAConstants.IsEnabledResourceConsumptionProvider });

                    // Check if the supplied feeder is the source of the relation
                    if (feeder.RelationCollection[IKEAConstants.CustomResourceConsumptionProvider]
                              .Where(RCP => RCP.GetAttributeValueOrDefault<bool>(IKEAConstants.IsEnabledResourceConsumptionProvider) &&
                                    (RCP as ICustomResourceConsumptionProvider).ConsumptionMode.Value == (int)CustomConsumptionModeEnum.DistributedConsumption &&
                                     RCP.SourceEntity.Id == feeder.Id).Any())
                    {
                        result = true;
                    }
                }
            }
            return result;
        }

        /// <summary>
        /// Retrieves the optimizer configuration associated with this resource on the generic table CustomOptimizerResourcesConfiguration
        /// </summary>
        /// <param name="resource"></param>
        /// <returns></returns>
        public static OptimizerResourceStructure GetHPOConfiguration(this IResource resource)
        {
            if (resource == null)
            {
                return null;
            }

            // Load the data from  the generic table about this resource
            IGenericTable genericTable = new GenericTable();
            genericTable.Load(IKEAConstants.CustomOptimizerResourcesConfiguration);
            genericTable.LoadData(new FilterCollection {
                new Filter {
                    Name = "Resource",
                    Value = resource.Name
                }
            });


            DataSet dataSet = NgpDataSet.ToDataSet(genericTable.Data);

            // Check if the resource has any configuration enabled for the optimizer
            if (dataSet.HasData())
            {
                DataRow firstRow = dataSet.Tables[0].Rows[0];

                return new OptimizerResourceStructure
                {
                    Resource = resource,
                    SendFileFolder = (string)firstRow["SendFileFolder"],
                    ReceiveFileFolder = (string)firstRow["ReceiveFileFolder"],
                    AllowToDispatchNotOptimizedGroupOrders = (bool)firstRow["AllowToDispatchNotOptimizedGroupOrders"],
                };
            }

            return null;
        }
    }
}

