﻿using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Exceptions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.Common;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;

namespace Cmf.Custom.IKEA.Common.Extensions
{
    public static class XMLExtensions
    {
        /// <summary>
        /// Retrieves the value of a tag on xml document by xpath
        /// </summary>
        /// <param name="doc">Xml Document</param>
        /// <param name="xPath">Path to the value</param>
        /// <param name="attribute">Get attribute tag</param>
        /// <returns>Value</returns>
        public static string GetValueByXPath(this XmlDocument doc, string xPath, string attribute = null)
        {
            string value = null;

            XmlNode node = doc.SelectSingleNode(xPath);
            if (node != null)
            {
                if (attribute == null)
                {
                    value = node.InnerText;
                }
                else
                {
                    value = node.Attributes[attribute].Value;
                }
            } else
            {
                throw new IKEAException(IKEAConstants.CustomERPProductionOrderXmlError);
            }
            return value;
        }

        #region XML


        /// <summary>
        /// Serialize Object to XML
        /// </summary>
        /// <typeparam name="T">Serializable Type</typeparam>
        /// <param name="value">Object to be serialized</param>
        /// <returns></returns>
        public static string SerializeToXML<T>(this T value)
        {
            if (value == null)
            {
                return string.Empty;
            }
            try
            {
                var xmlserializer = new XmlSerializer(typeof(T));
                var stringWriter = new StringWriter();
                using (var writer = XmlWriter.Create(stringWriter))
                {
                    xmlserializer.Serialize(writer, value);
                    return stringWriter.ToString();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Serialize Object to XmlDocument
        /// </summary>
        /// <typeparam name="T">Serializable Type</typeparam>
        /// <param name="value">Object to be serialized</param>
        /// <returns>XmlDocument</returns>
        public static XmlDocument SerializeToXMLDocument<T>(this T value)
        {
            string xml = SerializeToXML(value);

            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.LoadXml(xml);

            return xmlDoc;
        }

        public static Dictionary<string, string> DeserializeObject(string message)
        {
            return JsonConvert.DeserializeObject<Dictionary<string, string>>(message);
        }



        #endregion
    }
}
