﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;

using Cmf.Custom.IKEA.BusinessObjects.Abstractions;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.Enums;
using Cmf.Custom.IKEA.Common.Exceptions;
using Cmf.Custom.IKEA.Common.Extensions.BOM;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Foundation.Common.Base;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.Abstractions;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects;
using Microsoft.Extensions.DependencyInjection;

namespace Cmf.Custom.IKEA.Common.Extensions
{
    /// <summary>
    /// Custom Assemble Engine
    /// </summary>
    public static class CustomAssembleEngine
    {
        private static string objectTypeName = typeof(CustomAssembleEngine).FullName;
        private static IIKEAUtilities ikeaUtilities => ApplicationContext.CurrentServiceProvider.GetService<IIKEAUtilities>();
        private static IGenericUtilities genericUtilities => ApplicationContext.CurrentServiceProvider.GetService<IGenericUtilities>();
        private static IMaterialOrchestration materialOrchestration => ApplicationContext.CurrentServiceProvider.GetService<IMaterialOrchestration>();
        private static IDeeContextUtilities deeContextUtilities => ApplicationContext.CurrentServiceProvider.GetService<IDeeContextUtilities>();

        private static IEntityFactory entityFactory => ApplicationContext.CurrentServiceProvider.GetService<IEntityFactory>();
        /// <summary>
        /// Retrieves CustomBOMProductInformationCollection generated on receiving a BOM
        /// </summary>
        /// <param name="bOM"></param>
        /// <returns>customBOMProductInformationCollection</returns>
        public static CustomBOMProductInformationCollection GetCustomBOMProductInformation(this Cmf.Navigo.BusinessObjects.Abstractions.IBOM bOM)
        {
            CustomBOMProductInformationCollection customBOMProductInformationCollection = new CustomBOMProductInformationCollection();
            //Based on received BOM Version, loads BOM Products if not yet available and all BOM Products attributes
            if (bOM != null)
            {
                if (bOM.BomProducts.IsNullOrEmpty())
                {
                    bOM.GetBOMProducts();
                }

                if (!bOM.BomProducts.IsNullOrEmpty())
                {
                    bOM.BomProducts.LoadAttributes();

                    List<IBOMProduct> bOMProductsParents = bOM.BomProducts.Where(bp => bp.Parent == null).ToList();
                    List<IBOMProduct> bOMProductsSubstitutes = bOM.BomProducts.Where(bp => bp.Parent != null).ToList();

                    // Get a dictionary with BOM Product and its substitutes
                    Dictionary<IBOMProduct, List<IBOMProduct>> bomProducts = bOMProductsParents.ToDictionary(bp => bp, bp => bOMProductsSubstitutes.Where(s => s.Parent.UniqueId == bp.UniqueId).ToList());

                    // Retrieves CustomBOMProductInformationCollection of BOMProducts converted into CustomBOMProductInformation(derives from BOMProduct)
                    customBOMProductInformationCollection.AddRange(bomProducts.Select(x => new CustomBOMProductInformation(x)));
                }
            }

            return customBOMProductInformationCollection;
        }


        /// <summary>
        /// In the case of an existing bom, validates the setup
        /// </summary>
        /// <param name="material"></param>
        /// <param name="resource"></param>
        /// <returns>Boolean</returns>
        public static bool CustomValidateBOMSetup(this IMaterial material, IResource resource)
        {
            CustomOperationExecutionSettings res = new CustomOperationExecutionSettings();

            res.Output = new Dictionary<String, Object>() { { IKEAConstants.MaterialIsBOMSetupValid, false } };

            // Log method start
            Cmf.Foundation.Common.Utilities.StartMethod(objectTypeName, "CustomValidateBOMSetup", new KeyValuePair<String, Object>("Material", material),
                                                                            new KeyValuePair<String, Object>("Resource", resource),
                                                                            new KeyValuePair<String, Object>("CustomOperationExecutionSettings", res));

            // Check if previous actions override this one
            if (!res.IsOverride)
            {
                // Validate if key exists in the dictionary
                if (!res.Output.ContainsKey(IKEAConstants.MaterialIsBOMSetupValid))
                {
                    res.Output = new Dictionary<String, Object>() { { IKEAConstants.MaterialIsBOMSetupValid, false } };
                }

                if (material != null && material.ObjectExists())
                {
                    if (resource != null && resource.ObjectExists())
                    {
                        IBOM bOM =  entityFactory.Create<IBOM>();

                        IResource topMostResource = resource.GetTopMostResource();

                        // If BOM is not defined, try to resolve it in smart table
                        if (material.CurrentBOMVersion == null)
                        {
                            BomDataInput bomDataInput = new BomDataInput
                            {
                                BomLevelsToLoad = 1,
                                BOMProductLevelsToLoad = 1,
                                Material = material,
                                MaterialLevelsToLoad = 0,
                                Operation = GetDataForTrackInOperation.TrackIn,
                                Resource = topMostResource,
                                ResourceLevelsToLoad = 0,
                                TopMostMaterialLevelsToLoad = 0,
                            };

                            IResolveBomContextsResult bomContext = material.Product.ResolveBomContexts(material, bomDataInput.OperationAttributes);
                            if (bomContext != null && bomContext.Bom != null && bomContext.Bom.UniversalState == UniversalState.Effective)
                            {
                                bOM = bomContext.Bom;
                            }
                        }
                        else
                        {
                            bOM = material.CurrentBOMVersion;
                        }

                        // If a BOM exists check for setup validation. If not, validate it as Ok:
                        if (bOM != null)
                        {
                            CustomBOMSetupInformation customBOMSetupInformation = new CustomBOMSetupInformation(bOM, topMostResource);
                            res.Output[IKEAConstants.MaterialIsBOMSetupValid] = customBOMSetupInformation.CustomIsSetUpValid();
                        }
                        else
                        {
                            res.Output[IKEAConstants.MaterialIsBOMSetupValid] = true;
                        }
                    }
                    else
                    {
                        res.Output[IKEAConstants.MaterialIsBOMSetupValid] = false;
                    }
                }
                else
                {
                    res.Output[IKEAConstants.MaterialIsBOMSetupValid] = false;
                }
            }

            long objectInstanceId = -1;
            long objectTypeId = -1;
            Cmf.Foundation.Common.Utilities.EndMethod(objectTypeId, objectInstanceId, new KeyValuePair<String, Object>("CustomOperationExecutionSettings", res));

            return (bool)res.Output[IKEAConstants.MaterialIsBOMSetupValid];
        }

        /// <summary>
        /// Perform Custom Assemble
        /// Check if there is enough material quantity attached to a resource to consume
        /// </summary>
        /// <param name="material">Material to Assemble</param>
        /// <param name="materialsToDirectConsume">Materials to Consume</param>
        /// <param name="assembleCollection">Collection of Assemble Materials</param>
        public static void CustomPerformAutomaticAssemble(this IMaterial material,
                                                            Dictionary<IResource, List<IMaterial>> materialsToDirectConsume = null,
                                                            IAssembleMaterialCollection assembleCollection = null,
                                                            Dictionary<long, Dictionary<CustomBOMProductInformation, CustomBOMConsumptionInformation>> quantitiesToAssemble = null)
        {
            CustomOperationExecutionSettings res = new CustomOperationExecutionSettings();

            // Log method start
            Cmf.Foundation.Common.Utilities.StartMethod(objectTypeName, "CustomPerformAutomaticAssemble", new KeyValuePair<String, Object>("Material", material),
                                                                            new KeyValuePair<String, Object>("CustomOperationExecutionSettings", res));

            if (!res.IsOverride)
            {
                if (material != null && material.ObjectExists() && material.CurrentBOMVersion != null &&
                    material.SystemState == MaterialSystemState.InProcess && material.Form.CompareStrings(ikeaUtilities.GetCompletedMaterialForm(material)))
                {

                    // Check if the materials to consumed are already defined
                    // if not, calculate them
                    if (assembleCollection.IsNullOrEmpty())
                    {
                        if (quantitiesToAssemble == null)
                            quantitiesToAssemble = new Dictionary<long, Dictionary<CustomBOMProductInformation, CustomBOMConsumptionInformation>>();
                        else
                            quantitiesToAssemble.Clear();

                        assembleCollection = CalculateMaterialsToConsume(material, material.PrimaryQuantity.GetValueOrDefault(), materialsToDirectConsume, quantitiesToAssemble);
                    }

                    #region CustomAssemble Remove IsReference for Product
                    IAssembleMaterialCollection customAssembleMaterials = new AssembleMaterialCollection();
                    if (genericUtilities.GetConfigurationValueByPath<bool>(IKEAConstants.CustomAssembleEnabled))
                    {
                        customAssembleMaterials.AddRange(assembleCollection
                            .Where(assembleMaterial =>
                                assembleMaterial.BOMProduct?.IsReference.GetValueOrDefault(false) == true &&
                                assembleMaterial.BOMProduct.GetAttributeValueOrDefault<string>(IKEAConstants.BomProductCustomSourceStepAttribute, true) != null)
                            .ToList());

                        foreach (AssembleMaterial assemble in customAssembleMaterials)
                        {
                            assembleCollection.Remove(assemble);
                        }
                    }
                    #endregion

                    // Invoke MES native orchestration AssembleMaterial
                    AssembleMaterialInput assembleInput = new AssembleMaterialInput()
                    {
                        Material = material,
                        AssembleQuantity = material.PrimaryQuantity.GetValueOrDefault(),
                        SourceMaterials = assembleCollection
                    };

                    AssembleMaterialOutput output = materialOrchestration.AssembleMaterial(assembleInput);

                    if (customAssembleMaterials.Any())
                    {
                        ikeaUtilities.CustomPostAssembleConsumption(quantitiesToAssemble, output, assembleCollection, customAssembleMaterials, material);
                    }
                }

            }

            long objectInstanceId = material.Id;
            long objectTypeId = material.EntityType.Id;
            Cmf.Foundation.Common.Utilities.EndMethod(objectTypeId, objectInstanceId, new KeyValuePair<String, Object>("CustomOperationExecutionSettings", res),
                                                                new KeyValuePair<String, Object>("CustomAssembleConsumptionDetails", quantitiesToAssemble),
                                                                new KeyValuePair<String, Object>("Material", material));
        }

        /// <summary>
        /// Get a collection of assemble material to use in the assemble
        /// </summary>
        /// <param name="material">Material to assemble</param>
        /// <param name="materialsToDirectConsume">Materials to Consume</param>
        /// <param name="quantitiesToAssemble">Quantities To Assemble</param>
        /// <returns>Collection of AssembleMaterials</returns>
        public static IAssembleMaterialCollection CalculateMaterialsToConsume(this IMaterial material,
                                                                             decimal quantityToProduce,
                                                                             Dictionary<IResource, List<IMaterial>> materialsToDirectConsume = null,
                                                                             Dictionary<long, Dictionary<CustomBOMProductInformation, CustomBOMConsumptionInformation>> quantitiesToAssemble = null)
        {
            // Collection to Perform MES native orchestration AssembleMaterial
            IAssembleMaterialCollection assembleCollection = new AssembleMaterialCollection();

            if (material != null
                && material.ObjectExists()
                && material.CurrentBOMVersion != null
                && material.SystemState == MaterialSystemState.InProcess)
            {
                CustomBOMSetupInformation customBOMSetupInformation = new CustomBOMSetupInformation(material.CurrentBOMVersion, material.LastProcessedResource.GetTopMostResource());

                // Only proceed if the Information Details and BOM Product Information are filled
                if (!customBOMSetupInformation.CustomBOMSetupInformationDetails.IsNullOrEmpty()
                    && !customBOMSetupInformation.CustomBOMProductInformations.IsNullOrEmpty())
                {
                    CustomBOMProductInformationCollection customBOMProductInformations = new CustomBOMProductInformationCollection();
                    customBOMProductInformations.AddRange(customBOMSetupInformation.CustomBOMProductInformations.Where(x => ikeaUtilities.IsBOMProductReference(x)));

                    // Create a list for all process segments
                    List<Tuple<string, string>> lstMaterialsToDirectConsumeProcessSegments = new List<Tuple<string, string>>();

                    if (!materialsToDirectConsume.IsNullOrEmpty())
                    {
                        List<IMaterial> auxiliarMaterials = materialsToDirectConsume.Values.SelectMany(m => m).ToList();

                        Dictionary<string, decimal> materialQuantities = auxiliarMaterials.ToDictionary(m => m.Name, m => m.PrimaryQuantity.GetValueOrDefault());

                        IMaterialCollection materials = entityFactory.CreateCollection<IMaterialCollection>();
                        materials.AddRange(auxiliarMaterials);
                        materials.Load();

                        IResourceCollection resources = entityFactory.CreateCollection<IResourceCollection>();
                        resources.AddRange(materialsToDirectConsume.Keys);

                        // Load resource identifiers attributes:
                        resources.LoadAttributes(new Collection<string> { IKEAConstants.ProcessSegmentSequence, IKEAConstants.SubProcessSegmentName });

                        // Load the resource materials
                        IMaterialCollection materialsAtResources = entityFactory.CreateCollection<IMaterialCollection>();
                        resources.LoadRelations(Navigo.Common.Constants.MaterialResource);

                        Dictionary<long, IMaterialCollection> resourcesMaterials = resources.ToDictionary(r => r.Id, r => r.GetAttachedMaterials(false));

                        // Load all the SourceConsumptionMaterial from all the materials in the feeders
                        materialsAtResources.AddRange(resourcesMaterials.Values.SelectMany(m => m));
                        materialsAtResources.LoadAttributes(new Collection<string>() { IKEAConstants.CustomSourceConsumptionMaterial });

                        // Go through all the materials to direct consume
                        foreach (var materialsToConsume in materialsToDirectConsume)
                        {
                            IResource resource = materialsToConsume.Key;
                            // Dictionary with all the material names as keys
                            Dictionary<string, IMaterial> materialsInResource = resourcesMaterials[resource.Id].ToDictionary(m => m.Name, m => m);
                            // Dictionary with all the material SourceConsumptionMaterial as keys
                            Dictionary<string, IMaterial> sourceConsumptionMaterialInResource = resourcesMaterials[resource.Id].Where(m => m.HasAttribute(IKEAConstants.CustomSourceConsumptionMaterial))
                                                                                                                              .ToDictionary(m => m.GetAttributeValueOrDefault<string>(IKEAConstants.CustomSourceConsumptionMaterial), m => m);

                            // Get the Resource Identifiers
                            string processSegment = resource.GetAttributeValueOrDefault<string>(IKEAConstants.ProcessSegmentSequence, false);
                            string subProcessSegment = resource.GetAttributeValueOrDefault<string>(IKEAConstants.SubProcessSegmentName, false);

                            // Check if the resource is a distributed one. If so, overwrite the process segment with the distributed parent (main feeder):
                            // (The BOM never targets a distributed resource, always the main feeder.)
                            ICustomResourceConsumptionProviderCollection consumptionProviders = resource.GetRelationFromDistributedFeederTarget();
                            if (!consumptionProviders.IsNullOrEmpty())
                            {
                                IResource mainFeeder = consumptionProviders.FirstOrDefault().SourceEntity;

                                // Load the main feeder attributes:
                                mainFeeder.LoadAttributes(new Collection<string>()
                                {
                                    IKEAConstants.ProcessSegmentSequence,
                                    IKEAConstants.SubProcessSegmentName,
                                });

                                processSegment = mainFeeder.GetAttributeValueOrDefault<string>(IKEAConstants.ProcessSegmentSequence);
                                subProcessSegment = mainFeeder.GetAttributeValueOrDefault<string>(IKEAConstants.SubProcessSegmentName);
                            }

                            // Add the process segments to a list to be checked later:
                            lstMaterialsToDirectConsumeProcessSegments.Add(new Tuple<string, string>(processSegment, subProcessSegment));


                            // Try to obtain the BOM product information
                            CustomBOMProductInformation productInformation = customBOMProductInformations.FirstOrDefault(bp => bp.ProcessSegment == processSegment
                                                                                                                            && bp.SubProcessSegment == subProcessSegment
                                                                                                                            && bp.Parent == null);

                            // If there is any BOM Product information build the assemble material
                            if (productInformation != null)
                            {
                                foreach (IMaterial materialToDirectConsume in materialsToConsume.Value)
                                {
                                    IMaterial materialToConsume = null;

                                    // In the case where the given material is not attached to the resource we will
                                    // try to find a split material that came from the expected one
                                    if (!materialsInResource.ContainsKey(materialToDirectConsume.Name))
                                    {
                                        if (sourceConsumptionMaterialInResource.ContainsKey(materialToDirectConsume.Name))
                                        {
                                            // If it was able to find a split material that came from the given one, use ir
                                            materialToConsume = sourceConsumptionMaterialInResource[materialToDirectConsume.Name];
                                        }
                                    }
                                    else
                                    {
                                        materialToConsume = materialToDirectConsume;
                                    }

                                    if (materialToConsume != null)
                                    {
                                        IAssembleMaterial assembleMaterial = new AssembleMaterial()
                                        {
                                            Material = materialToConsume,
                                            SourceProduct = productInformation.TargetEntity,
                                            Quantity = materialQuantities[materialToDirectConsume.Name],
                                            BOMProduct = productInformation.GetBase()
                                        };

                                        assembleCollection.Add(assembleMaterial);
                                    }
                                    else
                                    {
                                        // If there is no matching material
                                        throw new IKEAException(IKEAConstants.CustomAssembleDirectConsumptionWrongMaterialToConsumeLocalizedMessage, materialToDirectConsume.Form, materialToDirectConsume.Name, processSegment, subProcessSegment);
                                    }

                                }
                            }
                            else
                            {
                                // If there is no BOM Product information throw an error
                                throw new IKEAException(IKEAConstants.CustomAssembleDirectConsumptionMismatchBOMProductLocalizedMessage, material.Form, material.Name, processSegment, subProcessSegment);
                            }
                        }
                    }

                    List<string> changedMaterials = new List<string>();

                    IResourceCollection feeders = entityFactory.CreateCollection<IResourceCollection>();

                    foreach (CustomBOMSetupInformationDetail item in customBOMSetupInformation.CustomBOMSetupInformationDetails)
                    {
                        if (item.Resources == null)
                        {
                            throw ikeaUtilities.LocalizedException(IKEAConstants.CustomCouldntResolveBOMResourceLocalizedMessage, customBOMSetupInformation.BOM.Name, item.ProcessSegment);
                        }
                    }

                    feeders.AddRange(customBOMSetupInformation.CustomBOMSetupInformationDetails.SelectMany(bpi => bpi.Resources));
                    feeders.LoadAttributes(new Collection<string>() { IKEAConstants.CustomResourceAttributeFeederConsumptionMode });

                    IMaterialCollection totalConsumedMaterials = entityFactory.CreateCollection<IMaterialCollection>();

                    foreach (CustomBOMProductInformation productInformation in customBOMProductInformations)
                    {
                        CustomBOMSetupInformationDetail detail = customBOMSetupInformation.CustomBOMSetupInformationDetails.First(x => x.ProcessSegment.CompareStrings(productInformation.ProcessSegment)
                                                                                                                                    && x.SubProcessSegment.CompareStrings(productInformation.SubProcessSegment)
                                                                                                                                    && x.ERPBOMOperationSequence.CompareStrings(productInformation.ERPBOMOperationSequence));
                        // If it could not find a matching resource throw an Exception
                        if (detail == null)
                        {
                            throw new IKEAException(IKEAConstants.CustomPerformAutomaticAssembleCantFindResource, productInformation.ProcessSegment);
                        }




                        //// Check if materials were already added to the resource by DirectConsumption (exist in materialsToDirectConsume collection):
                        //if (!materialsToDirectConsume.IsNullOrEmpty())
                        //{
                        //    if (materialsToDirectConsume.Any(R => R.Key.GetAttributeValueOrDefault<string>(IKEAConstants.ProcessSegmentSequence).CompareStrings(productInformation.ProcessSegment)
                        //                                       && R.Key.GetAttributeValueOrDefault<string>(IKEAConstants.SubProcessSegmentName).CompareStrings(productInformation.SubProcessSegment)))
                        //    {
                        //        continue;
                        //    }

                        //    // if distributed consumption, assossiated resource will assume the main feeder process segment. Force it to continue in that case.
                        //    if (detail.Resources.Count > 1)
                        //    {
                        //        continue;
                        //    }
                        //}

                        // Check if materials were already added to the resource by DirectConsumption (exist in materialsToDirectConsume collection):
                        if (!lstMaterialsToDirectConsumeProcessSegments.IsNullOrEmpty())
                        {
                            if (lstMaterialsToDirectConsumeProcessSegments.Any(LST => LST.Item1.CompareStrings(productInformation.ProcessSegment)
                                                                                   && LST.Item2.CompareStrings(productInformation.SubProcessSegment)))
                            {
                                continue;
                            }
                        }




                        if (detail.AttachedMaterials.IsNullOrEmpty())
                        {
                            throw new IKEAException(IKEAConstants.CustomMaterialNotCorrectlySetup, material.Name);
                        }


                        // Create a new Dictionary and calculate the needed quantity to consume
                        IResource usedResource = material.LastProcessedResource;
                        usedResource.Load();
                        usedResource.LoadAttribute(IKEAConstants.CustomRoundOverProductionAndLossQuantity);
                        decimal totalQuantityToConsume = 0;

                        // Check if rounding process of custom assemble is to be used
                        if (usedResource.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomRoundOverProductionAndLossQuantity)
                            && genericUtilities.GetConfigurationValueByPath<bool>(IKEAConstants.CustomAssembleEnabled)
                            && productInformation.IsReference.GetValueOrDefault(false) && productInformation.SourceStep != null)
                        {
                            decimal bomCalculation = decimal.Round(1m / productInformation.Quantity.GetValueOrDefault());
                            totalQuantityToConsume = quantityToProduce * (1m/ bomCalculation);

                            // Check if rounding is necessary based on the context
                            if (quantityToProduce % bomCalculation == 0)
                            {
                                totalQuantityToConsume = decimal.Round(totalQuantityToConsume);
                            }
                            else
                            {
                                totalQuantityToConsume = Math.Truncate(100000000 * totalQuantityToConsume) / 100000000;
                            }
                        }
                        else
                        {
                            totalQuantityToConsume = quantityToProduce * productInformation.Quantity.GetValueOrDefault();
                        }

                        // In case of Distributed consumption on multiple feeders, calculate distributed quantities:
                        Dictionary<long, decimal> distributedQuantitiesToConsume = new Dictionary<long, decimal>();
                        if (detail.Resources.Count > 1)
                        {
                            distributedQuantitiesToConsume = ikeaUtilities.CalculateFeedersDistributedQuantities(totalQuantityToConsume, detail, productInformation);
                        }

                        // Iterate over all feeders:
                        foreach (IResource resource in detail.Resources)
                        {

                            Dictionary<IMaterial, decimal> materialsToConsume = new Dictionary<IMaterial, decimal>();

                            decimal quantityToConsume = totalQuantityToConsume;

                            // In case of distributed consumption with multiple feeders, get the distributed quantity calculated previously:
                            if (distributedQuantitiesToConsume.ContainsKey(resource.Id))
                            {
                                quantityToConsume = distributedQuantitiesToConsume[resource.Id];
                            }

                            // Fill a collection with all materials that are attached to a certain subResource, and the quantity (per material attached)
                            decimal quantityAttached = 0;

                            //Get all materials available to be consumed ( from feeder and tank )
                            IMaterialCollection materialsFromFeederAndTank = entityFactory.CreateCollection<IMaterialCollection>();

                            switch (resource.GetAttributeValueOrDefault<CustomFeederConsumptionModeEnum>(IKEAConstants.CustomResourceAttributeFeederConsumptionMode))
                            {
                                // In case of product base consumption we only get the materials from the specific product
                                case CustomFeederConsumptionModeEnum.ProductSequenceBased:
                                    {
                                        materialsFromFeederAndTank.AddRange(detail.AttachedMaterials[resource.Id].Values.Where(m => m.GetNativeValue<long>(Navigo.Common.Constants.Product) == productInformation.TargetEntityId
                                                                                                                                                                || productInformation.Substitutes.Any(bp => bp.TargetEntityId == m.GetNativeValue<long>(Navigo.Common.Constants.Product))));
                                        break;
                                    }
                                // When Sequence Based, we use all materials per order in the feeder
                                case CustomFeederConsumptionModeEnum.SequenceBased:
                                default:
                                    {
                                        materialsFromFeederAndTank.AddRange(detail.AttachedMaterials[resource.Id].Values);
                                        break;
                                    }
                            }


                            foreach (IMaterial attachedMaterial in materialsFromFeederAndTank)
                            {
                                // Check if the materials was already split
                                if (changedMaterials.Contains(attachedMaterial.Name))
                                {
                                    // Load the material
                                    attachedMaterial.Load();
                                }

                                long materialProductId = attachedMaterial.GetNativeValue<long>(Navigo.Common.Constants.Product);
                                CustomBOMProductInformation bOMProductInformation = productInformation;

                                IMaterial materialToConsume = attachedMaterial;
                                if (quantityToConsume == quantityAttached)
                                {
                                    break;
                                }

                                decimal attachedMaterialQuantity = attachedMaterial.PrimaryQuantity.GetValueOrDefault();
                                decimal actualQuantity = 0;

                                //Material quantity is inferior to the quantity needed
                                //Can use full material quantity
                                if (quantityAttached + attachedMaterialQuantity <= quantityToConsume)
                                {
                                    materialsToConsume.Add(attachedMaterial, attachedMaterialQuantity);
                                    actualQuantity = attachedMaterialQuantity;

                                    quantityAttached += attachedMaterialQuantity;
                                }
                                else
                                {
                                    //Need to use part of the Material quantity
                                    if (detail.ConsumptionMode == CustomConsumptionModeEnum.SplitAndConsume)
                                    {
                                        actualQuantity = quantityToConsume - quantityAttached;
                                        quantityAttached += actualQuantity;

                                        //Material on the tank has more than the quantity we need > Perform split and use the split part
                                        // Prepare split settings
                                        ISplitInputParametersCollection splitSettings = new SplitInputParametersCollection();
                                        ISplitInputParameters sipCompletedSettingParameters = new SplitInputParameters()
                                        {
                                            PrimaryQuantity = quantityToConsume,
                                            SecondaryQuantity = 0
                                        };
                                        splitSettings.Add(sipCompletedSettingParameters);

                                        deeContextUtilities.SetContextParameter(IKEAConstants.CustomPerformAutomaticAssemble_SplitAndConsume, true);
                                        // perform split and update source material
                                        SplitMaterialOutput splitMaterialOutput = materialOrchestration.SplitMaterial(new SplitMaterialInput()
                                        {
                                            ChildMaterials = splitSettings,
                                            Material = attachedMaterial,
                                            TerminateOnZeroQuantity = true,
                                            ToCopyFutureHolds = true,
                                            SplitMode = MaterialSplitMode.SplitNotAssembled
                                        });

                                        if (splitMaterialOutput.ChildMaterials != null && splitMaterialOutput.ChildMaterials.Count > 0)
                                        {
                                            //Add split materials to materialsFromTank and decrease quantity needed 
                                            splitMaterialOutput.ChildMaterials[0].SaveAttributes(new Foundation.BusinessObjects.AttributeCollection() { { IKEAConstants.CustomSourceConsumptionMaterial, attachedMaterial.Name } });
                                        }

                                        // Save the name of the material that was split
                                        changedMaterials.Add(attachedMaterial.Name);

                                        deeContextUtilities.SetContextParameter(IKEAConstants.CustomPerformAutomaticAssemble_SplitAndConsume, false);
                                        materialToConsume = splitMaterialOutput.ChildMaterials[0];
                                        materialsToConsume.Add(splitMaterialOutput.ChildMaterials[0], actualQuantity);
                                    }

                                    if (detail.ConsumptionMode == CustomConsumptionModeEnum.DirectConsumption ||
                                        detail.ConsumptionMode == CustomConsumptionModeEnum.DistributedConsumption)
                                    {
                                        actualQuantity = quantityToConsume - quantityAttached;
                                        quantityAttached += actualQuantity;
                                        materialsToConsume.Add(attachedMaterial, actualQuantity);
                                    }

                                }

                                // Get the Source consumption material from attribute if exists:
                                IAssembleMaterial assembleMaterial = new AssembleMaterial()
                                {
                                    Material = materialToConsume,
                                    SourceProduct = bOMProductInformation.TargetEntity,
                                    Quantity = actualQuantity,
                                    BOMProduct = bOMProductInformation.GetBase()
                                };

                                assembleCollection.Add(assembleMaterial);
                            }

                            // If quantity are not enough to assemble, throw an Exception
                            if (materialsToConsume.Sum(q => q.Value) < quantityToConsume)
                            {
                                throw new IKEAException(IKEAConstants.CustomPerformAutomaticAssembleNotEnoughQuantity,
                                    resource.Name, productInformation.ERPBOMOperationSequence, productInformation.ProcessSegment,
                                    productInformation.SubProcessSegment, quantityToConsume.ToString(), productInformation.Units,
                                    materialsToConsume.Sum(q => q.Value).ToString());
                            }

                            // Fill CustomBOMConsumptionInformation
                            CustomBOMConsumptionInformation bomConsumptionInformation = new CustomBOMConsumptionInformation()
                            {
                                ProcessSegment = productInformation.ProcessSegment,
                                SubProcessSegment = productInformation.SubProcessSegment,
                                ERPBOMOperationSequence = productInformation.ERPBOMOperationSequence,
                                Resource = resource,
                                MaterialsToConsume = materialsToConsume,
                                QuantityToAssemble = totalQuantityToConsume
                            };


                            if (quantitiesToAssemble != null)
                            {
                                // Add values to dictionary Dictionary<CustomBOMProductInformation, CustomBOMConsumptionInformation>
                                quantitiesToAssemble[resource.Id] = new Dictionary<CustomBOMProductInformation, CustomBOMConsumptionInformation>();
                                quantitiesToAssemble[resource.Id].Add(productInformation, bomConsumptionInformation);
                            }

                            totalConsumedMaterials.AddRange(materialsToConsume.Keys);

                        }

                    }

                    // Load the relation MaterialResource
                    totalConsumedMaterials.LoadRelations("MaterialResource");

                    // Get a dictionary with the materials to be consumed and the resources 
                    Dictionary<long, long> materialResource = totalConsumedMaterials.Where(m => m.HasRelations("MaterialResource") && m.RelationCollection["MaterialResource"].Count == 1)
                                                                                    .SelectMany(m => m.RelationCollection["MaterialResource"])
                                                                                    .ToDictionary(m => m.GetNativeValue<long>("SourceEntity"), m => m.GetNativeValue<long>("TargetEntity"));

                    ApplicationContext.CallContext.SetInformationContext("CustomPerformAutomaticAssemble_ConsumedMaterialResources", materialResource);

                }
            }

            return assembleCollection;
        }

    }
}
