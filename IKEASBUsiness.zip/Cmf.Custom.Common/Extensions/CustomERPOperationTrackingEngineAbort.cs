﻿using Cmf.Custom.IKEA.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Common.CustomActionUtilities;

namespace Cmf.Custom.IKEA.Common.Extensions
{
    /// <summary>
    /// Partial class for CustomERPOperationTrackingEngine
    /// </summary>
    public static partial class CustomERPOperationTrackingEngine
    {

        /// <summary>
        /// Handles the abort operation, updating the scheduled quantity of the order
        /// </summary>
        /// <param name="materials"></param>
        public static void HandleAbortMaterial(IMaterialCollection materials)
        {
            string orderForm = ikeaUtilities.GetOrderMaterialForm();
            foreach (IMaterial material in materials)
            {
                if (material.Form == orderForm)
                {
                    ICustomERPOperationTrackingCollection operationTrackings = material.GetAllCustomERPOperationTrackingFromMOByRun(true);

                    if (!operationTrackings.IsNullOrEmpty())
                    {
                        // Set as negative so that it can be removed
                        decimal quantity = -material.PrimaryQuantity.Value;

                        foreach (ICustomERPOperationTracking operationTracking in operationTrackings)
                        {
                            operationTracking.UpdateScheduledQuantity(quantity, true);
                        }
                    }
                }
                else
                {
                    ICustomERPOperationTracking currentCustomERPOperationTracking = CustomERPOperationTrackingEngine.GetCurrentCustomERPOperatingTracking(material);

                    if (currentCustomERPOperationTracking != null)
                    {
                        if (currentCustomERPOperationTracking.OrderScheduledQuantity.HasValue)
                        {
                            //If not original 
                            //Transfers the OrderScheduledQuantity from the current CustomERPOperationTracking to the original CustomERPOperationTracking
                            if (!currentCustomERPOperationTracking.IsOriginal.Value)
                            {
                                ICustomERPOperationTracking originalCustomERPOperationTracking = CustomERPOperationTrackingEngine.GetOriginalCustomERPOperatingTracking(material);
                                currentCustomERPOperationTracking.TransferTo(originalCustomERPOperationTracking, originalCustomERPOperationTracking.OrderScheduledQuantity.Value);

                            }
                            //Updates the scheduled quantity of CustomERPOperationTracking
                            else
                            {
                                currentCustomERPOperationTracking.UpdateScheduledQuantity(-currentCustomERPOperationTracking.OrderScheduledQuantity.Value, false);
                            }
                        }
                    }
                }
            }
        }
    }
}
