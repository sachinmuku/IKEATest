﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Navigo.BusinessObjects;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Foundation.Common;
using Microsoft.Extensions.DependencyInjection;
using Namotion.Reflection;
using Cmf.Custom.IKEA.Common.Abstractions;

namespace Cmf.Custom.IKEA.Common.Extensions
{
    /// <summary>
    /// This class contains flow extension methods
    /// </summary>
    public static class FlowExtensions
    {
        private static IEntityFactory entityFactory => ApplicationContext.CurrentServiceProvider.GetService<IEntityFactory>();

        /// <summary>
        /// Get all ERPOperationCodes from SubsFlows of a Main Flow
        /// </summary>
        /// <param name="mainFlow">Main Flow</param>
        /// <returns>All ERPOperationCodes from SubsFlows of a Main Flow</returns>
        public static List<string> GetAllERPOperationCodesFromSubsFlows(this IFlow mainFlow)
        {
            List<string> erpOperationCodes = new List<string>();

            mainFlow.LoadChilds(1);

            // Check if the flow contains sub flows
            if (mainFlow.ChildType == FlowChildType.Flow)
            {
                Dictionary<IFlow, int> flowPositions = mainFlow.SubFlows.ToDictionary(sf => sf.TargetEntity, sf => sf.Position.Value);

                // Load ERPOperationCode of all flows
                IFlowCollection flows = entityFactory.CreateCollection<IFlowCollection>();
                flows.AddRange(flowPositions.Keys);
                flows.LoadAttributes(new Collection<string>() { IKEAConstants.ERPOperationCode });

                // Get all the sub-flows that contain a ERPOperationCode
                var flowsPosition = flowPositions.OrderBy(f => f.Value).ToList();

                foreach (var flow in flowsPosition)
                {
                    if (flow.Key.HasRelatedAttribute(IKEAConstants.ERPOperationCode))
                    {
                        erpOperationCodes.Add(flow.Key.GetRelatedAttributeValueOrDefault<string>(IKEAConstants.ERPOperationCode));
                    }

                    erpOperationCodes.AddRange(flow.Key.GetAllERPOperationCodesFromSubsFlows());
                }
            }

            return erpOperationCodes;
        }

        /// <summary>Calculate the flowpath of the Flow and the Step</summary>
        /// <param name="flowName">Name of the Flow</param>
        /// <param name="stepName">Name of the Step</param>
        /// <param name="previousCorrelationID">previous subFlow correlation ID</param>
        /// <returns>A string of the flow path</returns>
        public static string GetFlowPath(this IFlow flow, string stepName, int flowIndex = 1, long previousCorrelationID = 0)
        {
            // Search for the step
            if (flow.FlowSteps != null)
            {
                for (int i = 0; i < flow.FlowSteps.Count; i++)
                {
                    if (flow.FlowSteps[i].TargetEntity.Name == stepName)
                    {
                        return (string.Format("{0}:{1}:{2}/{3}:{4}", flow.Name, flow.Revision, flowIndex, stepName, flow.FlowSteps[i].CorrelationID.Value.ToString()));
                    }
                }
            }

            // Search for subflows
            if (flow.SubFlows != null)
            {
                for (int i = 0; i < flow.SubFlows.Count; i++)
                {
                    IFlow subFlow = flow.SubFlows[i].TargetEntity;
                    long CorrelationID = flow.SubFlows[i].CorrelationID.HasValue == true ? flow.SubFlows[i].CorrelationID.Value : 0;
                    string result = GetFlowPath(subFlow, stepName, i + 1);

                    if (result != null)
                    {
                        // If previous flow correlation ID found then taken that else consider flowIndex
                        if (previousCorrelationID > 0)
                        {
                            return (string.Format("{0}:{1}:{2}/{3}", flow.Name, flow.Revision, previousCorrelationID, result));
                        }
                        else
                        {
                            return (string.Format("{0}:{1}:{2}/{3}", flow.Name, flow.Revision, flowIndex, result));
                        }
                    }
                }
            }

            return (null);
        }

    }
}
