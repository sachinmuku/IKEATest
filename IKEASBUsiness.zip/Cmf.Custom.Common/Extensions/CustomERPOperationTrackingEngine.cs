﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Custom.IKEA.BusinessObjects;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.ERP;
using Cmf.Custom.IKEA.Common.Extensions.BOM;
using Cmf.Foundation.BusinessObjects.QueryObject;
using Cmf.Foundation.Common;
using Cmf.Navigo.BusinessObjects;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Xml;
using Cmf.Custom.IKEA.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.SmartTables;
using Pipelines.Sockets.Unofficial.Arenas;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Navigo.BusinessOrchestration.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Enums;

namespace Cmf.Custom.IKEA.Common.Extensions
{
    /// <summary>
    /// Partial class for CustomERPOperationTrackingEngine
    /// </summary>
    public static partial class CustomERPOperationTrackingEngine
    {
        private static IIKEAUtilities ikeaUtilities => ApplicationContext.CurrentServiceProvider.GetService<IIKEAUtilities>();
        private static IGenericUtilities genericUtilities => ApplicationContext.CurrentServiceProvider.GetService<IGenericUtilities>();
        private static IMaterialOrchestration materialOrchestration => ApplicationContext.CurrentServiceProvider.GetService<IMaterialOrchestration>();
        private static IDeeContextUtilities deeContextUtilities => ApplicationContext.CurrentServiceProvider.GetService<IDeeContextUtilities>();
        private static IEntityFactory entityFactory => ApplicationContext.CurrentServiceProvider.GetService<IEntityFactory>();

        private static string objectTypeName = typeof(CustomERPOperationTracking).FullName;

        #region Material Extensions

        /// <summary>
        /// Gets the Current CustomERPOperatingTracking for a given MO, Run, Operation and Resource
        /// </summary>
        /// <param name="instance"></param>
        /// <param name="createIfNotExisting"></param>
        /// <returns></returns>
        public static ICustomERPOperationTracking GetCurrentCustomERPOperatingTracking(this IMaterial instance, bool createIfNotExisting = true)
        {
            ICustomERPOperationTracking currentCustomERPOperationTracking = null;

            // string baseMaterialName = instance.GetAttributeValueOrDefault<string>(IKEAConstants.CustomMaterialAttributeBaseMaterial, true);
            instance.LoadAttributes(new Collection<string>() { IKEAConstants.CustomMaterialAttributeBaseMaterial, IKEAConstants.CustomMaterialAttributeOrderRunNumber });
            //Get Base Material attribute
            string baseMaterialName = instance.GetOrderMaterialName();
            //Get Order Run Number from Material
            int orderRunNumber = instance.GetAttributeValueOrDefault<int>(IKEAConstants.CustomMaterialAttributeOrderRunNumber);
            //ERP operation code
            string currentERPOperationCode = instance.GetCurrentERPOperationCode();

            if (!string.IsNullOrEmpty(currentERPOperationCode) && instance.LastProcessedResource != null && orderRunNumber > 0)
            {
                //Invokes GetCurrentCustomERPOperatingTracking
                currentCustomERPOperationTracking = CustomERPOperationTrackingEngine.GetCustomERPOperatingTracking(baseMaterialName,
                                                                                                                   orderRunNumber,
                                                                                                                   currentERPOperationCode,
                                                                                                                   resourceName: instance.LastProcessedResource.Name);

                //If current does not exist and flag to create is set to true, clone original ERP Operation tracking 
                if ((currentCustomERPOperationTracking == null || currentCustomERPOperationTracking.Id == 0) && createIfNotExisting)
                {
                    //Get source CustomERPOperationTracking
                    ICustomERPOperationTracking sourceCustomERPOperationTracking = CustomERPOperationTrackingEngine.GetOriginalCustomERPOperatingTracking(instance);

                    //currentCustomERPOperationTracking is set to sourceCustomERPOperationTracking
                    currentCustomERPOperationTracking = CustomERPOperationTrackingEngine.Clone(sourceCustomERPOperationTracking, instance.LastProcessedResource.Name);
                }
            }

            return currentCustomERPOperationTracking;
        }

        /// <summary>
        /// Get the CustomERPOperatingTracking marked as the Original
        /// </summary>
        /// <param name="instance">Material to obtain the Original CustomERPOperatingTracking</param>
        /// <returns>CustomERPOperatingTracking marked as the Original</returns>
        public static ICustomERPOperationTracking GetOriginalCustomERPOperatingTracking(this IMaterial instance)
        {
            ICustomERPOperationTracking operationTracking = null;

            instance.LoadAttributes(new Collection<string>() { IKEAConstants.CustomMaterialAttributeBaseMaterial, IKEAConstants.CustomMaterialAttributeOrderRunNumber });

            // Get base material and run number
            string baseMaterial = instance.GetOrderMaterialName();
            int runNumber = instance.GetAttributeValueOrDefault<int>(IKEAConstants.CustomMaterialAttributeOrderRunNumber);

            // Check if the base material, run number and flow are defined in the material
            if (runNumber > 0)
            {
                // Get ERP Operation code from the flow
                string erpOperationCode = instance.GetCurrentERPOperationCode();

                if (!string.IsNullOrWhiteSpace(erpOperationCode))
                {
                    // Get the CustomERPOperatingTracking marked as the Original
                    operationTracking = GetCustomERPOperatingTracking(baseMaterial,
                                                                      runNumber,
                                                                      erpOperationCode);
                }
            }


            return operationTracking;
        }

        /// <summary>
        /// Evaluate if the finished quantity has already reached the scheduled quantity, 
        /// if it has, then reports consumptions 
        /// </summary>
        /// <param name="instance">Material to evaluate</param>
        /// <param name="operationCode">ERP Operation Code</param>
        public static bool EvaluateReportConsumption(this IMaterial instance, string operationCode)
        {
            instance.LoadAttributes(new Collection<string>() { IKEAConstants.CustomMaterialAttributeOrderRunNumber });

            //Get Base Material attribute
            string baseMaterialName = instance.GetOrderMaterialName();

            //Get Order Run Number from Material
            int orderRunNumber = instance.GetAttributeValueOrDefault<int>(IKEAConstants.CustomMaterialAttributeOrderRunNumber);

            // Call base EvaluateReportConsumption
            return EvaluateReportConsumption(baseMaterialName, orderRunNumber, operationCode);
        }

        /// <summary>
        /// Evaluate if the finished quantity has already reached the scheduled quantity, 
        /// if it has, then reports consumptions 
        /// </summary>
        /// <param name="orderMaterial">Mo material name</param>
        /// <param name="runNumber">Run Number</param>
        /// <param name="operationCode">ERP Operation Code</param>
        public static bool EvaluateReportConsumption(string orderMaterial, int runNumber, string operationCode)
        {
            bool reportedConsumption = false;
            // Get all operation tracking for the Material Order, Material Run and ERP Operation Code
            ICustomERPOperationTrackingCollection operationTrackings = GetCustomERPOperationTrackingFromMOByERPOperationCode(orderMaterial, runNumber, operationCode, true);

            decimal scheduledQuantity = decimal.Zero;
            decimal finishedQuantity = decimal.Zero;

            // Sum all the schedule and finished quantities so that they can be compared
            foreach (ICustomERPOperationTracking operationTracking in operationTrackings)
            {
                scheduledQuantity += operationTracking.OrderScheduledQuantity.Value;
                finishedQuantity += operationTracking.OrderFinishedQuantity.Value;
            }

            // Check if the finished quantity has already reached or surpassed the scheduled quantity
            if (finishedQuantity >= scheduledQuantity)
            {
                // Report the consumption
                ICustomERPOperationTracking operationTrackingOriginal = operationTrackings.Where(ot => ot.IsOriginal.Value).First();
                operationTrackingOriginal.ReportConsumption();
                reportedConsumption = true;
            }
            return reportedConsumption;
        }

        public static bool EvaluateReportOperation(this IMaterial instance, string operationCode)
        {
            instance.LoadAttributes(new Collection<string>() { IKEAConstants.CustomMaterialAttributeOrderRunNumber });

            //Get Base Material attribute
            string baseMaterialName = instance.GetOrderMaterialName();

            //Get Order Run Number from Material
            int orderRunNumber = instance.GetAttributeValueOrDefault<int>(IKEAConstants.CustomMaterialAttributeOrderRunNumber);

            return EvaluateReportOperation(baseMaterialName, orderRunNumber, operationCode);
        }

        public static bool EvaluateReportOperation(string orderMaterial, int runNumber, string operationCode)
        {
            bool reportedOperation = false;
            //Loads all CustomERPOperationTracking entities for that order material, run number and operation
            ICustomERPOperationTrackingCollection operationTrackings = GetCustomERPOperationTrackingFromMOByERPOperationCode(orderMaterial, runNumber, operationCode, true);

            //checks if the total of completed quantities as reached the total scheduled quantities.
            if (operationTrackings.Count > 0)
            {
                var operationTrackingsAggregated = operationTrackings.GroupBy(r => r.OrderOperation)
                         .Select(a => new { Name = a.Key, OrderScheduledQuantitySum = a.Sum(b => b.OrderScheduledQuantity), OrderFinishedQuantitySum = a.Sum(b => b.OrderFinishedQuantity) })
                         .FirstOrDefault();

                if (operationTrackingsAggregated.OrderFinishedQuantitySum >= operationTrackingsAggregated.OrderScheduledQuantitySum)
                {
                    //reports operation per resource
                    foreach (ICustomERPOperationTracking operationTracking in operationTrackings)
                    {
                        // Report ReportableQuantity
                        operationTracking.LoadAttributes(new Collection<string>
                        {
                            IKEAConstants.CustomERPOperationTrackingAttributeOrderReportableQuantity
                        });
                        object objOrderReportableQuantity = operationTracking.GetAttributeValue(IKEAConstants.CustomERPOperationTrackingAttributeOrderReportableQuantity);
                        decimal quantityToReport = 0;
                        if (objOrderReportableQuantity != null)
                        {
                            decimal.TryParse(objOrderReportableQuantity.ToString(), out quantityToReport);
                        }
                        else
                        {
                            quantityToReport = 0;
                        }

                        // In the case where the reportable quantity surpasses the scheduled quantity we will only report the delta between the two
                        // in the report operation
                        if (quantityToReport > operationTracking.OrderScheduledQuantity)
                        {
                            quantityToReport = quantityToReport - operationTracking.OrderScheduledQuantity.Value;
                        }

                        if (quantityToReport > 0) // If Quantity > 0 then only allow to Report, To avoid non-reportable pallet types to trigger report operation
                        {
                            // Report Operation
                            operationTracking.ReportOperation(quantityToReport);
                            reportedOperation = true;
                        }
                    }
                }
            }
            return reportedOperation;
        }

        /// <summary>
        /// Get CustomERPOperationTracking from MO and ERP Operation Code
        /// </summary>
        /// <param name="instance">Material MO</param>
        /// <param name="erpOperationCode">ERP Operation Code</param>
        /// <returns>CustomERPOperationTracking from MO and ERP Operation Code</returns>
        public static ICustomERPOperationTrackingCollection GetCustomERPOperationTrackingFromMOByERPOperationCode(this IMaterial instance, string erpOperationCode, bool loadEntities = false)
        {
            instance.LoadAttributes(new Collection<string>() { IKEAConstants.CustomMaterialAttributeOrderRunNumber });

            //Get Base Material attribute
            string baseMaterialName = instance.GetOrderMaterialName();

            //Get Order Run Number from Material
            int orderRunNumber = instance.GetAttributeValueOrDefault<int>(IKEAConstants.CustomMaterialAttributeOrderRunNumber);

            return GetCustomERPOperationTrackingFromMOByERPOperationCode(baseMaterialName, orderRunNumber, erpOperationCode, loadEntities);
        }

        /// <summary>
        /// Get All CustomERPOperationTracking from MO and Run
        /// </summary>
        /// <param name="material">Material MO</param>
        /// <returns>CustomERPOperationTracking from MO and ERP Operation Code</returns>
        public static ICustomERPOperationTrackingCollection GetAllCustomERPOperationTrackingFromMOByRun(this IMaterial material, bool loadEntities = false)
        {
            ICustomERPOperationTrackingCollection operationTrackings = null;

            // Check if the material is initialized
            if (material != null)
            {
                material.LoadAttribute(IKEAConstants.CustomMaterialAttributeOrderRunNumber);

                // Get the run of the material
                int? runNumber = material.GetAttributeValueOrDefault<int?>(IKEAConstants.CustomMaterialAttributeOrderRunNumber);

                // if material is an order material then use its name, otherwise, extract base material name from attributes
                string orderMaterialName = material.GetOrderMaterialName() ?? String.Empty;

                // Only proceed if there is a run defined
                if (runNumber.HasValue)
                {
                    IQueryObject query = new QueryObject();
                    query.Description = "";
                    query.EntityTypeName = "CustomERPOperationTracking";
                    query.Name = "GetCustomERPOperationTrackingFromMO";
                    query.Query = new Query();
                    query.Query.Distinct = false;
                    query.Query.Filters = new FilterCollection()
                    {
                        new Filter()
                        {
                            Name = "OrderMaterial",
                            ObjectName = "CustomERPOperationTracking",
                            ObjectAlias = "CustomERPOperationTracking_1",
                            Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                            Value = orderMaterialName,
                            LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND,
                            FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                        },
                        new Filter()
                        {
                            Name = "OrderRunNumber",
                            ObjectName = "CustomERPOperationTracking",
                            ObjectAlias = "CustomERPOperationTracking_1",
                            Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                            Value = runNumber.Value,
                            LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND,
                            FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                        },
                        new Filter()
                        {
                            Name = "UniversalState",
                            ObjectName = "CustomERPOperationTracking",
                            ObjectAlias = "CustomERPOperationTracking_1",
                            Operator = Cmf.Foundation.Common.FieldOperator.IsNotEqualTo,
                            Value = (int)Foundation.Common.Base.UniversalState.Terminated,
                            LogicalOperator = Cmf.Foundation.Common.LogicalOperator.Nothing,
                            FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                        }
                    };
                    query.Query.Fields = new FieldCollection() {
                        new Field()
                        {
                            Alias = "Id",
                            ObjectName = "CustomERPOperationTracking",
                            ObjectAlias = "CustomERPOperationTracking_1",
                            IsUserAttribute = false,
                            Name = "Id",
                            Position = 0,
                            Sort = Cmf.Foundation.Common.FieldSort.NoSort
                        },
                        new Field()
                        {
                            Alias = "Name",
                            ObjectName = "CustomERPOperationTracking",
                            ObjectAlias = "CustomERPOperationTracking_1",
                            IsUserAttribute = false,
                            Name = "Name",
                            Position = 1,
                            Sort = Cmf.Foundation.Common.FieldSort.NoSort
                        }
                    };
                    query.Query.Relations = new RelationCollection();

                    DataSet resultDataSet = query.Execute(false, new QueryParameterCollection());

                    if (resultDataSet.HasData())
                    {
                        operationTrackings = entityFactory.CreateCollection<ICustomERPOperationTrackingCollection>();

                        foreach (DataRow row in resultDataSet.Tables[0].Rows)
                        {
                            var customERPOperationTracking = entityFactory.Create<ICustomERPOperationTracking>();
                            customERPOperationTracking.Name = row.Field<string>("Name");
                            operationTrackings.Add(customERPOperationTracking);
                        }

                        if (loadEntities && !operationTrackings.IsNullOrEmpty())
                        {
                            operationTrackings.Load();
                        }
                    }
                }
            }

            return operationTrackings;
        }

        #endregion

        #region Get CustomERPOperationTracking from DB

        /// <summary>
        /// Get the CustomERPOperatingTracking for a given Resource / Marked as Original 
        /// </summary>
        /// <param name="orderMaterialName"></param>
        /// <param name="orderMaterialRun"></param>
        /// <param name="orderMaterialOperation"></param>
        /// <param name="IsOriginal"></param>
        /// <param name="resourceName"></param>
        /// <returns>CustomERPOperationTracking</returns>
        public static ICustomERPOperationTracking GetCustomERPOperatingTracking(string orderMaterialName, int orderMaterialRun, string orderMaterialOperation, bool IsOriginal = true, string resourceName = null)
        {

            IQueryObject query = new QueryObject();
            query.Description = "";
            query.EntityTypeName = "CustomERPOperationTracking";
            query.Name = "GetOriginalCustomERPOperatingTracking";
            query.Query = new Query();
            query.Query.Distinct = false;
            query.Query.Filters = new FilterCollection() {
                new Filter()
                {
                    Name = "OrderMaterial",
                    ObjectName = "CustomERPOperationTracking",
                    ObjectAlias = "CustomERPOperationTracking_1",
                    Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                    Value = orderMaterialName,
                    LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND,
                    FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                },
                new Filter()
                {
                    Name = "OrderRunNumber",
                    ObjectName = "CustomERPOperationTracking",
                    ObjectAlias = "CustomERPOperationTracking_1",
                    Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                    Value = orderMaterialRun,
                    LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND,
                    FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                },
                new Filter()
                {
                    Name = "OrderOperation",
                    ObjectName = "CustomERPOperationTracking",
                    ObjectAlias = "CustomERPOperationTracking_1",
                    Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                    Value = orderMaterialOperation,
                    LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND,
                    FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                },
                new Filter()
                {
                    Name = "UniversalState",
                    ObjectName = "CustomERPOperationTracking",
                    ObjectAlias = "CustomERPOperationTracking_1",
                    Operator = Cmf.Foundation.Common.FieldOperator.IsNotEqualTo,
                    Value = (int)Foundation.Common.Base.UniversalState.Terminated,
                    LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND,
                    FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                }

            };
            if (!string.IsNullOrEmpty(resourceName))
            {
                query.Query.Filters.Add(
                    new Filter()
                    {
                        Name = "OrderResource",
                        ObjectName = "CustomERPOperationTracking",
                        ObjectAlias = "CustomERPOperationTracking_1",
                        Operator = Cmf.Foundation.Common.FieldOperator.Contains,
                        Value = resourceName,
                        LogicalOperator = Cmf.Foundation.Common.LogicalOperator.Nothing,
                        FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                    });
            }
            else
            {
                query.Query.Filters.Add(
                    new Filter()
                    {
                        Name = "IsOriginal",
                        ObjectName = "CustomERPOperationTracking",
                        ObjectAlias = "CustomERPOperationTracking_1",
                        Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                        Value = IsOriginal,
                        LogicalOperator = Cmf.Foundation.Common.LogicalOperator.Nothing,
                        FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                    });

            }
            query.Query.Fields = new FieldCollection() {
                new Field()
                {
                    Alias = "Id",
                    ObjectName = "CustomERPOperationTracking",
                    ObjectAlias = "CustomERPOperationTracking_1",
                    IsUserAttribute = false,
                    Name = "Id",
                    Position = 0,
                    Sort = Cmf.Foundation.Common.FieldSort.NoSort
                },
                new Field()
                {
                    Alias = "Name",
                    ObjectName = "CustomERPOperationTracking",
                    ObjectAlias = "CustomERPOperationTracking_1",
                    IsUserAttribute = false,
                    Name = "Name",
                    Position = 1,
                    Sort = Cmf.Foundation.Common.FieldSort.NoSort
                },
                new Field()
                {
                    Alias = "OrderOperationSequence",
                    ObjectName = "CustomERPOperationTracking",
                    ObjectAlias = "CustomERPOperationTracking_1",
                    IsUserAttribute = true,
                    Name = "OrderOperationSequence",
                    Position = 2,
                    Sort = Cmf.Foundation.Common.FieldSort.Ascending
                }
            };
            query.Query.Relations = new RelationCollection();

            DataSet resultDataSet = query.Execute(false, new QueryParameterCollection());
           

            if (resultDataSet.HasData())
            {
                var customERPOperationTracking = entityFactory.Create<ICustomERPOperationTracking>();
                customERPOperationTracking.Name = resultDataSet.Tables[0].Rows[0].Field<string>("Name");
                customERPOperationTracking.Load();
                return customERPOperationTracking;
            }

            return null;
        }

        /// <summary>
        /// Get CustomERPOperationTracking from MO and ERP Operation Code
        /// </summary>
        /// <param name="orderMaterial">Material MO</param>
        /// <param name="runNumber">Material Run Number</param>
        /// <param name="erpOperationCode">ERP Operation Code</param>
        /// <param name="erpOperationCode">Load Entities?</param>
        /// <returns>CustomERPOperationTracking from MO and ERP Operation Code</returns>
        public static ICustomERPOperationTrackingCollection GetCustomERPOperationTrackingFromMOByERPOperationCode(string orderMaterial, int runNumber, string erpOperationCode, bool loadEntities = false)
        {
            ICustomERPOperationTrackingCollection customERPOperationTracking = null;

            // Check if the material is initialized and if there is a ERP Operation Code defined
            if (orderMaterial != null && !string.IsNullOrWhiteSpace(erpOperationCode))
            {
                // Only proceed if there is a run defined
                if (runNumber > 0)
                {
                    IQueryObject query = new QueryObject();
                    query.Description = "";
                    query.EntityTypeName = "CustomERPOperationTracking";
                    query.Name = "GetCustomERPOperationTrackingFromMO";
                    query.Query = new Query();
                    query.Query.Distinct = false;
                    query.Query.Filters = new FilterCollection()
                    {
                        new Filter()
                        {
                            Name = "OrderMaterial",
                            ObjectName = "CustomERPOperationTracking",
                            ObjectAlias = "CustomERPOperationTracking_1",
                            Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                            Value = orderMaterial,
                            LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND,
                            FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                        },
                        new Filter()
                        {
                            Name = "OrderRunNumber",
                            ObjectName = "CustomERPOperationTracking",
                            ObjectAlias = "CustomERPOperationTracking_1",
                            Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                            Value = runNumber,
                            LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND,
                            FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                        },
                        new Filter()
                        {
                            Name = "OrderOperation",
                            ObjectName = "CustomERPOperationTracking",
                            ObjectAlias = "CustomERPOperationTracking_1",
                            Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                            Value = erpOperationCode,
                            LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND,
                            FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                        },
                        new Filter()
                        {
                            Name = "UniversalState",
                            ObjectName = "CustomERPOperationTracking",
                            ObjectAlias = "CustomERPOperationTracking_1",
                            Operator = Cmf.Foundation.Common.FieldOperator.IsNotEqualTo,
                            Value = (int)Foundation.Common.Base.UniversalState.Terminated,
                            LogicalOperator = Cmf.Foundation.Common.LogicalOperator.Nothing,
                            FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                        }
                    };
                    query.Query.Fields = new FieldCollection() {
                        new Field()
                        {
                            Alias = "Id",
                            ObjectName = "CustomERPOperationTracking",
                            ObjectAlias = "CustomERPOperationTracking_1",
                            IsUserAttribute = false,
                            Name = "Id",
                            Position = 0,
                            Sort = Cmf.Foundation.Common.FieldSort.NoSort
                        },
                        new Field()
                        {
                            Alias = "Name",
                            ObjectName = "CustomERPOperationTracking",
                            ObjectAlias = "CustomERPOperationTracking_1",
                            IsUserAttribute = false,
                            Name = "Name",
                            Position = 1,
                            Sort = Cmf.Foundation.Common.FieldSort.NoSort
                        }
                    };
                    query.Query.Relations = new RelationCollection();

                    DataSet resultDataSet = query.Execute(false, new QueryParameterCollection());

                    if (resultDataSet.HasData())
                    {
                        customERPOperationTracking = entityFactory.CreateCollection<ICustomERPOperationTrackingCollection>();
                        foreach (DataRow row in resultDataSet.Tables[0].Rows)
                        {
                            var customERPOperationTrackingEntity = entityFactory.Create<ICustomERPOperationTracking>();
                            customERPOperationTrackingEntity.Name = row.Field<string>("Name");
                            customERPOperationTracking.Add(customERPOperationTrackingEntity);
                        }

                        if (loadEntities)
                        {
                            customERPOperationTracking.Load();
                        }
                    }
                }
            }

            return customERPOperationTracking;
        }

        #endregion

        #region Get CustomERPOperationTrackingConsumptioLogs from DB

        /// <summary>
        /// Get all CustomERPOperationTrackingConsumptioLogs from a MO, run number and ERP Operation Code
        /// </summary>
        /// <param name="orderMaterialName">MO name</param>
        /// <param name="orderMaterialRun">Run Number of the material</param>
        /// <param name="orderMaterialOperation">ERP Operation Code</param>
        /// <param name="loadEntities">Load Entities?</param>
        /// <returns>All CustomERPOperationTrackingConsumptioLogs from a MO, run number and ERP Operation Code</returns>
        public static ICustomERPOperationTrackingConsumptionLogCollection GetAllConsumptionLogsForMO(string orderMaterialName, int orderMaterialRun, string orderMaterialOperation, bool loadEntities = false)
        {
            ICustomERPOperationTrackingConsumptionLogCollection consumptionLogs = entityFactory.CreateCollection<ICustomERPOperationTrackingConsumptionLogCollection>();

            IQueryObject query = new QueryObject();
            query.Description = "";
            query.EntityTypeName = "CustomERPOperationTrackingConsumptionLog";
            query.Name = "GetAllConsumptionLogsForMO";
            query.Query = new Query();
            query.Query.Distinct = false;
            query.Query.Filters = new FilterCollection() {
                new Filter()
                {
                    Name = "OrderMaterial",
                    ObjectName = "CustomERPOperationTracking",
                    ObjectAlias = "CustomERPOperationTrackingConsumptionLog_CustomERPOperationTracking_2",
                    Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                    Value = orderMaterialName,
                    LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND,
                    FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                },
                new Filter()
                {
                    Name = "OrderRunNumber",
                    ObjectName = "CustomERPOperationTracking",
                    ObjectAlias = "CustomERPOperationTrackingConsumptionLog_CustomERPOperationTracking_2",
                    Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                    Value = orderMaterialRun,
                    LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND,
                    FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                },
                new Filter()
                {
                    Name = "OrderOperation",
                    ObjectName = "CustomERPOperationTracking",
                    ObjectAlias = "CustomERPOperationTrackingConsumptionLog_CustomERPOperationTracking_2",
                    Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                    Value = orderMaterialOperation,
                    LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND,
                    FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                },
                new Filter()
                {
                    Name = "UniversalState",
                    ObjectName = "CustomERPOperationTracking",
                    ObjectAlias = "CustomERPOperationTrackingConsumptionLog_CustomERPOperationTracking_2",
                    Operator = Cmf.Foundation.Common.FieldOperator.IsNotEqualTo,
                    Value = (int)Foundation.Common.Base.UniversalState.Terminated,
                    LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND,
                    FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                },
                new Filter()
                {
                    Name = "UniversalState",
                    ObjectName = "CustomERPOperationTrackingConsumptionLog",
                    ObjectAlias = "CustomERPOperationTrackingConsumptionLog_1",
                    Operator = Cmf.Foundation.Common.FieldOperator.IsNotEqualTo,
                    Value = (int)Foundation.Common.Base.UniversalState.Terminated,
                    LogicalOperator = Cmf.Foundation.Common.LogicalOperator.Nothing,
                    FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                }
            };
            query.Query.Fields = new FieldCollection() {
                new Field()
                {
                    Alias = "Id",
                    ObjectName = "CustomERPOperationTrackingConsumptionLog",
                    ObjectAlias = "CustomERPOperationTrackingConsumptionLog_1",
                    IsUserAttribute = false,
                    Name = "Id",
                    Position = 0,
                    Sort = Cmf.Foundation.Common.FieldSort.NoSort
                },
                new Field()
                {
                    Alias = "Name",
                    ObjectName = "CustomERPOperationTrackingConsumptionLog",
                    ObjectAlias = "CustomERPOperationTrackingConsumptionLog_1",
                    IsUserAttribute = false,
                    Name = "Name",
                    Position = 1,
                    Sort = Cmf.Foundation.Common.FieldSort.NoSort
                }
            };
            query.Query.Relations = new RelationCollection() {
                new Relation()
                {
                    Alias = "",
                    IsRelation = false,
                    Name = "",
                    SourceEntity = "CustomERPOperationTrackingConsumptionLog",
                    SourceEntityAlias = "CustomERPOperationTrackingConsumptionLog_1",
                    SourceJoinType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.JoinType.InnerJoin,
                    SourceProperty = "CustomERPOperationTrackingId",
                    TargetEntity = "CustomERPOperationTracking",
                    TargetEntityAlias = "CustomERPOperationTrackingConsumptionLog_CustomERPOperationTracking_2",
                    TargetJoinType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.JoinType.InnerJoin,
                    TargetProperty = "Id"
                }
            };

            DataSet resultDataSet = query.Execute(false, new QueryParameterCollection());

            if (resultDataSet.HasData())
            {
                if (resultDataSet.HasData())
                {
                    foreach (DataRow row in resultDataSet.Tables[0].Rows)
                    {
                        var customERPOperationTrackingConsumptionLog = entityFactory.Create<ICustomERPOperationTrackingConsumptionLog>();
                        customERPOperationTrackingConsumptionLog.Name = row.Field<string>("Name");
                        consumptionLogs.Add(customERPOperationTrackingConsumptionLog);
                    }

                    if (loadEntities)
                    {
                        consumptionLogs.Load();
                    }
                }
            }

            return consumptionLogs;
        }

        #endregion

        #region Clone CustomERPOperationTracking

        /// <summary>
        /// Clones a given CustomERPOperationTracking and sets the Order Resource to a given Resource
        /// IsOriginal is Set to False and Quantities are set to 0
        /// </summary>
        /// <param name="source"></param>
        /// <param name="targetResourceName"></param>
        /// <returns></returns>
        public static ICustomERPOperationTracking Clone(ICustomERPOperationTracking source, string targetResourceName)
        {
            ICustomERPOperationTracking clonedCustomERPOperationTracking = null;

            if (source != null)
            {
                clonedCustomERPOperationTracking = entityFactory.Create<ICustomERPOperationTracking>(); ;
                //clonedCustomERPOperationTracking set name
                clonedCustomERPOperationTracking.Name = string.Format("{0}.{1}.{2}.{3}", source.OrderMaterial, source.OrderRunNumber, source.OrderOperation, targetResourceName);
                //Clone the source CustomERPOperationTracking entity
                clonedCustomERPOperationTracking.Clone(source);
                //Setup order resource, isOriginal = false and quantities set to 0
                clonedCustomERPOperationTracking.OrderResource = targetResourceName;
                clonedCustomERPOperationTracking.IsOriginal = false;
                clonedCustomERPOperationTracking.OrderFinishedQuantity = 0;
                clonedCustomERPOperationTracking.OrderScheduledQuantity = 0;
                //Create object on database
                clonedCustomERPOperationTracking.Save();

                //Create relation CustomPOERPOperationTracking
                source.LoadRelations("CustomPOERPOperationTracking");
                //Get ProductionOrder
                ICustomPOERPOperationTracking customPOERPOperationTracking = source.RelationCollection["CustomPOERPOperationTracking"].FirstOrDefault() as ICustomPOERPOperationTracking;
                //Create Relation
                ICustomPOERPOperationTracking poERPOperationTracking = entityFactory.Create<ICustomPOERPOperationTracking>();
                poERPOperationTracking.SourceEntity = customPOERPOperationTracking.SourceEntity;
                poERPOperationTracking.TargetEntity = clonedCustomERPOperationTracking;
                poERPOperationTracking.Create();
            }

            return clonedCustomERPOperationTracking;
        }

        #endregion

        #region Transfer CustomERPOperationTracking

        /// <summary>
        /// Transfers the scheduled quantity from source CustomERPOperationTracking to target CustomERPOperationTracking
        /// </summary>
        /// <param name="source"></param>
        /// <param name="target"></param>
        /// <param name="transferredScheduledQuantity"></param>
        public static void TransferScheduledQuantity(ICustomERPOperationTracking source, ICustomERPOperationTracking target, decimal transferredScheduledQuantity)
        {
            CustomOperationExecutionSettings res = new CustomOperationExecutionSettings();

            // Log method start
            Cmf.Foundation.Common.Utilities.StartMethod(objectTypeName, "TransferScheduledQuantity", new KeyValuePair<String, Object>("CustomERPOperationTrackingSource", source),
                                                                    new KeyValuePair<String, Object>("CustomERPOperationTrackingTarget", target),
                                                                    new KeyValuePair<String, Object>("QuantityTransfered", transferredScheduledQuantity),
                                                                    new KeyValuePair<String, Object>("TransferScheduledQuantitySettings", res));

            //Decrements scheduled quantity from source and increments to target
            source.OrderScheduledQuantity -= transferredScheduledQuantity;
            target.OrderScheduledQuantity += transferredScheduledQuantity;

            ICustomERPOperationTrackingCollection customERPOperationTrackingCollection = entityFactory.CreateCollection<ICustomERPOperationTrackingCollection>();
            customERPOperationTrackingCollection.Add(source);
            customERPOperationTrackingCollection.Add(target);

            customERPOperationTrackingCollection.Save();

            //If OrderFinishedQuantity and OrderScheduledQuantity are 0 and is not original, terminate entity
            source.Load();
            if (source.OrderFinishedQuantity == 0 && source.OrderScheduledQuantity == 0 && (!source.IsOriginal.HasValue || !source.IsOriginal.Value))
            {

                source.LoadRelations("CustomPOERPOperationTracking");

                // Terminate the relations
                if (source.HasRelations("CustomPOERPOperationTracking"))
                {
                    ICustomPOERPOperationTrackingCollection operationTrackings = entityFactory.CreateCollection<ICustomPOERPOperationTrackingCollection>();
                    operationTrackings.AddRange(source.RelationCollection["CustomPOERPOperationTracking"].Select(ot => ot as ICustomPOERPOperationTracking));

                    operationTrackings.Terminate();
                }

                // If both finished and scheduled quantities are 0 then the ERPOperationTracking can be terminated
                source.Terminate();
            }

            // log method exit
            long objectInstanceId = source.Id;
            long objectTypeId = source.EntityType.Id;
            Cmf.Foundation.Common.Utilities.EndMethod(objectTypeId, objectInstanceId, new KeyValuePair<String, Object>("TransferScheduledQuantity", transferredScheduledQuantity));
        }

        /// <summary>
        /// Transfers scheduled quantity on input from source CustomERPOperationTracking to CustomERPOperationTracking of the target resource received on the input
        /// </summary>
        /// <param name="source"></param>
        /// <param name="targetResource"></param>
        /// <param name="transferredScheduledQuantity"></param>
        public static void TransferScheduledQuantity(ICustomERPOperationTracking source, string targetResource, decimal transferredScheduledQuantity)
        {
            ICustomERPOperationTracking resourceERPOperationTracking = null;
            //Verifies that target resource is different from source entry
            if (source.OrderResource != targetResource)
            {
                //Retrieves ERPOperationTracking entry for selected resource and base properties from source (order material, run number and operation)
                resourceERPOperationTracking = CustomERPOperationTrackingEngine.GetCustomERPOperatingTracking(source.OrderMaterial, source.OrderRunNumber.Value, source.OrderOperation, resourceName: targetResource);
                // If not existing invokes CustomERPOperationTrackingEngine.Clone(source, targetResource) to create entry for current reesource
                if (resourceERPOperationTracking == null)
                {
                    resourceERPOperationTracking = CustomERPOperationTrackingEngine.Clone(source, targetResource);
                }
                //Then invokes CustomERPOperationTrackingEngine.TransferScheduledQuantity(CustomERPOperationTracking source, CustomERPOperationTracking target, decimal transferredScheduledQuantity)
                CustomERPOperationTrackingEngine.TransferScheduledQuantity(source, resourceERPOperationTracking, transferredScheduledQuantity);
            }
        }

        /// <summary>
        /// Transfers the scheduled quantity from source CustomERPOperationTracking to target CustomERPOperationTracking
        /// </summary>
        /// <param name="instance"></param>
        /// <param name="targetInstance"></param>
        /// <param name="transferredScheduledQuantity"></param>
        public static void TransferTo(this ICustomERPOperationTracking instance, ICustomERPOperationTracking targetInstance, decimal transferredScheduledQuantity)
        {
            CustomERPOperationTrackingEngine.TransferScheduledQuantity(instance, targetInstance, transferredScheduledQuantity);
        }

        #endregion

        #region CustomERPOperationTracking Extensions

        /// <summary>
        /// Report Consumption to ERP
        /// </summary>
        /// <param name="customERPOperationTracking">ERP Operation Tracking to be reported</param>
        public static void ReportConsumption(this ICustomERPOperationTracking customERPOperationTracking, IProductionOrder productionOrder = null, ICustomPOOperationResourceCollection poOperationResources = null)
        {
            CustomOperationExecutionSettings res = new CustomOperationExecutionSettings();

            // Log method start
            Cmf.Foundation.Common.Utilities.StartMethod(objectTypeName, "ReportConsumption", new KeyValuePair<String, Object>("CustomERPOperationTracking", customERPOperationTracking),
                                                                        new KeyValuePair<String, Object>("CustomOperationExecutionSettings", res));



            // Does previous actions override this one
            if (!res.IsOverride)
            {
                if (customERPOperationTracking != null)
                {
                    // Get Production Order
                    if (productionOrder == null)
                    {
                        customERPOperationTracking.LoadRelations("CustomPOERPOperationTracking");
                        productionOrder = customERPOperationTracking.RelationCollection["CustomPOERPOperationTracking"].Select(ot => (ot as ICustomPOERPOperationTracking).SourceEntity).FirstOrDefault();
                    }

                    if (poOperationResources.IsNullOrEmpty())
                    {
                        productionOrder.LoadRelations(IKEAConstants.CustomPOOperationResource);
                        if (productionOrder.HasRelations(IKEAConstants.CustomPOOperationResource))
                        {
                            poOperationResources = entityFactory.CreateCollection<ICustomPOOperationResourceCollection>();
                            poOperationResources.AddRange(productionOrder.RelationCollection[IKEAConstants.CustomPOOperationResource].Select(pr => pr as ICustomPOOperationResource));
                        }
                    }

                    if (!poOperationResources.IsNullOrEmpty())
                    {
                        ICustomPOOperationResource poOperationResource = poOperationResources.Where(p => p.OperationCode == customERPOperationTracking.OrderOperation).FirstOrDefault();

                        if (poOperationResource != null)
                        {
                            IResource resource = poOperationResource.TargetEntity;

                            // If the original the resource is different than the target resource, use the original resource
                            if (!poOperationResource.OriginalResourceToReport.IsNullOrEmpty())
                            {
                                if (resource.Name != poOperationResource.OriginalResourceToReport)
                                {
                                    resource = ikeaUtilities.GetResurceByName(poOperationResource.OriginalResourceToReport);
                                }
                            }

                            bool automaticReportConsumption = false;

                            // Check if the automatic reporting of consumption is enabled on the SmartTable:
                            IMaterial materialMO = entityFactory.Create<IMaterial>();
                            materialMO.Name = customERPOperationTracking.OrderMaterial;

                            if (materialMO.ObjectExists())
                            {
                                materialMO.Load();

                                IArea area = ikeaUtilities.GetAreaFromMaterial(materialMO);

                                ikeaUtilities.ResolveCustomERPReporting(materialMO.Step, materialMO.Facility, area, resource.Name).TryGetValue(IKEAConstants.CustomERPReportingResolutionReportConsumptionColumn, out automaticReportConsumption);

                                if (automaticReportConsumption)
                                {
                                    // Get resource inventory location
                                    string invetoryLocation = resource.GetAttributeValueOrDefault<string>(IKEAConstants.CustomResourceAttributeInventoryLocation, true);

                                    // Get Facility ERP identifier
                                    string erpIdentifier = productionOrder.Facility.GetAttributeValueOrDefault<string>(IKEAConstants.CustomFacilityAttributeERPIdentifier, true);

                                    // Get All ConsumptionLog entries of a CustomERPOperationTracking
                                    ICustomERPOperationTrackingConsumptionLogCollection consumptionLogs = GetAllConsumptionLogsForMO(customERPOperationTracking.OrderMaterial, customERPOperationTracking.OrderRunNumber.Value, customERPOperationTracking.OrderOperation, true);

                                    // Check if there are any consumptions to report
                                    if (!consumptionLogs.IsNullOrEmpty())
                                    {
                                        ICustomERPOperationTrackingConsumptionLogCollection consumptionLogsToReport = entityFactory.CreateCollection<ICustomERPOperationTrackingConsumptionLogCollection>();
                                        consumptionLogsToReport.AddRange(consumptionLogs.Where(cl => !cl.IsReported.Value));

                                        // Group the not yet reported consumptions by product and batch
                                        var groupedLogs = consumptionLogsToReport.GroupBy(c => new { c.ProductName, c.BatchName, c.MaterialName, c.BOMSequenceNumber });

                                        // Aggregate the values by product and batch
                                        if (!groupedLogs.IsNullOrEmpty())
                                        {
                                            foreach (var log in groupedLogs)
                                            {
                                                // Communicate consumption to ERP
                                                ikeaUtilities.ReportMaterialConsumption(erpIdentifier, invetoryLocation, productionOrder.Name, log.Key.ProductName, log.Key.MaterialName, log.Key.BatchName, log.Key.BOMSequenceNumber.ToString(), log.ToList().Sum(cl => cl.Quantity).Value, customERPOperationTracking.OrderOperation, true, false, resource.Name, false);
                                            }

                                            // Set the Consumption Log as reported
                                            foreach (ICustomERPOperationTrackingConsumptionLog consumptionLog in consumptionLogsToReport)
                                            {
                                                consumptionLog.IsReported = true;
                                            }

                                            consumptionLogsToReport.Save();
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // log method exit
            long objectInstanceId = customERPOperationTracking.Id;
            long objectTypeId = customERPOperationTracking.EntityType.Id;
            Cmf.Foundation.Common.Utilities.EndMethod(objectTypeId, objectInstanceId, new KeyValuePair<String, Object>("CustomERPOperationTracking", customERPOperationTracking));
        }

        /// <summary>
        /// Get All ConsumptionLog entries of a CustomERPOperationTracking
        /// </summary>
        /// <param name="customERPOperationTracking">CustomERPOperationTracking to obtain the ConsumptionLog entries</param>
        /// <param name="loadData">Load Data?</param>
        /// <returns>All ConsumptionLog entries of the CustomERPOperationTracking</returns>
        public static ICustomERPOperationTrackingConsumptionLogCollection GetConsumptionLogs(this ICustomERPOperationTracking customERPOperationTracking, bool loadData = false)
        {
            ICustomERPOperationTrackingConsumptionLogCollection consumptionLogs = entityFactory.CreateCollection<ICustomERPOperationTrackingConsumptionLogCollection>();

            IQueryObject query = new QueryObject();
            query.Description = "";
            query.EntityTypeName = "CustomERPOperationTrackingConsumptionLog";
            query.Name = "GetCustomERPOperationTrackingConsumptionLogs";
            query.Query = new Query();
            query.Query.Distinct = false;
            query.Query.Filters = new FilterCollection() {
                new Filter()
                {
                    Name = "Id",
                    ObjectName = "CustomERPOperationTracking",
                    ObjectAlias = "CustomERPOperationTrackingConsumptionLog_CustomERPOperationTracking_2",
                    Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                    Value = customERPOperationTracking.Id,
                    LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND,
                    FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                },
                new Filter()
                {
                    Name = "UniversalState",
                    ObjectName = "CustomERPOperationTrackingConsumptionLog",
                    ObjectAlias = "CustomERPOperationTrackingConsumptionLog_1",
                    Operator = Cmf.Foundation.Common.FieldOperator.IsNotEqualTo,
                    Value = (int)Foundation.Common.Base.UniversalState.Terminated,
                    LogicalOperator = Cmf.Foundation.Common.LogicalOperator.Nothing,
                    FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                }
            };
            query.Query.Fields = new FieldCollection() {
                new Field()
                {
                    Alias = "Id",
                    ObjectName = "CustomERPOperationTrackingConsumptionLog",
                    ObjectAlias = "CustomERPOperationTrackingConsumptionLog_1",
                    IsUserAttribute = false,
                    Name = "Id",
                    Position = 0,
                    Sort = Cmf.Foundation.Common.FieldSort.NoSort
                },
                new Field()
                {
                    Alias = "Name",
                    ObjectName = "CustomERPOperationTrackingConsumptionLog",
                    ObjectAlias = "CustomERPOperationTrackingConsumptionLog_1",
                    IsUserAttribute = false,
                    Name = "Name",
                    Position = 1,
                    Sort = Cmf.Foundation.Common.FieldSort.NoSort
                }
            };
            query.Query.Relations = new RelationCollection() {
                new Relation()
                {
                    Alias = "",
                    IsRelation = false,
                    Name = "",
                    SourceEntity = "CustomERPOperationTrackingConsumptionLog",
                    SourceEntityAlias = "CustomERPOperationTrackingConsumptionLog_1",
                    SourceJoinType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.JoinType.InnerJoin,
                    SourceProperty = "CustomERPOperationTrackingId",
                    TargetEntity = "CustomERPOperationTracking",
                    TargetEntityAlias = "CustomERPOperationTrackingConsumptionLog_CustomERPOperationTracking_2",
                    TargetJoinType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.JoinType.InnerJoin,
                    TargetProperty = "Id"
                }
            };

            DataSet resultDataSet = query.Execute(false, new QueryParameterCollection());

            if (resultDataSet.HasData())
            {
                foreach (DataRow row in resultDataSet.Tables[0].Rows)
                {
                    var customERPOperationTrackingConsumptionLog = entityFactory.Create<ICustomERPOperationTrackingConsumptionLog>();
                    customERPOperationTrackingConsumptionLog.Name = row.Field<string>("Name");
                    consumptionLogs.Add(customERPOperationTrackingConsumptionLog);
                }

                if (loadData)
                {
                    consumptionLogs.Load();
                }
            }

            return consumptionLogs;

        }

        /// <summary>
        /// Update the ReportableQuantity attribute of CustomERPOperationTracking Entity
        /// </summary>
        /// <param name="customERPOperationTracking">ERP Operation Tracking to be updated</param>
        /// <param name="finishedQuantityDelta">The quantity of the Pallet being produced</param>
        /// <param name="operationDurationDelta">The duration that took the pallet to be finished</param>
        /// <param name="material">Material to update progress</param>
        private static void UpdateReportableQuantity(ICustomERPOperationTracking customERPOperationTracking, decimal finishedQuantityDelta, decimal operationDurationDelta, IMaterial material)
        {
            // Load attribute to get Order Reportable quantity
            customERPOperationTracking.LoadAttributes(new Collection<string>
                        {
                            IKEAConstants.CustomERPOperationTrackingAttributeOrderReportableQuantity
                        });

            // Change the OrderFinishedQuantity and OrderOperationDuration to the new values
            customERPOperationTracking.OrderFinishedQuantity += finishedQuantityDelta;
            customERPOperationTracking.OrderOperationDuration = (customERPOperationTracking.OrderOperationDuration.HasValue ? customERPOperationTracking.OrderOperationDuration.Value : 0) + operationDurationDelta;

            // Get Order Reportable Quantity Attribute value
            object objOrderReportableQuantity = customERPOperationTracking.GetAttributeValue(IKEAConstants.CustomERPOperationTrackingAttributeOrderReportableQuantity);
            decimal orderReportableQuantity = 0;
            if (objOrderReportableQuantity != null)
            {
                decimal.TryParse(objOrderReportableQuantity.ToString(), out orderReportableQuantity);
            }
            else
            {
                orderReportableQuantity = 0;
            }

            // Change the OrderReportableQuantity
            if (material != null)
            {
                material.Load();
                SmartTable smartTable = new SmartTable();
                smartTable.Load(IKEAConstants.CustomERPReportablePalletTypesSmartTable);

                bool? result = ikeaUtilities.ResolveCustomERPReportableTypes(smartTable, material.Facility, ikeaUtilities.GetAreaFromMaterial(material),
                material.LastProcessedResource, material.Type != null ? material.Type : null, IKEAConstants.CustomERPReportablePalletTypesCollumnOperationTracking);

                if (result.HasValue && result.Value)
                {
                    orderReportableQuantity += finishedQuantityDelta;
                }
            }
            else
            {
                orderReportableQuantity += finishedQuantityDelta;
            }

            customERPOperationTracking.Save();
            // Save Order Reportable Quantity Attribute value
            customERPOperationTracking.SaveAttributes(new AttributeCollection { { IKEAConstants.CustomERPOperationTrackingAttributeOrderReportableQuantity, orderReportableQuantity } });
            customERPOperationTracking.Load();
        }

        /// <summary>
        /// Update the Progress of the MO being tracked
        /// </summary>
        /// <param name="customERPOperationTracking">ERP Operation Tracking to be updated</param>
        /// <param name="finishedQuantityDelta">The quantity of the Pallet being produced</param>
        /// <param name="operationDurationDelta">The duration that took the pallet to be finished</param>
        /// <param name="isTerminateMaterial">Indicate whether material is terminate or not</param>
        /// <param name="material">Material to update progress</param>
        public static void UpdateProgress(this ICustomERPOperationTracking customERPOperationTracking, decimal finishedQuantityDelta, decimal operationDurationDelta, bool isTerminateMaterial = false, IMaterial material = null, CustomUpdateProgressMethodEnum methodName=00)
        {
            CustomOperationExecutionSettings res = new CustomOperationExecutionSettings();

            // Log method start
            Cmf.Foundation.Common.Utilities.StartMethod(objectTypeName, "UpdateProgress", new KeyValuePair<String, Object>("CustomERPOperationTracking", customERPOperationTracking),
                                                                    new KeyValuePair<String, Object>("FinishedQuantity", finishedQuantityDelta),
                                                                    new KeyValuePair<String, Object>("OperationDuration", operationDurationDelta),
                                                                    new KeyValuePair<String, Object>("CustomOperationExecutionSettings", res));

            // Does previous actions override this one
            if (!res.IsOverride)
            {
                if (customERPOperationTracking != null)
                {
                    IMaterial materialMO = entityFactory.Create<IMaterial>();
                    materialMO.Name = customERPOperationTracking.OrderMaterial;

                    if (materialMO.ObjectExists())
                    {
                        materialMO.Load();
                        // Get ProductionOrder from OperationTracking
                        customERPOperationTracking.LoadRelations("CustomPOERPOperationTracking");
                        IProductionOrder productionOrder = customERPOperationTracking.RelationCollection["CustomPOERPOperationTracking"].Select(ot => (ot as ICustomPOERPOperationTracking).SourceEntity).FirstOrDefault();

                        // Get Area from material:
                        IArea area = ikeaUtilities.GetAreaFromMaterial(materialMO);

                        string usedResource = customERPOperationTracking.OrderResource;
                        Dictionary<string, bool> reportOperation = ikeaUtilities.ResolveCustomERPReporting(step: materialMO.Step, facility: productionOrder.Facility, area: area, resourceName: usedResource);
                        bool isToReportPalletization = false;
                        reportOperation.TryGetValue(IKEAConstants.CustomERPReportingResolutionReportPalletizationColumn, out isToReportPalletization);
                        bool isToReportOperation = false;
                        reportOperation.TryGetValue(IKEAConstants.CustomERPReportingResolutionReportOperationColumn, out isToReportOperation);

                        Dictionary<string, string> reportAt = ikeaUtilities.ResolveCustomERPReportingReportAt(step: materialMO.Step, facility: productionOrder.Facility, area: area, resourceName: usedResource);
                        string reportPalletizationAt = "";
                        reportAt.TryGetValue(IKEAConstants.CustomERPReportingResolutionReportPalletizationAtColumn, out reportPalletizationAt);
                        string reportOperationAt = "";
                        reportAt.TryGetValue(IKEAConstants.CustomERPReportingResolutionReportOperationAtColumn, out reportOperationAt);


                        // No need to Report, When None
                        if ((isToReportPalletization == false && reportOperationAt == IKEAConstants.CustomERPReportOperationAtTrackOut && methodName == CustomUpdateProgressMethodEnum.TrackOut) ||
                            (isToReportPalletization == false && reportOperationAt == IKEAConstants.CustomERPReportOperationAtMoveNext && methodName == CustomUpdateProgressMethodEnum.MoveToNext) ||
                            (isToReportPalletization == true && reportPalletizationAt == IKEAConstants.CustomERPReportPalletizationAtTrackOut && reportOperationAt == IKEAConstants.CustomERPReportOperationAtTrackOut && methodName == CustomUpdateProgressMethodEnum.TrackOut) ||
                            (isToReportPalletization == true && reportPalletizationAt == IKEAConstants.CustomERPReportPalletizationAtTrackOut && reportOperationAt == IKEAConstants.CustomERPReportOperationAtMoveNext && methodName == CustomUpdateProgressMethodEnum.MoveToNext) ||
                            (isToReportPalletization == true && reportPalletizationAt == IKEAConstants.CustomERPReportPalletizationAtMoveNext && reportOperationAt == IKEAConstants.CustomERPReportOperationAtTrackOut && methodName == CustomUpdateProgressMethodEnum.MoveToNext) ||
                            (isToReportPalletization == true && reportPalletizationAt == IKEAConstants.CustomERPReportPalletizationAtMoveNext && reportOperationAt == IKEAConstants.CustomERPReportOperationAtMoveNext && methodName == CustomUpdateProgressMethodEnum.MoveToNext) ||
                            (isToReportPalletization == true && reportPalletizationAt == IKEAConstants.CustomERPReportPalletizationAtMoveNext && reportOperationAt == IKEAConstants.CustomERPReportOperationAtOrderAbortOrStop && methodName == CustomUpdateProgressMethodEnum.MoveToNext) ||
                            reportOperationAt != IKEAConstants.CustomERPReportOperationAtOrderAbortOrStop && methodName == CustomUpdateProgressMethodEnum.Terminate ||
                            reportOperationAt != IKEAConstants.CustomERPReportOperationAtOrderAbortOrStop && methodName == CustomUpdateProgressMethodEnum.ChangeType
                            )
                        {
                            UpdateReportableQuantity(customERPOperationTracking, finishedQuantityDelta, operationDurationDelta, material);

                            if (isToReportOperation == true)
                            {
                                decimal quantity = 0;

                                if (methodName == CustomUpdateProgressMethodEnum.MoveToNext) // During MoveNext
                                {
                                    // Update OrderScheduledQuantity as OrderFinishedQuantity, to force ReportOperation
                                    customERPOperationTracking.OrderScheduledQuantity = customERPOperationTracking.OrderFinishedQuantity;
                                    customERPOperationTracking.Save();
                                    customERPOperationTracking.Load();

                                    quantity = 0;
                                }
                                else
                                {
                                    // Set as negative so that it can be removed
                                    quantity = -materialMO.PrimaryQuantity.Value;
                                    if (materialMO.SystemState == MaterialSystemState.Dispatched)
                                    {
                                        quantity = 0; // Set Quantity as Zero because aborted material quantity already updated in HandleAbortMaterial service
                                    }
                                }

                                // Report Operation
                                customERPOperationTracking.UpdateScheduledQuantity(quantity, true);

                                if (materialMO.SystemState == MaterialSystemState.InProcess && ((isToReportPalletization == true && reportPalletizationAt == IKEAConstants.CustomERPReportPalletizationAtTrackOut) || isToReportPalletization == false)) // create a new ERPOperationTracking
                                {
                                    var materialCollection = entityFactory.CreateCollection<IMaterialCollection>();
                                    materialCollection.Add(materialMO);
                                    CustomERPOperationTrackingEngine.HandleMaterialTrackIn(materialCollection, materialMO.PrimaryQuantity.Value);
                                }
                            }
                        }
                        // Report, When OrderAbortOrStop
                        else if ((isToReportPalletization == false && reportOperationAt == IKEAConstants.CustomERPReportOperationAtOrderAbortOrStop && methodName == CustomUpdateProgressMethodEnum.TrackOut) ||
                            (isToReportPalletization == true && reportPalletizationAt == IKEAConstants.CustomERPReportPalletizationAtTrackOut && reportOperationAt == IKEAConstants.CustomERPReportOperationAtOrderAbortOrStop && methodName == CustomUpdateProgressMethodEnum.TrackOut) ||
                            reportOperationAt == IKEAConstants.CustomERPReportOperationAtOrderAbortOrStop && methodName == CustomUpdateProgressMethodEnum.Terminate ||
                            reportOperationAt == IKEAConstants.CustomERPReportOperationAtOrderAbortOrStop && methodName == CustomUpdateProgressMethodEnum.ChangeType)
                        {
                            UpdateReportableQuantity(customERPOperationTracking, finishedQuantityDelta, operationDurationDelta, material);

                            if (isToReportOperation == true)
                            {
                                // Check if the finished quantity already reached the scheduled quantity
                                if (EvaluateReportConsumption(customERPOperationTracking.OrderMaterial, customERPOperationTracking.OrderRunNumber.Value, customERPOperationTracking.OrderOperation))
                                {
                                    // Report Operation
                                    EvaluateReportOperation(customERPOperationTracking.OrderMaterial, customERPOperationTracking.OrderRunNumber.Value, customERPOperationTracking.OrderOperation);

                                    customERPOperationTracking.Load();
                                    // Update the OperationEnd
                                    customERPOperationTracking.OrderOperationEnd = DateTime.Now;

                                    customERPOperationTracking.Save();
                                }
                            }
                        }
                        else if (reportOperationAt == IKEAConstants.CustomERPReportOperationAtNone && methodName == CustomUpdateProgressMethodEnum.TrackOut) //Update reportable quantity only on TrackOut
                        {
                            UpdateReportableQuantity(customERPOperationTracking, finishedQuantityDelta, operationDurationDelta, material);
                        }

                        // If ReportPalletization configured as MoveNext, Create new ERPOperationTracking in TrackOut, so that operation reporting works correctly
                        if ((isToReportPalletization == true && reportPalletizationAt == IKEAConstants.CustomERPReportPalletizationAtMoveNext && methodName == CustomUpdateProgressMethodEnum.TrackOut))
                        {
                            if (materialMO.SystemState == MaterialSystemState.InProcess) // create a new ERPOperationTracking
                            {
                                var materialCollection = entityFactory.CreateCollection<IMaterialCollection>();
                                materialCollection.Add(materialMO);
                                CustomERPOperationTrackingEngine.HandleMaterialTrackIn(materialCollection, materialMO.PrimaryQuantity.Value);
                            }
                        }
                    }
                }
            }

            // log method exit
            long objectInstanceId = customERPOperationTracking.Id;
            long objectTypeId = customERPOperationTracking.EntityType.Id;
            Cmf.Foundation.Common.Utilities.EndMethod(objectTypeId, objectInstanceId, new KeyValuePair<String, Object>("CustomERPOperationTracking", customERPOperationTracking));
        }

        /// <summary>
        /// Update the Scheduled quantity of the ERP Operation Tracking
        /// </summary>
        /// <param name="customERPOperationTracking">ERP Operation Tracking to be updated</param>
        /// <param name="scheduledQuantityDelta">The delta scheduled quantity to add or remove (the value should be negative in the case we want to remove)</param>
        public static void UpdateScheduledQuantity(this ICustomERPOperationTracking customERPOperationTracking, decimal scheduledQuantityDelta, bool terminateOnZeroQuantity)
        {
            CustomOperationExecutionSettings res = new CustomOperationExecutionSettings();

            // Log method start
            Cmf.Foundation.Common.Utilities.StartMethod(objectTypeName, "UpdateScheduledQuantity", new KeyValuePair<String, Object>("CustomERPOperationTracking", customERPOperationTracking),
                                                                                new KeyValuePair<String, Object>("ScheduledQuantity", scheduledQuantityDelta),
                                                                                new KeyValuePair<String, Object>("CustomOperationExecutionSettings", res));

            // Does previous actions override this one
            if (!res.IsOverride)
            {
                if (customERPOperationTracking != null)
                {
                    // Update the OrderScheduledQuantity and OrderOperationDuration to the new values
                    // if the value is positive, it will be added, if negative, it will be removed
                    decimal previousOrderScheduledQuantity = customERPOperationTracking.OrderScheduledQuantity.GetValueOrDefault();
                    customERPOperationTracking.OrderScheduledQuantity += scheduledQuantityDelta;
                    customERPOperationTracking.Save();
                    customERPOperationTracking.Load();

                    if (customERPOperationTracking.OrderFinishedQuantity > 0 || customERPOperationTracking.OrderScheduledQuantity > 0)
                    {
                        // Check if the finished quantity already reached the scheduled quantity
                        if (EvaluateReportConsumption(customERPOperationTracking.OrderMaterial, customERPOperationTracking.OrderRunNumber.Value, customERPOperationTracking.OrderOperation))
                        {
                            customERPOperationTracking.LoadAttributes();
                            object objOrderReportableQuantity = customERPOperationTracking.GetAttributeValue(IKEAConstants.CustomERPOperationTrackingAttributeOrderReportableQuantity);
                            decimal orderReportableQuantity = 0;
                            if (objOrderReportableQuantity != null)
                            {
                                decimal.TryParse(objOrderReportableQuantity.ToString(), out orderReportableQuantity);
                            }
                            else
                            { orderReportableQuantity = 0; }

                            // only report operation if scheduled quantity was above reportable quantity to not re report for exceptions (materials that became untrackable but came back to a tracking state)
                            // equal condition was added to prevent last pallet reporting
                            if (previousOrderScheduledQuantity >= orderReportableQuantity)
                            {
                                // Report Operation
                                EvaluateReportOperation(customERPOperationTracking.OrderMaterial, customERPOperationTracking.OrderRunNumber.Value, customERPOperationTracking.OrderOperation);
                            }

                            customERPOperationTracking.Load();

                            // Update the OperationEnd
                            customERPOperationTracking.OrderOperationEnd = DateTime.Now;
                            customERPOperationTracking.Save();
                        }

                    }
                    else if (customERPOperationTracking.OrderFinishedQuantity == 0
                               && customERPOperationTracking.OrderScheduledQuantity == 0)
                    {

                        // Save the new OrderScheduledQuantity before continuing
                        customERPOperationTracking.Save();

                        if (terminateOnZeroQuantity)
                        {
                            customERPOperationTracking.LoadRelations("CustomPOERPOperationTracking");

                            // Terminate the relations
                            if (customERPOperationTracking.HasRelations("CustomPOERPOperationTracking"))
                            {
                                ICustomPOERPOperationTrackingCollection operationTrackings = entityFactory.CreateCollection<ICustomPOERPOperationTrackingCollection>();
                                operationTrackings.AddRange(customERPOperationTracking.RelationCollection["CustomPOERPOperationTracking"].Select(ot => ot as ICustomPOERPOperationTracking));

                                operationTrackings.Terminate();
                            }

                            // Get all ConsumptionLogs and terminate them > Necessary because they prevent CustomPOERPOperationTracking from being terminated
                            ICustomERPOperationTrackingConsumptionLogCollection consumptionLogs = CustomERPOperationTrackingEngine.GetAllConsumptionLogsForMO(customERPOperationTracking.OrderMaterial, customERPOperationTracking.OrderRunNumber.Value, customERPOperationTracking.OrderOperation, true);
                            consumptionLogs.Terminate();

                            // If both finished and scheduled quantities are 0 then the ERPOperationTracking can be terminated
                            customERPOperationTracking.Terminate();
                        }
                    }
                }
            }

            // log method exit
            long objectInstanceId = customERPOperationTracking.Id;
            long objectTypeId = customERPOperationTracking.EntityType.Id;
            Cmf.Foundation.Common.Utilities.EndMethod(objectTypeId, objectInstanceId, new KeyValuePair<String, Object>("CustomERPOperationTracking", customERPOperationTracking));
        }

        /// <summary>
        /// Report Consumption to ERP
        /// </summary>
        /// <param name="customERPOperationTracking">ERP Operation Tracking to be reported</param>
        public static void LogConsumption(this ICustomERPOperationTracking customERPOperationTracking, IMaterial assembledMaterial, CustomBOMConsumptionInformationCollection consumedMaterialsData)
        {
            CustomOperationExecutionSettings res = new CustomOperationExecutionSettings();

            // Log method start
            Cmf.Foundation.Common.Utilities.StartMethod(objectTypeName, "LogConsumption", new KeyValuePair<String, Object>("CustomERPOperationTracking", customERPOperationTracking),
                                                                    new KeyValuePair<String, Object>("AssembledMaterial", assembledMaterial),
                                                                    new KeyValuePair<String, Object>("ConsumedMaterialData", consumedMaterialsData),
                                                                    new KeyValuePair<String, Object>("CustomOperationExecutionSettings", res));

            // Does previous actions override this one
            if (!res.IsOverride)
            {
                // Get the CustomERPOperationTracking from the MO
                customERPOperationTracking = assembledMaterial.GetCurrentCustomERPOperatingTracking(false);

                if (customERPOperationTracking != null)
                {
                    ICustomERPOperationTrackingConsumptionLogCollection consumptionLogs = entityFactory.CreateCollection<ICustomERPOperationTrackingConsumptionLogCollection>();

                    // Load the material attribute IsReported
                    Dictionary<IMaterial, decimal> materialQuantities = new Dictionary<IMaterial, decimal>();
                    Dictionary<IMaterial, string> materialBOMSequenceNumber = new Dictionary<IMaterial, string>();
                    IMaterialCollection materials = entityFactory.CreateCollection<IMaterialCollection>();

                    //Get ReRun and DirectRepair Material types
                    string reRunMaterialType = genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.CustomReRunMaterialDefaultTypePath);
                    string directRepairMaterialType = genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.CustomDirectRepairMaterialDefaultTypePath);

                    if (!consumedMaterialsData.IsNullOrEmpty())
                    {
                        foreach (CustomBOMConsumptionInformation consumedMaterialData in consumedMaterialsData)
                        {
                            foreach (var materialsAttached in consumedMaterialData.MaterialsToConsume.Where(E => !E.Key.Type.CompareStrings(reRunMaterialType) && !E.Key.Type.CompareStrings(directRepairMaterialType)))
                            {
                                materialQuantities[materialsAttached.Key] = materialsAttached.Value;
                                materialBOMSequenceNumber[materialsAttached.Key] = consumedMaterialData.ERPBOMOperationSequence;
                                materials.Add(materialsAttached.Key);
                            }
                        }
                    }
                    materials.LoadAttributes(new Collection<string>() { IKEAConstants.CustomMaterialAttributeIsReported, IKEAConstants.CustomSourceConsumptionMaterial });

                    // Get all the product ids of the not yet reported materials being consumed
                    Dictionary<IMaterial, long> materialProducts = materials.ToDictionary(m => m, m => m.GetNativeValue<long>(Navigo.Common.Constants.Product));

                    // Load the ERPConsumptionReporting attribute for all products
                    IProductCollection products = entityFactory.CreateCollection<IProductCollection>();
                    products.LoadByIDs<IProduct, Product>(materialProducts.Values.Distinct().ToList());

                    string sampleTestingTypeName = genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.MaterialTypeSampleTestingConfig);

                    // Get resources where the materials were attached
                    Dictionary<long, long> materialResource = ApplicationContext.CallContext.GetInformationContext("CustomPerformAutomaticAssemble_ConsumedMaterialResources") as Dictionary<long, long>;

                    Dictionary<long, string> feeders = new Dictionary<long, string>();

                    // Check if there are any resources defined
                    if (!materialResource.IsNullOrEmpty())
                    {
                        // Load the resources
                        IResourceCollection resources = entityFactory.CreateCollection<IResourceCollection>();
                        resources.Load(new Collection<long>(materialResource.Values.ToList()));

                        // Get dictionary with Id and name of the resource
                        feeders = resources.ToDictionary(r => r.Id, r => r.Name);
                    }

                    foreach (IMaterial material in materials)
                    {
                        // Get the Source consumption material from attribute if exists:
                        string sourceConsumptionMaterial = material.GetAttributeValueOrDefault<string>(IKEAConstants.CustomSourceConsumptionMaterial);

                        // Check if the assembled material is not of type 'SampleTesting':
                        if (sampleTestingTypeName.IsNullOrEmpty() || !material.Type.Equals(sampleTestingTypeName, StringComparison.InvariantCultureIgnoreCase))
                        {

                            // Get the batch material of the consumable
                            IMaterial batch = material.GetMaterialParentBatch();

                            // Product of the material being consumed
                            IProduct product = products.Where(p => p.DefinitionId == material.GetNativeValue<long>(Navigo.Common.Constants.Product)).FirstOrDefault();

                            // Get the product name of the material being consumed
                            string productName = product.Name;

                            // Get Product default units
                            string productUnits = product.DefaultUnits;

                            // Get the quantity of the material being consumed
                            decimal quantity = materialQuantities.Where(mc => mc.Key.Id == material.Id).Select(mc => mc.Value).FirstOrDefault();

                            // Get the quantity of the material being consumed
                            string bomSequenceNumber = materialBOMSequenceNumber.Where(mc => mc.Key.Id == material.Id).Select(mc => mc.Value).FirstOrDefault();

                            // Create the consumption log
                            ICustomERPOperationTrackingConsumptionLog consumptionLog = entityFactory.Create<ICustomERPOperationTrackingConsumptionLog>();
                            consumptionLog.Name = String.Format("{0}.{1}.{2}", customERPOperationTracking.Name, assembledMaterial.Name, material.Name);
                            consumptionLog.CustomERPOperationTracking = customERPOperationTracking;
                            consumptionLog.BatchName = batch?.Name;
                            consumptionLog.ProductName = productName;
                            consumptionLog.MaterialName = sourceConsumptionMaterial.IsNullOrEmpty() ? material.Name : sourceConsumptionMaterial;
                            consumptionLog.Quantity = quantity;
                            int bomSequence = 0;
                            Int32.TryParse(bomSequenceNumber, out bomSequence);
                            consumptionLog.BOMSequenceNumber = bomSequence;
                            consumptionLog.Units = productUnits;
                            consumptionLog.IsReported = material.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomMaterialAttributeIsReported);

                            // Set Consumption Resource
                            if (materialResource.ContainsKey(material.Id))
                            {
                                consumptionLog.Attributes[IKEAConstants.CustomConsumptionLogAttributeConsumptionResource] = feeders[materialResource[material.Id]];
                            }

                            consumptionLogs.Add(consumptionLog);
                        }
                    }

                    // Save the consumption log in the data base
                    if (!consumptionLogs.IsNullOrEmpty())
                    {
                        consumptionLogs.Create();
                    }
                }
            }

            // log method exit
            long objectInstanceId = customERPOperationTracking.Id;
            long objectTypeId = customERPOperationTracking.EntityType.Id;
            Cmf.Foundation.Common.Utilities.EndMethod(objectTypeId, objectInstanceId, new KeyValuePair<String, Object>("CustomERPOperationTracking", customERPOperationTracking));
        }

        /// <summary>
        /// Report Operation to ERP
        /// </summary>
        /// <param name="customERPOperationTracking">ERP Operation Tracking to be reported</param>
        public static void ReportOperation(this ICustomERPOperationTracking customERPOperationTracking, decimal quantityToReport, IProductionOrder productionOrder = null, bool isOperationClosure = false)
        {
            CustomOperationExecutionSettings res = new CustomOperationExecutionSettings();

            // Log method start
            Cmf.Foundation.Common.Utilities.StartMethod(objectTypeName, "ReportOperation", new KeyValuePair<String, Object>("CustomERPOperationTracking", customERPOperationTracking),
                                                                        new KeyValuePair<String, Object>("CustomOperationExecutionSettings", res));

            // Does previous actions override this one
            if (!res.IsOverride)
            {
                if (customERPOperationTracking != null)
                {
                    // Get Production Order
                    if (productionOrder == null)
                    {
                        customERPOperationTracking.LoadRelations("CustomPOERPOperationTracking");
                        productionOrder = customERPOperationTracking.RelationCollection["CustomPOERPOperationTracking"].Select(ot => (ot as ICustomPOERPOperationTracking).SourceEntity).FirstOrDefault();
                    }

                    // Load Product Attributes
                    productionOrder.Product.LoadAttributes(new Collection<string>
                    {
                        IKEAConstants.CustomProductAttributeBaseProduct,
                        IKEAConstants.CustomProductAttributeDecimalPlaces
                    });

                    // Get Facility ERP identifier
                    string erpIdentifier = productionOrder.Facility.GetAttributeValueOrDefault<string>(IKEAConstants.CustomFacilityAttributeERPIdentifier, true);

                    // Get Base Product
                    string baseProduct = productionOrder.Product.GetRelatedAttributeValueOrDefault<string>(IKEAConstants.CustomProductAttributeBaseProduct);

                    // Get Product Decimal Places
                    int? decimalPlaces = productionOrder.Product.GetRelatedAttributeValueOrDefault<int?>(IKEAConstants.CustomProductAttributeDecimalPlaces);

                    // Get override ERP operation code (short structures only!)
                    string erpOperationCodeOverride = productionOrder.GetAttributeValueOrDefault<string>("ERPOperationCodeOverride", true);

                    string usedResource = customERPOperationTracking.OrderResource;
                    string originalResource = string.Empty;

                    // Defaults reporting to ERP to false:
                    bool automaticReportingOperation = false;

                    // Default report operation when to send to ERP
                    string reportOperationAt = IKEAConstants.CustomERPReportOperationAtNone;

                    // Try to get the Order material (MO) from the OperationTracking:
                    IMaterial materialMO = entityFactory.Create<IMaterial>();
                    materialMO.Name = customERPOperationTracking.OrderMaterial;
                    if (materialMO.ObjectExists())
                    {
                        materialMO.Load();
                        bool isOrderless = materialMO.GetAttributeValueOrDefault(IKEAConstants.CustomMaterialIsOrderlessAttribute, defaultValue: false, loadAttribute: true);

                        // Do not report operations on Orderless MOs (report just Consumption and Palletization)
                        if (!isOrderless)
                        {
                            // Get Area from material:
                            IArea area = ikeaUtilities.GetAreaFromMaterial(materialMO);

                            // Resolve automatic Reporting to ERP:
                            ikeaUtilities.ResolveCustomERPReporting(step: materialMO.Step, facility: productionOrder.Facility, area: area, resourceName: usedResource).TryGetValue(IKEAConstants.CustomERPReportingResolutionReportOperationColumn, out automaticReportingOperation);

                            Dictionary<string, string> reportAt = ikeaUtilities.ResolveCustomERPReportingReportAt(step: materialMO.Step, facility: productionOrder.Facility, area: area, resourceName: usedResource);
                            reportAt.TryGetValue(IKEAConstants.CustomERPReportingResolutionReportOperationAtColumn, out reportOperationAt);

                        }
                    }

                    // If the automatic reporting to ERP is resolved to True & reportOperationAt to ERP is resolved to None in the SmartTable
                    if (automaticReportingOperation && reportOperationAt != IKEAConstants.CustomERPReportOperationAtNone)
                    {

                        // Check if it is the original value
                        if (customERPOperationTracking.IsOriginal.Value)
                        {
                            originalResource = customERPOperationTracking.OrderResource;
                        }
                        else
                        {
                            // Get the original tracking
                            ICustomERPOperationTracking customERPOperationTrackingOriginal = GetCustomERPOperatingTracking(customERPOperationTracking.OrderMaterial,
                                                                                                                            customERPOperationTracking.OrderRunNumber.Value,
                                                                                                                            customERPOperationTracking.OrderOperation);

                            originalResource = customERPOperationTrackingOriginal.OrderResource;
                        }

                        string resource = usedResource.CompareStrings(originalResource) ? string.Empty : usedResource;

                        // For ReRoutes, try to get the OriginalResourceToReport 
                        productionOrder.LoadRelations(IKEAConstants.CustomPOOperationResource);
                        if (productionOrder.HasRelations(IKEAConstants.CustomPOOperationResource))
                        {
                            ICustomPOOperationResource poOperationResources = productionOrder.RelationCollection[IKEAConstants.CustomPOOperationResource]
                                .Select(pr => pr as ICustomPOOperationResource)
                                .Where(pr => pr.TargetEntity.Name == customERPOperationTracking.OrderResource).FirstOrDefault();

                            if (poOperationResources != null && string.IsNullOrWhiteSpace(poOperationResources.OriginalResourceToReport))
                            {
                                originalResource = poOperationResources.OriginalResourceToReport;
                            }
                        }

                        // Only round the value if the product has the Decimal Places attribute set
                        decimal quantityToReportRounded = decimalPlaces != null
                            ? decimal.Round(quantityToReport, decimalPlaces.Value)
                            : quantityToReport;

                        string LanguageERP = genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.LanguageERP);
                        OrderMaterialCompletion orderMaterialCompletion = new OrderMaterialCompletion()
                        {
                            Facility = erpIdentifier,
                            ProductionNumber = !string.IsNullOrWhiteSpace(baseProduct) ? baseProduct : productionOrder.Product.Name,
                            ManualCompletionFlag = isOperationClosure ? "1" : "0",
                            ManufacturingOrderNumber = productionOrder.Name,
                            ERPOperation = erpOperationCodeOverride,
                            ReportingDate = DateTime.Now.ToString("yyyyMMdd"),
                            ManufacturedQuantity = isOperationClosure ? string.Empty : quantityToReportRounded.ToString("G", !String.IsNullOrEmpty(LanguageERP) ? System.Globalization.CultureInfo.CreateSpecificCulture(LanguageERP) : System.Globalization.CultureInfo.InvariantCulture),
                            ManufacturingUnitsOfMesurement = productionOrder.Units,
                            Resource = string.Empty,
                            TransactionTime = DateTime.Now.ToString("HHmmss").TrimStart('0'),
                            DeviatingWorkcenter = isOperationClosure ? string.Empty : usedResource
                        };

                        // Get Json file
                        string json = JsonConvert.SerializeObject(orderMaterialCompletion);

                        MESERPCommunication communication = new MESERPCommunication
                        {
                            API = IKEAConstants.ERPReportOrderOperation,
                            Message = json
                        };

                        // Serialize the object to a XML Document
                        XmlDocument xmlDoc = communication.SerializeToXMLDocument();

                        // Create the Integration Entry
                        ikeaUtilities.CreateIntegrationEntry(IKEAConstants.MESSystem,
                                                               IKEAConstants.ERPSystem,
                                                               IKEAConstants.ERPConsumptionOrderOperationMessageType,
                                                               IKEAConstants.ERPConsumptionOrderOperationEventName,
                                                               xmlDoc);

                        // Reset the operation duration
                        customERPOperationTracking.OrderOperationDuration = 0;
                        customERPOperationTracking.Save();
                    }
                }
            }

            // log method exit
            long objectInstanceId = customERPOperationTracking.Id;
            long objectTypeId = customERPOperationTracking.EntityType.Id;
            Cmf.Foundation.Common.Utilities.EndMethod(objectTypeId, objectInstanceId, new KeyValuePair<String, Object>("CustomERPOperationTracking", customERPOperationTracking));
        }

        #endregion

        #region CustomERPOperationTrackingCollection

        /// <summary>
        /// Terminate All CustomERPOperationTracking in a collection and its Consumption Logs
        /// </summary>
        /// <param name="erpOperationTrackings">CustomERPOperationTracking Collection</param>
        public static void TerminateAllCustomERPOperationTracking(this ICustomERPOperationTrackingCollection erpOperationTrackings, Dictionary<IProductionOrder, List<long>> poERPOperationTrackingIds, Dictionary<long, List<ICustomPOOperationResource>> poOperationResources)
        {
            ICustomERPOperationTrackingConsumptionLogCollection consumptionLogs = entityFactory.CreateCollection<ICustomERPOperationTrackingConsumptionLogCollection>();

            // Report the consumptions that haven't been reported yet
            foreach (ICustomERPOperationTracking erpOperationTracking in erpOperationTrackings)
            {
                IProductionOrder productionOrder = poERPOperationTrackingIds.Where(x => x.Value.Contains(erpOperationTracking.Id)).FirstOrDefault().Key;

                ICustomPOOperationResourceCollection operationResources = null;

                if (poOperationResources != null && poOperationResources.ContainsKey(productionOrder.Id))
                {
                    operationResources = entityFactory.CreateCollection<ICustomPOOperationResourceCollection>();
                    operationResources.AddRange(poOperationResources[productionOrder.Id]);
                    operationResources.Load();
                }

                erpOperationTracking.ReportConsumption(productionOrder, operationResources);

                consumptionLogs.AddRange(erpOperationTracking.GetConsumptionLogs());
            }

            // If there are any consumption logs to terminate, terminate them
            if (!consumptionLogs.IsNullOrEmpty())
            {
                consumptionLogs.Load();
                consumptionLogs.Terminate();
            }

            // Terminate all the CustomERPOperationTracking
            erpOperationTrackings.Terminate();
        }

        #endregion
    }
}
