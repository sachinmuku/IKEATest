﻿using Cmf.Navigo.BusinessObjects;
using System;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessObjects.Abstractions;
using System.Collections.ObjectModel;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Foundation.Common;
using Microsoft.Extensions.DependencyInjection;
using Cmf.Common.CustomActionUtilities;

namespace Cmf.Custom.IKEA.Common.Extensions
{
    public static class ProductExtensions
    {
        private static IEntityFactory entityFactory => ApplicationContext.CurrentServiceProvider.GetService<IEntityFactory>();

        /// <summary>
        /// Retrieves a Product's base product if existing
        /// </summary>
        /// <param name="product">Product instance for which base product will be obtained</param>
        /// <returns>Base product instance if obtained, self if not base product exists</returns>
        public static IProduct GetBaseProduct(this IProduct product)
        {
            IProduct returnProduct = product;

            if (product != null)
            {
                product.LoadAttributes(new Collection<string>() { IKEAConstants.CustomProductAttributeBaseProduct });

                string baseProduct = product.GetRelatedAttributeValueOrDefault<string>(IKEAConstants.CustomProductAttributeBaseProduct);
                if (!String.IsNullOrWhiteSpace(baseProduct) && !String.Equals(product.Name, baseProduct, StringComparison.InvariantCultureIgnoreCase))
                {
                    returnProduct = entityFactory.Create<IProduct>();
                    returnProduct.Load(baseProduct);
                }
            }

            return returnProduct;
        }
    }
}
