﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Custom.IKEA.BusinessObjects;
using Cmf.Foundation.BusinessObjects;
using Cmf.Navigo.BusinessObjects;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using Cmf.Custom.IKEA.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Navigo.BusinessOrchestration.Abstractions;
using Microsoft.Extensions.DependencyInjection;

namespace Cmf.Custom.IKEA.Common.Extensions
{
    public static partial class CustomERPOperationTrackingEngine
    {
        public static void HandleMaterialTrackIn(IMaterialCollection materials, decimal? scheduleQuantity = null)
        {
            string orderForm = ikeaUtilities.GetOrderMaterialForm();

            // Load the run attribute of all materials
            materials.LoadAttributes(new Collection<string>() { IKEAConstants.CustomMaterialAttributeOrderRunNumber });

            Dictionary<IMaterial, IAttributeCollection> materialAttributes = new Dictionary<IMaterial, IAttributeCollection>();

            DateTime dateStart = DateTime.Now;

            Dictionary<IProductionOrder, ICustomERPOperationTrackingCollection> productionOrderOperationTrackings = new Dictionary<IProductionOrder, ICustomERPOperationTrackingCollection>();

            // Load all the production orders of all the materials
            IProductionOrderCollection materialProductionOrders = entityFactory.CreateCollection<IProductionOrderCollection>(); ;
            materialProductionOrders.LoadByIDs<IProductionOrder, ProductionOrder>(materials.Select(m => m.GetNativeValue<long>(Navigo.Common.Constants.ProductionOrder)).ToList());

            // Load all the CustomPOOperationResource relations
            materialProductionOrders.LoadRelations(IKEAConstants.CustomPOOperationResource);

            List<long> productionOrdersOperationResources = materialProductionOrders.Where(po => po.HasRelations(IKEAConstants.CustomPOOperationResource))
                                                                                                .SelectMany(po => po.RelationCollection[IKEAConstants.CustomPOOperationResource].Select(x => (x as ICustomPOOperationResource).GetNativeValue<long>("TargetEntity")))
                                                                                                .ToList();

            IResourceCollection operationResources = entityFactory.CreateCollection<IResourceCollection>();
            operationResources.LoadByIDs<IResource, Resource>(productionOrdersOperationResources);

            if (!operationResources.IsNullOrEmpty() && !materialProductionOrders.IsNullOrEmpty())
            {
                foreach (IMaterial material in materials)
                {
                    IAttributeCollection attributes = new AttributeCollection();
                    ICustomERPOperationTrackingCollection operationTrackings = entityFactory.CreateCollection<ICustomERPOperationTrackingCollection>();

                    // Check if the material has the Order Form
                    if (material.Form.CompareStrings(orderForm))
                    {
                        // Get the Run number of the materials and add one
                        int runNumber = material.GetAttributeValueOrDefault<int>(IKEAConstants.CustomMaterialAttributeOrderRunNumber) + 1;
                        attributes[IKEAConstants.CustomMaterialAttributeOrderRunNumber] = runNumber;

                        // Get all the ERP Operation Codes of the main flow of the material
                        IFlowCollection flows = genericUtilities.GetFlowsInFlowPath(material.FlowPath, true);
                        List<string> erpOperationCodes = flows[0].GetAllERPOperationCodesFromSubsFlows();

                        int sequence = 0;

                        if (!erpOperationCodes.IsNullOrEmpty())
                        {
                            IProductionOrder productionOrder = materialProductionOrders.Where(mp => mp.Id == material.GetNativeValue<long>(Navigo.Common.Constants.ProductionOrder)).FirstOrDefault();

                            if (productionOrder != null && productionOrder.HasRelations(IKEAConstants.CustomPOOperationResource))
                            {
                                // Get all the ERP operation codes from the PO
                                Dictionary<string, long> operationCodes = productionOrder.RelationCollection[IKEAConstants.CustomPOOperationResource].Select(x => (x as ICustomPOOperationResource))
                                                                                                                                                        .ToDictionary(x => x.OperationCode, x => x.GetNativeValue<long>("TargetEntity"));

                                foreach (string operationCode in erpOperationCodes.Distinct().Intersect(operationCodes.Keys))
                                {
                                    IResource resource = sequence == 0 ? material.LastProcessedResource : operationResources.Where(r => r.Id == operationCodes[operationCode]).FirstOrDefault();

                                    if (resource != null)
                                    {
                                        // Initialize a new ERP Operation Tracking
                                        var customERPOperationTracking = entityFactory.Create<ICustomERPOperationTracking>();
                                        customERPOperationTracking.Name = String.Format("{0}.{1}.{2}.{3}", material.Name, runNumber, operationCode, resource.Name);
                                        customERPOperationTracking.OrderOperationStart = dateStart;
                                        customERPOperationTracking.OrderOperationSequence = sequence;
                                        customERPOperationTracking.OrderOperation = operationCode;
                                        customERPOperationTracking.OrderMaterial = material.Name;
                                        customERPOperationTracking.OrderFinishedQuantity = 0;
                                        customERPOperationTracking.OrderRunNumber = runNumber;
                                        customERPOperationTracking.OrderScheduledQuantity = scheduleQuantity ?? material.PrimaryQuantity;
                                        customERPOperationTracking.OrderResource = resource.Name;
                                        customERPOperationTracking.IsOriginal = true;
                                        operationTrackings.Add(customERPOperationTracking);

                                        sequence++;
                                    }
                                }

                                productionOrderOperationTrackings.Add(productionOrder, operationTrackings);
                            }

                        }
                    }
                    else
                    {
                        // Get the CustomERPOperationTracking not considered original for the resource
                        ICustomERPOperationTracking currentOperationTracking = material.GetCurrentCustomERPOperatingTracking(true);

                        // Check if the current operation tracking is not the original
                        if (!currentOperationTracking.IsOriginal.Value)
                        {
                            // Get the CustomERPOperationTracking marked as original
                            ICustomERPOperationTracking originalOperationTracking = material.GetOriginalCustomERPOperatingTracking();
                            // Transfer scheduled quantity from source to target
                            originalOperationTracking.TransferTo(currentOperationTracking, material.PrimaryQuantity.Value);
                        }
                    }

                    // Get the ERP Operation Code from the current material flow
                    IFlow flow = material.GetCurrentFlow();
                    string erpOperationCode = flow.GetERPOperationCode();

                    // Set the Internal track in date
                    attributes[IKEAConstants.CustomMaterialAttributeInternalTrackInDate] = DateTime.Now;

                    if (!string.IsNullOrWhiteSpace(erpOperationCode))
                    {
                        // Set the last known ERP operation of the material
                        attributes[IKEAConstants.CustomMaterialAttributeLastKnownERPOperation] = erpOperationCode;
                    }

                    materialAttributes[material] = attributes;
                }
            }

            if (!materialAttributes.IsNullOrEmpty())
            {
                // Set all the attributes of the materials
                ikeaUtilities.SaveAttributesToMultipleMaterials(materialAttributes);
            }

            ICustomERPOperationTrackingCollection poOperationTrackings = entityFactory.CreateCollection<ICustomERPOperationTrackingCollection>();
            poOperationTrackings.AddRange(productionOrderOperationTrackings.SelectMany(p => p.Value));

            // Create all the ERPOperationTracking and the relation to the POs
            if (!poOperationTrackings.IsNullOrEmpty())
            {
                poOperationTrackings.Create();

                poOperationTrackings.Load();

                ICustomPOERPOperationTrackingCollection poERPOperationTracking = entityFactory.CreateCollection<ICustomPOERPOperationTrackingCollection>();

                foreach (var poOperationTraking in productionOrderOperationTrackings)
                {
                    poERPOperationTracking.AddRange(poOperationTraking.Value.Select(ot =>
                    {
                        var customPOERPOperationTracking = entityFactory.Create<ICustomPOERPOperationTracking>();
                        customPOERPOperationTracking.SourceEntity = poOperationTraking.Key;
                        customPOERPOperationTracking.TargetEntity = poOperationTrackings.Where(o => o.Name == ot.Name).FirstOrDefault();
                        return customPOERPOperationTracking;
                    }));
                }

                poERPOperationTracking.Create();
            }
        }
    }
}
