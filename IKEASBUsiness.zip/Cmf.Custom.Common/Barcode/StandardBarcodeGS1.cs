﻿using Cmf.Custom.IKEA.Common.Exceptions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cmf.Common.CustomActionUtilities;
using Cmf.Custom.IKEA.Common.Abstractions;
using Microsoft.Extensions.DependencyInjection;

namespace Cmf.Custom.IKEA.Common.Barcode
{
    public class StandardBarcodeGS1 : IStandardBarcode
    {
        private static IIKEAUtilities ikeaUtilities => ApplicationContext.CurrentServiceProvider.GetService<IIKEAUtilities>();


        /// <summary>
        /// Extract Barcode Information For GS1-128
        /// </summary>
        /// <param name="barcodeString">Barcode</param>
        /// <param name="scanningConfiguration">Scanning Configuration</param>
        /// <param name="tokens">Tokens</param>
        /// <returns>Dictionary with the Barcode Information</returns>
        public Dictionary<string, string> ExtractBarcodeInformation(string barcodeString,
                                                                        CustomScanningConfiguration scanningConfiguration,
                                                                        List<CustomScanningConfigurationToken> tokens)
        {
            Dictionary<string, string> barcodeInformation = null;

            char separator;

            if(!string.IsNullOrWhiteSpace(scanningConfiguration.Separator))
            {
                int charCode;
                // Try to convert the separator value into a valid Char Code
                if(int.TryParse(scanningConfiguration.Separator, out charCode))
                {
                    // Get the char based on its ASCII code
                    separator = (char)charCode;
                }
                else
                {
                    throw new CustomBarcodeWrongSeparatorCharCodeException();
                }
            }
            else
            {
                // Set default char for GS1-128
                separator = (char)29;
            }

            // Split the barcode using the separator
            string[] splitBarcode = barcodeString.Split(separator);

            barcodeInformation = new Dictionary<string, string>();

            foreach (string barcodeToken in splitBarcode)
            {
                if(string.IsNullOrWhiteSpace(barcodeToken)) continue;

                CustomScanningConfigurationToken token = tokens.Where(t => barcodeToken.StartsWith(t.StandardToken)).FirstOrDefault();

                if(token != null)
                {
                    string parsedToken = string.Empty;

                    //If no lead filler at Token Level, use the ScanningConfiguration lead filler 
                    if (string.IsNullOrWhiteSpace(token.LeadFiller) && !string.IsNullOrWhiteSpace(scanningConfiguration.LeadFiller))
                    {
                        parsedToken = barcodeToken.TrimStart(token.StandardToken, true).TrimStart(scanningConfiguration.LeadFiller, true);
                    }
                    //If LeadFiller is defined at Token level, use that one instead
                    else
                    {
                        if (!string.IsNullOrWhiteSpace(token.LeadFiller))
                        {
                            parsedToken = barcodeToken.TrimStart(token.StandardToken,true).TrimStart(token.LeadFiller, true);
                        }
                        else
                        {
                            parsedToken = barcodeToken.TrimStart(token.StandardToken, true);
                        }
                    }
                    //If token parse is based on a Rule, execute rule and extract token information
                    if(!string.IsNullOrWhiteSpace(token.ParserRule))
                    {
                        Dictionary<string, object> parameters = new Dictionary<string, object>();

                        parameters[IKEAConstants.TokenNameKey] = token.Name;
                        parameters[IKEAConstants.StandardTokenKey] = token.StandardToken;
                        parameters[IKEAConstants.BarcodeKey] = parsedToken;

                        string barcodeInfoExtracted = ikeaUtilities.ExecuteRule(token.ParserRule, parameters) as string;

                        //if successfully extracted
                        if(!string.IsNullOrWhiteSpace(barcodeInfoExtracted))
                        {
                            barcodeInformation.Add(token.Name, barcodeInfoExtracted);
                        }
                        //Throw error if it was unable to extract token value
                        else
                        {
                            throw new IKEAException(IKEAConstants.CustomBarcodeExceptionsUnableToParseTokenLocalizedMessage, token.ParserRule, barcodeToken);
                        }
                    }
                    //If no rule is defined, parse information based on LeadFiller
                    else
                    {
                        barcodeInformation[token.Name] = parsedToken;
                    }
                }
                else
                {
                    // Throw exception indicating that there are no Standard Token that match the barcode
                    throw new IKEAException(IKEAConstants.CustomBarcodeExceptionsNoMatchingStandardTokenLocalizedMessage, scanningConfiguration.ScanningConfiguration);
                }
            }
            return barcodeInformation;
        }
    }
}
