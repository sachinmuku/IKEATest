﻿using System.Collections.Generic;

namespace Cmf.Custom.IKEA.Common.Barcode
{
    /// <summary>
    /// Interface to be used in the all the Standard Barcode Parsers
    /// </summary>
    public interface IStandardBarcode
    {
        /// <summary>
        /// Extract Barcode Information For Standard Barcodes
        /// </summary>
        /// <param name="barcodeString">Barcode</param>
        /// <param name="scanningConfiguration">Scanning Configuration</param>
        /// <param name="tokens">Tokens</param>
        /// <returns>Dictionary with the Barcode Information</returns>
        Dictionary<string, string> ExtractBarcodeInformation(string barcodeString,
                                                                            CustomScanningConfiguration scanningConfiguration,
                                                                            List<CustomScanningConfigurationToken> tokens);
    }
}