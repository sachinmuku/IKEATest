﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Common.Barcode
{
    public class CustomScanningConfigurationToken
    {
        public string ScanningConfiguration { get; set; }

        public int Position { get; set; }

        public string Name { get; set; }
        
        public string StandardToken { get; set; }
        
        public int? Length { get; set; }

        public string LeadFiller { get; set; }

        public string ParserRule { get; set; }
    }
}
