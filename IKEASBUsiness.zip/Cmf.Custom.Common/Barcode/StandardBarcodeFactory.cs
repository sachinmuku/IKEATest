﻿using Cmf.Custom.IKEA.Common.Exceptions;
using Cmf.Foundation.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Common.Barcode
{
    public static class StandardBarcodeFactory
    {
        /// <summary>
        /// Extract Barcode Information For Standard Barcodes
        /// </summary>
        /// <param name="barcodeString">Barcode</param>
        /// <param name="scanningConfiguration">Scanning Configuration</param>
        /// <param name="tokens">Tokens</param>
        /// <returns>Dictionary with the Barcode Information</returns>
        public static Dictionary<string, string> ExtractBarcodeInformation(string barcodeString,
                                                                            CustomScanningConfiguration scanningConfiguration,
                                                                            List<CustomScanningConfigurationToken> tokens)
        {
            Dictionary<string, string> barcodeInformation;

            IStandardBarcode standardBarcode;

            switch (scanningConfiguration.ScanningConfiguration)
            {
                case IKEAConstants.BarcodeStandardGS1128:
                    standardBarcode = new StandardBarcodeGS1();
                    break;
                default:
                    standardBarcode = null;
                    break;
            }

            // Check if any match to a Standard Barcode was found
            if (standardBarcode != null)
            {
                barcodeInformation = standardBarcode.ExtractBarcodeInformation(barcodeString,
                                                                                scanningConfiguration,
                                                                                tokens);
            }
            else
            {
                // Throw unrecognized Standard Barcode Type
                throw new IKEAException(IKEAConstants.CustomBarcodeExceptionsNotRecognizedStandardLocalizedMessage, 
                                                                            scanningConfiguration.ScanningConfiguration);
            }

            return barcodeInformation;
        }
    }
}
