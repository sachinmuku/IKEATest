﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cmf.Custom.IKEA.Common.Enums;

namespace Cmf.Custom.IKEA.Common.Barcode
{
    public class CustomScanningConfiguration
    {
        public string ScanningConfiguration { get; set; }

        public CustomScanningFormatEnum Format { get; set; }

        public string Separator { get; set; }

        public string LeadFiller { get; set; }
    }
}
