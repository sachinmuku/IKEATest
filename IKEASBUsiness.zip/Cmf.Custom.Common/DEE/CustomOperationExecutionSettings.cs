﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Common.DEE
{
    /// <summary>
    /// Class used to control the execution of operations
    /// </summary>
    public class CustomOperationExecutionSettings
    {
        // If true, then the original action will not be executed
        public bool IsOverride;


        public Dictionary<String, Object> Output;
    }
}
