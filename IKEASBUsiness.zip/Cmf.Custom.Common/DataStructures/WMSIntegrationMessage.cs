﻿using Cmf.Custom.IKEA.Common.Enums;
using System;

namespace Cmf.Custom.IKEA.Common.DataStructures
{
    /// <summary>
    /// Class that represents a WMS interface integration message
    /// </summary>
    public class WMSIntegrationMessage : IWMSIntegrationMessage
    {
        /// <summary>
        /// _id
        /// </summary>
        public string _id { get; set; }

        /// <summary>
        /// Request
        /// </summary>
        public int Request { get; set; }

        /// <summary>
        /// Response
        /// </summary>
        public CustomWMSOrderResponseType Response { get; set; }

        /// <summary>
        /// Details
        /// </summary>
        public string Details { get; set; }

        /// <summary>
        /// IOType
        /// </summary>
        public CustomWMSOrderRequestType IOType { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public int Command { get; set; }

        /// <summary>
        /// CommandParameter1
        /// </summary>
        public int CommandParameter1 { get; set; }

        /// <summary>
        /// State
        /// </summary>
        public CustomWMSOrderStateEnum State { get; set; }

        /// <summary>
        /// IOID
        /// </summary>
        public long? IOID { get; set; }

        /// <summary>
        /// ItemID
        /// </summary>
        public string ItemID { get; set; }

        /// <summary>
        /// ItemName
        /// </summary>
        public string ItemName { get; set; }

        /// <summary>
        /// Quantity
        /// </summary>
        public decimal Quantity { get; set; }

        /// <summary>
        /// DeliveredQuantity
        /// </summary>
        public decimal DeliveredQuantity { get; set; }

        /// <summary>
        /// Source
        /// </summary>
        public string Source { get; set; }

        /// <summary>
        /// Destination
        /// </summary>
        public string Destination { get; set; }

        /// <summary>
        /// PalletID
        /// </summary>
        public string PalletID { get; set; }

        /// <summary>
        /// PalletQuantity
        /// </summary>
        public decimal PalletQuantity { get; set; }

        /// <summary>
        /// BatchID
        /// </summary>
        public string BatchID { get; set; }

        /// <summary>
        /// Status
        /// </summary>
        public int Status { get; set; }

        /// <summary>
        /// StartTime
        /// </summary>
        public DateTime StartTime { get; set; } = DateTime.Now.ToUniversalTime();

        /// <summary>
        /// PalletDimension0
        /// </summary>
        public decimal PalletDimension0 { get; set; }

        /// <summary>
        /// PalletDimension1
        /// </summary>
        public decimal PalletDimension1 { get; set; }

        /// <summary>
        /// PalletDimension2
        /// </summary>
        public decimal PalletDimension2 { get; set; }

        /// <summary>
        /// BaseboardDimension0
        /// </summary>
        public decimal BaseboardDimension0 { get; set; }

        /// <summary>
        /// BaseboardDimension1
        /// </summary>
        public decimal BaseboardDimension1 { get; set; }

        /// <summary>
        /// BaseboardDimension2
        /// </summary>
        public decimal BaseboardDimension2 { get; set; }

        /// <summary>
        /// SeasoningTime
        /// </summary>
        public DateTime SeasoningTime { get; set; } = DateTime.Now.ToUniversalTime();

        /// <summary>
        /// SeasoningTime
        /// </summary>
        public string? ManufacturingOrderName { get; set; } = null;
    }
}
