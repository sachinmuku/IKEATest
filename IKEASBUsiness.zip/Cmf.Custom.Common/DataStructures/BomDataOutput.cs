﻿using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Common.DataStructures
{
    public class BomDataOutput
    {
        public IBOM Bom { get; set; }
        public IOperation Operation { get; set; }
        public IResourcePossibleTransitions ResourcePossibleTransitions { get; set; }
        public BOMAssemblyType BOMAssemblyType { get; set; }
        public IResourceCollection Resources { get; set; }
        public IMaterial Material { get; set; }
    }
}