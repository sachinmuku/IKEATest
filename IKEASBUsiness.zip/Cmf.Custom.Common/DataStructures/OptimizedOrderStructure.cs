﻿using System;
using System.Collections.Generic;
using System.Text;
using Cmf.Navigo.BusinessObjects;

namespace Cmf.Custom.IKEA.Common.DataStructures
{
    public class OptimizedOrderStructure
    {
        /// <summary>
        /// Optimized order name
        /// </summary>
        public string OrderName { get; set; }

        /// <summary>
        /// Length
        /// </summary>
        public decimal Length { get; set; }

        /// <summary>
        /// Width
        /// </summary>
        public decimal Width { get; set; }

        /// <summary>
        /// Requested Quantity
        /// </summary>
        public decimal? RequestedQuantity { get; set; }

        /// <summary>
        /// Optimized Quantity
        /// </summary>
        public decimal OptimizedQuantity { get; set; }

        /// <summary>
        /// Product Name
        /// </summary>
        public string ProductName { get; set; }

        /// <summary>
        /// Production Date
        /// </summary>
        public string ProductionDate { get; set; }

        /// <summary>
        /// Group MO Name
        /// </summary>
        public string GroupMOName { get; set; }

    }
}
