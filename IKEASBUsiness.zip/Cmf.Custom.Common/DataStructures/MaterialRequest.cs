﻿using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Common.DataStructures
{
    /// <summary>
    /// Setup Consumption detail info
    /// </summary>
    [DataContract(Namespace = "", IsReference = true, Name = "MaterialRequest")]
    public class MaterialRequest
    {
        [DataMember(Name = "Request", Order = 10)]
        public object Request { get; set; }

        [DataMember(Name = "RequestType", Order = 10)]
        public string RequestType { get; set; }

        [DataMember(Name = "Material", Order = 10)]
        public IMaterial Material { get; set; }

        [DataMember(Name = "Product", Order = 10)]
        public IProduct Product { get; set; }

        [DataMember(Name = "Quantity", Order = 10)]
        public string Quantity { get; set; }

        [DataMember(Name = "FromResource", Order = 10)]
        public IResource FromResource { get; set; }

        [DataMember(Name = "FromArea", Order = 10)]
        public IArea FromArea { get; set; }

        [DataMember(Name = "FromFacility", Order = 10)]
        public IFacility FromFacility { get; set; }

        [DataMember(Name = "ToResource", Order = 10)]
        public IResource ToResource { get; set; }

        [DataMember(Name = "ToArea", Order = 10)]
        public IArea ToArea { get; set; }

        [DataMember(Name = "ToFacility", Order = 10)]
        public IFacility ToFacility { get; set; }
    }
}
