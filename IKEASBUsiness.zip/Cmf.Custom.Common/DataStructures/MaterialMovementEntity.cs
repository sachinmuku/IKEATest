﻿using Cmf.Navigo.BusinessObjects;
using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Common.DataStructures
{
    /// <summary>
    /// Class to encapsulate MaterialMovement information
    /// </summary>
    public class MaterialMovementEntity
    {
        /// <summary>
        /// Material being moved
        /// </summary>
        public string MaterialToTransfer { get; set; }

        /// <summary>
        /// Source Facility
        /// </summary>
        public string SourceFacility { get; set; }

        /// <summary>
        /// Source Area
        /// </summary>
        public string SourceArea { get; set; }
        /// <summary>
        /// Source Step
        /// </summary>
        public string SourceStep { get; set; }

        /// <summary>
        /// Source Resource
        /// </summary>
        public string SourceResource { get; set; }

        /// <summary>
        /// To Resource
        /// </summary>
        public string ToResource { get; set; }
    }
}