﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using Cmf.Navigo.BusinessObjects;

namespace Cmf.Custom.IKEA.Common.DataStructures
{
    /// <summary>
    /// Data Structure representing a row from the Generic Table CustomUnitDimensions
    /// </summary>
    public class UnitDimensionsStructure
    {
        /// <summary>
        /// Unit (Pcs, m2, etc...)
        /// </summary>
        public string Unit { get; set; }

        /// <summary>
        /// Flag indicates if the unit requires the Length dimension
        /// </summary>
        public bool Length { get; set; }

        /// <summary>
        /// Flag indicates if the unit requires the Width dimension
        /// </summary>
        public bool Width { get; set; }

        /// <summary>
        /// Flag indicates if the unit requires the Thickness dimension
        /// </summary>
        public bool Thickness { get; set; }

        /// <summary>
        /// Flag indicates if the unit requires the Weight dimension
        /// </summary>
        public bool Weight { get; set; }

        /// <summary>
        /// Indicates if this unit does not require any of the possible dimensions
        /// </summary>
        public bool Dimensionless => !Length && !Width && !Thickness && !Weight;

        /// <summary>
        /// Create a new UnitDimensionsStructure from a DataRow object fetched from the database
        /// </summary>
        /// <param name="row"></param>
        /// <returns></returns>
        public static UnitDimensionsStructure FromDataRow(DataRow row)
        {
            return new UnitDimensionsStructure
            {
                Unit = row.Field<string>(IKEAConstants.CustomUnitDimensionsUnitColumn),
                Length = row.Field<bool>(IKEAConstants.CustomUnitDimensionsLengthColumn),
                Width = row.Field<bool>(IKEAConstants.CustomUnitDimensionsWidthColumn),
                Thickness = row.Field<bool>(IKEAConstants.CustomUnitDimensionsThicknessColumn),
                Weight = row.Field<bool>(IKEAConstants.CustomUnitDimensionsWeightColumn),
            };
        }
    }
}
