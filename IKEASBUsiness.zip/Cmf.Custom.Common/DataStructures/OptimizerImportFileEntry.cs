﻿using System;
using System.Collections.Generic;
using System.Text;
using Cmf.Navigo.BusinessObjects;

namespace Cmf.Custom.IKEA.Common.DataStructures
{
	public class OptimizerImportFileEntry
	{
		/// <summary>
		/// The Primary Quantity
		/// </summary>
		public decimal Quantity { get; set; }

		/// <summary>
		/// The Length Attribute of the Product
		/// </summary>
		public decimal Length { get; set; }

		/// <summary>
		/// The Width Attribute of the Product
		/// </summary>
		public decimal Width { get; set; }

		/// <summary>
		/// The Thickness Attribute of the Product
		/// </summary>
		public decimal Thickness { get; set; }

		/// <summary>
		/// The name of the Raw Material Product, resolved by the BOM
		/// </summary>
		public string SourceProduct { get; set; }

		/// <summary>
		/// The name of the Raw Material Product Description, resolved by the BOM
		/// </summary>
		public string SourceProductDescription { get; set; }

		/// <summary>
		/// The name of the MO
		/// </summary>
		public string ManufacturingOrder { get; set; }

		/// <summary>
		/// The name of the Product
		/// </summary>
		public string TargetProduct { get; set; }

		/// <summary>
		/// The Planned Start Date of the Production Order
		/// </summary>
		public DateTime? ProductionDate { get; set; }

		/// <summary>
		/// The name of the Group Order
		/// </summary>
		public string GroupOrder { get; set; }

		/// <summary>
		/// The descrition of the target product
		/// </summary>
		public string TargetProductDescription { get; set; }
	}
}
