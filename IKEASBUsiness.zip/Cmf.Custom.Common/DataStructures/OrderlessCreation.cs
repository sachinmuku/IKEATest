﻿using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Common.DataStructures
{
    /// <summary>
    /// OrderlessCreation detail info
    /// </summary>
    [DataContract(Namespace = "", IsReference = true, Name = "OrderlessCreation")]
    public class OrderlessCreation
    {
        /// <summary>
        /// Product for order
        /// </summary>
        [DataMember(Name = "Product", Order = 10)]
        public IProduct Product { get; set; }

        /// <summary>
        /// BOM for order
        /// </summary>
        [DataMember(Name = "BOM", Order = 10)]
        public IBOM BOM { get; set; }

        /// <summary>
        /// Order Quantity
        /// </summary>
        [DataMember(Name = "Quantity", Order = 10)]
        public decimal Quantity { get; set; }

        /// <summary>
        /// Optional - Parts Per Cycle
        /// </summary>
        [DataMember(Name = "PartsPerCycle", Order = 100)]
        public int PartsPerCycle { get; set; }

    }
}
