﻿using System.Collections.ObjectModel;
using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Common.DataStructures
{
    /// <summary>
    /// Output object CustomSetupConsumptionDetailCollection
    /// </summary>
    /// <seealso cref="Collection{CustomSetupConsumptionDetail}"/>
    [CollectionDataContract(Namespace = "", IsReference = true, Name = "CustomSetupConsumptionDetailCollection", ItemName = "CustomSetupConsumptionDetail")]
    public class CustomSetupConsumptionDetailCollection : Collection<CustomSetupConsumptionDetail>
    {

    }
}
