﻿using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Common.DataStructures
{

    /// <summary>
    /// Output Data Contract for the CustomForceOrderCompletion or CustomForceOrderAbort service
    /// </summary>
    [DataContract(Name = "ForceOrderOutput")]
    public class ForceOrderOutput : BaseOutput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// Indicates if it successfully forced the completion or abort of the MO
        /// </summary>
        [DataMember(Name = "Success", Order = 1)]
        public bool Success
        {
            get;
            set;
        }

        /// <summary>
        /// The Process Order material after all the transformations
        /// </summary>
        [DataMember(Name = "Material", Order = 2)]
        public IMaterial Material
        {
            get;
            set;
        }

        /// <summary>
        /// The newly generated process loss unit
        /// </summary>
        [DataMember(Name = "ProcessLossUnit", Order = 3)]
        public decimal ProcessLossUnit
        {
            get;
            set;
        }

        /// <summary>
        /// The Resource being used
        /// </summary>
        [DataMember(Name = "Resource", Order = 3)]
        public IResource Resource
        {
            get;
            set;
        }
        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
