﻿using System.Collections.ObjectModel;
using System.Runtime.Serialization;


namespace Cmf.Custom.IKEA.Common.DataStructures
{
    /// <summary>
    /// Output object CustomGetAutomationVariablesDetailCollection
    /// </summary>
    /// <seealso cref="Collection{CustomGetAutomationVariableDetail}"/>
    [CollectionDataContract(Namespace = "", IsReference = true, Name = "CustomGetAutomationVariableDetailCollection", ItemName = "CustomGetAutomationVariableDetail")]
    public class CustomGetAutomationVariableDetailCollection : Collection<CustomGetAutomationVariableDetail>
    {

    }
}
