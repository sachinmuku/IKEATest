﻿
using System;
using Cmf.Custom.IKEA.Common.Enums;

namespace Cmf.Custom.IKEA.Common.DataStructures
{
    /// <summary>
    /// interface that represents a Nice Label interface integration message
    /// </summary>
    public interface INiceLabelIntegrationMessage
    {
        /// <summary>
        /// Internal NiceLabel message id
        /// </summary>
        string _Id { get; set; }

        /// <summary>
        /// Workcenter of the Main Line
        /// </summary>
        string Workcenter { get; set; }

        /// <summary>
        /// Item No.
        /// </summary>
        string ItemNo { get; set; }
        
        /// <summary>
        /// Material Order ID
        /// </summary>
        string MOID { get; set; }

        /// <summary>
        /// Recipe 
        /// </summary>
        int Recipe { get; set; }

        /// <summary>
        /// Service Response from Nice Label
        /// </summary>
        CustomNiceLabelResponseType Response { get; set; }

    }
}
