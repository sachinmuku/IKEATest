﻿using System.Runtime.Serialization;


namespace Cmf.Custom.IKEA.Common.DataStructures
{
    /// <summary>
    /// Setup Automation detail info
    /// </summary>
    [DataContract(Namespace = "", IsReference = true, Name = "CustomGetAutomationVariableDetail")]
    public class CustomGetAutomationVariableDetail
    {

        /// <summary>
        ///  Name of the Variable
        /// </summary>
        [DataMember(Name = "Variable", Order = 100)]
        public string Variable { get; set; }

        /// <summary>
        ///  Description
        /// </summary>
        [DataMember(Name = "Description", Order = 200)]
        public string Description { get; set; }

        /// <summary>
        /// Label  will be the parameter name
        /// </summary>
        [DataMember(Name = "Label", Order = 300)]
        public string Label { get; set; }

        /// <summary>
        ///  Variable's value
        /// </summary>
        [DataMember(Name = "Value", Order = 400)]
        public string Value { get; set; }

        /// <summary>
        /// Variable's value's Unit
        /// </summary>
        [DataMember(Name = "Unit", Order = 500)]
        public string Unit { get; set; }

    }

}
