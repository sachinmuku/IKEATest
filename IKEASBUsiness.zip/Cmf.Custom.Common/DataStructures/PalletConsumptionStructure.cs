﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Common.DataStructures
{
    /// <summary>
    /// Pallet Consumption info
    /// </summary>
    [DataContract(Namespace = "", IsReference = true, Name = "PalletConsumptionStructure")]
    public class PalletConsumptionStructure
    {
        /// <summary>
        /// The material that was consumed
        /// </summary>
        [DataMember(Name = "ConsumableName", Order = 10)]
        public string ConsumableName { get; set; }

        /// <summary>
        /// Quantity Consumed
        /// </summary>
        [DataMember(Name = "QuantityConsumed", Order = 10)]
        public decimal QuantityConsumed { get; set; }

        /// <summary>
        /// Quantity still available to be consumed
        /// </summary>
        [DataMember(Name = "RemainingQuantity", Order = 10)]
        public decimal RemainingQuantity { get; set; }

        /// <summary>
        /// Consumption Finished On
        /// </summary>
        [DataMember(Name = "ConsumptionFinishedOn", Order = 10)]
        public DateTime? ConsumptionFinishedOn { get; set; }

        /// <summary>
        /// Pallet current state
        /// </summary>
        [DataMember(Name = "State", Order = 10)]
        public string State { get; set; }
    }
}
