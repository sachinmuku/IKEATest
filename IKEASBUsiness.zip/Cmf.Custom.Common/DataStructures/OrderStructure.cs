﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Cmf.Custom.IKEA.Common.Enums;

namespace Cmf.Custom.IKEA.Common.DataStructures
{
    public class OrderStructure
    {
        /// <summary>
        /// MO material ID
        /// </summary>
        public string MaterialId { get; set; }

        /// <summary>
        /// MO material Name
        /// </summary>
        public string MaterialName { get; set; }

        /// <summary>
        /// Material Quantity
        /// </summary>
        public decimal Quantity { get; set; }

        /// <summary>
        /// Quantity Produced 
        /// </summary>
        public decimal QuantityProduced { get; set; }

        /// <summary>
        /// Quantity Consumed 
        /// </summary>
        public decimal QuantityConsumed { get; set; }

        /// <summary>
        /// Quantity Outsorted
        /// </summary>
        public List<ProductionCounterStructure> QuantityOutsorted { get; set; }

        /// <summary>
        /// Quantity Infeeder
        /// </summary>
        public List<FeederStructure> QuantityInfeeder { get; set; }

        /// <summary>
        /// Quantity Outfeeder
        /// </summary>
        public List<ProductionCounterStructure> QuantityOutfeeder { get; set; }

        /// <summary>
        /// Maximum overproduction quantity
        /// </summary>
        public decimal? MaximumOverproductionQuantity { get; set; }

        /// <summary>
        /// Material MO State
        /// </summary>
        public string OrderState { get; set; }

        /// <summary>
        /// Product Name
        /// </summary>
        public string ProductName { get; set; }

        /// <summary>
        /// Product Description
        /// </summary>
        public string ProductDescription { get; set; }

        /// <summary>
        /// Pallet Total quantity for partial trackout
        /// </summary>
        public decimal? PalletQuantity { get; set; }

        /// <summary>
        /// Line Speed
        /// </summary>
        public double LineSpeed { get; set; }

        /// <summary>
        /// Line Name
        /// </summary>
        public string LineName { get; set; }

        /// <summary>
        /// If the PO is ready for production
        /// </summary>
        public bool IsReadyForProduction { get; set; }

        /// <summary>
        /// Indicates if the order running in full automation
        /// </summary>
        public bool IsFullAutomation { get; set; }

        /// <summary>
        /// Recipe Parameteres Structure
        /// </summary>
        public List<RecipeStructure> RecipeStructure { get; set; }

        /// <summary>
        /// Attached Materials Structure
        /// </summary>
        public List<AttachedMaterialsStructure> AttachedMaterialsStructures { get; set; }

        /// <summary>
        /// Material run information
        /// </summary>
        public int Run { get; set; }

        /// <summary>
        /// MES Quantity Consumed
        /// </summary>
        public int MESQuantityProduced { get; set; }

        /// <summary>
        /// Indicates the quantity to be consumed per unit produced
        /// </summary>
        public decimal ConsumptionPerUnitProduced { get; set; }

        /// <summary>
        /// The Main Feeder name for this order
        /// </summary>
        public string MainFeederName { get; set; }

        /// <summary>
        /// The Unit for this order
        /// </summary>
        public string Unit { get; set; }
        /// <summary>
        /// TheBaseUnitConversion for this order
        /// </summary>
        public decimal BaseUnitConversion { get; set; }

        /// <summary>
        /// Maximum Number of iterations
        /// </summary>
        public int MaxIterations { get; set; }

        /// <summary>
        /// Quantity consumed in the last iterations ( Iteration = MaxIteration)
        /// </summary>
        public decimal QuantityConsumedFinalIteration { get; set; }

        /// <summary>
        /// Total Qquantity of PartsPerCycle
        /// </summary>
        public decimal QuantityPerCycle { get; set; }

        /// <summary>
        /// Determines if the MO is set to direct feeding or storage mode in direct feeding lines
        /// </summary>
        public CustomDirectFeedingModeEnum DirectFeedingMode { get; set; }
    }
}
