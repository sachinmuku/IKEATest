﻿using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Common.DataStructures
{
    public class OptimizerResourceStructure
    {
        /// <summary>
        /// Resource name
        /// </summary>
        public IResource Resource { get; set; }

        /// <summary>
        /// Shared folder for sending files
        /// </summary>
        public string SendFileFolder { get; set; }

        /// <summary>
        /// ReceiveFileFolder
        /// </summary>
        public string ReceiveFileFolder { get; set; }

        /// <summary>
        /// Flag set to true if the group of materials can be dispatched without being optimized
        /// </summary>
        public bool AllowToDispatchNotOptimizedGroupOrders { get; set; }
    }
}
