﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Common.DataStructures
{
    [DataContract(Namespace = "", IsReference = true, Name = "ProductionCounterStructure")]
    [JsonObject(IsReference = false)]
    public class ProductionCounterStructure
    {
        /// <summary>
        /// Name of the resource that holds the counter
        /// </summary>
        [DataMember(Name = "Name", Order = 10)]
        public string Name { get; set; }

        /// <summary>
        /// Total quantity produced for the production point
        /// </summary>
        [DataMember(Name = "TotalQuantity", Order = 10)]
        public decimal TotalQuantity { get; set; }

        /// <summary>
        /// Current pallet quantity for the production point
        /// </summary>
        [DataMember(Name = "PalletQuantity", Order = 10)]
        public decimal PalletQuantity { get; set; }


        /// <summary>
        /// Current pallet quantities for product out palletization
        /// </summary>
        [DataMember(Name = "OrdersQuantities", Order = 10)]
        public List<MultipleOrdersOutInfo> OrdersQuantities { get; set; }
    }


}
