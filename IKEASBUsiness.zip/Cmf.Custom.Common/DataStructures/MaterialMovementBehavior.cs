﻿using System;
using System.Collections.Generic;
using System.Text;
using Cmf.Custom.IKEA.Common.Enums;


namespace Cmf.Custom.IKEA.Common.DataStructures
{
    /// <summary>
    /// Class representing the behavior to execute after a material movement
    /// </summary>
    public class MaterialMovementBehavior
    {
        /// <summary>
        /// Event Action
        /// </summary>
        public string EventAction { get; set; }

        /// <summary>
        /// Movement Request
        /// </summary>
        public bool MovementRequest { get; set; }

        /// <summary>
        /// WMS Request (Feed, Move, PutAway, Cancel, etc...)
        /// </summary>
        public CustomWMSOrderRequestType WMSRequest { get; set; }

        /// <summary>
        /// Destination Resource, used for WMSRequests of type Move
        /// </summary>
        public string DestinationResource { get; set; }

        /// <summary>
        /// Resource to Attach in case of Direct Repair or ReRun
        /// </summary>
        public string ResourceToAttach { get; set; }

        /// <summary>
        /// Evaluates if the current behavior is equivalent to doing nothing (no action and no request)
        /// </summary>
        public bool IsNone
        {
            get => (string.IsNullOrEmpty(EventAction) || EventAction.CompareStrings(IKEAConstants.CustomMaterialMovementConfigurationNone)) && WMSRequest == CustomWMSOrderRequestType.None;
        }
    }
}
