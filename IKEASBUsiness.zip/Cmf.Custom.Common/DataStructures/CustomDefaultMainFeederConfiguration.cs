﻿using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Common.DataStructures
{
    public class CustomDefaultMainFeederConfiguration
    {
        public IResource MainLine { get; set; }

        public IResource DefaultFeeder { get; set; }

        public IResource AlternativeFeeder { get; set; }

        public bool EnableOperatorSelection { get; set; }
    }
}
