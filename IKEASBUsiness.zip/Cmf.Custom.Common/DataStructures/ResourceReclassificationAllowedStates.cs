﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Common.DataStructures
{
    public class ResourceReclassificationAllowedStates
    {
        /// <summary>
        /// Allowed Role
        /// </summary>
        public string Role { get; set; }

        /// <summary>
        /// Allowed State Model
        /// </summary>
        public string StateModel { get; set; }

        /// <summary>
        /// Allowed State Model State
        /// </summary>
        public string StateModelState { get; set; }

        /// <summary>
        /// Allowed Reason
        /// </summary>
        public string Reason { get; set; }

        /// <summary>
        /// Allows Past Reclassifications when resource state is changed
        /// </summary>
        public bool AllowsPastReclassifications { get; set; }

        /// <summary>
        /// Enforce Comment when changing state
        /// </summary>
        public bool EnforceComment { get; set; }

        /// <summary>
        /// TimeAtState before enforce reclassifications
        /// </summary>
        public decimal TimeAtState { get; set; }

    }
}
