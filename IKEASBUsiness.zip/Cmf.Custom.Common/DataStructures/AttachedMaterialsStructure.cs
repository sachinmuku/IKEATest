﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Common.DataStructures
{
    public class AttachedMaterialsStructure
    {
        /// <summary>
        /// Attached Material Name
        /// </summary>
        public string MaterialName { get; set; }

        /// <summary>
        /// Attached Material Product Id
        /// </summary>
        public long ProductId { get; set; }

        /// <summary>
        /// Attached Material Product Id
        /// </summary>
        public string ProductName { get; set; }
        
        /// <summary>
        /// Attached Material Quantity
        /// </summary>
        public int Quantity { get; set; }

        /// <summary>
        /// Attached Material Consumed
        /// </summary>
        public int QuantityConsumed { get; set; }

        /// <summary>
        /// Attached Material State
        /// </summary>
        public string State { get; set; }

        /// <summary>
        /// Attached Material Date it was attached
        /// </summary>
        public string AttachedOn { get; set; }

        /// <summary>
        /// Attached Material Date of first consumption
        /// </summary>
        public string FirstConsumptionOn { get; set; }

        /// <summary>
        /// Attached Material Date that it was fully consumed
        /// </summary>
        public string ConsumptionFinishedOn { get; set; }

        /// <summary>
        /// Consumble Information
        /// </summary>
        public string ConsumableInformation { get; set; }

        /// <summary>
        /// Original Material
        /// </summary>
        public long OriginalMaterial { get; set; }

    }
}
