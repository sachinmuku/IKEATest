﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cmf.Custom.IKEA.Common.DataStructures
{
    public class CustomExpectedProductsAndConsumptionMode
    {
        public List<string> ProductsToConsider { get; set; }
        public string MOID { get; set; }
        public int FeederConsumptionMode { get; set; }
        public string FeederName { get; set; }
    }
}
