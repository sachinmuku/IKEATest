﻿using Cmf.Foundation.Marshalling.Converters;
using Newtonsoft.Json;
using System.Collections.Generic;

namespace Cmf.Custom.IKEA.Common.DataStructures
{
    /// <summary>
    /// Implementation of Dictionary that directly converts from a CMFMap Json artifact.
    /// </summary>
    [JsonConverter(typeof(DictionaryToMapConverter))]
    public class CMFMap<TKey, TValue> : Dictionary<TKey, TValue>
    {
    }
}
