﻿using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Common.DataStructures
{

    /// <summary>
    /// Input Data Contract for the CustomForceOrderCompletion or CustomForceOrderAbort service
    /// </summary>
    [DataContract(Name = "ForceOrderInput")]
    public class ForceOrderInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables

        #endregion

        #region Properties

        /// <summary>
        /// Material to Force Completion
        /// </summary>
        [DataMember(Name = "Material", Order = 1)]
        public IMaterial Material { get; set; }

        public bool IsCompletion { get; set; }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
