﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using Cmf.Custom.IKEA.BusinessObjects;
using Cmf.Custom.IKEA.BusinessObjects.Abstractions;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;

namespace Cmf.Custom.IKEA.Common.DataStructures
{
    [DataContract(Name = "GroupedInventoryOrders")]
    public class GroupedInventoryOrders
    {
        /// <summary>
        /// Material Name
        /// </summary>
        [DataMember(Name = "ManufacturingOrder", Order = 10)]
        public IMaterial ManufacturingOrder { get; set; }

        /// <summary>
        /// Material Name
        /// </summary>
        [DataMember(Name = "DestinationResource", Order = 10)]
        public IResource DestinationResource { get; set; }

        /// <summary>
        /// Product
        /// </summary>
        [DataMember(Name = "Product", Order = 10)]
        public IProduct Product { get; set; }

        /// <summary>
        /// InventoryOrderRequests
        /// </summary>
        [DataMember(Name = "InventoryOrderRequests", Order = 10)]
        public ICustomWMSMaterialTrackerCollection InventoryOrderRequests { get; set; }

        /// <summary>
        /// Sum of RequestedQuantity of all children
        /// </summary>
        [DataMember(Name = "RequestedQuantity", Order = 10)]
        public decimal RequestedQuantity { get; set; }

        /// <summary>
        /// Sum of DeliveredQuantity of all children
        /// </summary>
        [DataMember(Name = "DeliveredQuantity", Order = 10)]
        public decimal DeliveredQuantity { get; set; }

        /// <summary>
        /// Oldest CreatedOn date
        /// </summary>
        [DataMember(Name = "CreatedOn", Order = 10)]
        public DateTime? CreatedOn { get; set; }

        /// <summary>
        /// Newest ModifiedOn date
        /// </summary>
        [DataMember(Name = "ModifiedOn", Order = 10)]
        public DateTime? ModifiedOn { get; set; }

        public GroupedInventoryOrders(IMaterial material, IResource resource, IProduct product, IEnumerable<ICustomWMSMaterialTracker> inventoryOrderRequests = null)
        {
            ManufacturingOrder = material;
            DestinationResource = resource;
            Product = product;
            InventoryOrderRequests = ApplicationContext.CurrentServiceProvider.GetService<IEntityFactory>().CreateCollection<ICustomWMSMaterialTrackerCollection>();

            if (inventoryOrderRequests != null && inventoryOrderRequests.Any())
            {
                InventoryOrderRequests.AddRange(inventoryOrderRequests);

                UpdateCalculatedFields();
            }
        }

        /// <summary>
        /// Update the calculated fields (RequestedQuantity, DeliveredQuantity, CreatedOn, ModifiedOn)
        /// </summary>
        public void UpdateCalculatedFields()
        {
            RequestedQuantity = 0;
            DeliveredQuantity = 0;
            CreatedOn = null;
            ModifiedOn = null;

            foreach (ICustomWMSMaterialTracker tracker in InventoryOrderRequests)
            {
                // If the tracker is terminated, we only consider what was delivered as the requested quantity
                if (tracker.UniversalState == Foundation.Common.Base.UniversalState.Terminated)
                {
                    RequestedQuantity += tracker.DeliveredQuantity ?? 0;
                }
                else
                {
                    RequestedQuantity += tracker.RequestedQuantity ?? 0;
                }

                // Always count the total delivered quantity
                DeliveredQuantity += tracker.DeliveredQuantity ?? 0;

                if (CreatedOn == null || tracker.CreatedOn < CreatedOn)
                {
                    CreatedOn = tracker.CreatedOn;
                }

                if (ModifiedOn == null || tracker.ModifiedOn > ModifiedOn)
                {
                    ModifiedOn = tracker.ModifiedOn;
                }
            }
        }
    }
}
