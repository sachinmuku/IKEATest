﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Common.DataStructures
{
    [DataContract(Namespace = "", IsReference = true, Name = "MultipleOrdersOutInfo")]
    [JsonObject(IsReference = false)]
    public class MultipleOrdersOutInfo
    {
        /// <summary>
        /// Name of the child order
        /// </summary>
        [DataMember(Name = "OrderName", Order = 10)]
        public string OrderName { get; set; }

        /// <summary>
        /// Produced quantity for the child order
        /// </summary>
        [DataMember(Name = "Quantity", Order = 10)]
        public decimal Quantity { get; set; }
    }
}
