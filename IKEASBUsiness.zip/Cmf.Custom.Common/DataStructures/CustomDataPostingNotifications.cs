﻿using System.Collections.Generic;

namespace Cmf.Custom.IKEA.Common.DataStructures
{
    public class CustomDataPostingNotifications
    {
        /// <summary>
        /// LogicalChartName
        /// </summary>
        public string LogicalChartName { get; set; }

        /// <summary>
        /// Resource Name
        /// </summary>
        public string ResourceName { get; set; }

        /// <summary>
        /// Chart Name
        /// </summary>
        public string ChartName { get; set; }

        /// <summary>
        /// Parameter Name
        /// </summary>
        public string ParameterName { get; set; }

        /// <summary>
        /// State Model
        /// </summary>
        public string StateModelName { get; set; }

        /// <summary>
        /// State Model State
        /// </summary>
        public string StateModelStateName { get; set; }

        /// <summary>
        /// NotificationFrequency in minutes
        /// </summary>
        public int NotificationFrequency { get; set; }

        /// <summary>
        /// MESNotifications
        /// </summary>
        public bool MESNotifications { get; set; }

        /// <summary>
        /// EmailNotifications
        /// </summary>
        public bool EmailNotifications { get; set; }

        /// <summary>
        /// NotifyCheckedInEmployees
        /// </summary>
        public bool NotifyCheckedInEmployees { get; set; }

        /// <summary>
        /// NotificationRoleName
        /// </summary>
        public string NotificationRoleName { get; set; }

        /// <summary>
        /// EmailDistributionList
        /// </summary>
        public List<string> EmailDistributionList { get; set; }

    }
}
