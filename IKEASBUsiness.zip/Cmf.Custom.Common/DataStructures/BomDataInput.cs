﻿using Cmf.Navigo.BusinessObjects;
using System;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Common.DataStructures
{
    public class BomDataInput
    {
        public IMaterial Material { get; set; }
        public Int32 MaterialLevelsToLoad { get; set; }
        public Int32 ResourceLevelsToLoad { get; set; }
        public Int32 TopMostMaterialLevelsToLoad { get; set; }
        public Int32 BomLevelsToLoad { get; set; }
        public Int32 BOMProductLevelsToLoad { get; set; }

        public GetDataForTrackInOperation Operation { get; set; }
        public IResource Resource { get; set; }
        public IOperationAttributeCollection OperationAttributes { get; set; }
    }
}