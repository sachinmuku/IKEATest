﻿
using System;
using Cmf.Custom.IKEA.Common.Enums;

namespace Cmf.Custom.IKEA.Common.DataStructures
{
    /// <summary>
    /// Class that represents a NiceLabelIntegrationMessage interface integration message
    /// </summary>
    public class NiceLabelIntegrationMessage : INiceLabelIntegrationMessage
    {
        /// <summary>
        /// Internal NiceLabel message id
        /// </summary>
        public string _Id { get; set; }

        /// <summary>
        /// Workcenter of the Main Line
        /// </summary>
        public string Workcenter { get; set; }

        /// <summary>
        /// Item No.
        /// </summary>
        public string ItemNo { get; set; }

        /// <summary>
        /// Material order ID
        /// </summary>
        public string MOID { get; set; }

        /// <summary>
        /// Recipe
        /// </summary>
        public int Recipe { get; set; }

        /// <summary>
        /// Service Response from Nice Label
        /// </summary>
        public CustomNiceLabelResponseType Response { get; set; }
    }
}
