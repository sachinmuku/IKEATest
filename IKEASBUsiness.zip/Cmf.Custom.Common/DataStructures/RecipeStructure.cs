﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Common.DataStructures
{
    [JsonObject(IsReference = false)]
    public class RecipeStructure
    {
        /// <summary>
        /// Recipe Resource Name
        /// </summary>
        public string ProcessSegment { get; set; }
        
        /// <summary>
        /// Parameter Name
        /// </summary>
        public string ParameterName { get; set; }

        /// <summary>
        /// Parameter Value
        /// </summary>
        public object ParameterValue { get; set; }

        /// <summary>
        /// Parameter Value Type
        /// </summary>
        public string ParameterValueType { get; set; }

        /// <summary>
        /// Parameter ID
        /// </summary>
        public long ParameterId { get; set; }

        /// <summary>
        /// Parameter Units
        /// </summary>
        public string ParameterUnits { get; set; }
    }
}
