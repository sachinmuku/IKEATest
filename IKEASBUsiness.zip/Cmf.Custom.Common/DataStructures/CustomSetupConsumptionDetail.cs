﻿using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Common.DataStructures
{
    /// <summary>
    /// Setup Consumption detail info
    /// </summary>
    [DataContract(Namespace = "", IsReference = true, Name = "CustomSetupConsumptionDetail")]
    public class CustomSetupConsumptionDetail
    {
        /// <summary>
        /// BOM for material
        /// </summary>
        [DataMember(Name = "BOM", Order = 10)]
        public IBOM BOM { get; set; }

        /// <summary>
        /// BOM Product Position
        /// </summary>
        [DataMember(Name = "Position", Order = 10)]
        public int Position { get; set; }

        /// <summary>
        /// Expected Product
        /// </summary>
        [DataMember(Name = "ExpectedProduct", Order = 10)]
        public IProduct ExpectedProduct { get; set; }

        /// <summary>
        /// Currently Attached Product in first position of consumable feed
        /// </summary>
        [DataMember(Name = "CurrentlyAttachedProduct", Order = 10)]
        public IProduct CurrentlyAttachedProduct { get; set; }

        /// <summary>
        /// Consumable feed 
        /// </summary>
        [DataMember(Name = "ConsumableFeed", Order = 10)]
        public IResource ConsumableFeed { get; set; }

        /// <summary>
        /// Quantity Attached
        /// </summary>
        [DataMember(Name = "QuantityAttached", Order = 10)]
        public decimal QuantityAttached { get; set; }

        /// <summary>
        /// Minimum In Feeder
        /// </summary>
        [DataMember(Name = "MinimumInFeeder", Order = 10)]
        public decimal MinimumInFeeder { get; set; }

        /// <summary>
        /// Quantity Required to Produce 1 Pallet
        /// </summary>
        [DataMember(Name = "ToProducePallet", Order = 10)]
        public decimal ToProducePallet { get; set; }

        /// <summary>
        /// Total Order Requirement
        /// </summary>
        [DataMember(Name = "TotalOrderRequirement", Order = 10)]
        public decimal TotalOrderRequirement { get; set; }

        /// <summary>
        /// Attached Materials
        /// </summary>
        [DataMember(Name = "AttachedMaterials", Order = 10)]
        public IMaterialCollection AttachedMaterials { get; set; }

    }
}
