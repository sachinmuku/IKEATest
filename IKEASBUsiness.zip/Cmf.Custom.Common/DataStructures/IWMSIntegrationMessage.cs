﻿using Cmf.Custom.IKEA.Common.Enums;
using System;

namespace Cmf.Custom.IKEA.Common.DataStructures
{
    /// <summary>
    /// interface that represents a WMS interface integration message
    /// </summary>
    public interface IWMSIntegrationMessage
    {
        /// <summary>
        /// Internal WMS message id
        /// </summary>
        string _id { get; set; }

        /// <summary>
        /// Request: 0 - On request, MES will always defaults to 0
        /// </summary>
        int Request { get; set; }

        /// <summary>
        /// Service Response from WMS: 3-Accepted, 9-Rejected
        /// </summary>
        CustomWMSOrderResponseType Response { get; set; }

        /// <summary>
        /// Details - Optional message when Response field is 9-Rejected
        /// </summary>
        string Details { get; set; }

        /// <summary>
        /// IOType: 0-None, 1-Feed, 2-PutAway, 3-Move, 4-Cancel
        /// </summary>
        CustomWMSOrderRequestType IOType { get; set; }

        /// <summary>
        /// Command: 0 - On request, MES will always defaults to 0
        /// </summary>
        int Command { get; set; }

        /// <summary>
        /// CommandParameter1: 0 - On request, MES will always defaults to 0
        /// </summary>
        int CommandParameter1 { get; set; }

        /// <summary>
        /// State: Job Order states: Idle, Complete
        /// </summary>
        CustomWMSOrderStateEnum State { get; set; }

        /// <summary>
        /// IOID: Inventory Order Id
        /// </summary>
        long? IOID { get; set; }

        /// <summary>
        /// ItemID - Product Name
        /// </summary>
        string ItemID { get; set; }

        /// <summary>
        /// ItemName: Product Description
        /// </summary>
        string ItemName { get; set; }

        /// <summary>
        /// Quantity: Inventory order requested quantity
        /// </summary>
        decimal Quantity { get; set; }

        /// <summary>
        /// DeliveredQuantity: Inventory order Total delivered quantity
        /// </summary>
        decimal DeliveredQuantity { get; set; }

        /// <summary>
        /// Source: The origin resource
        /// </summary>
        string Source { get; set; }

        /// <summary>
        /// Destination: The destination resource
        /// </summary>
        string Destination { get; set; }

        /// <summary>
        /// PalletID: The Material name
        /// </summary>
        string PalletID { get; set; }

        /// <summary>
        /// PalletQuantity: The Material primary Quantity
        /// </summary>
        decimal PalletQuantity { get; set; }

        /// <summary>
        /// BatchID: The Batch of the Material
        /// </summary>
        string BatchID { get; set; }

        /// <summary>
        /// Status: Quality Status of the Material
        /// </summary>
        int Status { get; set; }

        /// <summary>
        /// StartTime: Order Planned Start Date if applicable. (Other cases must default to Now())
        /// </summary>
        DateTime StartTime { get; set; }

        /// <summary>
        /// PalletDimension0
        /// </summary>
        decimal PalletDimension0 { get; set; }

        /// <summary>
        /// PalletDimension1
        /// </summary>
        decimal PalletDimension1 { get; set; }

        /// <summary>
        /// PalletDimension2
        /// </summary>
        decimal PalletDimension2 { get; set; }

        /// <summary>
        /// BaseboardDimension0
        /// </summary>
        decimal BaseboardDimension0 { get; set; }

        /// <summary>
        /// BaseboardDimension1
        /// </summary>
        decimal BaseboardDimension1 { get; set; }

        /// <summary>
        /// BaseboardDimension2
        /// </summary>
        decimal BaseboardDimension2 { get; set; }

        /// <summary>
        /// SeasoningTime
        /// </summary>
        string? ManufacturingOrderName { get; set; }
    }
}
