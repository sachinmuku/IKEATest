﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Common.DataStructures
{
    [JsonObject(IsReference = false)]
    public class FeederStructure
    {
        /// <summary>
        /// Resource feeder name
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Feeder information value
        /// </summary>
        public int Value { get; set; }

        /// <summary>
        /// Whether it is linked to Main feeder or not
        /// </summary>
        public bool? DistributedMode { get; set; }

        /// <summary>
        /// List of Expected Products for this feeder for a specific order
        /// </summary>
        public List<String> ExpectedProducts { get; set; }
    }
}
