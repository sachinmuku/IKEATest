﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace Cmf.Custom.IKEA.Common.DataStructures
{
    [DataContract(Namespace = "", IsReference = true, Name = "UllLabelFields")]
    public class UllLabelFields
    {
        /// <summary>
        /// Unit Load Stacking Capacity
        /// </summary>
        [DataMember(Name = "UnitLoadStackingCapacity", Order = 0)]
        public decimal UnitLoadStackingCapacity { get; set; }

        /// <summary>
        /// Unit Load Footprint Width
        /// </summary>
        [DataMember(Name = "UnitLoadFootPrintWidth", Order = 1)]
        public decimal UnitLoadFootPrintWidth { get; set; }

        /// <summary>
        /// Unit Load Foorprint Length
        /// </summary>
        [DataMember(Name = "UnitLoadFootPrintLength", Order = 2)]
        public decimal UnitLoadFootPrintLength { get; set; }

        /// <summary>
        /// The type of pallet
        /// </summary>
        [DataMember(Name = "PalletType", Order = 3)]
        public string PalletType { get; set; }

        /// <summary>
        /// Factory signature
        /// </summary>
        [DataMember(Name = "FactorySignature", Order = 4)]
        public string FactorySignature { get; set; }

        /// <summary>
        /// Product Description
        /// </summary>
        [DataMember(Name = "ArticleName", Order = 5)]
        public string ArticleName { get; set; }

        /// <summary>
        /// Product Name
        /// </summary>
        [DataMember(Name = "ProductNumber", Order = 6)]
        public string ProductNumber { get; set; }

        /// <summary>
        /// Supplier Number
        /// </summary>
        [DataMember(Name = "SupplierNumber", Order = 7)]
        public string SupplierNumber { get; set; }

        /// <summary>
        /// Date stamp (YYWW - Year 2 digits, Weed 2 digits)
        /// </summary>
        [DataMember(Name = "DateStamp", Order = 8)]
        public string DateStamp { get; set; }

        /// <summary>
        /// Quantity
        /// </summary>
        [DataMember(Name = "Quantity", Order = 9)]
        public decimal Quantity { get; set; }

        /// <summary>
        /// Gross Weight (quantity multiplied by the product's unit weight)
        /// </summary>
        [DataMember(Name = "GrossWeight", Order = 10)]
        public decimal GrossWeight { get; set; }

        /// <summary>
        /// Reuse an existing pallet counter (when reprinting a label)
        /// </summary>
        [DataMember(Name = "PalletCounter", Order = 11)]
        public int? PalletCounter { get; set; }

        /// <summary>
        /// SSCCBarcode
        /// </summary>
        [DataMember(Name = "SSCCBarcode", Order = 12)]
        public string SSCCBarcode { get; set; }

        /// <summary>
        /// Pallet Number
        /// </summary>
        [DataMember(Name = "PalletNumber", Order = 13)]
        public string PalletNumber { get; set; }

    }
}
