using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Common.DataStructures
{
    /// <summary>
    /// Class that contains the changes of state of a resource
    /// </summary>
    public class ResourceStateChangesStructure
    {
        /// <summary>
        /// Resource that is changing state
        /// </summary>
        public IResource Resource { get; set; }

        /// <summary>
        /// Current state model of the resource
        /// </summary>
        public IStateModel ResourceMainStateModel { get; set; }

        /// <summary>
        /// Initial StateModel State
        /// </summary>
        public IStateModelState InitialStateModelState { get; set; }

        /// <summary>
        /// Initial StateModel State Reason
        /// </summary>
        public string InitialStateReason { get; set; }

        /// <summary>
        /// Initial StateModel State
        /// </summary>
        public IStateModelState FinalStateModelState { get; set; }

        /// <summary>
        /// Initial StateModel State Reason
        /// </summary>
        public string FinalStateReason { get; set; }
    }
}
