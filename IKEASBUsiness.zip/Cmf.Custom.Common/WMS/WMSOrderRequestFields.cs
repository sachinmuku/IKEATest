﻿using Cmf.Navigo.BusinessObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Common.WMS
{
    /// <summary>
    /// Class representing the BatchID, Status, PalletID and Quantity on request order to WMS
    /// </summary>
    [DataContract(Namespace = "", IsReference = true, Name = "WMSOrderRequestFields")]
    public class WMSOrderRequestFields
    {

        [DataMember(Name = "BatchId", Order = 300)]
        public string BatchId { get; set; }

        /// <summary>
        /// The Material Status
        /// </summary>
        [DataMember(Name = "Status", Order = 400)]
        public string Status { get; set; }

        /// <summary>
        /// The Pallet Id
        /// </summary>
        [DataMember(Name = "PalletId", Order = 500)]
        public string PalletId { get; set; }

        /// <summary>
        /// Dictionary containing the MaterialType and the loss reason with the quantity
        /// </summary>
        [DataMember(Name = "Quantity", Order = 10)]
        public decimal Quantity
        {
            get;
            set;
        }

    }
}
