﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cmf.Custom.IKEA.Common.WMS
{
    /// <summary>
    /// Class mapping the columns of the Smart Table "CustomConsumableFeedsDirectDelivery"
    /// </summary>
    public class CustomConsumableFeedsDirectDeliveryRow
    {
        public string MainLine { get; set; }

        public string Feeder { get; set; }

        public bool IsDirectDelivery { get; set; }
    }
}
