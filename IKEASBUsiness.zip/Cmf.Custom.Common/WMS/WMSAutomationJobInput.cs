﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;
using Cmf.Custom.IKEA.Common.Enums;
using Newtonsoft.Json;

namespace Cmf.Custom.IKEA.Common.WMS
{
    /// <summary>
    /// Class representing the JSON input of the AutomationJobs for WMS Order Requests
    /// </summary>
    [JsonObject(ItemNullValueHandling = NullValueHandling.Ignore)]
    [Serializable]
    public class WMSAutomationJobInput
    {
        /// <summary>
        /// IOType
        /// </summary>
        [DataMember(Name = "IOType", Order = 0)]
        public CustomWMSOrderRequestType IOType { get; set; }

        /// <summary>
        /// ItemID
        /// </summary>
        [DataMember(Name = "ItemID", Order = 1)]
        public string ItemID { get; set; }

        /// <summary>
        /// ItemName
        /// </summary>
        [DataMember(Name = "ItemName", Order = 2)]
        public string ItemName { get; set; }

        /// <summary>
        /// ItemName
        /// </summary>
        [DataMember(Name = "PalletID", Order = 3)]
        public string PalletID { get; set; }

        /// <summary>
        /// ItemName
        /// </summary>
        [DataMember(Name = "ManufacturingOrderName", Order = 4)]
        public string ManufacturingOrderName { get; set; }

        /// <summary>
        /// Source
        /// </summary>
        [DataMember(Name = "Source", Order = 5)]
        public string Source { get; set; }

        /// <summary>
        /// Destination
        /// </summary>
        [DataMember(Name = "Destination", Order = 6)]
        public string Destination { get; set; }

        /// <summary>
        /// StartTime
        /// </summary>
        [DataMember(Name = "StartTime", Order = 7)]
        public DateTime? StartTime { get; set; }

        /// <summary>
        /// Quantity
        /// </summary>
        [DataMember(Name = "Quantity", Order = 8)]
        public decimal? Quantity { get; set; }

        /// <summary>
        /// Status
        /// </summary>
        [DataMember(Name = "Status", Order = 9)]
        public int Status { get; set; }

        /// <summary>
        /// BatchId
        /// </summary>
        [DataMember(Name = "BatchID", Order = 10)]
        public string BatchID { get; set; }
    }
}
