﻿using System;

namespace Cmf.Custom.IKEA.Common.WMS
{
    /// <summary>
    /// Class that represent the base communication integration entry message MES > WMS
    /// </summary>
    [Serializable]
    public class MESWMSCommunication
    {
        /// <summary>
        /// Api endpoint
        /// </summary>
        public string API { get; set; }

        /// <summary>
        /// Json string message 
        /// </summary>
        public string Message { get; set; }

        /// <summary>
        /// FactoryAutomationJobId
        /// </summary>
        public string FactoryAutomationJobId { get; set; }
    }
}
