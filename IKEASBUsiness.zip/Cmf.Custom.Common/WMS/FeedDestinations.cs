﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.QueryObject;
using Cmf.Foundation.BusinessObjects.SmartTables;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Common.CustomActionUtilities;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Foundation.Common;
using Microsoft.Extensions.DependencyInjection;
using Cmf.Foundation.Common.Abstractions;

namespace Cmf.Custom.IKEA.Common.WMS
{

    /// <summary>
    /// This Utility class is used when building WMS FEED Order Requests messages. It contains the business logic for automatically selecting
    /// the default Resource destinations for each product in the BOM of a material.
    /// 
    /// The current logic works as follows:
    ///   - The default delivery destination is always the first Stocking Point associated with the main line.
    ///   - For each BOM product, this can be overridden to be the associated Feeder instead (as determined by the ProcessSegment and SubProcessSegmentName attributes)
    ///     through the Smart Table "CustomConsumableFeedsDirectDelivery"
    ///     
    /// Before using this class, it is important to call once the method `Load()`. Multiple calls to this method
    /// will result in the information being reloaded each time.
    /// </summary>
    public class FeedDestinations
    {
        private static IWMSUtilities wmsUtilities => ApplicationContext.CurrentServiceProvider.GetService<IWMSUtilities>();
        private static IStockingPointUtilities stockingPointUtilities => ApplicationContext.CurrentServiceProvider.GetService<IStockingPointUtilities>();
        private static IEntityFactory entityFactory => ApplicationContext.CurrentServiceProvider.GetService<IEntityFactory>();

        /// <summary>
        /// The Main Line Resource for which this class contains information about
        /// </summary>
        public IResource MainLine { get; set; }

        public IResource MainStockingPoint { get; set; }

        public IResourceCollection FeederResources { get; set; }

        public IResourceCollection DirectStorageResources { get; set; }

        public FeedDestinations(IResource mainLine)
        {
            MainLine = mainLine;
        }

        public void Load()
        {
            LoadMainLineFeeders();

            LoadDirectStorageResources();

            LoadMainStockingPoint();
        }

        protected void LoadMainLineFeeders()
        {
            FeederResources = wmsUtilities.GetMainLineFeeders(MainLine);
            FeederResources.LoadAttributes(new Collection<string>
            {
                IKEAConstants.ProcessSegmentSequence,
                IKEAConstants.SubProcessSegmentName,
            });
        }

        protected void LoadDirectStorageResources()
        {
            DirectStorageResources = entityFactory.CreateCollection<IResourceCollection>();

            if (FeederResources.Count == 0)
            {
                return;
            }

            var smartTable = new SmartTable();
            smartTable.Load(IKEAConstants.CustomConsumableFeedsDirectDeliverySmartTable);
            // The ideal query would be `MainLine = mainline.Name OR (MainLine IS NULL AND Feeder IN feederResources.Name)`, but that would
            // require using `InnerFilter`, which this service does not support. So, we do a less specific query,
            // `MainLine = mainline.Name OR Feeder IN feederResources.Name` and refine it further in here
            smartTable.LoadData(new FilterCollection
            {
                new Filter
                {
                    Name = "MainLine",
                    Operator = Foundation.Common.FieldOperator.IsEqualTo,
                    Value = MainLine.Name,
                    LogicalOperator = Foundation.Common.LogicalOperator.OR,
                },
                new Filter
                {
                    Name = "Feeder",
                    Operator = Foundation.Common.FieldOperator.In,
                    Value = FeederResources.Select(resource => resource.Name).ToList(),
                    LogicalOperator = Foundation.Common.LogicalOperator.Nothing,
                }
            });

            DataSet smartTableDS = NgpDataSet.ToDataSet(smartTable.Data);

            var directDeliveryRows = new List<CustomConsumableFeedsDirectDeliveryRow>();

            if (smartTableDS.HasData())
            {
                HashSet<string> feederNames = new HashSet<string>(
                    FeederResources.Select(resource => resource.Name)
                );

                foreach (DataRow row in smartTableDS.Tables[0].Rows)
                {
                    var configurationRow = new CustomConsumableFeedsDirectDeliveryRow
                    {
                        MainLine = row.Field<string>(IKEAConstants.CustomConsumableFeedsDirectDeliverySmartTableMainLine),
                        Feeder = row.Field<string>(IKEAConstants.CustomConsumableFeedsDirectDeliverySmartTableFeeder),
                        IsDirectDelivery = row.Field<bool>(IKEAConstants.CustomConsumableFeedsDirectDeliverySmartTableIsDirectDelivery),
                    };

                    // This filter is the refining of the query that we could not do when calling the service
                    if (configurationRow.MainLine.IsNullOrEmpty() || configurationRow.Feeder.IsNullOrEmpty() || feederNames.Contains(configurationRow.Feeder))
                    {
                        directDeliveryRows.Add(configurationRow);
                    }
                }
            }

            bool isDirectDeliveryDefault = directDeliveryRows.FirstOrDefault(
                row => string.IsNullOrEmpty(row.Feeder) && row.MainLine == MainLine.Name
            )?.IsDirectDelivery ?? false;

            var deliveryByFeeder = new Dictionary<string, bool>();

            foreach (var row in directDeliveryRows)
            {
                if (row.Feeder != null)
                {
                    bool withMainLine = row.MainLine != null;

                    if (!withMainLine && deliveryByFeeder.ContainsKey(row.Feeder))
                    {
                        continue;
                    }

                    deliveryByFeeder[row.Feeder] = row.IsDirectDelivery;
                }
            }

            DirectStorageResources = entityFactory.CreateCollection<IResourceCollection>();
            DirectStorageResources.AddRange(
                FeederResources.Where(resource =>
                {
                    return (deliveryByFeeder.ContainsKey(resource.Name) == false && isDirectDeliveryDefault) ||
                           (deliveryByFeeder.ContainsKey(resource.Name) == true && deliveryByFeeder[resource.Name] == true);
                })
            );
        }

        protected void LoadMainStockingPoint()
        {
            MainStockingPoint = stockingPointUtilities.GetLineStockingPoint(MainLine).FirstOrDefault()?.SourceEntity;

            if (MainStockingPoint != null)
            {
                MainStockingPoint.Load();
            }
        }

        /// <summary>
        /// Returns the Feeder resource associated with a BOm Product. Assumes that the attributes ProcessSegment and SubProcessSegment
        /// on the BOM Product are loaded.
        /// </summary>
        /// <param name="bomProduct"></param>
        /// <returns></returns>
        public IEnumerable<IResource> FindBomProductFeeder(IBOMProduct bomProduct)
        {
            string productProcessSegment = bomProduct.GetAttributeValueOrDefault<string>(IKEAConstants.BomProductProcessSegmentAttribute);
            string productSubProcessSegment = bomProduct.GetAttributeValueOrDefault<string>(IKEAConstants.BomProductSubProcessSegmentAttribute);

            return FeederResources.Where(resource =>
            {
                return resource.GetAttributeValueOrDefault<string>(IKEAConstants.ProcessSegmentSequence) == productProcessSegment
                    && resource.GetAttributeValueOrDefault<string>(IKEAConstants.SubProcessSegmentName) == productSubProcessSegment;
            });
        }

        /// <summary>
        /// Returns the Resource to be used as the FEED delivery destination. By default, it is the MainStockingPoint,
        /// but can also be the feeder associated with this BOM Product, if the feeder is marked as DirectDelivery
        /// in the "CustomConsumableFeedsDirectDelivery" Smart Table
        /// </summary>
        /// <param name="bomProduct"></param>
        /// <returns></returns>
        public IResource FindBomProductDestination(IBOMProduct bomProduct)
        {
            // By default the destination is the MainStockingPoint
            IResource bomProductDestination = MainStockingPoint;

            IResource feeder = FindBomProductFeeder(bomProduct).FirstOrDefault();

            // Unless this product's feeder is marked as direct storage
            if (feeder != null && DirectStorageResources.Any(resource => resource.Name == feeder.Name))
            {
                bomProductDestination = feeder;
            }

            return bomProductDestination;
        }
    }
}
