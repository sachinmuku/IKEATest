using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Utilities;
using Cmf.Foundation.Services.HostStartup;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;

namespace Cmf.Custom.IKEA.Common
{

    public class IKEAStartupModule : IStartupModule
    {
        public MiddlewarePositioning MiddlewarePositioning => MiddlewarePositioning.EarlyOn;

        public int ServiceRegistrationOrder => 1;

        public void Configure(IApplicationBuilder app, ConfigureMiddlewareContext context)
        {
        }

        public void ConfigureRootServices(IServiceCollection services)
        {
        }

        public void ConfigureServices(IServiceCollection services, ConfigureServicesContext context)
        {
            services.AddTransient<IAlarmHandlingUtilities, AlarmHandlingUtilities>();
            services.AddTransient<IAutomaticMaterialCreationUtilities, AutomaticMaterialCreationUtilities>();
            services.AddTransient<IAutomaticPrintingUtilities, AutomaticPrintingUtilities>();
            services.AddTransient<IBarcodeUtilities, BarcodeUtilities>();
            services.AddTransient<IDirectFeedingUtilities, DirectFeedingUtilities>();
            services.AddTransient<IERPUtilities, ERPUtilities>();
            services.AddTransient<IIKEAUtilities, IKEAUtilities>();
            services.AddTransient<IMaintenanceUtilities, MaintenanceUtilities>();
            services.AddTransient<INiceLabelUtilities, NiceLabelUtilities>();
            services.AddTransient<IPLMUtilities, PLMUtilities>();
            services.AddTransient<IProductionOrderHandlingUtilities, ProductionOrderHandlingUtilities>();
            services.AddTransient<ISPCViolationHandlingUtilities, SPCViolationHandlingUtilities>();
            services.AddTransient<IStockingPointUtilities, StockingPointUtilities>();
            services.AddTransient<IWMSUtilities, WMSUtilities>();
            services.AddTransient<IGenericUtilities, GenericUtilities>();
            services.AddTransient<IDeeContextUtilities, DeeContextUtilities>();
            services.AddTransient<IBOMUtilities, BOMUtilities>();


        }
    }
}