﻿using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Common.Enums
{
    /// <summary>
    /// CustomWMSOrderRequestType Enum
    /// </summary>
    [DataContract(Namespace = "", Name = "CustomWMSOrderRequestType")]
    public enum CustomWMSOrderRequestType
    {
        /// <summary>
        /// None
        /// </summary>
        [EnumMember]
        None = 0,

        /// <summary>
        /// Feed 
        /// </summary>
        [EnumMember]
        Feed = 1,

        /// <summary>
        /// PutAway  
        /// </summary>
        [EnumMember]
        PutAway = 2,

        /// <summary>
        /// Move  
        /// </summary>
        [EnumMember]
        Move = 3,

        /// <summary>
        /// Cancel  
        /// </summary>
        [EnumMember]
        Cancel = 4,
    }
}
