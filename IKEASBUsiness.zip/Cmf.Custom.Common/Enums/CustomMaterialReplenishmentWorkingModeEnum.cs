﻿using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Common.Enums
{
    /// <summary>
    /// CustomMaterialReplenishmentWorkingModeEnum
    /// </summary>
    [DataContract(Namespace = "", Name = "CustomMaterialReplenishmentWorkingModeEnum")]
    public enum CustomMaterialReplenishmentWorkingModeEnum
    {
        /// <summary>
        /// ActiveOrder 
        /// </summary>
        [EnumMember]
        ActiveOrder = 0,

        /// <summary>
        /// AllOrders  
        /// </summary>
        [EnumMember]
        AllOrders = 1,

        /// <summary>
        /// TimeRestricted  
        /// </summary>
        [EnumMember]
        TimeRestricted = 2,
    }
}
