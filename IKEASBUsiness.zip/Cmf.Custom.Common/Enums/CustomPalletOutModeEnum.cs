﻿using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Common.Enums
{
    /// <summary>
    /// CustomPalletOutMode Enum
    /// </summary>
    [DataContract(Namespace = "", Name = "CustomPalletOutModeEnum")]
    public enum CustomPalletOutModeEnum
    {
        /// <summary>
        /// PalletOutSignal 
        /// </summary>
        [EnumMember]
        PalletOutSignal = 0,

        /// <summary>
        /// PieceCount  
        /// </summary>
        [EnumMember]
        PieceCount = 1,

        /// <summary>
        /// MultipleOrdersOutSignal
        /// </summary>
        [EnumMember]
        MultipleOrdersOutSignal = 2,
    }
}
