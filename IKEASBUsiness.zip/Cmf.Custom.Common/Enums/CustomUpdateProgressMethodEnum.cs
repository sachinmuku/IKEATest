﻿using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Common.Enums
{
    /// <summary>
    /// CustomUpdateProgressMethodEnum 
    /// </summary>
    [DataContract(Namespace = "", Name = "")]
    public enum CustomUpdateProgressMethodEnum
    {    
            
    [EnumMember]
    TrackOut=1,

    [EnumMember]
    MoveToNext=2,

    [EnumMember]
    Terminate=3,

    [EnumMember]
    ChangeType=4

    }
}
