﻿using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Common.Enums
{
    /// <summary>
    /// CustomFeederConsumptionModeEnum
    /// </summary>
    [DataContract(Namespace = "", Name = "CustomFeederConsumptionModeEnum")]
    public enum CustomFeederConsumptionModeEnum
    {
        /// <summary>
        /// Sequence Based
        /// The materials will be consumed in sequence without taking into account the Product
        /// </summary>
        [EnumMember]
        SequenceBased = 0,

        /// <summary>
        /// Product Sequence Based 
        /// The materials will be consumed in sequence by the Product
        /// </summary>
        [EnumMember]
        ProductSequenceBased = 1,
    }
}
