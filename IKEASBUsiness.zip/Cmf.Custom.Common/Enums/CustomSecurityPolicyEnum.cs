﻿using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Common.Enums
{
	/// <summary>
	/// CustomSecuriyPolicyEnum
	/// </summary>
	[DataContract(Namespace = "", Name = "CustomSecurityPolicyEnum")]
		public enum CustomSecurityPolicyEnum
		{
			/// <summary>
			/// None 
			/// </summary>
			[EnumMember]
			None = 0,

			/// <summary>
			/// Basic128 
			/// </summary>
			[EnumMember]
			Basic128 = 1,

			/// <summary>
			/// Basic128Rsa15
			/// </summary>
			[EnumMember]
			Basic128Rsa15 = 2,

			/// <summary>
			/// Basic192
			/// </summary>
			[EnumMember]
			Basic192 = 3,

			/// <summary>
			/// Basic192Rsa15
			/// </summary>
			[EnumMember]
			Basic192Rsa15 = 4,

			/// <summary>
			/// Basic256
			/// </summary>
			[EnumMember]
			Basic256 = 5,

			/// <summary>
			/// Basic256Rsa15
			/// </summary>
			[EnumMember]
			Basic256Rsa15 = 6,

			/// <summary>
			/// Basic256Sha256
			/// </summary>
			[EnumMember]
			Basic256Sha256 = 7,

		}
}
