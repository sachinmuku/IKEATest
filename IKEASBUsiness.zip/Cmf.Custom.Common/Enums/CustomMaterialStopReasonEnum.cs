﻿using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Common.Enums
{
    /// <summary>
    /// CustomMaterialStopReason Enum
    /// </summary>
    [DataContract(Namespace = "", Name = "CustomMaterialStopReasonEnum")]
    public enum CustomMaterialStopReasonEnum
    {
        /// <summary>
        /// Complete Material reason
        /// </summary>
        [EnumMember]
        Complete = 0,

        /// <summary>
        /// Abort Material reason 
        /// </summary>
        [EnumMember]
        Abort = 1,

        /// <summary>
        /// EmptyAndAbort reason 
        /// </summary>
        [EnumMember]
        EmptyAndAbort = 2,

        /// <summary>
        /// Command Stop reason 
        /// </summary>
        [EnumMember]
        Stop = 3,
    }
}
