﻿using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Common.Enums
{
    /// <summary>
    /// CustomAutomationTrackingMode Enum
    /// </summary>
    [DataContract(Namespace = "", Name = "CustomAutomationTrackingModeEnum")]
    public enum CustomAutomationTrackingModeEnum
    {
        /// <summary>
        /// ExplicitTracking
        /// </summary>
        [EnumMember]
        ExplicitTracking = 0,

        /// <summary>
        /// ImplicitTracking 
        /// </summary>
        [EnumMember]
        ImplicitTracking = 1,
    }
}
