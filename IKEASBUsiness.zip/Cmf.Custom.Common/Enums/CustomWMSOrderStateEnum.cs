﻿using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Common.Enums
{
    /// <summary>
    /// CustomWMSOrderStateEnum Enum
    /// </summary>
    [DataContract(Namespace = "", Name = "CustomWMSOrderStateEnum")]
    public enum CustomWMSOrderStateEnum
    {
        /// <summary>
        /// Stopped
        /// </summary>
        [EnumMember]
        Stopped = 2,

        /// <summary>
        /// Starting
        /// </summary>
        [EnumMember]
        Starting = 3,

        /// <summary>
        /// Idle
        /// </summary>
        [EnumMember]
        Idle = 4,

        /// <summary>
        /// Suspended
        /// </summary>
        [EnumMember]
        Suspended = 5,

        /// <summary>
        /// Execute
        /// </summary>
        [EnumMember]
        Execute = 6,

        /// <summary>
        /// Stopping
        /// </summary>
        [EnumMember]
        Stopping = 7,

        /// <summary>
        /// Suspending
        /// </summary>
        [EnumMember]
        Suspending = 13,

        /// <summary>
        /// Unsuspending
        /// </summary>
        [EnumMember]
        Unsuspending = 14,

        /// <summary>
        /// Resetting
        /// </summary>
        [EnumMember]
        Resetting = 15,

        /// <summary>
        /// Completing
        /// </summary>
        [EnumMember]
        Completing = 16,

        /// <summary>
        /// Complete
        /// </summary>
        [EnumMember]
        Complete = 17,

    }
}
