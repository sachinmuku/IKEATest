﻿using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Common.Enums
{
    /// <summary>
    /// CustomAutomationTrackingMode Enum
    /// </summary>
    [DataContract(Namespace = "", Name = "")]
    public enum CustomAdHocMAOResourceLevelEnum
    {
        /// <summary>
        /// ParentAndSubResource
        /// </summary>
        [EnumMember]
        ParentAndSubResource = 0,

        /// <summary>
        /// SubResource 
        /// </summary>
        [EnumMember]
        SubResource = 1,
    }
}
