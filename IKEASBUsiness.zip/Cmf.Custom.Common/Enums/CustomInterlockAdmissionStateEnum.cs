﻿using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Common.Enums
{
    /// <summary>
    /// CustomInterlockAdmissionState Enum
    /// </summary>
    [DataContract(Namespace = "", Name = "CustomInterlockAdmissionStateEnum")]
    public enum CustomInterlockAdmissionStateEnum
    {

        /// <summary>
        /// Undefined
        /// </summary>
        [EnumMember]
        Undefined = 0,

        /// <summary>
        /// Closed
        /// </summary>
        [EnumMember]
        Closed = 1,

        /// <summary>
        /// Open
        /// </summary>
        [EnumMember]
        Open = 2,
    }
}