﻿using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Common.Enums
{
    /// <summary>
    /// CustomGroupOrderStateEnum Enum
    /// </summary>
    [DataContract(Namespace = "", Name = "CustomGroupOrderStateEnum")]
    public enum CustomGroupOrderStateEnum
    {
        /// <summary>
        /// Created
        /// </summary>
        [EnumMember]
        Created = 0,

        /// <summary>
        /// WaitingForHPO
        /// </summary>
        [EnumMember]
        WaitingForHPO = 1,

        /// <summary>
        /// WaitingForERP
        /// </summary>
        [EnumMember]
        WaitingForERP = 2,

        /// <summary>
        /// WaitingForOperator
        /// </summary>
        [EnumMember]
        WaitingForOperator = 4,

        /// <summary>
        /// Ready
        /// </summary>
        [EnumMember]
        Ready = 3
    }
}