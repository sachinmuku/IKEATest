﻿using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Common.Enums
{
    /// <summary>
    /// CustomAutoDispatchExceptionBehavior Enum
    /// </summary>
    [DataContract(Namespace = "", Name = "CustomAutoDispatchExceptionBehaviorEnum")]
    public enum CustomAutoDispatchExceptionBehaviorEnum
    {
        /// <summary>
        /// Force Dispatch
        /// </summary>
        [EnumMember]
        ForceDispatch = 0,

        /// <summary>
        /// Notify And Don't Dispatch
        /// </summary>
        [EnumMember]
        NotifyAndDontDispatch = 1,

        /// <summary>
        /// Auto Dispatch To Other equipment
        /// </summary>
        [EnumMember]
        AutoDispatchToOther = 2
    }
}