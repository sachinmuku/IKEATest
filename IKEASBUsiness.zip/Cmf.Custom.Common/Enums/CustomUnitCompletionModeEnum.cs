﻿using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Common.Enums
{
    /// <summary>
    /// CustomUnitCompletionModeEnum
    /// </summary>
    [DataContract(Namespace = "", Name = "CustomUnitCompletionModeEnum")]
    public enum CustomUnitCompletionModeEnum
    {
        /// <summary>
        /// Automation  
        /// </summary>
        [EnumMember]
        Manual = 0,

        /// <summary>
        /// ManualOutsorting 
        /// </summary>
        [EnumMember]
        ManualOutsorting = 1,

        /// <summary>
        /// Automation  
        /// </summary>
        [EnumMember]
        Automation = 2,

    }
}
