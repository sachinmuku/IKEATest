﻿using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Common.Enums
{
    [DataContract(Namespace = "", Name = "CustomMicrostopThresholdFilterEnum")]
    public enum CustomMicrostopThresholdFilterEnum
    {
        /// <summary>
        /// Display all stops, including those that have no threshold defined
        /// </summary>
        [EnumMember]
        All = 0,

        /// <summary>
        /// Display all stops, including those that have no threshold defined but excluding microstops
        /// </summary>
        [EnumMember]
        ExcludeMicrostops = 1,

        /// <summary>
        /// Display only microstops
        /// </summary>
        [EnumMember]
        OnlyMicrostops = 2,

        /// <summary>
        /// Display only stops that have a duration longer than the defined threshold
        /// </summary>
        [EnumMember]
        LongerThanThreshold = 3
    }
}
