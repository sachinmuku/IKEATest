﻿using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Common.Enums
{
    /// <summary>
    /// CustomAlarmOccurrenceOperationEnum
    /// </summary>
    [DataContract(Namespace = "", Name = "CustomAlarmOccurrenceOperationEnum")]
    public enum CustomAlarmOccurrenceOperationEnum
    {
        /// <summary>
        /// Create Operation
        /// </summary>
        [EnumMember]
        ToCreate = 0,

        /// <summary>
        /// Acknowledge Operation
        /// </summary>
        [EnumMember]
        ToUpdate = 1,

        /// <summary>
        /// End Operation
        /// </summary>
        [EnumMember]
        ToEnd = 2,
    }
}
