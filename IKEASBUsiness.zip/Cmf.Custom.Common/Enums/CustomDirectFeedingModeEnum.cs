﻿using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Common.Enums
{
    /// <summary>
    /// CustomDirectFeedingModeEnum
    /// </summary>
    [DataContract(Namespace = "", Name = "CustomDirectFeedingModeEnum")]
    public enum CustomDirectFeedingModeEnum
    {
        /// <summary>
        /// Storage Mode
        /// </summary>
        [EnumMember]
        Storage = 0,

        /// <summary>
        /// Direct Feeding Mode
        /// </summary>
        [EnumMember]
        DirectFeeding = 1,
    }
}