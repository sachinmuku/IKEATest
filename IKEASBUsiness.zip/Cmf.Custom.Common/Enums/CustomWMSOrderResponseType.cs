﻿using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Common.Enums
{
    /// <summary>
    /// CustomWMSOrderResponseType Enum
    /// </summary>
    [DataContract(Namespace = "", Name = "CustomWMSOrderResponseType")]
    public enum CustomWMSOrderResponseType
    {
        /// <summary>
        /// Accepted
        /// </summary>
        [EnumMember]
        Accepted = 3,

        /// <summary>
        /// Rejected  
        /// </summary>
        [EnumMember]
        Rejected = 9,

    }
}
