﻿using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Common.Enums
{
    /// <summary>
    /// CustomConsumptionModeEnum
    /// </summary>
    [DataContract(Namespace = "", Name = "CustomConsumptionModeEnum")]
    public enum CustomConsumptionModeEnum
    {
        /// <summary>
        /// DirectConsumption 
        /// </summary>
        [EnumMember]
        DirectConsumption = 0,

        /// <summary>
        /// SplitAndConsume  
        /// </summary>
        [EnumMember]
        SplitAndConsume = 1,

        /// <summary>
        /// DistributedConsumption for multiple feeders  
        /// </summary>
        [EnumMember]
        DistributedConsumption = 2,
    }
}
