﻿using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Common.Enums
{
	/// <summary>
	/// CustomSecurityModeEnum
	/// </summary>
	[DataContract(Namespace = "", Name = "CustomSecurityModeEnum")]
	public enum CustomSecurityModeEnum
	{
		/// <summary>
		/// None 
		/// </summary>
		[EnumMember]
		None = 0,

		/// <summary>
		/// None 
		/// </summary>
		[EnumMember]
		Sign = 1,

		/// <summary>
		/// None 
		/// </summary>
		[EnumMember]
		SignAndEncrypt = 2,

		/// <summary>
		/// None 
		/// </summary>
		[EnumMember]
		All = 3,



	}
}
