﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace Cmf.Custom.IKEA.Common.Enums
{
    /// <summary>
    /// CustomPrintingQueuePosition Enum
    /// </summary>
    [DataContract(Namespace = "", Name = "CustomPrintingQueuePosition")]
    public enum CustomPrintingQueuePosition
    {
        /// <summary>
        /// Head 
        /// </summary>
        [EnumMember]
        Head = 0,

        /// <summary>
        /// Tail 
        /// </summary>
        [EnumMember]
        Tail = 1,
    }
}
