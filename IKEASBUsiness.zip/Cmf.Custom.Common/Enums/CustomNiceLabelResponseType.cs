﻿using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Common.Enums
{
    /// <summary>
    /// CustomNiceLabelOrderResponseType Enum
    /// </summary>
    [DataContract(Namespace = "", Name = "CustomNiceLabelResponseType")]
    public enum CustomNiceLabelResponseType
    {
        /// <summary>
        /// Accepted
        /// </summary>
        [EnumMember]
        Accepted = 0,

        /// <summary>
        /// Rejected  
        /// </summary>
        [EnumMember]
        Rejected = 1,

    }
}
