﻿using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Common.Enums
{
    /// <summary>
    /// CustomPrintingOptions Enum
    /// </summary>
    [DataContract(Namespace = "", Name = "CustomPrintingOptionsEnum")]
    public enum CustomPrintingOptionsEnum
    {
        /// <summary>
        /// None
        /// </summary>
        [EnumMember]
        None = 0,

        /// <summary>
        /// Label
        /// </summary>
        [EnumMember]
        Label = 1,

        /// <summary>
        /// RFId
        /// </summary>
        [EnumMember]
        RFId = 2,

        /// <summary>
        /// Both
        /// </summary>
        [EnumMember]
        Both = 3
    }
}