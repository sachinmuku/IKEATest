﻿using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Common.Enums
{
    /// <summary>
    /// CustomMaterialReplenishmentRequestModeEnum
    /// </summary>
    [DataContract(Namespace = "", Name = "CustomMaterialReplenishmentRequestModeEnum")]
    public enum CustomMaterialReplenishmentRequestModeEnum
    {
        /// <summary>
        /// Manual 
        /// </summary>
        [EnumMember]
        Manual = 0,

        /// <summary>
        /// ERP  
        /// </summary>
        [EnumMember]
        ERP = 1,

        /// <summary>
        /// Automated  
        /// </summary>
        [EnumMember]
        Automated = 2,
    }
}
