﻿using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Common.Enums
{
    /// <summary>
    /// CustomPalletOutMode Enum
    /// </summary>
    [DataContract(Namespace = "", Name = "CustomAutomationCompletionCounterTypeEnum")]
    public enum CustomAutomationCompletionCounterTypeEnum
    {
        /// <summary>
        /// PalletOutSignal 
        /// </summary>
        [EnumMember]
        ConsumedCounter = 0,

        /// <summary>
        /// PieceCount  
        /// </summary>
        [EnumMember]
        ProducedCounter = 1,
    }
}
