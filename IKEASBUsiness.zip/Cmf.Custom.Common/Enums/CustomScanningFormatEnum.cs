﻿using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Common.Enums
{
    /// <summary>
    /// CustomScanningFormatEnum Enum
    /// </summary>
    [DataContract(Namespace = "", Name = "CustomScanningFormatEnum")]
    public enum CustomScanningFormatEnum
    {
        /// <summary>
        /// None
        /// </summary>
        [EnumMember]
        None = 0,

        /// <summary>
        /// Standard 
        /// </summary>
        [EnumMember]
        Standard = 1,

        /// <summary>
        /// CharacterCode 
        /// </summary>
        [EnumMember]
        CharacterCode = 2,

        /// <summary>
        /// Custom 
        /// </summary>
        [EnumMember]
        Custom = 3,

        /// <summary>
        /// LengthBased  
        /// </summary>
        [EnumMember]
        LengthBased = 4
    }
}
