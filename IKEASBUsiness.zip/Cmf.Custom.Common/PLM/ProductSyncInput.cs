﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Cmf.Custom.IKEA.Common.PLM
{
    public class ProductSyncInput
    {
        /// <summary>
        /// The Product's Base Name (from ProcessItemMaster.DataArea.ItemMaster.ItemMasterHeader.ItemID.ID)
        /// </summary>
        public string BaseName { get; set; }

        /// <summary>
        /// The revision number (from ProcessItemMaster.DataArea.ItemMaster.ItemMasterHeader.ItemID.RevisionID)
        /// </summary>
        public int Revision { get; set; }

        /// <summary>
        /// The name of the Product Revision
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Product description (from ProcessItemMaster.DataArea.ItemMaster.ItemMasterHeader.Description)
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Product Item Group (from ProcessItemMaster.DataArea.ItemMaster.ItemMasterHeader.Classification.Codes[listID="Item Groups"])
        /// </summary>
        public string AttributeItemGroup { get; set; }

        /// <summary>
        /// Product Group (from ProcessItemMaster.DataArea.ItemMaster.ItemMasterHeader.Classification.Codes[listID="Product Groups"])
        /// </summary>
        public string AttributeProductGroup { get; set; }

        /// <summary>
        /// Product Item Type (from ProcessItemMaster.DataArea.ItemMaster.ItemMasterHeader.Classification.Codes[listID="Item Types"])
        /// </summary>
        public string AttributeItemType { get; set; }

        /// <summary>
        /// Product Item Description (from ProcessItemMaster.DataArea.ItemMaster.ItemMasterHeader.UserArea.Property[.NameValue[name="FUDS"]])
        /// </summary>
        public string AttributeItemDescription { get; set; }

        /// <summary>
        /// Default units (from ProcessItemMaster.DataArea.ItemMaster.ItemMasterHeader.BaseUOMCode)
        /// </summary>
        public string DefaultUnits { get; set; }

        /// <summary>
        /// Facility Name (derived from ERP Code from ProcessItemMaster.DataArea.ItemMaster.ItemMasterHeader.UserArea.Property[.NameValue[name="FACI"]])
        /// </summary>
        public string FacilityName { get; set; }

        // TODO Implement Product Parameters when PLM implementations moves forward

        /// <summary>
        /// Dictionary of Unit -> Conversion Factor
        /// 
        /// The list of Unit Names are retrieved from ProcessItemMaster.DataArea.ItemMaster.ItemMasterHeader.UserArea.Property[.NameValue[name="ALUN"]]
        /// and are separated by commas
        /// 
        /// Each conversion factor then can be retrieved from
        /// ProcessItemMaster.DataArea.ItemMaster.ItemMasterHeader.UserArea.Property[.NameValue[name="Calc" + Unit]]
        /// </summary>
        public Dictionary<string, decimal> AlternateUnitConversions { get; set; }

        /// <summary>
        /// Product Width Measure (from ProcessItemMaster.DataArea.ItemMaster.ItemMasterHeader.PackagingUnit.Dimensions.WidthMeasure)
        /// </summary>
        public decimal WidthMeasure { get; set; }

        /// <summary>
        /// Product Height Measure (from ProcessItemMaster.DataArea.ItemMaster.ItemMasterHeader.PackagingUnit.Dimensions.HeightMeasure)
        /// </summary>
        public decimal HeightMeasure { get; set; }

        /// <summary>
        /// Product Length Measure (from ProcessItemMaster.DataArea.ItemMaster.ItemMasterHeader.PackagingUnit.Dimensions.LengthMeasure)
        /// </summary>
        public decimal LengthMeasure { get; set; }
    }
}
