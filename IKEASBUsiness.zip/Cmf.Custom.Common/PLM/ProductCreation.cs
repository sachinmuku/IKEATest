﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.PLM.Communication;
using Cmf.Foundation.Common;
using Microsoft.Extensions.DependencyInjection;

namespace Cmf.Custom.IKEA.Common.PLM
{
    public class ProductCreation
    {
        private static IGenericUtilities genericUtilities => ApplicationContext.CurrentServiceProvider.GetService<IGenericUtilities>();

        public ProcessItemMasterType ProcessItemMaster { get; set; }

        /// <summary>
        /// Constructor that accepts an XML string and deserializes it into a ProcessItemMasterType
        /// </summary>
        /// <param name="xml"></param>
        public ProductCreation (string xml)
        {
            ProcessItemMaster = genericUtilities.DeserializeXmlToObject<ProcessItemMasterType>(xml);
        }

        /// <summary>
        /// Constructor that accepts an XML Node and deserializes it into a ProcessItemMasterType
        /// </summary>
        /// <param name="xml"></param>
        public ProductCreation(XmlNode xml)
        {
            ProcessItemMaster = genericUtilities.DeserializeXmlToObject<ProcessItemMasterType>(xml);
        }

        /// <summary>
        /// Constructor that accepts an instance of a ProcessItemMasterType
        /// </summary>
        /// <param name="xml"></param>
        public ProductCreation(ProcessItemMasterType processItemMaster)
        {
            ProcessItemMaster = processItemMaster;
        }

        /// <summary>
        /// Gets the first ItemMasterHeader instance
        /// </summary>
        /// <returns></returns>
        public ItemMasterHeaderType GetItemMasterHeader() {
            return ProcessItemMaster.DataArea.ItemMaster[0].ItemMasterHeader;
        }

        /// <summary>
        /// Gets the first item with a ItemElementName equal to enumValue on a matching position, and casts it to T
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="enumValue"></param>
        /// <returns></returns>
        public T GetItem<T> (ItemsChoiceType enumValue) {
            ItemMasterHeaderType itemMasterHeader = GetItemMasterHeader();

            T item = default(T);

            for (int i = 0; i < itemMasterHeader.Items.Length; i++)
            {
                if (itemMasterHeader.ItemsElementName[i] == enumValue)
                {
                    item = (T)itemMasterHeader.Items[i];
                    break;
                }
            }

            return item;
        }

        /// <summary>
        /// Returns the classification code's value for the given listID
        /// </summary>
        /// <param name="listID"></param>
        /// <returns></returns>
        public string GetClassificationCode(string listID)
        {
            ItemMasterHeaderType itemMasterHeader = GetItemMasterHeader();

            return itemMasterHeader.Classification[0].Codes.FirstOrDefault(code => code.listID == listID)?.Value;
        }

        /// <summary>
        /// Tests if the given XmlElement is a property with the given name
        /// </summary>
        /// <param name="element"></param>
        /// <param name="name"></param>
        /// <returns></returns>
        protected bool IsPropertyElement(XmlElement element, string name)
        {
            if (element.Name != "Property" || !element.HasChildNodes) {
                return false;
            }

            for (int i = 0; i < element.ChildNodes.Count; i++)
            {
                XmlNode childNode = element.ChildNodes.Item(i);

                if (childNode.Name == "NameValue" && childNode.Attributes.GetNamedItem("name")?.Value == name)
                {
                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// Returns the property value that has the provided name
        /// </summary>
        /// <param name="element"></param>
        /// <param name="name"></param>
        /// <returns></returns>
        public string GetProperty(string name, string defaultValue = null)
        {
            ItemMasterHeaderType itemMasterHeader = GetItemMasterHeader();

            XmlElement propertyElement = itemMasterHeader.UserArea.Any.FirstOrDefault(elem => IsPropertyElement(elem, name));

            if (propertyElement != null)
            {
                for (int i = 0; i < propertyElement.ChildNodes.Count; i++)
                {
                    XmlNode childNode = propertyElement.ChildNodes.Item(i);

                    if (childNode.Name == "NameValue" && childNode.Attributes.GetNamedItem("name")?.Value == name)
                    {
                        return childNode.InnerText;
                    }
                }
            }

            return defaultValue;
        }

        /// <summary>
        /// Returns the first description it finds. If no description is found, returns null instead
        /// </summary>
        /// <returns></returns>
        public string GetDescription()
        {
            ItemMasterHeaderType itemMasterHeader = GetItemMasterHeader();

            if (itemMasterHeader.Description.Length > 0)
            {
                return itemMasterHeader.Description[0].Value;
            }

            return null;
        }

        /// <summary>
        /// Return the instance of the first Dimensions object
        /// </summary>
        /// <returns></returns>
        public DimensionsType GetDimensions ()
        {
            return GetItemMasterHeader().PackagingUnit[0].Dimensions;
        }
    }
}
