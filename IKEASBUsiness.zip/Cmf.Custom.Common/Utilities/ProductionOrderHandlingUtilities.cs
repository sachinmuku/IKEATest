﻿using Cmf.Common.CustomActionUtilities;

using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.ERP;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.QueryObject;
using Cmf.Foundation.BusinessObjects.SmartTables;
using Cmf.Foundation.BusinessOrchestration.TableManagement;
using Cmf.Foundation.Common;
using Cmf.Foundation.Security;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessOrchestration.OrderManagement;
using Cmf.Navigo.BusinessOrchestration.OrderManagement.InputObjects;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Xml;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Foundation.Security.Abstractions;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Foundation.BusinessOrchestration.Abstractions;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Foundation.Common.LocalizationService;
using Cmf.Navigo.BusinessOrchestration.Abstractions;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common.Exceptions;
using Cmf.Custom.IKEA.Common.Extensions;
using INotification = Cmf.Foundation.BusinessObjects.Abstractions.INotification;
using Cmf.Custom.IKEA.Common.Enums;

namespace Cmf.Custom.IKEA.Common.Utilities
{
    /// <summary>
    /// This partial class contains utilties for handling ProductionOrder related events
    /// </summary>
    public class ProductionOrderHandlingUtilities : IProductionOrderHandlingUtilities
    {
        private IEntityFactory _entityFactory;
        private IIKEAUtilities _iKEAUtilities;
        private IGenericUtilities _genericUtilities;
        private IGenericServiceOrchestration _genericServiceOrchestration;
        private ITableOrchestration _tableOrchestration;
        private IOrderOrchestration _orderOrchestration;
        //private IMaterialOrchestration _materialOrchestration;
        private ILocalizationService _localizationService;
        private IDeeContextUtilities _deeContextUtilities;

        [Microsoft.Extensions.DependencyInjection.ActivatorUtilitiesConstructor]
        public ProductionOrderHandlingUtilities(IEntityFactory entityFactory,
            IGenericUtilities genericUtilities,
            IGenericServiceOrchestration genericServiceOrchestration,
            IIKEAUtilities iKEAUtilities,
            ILocalizationService localizationService,
            IDeeContextUtilities deeContextUtilities,
            IOrderOrchestration orderOrchestration,
            ITableOrchestration tableOrchestration)
        {
            _entityFactory = entityFactory;
            _genericUtilities = genericUtilities;
            _genericServiceOrchestration = genericServiceOrchestration;
            _iKEAUtilities = iKEAUtilities;
            _localizationService = localizationService;
            _deeContextUtilities = deeContextUtilities;
            _orderOrchestration = orderOrchestration;
            _tableOrchestration = tableOrchestration;
        }
        /// <summary>
        /// Checks if production order is active and not started yet
        /// </summary>
        /// <param name="productionOrder"></param>
        /// <returns></returns>
        private bool IsProductionOrderActiveAndNotStarted(IProductionOrder productionOrder)
        {
            bool returnValue = true;

            if (productionOrder != null)
            {
                // check if production order is still in created or released mode.
                returnValue = (productionOrder.SystemState == ProductionOrderSystemState.Created || productionOrder.SystemState == ProductionOrderSystemState.Released || productionOrder.SystemState == ProductionOrderSystemState.InProgress);

                // if in created or released mode...
                if (returnValue)
                {
                    // ... check if any quantities have already been completed
                    returnValue = !(productionOrder.CompletedQuantity > 0);

                    // if no completed quantity produced... 
                    if (returnValue)
                    {
                        // ... check planned quantity against existing materials to determine if changes have occurred
                        productionOrder.LoadMaterials();
                        if (productionOrder.Materials != null && productionOrder.Materials.Count > 0)
                        {
                            decimal totalMaterialQuantity = productionOrder.Materials.Sum(E => E.PrimaryQuantity ?? 0);
                            returnValue = (totalMaterialQuantity == productionOrder.Quantity);
                            if (returnValue)
                            {
                                // all materials must not be in process or processed and must still be in the POs starting flow path
                                returnValue = productionOrder.Materials.All(E => (E.SystemState == MaterialSystemState.Queued || E.SystemState == MaterialSystemState.Dispatched)
                                                                                && String.Equals(productionOrder.FlowPath, E.FlowPath, StringComparison.InvariantCultureIgnoreCase));
                            }
                        }
                    }

                }
            }

            return returnValue;
        }

        /// <summary>
        /// Checks if production order can be closed
        /// </summary>
        /// <param name="productionOrder">Production Order To validate</param>
        /// <returns>Can PO be closed?</returns>
        private bool CanProductionOrderBeClosed(IProductionOrder productionOrder)
        {
            bool returnValue = true;

            if (productionOrder != null)
            {
                string orderForm = _iKEAUtilities.GetOrderMaterialForm();

                // Get all materials of a production order
                productionOrder.LoadMaterials();

                if (productionOrder.Materials != null && productionOrder.Materials.Count > 0)
                {
                    returnValue = !productionOrder.Materials.Any(m => !m.Form.CompareStrings(orderForm) || m.SystemState != MaterialSystemState.Queued);
                }
            }

            return returnValue;
        }

        /// <summary>
        /// Convert a given name with a specific Date format to a DateTime
        /// </summary>
        /// <param name="stringDate">String with a date</param>
        /// <param name="stringTime">String with a time</param>
        /// <param name="dateFormat">Format of the given date (default: "yyyyMMddHHmmss")</param>
        /// <returns>Null if it wasn't able to convert the date, otherwise returns a DateTime with the give date</returns>
        public DateTime? ConvertStringToDateTime(string stringDate, string stringTime, string dateFormat = "yyyyMMddHHmmss")
        {
            DateTime? convertedDate = null;
            DateTime date;
            bool increaseDay = false;

            if (stringTime.StartsWith("24"))
            {
                increaseDay = true;
                stringTime = new StringBuilder(stringTime).Remove(0, 2).Insert(0, "00").ToString();
            }

            if (DateTime.TryParseExact(stringDate + stringTime, dateFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out date))
            {
                convertedDate = increaseDay ? date.AddDays(1) : date;
            }

            return convertedDate;
        }

        /// <summary>
        /// Checks status of ERP Production Order against PO to be created / updated on MES Side
        /// </summary>
        /// <param name="poName">Name of the Production Order to check</param>
        /// <param name="poStatus">ERP Status Code in which the Production Order is</param>
        /// <param name="integrationEntryName">Name of the integration entry where the PO was received</param>
        /// <returns>True if PO Creation / Update should proceed. False otherwise</returns>
        public bool ValidatePOStatus(string poName, string poStatus, string integrationEntryName)
        {
            // by default, decision is that PO Creation / Update should proceed.
            bool returnValue = true;

            if (!String.IsNullOrWhiteSpace(poName))
            {
                // check if a notification is to be sent
                bool isToNotify = false;

                // consider by default that it's a new Production Order
                bool isNewProductionOrder = true;

                // Check if ProductionOrder exists
                IProductionOrder poToHandle = _entityFactory.Create<IProductionOrder>();
                poToHandle.Name = poName;
                isNewProductionOrder = !poToHandle.ObjectExists();

                // Handle existing POs
                if (!isNewProductionOrder)
                {
                    // Load PO object if it exists
                    poToHandle.Load();
                }

                // Determine if PO can be changed
                bool isPOOperateable = (isNewProductionOrder || IsProductionOrderActiveAndNotStarted(poToHandle));

                // check the different situations on order status
                switch (poStatus)
                {
                    case "20":  // RELEASED IN ERP. MEANS AN UPDATE WAS SENT OR IT'S A NEW PO

                        // if dealing with an update, can only proceed if order is still in created or released state
                        if (!isNewProductionOrder && !isPOOperateable)
                        {
                            returnValue = false;
                            isToNotify = true;
                        }

                        break;

                    case "24":  // CANCELLED IN ERP

                        // if it's a new PO and already has been cancelled there is nothing to do...
                        // if it's not new, we must check if we can cancel it
                        if (!isNewProductionOrder)
                        {
                            if (isPOOperateable)
                            {
                                _deeContextUtilities.SetContextParameter(IKEAConstants.ValidatePOStatusCancelingPO, true);
                                var poCollection = _entityFactory.CreateCollection<IProductionOrderCollection>();
                                poCollection.Add(poToHandle);
                                _orderOrchestration.CancelProductionOrders(new CancelProductionOrdersInput()
                                {
                                    ProductionOrders = poCollection
                                });

                                _deeContextUtilities.SetContextParameter(IKEAConstants.ValidatePOStatusCancelingPO, null);
                            }
                            else
                            {
                                isToNotify = true;
                            }
                        }

                        returnValue = false;
                        break;

                    case "90":  // CLOSED IN ERP

                        // if it's a new PO and already has been closed there is nothing to do...
                        // if it's not new, we must check if we can close it
                        if (!isNewProductionOrder)
                        {
                            if (CanProductionOrderBeClosed(poToHandle))
                            {

                                // If the PO is not in the state completed then we need to terminate all the materials
                                // and call the change PO quantity to set the PO to completed
                                if (poToHandle.Materials != null && poToHandle.Materials.Count > 0)
                                {
                                    var poCollectionMaterials = _entityFactory.CreateCollection<IProductionOrderCollection>();

                                    IReason reason = _entityFactory.Create<IReason>();
                                    reason.Name = IKEAConstants.ERPTerminatedDefaultReason;

                                    reason.Load();

                                    poToHandle.Materials.Terminate(reason);
                                    poToHandle.Materials.ChangeProductionOrder(poToHandle.Materials.ToDictionary(mat => mat, _ => (IProductionOrder)null));

                                    poToHandle.Load();
                                    poCollectionMaterials.Add(poToHandle);
                                    ChangeProductionOrdersProductAndQuantityInput input = new ChangeProductionOrdersProductAndQuantityInput()
                                    {
                                        ProductionOrders = poCollectionMaterials,
                                        NewProductsAndQuantities = new Dictionary<long, IProductionOrderProductAndQuantityChange>()
                                        {
                                            { poToHandle.Id, new ProductionOrderProductAndQuantityChange() { NewProduct = poToHandle.Product, NewQuantity = poToHandle.Quantity } }
                                        }
                                    };

                                    _orderOrchestration.ChangeProductionOrdersProductAndQuantity(input);

                                    poToHandle.Load();
                                }
                                var poCollection = _entityFactory.CreateCollection<IProductionOrderCollection>();

                                if (poToHandle.SystemState == ProductionOrderSystemState.Completed)
                                {

                                    poCollection.Add(poToHandle);
                                    _orderOrchestration.CloseProductionOrders(new CloseProductionOrdersInput()
                                    {
                                        ProductionOrders = poCollection,
                                        TerminateProductionOrders = true
                                    });
                                }
                                else
                                {
                                    poCollection.Add(poToHandle);
                                    _orderOrchestration.CancelProductionOrders(new CancelProductionOrdersInput()
                                    {

                                        ProductionOrders = poCollection
                                    });
                                }
                            }
                            else
                            {
                                isToNotify = true;
                            }
                        }

                        returnValue = false;
                        break;

                    default:
                        if (Convert.ToInt32(poStatus) > 20 && Convert.ToInt32(poStatus) < 80)
                        {
                            // if dealing with an update, can only proceed if order is still in created or released state
                            if (!isNewProductionOrder && !isPOOperateable)
                            {
                                returnValue = false;
                                isToNotify = true;
                            }
                        }
                        else
                        {
                            //When the received code is not recognized, do not update the PO
                            returnValue = false;
                            isToNotify = true;
                        }

                        break;
                }

                if (isToNotify)
                {
                    if (!isNewProductionOrder)
                    {
                        // Get notification role. if not defined, use administrators
                        string notificationRoleName = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.OrderHandlingNotificationRole);
                        if (!String.IsNullOrWhiteSpace(notificationRoleName))
                        {
                            notificationRoleName = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.AdministrationRole);
                        }
                        IRole notificationRoleToUse = new Role();
                        notificationRoleToUse.Load(notificationRoleName);


                        // get notification Subject
                        string notificationSubject = _iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomERPOrderCannotBeChangedSubject, poName);

                        // get notification body
                        string notificationBody = _iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomERPOrderCannotBeChangedMessage, poName, integrationEntryName, poToHandle.SystemState.ToString());

                        //Validate if Severity exists in config
                        string severity = _iKEAUtilities.GetValueFromConfigurationWithPath(IKEAConstants.DefaultNotificationSeverityConfig);

                        if (severity.IsNullOrEmpty())
                        {
                            throw new IKEAException(IKEAConstants.CustomDefaultNotificationSeverityConfigNotDefined, IKEAConstants.DefaultNotificationSeverityConfig);
                        }

                        INotification notification = _entityFactory.Create<INotification>();
                        notification.Type = "System";
                        notification.Title = notificationSubject;
                        notification.Details = notificationBody;
                        notification.Severity = _iKEAUtilities.GetValueFromLookupTable(IKEAConstants.NotificationSeverityLookupTableName, severity, true);
                        notification.AssignmentType = (NotificationAssignmentType)AssignmentType.Role;
                        notification.AssignedToRole = notificationRoleToUse;
                        notification.SendEmailToAssignedParty = true;
                        notification.Create();

                    }
                }
            }

            return returnValue;
        }

        #region ERP

        /// <summary>
        /// Creates a new IntegrationEntry containing the Product and quantity to request to the ERP.
        /// The ERP should create a new Production Order.
        /// This method should be invoked after receivinf the file From HPO
        /// </summary>
        /// <param name="groupMO"></param>
        /// <param name="facilityName"></param>
        /// <param name="product"></param>
        /// <param name="quantity"></param>
        /// <returns>IntegrationEntry</returns>
        public IIntegrationEntry RequestERPProductionOrder(IMaterial groupMO, string facilityERPIdentifier, IProduct product, decimal quantity, bool updateGroupState = true)
        {

            // Get the configurations for the request production order:
            string productStructureType = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.ERPRequestOrderProductStructureTypeConfig);

            string status = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.ERPRequestOrderStatusConfig);

            string responsible = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.ErpResponsibleConfig);

            string orderType = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.ERPRequestOrderTypeConfig);


            //The company field is filled by calling the parent constructor
            NewProductionOrderRequest request = new NewProductionOrderRequest()
            {
                Facility = facilityERPIdentifier,
                ProductNumber = product.GetRelatedAttributeValueOrDefault<string>(IKEAConstants.CustomProductAttributeBaseProduct, true) ?? product.Name,
                AlternateUnits = product.DefaultUnits,
                ProductStructureType = productStructureType,
                OrderedQuantityAlt = quantity.ToString(),
                Status = status,
                StartDate = DateTime.Now.Date.ToString("yyyyMMdd"),
                Responsible = responsible,
                OrderType = orderType
            };

            if (updateGroupState)
            {
                // Update the state of the optimized GroupMO to WaitingForERP:
                IAttributeCollection waitingForERPAttribute = new AttributeCollection
                {
                    { IKEAConstants.CustomMaterialAttributeGroupOrderState, CustomGroupOrderStateEnum.WaitingForERP }
                };
                groupMO.SaveAttributes(waitingForERPAttribute);
            }


            return CreateProductionOrderRequestIntegrationEntry(groupMO.Name, request);
        }

        /// <summary>
        /// Creates an IntegrationEntry for requesting a new Production Order.
        /// </summary>
        /// <param name="productName"></param>
        /// <param name="quantity"></param>
        /// <param name="request"></param>
        /// <returns>IntegrationEntry</returns>
        public IIntegrationEntry CreateProductionOrderRequestIntegrationEntry(string groupMOName, NewProductionOrderRequest request)
        {
            string requestEndpoint = IKEAConstants.ERPRequestProductionOrder;

            string jsonMessage = JsonConvert.SerializeObject(request);

            NewProductionOrderRequestCommunication communication = new NewProductionOrderRequestCommunication()
            {
                API = requestEndpoint,
                GroupMoName = groupMOName,
                Message = jsonMessage
            };

            XmlDocument xmlDoc = communication.SerializeToXMLDocument();

            return _iKEAUtilities.CreateIntegrationEntry(IKEAConstants.MESSystem, IKEAConstants.ERPSystem, IKEAConstants.ERPRequestProductionOrderMessageType, IKEAConstants.ERPRequestProductionOrderEventName, xmlDoc);
        }

        #endregion


        /// <summary>
        /// Creates a single Material Order (MO) from a orderless Production Order (PO).
        /// This material is dispatched on the specified resource and returned.
        /// </summary>
        /// <param name="resource">Resource</param>
        /// <param name="orderlessCreation">OrderlessCreation</param>
        /// <returns>Material</returns>
        public IMaterial CreateSingleOrderless(IResource resource, OrderlessCreation orderlessCreation)
        {
            //Load the information given on the parameters
            resource.Load();

            IProduct product = orderlessCreation.Product;
            product.Load();

            IBOM bom = orderlessCreation.BOM;
            decimal quantity = orderlessCreation.Quantity;

            IProductionOrder po = null;

            #region Storage variables for data

            string poName = null;
            string poType = null;
            string description = null;
            string workCenterName = "";
            string reportingWarehouse = null;
            string scheduleNumber = null;
            string structureType = null;

            #endregion

            #region Get PO values

            INameGenerator productOrderNameGenerator = _entityFactory.Create<INameGenerator>();
            productOrderNameGenerator.Load(IKEAConstants.CustomProductOrderlessNameGenerator);

            poName = productOrderNameGenerator.GenerateName(IKEAConstants.CustomProductOrderlessNameGenerator);

            //Create new production order
            po = _entityFactory.Create<IProductionOrder>();
            po.Name = poName;


            resource.Area.Load();

            IFacility facility = resource.Area.Facility;
            facility.Load();

            string flowpath;
            IFlow flow;
            IStep step;

            product.Flow.Load();
            product.Step.Load();

            //Get Material flow and step
            var materialFlows = _genericUtilities.ResolveAllMaterialFlows(facility, product, resource, product.Type, null);
            if (materialFlows != null && !materialFlows.Item1.IsNullOrEmpty())
            {
                flowpath = materialFlows.Item1;
                flow = _genericUtilities.GetFlowsInFlowPath(flowpath).FirstOrDefault();
                step = _genericUtilities.GetStepByFlowPath(flowpath);
            }
            else
            {
                flowpath = product.FlowPath;
                flow = product.Flow;
                step = product.Step;
            }

            //Get PO type and check if it exists on the POType table
            poType = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.ERPOrderlessPOTypeConfig);
            if (_iKEAUtilities.GetValueFromLookupTable("ProductionOrderType", poType, false).IsNullOrEmpty())
            {
                throw _iKEAUtilities.LocalizedException(IKEAConstants.CustomOrderlessIsNotOnProductionOrderTypeMessage, poType);
            }
            ;

            #endregion

            #region Initialize PO

            flow.Load();

            po.Name = poName;
            po.OrderNumber = poName;
            po.Description = description;
            po.Type = poType;
            po.SystemState = ProductionOrderSystemState.Released;
            po.Facility = facility;
            po.Product = product;
            po.RestrictOnComplete = false;
            po.FlowPath = flowpath;
            po.Flow = flow;
            po.Step = step;
            po.Quantity = quantity;
            po.Units = product.DefaultUnits;
            po.UnderDeliveryTolerance = 1;
            po.OverDeliveryTolerance = 1;

            //Placeholder dates
            po.PlannedStartDate = DateTime.Now.ToLocalTime();
            po.PlannedEndDate = DateTime.Now.ToLocalTime().AddHours(1);
            po.DueDate = DateTime.Now.ToLocalTime().AddHours(1);

            #endregion

            #region Add Attributes

            po.Attributes.Add(IKEAConstants.CustomProductionOrderAttributeDefaultWorkCenter, workCenterName);

            reportingWarehouse = resource.GetAttributeValueOrDefault(IKEAConstants.CustomResourceERPWarehouseLocationAttribute, defaultValue: string.Empty);
            po.Attributes.Add(IKEAConstants.CustomProductionOrderAttributeReportingWarehouse, reportingWarehouse);
            po.Attributes.Add("YieldlessPlannedQuantity", quantity);
            po.Attributes.Add("ScheduleNumber", scheduleNumber);
            po.Attributes.Add(IKEAConstants.CustomERPOperationCodeOverride, "");

            if (bom != null)
            {
                bom.Load();
                structureType = bom.GetAttributeValueOrDefault(IKEAConstants.CustomBOMStructureTypeAttribute, defaultValue: string.Empty, loadAttribute: true);
                po.Attributes.Add(IKEAConstants.CustomProductionOrderAttributeStructureType, structureType);
            }

            po.Attributes.Add(IKEAConstants.CustomProductionOrderIsOrderlessAttribute, true);

            #endregion

            po.Create();
            po.LoadMaterials();

            if (!po.Materials.IsNullOrEmpty() && bom != null)
            {
                // Associate all the materials created for this PO (should only be 1 material) with the BOM
                AssociateMaterialBOMs(po.Materials.ToDictionary(mat => mat, _ => bom));
            }

            //Return Material
            return po.Materials.FirstOrDefault();
        }

        /// <summary>
        /// This method only returns a BOM if it is associated specifically to these orders, looking only at the Material and Step columns
        /// It doesn't resolve the BOM using the regular MES methods. All material names from the argument are present in the returned dictionary
        /// If a material does not have an associated BOM, then the value of that key is null. The BOMs are anot loaded, and only have the name property filled.
        /// </summary>
        /// <param name="materials"></param>
        /// <returns></returns>
        public Dictionary<string, IBOM> GetAssociatedOrderBOMs(IEnumerable<IMaterial> materials)
        {
            // Create the Map that will hold the results of this function
            Dictionary<string, IBOM> resultBOMs = materials.ToDictionary(material => material.Name, _ => null as IBOM);

            if (resultBOMs.Any())
            {
                // Create the Smart Table object from which we will load the existing BOMs
                var bomContextSmartTable = new SmartTable { Name = IKEAConstants.CustomSmartTableBOMContext };
                bomContextSmartTable.Load();

                // Request from the server the BOM's for any of these orders
                bomContextSmartTable.LoadData(new Foundation.BusinessObjects.QueryObject.FilterCollection
                {
                    new Foundation.BusinessObjects.QueryObject.Filter
                    {
                        Name = "Material",
                        Operator = Cmf.Foundation.Common.FieldOperator.In,
                        Value = materials.Select(mat => mat.Name).ToList(),
                    }
                });

                var dataSet = NgpDataSet.ToDataSet(bomContextSmartTable.Data);

                if (dataSet.HasData())
                {
                    // Load all the steps from the materials at once
                    IStepCollection steps = _entityFactory.CreateCollection<IStepCollection>();
                    steps.LoadByIDs<IStep, Step>(materials.Select(material => material.GetNativeValue<long>(IKEAConstants.Step)).Distinct().ToList());

                    // And create a dictionary to avoid quadratic searches by Id
                    Dictionary<long, IStep> stepById = steps.ToDictionary(step => step.Id);

                    Dictionary<string, IStep> stepByMaterial = materials.ToDictionary(
                        material => material.Name,
                        material => stepById[material.GetNativeValue<long>(IKEAConstants.Step)]
                    );

                    // Get the rows returned from the service
                    foreach (DataRow row in dataSet.Tables[0].Rows)
                    {
                        string rowMaterialName = row.Field<string>("Material");
                        string rowStepName = row.Field<string>("Step");

                        if (rowStepName == stepByMaterial[rowMaterialName].Name)
                        {
                            var bom = _entityFactory.Create<IBOM>();
                            bom.Name = row.Field<string>("BOM");

                            resultBOMs[rowMaterialName] = bom;
                        }
                    }
                }
            }

            return resultBOMs;
        }

        /// <summary>
        /// Creates an association in the Smart Table BOMContext between each of the materials and their BOMs.
        /// Assumes such association does not yet exist in the table. The column keys used for this association in the table
        /// are the Material and Step only. 
        /// </summary>
        /// <param name="materialBOMs"></param>
        public void AssociateMaterialBOMs(Dictionary<IMaterial, IBOM> materialBOMs)
        {
            //Create BOMContext
            ISmartTable smartTable = new SmartTable();
            smartTable.Load(IKEAConstants.CustomSmartTableBOMContext);

            DataTable dataTable = new DataTable(Navigo.Common.Constants.BOMContext);

            #region Declare DataTable Schema

            Type stringType = typeof(string);
            Type longType = typeof(long);
            Type intType = typeof(int);

            // Create the structure for the smart table RecipeContext
            dataTable.Columns.AddRange(new DataColumn[]
            {
                new DataColumn() { ColumnName = string.Format("{0}Id", Navigo.Common.Constants.BOMContext), DataType = longType },
                new DataColumn() { ColumnName = Constants.LastServiceHistoryId, DataType = longType },
                new DataColumn() { ColumnName = Constants.LastOperationHistorySeq, DataType = longType },
                new DataColumn() { ColumnName = Navigo.Common.Constants.Step, DataType = stringType },
                new DataColumn() { ColumnName = "LogicalFlowPath", DataType = stringType },
                new DataColumn() { ColumnName = Navigo.Common.Constants.Product, DataType = stringType },
                new DataColumn() { ColumnName = Navigo.Common.Constants.ProductGroup, DataType = stringType },
                new DataColumn() { ColumnName = Navigo.Common.Constants.Flow, DataType = stringType },
                new DataColumn() { ColumnName = Navigo.Common.Constants.Material, DataType = stringType },
                new DataColumn() { ColumnName = Navigo.Common.Constants.BOM, DataType = stringType },
                new DataColumn() { ColumnName = "AssemblyType", DataType = intType },
                new DataColumn() { ColumnName = "TrackInCheckMode", DataType = intType },
                new DataColumn() { ColumnName = "TrackOutLossesMode", DataType = intType },
                new DataColumn() { ColumnName = "WeighAndDispenseMode", DataType = intType },
            });

            #endregion

            DataSet dataSet = dataTable.ToDataSet();

            // Load all the steps from the materials at once
            IStepCollection steps = _entityFactory.CreateCollection<IStepCollection>();
            steps.LoadByIDs<IStep, Step>(materialBOMs.Keys.Select(material => material.GetNativeValue<long>(IKEAConstants.Step)).Distinct().ToList());

            // And create a dictionary to avoid quadratic searches by Id
            Dictionary<long, IStep> stepById = steps.ToDictionary(step => step.Id);

            foreach (IMaterial material in materialBOMs.Keys)
            {
                IBOM bom = materialBOMs[material];

                DataRow newRow = dataSet.Tables[0].NewRow();
                newRow[smartTable.Name + "Id"] = -1;
                newRow["LastServiceHistoryId"] = -1;
                newRow["LastOperationHistorySeq"] = -1;
                newRow["Step"] = material.Step.Name;
                newRow["Material"] = material.Name;
                newRow["BOM"] = bom.Name;
                newRow["AssemblyType"] = (int)BOMAssemblyType.Explicit;
                newRow["TrackInCheckMode"] = (int)BOMTrackInCheckMode.None;
                newRow["TrackOutLossesMode"] = (int)BOMTrackOutLossesMode.AfterAssembly;

                dataSet.Tables[0].Rows.Add(newRow);
            }

            _tableOrchestration.InsertOrUpdateSmartTableRows(new Foundation.BusinessOrchestration.TableManagement.InputObjects.InsertOrUpdateSmartTableRowsInput()
            {
                SmartTable = smartTable,
                Table = NgpDataSet.FromDataSet(dataSet)
            });
        }

        /// <summary>
		/// Returns the attributes of the Integration Entry where an AdHoc PO was requested to ERP (ERPRequestProductionOrder).
		/// </summary>
		/// <param name="poName"></param>
		/// <returns>Returns a dictionary with the attributes</returns>
		public Dictionary<string, string> GetIntegrationEntryAttributes(string poName)
        {
            Dictionary<string, string> integrationEntryAttributes = new Dictionary<string, string>();

            IQueryObject query = new QueryObject();
            query.Description = "Gets integration entry attributes with PO name";
            query.EntityTypeName = "IntegrationEntry";
            query.Name = "GetIntegrationEntryAttributesByPOName";
            query.Query = new Query();
            query.Query.Distinct = true;
            query.Query.Filters = new FilterCollection() {
                new Filter()
                {
                    Name = "ERPRequestPOName",
                    ObjectName = "IntegrationEntry",
                    ObjectAlias = "IntegrationEntry_1",
                    Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                    Value = poName,
                    LogicalOperator = Cmf.Foundation.Common.LogicalOperator.Nothing,
                    FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal
                }
            };
            query.Query.Fields = new FieldCollection() {
                new Field()
                {
                    Alias = "ERPRequestPOName",
                    ObjectName = "IntegrationEntry",
                    ObjectAlias = "IntegrationEntry_1",
                    IsUserAttribute = true,
                    Name = "ERPRequestPOName",
                    Position = 2,
                    Sort = Cmf.Foundation.Common.FieldSort.NoSort
                },
                new Field()
                {
                    Alias = "ERPRequestResourceName",
                    ObjectName = "IntegrationEntry",
                    ObjectAlias = "IntegrationEntry_1",
                    IsUserAttribute = true,
                    Name = "ERPRequestResourceName",
                    Position = 3,
                    Sort = Cmf.Foundation.Common.FieldSort.NoSort
                }
            };
            query.Query.Relations = new RelationCollection();

            DataSet resultDataSet = query.Execute(false, new QueryParameterCollection());

            if (resultDataSet.HasData())
            {
                foreach (DataRow row in resultDataSet.Tables[0].Rows)
                {
                    integrationEntryAttributes.Add(IKEAConstants.IntegrationEntryAttributeERPRequestPOName, row[IKEAConstants.IntegrationEntryAttributeERPRequestPOName] as string);
                    integrationEntryAttributes.Add(IKEAConstants.IntegrationEntryAttributeERPRequestResourceName, row[IKEAConstants.IntegrationEntryAttributeERPRequestResourceName] as string);
                }
                ;
            }

            return integrationEntryAttributes;
        }
    }
}
