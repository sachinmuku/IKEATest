﻿using Cmf.Foundation.Common;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using OtherConstants = Cmf.Navigo.Common.Constants;
using System;
using Cmf.Custom.IKEA.BusinessObjects;
using Cmf.Custom.IKEA.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Common.CustomActionUtilities;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Foundation.BusinessOrchestration.Abstractions;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Foundation.Common.LocalizationService;
using Cmf.Custom.IKEA.Common.Exceptions;
using Cmf.Navigo.BusinessOrchestration.Abstractions;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;

namespace Cmf.Custom.IKEA.Common.Utilities
{
    public class AutomaticMaterialCreationUtilities : IAutomaticMaterialCreationUtilities
    {
        private IEntityFactory _entityFactory;
        private IIKEAUtilities _iKEAUtilities;
        private IGenericUtilities _genericUtilities;
        private IGenericServiceOrchestration _genericServiceOrchestration;
        private IMaterialOrchestration _materialOrchestration;
        private ILocalizationService _localizationService;
        private IServiceProvider _serviceProvider;

        [Microsoft.Extensions.DependencyInjection.ActivatorUtilitiesConstructor]
        public AutomaticMaterialCreationUtilities(IEntityFactory entityFactory,
            IGenericUtilities genericUtilities,
            IGenericServiceOrchestration genericServiceOrchestration,
            IIKEAUtilities iKEAUtilities,
            ILocalizationService localizationService,
            IMaterialOrchestration materialOrchestration,
            IServiceProvider serviceProvider)
        {
            _entityFactory = entityFactory;
            _genericUtilities = genericUtilities;
            _genericServiceOrchestration = genericServiceOrchestration;
            _iKEAUtilities = iKEAUtilities;
            _localizationService = localizationService;
            _materialOrchestration = materialOrchestration;
            _serviceProvider = serviceProvider;
        }
        /// <summary>
        /// Create a Material after scan read, if it doent exist and configuration is enabled.
        /// </summary>
        /// <remarks>
        /// Throws exceptions if validation fails
        /// </remarks>
        /// <param name="resource">Resource where material was scanned</param>
        /// <param name="serviceTokenList">Token list with information for creating the material</param>
        public IMaterial CustomCreateScannedMaterialAutomaticallyUtility(IResource resource, Dictionary<string, string> serviceTokenList)
        {
            IMaterial material = null;

            //Validate Token list
            Tuple<string, string, decimal> tuple = ValidateTokenList(serviceTokenList);
            string materialName = tuple.Item1;
            string productName = tuple.Item2;
            decimal quantity = tuple.Item3;

            string batchName = string.Empty;

            // Check if the token Batch exists
            if (serviceTokenList.ContainsKey(IKEAConstants.AutomaticScanningMaterialCreationBatchToken))
            {
                batchName = serviceTokenList[IKEAConstants.AutomaticScanningMaterialCreationBatchToken];
            }

            //Get configurations.
            string conf_materialform = _iKEAUtilities.GetValueFromConfigurationWithPath(IKEAConstants.AutomaticMaterialCreationDefaultForm);
            string conf_materialtype = _iKEAUtilities.GetValueFromConfigurationWithPath(IKEAConstants.AutomaticMaterialCreationDefaultType);
            if (conf_materialform.IsNullOrEmpty() || conf_materialtype.IsNullOrEmpty())
            {
                throw new IKEAException(IKEAConstants.CustomAutoMaterialCreationInvalidConfiguration, IKEAConstants.AutomaticMaterialCreationDefaultForm, IKEAConstants.AutomaticMaterialCreationDefaultType);
            }

            material = _entityFactory.Create<IMaterial>();
            material.Name = materialName;
            IProduct product = _entityFactory.Create<IProduct>();
            product.Name = productName;

            //Check if material already exists:
            if (material.ObjectExists())
            {
                throw new IKEAException(IKEAConstants.CustomAutoMaterialCreationMaterialAlreadyExists, materialName);
            }

            //Check if the indicated product exists in MES:
            if (!product.ObjectExists())
            {
                throw new IKEAException(IKEAConstants.CustomAutoMaterialCreationInvalidProduct, productName);
            }

            //Check if the product has DefaultUnits:
            product.Load();
            if (product.DefaultUnits == null)
            {
                throw new IKEAException(IKEAConstants.CustomAutoMaterialCreationInvalidProductDefaultUnits, productName);
            }

            //Get ConsumptionFlowPath and FlowPath from smarttable         
            string productflowpath = _genericUtilities.ResolveAllMaterialFlows(resource.Area.Facility, product, resource, conf_materialtype, null)?.Item2;
            if (productflowpath.IsNullOrEmpty())
            {
                if (product.FlowPath.IsNullOrEmpty())
                    throw new IKEAException(IKEAConstants.CustomAutoMaterialCreationFlowPathNotFound, resource.Name, resource.Area.Facility.Name);
                else
                    productflowpath = product.FlowPath;
            }

            material.PrimaryQuantity = quantity;
            material.PrimaryUnits = product.DefaultUnits;
            material.FlowPath = productflowpath;
            material.Product = product;
            material.Type = conf_materialtype;
            material.Form = conf_materialform;
            material.Facility = resource.Area.Facility;

            if (!string.IsNullOrWhiteSpace(batchName))
            {
                // Set Batch for the material
                SetMaterialBatch(batchName, ref material);
            }

            _materialOrchestration.CreateMaterial(new CreateMaterialInput() { Material = material });

            return material;
        }

        /// <summary>
        /// Create a Material after scan read, if it doent exist and configuration is enabled.
        /// </summary>
        /// <remarks>
        /// Throws exceptions if validation fails
        /// </remarks>
        /// <param name="resource">Resource where material was scanned</param>
        /// <param name="serviceTokenList">Token list with information for creating the material</param>
        public IMaterial CustomCreateScannedDurableAutomaticallyUtility(string materialName, string productName, decimal quantity, IResource resource)
        {
            IMaterial material = null;

            //Get configurations.
            string conf_materialform = _iKEAUtilities.GetValueFromConfigurationWithPath(IKEAConstants.AutomaticDurableCreationDefaultForm);
            string conf_materialtype = _iKEAUtilities.GetValueFromConfigurationWithPath(IKEAConstants.AutomaticDurableCreationDefaultType);
            if (conf_materialform.IsNullOrEmpty() || conf_materialtype.IsNullOrEmpty())
            {
                throw new IKEAException(IKEAConstants.CustomAutoMaterialCreationInvalidConfiguration, IKEAConstants.AutomaticDurableCreationDefaultForm, IKEAConstants.AutomaticDurableCreationDefaultType);
            }

            material = _entityFactory.Create<IMaterial>();
            material.Name = materialName;
            IProduct product = _entityFactory.Create<IProduct>();
            product.Name = productName;

            //Check if material already exists:
            if (material.ObjectExists())
            {
                throw new IKEAException(IKEAConstants.CustomAutoMaterialCreationMaterialAlreadyExists, materialName);
            }

            //Check if the indicated product exists in MES:
            if (!product.ObjectExists())
            {
                throw new IKEAException(IKEAConstants.CustomAutoMaterialCreationInvalidProduct, productName);
            }

            //Check if the product has DefaultUnits:
            product.Load();
            if (product.DefaultUnits == null)
            {
                throw new IKEAException(IKEAConstants.CustomAutoMaterialCreationInvalidProductDefaultUnits, productName);
            }

            //Get ConsumptionFlowPath and FlowPath from smarttable         
            string productflowpath = _genericUtilities.ResolveAllMaterialFlows(resource.Area.Facility, product, resource, conf_materialtype, null)?.Item2;
            if (productflowpath.IsNullOrEmpty())
            {
                if (product.FlowPath.IsNullOrEmpty())
                    throw new IKEAException(IKEAConstants.CustomAutoMaterialCreationFlowPathNotFound, resource.Name, resource.Area.Facility.Name);
                else
                    productflowpath = product.FlowPath;
            }

            material.PrimaryQuantity = quantity;
            material.PrimaryUnits = product.DefaultUnits;
            material.FlowPath = productflowpath;
            material.Product = product;
            material.Type = conf_materialtype;
            material.Form = conf_materialform;
            material.Facility = resource.Area.Facility;

            _materialOrchestration.CreateMaterial(new CreateMaterialInput() { Material = material });

            return material;
        }

        /// <summary>
        /// Validates if the Token list has all the information necessary for creating a new material: Material, Product and Quantity
        /// </summary>
        /// <param name="serviceTokenList"></param>
        /// <returns></returns>
        public Tuple<string, string, decimal> ValidateTokenList(Dictionary<string, string> serviceTokenList)
        {
            Tuple<string, string, decimal> tuple = null;
            decimal quantity = 0;

            //Check for missing tokens
            if (!serviceTokenList.ContainsKey(OtherConstants.Material))
            {
                throw new IKEAException(IKEAConstants.CustomAutoMaterialCreationTokenNotFound, OtherConstants.Material);
            }
            if (!serviceTokenList.ContainsKey(OtherConstants.Product))
            {
                throw new IKEAException(IKEAConstants.CustomAutoMaterialCreationTokenNotFound, OtherConstants.Product);
            }
            if (!serviceTokenList.ContainsKey(IKEAConstants.Quantity))
            {
                throw new IKEAException(IKEAConstants.CustomAutoMaterialCreationTokenNotFound, IKEAConstants.Quantity);
            }

            //Check for invalid data in tokens
            if (serviceTokenList.Where(x => x.Key == OtherConstants.Material).Select(x => x.Value).FirstOrDefault().IsNullOrEmpty())
            {
                throw new IKEAException(IKEAConstants.CustomAutoMaterialCreationInvalidToken, OtherConstants.Material);
            }
            if (serviceTokenList.Where(x => x.Key == OtherConstants.Product).Select(x => x.Value).FirstOrDefault().IsNullOrEmpty())
            {
                throw new IKEAException(IKEAConstants.CustomAutoMaterialCreationInvalidToken, OtherConstants.Product);
            }
            if (!decimal.TryParse(serviceTokenList.Where(x => x.Key == IKEAConstants.Quantity).Select(x => x.Value).FirstOrDefault(), out quantity))
            {
                throw new IKEAException(IKEAConstants.CustomAutoMaterialCreationInvalidToken, IKEAConstants.Quantity);
            }

            tuple = new Tuple<string, string, decimal>
                (
                serviceTokenList.Where(x => x.Key == OtherConstants.Material).Select(x => x.Value).FirstOrDefault(),
                serviceTokenList.Where(x => x.Key == OtherConstants.Product).Select(x => x.Value).FirstOrDefault(),
                quantity
                );

            return tuple;
        }

        /// <summary>
        /// Set Batch for the material
        /// </summary>
        /// <param name="batchName">Material Batch name</param>
        /// <param name="material">Material to add batch</param>
        public void SetMaterialBatch(string batchName, ref IMaterial material)
        {
            IMaterial materialBatch = _entityFactory.Create<IMaterial>();
            materialBatch.Name = batchName;

            // Check if the material exists
            if (materialBatch.ObjectExists())
            {
                materialBatch.Load();

                // Get Configured Pallet Form
                string palletForm = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.PalletMaterialForm);

                // check if the existing material is pallet form
                if (materialBatch.Form == palletForm)
                {
                    throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomBatchCreationFailedPalletExistsWithSameNameLocalizedMessage, materialBatch.Name));
                }

                // Create a relation between the material and the batch
                ICustomMaterialBatchCollection materialBatchRelations = _entityFactory.CreateCollection<ICustomMaterialBatchCollection>();
                ICustomMaterialBatch customMaterialBatch = _entityFactory.Create<ICustomMaterialBatch>();


                customMaterialBatch.SourceEntity = material;
                customMaterialBatch.TargetEntity = materialBatch;
                customMaterialBatch.IsParentBatch = true;

                materialBatchRelations.Add(customMaterialBatch);
                //material.RelationCollection = new Foundation.BusinessObjects.CmfEntityRelationCollection()
                //{
                //    materialBatchRelations
                //};
                material.RelationCollection = _serviceProvider.GetService<ICmfEntityRelationCollection>();
                material.RelationCollection.Add(materialBatchRelations);
            }
            else
            {
                //Create Batch Material 
                string batchFlowPath = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.BatchDefaultFlowPath);

                //Validate Type is defined
                string batchType = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.BatchMaterialType);
                if (string.IsNullOrWhiteSpace(batchType))
                {
                    throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomCreateBatchConfigNotDefinedLocalizedMessage, Constants.Type, IKEAConstants.BatchMaterialType));
                }

                //Validate Form is defined
                string batchForm = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.BatchMaterialForm);
                if (string.IsNullOrWhiteSpace(batchForm))
                {
                    throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomCreateBatchConfigNotDefinedLocalizedMessage, IKEAConstants.CustomCreateBatchFormConstant, IKEAConstants.BatchMaterialForm));

                }

                //Validate flowpath
                string batchFlowPathWithCorrelationId;
                if (!string.IsNullOrWhiteSpace(batchFlowPath))
                {
                    try
                    {
                        batchFlowPathWithCorrelationId = _iKEAUtilities.GetCorrelationIdFlowPath(batchFlowPath);
                    }
                    catch (Exception)
                    {
                        //Invalid Flowpath defined in the configuration
                        throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomCreateBatchInvalidFlowPathLocalizedMessage, IKEAConstants.BatchDefaultFlowPath));
                    }
                    if (!string.IsNullOrWhiteSpace(batchFlowPathWithCorrelationId))
                    {
                        materialBatch.Product = material.Product;
                        materialBatch.PrimaryQuantity = 0;
                        materialBatch.PrimaryUnits = material.PrimaryUnits;
                        materialBatch.FlowPath = batchFlowPathWithCorrelationId;
                        materialBatch.Type = batchType;
                        materialBatch.Form = batchForm;
                        materialBatch.Facility = material.Facility;

                        _materialOrchestration.CreateMaterial(new CreateMaterialInput() { Material = materialBatch });
                        materialBatch.Load();
                        // Create a relation between the material and the batch
                        //ICustomMaterialBatchCollection materialBatchRelations = new CustomMaterialBatchCollection()
                        //    {
                        //     new CustomMaterialBatch()
                        //        {
                        //         SourceEntity = material,
                        //         TargetEntity = materialBatch,
                        //         IsParentBatch = true
                        //       }
                        //    };

                        //material.RelationCollection = new Foundation.BusinessObjects.CmfEntityRelationCollection()
                        //    {
                        //        materialBatchRelations
                        //    };
                        ICustomMaterialBatchCollection materialBatchRelations = _entityFactory.CreateCollection<ICustomMaterialBatchCollection>();
                        ICustomMaterialBatch customMaterialBatch = _entityFactory.Create<ICustomMaterialBatch>();
                        customMaterialBatch.SourceEntity = material;
                        customMaterialBatch.TargetEntity = materialBatch;
                        customMaterialBatch.IsParentBatch = true;

                        materialBatchRelations.Add(customMaterialBatch);
                        material.RelationCollection = _serviceProvider.GetService<ICmfEntityRelationCollection>();
                        material.RelationCollection.Add(materialBatchRelations);
                    }
                    else
                    {
                        //Invalid Flowpath defined in the configuration
                        throw new IKEAException(IKEAConstants.CustomCreateBatchInvalidFlowPathLocalizedMessage, IKEAConstants.BatchDefaultFlowPath);
                    }
                }
                else
                {
                    // Batch default flowpath Config not defined
                    throw new IKEAException(IKEAConstants.CustomCreateBatchConfigNotDefinedLocalizedMessage, IKEAConstants.CustomCreateBatchFlowPathConstant, IKEAConstants.BatchDefaultFlowPath);
                }
            }
        }

        /// <summary>
        /// Overload method for SetMaterialBatch
        /// Receives a MO Material and a Pallet and sets a CustomMaterialBatch Relation from pallet to MO 
        /// </summary>
        /// <param name="batch">MO Material</param>
        /// <param name="pallet">Pallet to add relation to batch</param>
        public void SetMaterialBatch(IMaterial batch, IMaterial pallet)
        {
            // Check if the material exists
            if (batch.ObjectExists())
            {
                // Create a relation between the material and the batch
                //ICustomMaterialBatchCollection materialBatchRelations = new CustomMaterialBatchCollection()
                //{
                //    new CustomMaterialBatch()
                //    {
                //        SourceEntity = pallet,
                //        TargetEntity = batch,
                //        IsParentBatch = true
                //    }
                //};
                //Cmf.Foundation.BusinessObjects.Abstractions.ICmfEntityRelationCollection relationsToAdd = new Foundation.BusinessObjects.CmfEntityRelationCollection()
                //{
                //    materialBatchRelations
                //};
                //materialBatchRelations.Create();
                //ICmfEntityRelationCollection relationsToAdd = _serviceProvider.GetService<ICmfEntityRelationCollection>();
                ICustomMaterialBatchCollection materialBatchRelations = _entityFactory.CreateCollection<ICustomMaterialBatchCollection>();
                ICustomMaterialBatch customMaterialBatch = _entityFactory.Create<ICustomMaterialBatch>();
                customMaterialBatch.SourceEntity = pallet;
                customMaterialBatch.TargetEntity = batch;
                customMaterialBatch.IsParentBatch = true;

                materialBatchRelations.Add(customMaterialBatch);
                //pallet.RelationCollection.Add(materialBatchRelations);
                //pallet.RelationCollection.Add(materialBatchRelations);
                materialBatchRelations.Create();
                //pallet.Create();
            }
        }
    }
}
