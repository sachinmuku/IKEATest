﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;

using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Enums;
using Cmf.Custom.IKEA.Common.Exceptions;
using Cmf.Custom.IKEA.Common.Extensions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessObjects.SmartTables;
using Cmf.Foundation.BusinessOrchestration.Abstractions;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Foundation.Common.LocalizationService;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.Abstractions;
using Microsoft.Extensions.DependencyInjection;

namespace Cmf.Custom.IKEA.Common.Utilities
{
    public class DirectFeedingUtilities : IDirectFeedingUtilities
    {
        private IIKEAUtilities _iKEAUtilities;
        private IGenericUtilities _genericUtilities;

        [Microsoft.Extensions.DependencyInjection.ActivatorUtilitiesConstructor]
        public DirectFeedingUtilities(
            IGenericUtilities genericUtilities,
            IIKEAUtilities iKEAUtilities
            )
        {
            _genericUtilities = genericUtilities;
            _iKEAUtilities = iKEAUtilities;
        }
        /// <summary>
        /// Return Unloaded Direct Feeding counterpart Resource. Null if fails
        /// </summary>
        /// <param name="resource"></param>
        /// <param name="loadResource"></param>
        public IResource GetDirectFeedingCounterpartResource(IResource resource, bool loadResource = false)
        {
            System.IServiceProvider serviceProvider = ApplicationContext.CurrentServiceProvider;
            IEntityFactory entityFactory = serviceProvider.GetRequiredService<IEntityFactory>();
            if (loadResource)
            {
                resource.Load();
            }

            resource.LoadAttribute(IKEAConstants.CustomResourceDirectFeedingSendRequestTo);
            string counterpartResourceName = resource.GetAttributeValue(IKEAConstants.CustomResourceDirectFeedingSendRequestTo) as string;
            if (string.IsNullOrEmpty(counterpartResourceName))
            {
                return null;
            }
            IResource counterpartResource = entityFactory.Create<IResource>();
            counterpartResource.Name = counterpartResourceName;
            if (!counterpartResource.ObjectExists())
            {
                return null;
            }
            return counterpartResource;
        }

        /// <summary>
        /// Check if resource counterpart of direct feeding has the correct configurations
        /// </summary>
        /// <param name="resource"></param>
        /// <param name="loadResource"></param>
        public bool IsDirectFeedingResourceMatchValid(IResource resource, bool loadResource = false)
        {
            if (resource == null)
            {
                return false;
            }
            Collection<string> attributesToLoad = new Collection<string>() {
                IKEAConstants.CustomResourceDirectFeedingEnabled,
                IKEAConstants.CustomResourceDirectFeedingIsFirstLine,
                IKEAConstants.CustomResourceDirectFeedingSendRequestTo
            };
            if (loadResource)
            {
                resource.Load();
            }

            // Load mainResource Attributes
            resource.LoadAttributes(attributesToLoad);
            bool? resourceDirectFeedingIsFirstLine = resource.GetAttributeValue(IKEAConstants.CustomResourceDirectFeedingIsFirstLine) as bool?;

            // Load CounterpartResource
            IResource counterpartResource = GetDirectFeedingCounterpartResource(resource);
            if (counterpartResource == null)
            {
                return false;
            }
            counterpartResource.Load();
            counterpartResource.LoadAttributes(attributesToLoad);

            bool? counterpartDirectFeedingEnabled = counterpartResource.GetAttributeValue(IKEAConstants.CustomResourceDirectFeedingEnabled) as bool?;
            if (counterpartDirectFeedingEnabled == null || !(bool)counterpartDirectFeedingEnabled)
            {
                return false;
            }

            string counterpartDirectFeedingSendRequestTo = counterpartResource.GetAttributeValue(IKEAConstants.CustomResourceDirectFeedingSendRequestTo) as string;
            if (string.IsNullOrEmpty(counterpartDirectFeedingSendRequestTo) || !string.Equals(counterpartDirectFeedingSendRequestTo, resource.Name))
            {
                return false;
            }

            bool? counterpartDirectFeedingIsFirstLine = counterpartResource.GetAttributeValue(IKEAConstants.CustomResourceDirectFeedingIsFirstLine) as bool?;
            if ((counterpartDirectFeedingIsFirstLine ?? false) == (resourceDirectFeedingIsFirstLine ?? false))
            {
                return false;
            }
            return true;
        }

        /// <summary>
        /// Get DataSet with the resolution of the SmartTable CustomDirectFeedingRecipeMode
        /// </summary>
        /// <param name="material"></param>
        /// <param name="resource"></param>
        /// <returns></returns>
        public CustomDirectFeedingModeEnum? ResolveCustomDirectFeedingRecipeModeSmartTable(IMaterial material, IResource resource)
        {
            // Load smart table
            ISmartTable smartTable = new SmartTable();
            smartTable.Load(IKEAConstants.CustomDirectFeedingRecipeModeSmartTable);

            DataSet directFeedingMode = null;

            CustomDirectFeedingModeEnum feedingMode;

            INgpDataRow values = new NgpDataRow();

            if (!string.IsNullOrWhiteSpace(resource.Name))
            {
                values.Add(IKEAConstants.CustomDirectFeedingRecipeModeColumnResource, resource.Name);
            }

            // Validate if the material has a recipe and if yes use it to resolve the smart table
            if (material.CurrentRecipeInstance != null && material.CurrentRecipeInstance.ParentEntity != null
                && !string.IsNullOrWhiteSpace(material.CurrentRecipeInstance.ParentEntity.Name))
            {
                values.Add(IKEAConstants.CustomDirectFeedingRecipeModeColumnRecipe, material.CurrentRecipeInstance.ParentEntity.Name);
            }

            INgpDataSet ngoDataSet = smartTable.Resolve(values, true);
            if (ngoDataSet != null)
            {
                directFeedingMode = NgpDataSet.ToDataSet(ngoDataSet);
            }

            if (!directFeedingMode.HasData())
            {
                return null;
            }
            DataRow row = directFeedingMode.Tables[0].Rows[0];

            // Get direct feeding mode
            feedingMode = row.Field<CustomDirectFeedingModeEnum>(IKEAConstants.CustomDirectFeedingRecipeModeColumnDirectFeedingMode);

            return feedingMode;
        }

        /// <summary>
        /// Request IoT to create a Virtual Pallet. Returns empty string if successful otherwise error message.
        /// </summary>
        /// <param name="lineResource"></param>
        /// <param name="basedOnMaterial"></param>
        /// <param name="quantity"></param>
        public void RequestVirtualPalletCreation(IProduct product, IResource lineResource, decimal baseUnitConversion, decimal quantity)
        {
            System.IServiceProvider serviceProvider = ApplicationContext.CurrentServiceProvider;
            IEntityFactory entityFactory = serviceProvider.GetRequiredService<IEntityFactory>();

            if (product == null)
            {
                throw new CmfBaseException(String.Format(IKEAConstants.CustomErrorMessageRequestingVirtualPallet, Cmf.Navigo.Common.Constants.Product));
            }
            if (lineResource == null)
            {
                throw new CmfBaseException(String.Format(IKEAConstants.CustomErrorMessageRequestingVirtualPallet, Cmf.Navigo.Common.Constants.Resource));
            }
            lineResource.Load();
            lineResource.LoadAttribute(IKEAConstants.MESAutomationInFeederSubResourceController);
            IAutomationControllerInstance controllerInstance = lineResource.GetAutomationControllerInstance();
            if (controllerInstance == null)
            {
                throw new CmfBaseException(String.Format(IKEAConstants.CustomErrorMessageRequestingVirtualPallet, IKEAConstants.AutomationControllerInstance));
            }

            IResource mainFeeder = entityFactory.Create<IResource>();
            mainFeeder.Name = lineResource.GetAttributeValueOrDefault<string>(IKEAConstants.MESAutomationInFeederSubResourceController);
            if (mainFeeder.Name == string.Empty || !mainFeeder.ObjectExists())
            {
                throw new CmfBaseException(IKEAConstants.CustomAutomationNullOrMissingMainFeeder);

            }

            Dictionary<string, string> reply = _genericUtilities.RequestFromIoT<Dictionary<string, string>>(controllerInstance, IKEAConstants.AutomationRequestCreateVirtualPallet, new
            {
                VirtualPalletData = new
                {
                    ProductId = product.Id,
                    ProductName = product.Name,
                    Unit = product.DefaultUnits,
                    BaseUnitConversion = baseUnitConversion,
                    Quantity = quantity
                },
                ResourceName = mainFeeder.Name
            });

            bool success = false;
            if (reply != null && reply.ContainsKey(IKEAConstants.AutomationRequestReplyField))
            {
                bool.TryParse(reply[IKEAConstants.AutomationRequestReplyField], out success);
            }

            if (!success)
            {
                throw new CmfBaseException(String.Format(IKEAConstants.CustomErrorMessageVirtualCreationNoReply, product.Name));
            }
        }


        /// <summary>
        /// In Direct Feeding, if pallet is in first line and is set up for direct feeding mode, then attach it to the current resource counter part
        /// </summary>
        /// <param name="pallet"></param>
        public void DirectFeedingMovePalletToCounterPartResource(IMaterial pallet)
        {

            // In direct feeding, if validations are correct, attach palletized material to counter part resource, second line (move-next & attach)
            bool isDirectFeedingEnabled = _genericUtilities.GetConfigurationValueByPath<bool>(IKEAConstants.EnableDirectFeedingConfig);
            if (isDirectFeedingEnabled)
            {

                System.IServiceProvider serviceProvider = ApplicationContext.CurrentServiceProvider;
                IEntityFactory entityFactory = serviceProvider.GetRequiredService<IEntityFactory>();
                IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();

                bool directFeedingIsFirstLine = false;

                IResource palletResource = pallet.LastProcessedResource;
                if (palletResource != null)
                {
                    directFeedingIsFirstLine = palletResource.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomResourceDirectFeedingIsFirstLine, loadAttribute: true);
                }

                CustomDirectFeedingModeEnum materialInDirectFeedingMode = pallet.GetAttributeValueOrDefault<CustomDirectFeedingModeEnum>(IKEAConstants.CustomMaterialAttributeDirectFeedingMode, loadAttribute: true);

                // Check if material is in directFeedingMode and in the first line resource
                if (materialInDirectFeedingMode == CustomDirectFeedingModeEnum.DirectFeeding && directFeedingIsFirstLine)
                {
                    // Get resource name of counterpart
                    string resourceCounterPartName = palletResource.GetAttributeValueOrDefault<string>(IKEAConstants.CustomResourceDirectFeedingSendRequestTo, loadAttribute: true);

                    // Validate counterpart resource
                    IResource resourceCounterPart = entityFactory.Create<IResource>();
                    resourceCounterPart.Name = resourceCounterPartName;
                    if (resourceCounterPartName.IsNullOrEmpty() || !resourceCounterPart.ObjectExists())
                    {
                        palletResource.Load();
                        throw new IKEAException(IKEAConstants.CustomDirectFeedingResourceCounterPartNoValid, palletResource.Name);
                    }
                    resourceCounterPart.Load();

                    string counterpartMainFeederName = resourceCounterPart.GetAttributeValueOrDefault<string>(IKEAConstants.MESAutomationInFeederSubResourceController, true);
                    IResource counterpartMainFeeder = entityFactory.Create<IResource>();
                    counterpartMainFeeder.Name = counterpartMainFeederName;
                    counterpartMainFeeder.Load();

                    // Get consumption flow path
                    string consumptionFlowPath = _iKEAUtilities.ResolveConsumptionMaterialFlowByResource(resource: counterpartMainFeeder);

                    // If normal attach is done, no need to do special attach
                    deeContextUtilities.SetContextParameter(IKEAConstants.CustomDirectFeedingIsToSpecialAttach, false);

                    // Perform move-next and attach operations, change to consumption flow and step
                    deeContextUtilities.SetContextParameter(IKEAConstants.CustomDirectFeedingAutomaticAttach, true);
                    IStep consumptionStep = _genericUtilities.GetStepByFlowPath(consumptionFlowPath);
                    IFlow consumptionFlow = _genericUtilities.GetFlowsInFlowPath(consumptionFlowPath).FirstOrDefault();
                    pallet.ChangeFlowAndStep(consumptionFlow, consumptionFlowPath, consumptionStep, new OperationAttributeCollection { });
                    _iKEAUtilities.ApplyOperationActions(pallet, counterpartMainFeeder, "Attach");

                }

            }

        }

        /// <summary>
        /// Request IoT to change a Virtual Pallet to a Real Pallet.
        /// </summary>
        /// <param name="materialCollection"></param>
        /// <param name="lineResource"></param>
        /// <param name="controllerInstance"></param>
        public void RequestVirtualToRealPallet(IMaterialCollection materialCollection, IResource lineResource, IAutomationControllerInstance controllerInstance)
        {
            // Validate if DirectFeeding is enabled and lineResource is second line
            bool directFeedingIsFirstLine = lineResource.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomResourceDirectFeedingIsFirstLine, loadAttribute: true);
            bool isDirectFeedingEnabled = _genericUtilities.GetConfigurationValueByPath<bool>(IKEAConstants.EnableDirectFeedingConfig);

            if (isDirectFeedingEnabled && !directFeedingIsFirstLine)
            {

                // Validate parameters
                if (materialCollection.IsNullOrEmpty())
                {
                    throw new CmfBaseException(String.Format(IKEAConstants.CustomErrorMessageRequestingVirtualPallet, Cmf.Navigo.Common.Constants.MaterialCollection));
                }

                if (lineResource == null)
                {
                    throw new CmfBaseException(String.Format(IKEAConstants.CustomErrorMessageRequestingVirtualPallet, Cmf.Navigo.Common.Constants.Resource));
                }
                lineResource.Load();

                if (controllerInstance == null)
                {
                    throw new CmfBaseException(String.Format(IKEAConstants.CustomErrorMessageRequestingVirtualPallet, IKEAConstants.AutomationControllerInstance));
                }

                // Send request to IoT for each material that is in DirectFeedingMode
                foreach (IMaterial material in materialCollection)
                {
                    // Send data to IoT
                    bool success = SendAttachedData(controllerInstance, IKEAConstants.AutomationRequestVirtualToRealPallet, lineResource, material);
                    if (!success)
                    {
                        throw new CmfBaseException(String.Format(IKEAConstants.CustomErrorMessageFailedToConvertVirtualToReal, material.Name));
                    }
                }

            }
        }



        /// <summary>
        /// Request IoT to special attach material to resource
        /// </summary>
        /// <param name="material"></param>
        /// <param name="lineResource"></param>
        /// <exception cref="CmfBaseException"></exception>
        public void RequestSpecialAttach(IMaterial material, IResource lineResource)
        {

            // Validate if DirectFeeding is enabled and lineResource is second line
            bool directFeedingIsFirstLine = lineResource.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomResourceDirectFeedingIsFirstLine, loadAttribute: true);
            bool isDirectFeedingEnabled = _genericUtilities.GetConfigurationValueByPath<bool>(IKEAConstants.EnableDirectFeedingConfig);

            if (isDirectFeedingEnabled && !directFeedingIsFirstLine && lineResource.AutomationMode == ResourceAutomationMode.Online)
            {

                // Validate parameters
                if (material == null)
                {
                    throw new CmfBaseException(String.Format(IKEAConstants.CustomErrorMessageRequestingSpecialAttach, Cmf.Navigo.Common.Constants.Material));
                }

                if (lineResource == null)
                {
                    throw new CmfBaseException(String.Format(IKEAConstants.CustomErrorMessageRequestingSpecialAttach, Cmf.Navigo.Common.Constants.Resource));
                }
                lineResource.Load();


                IAutomationControllerInstance controllerInstance = lineResource.GetAutomationControllerInstance();
                if (controllerInstance == null)
                {
                    throw new CmfBaseException(String.Format(IKEAConstants.CustomErrorMessageRequestingSpecialAttach, IKEAConstants.AutomationControllerInstance));
                }

                // Send request to IoT for each material that is in DirectFeedingMode
                CustomDirectFeedingModeEnum materialDirectFeedingMode = material.GetAttributeValueOrDefault<CustomDirectFeedingModeEnum>(IKEAConstants.CustomMaterialAttributeDirectFeedingMode, loadAttribute: true);
                if (materialDirectFeedingMode == CustomDirectFeedingModeEnum.DirectFeeding)
                {
                    // Send data to IoT
                    bool success = SendAttachedData(controllerInstance, IKEAConstants.AutomationRequestSpecialAttach, lineResource, material);
                    if (!success)
                    {
                        throw new CmfBaseException(String.Format(IKEAConstants.CustomErrorMessageFailedToSpecialAttach, material.Name, lineResource.Name));
                    }
                }
            }

        }

        /// <summary>
        /// Sends the essential material information to IoT. Only the required data will be sent to avoid recursive problems in JSON serialization caused by calendars.
        /// </summary>
        /// <param name="controllerInstance">The automation controller instance.</param>
        /// <param name="requestType">The type of request being sent.</param>
        /// <param name="topMostResource">The topmost resource to be sent.</param>
        /// <param name="material">The material to be sent.</param>
        public bool SendAttachedData(IAutomationControllerInstance controllerInstance, string requestType, IResource topMostResource, IMaterial material)
        {
            System.IServiceProvider serviceProvider = ApplicationContext.CurrentServiceProvider;
            IEntityFactory entityFactory = serviceProvider.GetRequiredService<IEntityFactory>();

            material.LoadAttributes(new Collection<string>() {
                IKEAConstants.CustomMaterialAttributeCreationArea,
                IKEAConstants.CustomMaterialAttributeBaseMaterial,
                IKEAConstants.CustomMaterialAttributeOrderRunNumber,
            });

            AttributeCollection attributesToSend = new AttributeCollection();
            if (!material.Attributes.IsNullOrEmpty())
            {
                attributesToSend.AddRange((AttributeCollection)material.Attributes);
            }

            //Check if consumable material is from same Area that the resource:_
            bool isMaterialSameArea = material.GetAttributeValueOrDefault<string>(IKEAConstants.CustomMaterialAttributeCreationArea, false).CompareStrings(topMostResource.Area.Name);

            // Set the attributes to 0 when not in the same area, to send the information to IoT but not to update the material itself
            if (!isMaterialSameArea)
            {
                attributesToSend[IKEAConstants.CustomMaterialAttributeCurrentIteration] = 0;
                attributesToSend[IKEAConstants.CustomMaterialAttributeReworkCounter] = 0;
            }
            IMaterial mo = entityFactory.Create<IMaterial>();
            mo.Name = material.GetAttributeValueOrDefault<string>(IKEAConstants.CustomMaterialAttributeBaseMaterial);
            if (mo.ObjectExists())
            {
                mo.Load();
                attributesToSend[IKEAConstants.CustomMaterialAttributeBaseMaterial] = mo.Id.ToString();
            }

            attributesToSend[IKEAConstants.CustomMaterialAttributeOrderRunNumber] = material.GetAttributeValueOrDefault<int>(IKEAConstants.CustomMaterialAttributeOrderRunNumber);

            // It is not possible so convert a material to JsonString, this object is a representation of the material with the information that IoT needs
            var materialObject = new
            {
                Id = material.Id.ToString(),
                Name = material.Name,
                PrimaryQuantity = material.PrimaryQuantity,
                Product = new
                {
                    Id = material.Product.Id.ToString(),
                    Name = material.Product.Name
                },
                Attributes = attributesToSend,
                BaseUnitConversion = _iKEAUtilities.CalculateConversionFactorFromMaterial(material),
                Unit = material.PrimaryUnits
            };

            Dictionary<string, object> objectToSend = new Dictionary<string, object>();
            topMostResource.Load();

            string mainFeederName = topMostResource.GetAttributeValueOrDefault<string>(IKEAConstants.MESAutomationInFeederSubResourceController, true);
            if (mainFeederName.IsNullOrEmpty())
            {
                throw new CmfBaseException(IKEAConstants.CustomAutomationNullOrMissingMainFeeder);

            }

            objectToSend.Add("ResourceName", mainFeederName);
            objectToSend.Add("Material", materialObject);

            Dictionary<string, string> reply = _genericUtilities.RequestFromIoT<Dictionary<string, string>>(controllerInstance, requestType, objectToSend.ToJsonString());

            // Validate if there was an error
            bool success = false;
            if (reply != null && reply.ContainsKey(IKEAConstants.AutomationRequestReplyField))
            {
                bool.TryParse(reply[IKEAConstants.AutomationRequestReplyField], out success);
            }
            return success;
        }

        /// <summary>
        /// In case of Direct Feeding, the order needs to be able to be started even if there are not any attached pallets
        /// </summary>
        /// <param name="material"></param>
        /// <param name="isSetupCorrectly"></param>
        /// <returns></returns>
        public bool VerifyDirectFeedingConsumablesAttachToStart(IMaterial material, bool isSetupCorrectly)
        {

            // Verify if direct feeding and if the value is false (if it's already true there is no need to check further)
            bool isDirectFeedingEnabled = _genericUtilities.GetConfigurationValueByPath<bool>(IKEAConstants.EnableDirectFeedingConfig);
            if (isDirectFeedingEnabled && isSetupCorrectly == false)
            {
                IResource resource = material.LastProcessedResource;
                if (resource != null)
                {
                    // Verify if everything is setup correctly
                    bool isResourceUsingDirectFeeding = resource.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomResourceDirectFeedingEnabled, loadAttribute: true);
                    bool directFeedingIsFirstLine = resource.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomResourceDirectFeedingIsFirstLine, loadAttribute: true);
                    CustomDirectFeedingModeEnum isMaterialUsingDirectFeeding = material.GetAttributeValueOrDefault<CustomDirectFeedingModeEnum>(IKEAConstants.CustomMaterialAttributeDirectFeedingMode, loadAttribute: true);

                    // If everything is setup correctly then always define as true
                    if (isResourceUsingDirectFeeding && !directFeedingIsFirstLine
                        && isMaterialUsingDirectFeeding == CustomDirectFeedingModeEnum.DirectFeeding)
                    {
                        return true;
                    }
                }
            }

            return isSetupCorrectly;
        }

        /// <summary>
        /// Send request ClearDirectFeedingInterlock to firstLineResource
        /// </summary>
        /// <param name="firstLineResource"></param>
        public void RequestFirstLineToClearDirectFeedingInterlock(IResource firstLineResource)
        {
            IAutomationControllerInstance controllerInstance = firstLineResource.GetAutomationControllerInstance();
            if (controllerInstance == null)
            {
                throw new CmfBaseException(String.Format(IKEAConstants.CustomErrorMessageDFClearInterlockNullValue, IKEAConstants.AutomationControllerInstance));
            }
            Dictionary<string, string> reply = _genericUtilities.RequestFromIoT<Dictionary<string, string>>(controllerInstance, IKEAConstants.AutomationRequestClearDirectFeedingInterlock, new
            {
                InterlockReason = IKEAConstants.CustomDirectFeeding
            });

            bool success = false;
            if (reply != null && reply.ContainsKey(IKEAConstants.AutomationRequestReplyField))
            {
                bool.TryParse(reply[IKEAConstants.AutomationRequestReplyField], out success);
            }

            if (!success)
            {
                throw new CmfBaseException(IKEAConstants.CustomErrorMessageDFClearInterlockNoReply);
            }
        }

        /// <summary>
        /// Send request to IoT to reduce the pallet quantity on the outfeeder
        /// </summary>
        /// <param name="resource"></param>
        /// <param name="material"></param>
        /// <exception cref="CmfBaseException"></exception>
        public void SendRequestReducePalletQuantityOnOutfeeder(IResource resource, IMaterial material, decimal quantity)
        {
            System.IServiceProvider serviceProvider = ApplicationContext.CurrentServiceProvider;
            IEntityFactory entityFactory = serviceProvider.GetRequiredService<IEntityFactory>();

            resource.Load();

            bool isResourceUsingDirectFeeding = resource.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomResourceDirectFeedingEnabled, loadAttribute: true);
            CustomDirectFeedingModeEnum materialDirectFeedingMode = material.GetAttributeValueOrDefault<CustomDirectFeedingModeEnum>(IKEAConstants.CustomMaterialAttributeDirectFeedingMode, loadAttribute: true);

            if (isResourceUsingDirectFeeding && resource.AutomationMode == ResourceAutomationMode.Online && materialDirectFeedingMode == CustomDirectFeedingModeEnum.DirectFeeding)
            {
                // Get and validate outfeeder
                string resourceOutfeederName = resource.GetAttributeValueOrDefault<string>(IKEAConstants.CustomDirectFeedingOutfeederResource, loadAttribute: true);
                IResource outfeeder = entityFactory.Create<IResource>();
                outfeeder.Name = resourceOutfeederName;

                if (resourceOutfeederName.IsNullOrEmpty() || !outfeeder.ObjectExists())
                {
                    throw new CmfBaseException(String.Format(IKEAConstants.CustomErrorMessageRequestingReductionQuantityOutfeederNotDefined, resource.Name));
                }

                // Validate parameters
                if (material == null)
                {
                    throw new CmfBaseException(String.Format(IKEAConstants.CustomErrorMessageRequestingSpecialAttach, Cmf.Navigo.Common.Constants.Material));
                }

                IAutomationControllerInstance controllerInstance = resource.GetAutomationControllerInstance();
                if (controllerInstance == null)
                {
                    throw new CmfBaseException(String.Format(IKEAConstants.CustomErrorMessageRequestingReductionQuantityOutfeeder, IKEAConstants.AutomationControllerInstance));
                }

                Dictionary<string, object> objectToSend = new Dictionary<string, object>();
                objectToSend.Add("MaterialName", material.Name);
                objectToSend.Add("Quantity", quantity);
                objectToSend.Add("SubResourceName", outfeeder.Name);

                // Send request to IoT - ReducePalletQuantityOutfeeder
                _genericUtilities.RequestFromIoT<Dictionary<string, string>>(controllerInstance, IKEAConstants.AutomationRequestReducePalletQuantityOutfeeder, objectToSend.ToJsonString());

            }

        }


        /// <summary>
        /// Validates counterpart material in palletization process
        /// </summary>
        /// <param name="counterpartMaterial"></param>
        /// <param name="quantity"></param>
        /// <returns></returns>
        /// <exception cref="CmfBaseException"></exception>
        public bool ValidateCounterpartMaterialForPalletization(IMaterial counterpartMaterial, decimal quantity)
        {
            bool isCounterpartMaterialValid = false;

            // Validate counter part material
            // For this process to continue the counter part material needs to be tracked-in and have enough quantity for palletization
            // If it's tracked-in and it doesn't have enough quantity then an error is thrown
            if (!counterpartMaterial.Name.IsNullOrEmpty() && counterpartMaterial.ObjectExists())
            {
                counterpartMaterial.Load();
                CustomDirectFeedingModeEnum counterPartMaterialDirectFeedingMode = counterpartMaterial.GetAttributeValueOrDefault<CustomDirectFeedingModeEnum>(IKEAConstants.CustomMaterialAttributeDirectFeedingMode, loadAttribute: true);

                if (counterpartMaterial.CurrentMainState.CurrentState.Name == IKEAConstants.MaterialStateModelInProcess
                    && counterPartMaterialDirectFeedingMode == CustomDirectFeedingModeEnum.DirectFeeding)
                {
                    if (counterpartMaterial.PrimaryQuantity < quantity)
                    {
                        throw new IKEAException(IKEAConstants.CustomDirectFeedingCounterpartMaterialDoesNotHaveEnoughQuantity, counterpartMaterial.Name, quantity);
                    }

                    isCounterpartMaterialValid = true;
                }
            }

            return isCounterpartMaterialValid;
        }


        /// <summary>
        /// Calculate quantity according with bom ratio in direct feeding
        /// </summary>
        /// <param name="resource"></param>
        /// <param name="material"></param
        /// <param name="quantity"></param>
        /// <returns></returns>
        /// <exception cref="CmfBaseException"></exception>
        public decimal CalculateDirectFeedingQuantityAccordingWithBomRatio(IResource resource, IMaterial material, decimal quantity)
        {
            System.IServiceProvider serviceProvider = ApplicationContext.CurrentServiceProvider;
            IEntityFactory entityFactory = serviceProvider.GetRequiredService<IEntityFactory>();

            IResource mainFeeder = entityFactory.Create<IResource>();
            mainFeeder.Name = resource.GetAttributeValueOrDefault<string>(IKEAConstants.MESAutomationInFeederSubResourceController, true);
            if (mainFeeder.Name == string.Empty || !mainFeeder.ObjectExists())
            {
                throw new CmfBaseException(IKEAConstants.CustomAutomationNullOrMissingMainFeeder);
            }
            IBOMProductCollection currentBOMProducts = material.GetBOMProductsForSubResource(mainFeeder);

            decimal bomQuantityRatio = currentBOMProducts.FirstOrDefault().Quantity.Value;

            // Calculate quantity according with bom ratio
            decimal fullQuantity = quantity * bomQuantityRatio;

            return fullQuantity;
        }

       

    }
}