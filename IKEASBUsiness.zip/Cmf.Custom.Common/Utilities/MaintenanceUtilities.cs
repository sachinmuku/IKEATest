﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Xml;
using Cmf.Common.CustomActionUtilities;
using Cmf.Custom.IKEA.Common.ERP.Maintenance;
using Cmf.Custom.IKEA.Common.Extensions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.GenericTables;
using Cmf.Foundation.BusinessObjects.QueryObject;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Base;
using Cmf.Foundation.Security;
using Cmf.Navigo.BusinessObjects;
using Newtonsoft.Json;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Foundation.Security.Abstractions;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Foundation.BusinessOrchestration.Abstractions;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Foundation.Common.LocalizationService;
using Cmf.Custom.IKEA.Common.Exceptions;
using INotificationCollection = Cmf.Navigo.BusinessObjects.Abstractions.INotificationCollection;
using INotification = Cmf.Navigo.BusinessObjects.Abstractions.INotification;

namespace Cmf.Custom.IKEA.Common.Utilities
{
    /// <summary>
    /// Maintenance-specific utilities.
    /// </summary>
    public class MaintenanceUtilities : IMaintenanceUtilities
    {
        private IEntityFactory _entityFactory;
        private IIKEAUtilities _iKEAUtilities;

        [Microsoft.Extensions.DependencyInjection.ActivatorUtilitiesConstructor]
        public MaintenanceUtilities(IEntityFactory entityFactory,
            IGenericUtilities genericUtilities,
            IGenericServiceOrchestration genericServiceOrchestration,
            IIKEAUtilities iKEAUtilities,
            ILocalizationService localizationService)
        {
            _entityFactory = entityFactory;
            _iKEAUtilities = iKEAUtilities;
        }

        #region ERP

        /// <summary>
        /// Creates a new IntegrationEntry containing the MaintenanceActivityOrder's data.
        /// </summary>
        /// <param name="maintenanceActivityOrder">Instance of MaintenanceActivityOrder.</param>
        /// <param name="txt1">description being sent to ERP</param>
        /// <param name="txt2">Signature being sent to ERP</param>
        /// <param name="txt3">detailed description being sent to ERP</param>
        /// <returns>The created IntegrationEntry.</returns>
        public IIntegrationEntry CreateERPMaintenanceRequest(IMaintenanceActivityOrder maintenanceActivityOrder, string txt1 = "",
            string txt2 = "", string txt3 = "")
        {
            //Only proceed if the MAO is associated with a Resource
            if (maintenanceActivityOrder.MaintenancePlanInstance.ReferredEntity.GetType().Equals(typeof(Resource)))
            {
                IResource resource = maintenanceActivityOrder.MaintenancePlanInstance.ReferredEntity as IResource;

                string maintenanceRequestUser = resource.GetERPMaintenanceRequestUser();

                //If the ERPMaintenanceUser attribute could not be obtained, the user's AD account is used
                if (string.IsNullOrEmpty(maintenanceRequestUser))
                {
                    IUser user = _iKEAUtilities.GetInvokingUser();

                    //Discard the Domain's name
                    if (user.UserAccount.IndexOf('\\') != -1)
                    {
                        maintenanceRequestUser = user.UserAccount.Split('\\')[1];
                    }
                    else
                    {
                        maintenanceRequestUser = user.UserAccount;
                    }
                }

                //Load the MAO's attributes
                maintenanceActivityOrder.LoadAttributes(new Collection<string>()
                {
                    IKEAConstants.CustomWorkRequestIdAttribute,
                    IKEAConstants.CustomWorkOrderIdAttribute,
                    IKEAConstants.CustomERPEquipmentIdAttribute
                });

                //Get MAO's attributes
                string workRequestId = maintenanceActivityOrder.GetAttributeValueOrDefault<string>(IKEAConstants.CustomWorkRequestIdAttribute);
                string workOrderid = maintenanceActivityOrder.GetAttributeValueOrDefault<string>(IKEAConstants.CustomWorkOrderIdAttribute);
                string erpEquipmentId = maintenanceActivityOrder.GetAttributeValueOrDefault<string>(IKEAConstants.CustomERPEquipmentIdAttribute);

                string resourceName = resource.Name;
                string resourceType = resource.Type;
                string areaName = resource.Area.Name;
                string facilityName = resource.Area.Facility.Name;

                IMaintenancePlan maintenancePlan = _iKEAUtilities.ResolveCustomERPMaintenancePlansConfiguration(facilityName, areaName, resourceType, resourceName);

                //Check if the maintenance plan should report to ERP and that the MAO has not already been approved by ERP
                if (maintenancePlan != null && workRequestId == null && workOrderid == null && erpEquipmentId == null)
                {
                    //Load resource and its attribute
                    resource.LoadAttributes(new Collection<string>()
                    {
                        IKEAConstants.CustomResourceERPEquipmentIdentifiers,
                        IKEAConstants.CustomERPMaintenanceFacility
                    });

                    //Load the resource's facility attributes
                    resource.Area.Facility.LoadAttribute(IKEAConstants.CustomERPMaintenanceFacilityCode);


                    // Because of the ERP limitations, the Comment string must not contain new line chars and should have a maximum of 40 characters long:
                    txt3 = txt3.Replace("\n", " ");
                    txt3 = txt3.Substring(0, Math.Min(txt3.Length, 40));

                    string erpEquipmentNumber = string.Empty;

                    List<string> resourceERPEquipmentIds = resource.GetAttributeValueOrDefault<List<string>>(IKEAConstants.CustomResourceERPEquipmentIdentifiers);

                    if (resourceERPEquipmentIds != null)
                    {
                        erpEquipmentNumber = resourceERPEquipmentIds.FirstOrDefault();
                    }

                    DateTime scheduleDateTime = maintenanceActivityOrder.ScheduledDate ?? DateTime.Now;

                    //The company field is filled by calling the parent constructor
                    NewWorkOrderRequest request = new NewWorkOrderRequest()
                    {
                        ERPMaintenanceFacilityCode = resource.Area.Facility.GetAttributeValueOrDefault<string>(IKEAConstants.CustomERPMaintenanceFacilityCode),
                        EquipmentNumber = erpEquipmentNumber,
                        MAOType = GetERPType(maintenanceActivityOrder.Type).Item1,
                        TXT3 = txt3,
                        TXT1 = txt1,
                        TXT2 = txt2,
                        ERPFacility = resource.GetAttributeValueOrDefault<string>(IKEAConstants.CustomERPMaintenanceFacility),
                        OrderRequestUser = maintenanceRequestUser,
                        ScheduleDate = scheduleDateTime.ToString("yyyyMMdd"),
                        ScheduleTime = scheduleDateTime.ToString("HHmm"),
                    };

                    return CreateWorkOrderIntegrationEntry(maintenanceActivityOrder.Name, request);
                }
            }

            return null;
        }

        /// <summary>
        /// Creates an IntegrationEntry for requesting a new WorkOrder.
        /// </summary>
        /// <param name="maoName">Name of the MaintenanceActivityOrder</param>
        /// <param name="request">NewWorkOrderRequest</param>
        /// <returns>Created IntegrationEntry instance</returns>
        public IIntegrationEntry CreateWorkOrderIntegrationEntry(string maoName, NewWorkOrderRequest request)
        {
            string requestEndpoint = IKEAConstants.ERPMaintenanceRequestWorkOrder;

            string jsonMessage = JsonConvert.SerializeObject(request, new JsonSerializerSettings
            {
                NullValueHandling = NullValueHandling.Ignore
            });

            MaintenanceMESERPCommunication communication = new MaintenanceMESERPCommunication()
            {
                API = requestEndpoint,
                MaintenanceActivityOrderName = maoName,
                Message = jsonMessage
            };

            XmlDocument xmlDoc = communication.SerializeToXMLDocument();

            return _iKEAUtilities.CreateIntegrationEntry(IKEAConstants.MESSystem, IKEAConstants.ERPSystem, IKEAConstants.ERPRequestWorkOrderMessageType, IKEAConstants.ERPRequestWorkOrderEventName, xmlDoc);
        }

        #endregion

        #region Smart Tables

       

        #endregion

        #region Generic Tables

        /// <summary>
        ///  Uses the CustomERPMaintenanceTypesMapping GenericTable to get the corresponding ERP Maintenance Type.
        /// </summary>
        /// <param name="mesMaintenanceType">MES's maintenance type.</param>
        /// <returns>Tuple representing the ERP's maintenance type, whereby the first item is the MainType and the second item is the SubType.</returns>
        public Tuple<string, string> GetERPType(string mesMaintenanceType)
        {
            string erpMainType = string.Empty;
            string erpSubType = string.Empty;

            //Use the CustomERPMaintenanceTypesMapping Generic Table
            IGenericTable maintenanceTypesTable = new GenericTable();
            maintenanceTypesTable.Load(IKEAConstants.CustomERPMaintenanceTypesMappingGenericTable);

            IFilterCollection maintenanceTypesFilters = new FilterCollection()
            {
                new Filter()
                {
                    Name = IKEAConstants.CustomERPMaintenanceTypesMappingMESTypeColumn,
                    Value = mesMaintenanceType,
                    Operator = Foundation.Common.FieldOperator.IsEqualTo
                }
            };

            maintenanceTypesTable.LoadData(maintenanceTypesFilters);

            if (maintenanceTypesTable.HasData)
            {
                DataRow dataRow = NgpDataSet.ToDataSet(maintenanceTypesTable.Data).Tables[0].AsEnumerable().FirstOrDefault();

                erpMainType = dataRow?.Field<string>(IKEAConstants.CustomERPMaintenanceTypesMappingERPMainTypeColumn);
                erpSubType = dataRow?.Field<string>(IKEAConstants.CustomERPMaintenanceTypesMappingERPSubTypeColumn);
            }

            return new Tuple<string, string>(erpMainType, erpSubType);
        }

        /// <summary>
        ///  Uses the CustomERPMaintenanceTypesMapping GenericTable to get the corresponding MES Maintenance Type.
        /// </summary>
        /// <param name="erpMainType">ERP Main type.</param>
        /// <param name="erpSubType">ERP Sub type.</param>
        /// <returns>MES maintenance type.</returns>
        public string GetMESMaintenanceTypeByERPMainTypeAndSubType(string erpMainType, string erpSubType)
        {
            string mesType = string.Empty;

            //Use the CustomERPMaintenanceTypesMapping Generic Table
            IGenericTable maintenanceTypesTable = new GenericTable();
            maintenanceTypesTable.Load(IKEAConstants.CustomERPMaintenanceTypesMappingGenericTable);

            IFilterCollection maintenanceTypesFilters = new FilterCollection()
            {
                new Filter()
                {
                    Name = IKEAConstants.CustomERPMaintenanceTypesMappingERPMainTypeColumn,
                    Value = erpMainType,
                    Operator = Foundation.Common.FieldOperator.IsEqualTo
                },
                new Filter()
                {
                    Name = IKEAConstants.CustomERPMaintenanceTypesMappingERPSubTypeColumn,
                    Value = erpSubType,
                    Operator = Foundation.Common.FieldOperator.IsEqualTo
                }
            };

            maintenanceTypesTable.LoadData(maintenanceTypesFilters);

            if (maintenanceTypesTable.HasData)
            {
                DataRow dataRow = NgpDataSet.ToDataSet(maintenanceTypesTable.Data).Tables[0].AsEnumerable().FirstOrDefault();

                mesType = dataRow?.Field<string>(IKEAConstants.CustomERPMaintenanceTypesMappingMESTypeColumn);
            }

            return mesType;
        }

        /// <summary>
        ///	Uses the CustomERPStatusMapping GenericTable to get the corresponding MES Maintenance Activity Order Status.
        /// </summary>
        /// <param name="erpStatus">ERP Status. (If null, returns all values)</param>
        /// <returns>MES maintenance activity order status.</returns>
        public Dictionary<string, MaintenanceExecutionStates> GetMaintenanceActivityOrderStatusByERPStatus(string erpStatus = null)
        {
            Dictionary<string, MaintenanceExecutionStates> maoStatus = null;

            // Use the CustomERPStatusMapping Generic Table
            IGenericTable maoStatusTable = new GenericTable();
            maoStatusTable.Load(IKEAConstants.CustomERPStatusMappingGenericTable);

            IFilterCollection erpStatusFilters = null;

            // Only apply filter if we have a status to filter
            if (!string.IsNullOrWhiteSpace(erpStatus))
            {
                erpStatusFilters = new FilterCollection()
                {
                    new Filter()
                    {
                        Name = IKEAConstants.CustomERPStatusMappingERPStatusColumn,
                        Value = erpStatus,
                        Operator = Foundation.Common.FieldOperator.IsEqualTo
                    }
                };
            }

            maoStatusTable.LoadData(erpStatusFilters);

            if (maoStatusTable.HasData)
            {
                DataSet result = NgpDataSet.ToDataSet(maoStatusTable.Data);

                if (result.HasData())
                {
                    maoStatus = NgpDataSet.ToDataSet(maoStatusTable.Data).Tables[0].AsEnumerable().ToDictionary(dr => dr.Field<string>(IKEAConstants.CustomERPStatusMappingERPStatusColumn),
                                                                                                                dr => (MaintenanceExecutionStates)dr.Field<int>(IKEAConstants.CustomERPStatusMappingMESActivityStateColumn));
                }
            }

            return maoStatus;
        }

        #endregion

        #region Queries

        /// <summary>
        /// Get Maintenance Activity Orders By Work Order Id
        /// </summary>
        /// <param name="workOrderId">Work Order Id</param>
        /// <param name="loadEntities">Load the Maintenance Activity Order?</param>
        /// <returns>Maintenance Activity Orders</returns>
        public IMaintenanceActivityOrderCollection GetMaintenanceActivityOrdersByWorkOrderId(string workOrderId, bool loadEntities = false, bool includeTerminated = false)
        {
            IMaintenanceActivityOrderCollection maintenanceActivityOrders = null;

            IQueryObject query = new QueryObject();
            query.Description = "";
            query.EntityTypeName = "MaintenanceActivityOrder";
            query.Name = "GetMaintenanceActivityOrdersByWorkOrderId";
            query.Query = new Query();
            query.Query.Distinct = false;
            query.Query.Filters = new FilterCollection()
            {
                new Filter()
                {
                    Name = "WorkOrderId",
                    ObjectName = "MaintenanceActivityOrder",
                    ObjectAlias = "MaintenanceActivityOrder_1",
                    Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                    Value = workOrderId,
                    LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND,
                    FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                }
            };

            if (includeTerminated == false)
            {
                query.Query.Filters.Add(new Filter()
                {
                    Name = "UniversalState",
                    ObjectName = "MaintenanceActivityOrder",
                    ObjectAlias = "MaintenanceActivityOrder_1",
                    Operator = Cmf.Foundation.Common.FieldOperator.IsNotEqualTo,
                    Value = (int)UniversalState.Terminated,
                    LogicalOperator = Cmf.Foundation.Common.LogicalOperator.Nothing,
                    FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                });
            }

            query.Query.Fields = new FieldCollection()
            {
                new Field()
                {
                    Alias = "Id",
                    ObjectName = "MaintenanceActivityOrder",
                    ObjectAlias = "MaintenanceActivityOrder_1",
                    IsUserAttribute = false,
                    Name = "Id",
                    Position = 0,
                    Sort = Cmf.Foundation.Common.FieldSort.NoSort
                },
                new Field()
                {
                    Alias = "Name",
                    ObjectName = "MaintenanceActivityOrder",
                    ObjectAlias = "MaintenanceActivityOrder_1",
                    IsUserAttribute = false,
                    Name = "Name",
                    Position = 1,
                    Sort = Cmf.Foundation.Common.FieldSort.NoSort
                }
            };

            DataSet queryResults = query.Execute(false, null);

            if (queryResults.HasData())
            {
                maintenanceActivityOrders = _entityFactory.CreateCollection<IMaintenanceActivityOrderCollection>();

                foreach (DataRow row in queryResults.Tables[0].Rows)
                {
                    var maintenanceActivityOrder = _entityFactory.Create<IMaintenanceActivityOrder>();
                    maintenanceActivityOrder.Name = row.Field<string>("Name");
                    maintenanceActivityOrders.Add(maintenanceActivityOrder);
                }

                if (loadEntities)
                {
                    maintenanceActivityOrders.Load();
                }
            }

            return maintenanceActivityOrders;
        }

        /// <summary>
        /// Get All the Maintenance Plan Instances for the Resource
        /// </summary>
        /// <param name="resourceName">Resource Name</param>
        /// <param name="loadEntities">Load Entity?</param>
        /// <returns>Maintenance Plan Instances</returns>
        public IMaintenancePlanInstanceCollection GetMaintenancePlanInstancesForResource(string resourceName, bool loadEntities = false)
        {
            IMaintenancePlanInstanceCollection maintenancePlanInstances = null;

            IQueryObject query = new QueryObject();
            query.Description = "";
            query.EntityTypeName = "MaintenancePlanInstance";
            query.Name = "GetResourceMaintenacePlanInstance";
            query.Query = new Query();
            query.Query.Distinct = false;
            query.Query.Filters = new FilterCollection()
            {
                new Filter()
                {
                    Name = "Name",
                    ObjectName = "Resource",
                    ObjectAlias = "MaintenancePlanInstance_Resource_2",
                    Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                    Value = resourceName,
                    LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND,
                    FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                },
                new Filter()
                {
                    Name = "UniversalState",
                    ObjectName = "MaintenancePlanInstance",
                    ObjectAlias = "MaintenancePlanInstance_1",
                    Operator = Cmf.Foundation.Common.FieldOperator.IsNotEqualTo,
                    Value = 4,
                    LogicalOperator = Cmf.Foundation.Common.LogicalOperator.Nothing,
                    FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                }
            };
            query.Query.Fields = new FieldCollection()
            {
                new Field()
                {
                    Alias = "Id",
                    ObjectName = "MaintenancePlanInstance",
                    ObjectAlias = "MaintenancePlanInstance_1",
                    IsUserAttribute = false,
                    Name = "Id",
                    Position = 0,
                    Sort = Cmf.Foundation.Common.FieldSort.NoSort
                },
                new Field()
                {
                    Alias = "Name",
                    ObjectName = "MaintenancePlanInstance",
                    ObjectAlias = "MaintenancePlanInstance_1",
                    IsUserAttribute = false,
                    Name = "Name",
                    Position = 1,
                    Sort = Cmf.Foundation.Common.FieldSort.NoSort
                }
            };
            query.Query.Relations = new RelationCollection()
            {
                new Relation()
                {
                    Alias = "",
                    IsRelation = false,
                    Name = "",
                    SourceEntity = "MaintenancePlanInstance",
                    SourceEntityAlias = "MaintenancePlanInstance_1",
                    SourceJoinType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.JoinType.InnerJoin,
                    SourceProperty = "ResourceId",
                    TargetEntity = "Resource",
                    TargetEntityAlias = "MaintenancePlanInstance_Resource_2",
                    TargetJoinType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.JoinType.InnerJoin,
                    TargetProperty = "Id"
                }
            };

            DataSet queryResults = query.Execute(false, null);

            if (queryResults.HasData())
            {
                maintenancePlanInstances = _entityFactory.CreateCollection<IMaintenancePlanInstanceCollection>();

                foreach (DataRow row in queryResults.Tables[0].Rows)
                {
                    var maintenancePlanInstance = _entityFactory.Create<IMaintenancePlanInstance>();
                    maintenancePlanInstance.Name = row.Field<string>("Name");
                    maintenancePlanInstances.Add(maintenancePlanInstance);
                }

                if (loadEntities)
                {
                    maintenancePlanInstances.Load();
                }
            }

            return maintenancePlanInstances;

        }
        #endregion

        #region Notifications

        /// <summary>
        /// Generate Notifications for MAOs with open DCs and CheckLists
        /// </summary>
        /// <param name="maosWithoutClosedChecklists">Collection of MAOs with open CheckLists</param>
        /// <param name="maosWithoutFilledDataCollection">Collection of MAOs with open Data Collections not filled</param>
        /// <returns>A boolean indicating if notifications were created</returns>
        public bool GenerateNotificationsForMAOsWithOpenDCAndCheckLists(IMaintenanceActivityOrderCollection maosWithoutClosedChecklists, IMaintenanceActivityOrderCollection maosWithoutFilledDataCollection)
        {
            bool notificationCreated = false;

            if (maosWithoutClosedChecklists.IsNullOrEmpty() && maosWithoutFilledDataCollection.IsNullOrEmpty())
            {
                return notificationCreated;
            }

            const string missingCheckList = "CheckList";
            const string missingDataCollection = "DataCollection";
            const string ownerRole = "OwnerRole";
            const string ownerEmployee = "OwnerEmployee";

            Dictionary<long, Dictionary<string, List<IMaintenanceActivityOrder>>> ownerRolesToNotify = new Dictionary<long, Dictionary<string, List<IMaintenanceActivityOrder>>>();
            Dictionary<long, Dictionary<string, List<IMaintenanceActivityOrder>>> ownerEmployeeToNotify = new Dictionary<long, Dictionary<string, List<IMaintenanceActivityOrder>>>();

            if (!maosWithoutClosedChecklists.IsNullOrEmpty())
            {
                ownerRolesToNotify.AddRange(maosWithoutClosedChecklists.GroupBy(m => m.GetNativeValue<long>(ownerRole))
                                                                        .Where(m => m.Key > 0)
                                                                        .ToDictionary(m => m.Key, m => new Dictionary<string, List<IMaintenanceActivityOrder>>() { { missingCheckList, m.ToList() } }));

                ownerEmployeeToNotify.AddRange(maosWithoutClosedChecklists.GroupBy(m => m.GetNativeValue<long>(ownerEmployee))
                                                                            .Where(m => m.Key > 0)
                                                                            .ToDictionary(m => m.Key, m => new Dictionary<string, List<IMaintenanceActivityOrder>>() { { missingCheckList, m.ToList() } }));
            }

            if (!maosWithoutFilledDataCollection.IsNullOrEmpty())
            {
                foreach (var maoByRole in maosWithoutFilledDataCollection.GroupBy(m => m.GetNativeValue<long>(ownerRole)).Where(m => m.Key > 0))
                {
                    if (!ownerRolesToNotify.ContainsKey(maoByRole.Key))
                    {
                        ownerRolesToNotify[maoByRole.Key] = new Dictionary<string, List<IMaintenanceActivityOrder>>();
                    }

                    ownerRolesToNotify[maoByRole.Key][missingDataCollection] = maoByRole.ToList();
                }

                foreach (var maoByEmployee in maosWithoutFilledDataCollection.GroupBy(m => m.GetNativeValue<long>(ownerEmployee)).Where(m => m.Key > 0))
                {
                    if (!ownerEmployeeToNotify.ContainsKey(maoByEmployee.Key))
                    {
                        ownerEmployeeToNotify[maoByEmployee.Key] = new Dictionary<string, List<IMaintenanceActivityOrder>>();
                    }

                    ownerEmployeeToNotify[maoByEmployee.Key][missingDataCollection] = maoByEmployee.ToList();
                }
            }

            Dictionary<long, IRole> roles = null;
            Dictionary<long, IEmployee> employees = null;

            if (!ownerRolesToNotify.IsNullOrEmpty())
            {
                IRoleCollection roleCollection = new RoleCollection();
                roleCollection.LoadByIDs<IRole, Role>(ownerRolesToNotify.Keys.ToList());

                roles = roleCollection.ToDictionary(r => r.Id, r => r);
            }

            if (!ownerEmployeeToNotify.IsNullOrEmpty())
            {
                IEmployeeCollection employeeCollection = _entityFactory.CreateCollection<IEmployeeCollection>();
                employeeCollection.LoadByIDs<IEmployee, Employee>(ownerEmployeeToNotify.Keys.ToList());

                employees = employeeCollection.ToDictionary(e => e.Id, e => e);
            }

            StringBuilder message = new StringBuilder(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomERPMaintenanceIntegrationCannotCompleteMissingActionLocalizedMessage));

            // Validate Severity in config
            string severity = _iKEAUtilities.GetValueFromConfigurationWithPath(IKEAConstants.DefaultNotificationSeverityConfig);

            if (string.IsNullOrWhiteSpace(severity))
            {
                throw new IKEAException(IKEAConstants.CustomDefaultNotificationSeverityConfigNotDefined, IKEAConstants.DefaultNotificationSeverityConfig);
            }

            INotificationCollection notifications = _entityFactory.CreateCollection<INotificationCollection>();

            // Get the notification severity level
            string notificationSeverity = _iKEAUtilities.GetValueFromLookupTable(IKEAConstants.NotificationSeverityLookupTableName, severity, true);

            foreach (var employeeToNotify in ownerEmployeeToNotify)
            {
                if (employeeToNotify.Value.ContainsKey(missingCheckList))
                {
                    message.AppendLine().Append(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomERPMaintenanceIntegrationCannotCompleteActiveCheckListLocalizedMessage, string.Join(", ", employeeToNotify.Value[missingCheckList].Select(m => m.Name))));
                }
                else if (employeeToNotify.Value.ContainsKey(missingDataCollection))
                {
                    message.AppendLine().Append(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomERPMaintenanceIntegrationCannotCompleteActiveDataCollectionLocalizedMessage, string.Join(", ", employeeToNotify.Value[missingDataCollection].Select(m => m.Name))));
                }

                // Create Notification
                var notification = _entityFactory.Create<INotification>();
                notification.Type = "System";
                notification.Title = _iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomAutomationAttachErrorTitleMessageLocalizedMessage);
                notification.Details = message.ToString();
                notification.Severity = notificationSeverity;
                notification.AssignmentType = (NotificationAssignmentType)AssignmentType.Employee;
                notification.AssignedToUser = (IUser)employees[employeeToNotify.Key];
                notification.ClearanceMode = ClearanceMode.ManualSingleUser;
                notifications.Add(notification);
            }

            foreach (var roleToNotify in ownerRolesToNotify)
            {
                if (roleToNotify.Value.ContainsKey(missingCheckList))
                {
                    message.AppendLine().Append(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomERPMaintenanceIntegrationCannotCompleteActiveCheckListLocalizedMessage, string.Join(", ", roleToNotify.Value[missingCheckList].Select(m => m.Name))));
                }
                else if (roleToNotify.Value.ContainsKey(missingDataCollection))
                {
                    message.AppendLine().Append(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomERPMaintenanceIntegrationCannotCompleteActiveDataCollectionLocalizedMessage, string.Join(", ", roleToNotify.Value[missingDataCollection].Select(m => m.Name))));
                }

                // Create Notification
                var notification =_entityFactory.Create<INotification>();
                notification.Type = "System";
                notification.Title = _iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomERPMaintenanceIntegrationCannotCompleteTitleLocalizedMessage);
                notification.Details = message.ToString();
                notification.Severity = notificationSeverity;
                notification.AssignmentType = (NotificationAssignmentType)AssignmentType.Role;
                notification.AssignedToRole = roles[roleToNotify.Key];
                notification.ClearanceMode = ClearanceMode.ManualSingleUser;
                notifications.Add(notification);
            }

            if (!notifications.IsNullOrEmpty())
            {
                notificationCreated = true;

                notifications.Create();
            }

            return notificationCreated;
        }

        #endregion
    }
}
