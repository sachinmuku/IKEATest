﻿using Cmf.Common.CustomActionUtilities;

using Cmf.Custom.IKEA.BusinessObjects;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.QueryObject;
using Cmf.Foundation.BusinessObjects.SmartTables;
using Cmf.Foundation.BusinessOrchestration.GenericServiceManagement;
using Cmf.Foundation.BusinessOrchestration.GenericServiceManagement.InputObjects;
using Cmf.Foundation.BusinessOrchestration.GenericServiceManagement.OutputObjects;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Base;
using Cmf.Navigo.BusinessObjects;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Cmf.Custom.IKEA.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Foundation.BusinessOrchestration.Abstractions;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Foundation.Common.LocalizationService;
using Cmf.Navigo.BusinessOrchestration.Abstractions;
using INotificationCollection = Cmf.Foundation.BusinessObjects.Abstractions.INotificationCollection;
using Cmf.Custom.IKEA.Common.Enums;


namespace Cmf.Custom.IKEA.Common.Utilities
{
    /// <summary>
    /// Static class containing Stocking Points related utilities
    /// </summary>
    public class StockingPointUtilities : IStockingPointUtilities
    {
        private IEntityFactory _entityFactory;
        private IIKEAUtilities _iKEAUtilities;
        private IGenericUtilities _genericUtilities;
        private IGenericServiceOrchestration _genericServiceOrchestration;
        private ITableOrchestration _tableOrchestration;
        private IOrderOrchestration _orderOrchestration;
        //private IMaterialOrchestration _materialOrchestration;
        private ILocalizationService _localizationService;
        private IDeeContextUtilities _deeContextUtilities;
        private IAlarmHandlingUtilities _alarmHandlingUtilities;

        [Microsoft.Extensions.DependencyInjection.ActivatorUtilitiesConstructor]
        public StockingPointUtilities(IEntityFactory entityFactory,
            IGenericUtilities genericUtilities,
            IGenericServiceOrchestration genericServiceOrchestration,
            IIKEAUtilities iKEAUtilities,
            ILocalizationService localizationService,
            IDeeContextUtilities deeContextUtilities,
            IOrderOrchestration orderOrchestration,
            ITableOrchestration tableOrchestration,
            IAlarmHandlingUtilities alarmHandlingUtilities)
        {
            _entityFactory = entityFactory;
            _genericUtilities = genericUtilities;
            _genericServiceOrchestration = genericServiceOrchestration;
            _iKEAUtilities = iKEAUtilities;
            _localizationService = localizationService;
            _deeContextUtilities = deeContextUtilities;
            _orderOrchestration = orderOrchestration;
            _tableOrchestration = tableOrchestration;
            _alarmHandlingUtilities = alarmHandlingUtilities;
        }
        /// <summary>
        /// Calculate Order Necessities
        /// </summary>
        /// <param name="orderMaterial">Order Material</param>
        /// <param name="orderQuantityToProduce">Order Quantity To Produce</param>
        /// <returns>Order Necessities by Product</returns>
        public Dictionary<IProduct, decimal> CalculateOrderNecessities(IMaterial orderMaterial, decimal orderQuantityToProduce)
        {
            Dictionary<IProduct, decimal> quantitiesByProduct = new Dictionary<IProduct, decimal>();

            // Check if the input parameters are defined
            if (orderMaterial != null
                && orderQuantityToProduce > 0)
            {
                // Check if it should load the material
                if (orderMaterial.Id == 0
                    || string.IsNullOrWhiteSpace(orderMaterial.Name))
                {
                    orderMaterial.Load();
                }

                IBOM materialBOM = null;

                // If the order material doesn't have a BOM associated, 
                // try to resolve one for the material
                if (orderMaterial.CurrentBOMVersion == null)
                {
                    // Resolve BOM for the material
                    IResolveBomContextsResult bomContextsResult = orderMaterial.Product.ResolveBomContexts(orderMaterial);

                    if (bomContextsResult != null)
                    {
                        materialBOM = bomContextsResult.Bom;
                    }
                }
                else
                {
                    // Get the BOM defined in the material
                    materialBOM = orderMaterial.CurrentBOMVersion;
                }

                // Check if there is any BOM for the Material
                if (materialBOM != null)
                {
                    // Get all the BOM Products from the BOM
                    IBOMProductCollection bomProducts = materialBOM.GetBOMProducts();

                    // Check if the BOM has any products defined
                    if (!bomProducts.IsNullOrEmpty())
                    {
                        // Get all the products from BOM that are not reference and are not Substitutes, and the summed quantity for each one
                        Dictionary<long, decimal> productQuantities = bomProducts.Where(bp => !bp.IsReference.GetValueOrDefault() && bp.Parent == null)
                                                                                    .GroupBy(bp => bp.GetNativeValue<long>("TargetEntity"))
                                                                                    .ToDictionary(bp => bp.Key, bp => bp.ToList().Sum(p => p.Quantity.GetValueOrDefault()));

                        if (!productQuantities.IsNullOrEmpty())
                        {
                            IProductCollection products = _entityFactory.CreateCollection<IProductCollection>();
                            products.LoadByIDs<IProduct, Product>(productQuantities.Keys.Distinct().ToList());

                            // Set the Products and the required quantity for each one
                            quantitiesByProduct.AddRange(products.ToDictionary(p => p, p => orderQuantityToProduce * productQuantities[p.DefinitionId]));
                        }
                    }
                }
            }

            return quantitiesByProduct;
        }

        /// <summary>
        /// Updates the received quantity with the amount indicated. If quantity equals or exceeds requested, terminates the request.
        /// </summary>
        /// <param name="stockingPoint"></param>
        /// <param name="product"></param>
        /// <param name="deliveredQuantity"></param>
        public void UpdateReplenishmentRequest(string stockingPoint, string product, decimal deliveredQuantity)
        {
            // Gets all material transfer requests for this stocking point and product:
            var requestTrackers = GetCustomMaterialReplenishmentRequestTrackers(stockingPoint, product);

            if (!requestTrackers.IsNullOrEmpty())
            {
                // Update delivered quantity:
                ICustomMaterialReplenishmentRequestTracker requestTracker = requestTrackers.FirstOrDefault();
                requestTracker.DeliveredQuantity += deliveredQuantity;
                requestTracker.Save();

                // If the delivered quantity matches or exceeds the requested quantity, terminates the request:
                if (requestTracker.DeliveredQuantity >= requestTracker.RequestedQuantity)
                {
                    // Terminates the requests and associated tasks:
                    var customMaterialReplenishmentRequestTrackerCollection = _entityFactory.CreateCollection<ICustomMaterialReplenishmentRequestTrackerCollection>();
                    customMaterialReplenishmentRequestTrackerCollection.Add(requestTracker);
                    TerminateStockingPointTrackersAndTasks(customMaterialReplenishmentRequestTrackerCollection, terminateTasks: true);
                }
            }
        }

        /// <summary>
        /// Clears all requests that are not used any longer. Also terminates its associated tasks.
        /// </summary>
        /// <param name="stockingPoint"></param>
        /// <param name="product"></param>
        /// <param name="deliveredQuantity"></param>
        public void CleanUpReplenishmentRequest(string stockingPoint, IProductCollection products)
        {
            if (products != null)
            {
                // Gets all the material transfer requests for this stocking point:
                var stockingPointTrackers = GetCustomMaterialReplenishmentRequestTrackers(stockingPoint);

                if (!stockingPointTrackers.IsNullOrEmpty())
                {
                    ICustomMaterialReplenishmentRequestTrackerCollection materialReplenishmentRequestTrackers = _entityFactory.CreateCollection<ICustomMaterialReplenishmentRequestTrackerCollection>();
                    // Gets all the MaterialReplenishmentRequestTrackers that do not exist in the Product list:
                    materialReplenishmentRequestTrackers.AddRange(stockingPointTrackers.Where(spt => !products.Any(pr => pr.Name.Equals(spt.ProductName)) && spt.DeliveredQuantity == 0));

                    // Terminates all requests and associated tasks
                    TerminateStockingPointTrackersAndTasks(materialReplenishmentRequestTrackers, terminateNotifications: true);
                }
            }
        }

        /// <summary>
        /// Terminates request trackers and associated Tasks
        /// </summary>
        /// <param name="stockingPointTrackersToTerminate"></param>
        /// <param name="stockingPoint"></param>
        public void TerminateStockingPointTrackersAndTasks(ICustomMaterialReplenishmentRequestTrackerCollection stockingPointTrackersToTerminate,
                                                                    bool terminateTasks = false,
                                                                    bool terminateNotifications = false)
        {
            if (!stockingPointTrackersToTerminate.IsNullOrEmpty())
            {
                List<long> trackerIds = stockingPointTrackersToTerminate.Select(s => s.Id).ToList();

                if (terminateTasks)
                {
                    // Complete all tasks for each stocking point and product (need to iterate each one because products can be different):
                    ITaskCollection tasksToComplete = _iKEAUtilities.GetMaterialTransferRequestTasksFromTrackerId(trackerIds);

                    if (!tasksToComplete.IsNullOrEmpty())
                    {
                        // load attributes
                        tasksToComplete.LoadAttributes();
                        // Update progress:
                        tasksToComplete.ToList().ForEach(t => t.Progress = 100);
                        // Perform tasks:
                        tasksToComplete.Perform(new OperationAttributeCollection());

                        // collect all task attributes
                        var notificationsToSend = tasksToComplete.Select(E => new
                        {
                            Facility = E.GetAttributeValueOrDefault<string>(IKEAConstants.MaterialTransferFromFacility) ?? String.Empty
                            ,
                            Area = E.GetAttributeValueOrDefault<string>(IKEAConstants.MaterialTransferFromArea) ?? String.Empty
                            ,
                            Resource = E.GetAttributeValueOrDefault<string>(IKEAConstants.MaterialTransferFromLocation) ?? String.Empty
                        }).Distinct();

                        foreach (var entry in notificationsToSend)
                        {
                            _iKEAUtilities.PublishMaterialMovementEvent(entry.Facility, entry.Area, entry.Resource);
                        }
                    }
                }

                if (terminateNotifications)
                {
                    // Terminate the notifications
                    INotificationCollection notifications = _iKEAUtilities.GetMaterialTransferRequestNotificationsFromTrackerId(trackerIds);

                    if (!notifications.IsNullOrEmpty())
                    {
                        // Load attributes to generate GUI refresh
                        notifications.LoadAttributes();

                        // collect all task attributes
                        var notificationsToSend = notifications.Select(E => new
                        {
                            Facility = E.GetAttributeValueOrDefault<string>(IKEAConstants.MaterialTransferFromFacility) ?? String.Empty
                            ,
                            Area = E.GetAttributeValueOrDefault<string>(IKEAConstants.MaterialTransferFromArea) ?? String.Empty
                            ,
                            Resource = E.GetAttributeValueOrDefault<string>(IKEAConstants.MaterialTransferFromLocation) ?? String.Empty
                        }).Distinct();

                        foreach (var entry in notificationsToSend)
                        {
                            _iKEAUtilities.PublishMaterialMovementEvent(entry.Facility, entry.Area, entry.Resource);
                        }

                        // Set the context for the CustomERPChangeTypeReport indicating that the change type is being done by the unit completion
                        _deeContextUtilities.SetContextParameter(IKEAConstants.TerminateStockingPointTrackersAndTasksTerminateNotifications, true);

                        // terminate the notifications
                        notifications.Terminate();

                        // Set the context for the CustomERPChangeTypeReport indicating that the change type is being done by the unit completion
                        _deeContextUtilities.SetContextParameter(IKEAConstants.TerminateStockingPointTrackersAndTasksTerminateNotifications, false);

                    }
                }

                // Terminate all requests:
                stockingPointTrackersToTerminate.Terminate();
            }
        }

        /// <summary>
        /// Gets all CustomMaterialReplenishmentRequestTrackers for the specified Stocking Point
        /// </summary>
        /// <param name="stockingPoint"></param>
        /// <returns>CustomMaterialReplenishmentRequestTrackerCollection for the specified StockingPoint</returns>
        public ICustomMaterialReplenishmentRequestTrackerCollection GetCustomMaterialReplenishmentRequestTrackers(string stockingPoint, string product = null)
        {
            ICustomMaterialReplenishmentRequestTrackerCollection requestTrackers = null;

            IQueryObject query = new QueryObject();
            query.Description = "";
            query.EntityTypeName = "CustomMaterialReplenishmentRequestTracker";
            query.Name = "GetCustomMaterialReplenishmentRequestTracker";
            query.Query = new Query();
            query.Query.Distinct = false;
            query.Query.Filters = new FilterCollection() {
                new Filter()
                {
                    Name = "StockingPoint",
                    ObjectName = "CustomMaterialReplenishmentRequestTracker",
                    ObjectAlias = "CustomMaterialReplenishmentRequestTracker_1",
                    Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                    Value = stockingPoint,
                    LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND,
                    FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                },
                new Filter()
                {
                    Name = "UniversalState",
                    ObjectName = "CustomMaterialReplenishmentRequestTracker",
                    ObjectAlias = "CustomMaterialReplenishmentRequestTracker_1",
                    Operator = Cmf.Foundation.Common.FieldOperator.IsNotEqualTo,
                    Value = (int)UniversalState.Terminated,
                    LogicalOperator = Cmf.Foundation.Common.LogicalOperator.Nothing,
                    FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                }
            };

            if (product != null)
            {
                query.Query.Filters.Add(
                    new Filter()
                    {
                        Name = "ProductName",
                        ObjectName = "CustomMaterialReplenishmentRequestTracker",
                        ObjectAlias = "CustomMaterialReplenishmentRequestTracker_1",
                        Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                        Value = product,
                        LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND,
                        FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                    });
            }

            query.Query.Fields = new FieldCollection() {
                new Field()
                {
                    Alias = "Id",
                    ObjectName = "CustomMaterialReplenishmentRequestTracker",
                    ObjectAlias = "CustomMaterialReplenishmentRequestTracker_1",
                    IsUserAttribute = false,
                    Name = "Id",
                    Position = 0,
                    Sort = Cmf.Foundation.Common.FieldSort.NoSort
                },
                new Field()
                {
                    Alias = "Name",
                    ObjectName = "CustomMaterialReplenishmentRequestTracker",
                    ObjectAlias = "CustomMaterialReplenishmentRequestTracker_1",
                    IsUserAttribute = false,
                    Name = "Name",
                    Position = 1,
                    Sort = Cmf.Foundation.Common.FieldSort.NoSort
                }
            };
            query.Query.Relations = new RelationCollection();

            DataSet resultDataSet = query.Execute(false, new QueryParameterCollection());

            if (resultDataSet.HasData())
            {
                requestTrackers = _entityFactory.CreateCollection<ICustomMaterialReplenishmentRequestTrackerCollection>();


                foreach (DataRow requestTrackerRow in resultDataSet.Tables[0].Rows)
                {
                    var requestTracker = _entityFactory.Create<ICustomMaterialReplenishmentRequestTracker>();
                    requestTracker.Name = requestTrackerRow.Field<string>("Name");
                    requestTrackers.Add(requestTracker);
                }

                if (!requestTrackers.IsNullOrEmpty())
                {
                    requestTrackers.Load();
                }
            }
            return requestTrackers;
        }

        /// <summary>
        /// Gets all Tasks of type MaterialTransferRequest for the specified StockingPoint and Product
        /// </summary>
        /// <param name="stockingPoint"></param>
        /// <param name="product"></param>
        /// <returns>TaskCollection</returns>
        public ITaskCollection GetMaterialTransferTasks(string stockingPoint, string product)
        {
            ITaskCollection tasks = _entityFactory.CreateCollection<ITaskCollection>();

            // Get Configured type
            string taskType = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.CustomMaterialTransferRequestTypePath);

            IQueryObject query = new QueryObject();
            query.Description = "";
            query.EntityTypeName = "Task";
            query.Name = "GetMaterialTransferTasks";
            query.Query = new Query();
            query.Query.Distinct = false;
            query.Query.Filters = new FilterCollection()
            {
                new Filter()
                {
                    Name = "TaskType",
                    ObjectName = "Task",
                    ObjectAlias = "Task_1",
                    Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                    Value = taskType,
                    LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND,
                    FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                },
                new Filter()
                {
                    Name = "MaterialTransferRequiredProduct",
                    ObjectName = "Task",
                    ObjectAlias = "Task_1",
                    Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                    Value = product,
                    LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND,
                    FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                },
                new Filter()
                {
                    Name = "MaterialTransferToLocation",
                    ObjectName = "Task",
                    ObjectAlias = "Task_1",
                    Operator = Cmf.Foundation.Common.FieldOperator.Contains,
                    Value = stockingPoint,
                    LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND,
                    FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                },
                new Filter()
                {
                    Name = "UniversalState",
                    ObjectName = "Task",
                    ObjectAlias = "Task_1",
                    Operator = Cmf.Foundation.Common.FieldOperator.IsNotEqualTo,
                    Value = (int)UniversalState.Terminated,
                    LogicalOperator = Cmf.Foundation.Common.LogicalOperator.Nothing,
                    FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                }
            };
            query.Query.Fields = new FieldCollection()
            {
                new Field()
                {
                    Alias = "Id",
                    ObjectName = "Task",
                    ObjectAlias = "Task_1",
                    IsUserAttribute = false,
                    Name = "Id",
                    Position = 0,
                    Sort = Cmf.Foundation.Common.FieldSort.NoSort
                },
                new Field()
                {
                    Alias = "Name",
                    ObjectName = "Task",
                    ObjectAlias = "Task_1",
                    IsUserAttribute = false,
                    Name = "Name",
                    Position = 1,
                    Sort = Cmf.Foundation.Common.FieldSort.NoSort
                }
            };

            query.Query.Relations = new RelationCollection();

            DataSet resultDataSet = query.Execute(false, new QueryParameterCollection());
            if (resultDataSet.HasData())
            {
                foreach (DataRow row in resultDataSet.Tables[0].Rows)
                {
                    var task = _entityFactory.Create<ITask>();
                    task.Name = row.Field<string>("Name");

                    tasks.Add(task);
                }

                if (!tasks.IsNullOrEmpty())
                {
                    tasks.Load();
                }
            }
            return tasks;
        }

        /// <summary>
        /// Returns the orders and the remaining quantity to be produced by each order on the line
        /// </summary>
        /// <param name="mainLine">Resource where orders will be fetched</param>
        /// <param name="workingMode">WorkingMode of the resource</param>
        /// <param name="hoursToConsider">Timeframe to search for orders</param>
        /// <returns></returns>
        public Dictionary<IMaterial, decimal?> RetrieveOrderQuantity(IResource mainLine, CustomMaterialReplenishmentWorkingModeEnum workingMode, decimal? hoursToConsiderInput)
        {
            //Dictionary to return data
            Dictionary<IMaterial, decimal?> orderQuantity = new Dictionary<IMaterial, decimal?>();

            //Depending on working mode, return a list of materials at resource
            switch (workingMode)
            {
                case CustomMaterialReplenishmentWorkingModeEnum.ActiveOrder:
                    //Validate that Resource is loaded
                    if (mainLine.Id <= 0)
                    {
                        mainLine.Load();
                    }
                    List<int> systemStatesInProgress = new List<int>();
                    systemStatesInProgress.Add((int)MaterialSystemState.InProcess);

                    //Query for all materials in progress on the Resource
                    IMaterialCollection materialsInProgressAtResource = _iKEAUtilities.GetMaterialsInProgressOnMainLine(mainLine.Id, systemStatesInProgress, true);
                    if (!materialsInProgressAtResource.IsNullOrEmpty())
                    {
                        orderQuantity.AddRange(materialsInProgressAtResource.ToDictionary(mat => mat, mat => mat.PrimaryQuantity));
                    }
                    break;
                case CustomMaterialReplenishmentWorkingModeEnum.AllOrders:
                    //Validate that Resource is loaded
                    if (mainLine.Id <= 0)
                    {
                        mainLine.Load();
                    }
                    //Get all Materials available to be dispatched to the Resource
                    IMaterialCollection materialsDispatchable = mainLine.GetDispatchList();

                    // List to filter SystemStates
                    List<int> systemStatesToFilter = new List<int>();
                    systemStatesToFilter.Add((int)MaterialSystemState.Dispatched);
                    systemStatesToFilter.Add((int)MaterialSystemState.InProcess);

                    //Query for all materials InProgress / Dispatched on the Resource
                    IMaterialCollection allMaterialsAtResource = _iKEAUtilities.GetMaterialsInProgressOnMainLine(mainLine.Id, systemStatesToFilter, true);
                    if (!materialsDispatchable.IsNullOrEmpty())
                    {
                        allMaterialsAtResource.AddRange(materialsDispatchable);
                    }
                    if (!allMaterialsAtResource.IsNullOrEmpty())
                    {
                        orderQuantity.AddRange(allMaterialsAtResource.ToDictionary(mat => mat, mat => mat.PrimaryQuantity));
                    }
                    break;
                case CustomMaterialReplenishmentWorkingModeEnum.TimeRestricted:

                    DateTime actualDate = DateTime.Now;
                    double hoursToConsider = (double)hoursToConsiderInput.GetValueOrDefault();

                    if (hoursToConsider > 0)
                    {
                        //Setup provisory timeframe
                        DateTime startLimit = actualDate;
                        DateTime endLimit = actualDate.AddHours(hoursToConsider);

                        //Default hours to exclude
                        long hoursToNotConsiderForShift = 0;
                        //Load Calendar days
                        mainLine.Area.Calendar.LoadDays(startLimit.AddDays(-1), endLimit);

                        #region Get actual time to consider

                        if (!mainLine.Area.Calendar.CalendarDays.IsNullOrEmpty())
                        {
                            //Iterate through each Calendar day inside the timeframe
                            foreach (ICalendarDay day in mainLine.Area.Calendar.CalendarDays.OrderBy(x => x.Day).ToList())
                            {
                                day.LoadShifts();
                                //Validate if day has ShiftDefinition and ShiftDefinition has entries
                                if (day.ShiftDefinition != null && !day.ShiftDefinition.ShiftsCollection.IsNullOrEmpty())
                                {
                                    //Get the shift definition shift for the calendar days
                                    foreach (IShiftDefinitionShift shift in day.ShiftDefinition.ShiftsCollection)
                                    {
                                        //Store shift start and end
                                        DateTime shiftStart = day.Day.GetValueOrDefault().Date.Add(shift.StartTime.Value);
                                        DateTime shiftEnd = day.Day.GetValueOrDefault().Date.Add(shift.EndTime.Value);
                                        //In case shift starts at 7PM and ends at 3PM > shift end is on the following day
                                        if (shift.StartTime.Value <= shift.EndTime.Value)
                                        {
                                            shiftEnd.AddDays(1);
                                        }

                                        //Exclude all shifts that Ended After Actual Date AND Starterd after DateLimit
                                        if (shiftStart <= endLimit && shiftEnd >= startLimit)
                                        {
                                            //Shift Start and End occur inside the timeframe [ NOW , LIMIT DATE ]
                                            if (shiftStart >= startLimit && shiftEnd <= endLimit)
                                            {
                                                //Decrement all NonWorking hours from shift if existing
                                                if (!shift.NonWorkingTimeCollection.IsNullOrEmpty())
                                                {
                                                    hoursToNotConsiderForShift += shift.NonWorkingTimeCollection.Select(x => x.EndTime - x.StartTime).Sum(x => x.Ticks);
                                                }
                                            }
                                            else
                                            {
                                                //Case when shift starts before the timeframe or ends after the timeframe
                                                //Need to decrement the nonworking hours that occurred inside the defined timeframe
                                                if (!shift.NonWorkingTimeCollection.IsNullOrEmpty())
                                                {
                                                    foreach (INonWorkingTime nonWorkingTime in shift.NonWorkingTimeCollection)
                                                    {
                                                        //Store NonWorkingTime start and end
                                                        DateTime startNonWorkingTime = day.Day.GetValueOrDefault().Date.Add(nonWorkingTime.StartTime);
                                                        DateTime endNonWorkingTime = day.Day.GetValueOrDefault().Date.Add(nonWorkingTime.EndTime);

                                                        //In case NonWorkingTime starts at 7PM and ends at 3PM > NonWorkingTime end is on the following day
                                                        if (nonWorkingTime.StartTime <= nonWorkingTime.EndTime)
                                                        {
                                                            endNonWorkingTime.AddDays(1);
                                                        }

                                                        //Exclude all nonworking times that Ended After Actual Date AND Started after DateLimit
                                                        if (startNonWorkingTime <= endLimit && endNonWorkingTime >= startLimit)
                                                        {
                                                            if (startNonWorkingTime >= startLimit)
                                                            {
                                                                //nonWorkingTimeStart and nonWorkingTimeEnd occur inside the timeframe [ NOW , LIMIT DATE ]
                                                                if (endNonWorkingTime <= endLimit)
                                                                {
                                                                    //All nonWorking hours need to be considered
                                                                    hoursToNotConsiderForShift += (endNonWorkingTime - startNonWorkingTime).Ticks;
                                                                }
                                                                else
                                                                {
                                                                    //WorkingHours to be considered are between nonWorkingTimeStart and DateLimit
                                                                    hoursToNotConsiderForShift += (startNonWorkingTime - endLimit).Ticks;
                                                                }
                                                            }
                                                            //nonWorkingTimeStart stars before dateStartLimitToConsider and ends before DateLimit
                                                            if (startNonWorkingTime < startLimit)
                                                            {
                                                                //nonWorkingTimeStart before ActualDate and ended after DateLimit
                                                                if (endNonWorkingTime > endLimit)
                                                                {
                                                                    hoursToNotConsiderForShift += (endLimit - startLimit).Ticks;
                                                                }
                                                                //nonWorkingTimeStart before ActualDate and ended after DateLimit
                                                                else
                                                                {
                                                                    hoursToNotConsiderForShift += (endNonWorkingTime - startLimit).Ticks;
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        TimeSpan hoursToNotConsider = new TimeSpan(hoursToNotConsiderForShift);
                        //Decrement the nonworking hours to the limit date to consider for MO gathering
                        endLimit = endLimit.Subtract(hoursToNotConsider);
                        #endregion

                        //Get all materials assigned to the line
                        IResourceMaterialInformationCollection materialsAssignedToLine = mainLine.GetResourceMaterialInformation(false);

                        DateTime materialStart = DateTime.Now;
                        //Iterate through all materials InProgress ordered by Order and then materials Dispatched ordered by Order
                        foreach (IMaterial material in materialsAssignedToLine.OrderByDescending(x => x.Material.SystemState).ThenBy(x => x.Order).Select(x => x.Material))
                        {
                            IProductionOrder productionOrder = material.ProductionOrder;
                            //Only consider materials with PO and CustomPOOperationResource relation defined
                            if (material.ProductionOrder != null)
                            {
                                productionOrder.LoadRelations(IKEAConstants.CustomPOOperationResource);
                                if (productionOrder.RelationCollection.ContainsKey(IKEAConstants.CustomPOOperationResource))
                                {
                                    if (productionOrder.RelationCollection != null)
                                    {
                                        var relations = productionOrder.RelationCollection.FirstOrDefault(E => E.Key.CompareStrings(IKEAConstants.CustomPOOperationResource));
                                        if (relations.Value != null)
                                        {
                                            ICustomPOOperationResource poOperationResource = productionOrder.RelationCollection[IKEAConstants.CustomPOOperationResource]
                                                .Where(ER => ER.TargetEntity.Id == mainLine.Id)
                                                .Select(ER => ER as ICustomPOOperationResource).FirstOrDefault();

                                            if (poOperationResource != null)
                                            {
                                                //Get CycleTime from CustomPOOperationResource relation
                                                decimal projectedCycleTime = poOperationResource.ProjectedCycleTime.HasValue ? poOperationResource.ProjectedCycleTime.Value : 1;

                                                //Calculate estimated MO finish time
                                                DateTime estimatedMaterialFinishTime;
                                                if (material.CurrentMainState.StateModel.Name.CompareStrings(IKEAConstants.MaterialStateModel)
                                                    && material.CurrentMainState.CurrentState.Name.CompareStrings(IKEAConstants.MaterialStateModelSetup))
                                                {
                                                    double expectedSetupTime = 0;
                                                    DateTime dateToConsider = materialStart.AddSeconds(expectedSetupTime);
                                                    estimatedMaterialFinishTime = dateToConsider.AddSeconds((double)(material.PrimaryQuantity.Value * projectedCycleTime));
                                                }
                                                else
                                                {
                                                    estimatedMaterialFinishTime = materialStart.AddSeconds((double)(material.PrimaryQuantity.Value * projectedCycleTime));
                                                }
                                                //If material will complete all quantity inside the time limit > add all its quantity
                                                if (estimatedMaterialFinishTime <= endLimit)
                                                {
                                                    orderQuantity.Add(material, material.PrimaryQuantity.Value);
                                                    if (estimatedMaterialFinishTime == endLimit) break;
                                                }
                                                else
                                                {
                                                    //Calculate quantity that can be produced until dateLimitToConsider
                                                    TimeSpan producingInterval = endLimit - materialStart;
                                                    decimal QuantityThatCanStillBeProduced = (decimal)producingInterval.TotalSeconds / (decimal)projectedCycleTime;
                                                    orderQuantity.Add(material, QuantityThatCanStillBeProduced);
                                                    break;
                                                }
                                                //Update material start to the end of the last analyzed material
                                                materialStart = estimatedMaterialFinishTime;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    break;
            }
            return orderQuantity;
        }

        /// <summary>
        /// Get all the material replenishment request configurations from the smart table CustomMaterialReplenishmentRequestConfiguration
        /// </summary>
        /// <returns>All the material replenishment request configurations</returns>
        public List<MaterialReplenishmentRequestConfiguration> GetMaterialReplenishmentRequestConfiguration()
        {
            List<MaterialReplenishmentRequestConfiguration> configurations = new List<MaterialReplenishmentRequestConfiguration>();

            ISmartTable smartTable = new SmartTable() { Name = IKEAConstants.CustomMaterialReplenishmentRequestConfigurationSmartTable };
            smartTable.Load();
            smartTable.LoadData();

            INgpDataSet resultSet = smartTable.Data;
            DataSet resultDataSet = NgpDataSet.ToDataSet(resultSet);

            if (resultDataSet.HasData())
            {
                foreach (DataRow row in resultDataSet.Tables[0].Rows)
                {
                    configurations.Add(new MaterialReplenishmentRequestConfiguration()
                    {
                        StockingPoint = row.Field<string>(IKEAConstants.CustomMaterialReplenishmentRequestConfigurationStockingPoint),
                        Product = row.Field<string>(IKEAConstants.CustomMaterialReplenishmentRequestConfigurationProduct),
                        ProductType = row.Field<string>(IKEAConstants.CustomMaterialReplenishmentRequestConfigurationProductType),
                        WorkingMode = (CustomMaterialReplenishmentWorkingModeEnum)row.Field<int>(IKEAConstants.CustomMaterialReplenishmentRequestConfigurationWorkingMode),
                        HoursToConsider = row.Field<decimal?>(IKEAConstants.CustomMaterialReplenishmentRequestConfigurationHoursToConsider),
                        RequestMode = (CustomMaterialReplenishmentRequestModeEnum)row.Field<int>(IKEAConstants.CustomMaterialReplenishmentRequestConfigurationRequestMode),
                        QuantityToRequest = row.Field<decimal?>(IKEAConstants.CustomMaterialReplenishmentRequestConfigurationQuantityToRequest),
                        Threshold = row.Field<decimal?>(IKEAConstants.CustomMaterialReplenishmentRequestConfigurationThreshold),
                        Facility = row.Field<string>(IKEAConstants.CustomMaterialReplenishmentRequestConfigurationFacility),
                        Area = row.Field<string>(IKEAConstants.CustomMaterialReplenishmentRequestConfigurationArea)
                    });
                }

            }

            return configurations;
        }

        /// <summary>
        /// Get all stocking points of a line
        /// </summary>
        /// <param name="resource">Main Line</param>
        /// <returns>Cll stocking points of a line</returns>
        public ICustomStockingPointResourceCollection GetLineStockingPoint(IResource resource)
        {
            
            ICustomStockingPointResourceCollection stockingPointResources = _entityFactory.CreateCollection<ICustomStockingPointResourceCollection>();

            GetObjectsByFilterInput getObjectsByFilterInput = new GetObjectsByFilterInput()
            {
                Filter = new FilterCollection()
                   {
                       new Filter()
                       {
                            Name = "TargetEntityId",
                            Operator = FieldOperator.IsEqualTo,
                            Value = resource.Id
                       }
                   },
                Type = _entityFactory.Create<ICustomStockingPointResource>()
            };

            GetObjectsByFilterOutput getObjectsByFilterOutput = _genericServiceOrchestration.GetObjectsByFilter(getObjectsByFilterInput);

            if (getObjectsByFilterOutput != null && getObjectsByFilterOutput.Instance != null && getObjectsByFilterOutput.Instance.Any())
            {
                stockingPointResources.AddRange(getObjectsByFilterOutput.Instance.Cast<ICustomStockingPointResource>());
            }

            return stockingPointResources;
        }

        /// <summary>
        /// Check if the stocking point replenishment request already exists
        /// </summary>
        /// <param name="productName">Requested Product</param>
        /// <param name="requestedQuantity">Requested quantity</param>
        /// <param name="stockingPoint">The stocking point to where the request was made</param>
        /// <returns>True if request already exists</returns>
        public bool ReplenishmentRequestExists(string productName, decimal requestedQuantity, string stockingPoint)
        {
            ICustomMaterialReplenishmentRequestTrackerCollection materialReplenishmentRequestTrackers = _entityFactory.CreateCollection<ICustomMaterialReplenishmentRequestTrackerCollection>();

            GetObjectsByFilterInput getObjectsByFilterInput = new GetObjectsByFilterInput()
            {
                Filter = new FilterCollection()
                   {
                       new Filter()
                       {
                            Name = "ProductName",
                            Operator = FieldOperator.IsEqualTo,
                            Value = productName
                       },
                       new Filter()
                       {
                            Name = "RequestedQuantity",
                            Operator = FieldOperator.IsEqualTo,
                            Value = requestedQuantity
                       },
                       new Filter()
                       {
                            Name = "StockingPoint",
                            Operator = FieldOperator.IsEqualTo,
                            Value = stockingPoint
                       },
                       new Filter()
                       {
                            Name = "UniversalState",
                            Operator = FieldOperator.IsNotEqualTo,
                            Value = (int)UniversalState.Terminated
                       }
                   },
                Type = _entityFactory.Create<ICustomMaterialReplenishmentRequestTracker>()
            };

            GetObjectsByFilterOutput getObjectsByFilterOutput = _genericServiceOrchestration.GetObjectsByFilter(getObjectsByFilterInput);

            if (getObjectsByFilterOutput != null && getObjectsByFilterOutput.Instance != null && getObjectsByFilterOutput.Instance.Any())
            {
                materialReplenishmentRequestTrackers.AddRange(getObjectsByFilterOutput.Instance.Cast<ICustomMaterialReplenishmentRequestTracker>());
            }

            return !materialReplenishmentRequestTrackers.IsNullOrEmpty();
        }

    }
}
