﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Exceptions;
using Cmf.Custom.IKEA.Common.Extensions;
using Cmf.Custom.IKEA.Common.NiceLabel;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessObjects.QueryObject;
using Cmf.Foundation.BusinessObjects.SmartTables;
using Cmf.Foundation.BusinessOrchestration.Abstractions;
using Cmf.Foundation.BusinessOrchestration.TableManagement.InputObjects;
using Cmf.Foundation.BusinessOrchestration.TableManagement.OutputObjects;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Foundation.Common.LocalizationService;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Xml;

namespace Cmf.Custom.IKEA.Common.Utilities
{
    public class NiceLabelUtilities : INiceLabelUtilities
    {
        private IEntityFactory _entityFactory;
        private IIKEAUtilities _iKEAUtilities;
        private IGenericUtilities _genericUtilities;
        private IGenericServiceOrchestration _genericServiceOrchestration;
        //private IMaterialOrchestration _materialOrchestration;
        private ILocalizationService _localizationService;

        [Microsoft.Extensions.DependencyInjection.ActivatorUtilitiesConstructor]
        public NiceLabelUtilities(IEntityFactory entityFactory,
            IGenericUtilities genericUtilities,
            IGenericServiceOrchestration genericServiceOrchestration,
            IIKEAUtilities iKEAUtilities,
            ILocalizationService localizationService)
        {
            _entityFactory = entityFactory;
            _genericUtilities = genericUtilities;
            _genericServiceOrchestration = genericServiceOrchestration;
            _iKEAUtilities = iKEAUtilities;
            _localizationService = localizationService;
        }

        /// <summary>
        /// Sends an HTTP NiceLabel Message
        /// </summary>
        /// <param name="serializedMessage">NiceLabelIntegrationMessage serialized to a json string
        /// <param name="messageEndpoint"></param>
        /// <returns></returns>
        public string SendNiceLabelMessage(string serializedMessage, string messageEndpoint)
        {
            return SendNiceLabelMessage(serializedMessage, messageEndpoint, HttpMethod.Post);
        }

        /// <summary>
        /// Send NiceLabel Message
        /// </summary>
        /// <param name="message">Dictionary that contains the parameters and their values</param>
        /// <param name="messageEndpoint"></param>
        /// <returns></returns>
        public string SendNiceLabelMessage(string serializedMessage, string messageEndpoint, HttpMethod httpMethod)
        {
            string result = string.Empty;
            bool isBodyLess = httpMethod == HttpMethod.Get;

            if (!string.IsNullOrWhiteSpace(serializedMessage) || isBodyLess)
            {
                // Check if authentication is required
                bool isToAuthenticate = _genericUtilities.GetConfigurationValueByPath<bool>(IKEAConstants.NiceLabelIsToAuthenticate);

                string accessToken = String.Empty;

                // Get access token if authentication is required
                if (isToAuthenticate)
                {
                    accessToken = GetNiceLabelAccessToken();

                    // Check if the access token was retrieved
                    if (String.IsNullOrEmpty(accessToken))
                    {
                        throw new IKEAException(IKEAConstants.CustomNiceLabelUnableToObtainTokenLocalizedMessage);
                    }
                }

                // Get base URL
                string baseURL = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.NiceLabelBaseEndpoint);

                // Check if any base URL was configured
                if (!string.IsNullOrWhiteSpace(baseURL))
                {
                    using (HttpClient httpClient = new HttpClient())
                    {
                        httpClient.BaseAddress = new Uri(baseURL);

                        // Only add authentication header if authentication is required
                        if (!String.IsNullOrEmpty(accessToken))
                        {
                            httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
                        }

                        try
                        {
                            // Create an HTTP request:
                            HttpRequestMessage httpRequest = new HttpRequestMessage(httpMethod, messageEndpoint);

                            // GET Requests cannot have bodies
                            if (!isBodyLess)
                            {
                                // Add the json serialized message to the content of the request:
                                var contentMessage = new System.Net.Http.StringContent(serializedMessage, Encoding.UTF8, "application/json");

                                httpRequest.Content = contentMessage;
                            }

                            // Get a response:
                            HttpResponseMessage httpResponse = httpClient.SendAsync(httpRequest).GetAwaiter().GetResult();

                            // Read the response:
                            string responseBody = httpResponse.Content.ReadAsStringAsync().GetAwaiter().GetResult();

                            // Handle http errors:
                            if (!httpResponse.IsSuccessStatusCode)
                            {
                                throw new IKEAException(IKEAConstants.CustomNiceLabelExceptionLocalizedMessage, ("HTTP " + (int)httpResponse.StatusCode + " - " + httpResponse.StatusCode));
                            }

                            // Check if NiceLabel returned an error message in the response (usually is XML)
                            string errorMessage = "";

                            if (httpResponse.Content.Headers.ContentType.MediaType == "application/xml" || httpResponse.Content.Headers.ContentType.MediaType == "text/xml")
                            {
                                XmlDocument xmldoc = new XmlDocument();
                                xmldoc.LoadXml(responseBody);

                                // If an error message is received:
                                if (xmldoc.SelectNodes(IKEAConstants.ErrorMessage).Count > 0)
                                {
                                    errorMessage = xmldoc.GetValueByXPath(IKEAConstants.ErrorMessageContent);
                                }
                            }
                            else if (httpResponse.Content.Headers.ContentType.MediaType == "application/json")
                            {
                                errorMessage = JObject.Parse(responseBody).Value<string>("error");
                            }

                            // Message was processed but the NiceLabel returned an error message:
                            if (!errorMessage.IsNullOrEmpty())
                            {
                                throw new IKEAException(IKEAConstants.CustomNiceLabelExceptionLocalizedMessage, errorMessage);
                            }

                            result = responseBody;

                        }
                        catch (WebException exception)
                        {
                            string responseText = string.Empty;

                            var responseStream = exception.Response != null ? exception.Response.GetResponseStream() : null;

                            if (responseStream != null)
                            {
                                using (var reader = new StreamReader(responseStream))
                                {
                                    responseText = reader.ReadToEnd();
                                    if (!string.IsNullOrEmpty(responseText))
                                        throw new IKEAException(IKEAConstants.CustomNiceLabelExceptionLocalizedMessage, responseText);
                                }
                            }
                        }
                    }
                }
                else
                {
                    throw new IKEAException((IKEAConstants.CustomNiceLabelMissingBaseEndpointLocalizedMessage));
                }
            }
            return result;
        }

        /// <summary>
        /// Get Access Token
        /// </summary>
        /// <returns>Access Token</returns>
        private string GetNiceLabelAccessToken()
        {
            string accessToken = string.Empty;

            using (WebClient client = new WebClient())
            {
                try
                {
                    accessToken = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.NiceLabelToken);

                    // If we have a pre-defined token in the configuration, do not make a Web Request to retrieve it
                    if (string.IsNullOrWhiteSpace(accessToken))
                    {
                        // Get authentication configurations
                        string username = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.NiceLabelUsername);
                        string password = _iKEAUtilities.GetDecryptedSecureStringConfiguration(IKEAConstants.NiceLabelPassword);
                        string tokenEndpoint = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.NiceLabelTokenEndpoint);

                        // Check if any of the configurations is missing
                        if (!string.IsNullOrWhiteSpace(username)
                            && !string.IsNullOrWhiteSpace(password)
                            && !string.IsNullOrWhiteSpace(tokenEndpoint))
                        {
                            // Build json Request Message
                            Dictionary<string, string> requestInfo = new Dictionary<string, string>()
                            {
                                { "username", username },
                                { "password", password },
                            };
                            string request = requestInfo.ToJsonString();

                            // Set headers
                            client.Headers.Add(HttpRequestHeader.ContentType, "application/json");
                            client.Headers.Add(HttpRequestHeader.Accept, "*/*");

                            // Upload Message
                            string result = client.UploadString(tokenEndpoint, "POST", request);

                            // Get result data
                            var data = JObject.Parse(result);

                            // Get access token from result data
                            accessToken = data["token"].ToString();
                        }
                        else
                        {
                            throw new IKEAException((IKEAConstants.CustomNiceLabelMissingConfigurationsLocalizedMessage));
                        }
                    }
                }
                catch (WebException exception)
                {
                    string responseText = string.Empty;

                    var responseStream = exception.Response != null ? exception.Response.GetResponseStream() : null;

                    if (responseStream != null)
                    {
                        using (var reader = new StreamReader(responseStream))
                        {
                            responseText = reader.ReadToEnd();
                            if (!string.IsNullOrEmpty(responseText))
                                throw new IKEAException(IKEAConstants.CustomNiceLabelExceptionLocalizedMessage, responseText);
                        }
                    }

                    if (string.IsNullOrEmpty(responseText) && !string.IsNullOrEmpty(exception.Message))
                    {
                        responseText = exception.Message;
                    }

                    throw new IKEAException(IKEAConstants.CustomNiceLabelExceptionLocalizedMessage, responseText);
                }
            }
            return accessToken;
        }

        /// <summary>
        /// Creates an integration entry for sending an TrackIn Notification request to the NiceLabel Endpoint
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public IIntegrationEntry CreateNiceLabelOutgoingIntegrationEntry(INiceLabelIntegrationMessage request, string requestEndpoint, string requestType = IKEAConstants.NiceLabelNotifyTrackInMessageType, string eventName = IKEAConstants.NiceLabelNotifyTrackInEventName)
        {
            string jsonMessage = JsonConvert.SerializeObject(request);

            MESNiceLabelCommunication communication = new MESNiceLabelCommunication()
            {
                API = requestEndpoint,
                Message = jsonMessage,
            };

            XmlDocument xmlDoc = communication.SerializeToXMLDocument();

            return _iKEAUtilities.CreateIntegrationEntry(IKEAConstants.MESSystem, IKEAConstants.NiceLabelSystem, requestType, eventName, xmlDoc);
        }

        /// <summary>
        /// Creates an integration entry for receiving a label printing message from NiceLabel
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public IIntegrationEntry CreateNiceLabelIncomingIntegrationEntry(object request, IIntegrationEntry parentIntegration, bool isFlag, string errorMessage, string requestType = IKEAConstants.NiceLabelSSCCInfoMessageType, string eventName = IKEAConstants.NiceLabelSSCCInfoEventName)
        {
            string jsonMessage = JsonConvert.SerializeObject(request, new JsonSerializerSettings
            {
                NullValueHandling = NullValueHandling.Ignore
            });

            MESNiceLabelCommunication communication = new MESNiceLabelCommunication()
            {
                Message = jsonMessage,
            };

            XmlDocument xmlDoc = communication.SerializeToXMLDocument();
            if (isFlag)
            {
                return _iKEAUtilities.CreateIntegrationEntry(IKEAConstants.NiceLabelSystem, IKEAConstants.MESSystem, requestType, eventName, xmlDoc, isRetriable: true, description: "NiceLabel Integration Message Received", parentIngtegration: parentIntegration);
            }
            else
            {
                return _iKEAUtilities.CreateFailedIntegrationEntry(IKEAConstants.NiceLabelSystem, IKEAConstants.MESSystem, requestType, eventName, xmlDoc, errorMessage, isRetriable: true, description: "NiceLabel Integration Message Received", parentIngtegration: parentIntegration);
            }
            
        }

        /// <summary>
        /// Get DatatSet with the resolution of the SmartTable CustomAutomaticPrintableDocumentContext
        /// </summary>
        /// <param name="material"></param>
        /// <param name="printingSequence"></param>
        /// <param name="step"></param>
        /// <param name="resource"></param>
        /// <returns></returns>
        public DataSet ResolveNiceLabelContextSmartTable(IResource resource, IProduct product)
        {
            ISmartTable smartTable = new SmartTable();
            smartTable.Load(IKEAConstants.CustomNiceLabelContextSmartTable);

            DataSet recipeDataSet = null;

            INgpDataRow values = new NgpDataRow();

            if (!string.IsNullOrWhiteSpace(resource.Name))
            {
                values.Add(IKEAConstants.CustomNiceLabelContextResourceColumn, resource.Name);
            }

            if (!string.IsNullOrWhiteSpace(product.Name))
            {
                values.Add(IKEAConstants.CustomNiceLabelContextProductColumn, product.Name);
            }

            INgpDataSet ngoDataSet = smartTable.Resolve(values, true);
            if (ngoDataSet != null)
            {
                recipeDataSet = NgpDataSet.ToDataSet(ngoDataSet);
            }

            return recipeDataSet;
        }

        /// <summary>
        /// Get DatatSet with the resolution of the GenericTable CustomNiceLabelIntegrationEntries for a specific Integration Entry
        /// </summary>
        /// <param name="integrationEntry"></param>
        /// <returns></returns>
        public DataSet GetNiceLabelMaterialForIntegrationEntry(IIntegrationEntry integrationEntry)
        {
            System.IServiceProvider serviceProvider = ApplicationContext.CurrentServiceProvider;
            ITableOrchestration tableOrchestration = serviceProvider.GetService<ITableOrchestration>();
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            GetGenericTablesByFilterOutput output = tableOrchestration.GetGenericTablesByFilter(new GetGenericTablesByFilterInput()
            {
                Filter = new FilterCollection()
                    {
                            new Filter()
                            {
                                Name = "Name"
                                , Value = IKEAConstants.CustomNiceLabelIntegrationEntries
                                , Operator = Foundation.Common.FieldOperator.IsEqualTo
                                , LogicalOperator = Foundation.Common.LogicalOperator.Nothing
                            }
                    }
            });

            DataSet resultingDataSet = null;

            // if generic table exists, proceed
            if (output.GenericTableCollection != null && output.GenericTableCollection.Count > 0)
            {
                IGenericTable gtCustomNiceLabelIntegrationEntries = output.GenericTableCollection.First();
                gtCustomNiceLabelIntegrationEntries.LoadData(new FilterCollection() {
                        new Filter()
                        {
                            Name = IKEAConstants.CustomNiceLabelIntegrationEntriesIntegrationEntryColumn
                            , Value = integrationEntry.Name
                            , Operator = Foundation.Common.FieldOperator.IsEqualTo
                            , LogicalOperator = Foundation.Common.LogicalOperator.Nothing
                        }
                 });

                if (gtCustomNiceLabelIntegrationEntries.Data != null)
                {
                    // Convert to dataset to extract data
                    resultingDataSet = NgpDataSet.ToDataSet(gtCustomNiceLabelIntegrationEntries.Data);
                }
            }
            return resultingDataSet;
        }

        /// <summary>
        /// Get IMaterialCollection with the resolution of the GenericTable CustomNiceLabelIntegrationEntries for a specific Resource
        /// </summary>
        /// <param name="integrationEntry"></param>
        /// <returns></returns>
        public IMaterialCollection GetNiceLabelMaterialAlreadyAssociatedForResource(IResource resource)
        {
            System.IServiceProvider serviceProvider = ApplicationContext.CurrentServiceProvider;
            ITableOrchestration tableOrchestration = serviceProvider.GetService<ITableOrchestration>();
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            GetGenericTablesByFilterOutput output = tableOrchestration.GetGenericTablesByFilter(new GetGenericTablesByFilterInput()
            {
                Filter = new FilterCollection()
                    {
                            new Filter()
                            {
                                Name = "Name"
                                , Value = IKEAConstants.CustomNiceLabelIntegrationEntries
                                , Operator = Foundation.Common.FieldOperator.IsEqualTo
                                , LogicalOperator = Foundation.Common.LogicalOperator.Nothing
                            }
                    }
            });

            IMaterialCollection materialsAlreadyTaken = entityFactory.CreateCollection<IMaterialCollection>();

            // if generic table exists, proceed
            if (output.GenericTableCollection != null && output.GenericTableCollection.Count > 0)
            {
                IGenericTable gtCustomNiceLabelIntegrationEntries = output.GenericTableCollection.First();
                gtCustomNiceLabelIntegrationEntries.LoadData(new FilterCollection() {
                        new Filter()
                        {
                            Name = IKEAConstants.CustomNiceLabelIntegrationEntriesResourceColumn
                            , Value = resource.Name
                            , Operator = Foundation.Common.FieldOperator.IsEqualTo
                            , LogicalOperator = Foundation.Common.LogicalOperator.Nothing
                        }
                 });

                if (gtCustomNiceLabelIntegrationEntries.Data != null)
                {
                    // Convert to dataset to extract data
                    DataSet dsResultSet = NgpDataSet.ToDataSet(gtCustomNiceLabelIntegrationEntries.Data);
                    if (dsResultSet.HasData())
                    {
                        foreach (DataRow row in dsResultSet.Tables[0].Rows)
                        {
                            string materialName = row.GetValue<String>(IKEAConstants.CustomNiceLabelIntegrationEntriesMaterialColumn);
                            IMaterial material = entityFactory.Create<IMaterial>();
                            material.Name = materialName;
                            materialsAlreadyTaken.Add(material);
                        }
                    }
                }
            }
            return materialsAlreadyTaken;
        }

        /// <summary>
        /// Gets the last IntegrationEntry in a queue of IntegrationEntries set with parentIntegrationID
        /// </summary>
        /// <param name="objects"></param>
        /// <returns></returns>
        public IIntegrationEntryCollection GetNiceLabelLastIntegrationInQueue(IIntegrationEntryCollection objects)
        {
            System.IServiceProvider serviceProvider = ApplicationContext.CurrentServiceProvider;
            IEntityFactory entity = serviceProvider.GetService<IEntityFactory>();

            if (objects == null || objects.Count == 0)
            {
                return entity.CreateCollection<IIntegrationEntryCollection>();
            }

            // Set of all objects
            HashSet<IIntegrationEntry> allObjects = new HashSet<IIntegrationEntry>(objects);

            // Set of all objects that are referenced as ParentId
            HashSet<string> referencedParents = new HashSet<string>(
                objects.Where(o => o.ParentIntegrationEntry != null).Select(o => o.ParentIntegrationEntry.Name)
            );

            // Last objects are in allObjects but not in referencedParents
            allObjects.RemoveWhere(ie => referencedParents.Contains(ie.Name));

            IIntegrationEntryCollection integrationsThatAreNotParents = entity.CreateCollection<IIntegrationEntryCollection>();
            integrationsThatAreNotParents.AddRange(allObjects);

            return integrationsThatAreNotParents;
        }

        /// <summary>
        /// Get all the NiceLabelSSCCInfo Integration Entries that are still executing or going to be executed.
        /// </summary>
        /// <returns></returns>
        public IIntegrationEntryCollection GetNiceLabelProcessingIntegrationEntries()
        {
            System.IServiceProvider serviceProvider = ApplicationContext.CurrentServiceProvider;
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();

            IIntegrationEntryCollection integrationEntries = entityFactory.CreateCollection<IIntegrationEntryCollection>();

            QueryObject query = new QueryObject();
            query.Description = "";
            query.EntityTypeName = "IntegrationEntry";
            query.Name = "GetNiceLabelProcessingIntegrationEntries";
            query.Query = new Query();
            query.Query.Distinct = false;
            query.Query.Filters = new FilterCollection() {
                new Filter()
                {
                    Name = "MessageType",
                    ObjectName = "IntegrationEntry",
                    ObjectAlias = "IntegrationEntry_1",
                    Operator = Cmf.Foundation.Common.FieldOperator.Contains,
                    Value = "NiceLabelSSCCInfo",
                    LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND,
                    FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                },
                new Filter()
                {
                    LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND,
                    FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.AlwaysTrue,
                    InnerFilters = new FilterCollection() {
                        new Filter()
                        {
                            Name = "SystemState",
                            ObjectName = "IntegrationEntry",
                            ObjectAlias = "IntegrationEntry_1",
                            Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                            Value = Cmf.Foundation.BusinessObjects.Abstractions.IntegrationEntrySystemState.Received,
                            LogicalOperator = Cmf.Foundation.Common.LogicalOperator.OR,
                            FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                        },
                        new Filter()
                        {
                            LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND,
                            FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.AlwaysTrue,
                            InnerFilters = new FilterCollection() {
                                new Filter()
                                {
                                    Name = "SystemState",
                                    ObjectName = "IntegrationEntry",
                                    ObjectAlias = "IntegrationEntry_1",
                                    Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                                    Value = Cmf.Foundation.BusinessObjects.Abstractions.IntegrationEntrySystemState.Failed,
                                    LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND,
                                    FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                                },
                                new Filter()
                                {
                                    Name = "IsRetriable",
                                    ObjectName = "IntegrationEntry",
                                    ObjectAlias = "IntegrationEntry_1",
                                    Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                                    Value = true,
                                    LogicalOperator = Cmf.Foundation.Common.LogicalOperator.Nothing,
                                    FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                                }
                            }
                        }
                    }
                }
            };
            query.Query.Fields = new FieldCollection() {
                new Field()
                {
                    Alias = "Id",
                    ObjectName = "IntegrationEntry",
                    ObjectAlias = "IntegrationEntry_1",
                    IsUserAttribute = false,
                    Name = "Id",
                    Position = 0,
                    Sort = Cmf.Foundation.Common.FieldSort.NoSort
                },
                new Field()
                {
                    Alias = "Name",
                    ObjectName = "IntegrationEntry",
                    ObjectAlias = "IntegrationEntry_1",
                    IsUserAttribute = false,
                    Name = "Name",
                    Position = 1,
                    Sort = Cmf.Foundation.Common.FieldSort.NoSort
                }
            };
            query.Query.Relations = new RelationCollection();

            DataSet resultDataSet = query.Execute(false, new QueryParameterCollection());

            if (resultDataSet.HasData())
            {
                foreach (DataRow row in resultDataSet.Tables[0].Rows)
                {
                    IIntegrationEntry integrationEntry = entityFactory.Create<IIntegrationEntry>();
                    integrationEntry.Name = row["Name"] as string;

                    integrationEntries.Add(integrationEntry);
                }
                integrationEntries.Load();
            }
            return integrationEntries;
        }
    }
}

