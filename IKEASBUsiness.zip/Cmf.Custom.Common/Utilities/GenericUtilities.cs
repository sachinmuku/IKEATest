﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;
using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;

using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Enums;
using Cmf.Custom.IKEA.Common.Exceptions;
using Cmf.Custom.IKEA.Common.Extensions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessObjects.SmartTables;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Foundation.Configuration;
using Cmf.Foundation.Configuration.Abstractions;
using Cmf.Foundation.Marshalling.Converters;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json;
using OtherConstants = Cmf.Navigo.Common.Constants;

namespace Cmf.Custom.IKEA.Common.Utilities
{
    public class GenericUtilities : IGenericUtilities
    {
        private IEntityFactory _entityFactory;
        
        [Microsoft.Extensions.DependencyInjection.ActivatorUtilitiesConstructor]
        public GenericUtilities(IEntityFactory entityFactory)
        {
            _entityFactory = entityFactory;
        }

        public T GetEntityByName<T>(string name) where T : ICoreBase
        {
            var entity = _entityFactory.Create<T>();
            if (entity is IEntityBase entityBase)
            {
                entityBase.Name = name;
                entityBase.Load();
            }
            else if (entity is ISmartTable smartTable)
            {
                smartTable.Name = name;
                smartTable.Load();
            }
            else if (entity is IGenericTable genericTable)
            {
                genericTable.Name = name;
                genericTable.Load();
            }
            else if (entity is ILookupTable lookupTable)
            {
                lookupTable.Name = name;
                lookupTable.Load();
            }
            return entity;
        }

        #region Generic

        /// <summary>
        /// Get Configuration Value By Path
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="path">Configuration Path</param>
        /// <returns>Configuration Value</returns>
        public T GetConfigurationValueByPath<T>(string path)
        {
            T returnValue = default(T);
            if (!String.IsNullOrEmpty(path))
            {
                IConfig config = null;
                if (Config.TryGetConfig(path, out config) && config != null)
                {
                    if (config.ValueType == typeof(System.Security.SecureString).FullName)
                    {
                        returnValue = (T)Convert.ChangeType(config.GetDecryptedConfigValue(), typeof(T));
                    }
                    else
                    {
                        returnValue = (T)Convert.ChangeType(config.Value, typeof(T));
                    }
                }
            }

            return returnValue;
        }

        #endregion

        #region XML

        /// <summary>
        /// Deserialize Xml To Object
        /// </summary>
        /// <typeparam name="T">Serializable Class</typeparam>
        /// <param name="xml">XML</param>
        /// <returns>Object</returns>
        public T DeserializeXmlToObject<T>(string xml)
        {
            T newObject;
            // Construct an instance of the XmlSerializer with the type
            // of object that is being deserialized.
            XmlSerializer serializer = new XmlSerializer(typeof(T));

            using (TextReader reader = new StringReader(xml))
            {
                // Call the Deserialize method and cast to the object type.
                newObject = (T)serializer.Deserialize(reader);
            }

            return newObject;
        }

        /// <summary>
        /// Deserialize Xml To Object
        /// </summary>
        /// <typeparam name="T">Serializable Class</typeparam>
        /// <param name="xml">XML</param>
        /// <returns>Object</returns>
        public T DeserializeXmlToObject<T>(XmlNode xml)
        {
            T newObject;
            // Construct an instance of the XmlSerializer with the type
            // of object that is being deserialized.
            XmlSerializer serializer = new XmlSerializer(typeof(T));

            using (XmlNodeReader reader = new XmlNodeReader(xml))
            {
                // Call the Deserialize method and cast to the object type.
                newObject = (T)serializer.Deserialize(reader);
            }

            return newObject;
        }

        public Dictionary<string, string> DeserializeObject(string message)
        {
            return JsonConvert.DeserializeObject<Dictionary<string, string>>(message);
        }

        #endregion

        #region IOT
        /// <summary>
        /// Gets the materials from IoT for manual process loss reporting
        /// </summary>
        /// <param name="material"></param>
        /// <returns></returns>
        public T IoTManualProcessLossRequest<T>(IMaterial material, decimal? quantity, bool isConfirmation = false)
        {
            T result;
            object parsedReply = null;
            object data = new
            {
                IsConfirmation = isConfirmation,
                Material = material.Name,
                Quantity = quantity
            };
            IResource resource = material.LastProcessedResource;
            resource.Load();
            IAutomationControllerInstance controllerInstance = resource.GetAutomationControllerInstance();
            var eiReply = RequestFromIoT<Dictionary<string, object>>(controllerInstance, IKEAConstants.AutomationRequestTypeProcessLossReport, data);

            if (eiReply != null && eiReply.ContainsKey(IKEAConstants.AutomationRequestReplyField))
            {
                eiReply.TryGetValue(IKEAConstants.AutomationRequestReplyField, out parsedReply);
            }


            if (typeof(T).Name == typeof(Dictionary<,>).Name)
            {
                result = JsonConvert.DeserializeObject<T>(parsedReply?.ToJsonString(), new DictionaryToMapConverter());
            }
            else
            {
                result = JsonConvert.DeserializeObject<T>(parsedReply?.ToJsonString());
            }

            return result;

        }



        /// <summary>
        /// Sends a request to Automation, using the default request timeout.
        /// </summary>
        /// <param name="controllerInstance">AutomationControllerInstance</param>
        /// <param name="requestType">RequestType</param>
        /// <param name="requestData">RequestData</param>
        /// <returns>SendRequest's response.</returns>
        private object InnerRequestFromIoT(IAutomationControllerInstance controllerInstance, string requestType, object requestData)
        {
            object obj = null;

            if (controllerInstance != null)
            {
                // Get EI default timeout
                int requestTimeout = GetConfigurationValueByPath<int>(IKEAConstants.DownloadOrderToAutomationSendRequestDefaultTimeout);

                // Send synchronous request to automation:
                obj = controllerInstance.SendRequest(requestType, requestData, requestTimeout);

                if (obj == null)
                {
                    throw new IKEAException(IKEAConstants.CustomIOTConnectionTimeoutLocalizedMessage, requestType);
                }
            }

            return obj;
        }

        /// <summary>
        /// Sends a request to Automation
        /// </summary>
        /// <typeparam name="T">Type to which the data must be converted</typeparam>
        /// <param name="controllerInstance">AutomationControllerInstance</param>
        /// <param name="requestType">RequestType</param>
        /// <param name="requestData">RequestType</param>
        /// <returns>SendRequest's response as an instance of T.</returns>
        public T RequestFromIoT<T>(IAutomationControllerInstance controllerInstance, string requestType, object requestData)
        {
            object response = InnerRequestFromIoT(controllerInstance, requestType, requestData);

            return JsonConvert.DeserializeObject<T>(response.ToJsonString());
        }

        #endregion

        /// <summary>
        /// Sets the new value of the material state model
        /// </summary>
        /// <param name="material"></param>
        /// <param name="stateModelValue"></param>
        /// <returns></returns>
        public ICurrentEntityState SetEntityStateModelState(IMaterial material, string stateModelValue)
        {
            IStateModel stateModel = new StateModel()
            {
                Name = IKEAConstants.MaterialStateModel
            };

            stateModel.Load();
            IStateModelState stateModelState = new StateModelState();
            stateModelState.Load(stateModelValue, stateModel);
            var currentEntityState = _entityFactory.Create<ICurrentEntityState>();
            currentEntityState.Entity = material;
            currentEntityState.StateModel = stateModel;
            currentEntityState.CurrentState = stateModelState;
            return currentEntityState;
        }
        /// <summary>
        /// Change material state model (MSM)
        /// </summary>
        /// <param name="material"></param>
        /// <param name="stateModelValue"></param>
        public void ChangeMaterialStateModel(IMaterial material, string stateModelValue)
        {
            material.Load();

            if (material.CurrentMainState == null
                || !material.CurrentMainState.CurrentState.Name.CompareStrings(stateModelValue))
            {
                ICurrentEntityState currentEntityState = SetEntityStateModelState(material, stateModelValue);
                // Set the new State Model
                material.SetMainStateModel(currentEntityState);
            }
        }

        /// <summary>
        /// Maps material state model MSM depending on the action that was triggered
        /// </summary>
        /// <param name="action"></param>
        /// <param name="materials"></param>
        /// <returns></returns>
        public IMaterialCollection MaterialStateModelMappingLogic(string action, IMaterialCollection materials)
        {
            foreach (var material in materials)
            {
                switch (action)
                {
                    case "Create":
                        var orderMaterialForm = GetConfigurationValueByPath<string>(IKEAConstants.IKEAOrderMaterialFormPath);
                        if (material.Form == orderMaterialForm && (material.CurrentMainState == null || material.CurrentMainState.CurrentState.Name != IKEAConstants.MaterialStateModelQueued))
                        {
                            material.CurrentMainState = SetEntityStateModelState(material, IKEAConstants.MaterialStateModelQueued);
                        }
                        break;

                    case "Dispatch":
                        ChangeMaterialStateModel(material, IKEAConstants.MaterialStateModelDispatched);
                        break;

                    case "MoveToNextStep":
                    case "ChangeFlowAndStep":
                    case "Undispatch":
                    case "MoveToStep":
                        if (material.CurrentMainState == null || material.CurrentMainState.CurrentState.Name != IKEAConstants.MaterialStateModelCompleted)
                        {
                            ChangeMaterialStateModel(material, IKEAConstants.MaterialStateModelQueued);
                        }
                        break;

                    case "TrackIn":
                        ChangeMaterialStateModel(material, IKEAConstants.MaterialStateModelSetup);
                        break;

                    case "AbortProcess":
                        ChangeMaterialStateModel(material, IKEAConstants.MaterialStateModelAborted);

                        // In direct feeding - send request for DirectFeedingCounterpartFinished
                        RetryDirectFeedingCounterPartFinished(material);
                        break;

                    case "TrackOut":
                    case "Terminate":
                        if (material.CurrentMainState == null || material.CurrentMainState.CurrentState.Name != IKEAConstants.MaterialStateModelCompleted)
                        {
                            ChangeMaterialStateModel(material, IKEAConstants.MaterialStateModelCompleting);
                        }
                        break;

                    default:
                        break;

                }

            }

            return materials;
        }

        /// <summary>
        /// Send request DirectFeedingCounterpartFinished when material is finished
        /// </summary>
        /// <param name="material"></param>
        /// <param name="loadEntities"></param>
        /// <exception cref="CmfBaseException"></exception>
        public void RetryDirectFeedingCounterPartFinished(IMaterial material, bool loadEntities = false)
        {

            IResource mainLine = material.LastProcessedResource;
            if (mainLine != null && mainLine.AutomationMode == ResourceAutomationMode.Online)
            {
                // Check if resource is configured for direct feeding
                bool isLineUsingDirectFeeding = mainLine.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomResourceDirectFeedingEnabled, loadAttribute: true);

                // Only active if direct feeding is enabled and line is configured for direct feeding
                bool isDirectFeedingEnabled = GetConfigurationValueByPath<bool>(IKEAConstants.EnableDirectFeedingConfig);

                Collection<string> attributesToLoad = new Collection<string>() {
                        IKEAConstants.CustomMaterialAttributeDirectFeedingMode,
                        IKEAConstants.CustomMaterialAttributeDirectFeedingCounterPart
                    };
                material.LoadAttributes(attributesToLoad);
                CustomDirectFeedingModeEnum feedingMode = material.GetAttributeValueOrDefault<CustomDirectFeedingModeEnum>(IKEAConstants.CustomMaterialAttributeDirectFeedingMode, loadAttribute: false);
                if (isDirectFeedingEnabled && isLineUsingDirectFeeding && feedingMode == CustomDirectFeedingModeEnum.DirectFeeding)
                {

                    // Check controller instance of resource
                    IAutomationControllerInstance controllerInstance = mainLine.GetAutomationControllerInstance();
                    if (controllerInstance == null)
                    {
                        throw new CmfBaseException(IKEAConstants.CustomErrorMessageRequestingVirtualPalletAutomationControllerInstanceIsNull);
                    }

                    // Verify if order is setup correctly (if second line, verify if first line is already finished)
                    VerifyOrderCounterPart(material, mainLine, loadEntities);

                    // Name of counter part of MO that has to be finished in order for the one on the first line to proceed
                    string directFeedingCounterPart = material.GetAttributeValueOrDefault<string>(IKEAConstants.CustomMaterialAttributeDirectFeedingCounterPart, loadAttribute: false);

                    // Send data to IoT
                    controllerInstance.Publish(IKEAConstants.DirectFeedingCounterpartFinished, new
                    {
                        MaterialName = directFeedingCounterPart
                    });

                }
            }

        }

        /// <summary>
        /// Verify if, in case the resource is second line and direct feeding is enabled, the MO counterpart has already been finished (aborted or completed)
        /// </summary>
        /// <param name="material"></param>
        /// <param name="resource"></param>
        /// <param name="loadEntities"></param>
        public void VerifyOrderCounterPart(IMaterial material, IResource resource, bool loadEntities = false)
        {
            System.IServiceProvider serviceProvider = ApplicationContext.CurrentServiceProvider;
            IEntityFactory entityFactory = serviceProvider.GetRequiredService<IEntityFactory>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();

            // If this validation is being done in a case where the process was started by a Stop Operation, then the validations done in this utility should be skipped
            bool? isStopOperationByIoT = deeContextUtilities.GetContextParameter(IKEAConstants.DirectFeedingAbortByStopOperationContextKey) as bool?;
            if (isStopOperationByIoT.HasValue && isStopOperationByIoT.Value)
            {
                return;
            }

            if (loadEntities)
            {
                resource.Load();
                material.Load();
            }

            // Load resource attributes
            bool directFeedingEnabled = resource.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomResourceDirectFeedingEnabled, loadAttribute: true);
            bool isFirstLineDirectFeeding = resource.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomResourceDirectFeedingIsFirstLine, loadAttribute: true);

            // Check if resource has direct feeding and is a second line
            if (directFeedingEnabled && !isFirstLineDirectFeeding)
            {
                // Name of counter part of MO that has to be finished in order for the one on the first line to proceed
                string directFeedingCounterPart = material.GetAttributeValueOrDefault<string>(IKEAConstants.CustomMaterialAttributeDirectFeedingCounterPart, loadAttribute: true);

                #region Load material MO counterpart
                // Load material MO counterpart and check if it's valid
                IMaterial counterPartMaterial = entityFactory.Create<IMaterial>();
                counterPartMaterial.Name = directFeedingCounterPart;

                if (directFeedingCounterPart.IsNullOrEmpty() || !counterPartMaterial.ObjectExists())
                {
                    throw new IKEAException(IKEAConstants.CustomDirectFeedingSecondLineCounterPartNotValid, material.Name);
                }
                counterPartMaterial.Load();
                #endregion

                // Check if counter part MO (in DF1) is not in process
                if (counterPartMaterial.SystemState == MaterialSystemState.InProcess)
                {
                    throw new IKEAException((IKEAConstants.CustomDirectFeedingCounterPartUnfinished));
                }

            }

        }

        /// <summary>
        /// Verifies if MO is configured for direct feeding and is on second line of direct feeding
        /// </summary>
        /// <param name="resource"></param>
        /// <param name="material"></param
        /// <returns></returns>
        /// <exception cref="CmfBaseException"></exception>
        public bool DirectFeedingIsDirectFeedingAndSecondLine(IResource resource, IMaterial materialMO)
        {
            bool isDirectFeedingEnabled = GetConfigurationValueByPath<bool>(IKEAConstants.EnableDirectFeedingConfig);

            if (isDirectFeedingEnabled)
            {
                Collection<string> materialAttributesToLoad = new Collection<string>() {
                                IKEAConstants.CustomMaterialAttributeDirectFeedingMode,
                            };

                materialMO.LoadAttributes(materialAttributesToLoad);

                CustomDirectFeedingModeEnum materialDirectFeedingMode = materialMO.GetAttributeValueOrDefault<CustomDirectFeedingModeEnum>(IKEAConstants.CustomMaterialAttributeDirectFeedingMode);

                if (materialDirectFeedingMode == CustomDirectFeedingModeEnum.DirectFeeding)
                {
                    Collection<string> resourceAttributesToLoad = new Collection<string>() {
                                    IKEAConstants.CustomResourceDirectFeedingIsFirstLine,
                                };

                    resource.LoadAttributes(resourceAttributesToLoad);
                    bool isFirstLine = resource.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomResourceDirectFeedingIsFirstLine);

                    // return true if it is second line
                    if (!isFirstLine)
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        /// <summary>
        /// Resolves the step to be used in the BOM Product created by ERP
        /// </summary>
        /// <param name="product">Product</param>
        /// <param name="facility">Facility</param>
        /// <param name="resource">Resource</param>
        /// <returns>Step for the BOM Product</returns>
        public IStep ERPResolveStepForBOMProduct(IProduct product, IFacility facility, IResource resource, string workCenter)
        {
            IStep step = null;
            var flowResolve = ResolveAllMaterialFlows(facility, product, resource, null, workCenter);

            if (flowResolve != null && !flowResolve.Item2.IsNullOrEmpty())
            {
                step = GetStepByFlowPath(flowResolve.Item2);
            }
            else
            {
                var flowPath = product.FlowPath;
                if (!flowPath.IsNullOrEmpty())
                {
                    var flow = GetFlowsInFlowPath(flowPath).FirstOrDefault();
                    flow.Load();
                    var flowStep = GetFirstOrLastFlowStepFromFlow(flow, false);
                    step = flowStep.TargetEntity;
                }
                else
                {
                    throw new IKEAException(IKEAConstants.CustomERPNOFlowFoundForProductError, product.Name);
                }
            }

            return step;
        }

        /// <summary>
        /// Resolve the ConsumptionFlowPath (or FlowPath if the first is null) for the Automatic Material Creation
        /// </summary>
        /// <param name="facility"></param>
        /// <param name="product"></param>
        /// <param name="resource"></param>
        /// <param name="moType"></param>
        /// <returns>ConsumptionFlowPath. If it is null, FlowPath is returned instead</returns>
        public Tuple<string, string> ResolveAllMaterialFlows(IFacility facility, IProduct product, IResource resource, string moType, string workcenter)
        {
            ISmartTable smartTable = new SmartTable();
            smartTable.Load(IKEAConstants.CustomMaterialFlowResolution);

            INgpDataRow values = new NgpDataRow();
            if (resource != null)
            {
                values.Add(OtherConstants.Resource, resource.Name);
            }

            if (product != null)
            {
                values.Add(OtherConstants.Product, product.Name);
            }
            if (!String.IsNullOrEmpty(moType))
            {
                values.Add(IKEAConstants.MaterialTypeField, moType);
            }

            if (product != null && product.ProductGroup != null)
            {
                values.Add(OtherConstants.ProductGroup, product.ProductGroup.Name);
            }
            if (facility != null)
            {
                values.Add(OtherConstants.Facility, facility.Name);
            }
            if (!String.IsNullOrEmpty(workcenter))
            {
                values.Add(IKEAConstants.WorkCenter, workcenter);
            }
            //Add BaseProduct resolution
            INgpDataSet nds = smartTable.Resolve(values, true);

            if (product != null)
            {
                string baseProductName = product.GetRelatedAttributeValueOrDefault<string>(IKEAConstants.CustomProductAttributeBaseProduct, true);
                //Try to resolve using BaseProduct
                nds = ResolveBaseProduct(baseProductName, smartTable, values, nds);
            }

            if (nds != null)
            {
                DataSet ds = NgpDataSet.ToDataSet(nds);
                if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    string incomingFlowPath = Convert.ToString(ds.Tables[0].Rows[0][OtherConstants.FlowPath]);

                    string flowpath = GetCorrectFlowPath(incomingFlowPath);

                    string verifyConsuptionFlowpath = ds.Tables[0].Rows[0][IKEAConstants.CustomMaterialFlowResolutionConsumptionFlowPath].ToString();
                    string consumptionFlowpath = GetCorrectFlowPath(verifyConsuptionFlowpath);

                    return new Tuple<string, string>(flowpath, consumptionFlowpath);
                }
            }

            return null;
        }
        /// <summary>
        /// Gets the flows in flow path.
        /// </summary>
        /// <param name="flowpath">The flowpath.</param>
        /// <param name="loadFlows">if set to <c>true</c> [load flows].</param>
        /// <returns></returns>
        public IFlowCollection GetFlowsInFlowPath(string flowpath, bool loadFlows = false)
        {
            IFlowCollection flowsInFlowpath = _entityFactory.CreateCollection<IFlowCollection>();
            HashSet<string> flowNames = new HashSet<string>();
            string[] flowPathStructure = flowpath.Split('/');

            for (int i = 0; i < flowPathStructure.Count() - 1; i++)
            {
                string flowName = flowPathStructure[i].Split(':')[0];
                flowNames.Add(flowName);
            }

            foreach (string flowName in flowNames)
            {
                IFlow flow = _entityFactory.Create<IFlow>();
                flow.Name = flowName;

                if (flow.ObjectExists())
                    flowsInFlowpath.Add(flow);
            }

            if (loadFlows)
                flowsInFlowpath.Load();

            return flowsInFlowpath;
        }

        /// <summary>
        /// Extracts the step name from a given flow path
        /// </summary>
        /// <param name="flowPath"></param>
        /// <returns></returns>
        public IStep GetStepByFlowPath(string flowPath, bool loadStep = true)
        {
            IStep step = _entityFactory.Create<IStep>();
            string returnValue = null;

            if (!String.IsNullOrWhiteSpace(flowPath))
            {
                string[] flowPathSplit = flowPath.Split('/');
                if (flowPathSplit.Length >= 2)
                {
                    string lastToken = flowPathSplit.Last();
                    if (!String.IsNullOrWhiteSpace(lastToken))
                    {
                        string[] result = lastToken.Split(':');
                        if (result.Length == 2)
                        {
                            returnValue = result.First();
                        }
                    }
                }
            }
            //Validate if a step is returned from the flowpath
            if (!string.IsNullOrEmpty(returnValue))
            {
                step.Name = returnValue;
                //Load step if flag is set
                if (loadStep)
                {
                    step.Load();
                }
            }


            return step;
        }

        /// <summary>
        /// Gets the FlowStep from Flow
        /// </summary>
        /// <param name="flow">The flow.</param>
        /// <returns>FlowStep entity</returns>
        public IFlowStep GetFirstOrLastFlowStepFromFlow(IFlow flow, bool first = true)
        {
            IFlow subFlow = flow;
            subFlow.LoadChilds();

            while (subFlow.ChildType != FlowChildType.Step)
            {
                ISubFlow sub = null;
                if (first)
                    sub = subFlow.SubFlows.OrderBy(e => e.Position).FirstOrDefault();
                else
                    sub = subFlow.SubFlows.OrderBy(e => e.Position).LastOrDefault();

                if (sub != null)
                {
                    subFlow = sub.TargetEntity;
                    subFlow.LoadChilds();
                }
                else break;
            }


            if (subFlow.ChildType == FlowChildType.Step)
            {
                IFlowStep fs = null;
                if (first)
                    fs = subFlow.FlowSteps.OrderBy(e => e.Position).FirstOrDefault();
                else
                    fs = subFlow.FlowSteps.OrderBy(e => e.Position).LastOrDefault();

                if (fs != null)
                {
                    return fs;
                }
            }

            return null;
        }

        /// <summary>
        /// Obtains the correct flow path.
        /// </summary>
        /// <param name="flowpath">The flowpath.</param>
        /// <returns></returns>
        public string GetCorrectFlowPath(string flowPath)
        {
            string correctFlowPath = String.Empty;

            IStep step = GetStepByFlowPath(flowPath);
            IFlowCollection flows = GetFlowsInFlowPath(flowPath, true);

            if (step != null && flows != null && flows.Count > 0)
            {
                IFlow mainFlow = flows.FirstOrDefault();
                string[] subFlowNames = null;
                flows.RemoveAt(0);

                if (flows.Count > 0)
                {
                    subFlowNames = flows.Select(f => f.Name).ToArray();
                }

                correctFlowPath = FlowSearchHelper.CalculateFlowPath(mainFlow.Name, step.Name, subFlowNames);
            }

            return correctFlowPath;
        }
        /// <summary>
        /// Function to resolve Custom Smart Tables using BaseProduct when Product with revision could not be resolver or it is not explicit on the Resolution
        /// </summary>
        /// <param name="material"></param>
        /// <param name="printContext"></param>
        /// <param name="values"></param>
        /// <param name="nds"></param>
        /// <returns></returns>
        public INgpDataSet ResolveBaseProduct(string baseProductName, ISmartTable st, INgpDataRow values, INgpDataSet nds, bool isFirstResolveOrder = false)
        {
            if (baseProductName != null)
            {
                //Resolve based on BaseProduct
                if (nds == null)
                {
                    values[Cmf.Navigo.Common.Constants.Product] = baseProductName;
                    //If it is to resolve first order
                    if (isFirstResolveOrder)
                    {
                        nds = st.FirstResolveOrder(values);
                    }
                    else
                    {
                        nds = st.Resolve(values, true);
                    }
                }
                //If no Product is explicit on the result, resolve using base product
                else
                {
                    DataSet ds = NgpDataSet.ToDataSet(nds);
                    //Validate that Product key is Empty on the result set and try to resolve
                    if (ds.Tables.Count > 0 && (ds.Tables[0].Rows.Count == 0 || ds.Tables[0].Rows.Count > 0 && string.IsNullOrWhiteSpace(ds.Tables[0].Rows[0][Cmf.Navigo.Common.Constants.Product].ToString())))
                    {
                        values[Cmf.Navigo.Common.Constants.Product] = baseProductName;

                        //If it is to resolve first order
                        if (isFirstResolveOrder)
                        {
                            nds = st.FirstResolveOrder(values);
                        }
                        else
                        {
                            nds = st.Resolve(values, true);
                        }
                    }
                }
            }

            return nds;
        }
        /// <summary>
        /// Retrieves the list of users checkedIn users on a given Resource
        /// </summary>
        /// <param name="resourceName"></param>
        /// <returns>checkedInUserEmailList</returns>
        public IEmployeeCollection GetCheckedInEmployees(string resourceName)
        {
            IEmployeeCollection employeesCheckedIn = _entityFactory.CreateCollection<IEmployeeCollection>();

            if (resourceName != null)
            {
                //Load resource received as parameter
                IResource resource = GetEntityByName<IResource>(resourceName);

                resource.LoadRelations("ResourceEmployee");
                //This relation grants that the Employee is checkedIn on the Resource
                if (resource.RelationCollection.ContainsKey("ResourceEmployee"))
                {
                    IEmployeeCollection employeeColection = _entityFactory.CreateCollection<IEmployeeCollection>();
                    employeeColection.AddRange(resource.RelationCollection["ResourceEmployee"].Select(ET => ET.TargetEntity as IEmployee).ToList());
                    if (employeeColection != null && employeeColection.Any())
                    {
                        employeesCheckedIn.AddRange(employeeColection);
                    }
                }
            }
            //Return the list of MailAdresses
            return employeesCheckedIn;
        }


    }
}
