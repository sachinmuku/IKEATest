﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Cmf.Custom.IKEA.Common.PLM;
using Cmf.Foundation.BusinessObjects;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Common.CustomActionUtilities;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Foundation.BusinessOrchestration.Abstractions;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Foundation.Common.LocalizationService;
using Cmf.Navigo.BusinessOrchestration.Abstractions;
using Cmf.Custom.IKEA.Common.Exceptions;

namespace Cmf.Custom.IKEA.Common.Utilities
{
    public class PLMUtilities : IPLMUtilities
    {
        private IEntityFactory _entityFactory;
        private IIKEAUtilities _iKEAUtilities;
        private IGenericUtilities _genericUtilities;
        private IGenericServiceOrchestration _genericServiceOrchestration;
        //private IMaterialOrchestration _materialOrchestration;
        private ILocalizationService _localizationService;

        [Microsoft.Extensions.DependencyInjection.ActivatorUtilitiesConstructor]
        public PLMUtilities(IEntityFactory entityFactory,
            IGenericUtilities genericUtilities,
            IGenericServiceOrchestration genericServiceOrchestration,
            IIKEAUtilities iKEAUtilities,
            ILocalizationService localizationService)
        {
            _entityFactory = entityFactory;
            _genericUtilities = genericUtilities;
            _genericServiceOrchestration = genericServiceOrchestration;
            _iKEAUtilities = iKEAUtilities;
            _localizationService = localizationService;
        }
        public void NormalizeProductUnitsFromPLM(ProductSyncInput input)
        {
            ILookupTable lookupTable = _iKEAUtilities.GetLookupTable("Units");

            string normalizedUnit = lookupTable.Values
                .FirstOrDefault(x => x.Value.Equals(input.DefaultUnits, StringComparison.InvariantCultureIgnoreCase))
                ?.Value;

            if (normalizedUnit == null)
            {
                throw new IKEAException(IKEAConstants.CustomPLMInvalidUnitNameLocalizedMessage, input.DefaultUnits, lookupTable.Name);
            }

            input.DefaultUnits = normalizedUnit;

            foreach (KeyValuePair<string, decimal> alternateUnitConversion in input.AlternateUnitConversions.ToList())
            {
                normalizedUnit = lookupTable.Values
                    .FirstOrDefault(x => x.Value.Equals(alternateUnitConversion.Key, StringComparison.InvariantCultureIgnoreCase))
                    ?.Value;

                if (normalizedUnit == null)
                {
                    throw new IKEAException(IKEAConstants.CustomPLMInvalidUnitNameLocalizedMessage, alternateUnitConversion.Key, lookupTable.Name);
                }

                input.AlternateUnitConversions.Remove(alternateUnitConversion.Key);

                input.AlternateUnitConversions[normalizedUnit] = alternateUnitConversion.Value;
            }
        }

        public void FullUpdateUnitConversionFactorsFromPLM(IProduct product, Dictionary<string, decimal> newConversions, bool loadUnitConversionFactors = true)
        {
            if (loadUnitConversionFactors)
            {
                product.LoadUnitConversionFactors();
            }

            // Will be useful later on when actually performing changes to have the type here be DataRow
            var existingConversions = new List<DataRow>();

            #region Convert Data Set to List
            DataSet dataSet = NgpDataSet.ToDataSet(product.UnitConversionFactors.Data);

            if (dataSet.HasData())
            {
                foreach (DataRow row in dataSet.Tables[0].Rows)
                {
                    existingConversions.Add(row);
                }
            }
            #endregion
            // Clone copies the table structure but keeps data empty on the new copies
            DataTable rowsToRemove = dataSet.Tables[0].Clone();
            DataTable rowsToUpdateOrInsert = dataSet.Tables[0].Clone();

            #region Calculate Generic Table Differences
            // Let's start by adding all the existing conversion factors with a 
            // different "FromUnit" from the product.DefaultUnits to the removing list
            foreach (DataRow row in existingConversions.Where(conversion => (string)conversion["FromUnit"] != product.DefaultUnits))
            {
                rowsToRemove.AddCopyRow(row);
            }

            // Now create a dictionary indexed by the "ToUnit" to compare what to update, remove or leave be
            Dictionary<string, DataRow> existingConversionsByKey = existingConversions
                .Where(conversion => (string)conversion["FromUnit"] == product.DefaultUnits)
                .ToDictionary(conversion => (string)conversion["ToUnit"]);

            foreach (KeyValuePair<string, decimal> keyValue in newConversions)
            {
                DataRow row;
                if (existingConversionsByKey.TryGetValue(keyValue.Key, out row))
                {
                    // If the value has changed, mark for update, otherwise just leave be
                    if ((double)row["ConversionFactor"] != (double)keyValue.Value)
                    {
                        rowsToUpdateOrInsert.AddCopyRow(row, new Dictionary<string, object>
                        {
                            { "ConversionFactor", (double)keyValue.Value }
                        });
                    }

                    // Remove this unit from the dictionary, so in the end, only the remaining units on it
                    // are marked to be removed from the generic table
                    existingConversionsByKey.Remove(keyValue.Key);
                }
                else
                {
                    row = rowsToUpdateOrInsert.GetNewRow(new Dictionary<string, object>
                    {
                        { "ProductUnitConversionFactorsId", (long)0 },
                        { "ProductName", product.Name },
                        { "FromUnit", product.DefaultUnits },
                        { "ToUnit", keyValue.Key },
                        { "ConversionFactor", keyValue.Value },
                        { "LastServiceHistoryId", -1 },
                        { "LastOperationHistorySeq", -1 },
                    });

                    rowsToUpdateOrInsert.Rows.Add(row);
                }
            }

            // If there were any existing conversions that were not touched anywhere by the new ones we received,
            // it means they should be removed
            if (existingConversionsByKey.Count > 0)
            {
                foreach (DataRow row in existingConversionsByKey.Values)
                {
                    rowsToRemove.AddCopyRow(row);
                }
            }
            #endregion

            #region Perform Generic Table Changes If Needed

            if (rowsToRemove.Rows.Count > 0)
            {
                product.UnitConversionFactors.RemoveRows(NgpDataSet.FromDataSet(rowsToRemove.ToDataSet()));
            }

            if (rowsToUpdateOrInsert.Rows.Count > 0)
            {
                product.UnitConversionFactors.InsertOrUpdateRows(NgpDataSet.FromDataSet(rowsToUpdateOrInsert.ToDataSet()));
            }

            #endregion
        }

        public IProduct CreateProductFromPLM(ProductSyncInput input, bool isRevision)
        {
            IProduct product = _entityFactory.Create<IProduct>();

            product.Name = isRevision ? input.Name : input.BaseName;
            product.Type = "Standard";
            product.Description = input.Description;
            product.DefaultUnits = input.DefaultUnits;

            product.Attributes[IKEAConstants.CustomProductAttributeItemGroup] = input.AttributeItemGroup;
            product.Attributes[IKEAConstants.CustomProductAttributeProductGroup] = input.AttributeProductGroup;
            product.Attributes[IKEAConstants.CustomProductAttributeItemType] = input.AttributeItemType;
            product.RelatedAttributes[IKEAConstants.ItemDescription] = input.AttributeItemDescription;
            product.RelatedAttributes[IKEAConstants.CustomProductAttributeFinishedWidth] = input.WidthMeasure;
            product.RelatedAttributes[IKEAConstants.CustomProductAttributeFinishedLength] = input.LengthMeasure;
            product.RelatedAttributes[IKEAConstants.CustomProductAttributeThickness] = input.HeightMeasure;

            if (isRevision)
            {
                product.RelatedAttributes[IKEAConstants.CustomProductAttributeBaseProduct] = input.BaseName;
                product.RelatedAttributes[IKEAConstants.CustomProductAttributeRevision] = input.Revision;
            }

            product.CreateNewEntityVersion();

            product.Load();

            FullUpdateUnitConversionFactorsFromPLM(product, input.AlternateUnitConversions);

            return product;
        }

        /// <summary>
        /// Send ERP Message
        /// </summary>
        /// <param name="input"></param>
        /// <param name="isRevision"></param>
        /// <returns></returns>
        public IProduct CreateProductVersionFromPLM(ProductSyncInput input, bool isRevision)
        {
            string productName = isRevision ? input.Name : input.BaseName;
            IProduct product = _entityFactory.Create<IProduct>();
            product.Name = productName;
            if (product.ObjectExists())
            {
                product.Load();
                product.LoadAttributes();
                bool versionnedModification = false;

                // List of versionned properties or Attributes
                if (
                    !product.Attributes[IKEAConstants.CustomProductAttributeItemGroup].Equals(input.AttributeItemGroup) ||
                    !product.Attributes[IKEAConstants.CustomProductAttributeProductGroup].Equals(input.AttributeProductGroup) ||
                    !product.Attributes[IKEAConstants.CustomProductAttributeItemType].Equals(input.AttributeItemType) ||
                    !product.Description.Equals(input.Description)
                    )
                {
                    versionnedModification = true;
                }

                product.Description = input.Description;
                product.DefaultUnits = input.DefaultUnits;
                product.Attributes[IKEAConstants.CustomProductAttributeItemGroup] = input.AttributeItemGroup;
                product.Attributes[IKEAConstants.CustomProductAttributeProductGroup] = input.AttributeProductGroup;
                product.Attributes[IKEAConstants.CustomProductAttributeItemType] = input.AttributeItemType;
                product.RelatedAttributes[IKEAConstants.CustomProductAttributeFinishedWidth] = input.WidthMeasure;
                product.RelatedAttributes[IKEAConstants.CustomProductAttributeFinishedLength] = input.LengthMeasure;
                product.RelatedAttributes[IKEAConstants.CustomProductAttributeThickness] = input.HeightMeasure;

                // not versionned
                product.RelatedAttributes[IKEAConstants.ItemDescription] = input.AttributeItemDescription;

                if (isRevision)
                {
                    product.RelatedAttributes[IKEAConstants.CustomProductAttributeBaseProduct] = input.BaseName;
                    product.RelatedAttributes[IKEAConstants.CustomProductAttributeRevision] = input.Revision;
                }

                if (!versionnedModification)
                {
                    product.Save();
                    product.SaveRelatedAttributes(new AttributeCollection(product.RelatedAttributes));
                }
                else
                {
                    product.CreateNewEntityVersion();
                }

                product.Load();

                FullUpdateUnitConversionFactorsFromPLM(product, input.AlternateUnitConversions);

                return product;
            }
            return null;
        }

    }
}
