﻿using Cmf.Common.CustomActionUtilities;

using Cmf.Custom.IKEA.Common.Barcode;
using Cmf.Foundation.BusinessObjects.QueryObject;
using Cmf.Foundation.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using OtherConstants = Cmf.Navigo.Common.Constants;
using Cmf.Custom.IKEA.Common.Exceptions;
using Cmf.Foundation.BusinessObjects.SmartTables;
using Cmf.Foundation.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Foundation.BusinessOrchestration.Abstractions;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Foundation.Common.LocalizationService;
using Cmf.Navigo.BusinessOrchestration.Abstractions;
using Cmf.Custom.IKEA.Common.Enums;

namespace Cmf.Custom.IKEA.Common.Utilities
{
    public class BarcodeUtilities : IBarcodeUtilities
    {
        private IEntityFactory _entityFactory;
        private IIKEAUtilities _iKEAUtilities;
        private IGenericUtilities _genericUtilities;
        private IGenericServiceOrchestration _genericServiceOrchestration;
        //private IMaterialOrchestration _materialOrchestration;
        private ILocalizationService _localizationService;

        [Microsoft.Extensions.DependencyInjection.ActivatorUtilitiesConstructor]
        public BarcodeUtilities(IEntityFactory entityFactory,
            IGenericUtilities genericUtilities,
            IGenericServiceOrchestration genericServiceOrchestration,
            IIKEAUtilities iKEAUtilities,
            ILocalizationService localizationService)
        {
            _entityFactory = entityFactory;
            _genericUtilities = genericUtilities;
            _genericServiceOrchestration = genericServiceOrchestration;
            _iKEAUtilities = iKEAUtilities;
            _localizationService = localizationService;
        }
        /// <summary>
        /// Extract Barcode Information based on Forklift Configuration
        /// </summary>
        /// <param name="barcodeString">Barcode String</param>
        /// <param name="resource">Resource</param>
        /// <returns>Dictionary with the Barcode Information</returns>
        public Dictionary<string, string> ExtractBarcodeInformation(string barcodeString)
        {
            return ExtractBarcodeInformation(barcodeString, null);
        }

        /// <summary>
        /// Extract Barcode Information
        /// </summary>
        /// <param name="barcodeString">Barcode String</param>
        /// <param name="resource">Resource</param>
        /// <returns>Dictionary with the Barcode Information</returns>
        public Dictionary<string, string> ExtractBarcodeInformation(string barcodeString,
                                                                        IResource resource)
        {
            Dictionary<string, string> barcodeInformation = new Dictionary<string, string>();
            string scanningConfigurationName = string.Empty;

            //If there is no resource in the method call, it is being called by forklift mechanism
            if (resource == null)
            {
                string forkliftScanningConfigurationName = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.CustomForkliftScanningConfigurationPath);
                if (string.IsNullOrEmpty(forkliftScanningConfigurationName))
                {
                    throw new IKEAException(IKEAConstants.CustomInvalidDefaultScanningConfigurationFound, IKEAConstants.CustomForkliftScanningConfigurationPath);
                }
                else if (!TableHelper.GetLookupTableValues(IKEAConstants.CustomScanningConfigurationsLookupTable).Contains(forkliftScanningConfigurationName))
                {
                    throw new IKEAException(IKEAConstants.CustomMismatchOnConfigurationAndLookupTable, IKEAConstants.CustomForkliftScanningConfigurationPath, IKEAConstants.CustomScanningConfigurationsLookupTable);
                }
                scanningConfigurationName = forkliftScanningConfigurationName;
            }
            else
            {
                // Try to obtain the scanning configuration name from the smart table
                scanningConfigurationName = GetScanningConfiguration(resource);
            }

            // Check if there is a scanning configuration name configured
            if (!string.IsNullOrWhiteSpace(scanningConfigurationName))
            {
                IFilterCollection filterCollection = new FilterCollection()
                {
                    new Filter()
                    {
                        Name = IKEAConstants.CustomScanningConfigurationScanningConfigurationColumn,
                        Operator = FieldOperator.IsEqualTo,
                        Value = scanningConfigurationName,
                    }
                };

                // Try to obtain the scanning configurations for the given scanning configuration name
                DataSet result = TableHelper.GetDataFromGenericTable(IKEAConstants.CustomScanningConfigurationGenericTable, filterCollection);

                // Check if there are any scanning configurations
                if (result.HasData())
                {
                    // Try to obtain the configured tokens for the given scanning configuration name
                    DataSet tokensDataSet = TableHelper.GetDataFromGenericTable(IKEAConstants.CustomScanningConfigurationTokenGenericTable, filterCollection);

                    // Check if there are any tokens configured
                    if (tokensDataSet.HasData())
                    {
                        DataRow dataRow = result.Tables[0].Rows[0];

                        int configFormat = dataRow.Field<int>(IKEAConstants.CustomScanningConfigurationFormatColumn);

                        CustomScanningFormatEnum scanningFormat = (CustomScanningFormatEnum)Enum.ToObject(typeof(CustomScanningFormatEnum), configFormat);

                        CustomScanningConfiguration scanningConfiguration = new CustomScanningConfiguration()
                        {
                            ScanningConfiguration = dataRow.Field<string>(IKEAConstants.CustomScanningConfigurationScanningConfigurationColumn),
                            Format = scanningFormat,
                            Separator = dataRow.Field<string>(IKEAConstants.CustomScanningConfigurationSeparatorColumn),
                            LeadFiller = dataRow.Field<string>(IKEAConstants.CustomScanningConfigurationLeadFillerColumn)
                        };

                        // Get a list of configured tokens
                        List<CustomScanningConfigurationToken> tokens = new List<CustomScanningConfigurationToken>(tokensDataSet.Tables[0].AsEnumerable().Select(t => new CustomScanningConfigurationToken()
                        {
                            ScanningConfiguration = t.Field<string>(IKEAConstants.CustomScanningConfigurationScanningConfigurationColumn),
                            Position = t.Field<int>(IKEAConstants.CustomScanningConfigurationPositionColumn),
                            Name = t.Field<string>(IKEAConstants.CustomScanningConfigurationNameColumn),
                            StandardToken = t.Field<string>(IKEAConstants.CustomScanningConfigurationStandardTokenColumn),
                            Length = t.Field<int?>(IKEAConstants.CustomScanningConfigurationLengthColumn),
                            LeadFiller = t.Field<string>(IKEAConstants.CustomScanningConfigurationTokenLeadFillerColumn),
                            ParserRule = t.Field<string>(IKEAConstants.CustomScanningConfigurationTokenParserRuleColumn)
                        }));

                        switch (scanningFormat)
                        {
                            case CustomScanningFormatEnum.Standard:
                                // Extract Barcode Information using a standard barcode parser
                                barcodeInformation = StandardBarcodeFactory.ExtractBarcodeInformation(barcodeString, scanningConfiguration, tokens);
                                break;
                            case CustomScanningFormatEnum.CharacterCode:
                                // Extract Barcode Information By ASCII Character Code
                                barcodeInformation = ExtractBarcodeInformationByCharacterCode(barcodeString, scanningConfiguration, tokens);
                                break;
                            case CustomScanningFormatEnum.Custom:
                                // Extract Barcode Information By a String
                                barcodeInformation = ExtractBarcodeInformationByString(barcodeString, scanningConfiguration, tokens);
                                break;
                            case CustomScanningFormatEnum.LengthBased:
                                // Extract Barcode Information By Length
                                barcodeInformation = ExtractBarcodeInformationByLength(barcodeString, scanningConfiguration, tokens);
                                break;
                            case CustomScanningFormatEnum.None:
                            default:
                                // Extract Barcode Information when the configured Format is None
                                barcodeInformation = ExtractBarcodeInformationWithNoneConfiguration(barcodeString, resource, tokens);
                                break;
                        }
                    }
                    else
                    {
                        throw new CustomBarcodeNoScanningConfigurationTokensFoundException(resource.Name);
                    }
                }
                else
                {
                    if (resource == null)
                    {
                        throw new IKEAException(IKEAConstants.CustomInvalidConfigurationOnGenericTable, IKEAConstants.CustomScanningConfigurationGenericTable);
                    }
                    else
                    {
                        throw new CustomBarcodeNoScanningConfigurationFoundException(resource.Name);
                    }
                }
            }
            else
            {
                throw new CustomBarcodeNoScanningConfigurationFoundException(resource.Name);
            }

            return barcodeInformation;
        }

        /// <summary>
        /// Get Scanning Configuration from smart table
        /// </summary>
        /// <param name="resource">Resource</param>
        /// <returns>Scanning Configuration</returns>
        public string GetScanningConfiguration(IResource resource)
        {
            string scanningConfiguration = null;

            if (resource != null && resource.ObjectExists())
            {
                ISmartTable smartTable = new SmartTable();
                smartTable.Load(IKEAConstants.CustomScanningConfigurationSmartTable);

                INgpDataRow values = new NgpDataRow();

                values.Add(OtherConstants.Facility, resource.Area.Facility.Name);
                values.Add(OtherConstants.Area, resource.Area.Name);
                values.Add(OtherConstants.Resource, resource.Name);
                values.Add("ResourceType", resource.Type);

                INgpDataSet nds = smartTable.Resolve(values, true);
                if (nds != null)
                {
                    DataSet ds = NgpDataSet.ToDataSet(nds);
                    if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                    {
                        scanningConfiguration = ds.Tables[0].Rows[0][IKEAConstants.CustomScanningConfigurationScanningConfigurationColumn] as string;
                    }
                }
            }

            return scanningConfiguration;
        }

        #region Private Methods

        /// <summary>
        /// Extract Barcode Information By ASCII Character Code
        /// </summary>
        /// <param name="barcodeString">Barcode</param>
        /// <param name="scanningConfiguration">Scanning Configuration</param>
        /// <param name="tokens">Tokens</param>
        /// <returns>Dictionary with the Barcode Information</returns>
        private static Dictionary<string, string> ExtractBarcodeInformationByCharacterCode(string barcodeString,
                                                                                            CustomScanningConfiguration scanningConfiguration,
                                                                                            List<CustomScanningConfigurationToken> tokens)
        {
            Dictionary<string, string> barcodeInformation = null;

            int charCode;

            // Try to convert the separator value into a valid Char Code
            if (int.TryParse(scanningConfiguration.Separator, out charCode))
            {
                // Get the char based on its ASCII code
                char separator = (char)charCode;

                // Split the barcode string by the given char
                string[] splitBarcode = barcodeString.Split(separator);

                // Extract the barcode information by a split string
                barcodeInformation = ExtractBarcodeInformationBySplitString(splitBarcode, scanningConfiguration, tokens);
            }
            else
            {
                throw new CustomBarcodeWrongSeparatorCharCodeException();
            }

            return barcodeInformation;
        }

        /// <summary>
        /// Extract Barcode Information By a String
        /// </summary>
        /// <param name="barcodeString">Barcode</param>
        /// <param name="scanningConfiguration">Scanning Configuration</param>
        /// <param name="tokens">Tokens</param>
        /// <returns>Dictionary with the Barcode Information</returns>
        private static Dictionary<string, string> ExtractBarcodeInformationByString(string barcodeString,
                                                                                    CustomScanningConfiguration scanningConfiguration,
                                                                                    List<CustomScanningConfigurationToken> tokens)
        {
            // Split the string by another string
            string[] splitBarcode = barcodeString.Split(new string[] { scanningConfiguration.Separator }, StringSplitOptions.None);

            // Extract the barcode information by a split string
            return ExtractBarcodeInformationBySplitString(splitBarcode, scanningConfiguration, tokens);
        }

        /// <summary>
        /// Extract Barcode Information using a split string
        /// </summary>
        /// <param name="splitBarcode">Barcode</param>
        /// <param name="scanningConfiguration">Scanning Configuration</param>
        /// <param name="tokens">Tokens</param>
        /// <returns>Dictionary with the Barcode Information</returns>
        private static Dictionary<string, string> ExtractBarcodeInformationBySplitString(string[] splitBarcode,
                                                                                            CustomScanningConfiguration scanningConfiguration,
                                                                                            List<CustomScanningConfigurationToken> tokens)
        {
            Dictionary<string, string> barcodeInformation = null;

            // Check if the number of strings in the split barcode is the same 
            // as the number of configured tokens
            if (splitBarcode.Length == tokens.Count)
            {
                barcodeInformation = new Dictionary<string, string>();

                for (int i = 0; i < splitBarcode.Length; i++)
                {
                    // Get the correspondent token by its position
                    CustomScanningConfigurationToken token = tokens.Where(t => t.Position == i + 1).FirstOrDefault();

                    if (token != null)
                    {
                        // Get the barcode info by position and trim the Lead Filler
                        barcodeInformation.Add(token.Name, splitBarcode[i].TrimStart(scanningConfiguration.LeadFiller, true));
                    }
                    else
                    {
                        throw new CustomBarcodeTokenWithPositionDoesNotExistException(scanningConfiguration.ScanningConfiguration, i.ToString());
                    }
                }
            }
            else
            {
                throw new CustomBarcodeWrongBarcodeLengthException();
            }

            return barcodeInformation;
        }

        /// <summary>
        /// Extract Barcode Information By Length
        /// </summary>
        /// <param name="barcodeString">Barcode</param>
        /// <param name="scanningConfiguration">Scanning Configuration</param>
        /// <param name="tokens">Tokens</param>
        /// <returns>Dictionary with the Barcode Information</returns>
        private static Dictionary<string, string> ExtractBarcodeInformationByLength(string barcodeString,
                                                                                    CustomScanningConfiguration scanningConfiguration,
                                                                                    List<CustomScanningConfigurationToken> tokens)
        {
            Dictionary<string, string> barcodeInformation = null;

            // Get the expected length of the barcode by the sum of
            // length configured in the tokens
            int length = tokens.Sum(t => t.Length.HasValue ? t.Length.Value : 0);

            // Check if the barcode string has the expected length
            if (barcodeString.Length == length)
            {
                barcodeInformation = new Dictionary<string, string>();

                int startPosition = 0;

                foreach (CustomScanningConfigurationToken token in tokens.Where(t => t.Length.HasValue).OrderBy(t => t.Position))
                {
                    // Get the barcode info by position and length in the original string and trim the Lead Filler
                    string info = barcodeString.Substring(startPosition, token.Length.Value).TrimStart(scanningConfiguration.LeadFiller, true);

                    barcodeInformation.Add(token.Name, info);

                    startPosition += token.Length.Value;
                }
            }
            else
            {
                throw new CustomBarcodeWrongBarcodeLengthException();
            }

            return barcodeInformation;
        }

        /// <summary>
        /// Extract Barcode Information when the configured Format is None
        /// </summary>
        /// <param name="barcodeString">Barcode</param>
        /// <param name="scanningConfiguration">Scanning Configuration</param>
        /// <param name="tokens">Tokens</param>
        /// <returns>Dictionary with the Barcode Information</returns>
        private static Dictionary<string, string> ExtractBarcodeInformationWithNoneConfiguration(string barcodeString,
                                                                                                    IResource resource,
                                                                                                    List<CustomScanningConfigurationToken> tokens)
        {
            Dictionary<string, string> barcodeInformation = null;

            // Get the first token
            CustomScanningConfigurationToken token = tokens.OrderBy(t => t.Position).FirstOrDefault();

            // Check if there are any tokens
            if (token != null)
            {
                barcodeInformation = new Dictionary<string, string>();

                // Return the unaltered barcode string with the 
                // name of the first token as the key
                barcodeInformation.Add(token.Name, barcodeString);
            }
            else
            {
                throw new CustomBarcodeNoScanningConfigurationTokensFoundException(resource.Name);
            }

            return barcodeInformation;
        }

        #endregion
    }
}
