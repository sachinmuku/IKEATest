﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Custom.IKEA.Common.ERP;
using Cmf.Custom.IKEA.Common.Extensions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.Common;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Xml;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Custom.IKEA.BusinessObjects.Abstractions;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Foundation.BusinessOrchestration.Abstractions;
using Cmf.Foundation.Common.LocalizationService;
using Cmf.Navigo.BusinessOrchestration.Abstractions;
using Cmf.Custom.IKEA.Common.Exceptions;
using Cmf.Common.CustomActionUtilities.Abstractions;

namespace Cmf.Custom.IKEA.Common.Utilities
{
    public class ERPUtilities : IERPUtilities
    {
        private IEntityFactory _entityFactory;
        private IIKEAUtilities _iKEAUtilities;
        private IGenericUtilities _genericUtilities;
        private IGenericServiceOrchestration _genericServiceOrchestration;
        //private IMaterialOrchestration _materialOrchestration;
        private ILocalizationService _localizationService;
        private IDeeContextUtilities _deeContextUtilities;

        [Microsoft.Extensions.DependencyInjection.ActivatorUtilitiesConstructor]
        public ERPUtilities(IEntityFactory entityFactory,
            IGenericUtilities genericUtilities,
            IGenericServiceOrchestration genericServiceOrchestration,
            IIKEAUtilities iKEAUtilities,
            ILocalizationService localizationService,
            IDeeContextUtilities deeContextUtilities)
        {
            _entityFactory = entityFactory;
            _genericUtilities = genericUtilities;
            _genericServiceOrchestration = genericServiceOrchestration;
            _iKEAUtilities = iKEAUtilities;
            _localizationService = localizationService;
            _deeContextUtilities = deeContextUtilities;
        }
        /// <summary>
        /// Send ERP Message
        /// </summary>
        /// <param name="message">Dictionary that contains the parameters and their values</param>
        /// <param name="messageEndpoint"></param>
        /// <returns></returns>
        public string SendERPMessage(Dictionary<string, string> message, string messageEndpoint)
        {
            string result = string.Empty;

            if (!message.IsNullOrEmpty())
            {
                // Get Access Token
                string accessToken = GetAccessToken();

                // Check if any access point was retrieve
                if (!string.IsNullOrWhiteSpace(accessToken))
                {
                    // Get base URL
                    string baseURL = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.ERPM3BaseEndpoint);

                    // Check if any base URL was configured
                    if (!string.IsNullOrWhiteSpace(baseURL))
                    {
                        using (HttpClient httpClient = new HttpClient())
                        {
                            httpClient.BaseAddress = new Uri(baseURL);
                            httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);

                            // Get list of strings from the dictionary with the format {0}={1}
                            List<string> messageValues = message.Select(x => string.Format("{0}={1}", x.Key, x.Value)).ToList();

                            string requestUrl = string.Format("{0}?{1}", messageEndpoint, string.Join("&", messageValues));

                            try
                            {
                                HttpRequestMessage httpRequest = new HttpRequestMessage(HttpMethod.Get, requestUrl);

                                HttpResponseMessage httpResponse = httpClient.SendAsync(httpRequest).GetAwaiter().GetResult();

                                string responseBody = httpResponse.Content.ReadAsStringAsync().GetAwaiter().GetResult();

                                // Handle http errors:
                                if (!httpResponse.IsSuccessStatusCode)
                                {
                                    throw new IKEAException(IKEAConstants.CustomERPExceptionLocalizedMessage, ("HTTP " + (int)httpResponse.StatusCode + " - " + httpResponse.StatusCode));
                                }

                                // Check if the ERP returned an error message in the response (usually is XML)
                                string errorMessage = "";

                                if (httpResponse.Content.Headers.ContentType.MediaType == "application/xml" || httpResponse.Content.Headers.ContentType.MediaType == "text/xml")
                                {
                                    XmlDocument xmldoc = new XmlDocument();
                                    xmldoc.LoadXml(responseBody);

                                    // If an error message is received:
                                    if (xmldoc.SelectNodes(IKEAConstants.ErrorMessage).Count > 0)
                                    {
                                        errorMessage = xmldoc.GetValueByXPath(IKEAConstants.ErrorMessageContent);
                                    }
                                }
                                else if (httpResponse.Content.Headers.ContentType.MediaType == "application/json")
                                {
                                    errorMessage = JObject.Parse(responseBody).Value<string>("error");
                                }

                                // Message was processed but the ERP returned an error message:
                                if (!errorMessage.IsNullOrEmpty())
                                {
                                    throw new IKEAException(IKEAConstants.CustomERPExceptionLocalizedMessage, errorMessage);
                                }

                                result = responseBody;

                            }
                            catch (WebException exception)
                            {
                                string responseText = string.Empty;

                                var responseStream = exception.Response != null ? exception.Response.GetResponseStream() : null;

                                if (responseStream != null)
                                {
                                    using (var reader = new StreamReader(responseStream))
                                    {
                                        responseText = reader.ReadToEnd();
                                        if (!string.IsNullOrEmpty(responseText))
                                            throw new IKEAException(IKEAConstants.CustomERPExceptionLocalizedMessage, responseText);
                                    }
                                }
                            }
                        }
                    }
                    else
                    {
                        throw new IKEAException((IKEAConstants.CustomERPMissingBaseEndpointLocalizedMessage));
                    }
                }
                else
                {
                    throw new IKEAException((IKEAConstants.CustomERPUnableToObtainTokenLocalizedMessage));
                }
            }

            return result;
        }

        /// <summary>
        /// Get Access Token
        /// </summary>
        /// <returns>Access Token</returns>
        private string GetAccessToken()
        {
            string accessToken = string.Empty;

            using (WebClient client = new WebClient())
            {
                try
                {
                    // Get authentication configurations
                    string username = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.ERPM3Username);
                    string password = _iKEAUtilities.GetDecryptedSecureStringConfiguration(IKEAConstants.ERPM3Password);
                    string clientId = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.ERPM3ClientId);
                    string clientSecret = _iKEAUtilities.GetDecryptedSecureStringConfiguration(IKEAConstants.ERPM3ClientSecret);
                    string tokenEndpoint = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.ERPM3TokenEndpoint);

                    // Check if any of the configurations is missing
                    if (!string.IsNullOrWhiteSpace(username)
                        && !string.IsNullOrWhiteSpace(password)
                        && !string.IsNullOrWhiteSpace(clientId)
                        && !string.IsNullOrWhiteSpace(clientSecret)
                        && !string.IsNullOrWhiteSpace(tokenEndpoint))
                    {
                        StringBuilder tokenRequest = new StringBuilder();

                        // Build Request Message
                        tokenRequest.Append("grant_type=password").Append("&")
                                    .AppendFormat("username={0}", username).Append("&")
                                    .AppendFormat("password={0}", password).Append("&")
                                    .AppendFormat("client_id={0}", clientId).Append("&")
                                    .AppendFormat("client_secret={0}", clientSecret);

                        // Set headers
                        client.Headers.Add(HttpRequestHeader.ContentType, "application/x-www-form-urlencoded");
                        client.Headers.Add(HttpRequestHeader.Accept, "application/json");

                        // Upload Message
                        string result = client.UploadString(tokenEndpoint, "POST", tokenRequest.ToString());

                        // Get result data
                        var data = JObject.Parse(result);

                        // Get access token from result data
                        accessToken = data["access_token"].ToString();
                    }
                    else
                    {
                        throw new IKEAException((IKEAConstants.CustomERPMissingConfigurationsLocalizedMessage));
                    }
                }
                catch (WebException exception)
                {
                    string responseText = string.Empty;

                    var responseStream = exception.Response != null ? exception.Response.GetResponseStream() : null;

                    if (responseStream != null)
                    {
                        using (var reader = new StreamReader(responseStream))
                        {
                            responseText = reader.ReadToEnd();
                            if (!string.IsNullOrEmpty(responseText))
                                throw new IKEAException(IKEAConstants.CustomERPExceptionLocalizedMessage, responseText);
                        }
                    }

                    if (string.IsNullOrEmpty(responseText) && !string.IsNullOrEmpty(exception.Message))
                    {
                        responseText = exception.Message;
                    }

                    throw new IKEAException(IKEAConstants.CustomERPExceptionLocalizedMessage, responseText);
                }
            }

            return accessToken;
        }

        /// <summary>
        /// Reports the completion of units
        /// </summary>
        /// <param name="materials">Materials to be reported</param>
        /// <param name="force">Boolean to force Completion</param>
        public void ReportUnitComplete(IMaterialCollection materials, bool isNiceLabelReport, bool force = false)
        {
            if (!materials.IsNullOrEmpty())
            {
                // Edge case: when a pallet is retrieved and has a 'MoveNext' event configured on 'CustomMaterialMovementConfiguration' SmartTable
                // and the destination Step has configured the parameter 'MarksProductCompletion' set to true, the ProductionOrder link to the pallet
                // will be list, before this report being called. To overcome this, the 'CustomMaterialProcessingHandler' is sending the material / PO relation.
                // Both ProductionOrder as Material's property and as ContextParameter are being checked to decide if the material is reported or not.
                Dictionary<IMaterial, string> materialProductionOrderName = DeeContextHelper.GetContextParameter("CustomMaterialProcessingHandlerMaterialProductionOrder") as Dictionary<IMaterial, string>;

                List<long> resourceIds = materials.Select(m => m.GetNativeValue<long>("LastProcessedResource")).Distinct().ToList();

                IResourceCollection resources = _entityFactory.CreateCollection<IResourceCollection>();
                resources.LoadByIDs<IResource, Navigo.BusinessObjects.Resource>(resourceIds);

                // Load all the InventoryLocation of the resources
                resources.LoadAttributes(new Collection<string>() { IKEAConstants.CustomResourceAttributeInventoryLocation });

                Dictionary<long, IResource> loadedResources = resources.ToDictionary(r => r.Id, r => r);

                Dictionary<IMaterial, IAttributeCollection> materialAttributes = new Dictionary<IMaterial, IAttributeCollection>();

                IAttributeCollection attributes = new AttributeCollection()
                {
                    { IKEAConstants.CustomMaterialAttributeERPIsCreationReported, true },
                    { IKEAConstants.CustomMaterialAttributeERPBlockedMovementReport, false }
                };

                // Materials with type 'SampleTesting' do not report to ERP.
                string sampleTestingTypeName = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.MaterialTypeSampleTestingConfig);

                materials.LoadAttributes(new Collection<string>() {
                                                                    IKEAConstants.CustomMaterialAttributeERPOriginalName,
                                                                    IKEAConstants.CustomMaterialAttributeERPIsCreationReported });

                foreach (IMaterial material in materials)
                {
                    // Due to the MoveNext edgecase: Obtain ProductionOrder name from DeeContext if Material has list it's ProductionOrder relation
                    string productionOrderName;
                    if (material.ProductionOrder != null)
                    {
                        productionOrderName = material.ProductionOrder.Name;
                    }
                    else
                    {
                        productionOrderName = GetMaterialRelatedEntityNameFromMaterial("CustomMaterialProcessingHandlerMaterialProductionOrder", material.Name);
                    }

                    if (sampleTestingTypeName.IsNullOrEmpty() || !material.Type.Equals(sampleTestingTypeName, StringComparison.InvariantCultureIgnoreCase))
                    {

                        // Gets the corresponding ERP material type for the material type:
                        string erpMaterialType = _iKEAUtilities.GetTypeFromErpMappingTable(IKEAConstants.MESSystem, IKEAConstants.CustomERPColumnsMappingMaterial, IKEAConstants.CustomERPColumnsMappingType, material.Type, IKEAConstants.ERPSystem);

                        if (!string.IsNullOrEmpty(erpMaterialType))
                        {
                            // Edge case: when a pallet is retrieved and has a 'MoveNext' event configured on 'CustomMaterialMovementConfiguration' SmartTable
                            // pallet flow path and step will change before being reported.
                            // To overcome this, the 'CustomMaterialProcessingHandler' is sending the material / flowpath and material / step relation before the MoveNext event.

                            // Get the main flow of the flow path
                            string flowpath;
                            string materialFlowPathFromContext = GetMaterialRelatedEntityNameFromMaterial("CustomMaterialProcessingHandlerMaterialFlowPath", material.Name);
                            if (materialFlowPathFromContext != String.Empty)
                            {
                                flowpath = materialFlowPathFromContext;
                            }
                            else
                            {
                                flowpath = material.FlowPath;
                            }

                            IFlow mainFlow = _genericUtilities.GetFlowsInFlowPath(flowpath).FirstOrDefault();

                            // Get the last process step of the last flow with ERPOperationCode
                            IStep step = _iKEAUtilities.GetLastProcessStepFromLastFlowWithERPOperation(mainFlow);

                            string stepNameFromDeeContext = GetMaterialRelatedEntityNameFromMaterial("CustomMaterialProcessingHandlerMaterialStep", material.Name);
                            long currentMaterialStepId;
                            if (stepNameFromDeeContext != String.Empty)
                            {
                                IStep currentMaterialStep = _entityFactory.Create<IStep>();
                                currentMaterialStep.Name = stepNameFromDeeContext;
                                currentMaterialStep.Load();
                                currentMaterialStepId = currentMaterialStep.Id;
                            }
                            else
                            {
                                currentMaterialStepId = material.GetNativeValue<long>(Navigo.Common.Constants.Step);
                            }

                            if (step != null)
                            {
                                step.Load();

                                // Get facility ERP Identifier
                                string erpIdentifier = material.Facility.GetAttributeValueOrDefault<string>(IKEAConstants.CustomFacilityAttributeERPIdentifier, true);

                                IResource resource = loadedResources[material.GetNativeValue<long>("LastProcessedResource")];

                                // Check if the automatic reporting to ERP is enabled in the SmartTable:
                                bool automaticReportPalletization = false;
                                _iKEAUtilities.ResolveCustomERPReporting(step, material.Facility, resource.Area, resource.Name).TryGetValue(IKEAConstants.CustomERPReportingResolutionReportPalletizationColumn, out automaticReportPalletization);

                                if (automaticReportPalletization)
                                {

                                    // Get the inventory location of the resource
                                    string inventoryLocation = resource.GetAttributeValueOrDefault<string>(IKEAConstants.CustomResourceAttributeInventoryLocation);
                                    string cono = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.CompanyCodeConfig);
                                    string materialQuantity = material.PrimaryQuantity.HasValue ? material.PrimaryQuantity.Value.ToString("#########0.###") : "0";

                                    // Get Material ERP Original Name
                                    string erpOriginalName = material.GetAttributeValueOrDefault<string>(IKEAConstants.CustomMaterialAttributeERPOriginalName);

                                    string materialName = string.IsNullOrWhiteSpace(erpOriginalName) ? material.Name : erpOriginalName;

                                    bool isOrderless = material.GetAttributeValueOrDefault(IKEAConstants.CustomMaterialIsOrderlessAttribute, defaultValue: false);

                                    bool reportOrderless = false;

                                    if (isOrderless)
                                    {
                                        reportOrderless = _genericUtilities.GetConfigurationValueByPath<bool>(IKEAConstants.ERPReportOrderlessConfig);
                                    }

                                    // Instantiate the object to be serialized as the Integration Entry body
                                    MESERPCommunication communication = null;

                                    string bano = string.Empty;
                                    string camu = materialName;
                                    if (isNiceLabelReport)
                                    {
                                        camu = material.GetAttributeValueOrDefault<string>(IKEAConstants.CustomMaterialSSCCAttribute);
                                        bano = productionOrderName;
                                    }
                                    if (isOrderless && reportOrderless)
                                    {
                                        // Load the required attributes from the Production Order
                                        IProductionOrder productionOrder = _entityFactory.Create<IProductionOrder>();
                                        productionOrder.Name = productionOrderName;
                                        productionOrder.Load();
                                        productionOrder.LoadAttributes(new Collection<string>
                                        {
                                            IKEAConstants.CustomProductionOrderAttributeReportingWarehouse,
                                            IKEAConstants.CustomProductionOrderAttributeStructureType,
                                        });

                                        string warehouseLocation = productionOrder.GetAttributeValueOrDefault<string>(IKEAConstants.CustomProductionOrderAttributeReportingWarehouse);
                                        string structureType = productionOrder.GetAttributeValueOrDefault<string>(IKEAConstants.CustomProductionOrderAttributeStructureType);

                                        if (!warehouseLocation.IsNullOrEmpty() && !structureType.IsNullOrEmpty())
                                        {
                                            var message = new ERPOrderlessPalletizationCompletionCommunication
                                            {
                                                Warehouse = warehouseLocation,
                                                ProductionNumber = material.Product.GetRelatedAttributeValueOrDefault<string>(IKEAConstants.CustomProductAttributeBaseProduct, true) ?? material.Product.Name,
                                                StructureType = structureType,
                                                OrderQuantity = materialQuantity,
                                                Location = inventoryLocation ?? string.Empty,
                                                LotNumber = bano,
                                                Container = camu
                                            };

                                            communication = new MESERPCommunication()
                                            {
                                                API = IKEAConstants.ERPM3EndpointOrderlessUnitComplete,
                                                Message = JsonConvert.SerializeObject(message),
                                                // Include the material name in the Integration Entry, so in the response we can save the ERP Order Name in its attributes
                                                Context = material.Name,
                                            };
                                        }
                                    }
                                    else if (!isOrderless)
                                    {
                                        var message = new ERPPalletizationCompletionCommunication
                                        {
                                            Facility = erpIdentifier,
                                            ProductionNumber = material.Product.GetRelatedAttributeValueOrDefault<string>(IKEAConstants.CustomProductAttributeBaseProduct, true) ?? material.Product.Name,
                                            ManufacturingOrderNumber = productionOrderName,
                                            ReportingDate = DateTime.Now.ToString("yyyyMMdd"),
                                            ReportingTime = DateTime.Now.ToString("hhmmss").TrimStart('0'),
                                            ReportQuantityInAlternativeUnit = materialQuantity,
                                            ManufacturingUnitsMeasurement = material.PrimaryUnits,
                                            Status = (material.Type.CompareStrings(IKEAConstants.MaterialTypeOutsorted) ? "1" : "2"),
                                            ManualCompletionFlag = "0",
                                            Location = inventoryLocation ?? string.Empty,
                                            LotNumber = bano,
                                            Container = camu
                                        };

                                        if (force)
                                        {
                                            string rejectionReason = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.ERPM3RejectionReason);

                                            message.ManufacturedQuantity = materialQuantity;
                                            message.ScrapQuantityAlternativeUnit = materialQuantity;
                                            message.RejectionReason = rejectionReason;
                                        }

                                        communication = new MESERPCommunication()
                                        {
                                            API = IKEAConstants.ERPM3EndpointUnitComplete,
                                            Message = JsonConvert.SerializeObject(message)
                                        };
                                    }

                                    // Get attribute to do not report if material has already been reported
                                    bool materialAttributeERPIsCreationReported = material.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomMaterialAttributeERPIsCreationReported);

                                    if (communication != null && !materialAttributeERPIsCreationReported)
                                    {
                                        // Convert the object to XML
                                        XmlDocument xmlDoc = XMLExtensions.SerializeToXMLDocument(communication);

                                        // Create the Integration Entry
                                        _iKEAUtilities.CreateIntegrationEntry(IKEAConstants.MESSystem,
                                                                            IKEAConstants.ERPSystem,
                                                                            IKEAConstants.ERPUnitCompleteMessageType,
                                                                            IKEAConstants.ERPPalletizationUnitCompleteEventName,
                                                                            xmlDoc);

                                        // Save indication that the creation of the material was reported
                                        materialAttributes.Add(material, attributes);
                                    }
                                }
                            }                            
                        }
                    }
                }

                // Check if there are any attributes to save
                if (!materialAttributes.IsNullOrEmpty())
                {
                    _iKEAUtilities.SaveAttributesToMultipleMaterials(materialAttributes);
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="materials"></param>
        /// <param name="force"></param>
        public void ReportLeftOvers(IMaterialCollection materialsLeftOver)
        {
            //TODO Validate code
            if (!materialsLeftOver.IsNullOrEmpty())
            {
                List<long> resourceIds = materialsLeftOver.Select(m => m.GetNativeValue<long>("LastProcessedResource")).Distinct().ToList();

                IResourceCollection resources = _entityFactory.CreateCollection<IResourceCollection>();
                resources.LoadByIDs<IResource, Navigo.BusinessObjects.Resource>(resourceIds);

                // Load all the InventoryLocation of the resources
                resources.LoadAttributes(new Collection<string>() { IKEAConstants.CustomResourceAttributeInventoryLocation });

                Dictionary<long, IResource> loadedResources = resources.ToDictionary(r => r.Id, r => r);

                Dictionary<IMaterial, IAttributeCollection> materialAttributes = new Dictionary<IMaterial, IAttributeCollection>();

                IAttributeCollection attributes = new AttributeCollection()
                {
                    { IKEAConstants.CustomMaterialAttributeERPIsCreationReported, true },
                    { IKEAConstants.CustomMaterialAttributeERPBlockedMovementReport, false }
                };

                materialsLeftOver.LoadAttributes(new Collection<string>() {
                                                IKEAConstants.CustomMaterialAttributeERPOriginalName,
                                                IKEAConstants.CustomMaterialAttributeERPIsCreationReported,
                                                IKEAConstants.CustomMaterialMOReportLeftOverAttribute});

                foreach (IMaterial leftOver in materialsLeftOver)
                {
                    string nameMO = leftOver.GetAttributeValueOrDefault<string>(IKEAConstants.CustomMaterialMOReportLeftOverAttribute);
                    IMaterial materialMO = _entityFactory.Create<IMaterial>();
                    materialMO.Load(nameMO);

                    if (materialMO.GetNativeValue<long>(Navigo.Common.Constants.ProductionOrder) <= 0)
                    {
                        continue;
                    }

                    string config = IKEAConstants.ERPM3Endpoint + IKEAConstants.ERPM3EndpointERPLeftOverUnitComplete;
                    string endpoint = _genericUtilities.GetConfigurationValueByPath<string>(config);
                    string erpMaterialType = _iKEAUtilities.GetTypeFromErpMappingTable(IKEAConstants.MESSystem, IKEAConstants.CustomERPColumnsMappingMaterial, IKEAConstants.CustomERPColumnsMappingType, leftOver.Type, IKEAConstants.ERPSystem, endpoint);

                    if (!string.IsNullOrEmpty(erpMaterialType))
                    {
                        string flowpath = materialMO.FlowPath;

                        // Get the main flow of the flow path
                        IFlow mainFlow = _genericUtilities.GetFlowsInFlowPath(flowpath).FirstOrDefault();

                        // Get the last process step of the last flow with ERPOperationCode
                        IStep step = _iKEAUtilities.GetLastProcessStepFromLastFlowWithERPOperation(mainFlow);

                        if (step != null && step.Id == materialMO.GetNativeValue<long>(Navigo.Common.Constants.Step))
                        {
                            // Get facility ERP Identifier
                            string erpIdentifier = materialMO.Facility.GetAttributeValueOrDefault<string>(IKEAConstants.CustomFacilityAttributeERPIdentifier, true);

                            IResource resource = loadedResources[materialMO.GetNativeValue<long>("LastProcessedResource")];

                            // Check if the automatic reporting to ERP is enabled in the SmartTable:
                            bool automaticReportPalletization = false;
                            _iKEAUtilities.ResolveCustomERPReporting(step, materialMO.Facility, resource.Area, resource.Name).TryGetValue(IKEAConstants.CustomERPReportingResolutionReportPalletizationColumn, out automaticReportPalletization);

                            if (automaticReportPalletization)
                            {
                                // Get the inventory location of the resource
                                string inventoryLocation = resource.GetAttributeValueOrDefault<string>(IKEAConstants.CustomResourceAttributeInventoryLocation);

                                // Instantiate the object to be serialized as the Integration Entry body
                                MESERPCommunication communication = null;

                                // Get override ERP operation code (short structures only!)
                                string erpOperationCodeOverride = materialMO.ProductionOrder.GetAttributeValueOrDefault<string>("ERPOperationCodeOverride", true);

                                IBOMProductCollection materialBOMProducts = _iKEAUtilities.GetCurrentBOMProductsFromMaterials(new List<string>() { materialMO.Name });
                                materialBOMProducts.LoadAttributes(new Collection<string>
                                {
                                    IKEAConstants.BomProductIsByProductSegmentAttribute,
                                    IKEAConstants.BomProductERPBOMOperationSequenceAttribute
                                });
                                IBOMProduct bomProduct = materialBOMProducts.Where(bp => bp.GetAttributeValueOrDefault<bool>(IKEAConstants.BomProductIsByProductSegmentAttribute)).FirstOrDefault();

                                bomProduct?.TargetEntity?.Load();
                                int? decimalPlaces = bomProduct?.TargetEntity?.GetRelatedAttributeValueOrDefault<int?>(IKEAConstants.CustomProductAttributeDecimalPlaces, true);

                                //Left over quatity
                                decimal materialQuantity = leftOver.PrimaryQuantity.Value;
                                // Only round the value if the product has the Decimal Places attribute set
                                decimal quantityToReportRounded = decimalPlaces != null
                                    ? decimal.Round(materialQuantity, decimalPlaces.Value)
                                    : materialQuantity;

                                // Get Material ERP Original Name
                                string erpOriginalName = leftOver.GetAttributeValueOrDefault<string>(IKEAConstants.CustomMaterialAttributeERPOriginalName);

                                string materialName = string.IsNullOrWhiteSpace(erpOriginalName) ? leftOver.Name : erpOriginalName;

                                var message = new ERPPalletizationLeftOversCommunication
                                {
                                    Facility = erpIdentifier,
                                    ManufacturingOrderNumber = materialMO.ProductionOrder?.Name ?? materialMO.Name,
                                    OperationNumber = erpOperationCodeOverride,
                                    SequenceNumber = bomProduct?.GetAttributeValueOrDefault<string>(IKEAConstants.BomProductERPBOMOperationSequenceAttribute),
                                    ReportingDate = DateTime.Now.ToString("yyyyMMdd"),
                                    ReportingTime = DateTime.Now.ToString("hhmmss").TrimStart('0'),
                                    ReportedQuantity = quantityToReportRounded.ToString(),
                                    Location = inventoryLocation ?? string.Empty,
                                    MaterialName = materialName ?? string.Empty,
                                    StatusBalanceID = String.IsNullOrWhiteSpace(erpMaterialType) ? "NA" : erpMaterialType
                                };

                                communication = new MESERPCommunication()
                                {
                                    API = IKEAConstants.ERPM3EndpointERPLeftOverUnitComplete,
                                    Message = JsonConvert.SerializeObject(message)
                                };


                                // Get attribute to do not report if material has already been reported
                                bool materialAttributeERPIsCreationReported = leftOver.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomMaterialAttributeERPIsCreationReported);

                                if (communication != null && !materialAttributeERPIsCreationReported)
                                {
                                    // Convert the object to XML
                                    XmlDocument xmlDoc = XMLExtensions.SerializeToXMLDocument(communication);

                                    // Create the Integration Entry
                                    _iKEAUtilities.CreateIntegrationEntry(IKEAConstants.MESSystem,
                                                                        IKEAConstants.ERPSystem,
                                                                        IKEAConstants.ERPLeftOverUnitCompleteMessageType,
                                                                        IKEAConstants.ERPPalletizationLeftOversEventName,
                                                                        xmlDoc);

                                    // Save indication that the creation of the material was reported
                                    materialAttributes.Add(leftOver, attributes);
                                }
                            }
                        }
                    }

                }

                // Check if there are any attributes to save
                if (!materialAttributes.IsNullOrEmpty())
                {
                    _iKEAUtilities.SaveAttributesToMultipleMaterials(materialAttributes);
                }
            }
        }

        /// <summary>
        /// Reports the completion of the production order
        /// </summary>
        /// <param name="productionOrder"></param>
        public void ReportProductionOrderComplete(IProductionOrder productionOrder)
        {

            // Get facility ERP Identifier
            string erpIdentifier = productionOrder.Facility.GetAttributeValueOrDefault<string>(IKEAConstants.CustomFacilityAttributeERPIdentifier, true);

            productionOrder.LoadRelations(IKEAConstants.CustomPOOperationResource);

            if (productionOrder.RelationCollection != null && productionOrder.RelationCollection.ContainsKey(IKEAConstants.CustomPOOperationResource))
            {
                ICustomPOOperationResource relation = productionOrder.RelationCollection[IKEAConstants.CustomPOOperationResource].FirstOrDefault() as ICustomPOOperationResource;
                if (relation != null)
                {
                    //resource is a mandatory property in this relation
                    IResource resource = relation.TargetEntity;
                    resource.Load();
                    if (resource.Area != null)
                    {
                        resource.Area.Name = resource.Area.GetNativeValue<string>(Constants.Name);
                    }

                    if (productionOrder.Step != null)
                    {
                        productionOrder.Step.Name = productionOrder.Step.GetNativeValue<string>(Constants.Name);
                    }

                    if (productionOrder.Facility != null)
                    {
                        productionOrder.Facility.Name = productionOrder.Facility.GetNativeValue<string>(Constants.Name);
                    }

                    //resolve smart table
                    bool automaticReportPalletization = false;
                    _iKEAUtilities.ResolveCustomERPReporting(productionOrder.Step, productionOrder.Facility, resource.Area, resource.Name).TryGetValue(IKEAConstants.CustomERPReportingResolutionReportPalletizationColumn, out automaticReportPalletization);

                    if (automaticReportPalletization)
                    {
                        // Instantiate the object to be serialized
                        ERPPalletizationCompletionCommunication palletizationCompletionCommunication = new ERPPalletizationCompletionCommunication
                        {
                            Facility = erpIdentifier,
                            ProductionNumber = productionOrder.Product.GetRelatedAttributeValueOrDefault<string>(IKEAConstants.CustomProductAttributeBaseProduct, true) ?? productionOrder.Product.Name,
                            ManufacturingOrderNumber = productionOrder.Name,
                            ReportingDate = DateTime.Now.ToString("yyyyMMdd"),
                            ReportingTime = DateTime.Now.ToString("hhmmss").TrimStart('0'),
                            ReportQuantityInAlternativeUnit = string.Empty,
                            ManufacturingUnitsMeasurement = string.Empty,
                            Status = string.Empty,
                            ManualCompletionFlag = "1",
                            Location = string.Empty,
                            LotNumber = string.Empty,
                            Container = string.Empty
                        };

                        // Get json file
                        string json = JsonConvert.SerializeObject(palletizationCompletionCommunication);

                        MESERPCommunication communication = new MESERPCommunication()
                        {
                            API = IKEAConstants.ERPM3EndpointUnitComplete,
                            Message = json
                        };

                        // Convert the object to XML
                        XmlDocument xmlDoc = XMLExtensions.SerializeToXMLDocument(communication);

                        // Create the Integration Entry
                        _iKEAUtilities.CreateIntegrationEntry(IKEAConstants.MESSystem,
                                                            IKEAConstants.ERPSystem,
                                                            IKEAConstants.ERPUnitCompleteMessageType,
                                                            IKEAConstants.ERPProductionOrderCompleteEventName,
                                                            xmlDoc);


                    }
                }
            }
        }

        /// <summary>
        /// Handles the result of calling the ERP Orderless Unit Complete API
        /// Saves the Order Name returned by the ERP in an attribute in the Pallet Material
        /// 
        /// Example of the response sent in JSON:
        /// 
        /// {
        ///     "MIRecord": [
        ///         {
        ///             "RowIndex": 0,
        ///             "NameValue": [
        ///                 {
        ///                     "Name": "PANR",
        ///                     "Value": "             "
        ///                 },
        ///                 {
        ///                     "Name": "PAII",
        ///                     "Value": "             "
        ///                 },
        ///                 {
        ///                     "Name": "RIDN",
        ///                     "Value": "1000056149"
        ///                 }
        ///             ]
        ///         }
        ///     ]
        /// }
        /// </summary>
        /// <param name="communication"></param>
        /// <param name="result"></param>
        public void HandleERPOrderlessUnitCompleteResponse(MESERPCommunication communication, string result)
        {
            // In the Context property is stored the tracked-ou Pallet Material's Name
            var materialName = communication.Context;

            // Let's avoid throwing any exceptions here. Since we already called the ERP API to register this API,
            // if we throw any exception here, the Integration Entry where this function is called would be marked
            // as failed. It could then be reprocessed, and the API called again, leading it to think there are
            // two pallets instead of one.
            if (!materialName.IsNullOrEmpty())
            {
                var material = _entityFactory.Create<IMaterial>();
                material.Name = materialName;

                if (material.ObjectExists())
                {
                    JObject jsonResult = JObject.Parse(result);

                    string erpOrderName = (string)jsonResult.SelectToken("$.MIRecord[0].NameValue[?(@.Name == 'RIDN')].Value", false);

                    if (erpOrderName != null)
                    {
                        material.Load();
                        material.SaveAttributes(new AttributeCollection
                        {
                            { IKEAConstants.CustomMaterialERPOrderNameAttribute, erpOrderName }
                        });
                    }
                }
            }
        }

        /// <summary>
        /// Handles Material movement communication between MES > ERP
        /// </summary>
        /// <param name="isToCreateIntegrationEntry"></param>
        /// <param name="pallets"></param>
        /// <param name="palletNewLocation"></param>
        public void HandleMaterialMovementCommunication(bool isToCreateIntegrationEntry, IMaterialCollection pallets, Dictionary<long, string> palletNewLocation)
        {
            // get material forms not eligible for reporting movements
            string materialOrderForm = _iKEAUtilities.GetOrderMaterialForm();
            string materialBatchForm = _iKEAUtilities.GetOrderMaterialBatch();

            pallets.LoadAttributes(new Collection<string>() {
                    IKEAConstants.CustomMaterialAttributeERPOriginalName
                    , IKEAConstants.CustomMaterialAttributeLastKnownERPOperation
                    , IKEAConstants.CustomMaterialAttributeERPBlockedMovementReport
                    , IKEAConstants.CustomMaterialAttributeERPInventoryLocation
                    , IKEAConstants.CustomMaterialAttributeIsReportingBlocked
            });

            foreach (IMaterial material in pallets)
            {
                // Get Material ERP Original Name
                string erpOriginalName = material.GetAttributeValueOrDefault<string>(IKEAConstants.CustomMaterialAttributeERPOriginalName);

                //Get the Inventory Location on Material
                string materialInventoryLocation = material.GetAttributeValueOrDefault<string>(IKEAConstants.CustomMaterialAttributeERPInventoryLocation);

                bool? isERPReportBLocked = material.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomMaterialAttributeERPBlockedMovementReport) || material.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomMaterialAttributeIsReportingBlocked);

                // get new material location
                string newMaterialLocation = palletNewLocation.ContainsKey(material.Id) ? palletNewLocation[material.Id] : null;

                // Do not report a material that does not have a Material Inventory Location because it means it is ERP responsibility to move it into the location it is being moved to.
                // also do not report if blocked
                if (!string.IsNullOrWhiteSpace(materialInventoryLocation))
                {
                    //Only update if 
                    // > Material current Inventory Location is different than new Inventory Location and new inventory location defined
                    // > Material Form is NOT Order NOR batch
                    if (!String.Equals(material.Form, materialOrderForm, StringComparison.InvariantCultureIgnoreCase)
                        && !String.Equals(material.Form, materialBatchForm, StringComparison.InvariantCultureIgnoreCase)
                        && !String.IsNullOrWhiteSpace(newMaterialLocation)
                        && !String.Equals(newMaterialLocation, materialInventoryLocation, StringComparison.InvariantCultureIgnoreCase))
                    {
                        if (isToCreateIntegrationEntry)
                        {
                            // Get the default reject unit
                            string rejectUnit = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.ScrapManagementRejectUnit);

                            // Initiate the material quantity with the material primary quantity
                            decimal materialQuantity = (material.PrimaryQuantity.HasValue ? material.PrimaryQuantity.Value : 0);

                            // When the material secondary unit is Reject, it will also be added to the material quantity
                            if (material.SecondaryUnits.CompareStrings(rejectUnit))
                            {
                                materialQuantity += (material.SecondaryQuantity.HasValue ? material.SecondaryQuantity.Value : 0);
                            }

                            //Get Facility WareHouse Location attribute
                            string erpFacility = material.Facility.GetAttributeValueOrDefault<string>(IKEAConstants.CustomFaciltyAttributeERPWarehouseLocation, true);

                            string materialName = string.IsNullOrWhiteSpace(erpOriginalName) ? material.Name : erpOriginalName;

                            //if the material will be shipped
                            bool? isShipping = DeeContextHelper.GetContextParameter(IKEAConstants.CustomMaterialIsToShip) as bool?;
                            if (isShipping.HasValue && isShipping.Value)
                            {
                                material.LoadRelations(Navigo.Common.Constants.MaterialResource);
                                if (material.RelationCollection != null && material.RelationCollection.ContainsKey(Navigo.Common.Constants.MaterialResource))
                                {
                                    IResource materialCurrentResource = material.MaterialResourceRelations.Select(relation => relation.TargetEntity).FirstOrDefault();   // get Current Resource
                                    if (materialCurrentResource != null)
                                        _iKEAUtilities.RequestMaterialShipping(material.Facility, material, material.Product, materialCurrentResource, material.PrimaryQuantity.Value);

                                }
                                _deeContextUtilities.SetContextParameter(IKEAConstants.CustomMaterialIsToShip, false); // set Context to false
                                continue; //if is to ship do not report material movement IE
                            }

                            // Instantiate the object to be serialized
                            MaterialMovementCommunication materialMovementCommunication = new MaterialMovementCommunication
                            {
                                WarehouseLocation = erpFacility ?? String.Empty,
                                BaseProduct = material.Product.GetRelatedAttributeValueOrDefault<string>(IKEAConstants.CustomProductAttributeBaseProduct, true) ?? material.Product.Name,
                                ToERPInventoryLocation = newMaterialLocation,
                                MaterialQuantity = materialQuantity.ToString(),
                                FromERPInventoryLocation = materialInventoryLocation ?? String.Empty,
                                ProductionOrderName = String.Empty,
                                MaterialName = (isERPReportBLocked == null || isERPReportBLocked != true) ? materialName : String.Empty
                            };

                            // Get Json file
                            string json = JsonConvert.SerializeObject(materialMovementCommunication);

                            MESERPCommunication communication = new MESERPCommunication
                            {
                                API = IKEAConstants.ERPReportMaterialMovement,
                                Message = json
                            };

                            // Serialize the object to a XML Document
                            XmlDocument xmlDoc = XMLExtensions.SerializeToXMLDocument(communication);

                            // Create the Integration Entry
                            _iKEAUtilities.CreateIntegrationEntry(IKEAConstants.MESSystem,
                                                                IKEAConstants.ERPSystem,
                                                                IKEAConstants.ERPMaterialMovementMessageType,
                                                                IKEAConstants.ERPMaterialMovementEventName,
                                                                xmlDoc);
                        }
                    }
                }

                // always save the new inventory location if set. if not defined, storage location is not handled by ERP but when moving to a new one tracked by ERP the last known one must be used
                if (!String.IsNullOrWhiteSpace(newMaterialLocation))
                {
                    IAttributeCollection attributesToSave = new AttributeCollection();
                    attributesToSave.Add(IKEAConstants.CustomMaterialAttributeERPInventoryLocation, newMaterialLocation);
                    material.SaveAttributes(attributesToSave);
                }
            }
        }

        /// <summary>
        /// Retrieves all reportable forms
        /// </summary>
        /// <returns>ERP reportable forms</returns>
        public List<string> GetERPReportableForms()
        {
            List<string> reportableForms = new List<string>();

            // Gets the 'CustomERPReportableForms' lookup table to retrieve all reportable forms
            ILookupTable reportableFormsTable = new LookupTable();
            reportableFormsTable.Load(IKEAConstants.CustomERPReportableForms);

            if (!reportableFormsTable.Values.IsNullOrEmpty())
            {
                reportableForms = reportableFormsTable.Values.Select(e => e.Value).ToList();
            }

            return reportableForms;
        }

       
       

      

        
        /// <summary>
        /// Obtain ContextParameter Entity Name
        /// Returns String.Empty if contextParameter does not exists
        /// </summary>
        /// <param name="contextParameter">DeeContextParameter Name</param>
        /// <param name="materialName">Material.Name</param>
        /// <returns>Entity.Name</returns>
        public string GetMaterialRelatedEntityNameFromMaterial(string contextParameter, string materialName)
        {
            // Obtain contextParameter value
            Dictionary<IMaterial, string> materialEntityName = DeeContextHelper.GetContextParameter(contextParameter) as Dictionary<IMaterial, string>;

            // Return String.Empty if contextParameter does not exists
            if (materialEntityName == null || materialEntityName.Count == 0)
            {
                return String.Empty;
            }

            // Return ContextParameter
            string entityName = materialEntityName.Where(
                men => men.Key.Name == materialName
                ).FirstOrDefault().Value;

            return entityName;
        }
    }
}

