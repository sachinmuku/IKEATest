﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cmf.Common.CustomActionUtilities;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.ERP;
using Cmf.Custom.IKEA.Common.Exceptions;
using Cmf.Custom.IKEA.Common.Extensions.BOM;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Foundation.Common;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System.Data;
using Cmf.Foundation.BusinessObjects.QueryObject;

namespace Cmf.Custom.IKEA.Common.Utilities
{
    public class BOMUtilities : IBOMUtilities
    {
        private IEntityFactory _entityFactory;
        private IGenericUtilities _genericUtilities;

        [Microsoft.Extensions.DependencyInjection.ActivatorUtilitiesConstructor]
        public BOMUtilities(IEntityFactory entityFactory, IGenericUtilities genericUtilities)
        {
            _entityFactory = entityFactory;
            _genericUtilities = genericUtilities;
        }

        /// <summary>
        /// Get BOM Products from BOM Template
        /// </summary>
        /// <param name="productName">Product Name</param>
        /// <param name="erpBOMProducts">BOM Products coming from ERP</param>
        /// <param name="resources">Sub Resources of a Resource</param>
        /// <param name="facility">Facility</param>
        /// <param name="areaName">Resource Main Line</param>
        /// <param name="workCenter">Resource WorkCenter</param>
        /// <param name="resourceName">Main Line Name</param>
        /// <returns>Collection of BOM Products</returns>
        public CustomBOMProductInformationCollection GetBOMFromTemplate(string productName,
                                                                                List<ERPBOMProduct> erpBOMProducts,
                                                                                IResourceCollection resources,
                                                                                IFacility facility,
                                                                                IResource mainFeeder,
                                                                                string areaName = null,
                                                                                string workCenter = null,
                                                                                string resourceName = null,
                                                                                string orderType = null,
                                                                                string structureType = null)
        {
            CustomBOMProductInformationCollection bomProductInformations = new CustomBOMProductInformationCollection();
            List<ERPBOMProduct> aggregatedBOMProducts = new List<ERPBOMProduct>();

            // Resolves the BOM Template from the smart table CustomBOMTemplateHandler
            string template = ResolveCustomBOMTemplateHandler(productName,
                                                                facility.Name,
                                                                areaName,
                                                                workCenter,
                                                                resourceName,
                                                                orderType,
                                                                structureType);

            // Check if any template is configured
            if (!string.IsNullOrWhiteSpace(template))
            {
                // Get all the configured BOM Template details
                List<CustomBOMTemplateDetail> bomTemplateDetails = GetBOMTemplateDetails(template);

                // Check if there are any BOM template details configured
                if (!bomTemplateDetails.IsNullOrEmpty())
                {
                    int i = 1;

                    var resourcesDictionary = resources.ToDictionary(E => new { ProcessSegmentSequence = E.GetAttributeValueOrDefault<string>(IKEAConstants.ProcessSegmentSequence), SubProcessSegmentName = E.GetAttributeValueOrDefault<string>(IKEAConstants.SubProcessSegmentName) }, E => E);

                    // Get All products to be used in the BOM Products
                    IProductCollection products = _entityFactory.CreateCollection<IProductCollection>();
                    products.AddRange(erpBOMProducts.Select(E => E.Product).Distinct().Select(e =>
                    {
                        var product = _entityFactory.Create<IProduct>();
                        product.Name = e;
                        return product;
                    }));
                    products.Load();

                    ILookupTable ltUnits = new LookupTable();
                    ltUnits.Load("Units");
                    Dictionary<string, string> unitPossibleValues = ltUnits.Values.ToDictionary(E => E.Value.ToLower(), E => E.Value);

                    Dictionary<string, List<CustomBOMTemplateDetail>> detailsByProduct = bomTemplateDetails.GroupBy(E => E.Product).ToDictionary(E => E.Key, E => E.ToList());
                    Dictionary<string, List<ERPBOMProduct>> productBomProducts = erpBOMProducts.GroupBy(E => E.Product).ToDictionary(E => E.Key, E => E.ToList());

                    foreach (var productERPBOMProduct in productBomProducts)
                    {
                        ERPBOMProduct eRPBOMProduct = new ERPBOMProduct();
                        eRPBOMProduct.Clone(productERPBOMProduct.Value.First());
                        //Multiply for 1.0m to force cast to decimal
                        eRPBOMProduct.Quantity = productERPBOMProduct.Value.Sum(X => X.Quantity) * 1.0m;

                        aggregatedBOMProducts.Add(eRPBOMProduct);
                    }

                    // Go through all the BOM products coming from the ERP
                    foreach (ERPBOMProduct bomProduct in aggregatedBOMProducts)
                    {
                        // Get the defined product for the BOM product
                        IProduct product = products.First(p => p.Name == bomProduct.Product);

                        if (!bomProduct.IsReference)
                        {
                            // Check if there are any configuration for the specific product
                            if (detailsByProduct.ContainsKey(bomProduct.Product))
                            {

                                if (bomProduct.Quantity == 0)
                                {
                                    throw new IKEAException(IKEAConstants.CustomValidateBOMProductWithZeroQuantityLocalizedMessage, product.Name, bomProduct.ERPBOMOperationSequence.ToString());
                                }

                                decimal mainQuantity = bomProduct.Quantity;
                                decimal totalRatio = 1;
                                int decimalPlaces = (bomProduct.Quantity - Math.Truncate(bomProduct.Quantity)).ToString().Count() - 1;

                                foreach (CustomBOMTemplateDetail templateDetail in detailsByProduct[bomProduct.Product])
                                {
                                    // Create a resource key to easily access the resource dictionary
                                    var resourceKey = new { ProcessSegmentSequence = templateDetail.ProcessSegment, SubProcessSegmentName = templateDetail.SubProcessSegment };

                                    // Check if the configured resource exists
                                    if (resourcesDictionary.ContainsKey(resourceKey))
                                    {
                                        // Get the feeder by ProcessSegmentSequence and SubProcessSegmentName
                                        IResource resource = resourcesDictionary[resourceKey];

                                        // Calculate the quantity based on the ratio (this can the configured Ratio or the Numerator / Denominator)
                                        decimal quantity = Math.Round((templateDetail.Ratio * mainQuantity) / totalRatio, decimalPlaces);

                                        mainQuantity = mainQuantity - quantity;
                                        totalRatio = totalRatio - templateDetail.Ratio;

                                        IStep step = null;

                                        // If the BOM Product is not reference then it needs to get a step to use
                                        if (!bomProduct.IsReference)
                                        {
                                            // Get step to be used in the BOM Product
                                            step = _genericUtilities.ERPResolveStepForBOMProduct(product, facility, resource, workCenter);
                                        }

                                        // Check if custom assemble is to be used, if create the bom product with isReference set to true
                                        // and set the sourceStep to the current step
                                        System.IServiceProvider serviceProvider = ApplicationContext.CurrentServiceProvider;
                                        IEntityFactory entityFactory = serviceProvider.GetRequiredService<IEntityFactory>();

                                        IResource baseResource = entityFactory.Create<IResource>();
                                        baseResource.Name = resourceName;
                                        baseResource.Load();

                                        baseResource.LoadAttribute(IKEAConstants.CustomRoundOverProductionAndLossQuantity);
                                        CustomBOMProductInformation productInformation = null;
                                        if (baseResource.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomRoundOverProductionAndLossQuantity)
                                                && _genericUtilities.GetConfigurationValueByPath<bool>(IKEAConstants.CustomAssembleEnabled)
                                                && mainFeeder.Name == resource.Name
                                                && quantity < 1 && step != null)
                                        {
                                            // Create custom BOMProduct
                                            productInformation = new CustomBOMProductInformation()
                                            {
                                                Order = i,
                                                TargetEntity = product,
                                                IsReference = true,
                                                Quantity = quantity,
                                                Units = unitPossibleValues.ContainsKey(bomProduct.Units) ? unitPossibleValues[bomProduct.Units] : bomProduct.Units,
                                                Step = null,
                                                ProcessSegment = templateDetail.ProcessSegment,
                                                SubProcessSegment = templateDetail.SubProcessSegment,
                                                ERPBOMOperationSequence = bomProduct.ERPBOMOperationSequence.ToString(),
                                                IsByProductSegment = bomProduct.IsByProductSegment,
                                                SourceStep = step.Name
                                            };
                                        }
                                        else
                                        {
                                            // Create custom BOMProduct
                                            productInformation = new CustomBOMProductInformation()
                                            {
                                                Order = i,
                                                TargetEntity = product,
                                                IsReference = bomProduct.IsReference,
                                                Quantity = quantity,
                                                Units = unitPossibleValues.ContainsKey(bomProduct.Units) ? unitPossibleValues[bomProduct.Units] : bomProduct.Units,
                                                Step = step,
                                                ProcessSegment = templateDetail.ProcessSegment,
                                                SubProcessSegment = templateDetail.SubProcessSegment,
                                                ERPBOMOperationSequence = bomProduct.ERPBOMOperationSequence.ToString(),
                                                IsByProductSegment = bomProduct.IsByProductSegment,
                                                SourceStep = null
                                            };
                                        }

                                        bomProductInformations.Add(productInformation);
                                        i++;
                                    }
                                    else
                                    {
                                        throw new IKEAException(IKEAConstants.CustomValidateBOMSubResourceDoesNotExistLocalizedMessage, resourceName, templateDetail.ProcessSegment, templateDetail.SubProcessSegment);
                                    }
                                }
                            }
                        }
                        else
                        {
                            // Create custom BOMProduct
                            CustomBOMProductInformation productInformation = new CustomBOMProductInformation()
                            {
                                Order = i,
                                TargetEntity = product,
                                IsReference = bomProduct.IsReference,
                                Quantity = bomProduct.Quantity,
                                Units = unitPossibleValues.ContainsKey(bomProduct.Units) ? unitPossibleValues[bomProduct.Units] : bomProduct.Units,
                                Step = null,
                                ProcessSegment = null,
                                SubProcessSegment = null,
                                ERPBOMOperationSequence = bomProduct.ERPBOMOperationSequence.ToString(),
                                IsByProductSegment = bomProduct.IsByProductSegment,
                                SourceStep = null
                            };

                            bomProductInformations.Add(productInformation);
                            i++;
                        }
                    }
                }
                else
                {
                    throw new IKEAException(IKEAConstants.CustomValidateBOMTemplateDetailsMissingConfigurationLocalizedMessage, template);
                }

                // Validate if the _entityFactory.Create<IBOM>(); matches what comes from ERP
                if (!ValidateERPBOMProductsQuantities(aggregatedBOMProducts, bomProductInformations))
                {
                    throw new IKEAException(IKEAConstants.CustomValidateBOMMismatchBOMProductsLocalizedMessage, template);
                }

            }
            else
            {
                throw new IKEAException(IKEAConstants.CustomValidateBOMTemplateMissingConfigurationLocalizedMessage, productName);
            }

            return bomProductInformations;

        }

        /// <summary>
        /// Validate if the _entityFactory.Create<IBOM>(); matches what comes from ERP
        /// </summary>
        /// <param name="erpBOMProducts">BOM Products coming from ERP</param>
        /// <param name="bomProductInformations">BOM Products generated</param>
        /// <returns>True if the BOM products </returns>
        public bool ValidateERPBOMProductsQuantities(List<ERPBOMProduct> erpBOMProducts, CustomBOMProductInformationCollection bomProductInformations)
        {
            //Get a dictionary with the product and the sum of all quantities of that product
            Dictionary<string, decimal> generatedProductQuantities = bomProductInformations.GroupBy(E => E.TargetEntity.Name).ToDictionary(E => E.Key, E => E.Sum(X => X.Quantity.GetValueOrDefault()));
            Dictionary<string, decimal> erpProductQuantities = erpBOMProducts.GroupBy(E => E.Product).ToDictionary(E => E.Key, E => E.Sum(X => X.Quantity));

            foreach (var eRPBOMProduct in erpProductQuantities)
            {
                // If the product coming from ERP is not present in the new collection of BOM Products
                // Or the quantity for the product does not match, then the BOM is not valid
                if (!generatedProductQuantities.ContainsKey(eRPBOMProduct.Key)
                    || generatedProductQuantities[eRPBOMProduct.Key] != eRPBOMProduct.Value)
                {
                    return false;
                }
            }

            return true;
        }


        /// <summary>
        /// Get all the configured BOM Template details by template name
        /// </summary>
        /// <param name="templateName">Template Name</param>
        /// <returns>List of BOM Template details</returns>
        public List<CustomBOMTemplateDetail> GetBOMTemplateDetails(string templateName)
        {
            List<CustomBOMTemplateDetail> bomTemplateDetails = new List<CustomBOMTemplateDetail>();
            IFilterCollection filterCollection = new FilterCollection() {
                new Filter()
                {
                    Name = IKEAConstants.CustomBOMTemplateDetailsTemplate,
                    Operator = FieldOperator.IsEqualTo,
                    Value = templateName,
                    LogicalOperator = LogicalOperator.Nothing
                }
            };

            System.Data.DataSet result = TableHelper.GetDataFromGenericTable(IKEAConstants.CustomBOMTemplateDetailsGenericTable, filterCollection);
            if (result != null && result.HasData())
            {
                foreach (DataRow row in result.Tables[0].Rows)
                {
                    CustomBOMTemplateDetail bomTemplateDetail = new CustomBOMTemplateDetail();

                    bomTemplateDetail.Template = row.Field<string>(IKEAConstants.CustomBOMTemplateDetailsTemplate);
                    bomTemplateDetail.ProcessSegment = row.Field<string>(IKEAConstants.CustomBOMTemplateDetailsProcessSegment);
                    bomTemplateDetail.SubProcessSegment = row.Field<string>(IKEAConstants.CustomBOMTemplateDetailsSubProcessSegment);
                    bomTemplateDetail.Product = row.Field<string>(IKEAConstants.CustomBOMTemplateDetailsProduct);

                    decimal? ratio = row.Field<decimal?>(IKEAConstants.CustomBOMTemplateDetailsRatio);
                    if (ratio.HasValue)
                    {
                        bomTemplateDetail.Ratio = ratio.GetValueOrDefault();
                    }

                    bomTemplateDetail.Numerator = row.Field<int?>(IKEAConstants.CustomBOMTemplateDetailsNumerator);
                    bomTemplateDetail.Denominator = row.Field<int?>(IKEAConstants.CustomBOMTemplateDetailsDenominator);

                    bomTemplateDetails.Add(bomTemplateDetail);
                }
            }

            return bomTemplateDetails;
        }




        /// <summary>
        /// Resolves the BOM Template from the smart table CustomBOMTemplateHandler
        /// </summary>
        /// <param name="productName">Product Name</param>
        /// <param name="facilityName">Facility</param>
        /// <param name="areaName">Area</param>
        /// <param name="workCenter">WorkCenter</param>
        /// <param name="resourceName">Resource</param>
        /// <returns>Time Threshold, Role and DistributionList</returns>
        public string ResolveCustomBOMTemplateHandler(string productName,
                                                                string facilityName = null,
                                                                string areaName = null,
                                                                string workCenter = null,
                                                                string resourceName = null,
                                                                string orderType = null,
                                                                string structureType = null)
        {
            string template = null;

            Dictionary<string, string> nameAndValues = new Dictionary<string, string>();
            if (!string.IsNullOrEmpty(facilityName))
            {
                nameAndValues.Add(IKEAConstants.CustomBOMTemplateHandlerFacility, facilityName);
            }

            if (!string.IsNullOrEmpty(areaName))
            {
                nameAndValues.Add(IKEAConstants.CustomBOMTemplateHandlerArea, areaName);
            }

            if (!string.IsNullOrEmpty(workCenter))
            {
                nameAndValues.Add(IKEAConstants.CustomBOMTemplateHandlerWorkCenter, workCenter);
            }

            if (!string.IsNullOrEmpty(resourceName))
            {
                nameAndValues.Add(IKEAConstants.CustomBOMTemplateHandlerResource, resourceName);
            }

            if (!string.IsNullOrEmpty(orderType))
            {
                nameAndValues.Add(IKEAConstants.CustomBOMTemplateHandlerOrderType, orderType);
            }

            if (!string.IsNullOrEmpty(structureType))
            {
                nameAndValues.Add(IKEAConstants.CustomBOMTemplateHandlerStructureType, structureType);
            }

            if (!string.IsNullOrEmpty(productName))
            {
                nameAndValues.Add(IKEAConstants.CustomBOMTemplateHandlerProduct, productName);
            }

            System.Data.DataSet result = TableHelper.ResolveSmartTable(IKEAConstants.CustomBOMTemplateHandlerSmartTable, nameAndValues, true);

            //Validate if result returned no data or returned data without product specified
            if (!result.HasData() ||
                (string.IsNullOrWhiteSpace(result.Tables[0].Rows[0].Field<string>(IKEAConstants.CustomBOMTemplateHandlerProduct))) && !string.IsNullOrEmpty(productName))
            {
                IProduct prod = _entityFactory.Create<IProduct>();
                prod.Name = productName;
                prod.Load();

                nameAndValues[IKEAConstants.CustomBOMTemplateHandlerProduct] = prod.GetRelatedAttributeValueOrDefault<string>(IKEAConstants.CustomProductAttributeBaseProduct, true);
                result = TableHelper.ResolveSmartTable(IKEAConstants.CustomBOMTemplateHandlerSmartTable, nameAndValues, true);
            }


            if (result.HasData())
            {
                template = result.Tables[0].Rows[0].Field<string>(IKEAConstants.CustomBOMTemplateHandlerTemplate);
            }

            return template;
        }


    }
}