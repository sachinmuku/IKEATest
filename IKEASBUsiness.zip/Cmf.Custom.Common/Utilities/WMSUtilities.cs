﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Xml;
using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.BusinessObjects;
using Cmf.Custom.IKEA.BusinessObjects.Abstractions;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using Cmf.Custom.IKEA.Common.Exceptions;
using Cmf.Custom.IKEA.Common.Extensions;
using Cmf.Custom.IKEA.Common.WMS;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessObjects.GenericTables;
using Cmf.Foundation.BusinessObjects.QueryObject;
using Cmf.Foundation.BusinessOrchestration.Abstractions;
using Cmf.Foundation.BusinessOrchestration.DataPlatform;
using Cmf.Foundation.BusinessOrchestration.DataPlatform.Domain;
using Cmf.Foundation.BusinessOrchestration.DataPlatform.InputObjects;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Foundation.Common.Base;
using Cmf.Foundation.Common.LocalizationService;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.Abstractions;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects;
using DocumentFormat.OpenXml.Bibliography;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace Cmf.Custom.IKEA.Common.Utilities
{
    /// <summary>
    /// Utilities for handling WMS integration processes
    /// </summary>
    public class WMSUtilities : IWMSUtilities
    {
        private IEntityFactory _entityFactory;
        private IIKEAUtilities _iKEAUtilities;
        private IGenericUtilities _genericUtilities;
        private IMaterialOrchestration _materialOrchestration;
        private IDeeContextUtilities _deeContextUtilities;
        private IAlarmHandlingUtilities _alarmHandlingUtilities;
        private IAutomaticMaterialCreationUtilities _automaticMaterialCreationUtilities;
        private IDataPlatformManagementOrchestration _dataPlatformOrchestration;

        [Microsoft.Extensions.DependencyInjection.ActivatorUtilitiesConstructor]
        public WMSUtilities(IEntityFactory entityFactory,
            IGenericUtilities genericUtilities,
            IIKEAUtilities iKEAUtilities,
            IDeeContextUtilities deeContextUtilities,
            IAlarmHandlingUtilities alarmHandlingUtilities,
            IAutomaticMaterialCreationUtilities automaticMaterialCreationUtilities,
            IDataPlatformManagementOrchestration dataPlatformOrchestration
            )
        {
            _entityFactory = entityFactory;
            _genericUtilities = genericUtilities;
            _iKEAUtilities = iKEAUtilities;
            _deeContextUtilities = deeContextUtilities;
            _alarmHandlingUtilities = alarmHandlingUtilities;
            _automaticMaterialCreationUtilities = automaticMaterialCreationUtilities;
            _dataPlatformOrchestration = dataPlatformOrchestration;
            
        }
        /// <summary>
        /// Get the CustomWMSMaterialTrackers for the specified column (of type string) value
        /// </summary>
        /// <param name="filterColumnValue"></param>
        /// <returns>CustomMaterialReplenishmentRequestTrackerCollection</returns>
        public ICustomWMSMaterialTrackerCollection GetCustomWMSMaterialTrackers(IMaterial material, bool includeTerminated = false)
        {
            string materialOrderForm = _iKEAUtilities.GetOrderMaterialForm();

            string fieldName;

            // Choose which field to use when searching for trackers based on the Form of the Material.
            // Manufacturing Orders have trackers of type Feed, and their name is stored in the property ManufacturingOrder
            // Pallets, Consumables and others have trackers of type PutAway, Move, and their names are stored in the property PalletName
            if (string.Equals(material.Form, materialOrderForm, StringComparison.InvariantCultureIgnoreCase))
            {
                fieldName = nameof(CustomWMSMaterialTracker.ManufacturingOrder);
            }
            else
            {
                fieldName = nameof(CustomWMSMaterialTracker.PalletName);
            }

            return GetCustomWMSMaterialTrackers(material.Name, fieldName, includeTerminated);
        }

        /// <summary>
        /// Get the CustomWMSMaterialTrackers for the specified column (of type string) value
        /// </summary>
        /// <param name="filterColumnValue"></param>
        /// <returns>CustomMaterialReplenishmentRequestTrackerCollection</returns>
        public ICustomWMSMaterialTrackerCollection GetCustomWMSMaterialTrackers(string filterColumnValue, string filterColumnName = nameof(CustomWMSMaterialTracker.PalletName), bool includeTerminated = false)
        {
            return GetCustomWMSMaterialTrackers(new Filter()
            {
                Name = filterColumnName,
                ObjectName = "CustomWMSMaterialTracker",
                ObjectAlias = "CustomWMSMaterialTracker_1",
                Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                Value = filterColumnValue,
                LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND,
                FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
            }, includeTerminated);
        }

        /// <summary>
        /// Get the CustomWMSMaterialTrackers for the specified WMS Inventory Order ID
        /// </summary>
        /// <param name="inventoryOrderId"></param>
        /// <returns>CustomMaterialReplenishmentRequestTrackerCollection</returns>
        public ICustomWMSMaterialTrackerCollection GetCustomWMSMaterialTrackers(long inventoryOrderId, string filterColumnName = "InventoryOrderId", bool includeTerminated = false)
        {
            return GetCustomWMSMaterialTrackers(new List<long> { inventoryOrderId }, filterColumnName, includeTerminated);

        }

        /// <summary>
        /// Get the CustomWMSMaterialTrackers for the specified WMS Inventory Order IDs
        /// </summary>
        /// <param name="inventoryOrderIds">The list of WMS Inventory Order IDs</param>
        /// <returns>CustomMaterialReplenishmentRequestTrackerCollection</returns>
        public ICustomWMSMaterialTrackerCollection GetCustomWMSMaterialTrackers(IEnumerable<long> inventoryOrderIds, string filterColumnName = "InventoryOrderId", bool includeTerminated = false)
        {
            return GetCustomWMSMaterialTrackers(new Filter()
            {
                Name = filterColumnName,
                ObjectName = "CustomWMSMaterialTracker",
                ObjectAlias = "CustomWMSMaterialTracker_1",
                Operator = Cmf.Foundation.Common.FieldOperator.In,
                Value = inventoryOrderIds,
                LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND,
                FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
            }, includeTerminated);
        }

        /// <summary>
        /// Get the CustomWMSMaterialTrackers for the filter
        /// </summary>
        /// <param name="filter"></param>
        /// <returns>CustomMaterialReplenishmentRequestTrackerCollection</returns>
        public ICustomWMSMaterialTrackerCollection GetCustomWMSMaterialTrackers(IFilter filter, bool includeTerminated = false)
        {
            ICustomWMSMaterialTrackerCollection requestTrackers = _entityFactory.CreateCollection<ICustomWMSMaterialTrackerCollection>();

            IQueryObject query = new QueryObject();
            query.Description = "";
            query.EntityTypeName = "CustomWMSMaterialTracker";
            query.Name = "GetTracker";
            query.Query = new Query();
            query.Query.Distinct = false;
            query.Query.Filters = new FilterCollection() { filter };
            if (includeTerminated == false)
            {
                query.Query.Filters.Add(new Filter()
                {
                    Name = "UniversalState",
                    ObjectName = "CustomWMSMaterialTracker",
                    ObjectAlias = "CustomWMSMaterialTracker_1",
                    Operator = Cmf.Foundation.Common.FieldOperator.IsNotEqualTo,
                    Value = 4,
                    LogicalOperator = Cmf.Foundation.Common.LogicalOperator.Nothing,
                    FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                });
            }

            query.Query.Fields = new FieldCollection() {
                new Field()
                {
                    Alias = "Id",
                    ObjectName = "CustomWMSMaterialTracker",
                    ObjectAlias = "CustomWMSMaterialTracker_1",
                    IsUserAttribute = false,
                    Name = "Id",
                    Position = 0,
                    Sort = Cmf.Foundation.Common.FieldSort.NoSort
                },
                new Field()
                {
                    Alias = "Name",
                    ObjectName = "CustomWMSMaterialTracker",
                    ObjectAlias = "CustomWMSMaterialTracker_1",
                    IsUserAttribute = false,
                    Name = "Name",
                    Position = 1,
                    Sort = Cmf.Foundation.Common.FieldSort.NoSort
                }
            };
            query.Query.Relations = new RelationCollection();

            DataSet resultDataSet = query.Execute(false, new QueryParameterCollection());

            if (resultDataSet.HasData())
            {
                requestTrackers = _entityFactory.CreateCollection<ICustomWMSMaterialTrackerCollection>();

                foreach (DataRow requestTrackerRow in resultDataSet.Tables[0].Rows)
                {
                    var customWMSMaterialTracker = _entityFactory.Create<ICustomWMSMaterialTracker>();
                    customWMSMaterialTracker.Name = requestTrackerRow.Field<string>("Name");
                    requestTrackers.Add(customWMSMaterialTracker);
                }

                if (!requestTrackers.IsNullOrEmpty())
                {
                    requestTrackers.Load();
                }
            }
            return requestTrackers;
        }

        /// <summary>
        /// Get the CustomWMSMaterialTrackers for the filter
        /// </summary>
        /// <param name="filter"></param>
        /// <returns>CustomMaterialReplenishmentRequestTrackerCollection</returns>
        public ICustomWMSMaterialTrackerCollection GetCustomWMSMaterialTrackers(IFilterCollection filters, bool includeTerminated = false)
        {
            ICustomWMSMaterialTrackerCollection requestTrackers = _entityFactory.CreateCollection<ICustomWMSMaterialTrackerCollection>();

            IQueryObject query = new QueryObject();
            query.Description = "";
            query.EntityTypeName = "CustomWMSMaterialTracker";
            query.Name = "GetTracker";
            query.Query = new Query();
            query.Query.Distinct = false;
            query.Query.Filters = filters;
            if (includeTerminated == false)
            {
                query.Query.Filters.Add(new Filter()
                {
                    Name = "UniversalState",
                    ObjectName = "CustomWMSMaterialTracker",
                    ObjectAlias = "CustomWMSMaterialTracker_1",
                    Operator = Cmf.Foundation.Common.FieldOperator.IsNotEqualTo,
                    Value = 4,
                    LogicalOperator = Cmf.Foundation.Common.LogicalOperator.Nothing,
                    FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                });
            }

            query.Query.Fields = new FieldCollection() {
                new Field()
                {
                    Alias = "Id",
                    ObjectName = "CustomWMSMaterialTracker",
                    ObjectAlias = "CustomWMSMaterialTracker_1",
                    IsUserAttribute = false,
                    Name = "Id",
                    Position = 0,
                    Sort = Cmf.Foundation.Common.FieldSort.NoSort
                },
                new Field()
                {
                    Alias = "Name",
                    ObjectName = "CustomWMSMaterialTracker",
                    ObjectAlias = "CustomWMSMaterialTracker_1",
                    IsUserAttribute = false,
                    Name = "Name",
                    Position = 1,
                    Sort = Cmf.Foundation.Common.FieldSort.NoSort
                }
            };
            query.Query.Relations = new RelationCollection();

            DataSet resultDataSet = query.Execute(false, new QueryParameterCollection());

            if (resultDataSet.HasData())
            {
                requestTrackers = _entityFactory.CreateCollection<ICustomWMSMaterialTrackerCollection>();

                foreach (DataRow requestTrackerRow in resultDataSet.Tables[0].Rows)
                {
                    var customWMSMaterialTracker = _entityFactory.Create<ICustomWMSMaterialTracker>();
                    customWMSMaterialTracker.Name = requestTrackerRow.Field<string>("Name");
                    requestTrackers.Add(customWMSMaterialTracker);
                }

                if (!requestTrackers.IsNullOrEmpty())
                {
                    requestTrackers.Load();
                }
            }
            return requestTrackers;
        }

        /// <summary>
        /// Method that returns the latest CustomWMSMaterialTracker. If there are any active trackers, returns the first one of those. Otherwise,
        /// just returns the latest (by CreatedOn date) inactive tracker (the ones with UniversalState Terminated)
        /// </summary>
        /// <param name="factoryAutomationJobId"></param>
        /// <returns></returns>
        public ICustomWMSMaterialTracker GetJobLatestCustomWMSMaterialTracker(string factoryAutomationJobId, bool includeTerminated = false)
        {
            long automationJobId;

            if (!long.TryParse(factoryAutomationJobId, out automationJobId))
            {
                return null;
            }

            var trackers = GetCustomWMSMaterialTrackers(
                automationJobId,
                filterColumnName: "FactoryAutomationJobId",
                includeTerminated: includeTerminated
            );

            if (trackers?.Any() ?? false)
            {
                var activeTracker = trackers
                    .Where(tracker => tracker.UniversalState != Foundation.Common.Base.UniversalState.Terminated)
                    .FirstOrDefault();

                // If there is any active tracker, return that one
                if (activeTracker != null)
                {
                    return activeTracker;
                }

                // When there are no active trackers, then return the most recent one from the terminated list
                return trackers.MaxBy(tracker => tracker.CreatedOn);
            }

            return null;
        }

        /// <summary>
        /// Creates a material in MES deliverered from WMS
        /// </summary>
        /// <param name="wmsMessage"></param>
        /// <param name="errorDetails"></param>
        /// <param name="resourceName"></param>
        /// <param name="productionOrderName"></param>
        /// <returns></returns>
        public IMaterial CreateMaterialFromWMS(IWMSIntegrationMessage wmsMessage, out List<string> errorDetails, string resourceName, string productionOrderName = null)
        {
            errorDetails = new List<string>();

            //Get configurations.
            string materialForm = _iKEAUtilities.GetValueFromConfigurationWithPath(IKEAConstants.AutomaticMaterialCreationDefaultForm);
            string materialType = _iKEAUtilities.GetValueFromConfigurationWithPath(IKEAConstants.AutomaticMaterialCreationDefaultType);
            if (materialForm.IsNullOrEmpty() || materialType.IsNullOrEmpty())
            {
                throw new IKEAException(IKEAConstants.CustomAutoMaterialCreationInvalidConfiguration, IKEAConstants.AutomaticDurableCreationDefaultForm, IKEAConstants.AutomaticDurableCreationDefaultType);
            }

            IMaterial newMaterial = null;

            //Check if the indicated product exists in MES:
            string lastProductRevision = _iKEAUtilities.GetLatestRevisionForBaseProduct(wmsMessage.ItemID)?.Name ?? wmsMessage.ItemID;
            IProduct product = _entityFactory.Create<IProduct>();
            product.Name = lastProductRevision;
            if (product.ObjectExists())
            {

                //Check if the product has DefaultUnits:
                product.Load();
                if (product.DefaultUnits == null)
                {
                    throw new IKEAException(IKEAConstants.CustomAutoMaterialCreationInvalidProductDefaultUnits, product.Name);
                }


                IProductionOrder productionOrder = null;
                if (!string.IsNullOrWhiteSpace(productionOrderName))
                {
                    productionOrder = _entityFactory.Create<IProductionOrder>();
                    productionOrder.Name = productionOrderName;
                    if (!productionOrder.ObjectExists())
                    {
                        productionOrder = null;
                    }
                }

                IResource resource = _entityFactory.Create<IResource>(); resource.Name = resourceName;
                if (resource.ObjectExists())
                {
                    // Get ConsumptionFlowPath and FlowPath from smarttable       
                    resource.Load();
                    string productflowpath = _genericUtilities.ResolveAllMaterialFlows(resource.Area.Facility, product, resource, materialType, null)?.Item2;
                    if (productflowpath.IsNullOrEmpty())
                    {
                        if (product.FlowPath.IsNullOrEmpty())
                        {
                            throw new IKEAException(IKEAConstants.CustomWMSMaterialCreationFlowPathNotFoundLocalizedMessage, resource.Name, resource.Area.Facility.Name, product.Name);
                        }
                        else
                        {
                            productflowpath = product.FlowPath;
                        }
                    }


                    // Set the material properties:
                    newMaterial = _entityFactory.Create<IMaterial>();
                    newMaterial.PrimaryQuantity = wmsMessage.PalletQuantity;
                    newMaterial.PrimaryUnits = product.DefaultUnits;
                    newMaterial.FlowPath = productflowpath;
                    newMaterial.Product = product;
                    newMaterial.Type = materialType;
                    newMaterial.Form = materialForm;
                    newMaterial.Facility = resource.Area.Facility;
                    newMaterial.Description = wmsMessage.ItemName;
                    newMaterial.Flow = _genericUtilities.GetFlowsInFlowPath(productflowpath).FirstOrDefault();
                    newMaterial.Step = _genericUtilities.GetStepByFlowPath(productflowpath);
                    newMaterial.ProductionOrder = productionOrder;

                    // Fill attributes for the material:
                    resource.Area.Load();
                    string inventoryLocation = resource.GetTopMostResource().GetAttributeValueOrDefault<string>(IKEAConstants.CustomResourceAttributeInventoryLocation, true);
                    newMaterial.Attributes[IKEAConstants.CustomWMSInventoryOrderId] = wmsMessage.IOID;
                    newMaterial.Attributes[IKEAConstants.CustomMaterialAttributeERPOriginalName] = wmsMessage.BatchID;
                    newMaterial.Attributes[IKEAConstants.CustomMaterialAttributeBaseMaterial] = wmsMessage.BatchID;
                    newMaterial.Attributes[IKEAConstants.CustomMaterialAttributeERPInventoryLocation] = inventoryLocation;
                    newMaterial.Attributes[IKEAConstants.CustomMaterialAttributeCreationArea] = resource.Area.Name;

                    // Set Batch for the material
                    if (!string.IsNullOrWhiteSpace(wmsMessage.BatchID))
                    {
                        _automaticMaterialCreationUtilities.SetMaterialBatch(wmsMessage.BatchID, ref newMaterial);
                    }

                    // Set the material name
                    if (!string.IsNullOrWhiteSpace(wmsMessage.PalletID))
                    {
                        IMaterial material = _entityFactory.Create<IMaterial>();
                        material.Name = wmsMessage.PalletID;
                        ;
                        if (material.ObjectExists())
                        {
                            // Generate a name for this material based on the original one:
                            string nameGeneratorToUse = _iKEAUtilities.GetMaterialNameGenerator(materialForm);
                            if (string.IsNullOrWhiteSpace(nameGeneratorToUse))
                            {
                                nameGeneratorToUse = IKEAConstants.DefaultMaterialNameGenerator;
                            }
                            newMaterial.Name = GenerateNameForExistingMaterial(newMaterial, wmsMessage.BatchID, nameGeneratorToUse);

                            // Save the original material name in attribute:
                            material.Load();
                            string originalMaterial = material.GetAttributeValueOrDefault<string>(IKEAConstants.CustomWMSOriginalMaterial, true);
                            newMaterial.Attributes[IKEAConstants.CustomWMSOriginalMaterial] = originalMaterial.IsNullOrEmpty() ? wmsMessage.PalletID : originalMaterial;
                        }
                        else
                        {
                            newMaterial.Name = wmsMessage.PalletID;
                        }
                    }
                    else
                    {
                        // Generate a name for the material:
                        string nameGeneratorToUse = _iKEAUtilities.GetMaterialNameGenerator(materialForm);
                        if (string.IsNullOrWhiteSpace(nameGeneratorToUse))
                        {
                            nameGeneratorToUse = IKEAConstants.DefaultMaterialNameGenerator;
                        }
                        var materialNameGenerator = _entityFactory.Create<INameGenerator>();
                        newMaterial.Name = materialNameGenerator.GenerateName(nameGeneratorToUse, newMaterial);
                    }
                    newMaterial.Create();
                    // Create the material:                    
                    //var output = _materialOrchestration.CreateMaterial(new CreateMaterialInput() { Material = newMaterial });
                    //newMaterial = output.Material;
                }
                else
                {
                    errorDetails.Add(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomWMSMaterialCreationResourceNotFoundLocalizedMessage, resource.Name));
                }
            }
            else
            {
                errorDetails.Add(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomWMSMaterialCreationProductNotFoundLocalizedMessage, product.Name));
            }

            return newMaterial;
        }


        /// <summary>
        /// Method for updating a material coming from the WMS
        /// </summary>
        /// <param name="wmsMessage"></param>
        /// <param name="errorDetails"></param>
        /// <param name="resourceName"></param>
        /// <param name="productionOrderName"></param>
        /// <returns></returns>
        public IMaterial UpdateMaterialFromWMS(IWMSIntegrationMessage wmsMessage, out List<string> errorDetails, string resourceName = "", string productionOrderName = null)
        {
            errorDetails = new List<string>();

            IMaterial material = _entityFactory.Create<IMaterial>();
            material.Name = wmsMessage.PalletID;
            material.Load();
            material.Product.Load();

            IResource resource = _entityFactory.Create<IResource>();
            resource.Name = resourceName;
            resource.Load();

            // Call this method to Detach if already attached & ChangeFlowAndStep if necessary
            _iKEAUtilities.ApplyOperationActions(material, resource, IKEAConstants.WMSDetach);

            // Check material state:
            if (material.SystemState != MaterialSystemState.Queued)
            {
                errorDetails.Add(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomWMSMaterialUpdateNotAllowedStateLocalizedMessage, material.SystemState.ToString()));
            }
            else
            {
                // Update Quantity
                if (material.PrimaryQuantity != wmsMessage.PalletQuantity)
                {
                    material.ChangeQuantity(wmsMessage.PalletQuantity, material.SecondaryQuantity, null, null, null);
                }
            }

            return material;
        }

        /// <summary>
        /// Method to build a WMS Order Request message
        /// </summary>
        /// <param name="type"></param>
        /// <param name="productName"></param>
        /// <param name="materialName"></param>
        /// <param name="productionOrderName"></param>
        /// <param name="feedQuantity"></param>
        /// <param name="sourceResourceName"></param>
        /// <param name="destinationResourceName"></param>
        /// <param name="wmsIOID"></param>
        /// <param name="batchID"></param>
        /// <param name="palletID"></param>
        /// <param name="status"></param>
        /// <returns></returns>
        public WMSIntegrationMessage CreateWMSOrderRequestMessage(CustomWMSOrderRequestType type,
                                                                         string productName = null,
                                                                         string materialName = null,
                                                                         string productionOrderName = null,
                                                                         decimal? feedQuantity = null,
                                                                         string sourceResourceName = null,
                                                                         string destinationResourceName = null,
                                                                         long? wmsIOID = null,
                                                                         string batchID = null,
                                                                         string palletID = null,
                                                                         string status = null)
        {
            WMSIntegrationMessage requestMessage = null;
            bool StartTimeConfigValue = _genericUtilities.GetConfigurationValueByPath<bool>(IKEAConstants.StartTimeTakenAsCurrentTimeInWMSOrderRequestEnable);
            // Fill in the correct fields according the selected type:
            switch (type)
            {
                case CustomWMSOrderRequestType.Feed:

                    // Validate request quantity:
                    if (feedQuantity.HasValue && feedQuantity.Value > 0)
                    {
                        DateTime? startTime = DateTime.Now;
                        if (StartTimeConfigValue == true)
                        {
                            startTime = DateTime.Now;
                        }
                        else
                        {
                            if (!String.IsNullOrEmpty(productionOrderName))
                            {
                                IProductionOrder productionOrder = _entityFactory.Create<IProductionOrder>();
                                productionOrder.Name = productionOrderName;
                                productionOrder.Load();

                                if (productionOrder.PlannedStartDate != null)
                                {
                                    startTime = productionOrder.PlannedStartDate;
                                }
                            }
                        }


                        IProduct product = _entityFactory.Create<IProduct>();
                        product.Name = productName;
                        product.Load();

                        // Send DateTime objects in UTC
                        requestMessage = new WMSIntegrationMessage()
                        {
                            IOType = type,
                            ItemID = product.GetBaseProduct().Name,
                            ItemName = product.Description,
                            Destination = destinationResourceName,
                            Quantity = feedQuantity.Value,
                            StartTime = startTime.Value.ToUniversalTime(),
                            PalletID = palletID,
                            BatchID = batchID,
                            Status = Convert.ToInt32(status),
                            ManufacturingOrderName = productionOrderName
                        };
                    }
                    break;

                case CustomWMSOrderRequestType.PutAway:

                    // Validate the source resource:
                    if (!string.IsNullOrWhiteSpace(sourceResourceName))
                    {
                        IMaterial material = _entityFactory.Create<IMaterial>();
                        material.Name = materialName;
                        material.Load();
                        material.Product.Load();
                        // Send DateTime objects in UTC
                        requestMessage = new WMSIntegrationMessage()
                        {
                            IOType = type,
                            ItemID = material.Product.GetBaseProduct().Name,
                            ItemName = material.Product.Description,
                            PalletID = material.Name,
                            Source = sourceResourceName,
                            PalletQuantity = material.PrimaryQuantity.Value,
                            BatchID = material.GetOrderMaterialName(),
                            SeasoningTime = (GetMaterialSeasoningTime(material) ?? DateTime.Now).ToUniversalTime(),
                            Status = GetWMSStatus(material.Type)
                        };
                    }
                    break;

                case CustomWMSOrderRequestType.Move:

                    // Validate source and destination resources:
                    if (!string.IsNullOrWhiteSpace(sourceResourceName) && !string.IsNullOrWhiteSpace(destinationResourceName))
                    {
                        IMaterial material = _entityFactory.Create<IMaterial>();
                        material.Name = materialName;
                        material.Load();
                        material.Product.Load();

                        // Send DateTime objects in UTC
                        requestMessage = new WMSIntegrationMessage()
                        {
                            IOType = type,
                            ItemID = material.Product.GetBaseProduct().Name,
                            ItemName = material.Product.Description,
                            PalletID = material.Name,
                            Source = sourceResourceName,
                            Destination = destinationResourceName,
                            PalletQuantity = material.PrimaryQuantity.Value,
                            BatchID = material.GetOrderMaterialName(),
                            SeasoningTime = (GetMaterialSeasoningTime(material) ?? DateTime.Now).ToUniversalTime(),
                            Status = GetWMSStatus(material.Type)
                        };
                    }
                    break;

                case CustomWMSOrderRequestType.Cancel:

                    // Validate te IOID:
                    if (wmsIOID.HasValue && wmsIOID.Value > 0)
                    {
                        requestMessage = new WMSIntegrationMessage()
                        {
                            IOType = type,
                            IOID = wmsIOID.Value
                        };
                    }
                    break;

                case CustomWMSOrderRequestType.None:
                default:
                    break;
            }
            return requestMessage;
        }

        /// <summary>
        /// Method to build a WMS Set Pallet Status Message
        /// </summary>
        /// <param name="material"></param>
        /// <returns></returns>
        public WMSIntegrationMessage CreateSetPalletStatusMessage(IMaterial material)
        {
            return new WMSIntegrationMessage
            {
                PalletID = material.Name,
                Status = GetWMSStatus(material.Type),
            };
        }

        /// <summary>
        /// Method to get a MES status from WMS status in generic table
        /// </summary>
        /// <param name="mesStatus"></param>
        /// <returns></returns>
        public string GetMESStatus(int wmsStatus)
        {
            string mesStatus = String.Empty;

            IGenericTable materialTypeMappingTable = new GenericTable();
            materialTypeMappingTable.Load(IKEAConstants.CustomWMSMaterialTypeMappingGenericTable);

            IFilterCollection MaterialTypeMappingFilters = new FilterCollection()
            {
                new Filter()
                {
                    Name = IKEAConstants.CustomWMSMaterialTypeMappingGenericTableWMSStatus,
                    Value = wmsStatus,
                    Operator = Foundation.Common.FieldOperator.IsEqualTo
                }
            };

            materialTypeMappingTable.LoadData(MaterialTypeMappingFilters);

            if (materialTypeMappingTable.HasData)
            {
                DataRow dataRow = NgpDataSet.ToDataSet(materialTypeMappingTable.Data).Tables[0].Rows[0];

                mesStatus = dataRow.Field<string>(IKEAConstants.CustomWMSMaterialTypeMappingGenericTableMESStatus);
            }
            else
            {
                throw new IKEAException(IKEAConstants.CustomWMSMaterialStatusMappingNotFoundLocalizedMessage, IKEAConstants.CustomWMSMaterialTypeMappingGenericTable, wmsStatus);
            }
            return mesStatus;
        }

        /// <summary>
        /// Method to get a WMS status from MES status in generic table
        /// </summary>
        /// <param name="wmsStatus"></param>
        /// <returns></returns>
        public int GetWMSStatus(string mesStatus)
        {
            int wmsStatus = -1;

            IGenericTable materialTypeMappingTable = new GenericTable();
            materialTypeMappingTable.Load(IKEAConstants.CustomWMSMaterialTypeMappingGenericTable);

            IFilterCollection MaterialTypeMappingFilters = new FilterCollection()
            {
                new Filter()
                {
                    Name = IKEAConstants.CustomWMSMaterialTypeMappingGenericTableMESStatus,
                    Value = mesStatus,
                    Operator = Foundation.Common.FieldOperator.IsEqualTo
                }
            };

            materialTypeMappingTable.LoadData(MaterialTypeMappingFilters);

            if (materialTypeMappingTable.HasData)
            {
                DataRow dataRow = NgpDataSet.ToDataSet(materialTypeMappingTable.Data).Tables[0].Rows[0];

                wmsStatus = dataRow.Field<int>(IKEAConstants.CustomWMSMaterialTypeMappingGenericTableWMSStatus);
            }
            return wmsStatus;
        }


        /// <summary>
        /// Sends a GetPalletStatus message to WMS synchronously and returns it's response
        /// </summary>
        /// <param name="material"></param>
        /// <returns></returns>
        public WMSIntegrationMessage SendGetPalletStatusMessageSync(IMaterial material)
        {
            string config = IKEAConstants.WMSEndPoint + IKEAConstants.WMSGetPalletStatusEndpoint;
            string endPoint = _genericUtilities.GetConfigurationValueByPath<string>(config) + "/" + material.Name;

            WMSIntegrationMessage wmsResponse;

            if (endPoint.IsNullOrEmpty())
            {
                throw new IKEAException(IKEAConstants.CustomWMSMissingEndpointConfigLocalizedMessage, config);
            }

            // GetPalletStatus requests have an empty body
            wmsResponse = SendWMSMessageWithIntegrationEntry(null, endPoint, HttpMethod.Get);
            if (wmsResponse.Response == CustomWMSOrderResponseType.Rejected)
            {
                throw _iKEAUtilities.LocalizedException(IKEAConstants.CustomWMSExceptionLocalizedMessage, wmsResponse.Details);
            }

            return wmsResponse;
        }

        /// <summary>
        /// Creates an integration entry for sending an Order request to WMS Endpoint
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public IIntegrationEntry CreateWMSIntegrationEntry(WMSIntegrationMessage request, string requestEndpoint, string requestType = IKEAConstants.WMSOrderRequestMessageType, string eventName = IKEAConstants.WMSOrderRequestEventName, string factoryAutomationJobId = null, string? description = null)
        {
            string jsonMessage = JsonConvert.SerializeObject(request, Newtonsoft.Json.Formatting.Indented);

            MESWMSCommunication communication = new MESWMSCommunication()
            {
                API = requestEndpoint,
                Message = jsonMessage,
                FactoryAutomationJobId = factoryAutomationJobId
            };

            XmlDocument xmlDoc = communication.SerializeToXMLDocument();

            return _iKEAUtilities.CreateIntegrationEntry(IKEAConstants.MESSystem, IKEAConstants.WMSSystem, requestType, eventName, xmlDoc, description: description, message: description);
        }

        /// <summary>
        /// Send a message to FactoryAutomation
        /// </summary>
        /// <param name="inventoryOrderId"></param>
        /// <param name="requestType"></param>
        public string SendRequestToFactoryAutomation(long inventoryOrderId, string requestType, bool isFromWMS = false)
        {
            string resourceName = !String.IsNullOrWhiteSpace(_genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.FactoryAutomationWMSHandler)) ?
                            _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.FactoryAutomationWMSHandler) : "FactoryAutomationWMSHandler";

            // Load dummy resource that contains the controller:
            IResource factoryAutomationResource = _entityFactory.Create<IResource>();
            factoryAutomationResource.Name = resourceName;
            if (!factoryAutomationResource.ObjectExists())
            {
                throw new IKEAException(IKEAConstants.CustomWMSFactoryAutomationInvalidResourceLocalizedMessage, resourceName);
            }
            factoryAutomationResource.Load();

            // Get the automation controller:
            IAutomationControllerInstance controllerInstance = factoryAutomationResource.GetAutomationControllerInstance();
            if (controllerInstance == null)
            {
                throw new IKEAException(IKEAConstants.CustomWMSFactoryAutomationInvalidResourceControllerLocalizedMessage, resourceName);
            }

            return SendRequestToFactoryAutomation(controllerInstance, inventoryOrderId, requestType, isFromWMS);
        }

        /// <summary>
        /// Send a message to FactoryAutomation
        /// </summary>
        /// <param name="inventoryOrderId"></param>
        /// <param name="requestType"></param>
        public string SendRequestToFactoryAutomation(IAutomationControllerInstance controllerInstance, long inventoryOrderId, string requestType, bool isFromWMS = false)
        {
            string factoryAutomationResponseMessage = null;

            // Create the data objet to send:
            object requestData = new { IOID = inventoryOrderId, IsFromWMS = isFromWMS };

            // Send request:
            var factoryAutomationResponse = _genericUtilities.RequestFromIoT<Dictionary<string,string>>(controllerInstance, requestType, requestData);

            // Validate if FA accepted the request:
            if (factoryAutomationResponse != null && factoryAutomationResponse.ContainsKey(IKEAConstants.AutomationRequestReplyField))
            {
                string attachResponseCode = null;
                factoryAutomationResponse.TryGetValue(IKEAConstants.AutomationRequestReplyField, out attachResponseCode);

                if (attachResponseCode is string && !string.IsNullOrWhiteSpace((string)attachResponseCode))
                {
                    factoryAutomationResponseMessage = (string)attachResponseCode;
                }
            }

            return factoryAutomationResponseMessage;
        }

        /// <summary>
        /// Sends a batch of requests to the IoT controller
        /// </summary>
        /// <param name="inventoryOrderIdsList"></param>
        /// <param name="requestType"></param>
        /// <returns></returns>
        public Dictionary<long, string> SendRequestToFactoryAutomation(IEnumerable<long> inventoryOrderIdsList, string requestType)
        {
            Dictionary<long, string> errorsByOrderId = new Dictionary<long, string>();

            string resourceName = !string.IsNullOrWhiteSpace(_genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.FactoryAutomationWMSHandler)) ?
                            _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.FactoryAutomationWMSHandler) : "FactoryAutomationWMSHandler";

            // Load dummy resource that contains the controller:
            IResource factoryAutomationResource = _entityFactory.Create<IResource>();
            factoryAutomationResource.Name = resourceName;
            if (!factoryAutomationResource.ObjectExists())
            {
                throw new IKEAException(IKEAConstants.CustomWMSFactoryAutomationInvalidResourceLocalizedMessage, resourceName);
            }
            factoryAutomationResource.Load();

            // Get the automation controller:
            IAutomationControllerInstance instance = factoryAutomationResource.GetAutomationControllerInstance();

            foreach (long inventoryOrderId in inventoryOrderIdsList.Distinct())
            {
                string requestError = SendRequestToFactoryAutomation(instance, inventoryOrderId, requestType);

                if (!string.IsNullOrEmpty(requestError))
                {
                    // To optimize for the ideal use case, when there are no errors, the dictionary is not allocated until
                    // there is an error returned
                    if (errorsByOrderId == null)
                    {
                        errorsByOrderId = new Dictionary<long, string>();
                    }

                    errorsByOrderId[inventoryOrderId] = requestError;
                }
            }

            return errorsByOrderId;
        }

        /// <summary>
        /// Sends an HTTP WMS Message and returns the response
        /// Wrapper of the method SendWMSMessage.
        /// </summary>
        /// <param name="wmsIntegrationMessage">WMSIntegrationMessage 
        /// <param name="messageEndpoint"></param>
        /// <param name="httpMethod"></param>
        /// <returns>The WMS response.</returns>
        public WMSIntegrationMessage SendWMSMessageWithIntegrationEntry(WMSIntegrationMessage wmsIntegrationMessage, string messageEndpoint, HttpMethod httpMethod)
        {
            IIntegrationEntry integrationEntry = CreateWMSIntegrationEntry(
                wmsIntegrationMessage,
                messageEndpoint,
                description: wmsIntegrationMessage.IOType.ToString()
            );

            WMSIntegrationMessage wmsResponse = null;

            try
            {
                wmsResponse = SendWMSMessage(wmsIntegrationMessage, messageEndpoint, httpMethod);
            }
            catch (Exception exception)
            {
                integrationEntry.SaveResultMessage(Encoding.ASCII.GetBytes(exception.Message));
                integrationEntry.Fail();
                return null;
            }

            string serializedResponse = JsonConvert.SerializeObject(wmsResponse);
            integrationEntry.SaveResultMessage(Encoding.ASCII.GetBytes(serializedResponse));

            if (wmsResponse.Response == CustomWMSOrderResponseType.Accepted)
            {
                integrationEntry.Complete();
            }
            else
            {
                integrationEntry.Reject();
            }
            return wmsResponse;
        }

        /// <summary>
        /// Sends an HTTP WMS Message
        /// </summary>
        /// <param name="wmsIntegrationMessage">WMSIntegrationMessage
        /// <param name="messageEndpoint"></param>
        /// <returns>The WMSResponse</returns>
        private WMSIntegrationMessage SendWMSMessage(WMSIntegrationMessage wmsIntegrationMessage, string messageEndpoint, HttpMethod httpMethod)
        {
            WMSIntegrationMessage wmsResponse = null;

            if (wmsIntegrationMessage == null && httpMethod == HttpMethod.Post)
            {
                return wmsResponse;
            }

            // Get Access Token
            string accessToken = GetWMSAccessToken();
            if (string.IsNullOrWhiteSpace(accessToken))
            {
                throw new IKEAException((IKEAConstants.CustomWMSUnableToObtainTokenLocalizedMessage));
            }

            // Get base URL
            string baseURL = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.WMSBaseEndpoint);
            if (string.IsNullOrWhiteSpace(baseURL))
            {
                throw new IKEAException((IKEAConstants.CustomWMSMissingBaseEndpointLocalizedMessage));
            }
            try
            {
                using HttpClient httpClient = new();
                httpClient.BaseAddress = new Uri(baseURL);
                httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);

                // Create an HTTP request:
                HttpRequestMessage httpRequest = new HttpRequestMessage(httpMethod, messageEndpoint);
                if (httpMethod == HttpMethod.Post)
                {
                    // Add the json serialized message to the content of the request:
                    httpRequest.Content = new StringContent(
                        content: JsonConvert.SerializeObject(wmsIntegrationMessage),
                        encoding: Encoding.UTF8,
                        mediaType: "application/json"
                    );
                }

                // Get response
                HttpResponseMessage httpResponse = httpClient.SendAsync(httpRequest).GetAwaiter().GetResult();
                string responseBody = httpResponse.Content.ReadAsStringAsync().GetAwaiter().GetResult();

                // Handle http errors:
                if (!httpResponse.IsSuccessStatusCode)
                {
                    throw new IKEAException(IKEAConstants.CustomWMSExceptionLocalizedMessage, ("HTTP " + (int)httpResponse.StatusCode + " - " + httpResponse.StatusCode));
                }

                // Check if WMS returned an error message in the response (usually is XML)
                string errorMessage = String.Empty;
                if (httpResponse.Content.Headers.ContentType.MediaType == "application/xml" || httpResponse.Content.Headers.ContentType.MediaType == "text/xml")
                {
                    XmlDocument xmldoc = new();
                    xmldoc.LoadXml(responseBody);

                    // If an error message is received:
                    if (xmldoc.SelectNodes(IKEAConstants.ErrorMessage).Count > 0)
                    {
                        errorMessage = xmldoc.GetValueByXPath(IKEAConstants.ErrorMessageContent);
                    }
                }
                else if (httpResponse.Content.Headers.ContentType.MediaType == "application/json")
                {
                    errorMessage = JObject.Parse(responseBody).Value<string>("error");
                }

                // Message was processed but the ERP returned an error message:
                if (!errorMessage.IsNullOrEmpty())
                {
                    throw new IKEAException(IKEAConstants.CustomWMSExceptionLocalizedMessage, errorMessage);
                }

                // Parse the response
                try
                {
                    wmsResponse = JsonConvert.DeserializeObject<WMSIntegrationMessage>(responseBody);
                }
                catch (Exception exception)
                {
                    throw _iKEAUtilities.LocalizedException(IKEAConstants.CustomWMSInvalidResponseLocalizedMessage, exception.Message);
                }
            }
            catch (WebException exception)
            {
                string responseText = string.Empty;

                var responseStream = exception.Response?.GetResponseStream();

                if (responseStream != null)
                {
                    using StreamReader reader = new(responseStream);
                    responseText = reader.ReadToEnd();
                    if (!string.IsNullOrEmpty(responseText))
                    {
                        throw new IKEAException(IKEAConstants.CustomWMSExceptionLocalizedMessage, responseText);
                    }
                }
            }
            return wmsResponse;
        }

        /// <summary>
        /// Get WMS Access Token. cURL:
        ///     curl --location --request POST 'https://dev-api.retnig.pl/Token' \
        ///          --header 'Content-Type: application/json' \
        ///          --data-raw '{"Username":"critical","Password":"Cr1t1c4l!"}'
        /// </summary>
        /// <returns>Access Token</returns>
        private string GetWMSAccessToken()
        {
            string accessToken = string.Empty;

            using (WebClient client = new WebClient())
            {
                try
                {
                    // Get authentication configurations
                    string username = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.WMSUsername);
                    string password = _iKEAUtilities.GetDecryptedSecureStringConfiguration(IKEAConstants.WMSPassword);
                    string tokenEndpoint = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.WMSTokenEndpoint);

                    // Check if any of the configurations is missing
                    if (!string.IsNullOrWhiteSpace(username)
                        && !string.IsNullOrWhiteSpace(password)
                        && !string.IsNullOrWhiteSpace(tokenEndpoint))
                    {
                        // Build json Request Message
                        Dictionary<string, string> requestInfo = new Dictionary<string, string>()
                        {
                            { "username", username },
                            { "password", password },
                        };
                        string request = requestInfo.ToJsonString();

                        // Set headers
                        client.Headers.Add(HttpRequestHeader.ContentType, "application/json");
                        client.Headers.Add(HttpRequestHeader.Accept, "*/*");

                        // Upload Message
                        string result = client.UploadString(tokenEndpoint, "POST", request);

                        // Get wmsResponse data
                        var data = JObject.Parse(result);

                        // Get access token from wmsResponse data
                        accessToken = data["token"].ToString();
                    }
                    else
                    {
                        throw new IKEAException((IKEAConstants.CustomWMSMissingConfigurationsLocalizedMessage));
                    }
                }
                catch (WebException exception)
                {
                    string responseText = string.Empty;

                    var responseStream = exception.Response != null ? exception.Response.GetResponseStream() : null;

                    if (responseStream != null)
                    {
                        using (var reader = new StreamReader(responseStream))
                        {
                            responseText = reader.ReadToEnd();
                            if (!string.IsNullOrEmpty(responseText))
                                throw new IKEAException(IKEAConstants.CustomWMSExceptionLocalizedMessage, responseText);
                        }
                    }

                    if (string.IsNullOrEmpty(responseText))
                    {
                        if (exception.InnerException != null && !string.IsNullOrEmpty(exception.InnerException.Message))
                        {
                            responseText = exception.InnerException.Message;
                        }
                        else if (!string.IsNullOrEmpty(exception.Message))
                        {
                            responseText = exception.Message;
                        }
                    }

                    throw new IKEAException(IKEAConstants.CustomWMSExceptionLocalizedMessage, responseText);
                }
            }

            return accessToken;
        }

        /// <summary>
        /// Utility function that returns the list of Resources of type Feeder associated with a MainLine Resource
        /// </summary>
        /// <param name="mainLine"></param>
        /// <param name="loadRelation"></param>
        /// <returns></returns>
        public IResourceCollection GetMainLineFeeders(IResource mainLine, bool loadRelation = true)
        {
            IResourceCollection resourceFeeders = _entityFactory.CreateCollection<IResourceCollection>();

            if (mainLine.HasRelations("SubResource", loadRelation))
            {
                resourceFeeders.AddRange(
                    mainLine.RelationCollection["SubResource"]
                        .Cast<ISubResource>()
                        .Select(subResource => subResource.TargetEntity)
                        .Where(subResource => subResource.ProcessingType == ProcessingType.ConsumableFeed)
                    );
            }

            return resourceFeeders;
        }


        /// <summary>
        /// For one manufacturing order, create the list of corresponding AutomationJob Input Objects.
        /// </summary>
        /// <param name="type"></param>
        /// <param name="sourceResource"></param>
        /// <param name="targetResource"></param>
        /// <param name="operationMaterial">Material involved in the configured operation</param>
        /// <param name="feedDestinationsByMainLine">Optional cache to remember Resource destination information (only usefull for FEED requests)</param>
        /// <returns></returns>
        public List<WMSAutomationJobInput> CreateWMSManufacturingOrderJobInputs(
            CustomWMSOrderRequestType type,
            IResource sourceResource,
            IResource targetResource,
            IMaterial operationMaterial,
            Dictionary<string, FeedDestinations> feedDestinationsByMainLine = null
        )
        {
            // Collection of materials (can be MOS or other materials)
            IMaterialCollection operationMaterialCollection = _entityFactory.CreateCollection<IMaterialCollection>();

            if (operationMaterial.IsGroupMO())
            {
                operationMaterialCollection.AddRange(_iKEAUtilities.GetChildMaterialsFromGroupMO(operationMaterial));
            }
            else
            {
                operationMaterialCollection.Add(operationMaterial);
            }

            List<WMSAutomationJobInput> messages = new List<WMSAutomationJobInput>();

            switch (type)
            {
                case CustomWMSOrderRequestType.Feed:
                    List<(IProduct, IMaterial, IResource, decimal)> childFeedOrders = new List<(IProduct, IMaterial, IResource, decimal)>();

                    #region Load feedDestinations information
                    FeedDestinations feedDestinations;
                    if (feedDestinationsByMainLine == null || !feedDestinationsByMainLine.TryGetValue(targetResource.Name, out feedDestinations))
                    {
                        feedDestinations = new FeedDestinations(targetResource);
                        feedDestinations.Load();

                        if (feedDestinationsByMainLine != null)
                        {
                            feedDestinationsByMainLine[targetResource.Name] = feedDestinations;
                        }
                    }
                    #endregion

                    foreach (IMaterial material in operationMaterialCollection)
                    {
                        IResolveBomContextsResult bomResult = material.Product.ResolveBomContexts(material);

                        if (bomResult?.Bom != null)
                        {
                            bomResult.Bom.LoadRelations(Cmf.Navigo.Common.Constants.BOMProduct, 1);

                            if (!bomResult.Bom.BomProducts.IsNullOrEmpty())
                            {
                                bomResult.Bom.BomProducts.LoadAttributes(new Collection<string> {
                                    IKEAConstants.BomProductProcessSegmentAttribute,
                                    IKEAConstants.BomProductSubProcessSegmentAttribute
                                });
                                //if product isReference == true or is substitute (Parent is not null), we ignore it
                                foreach (IBOMProduct product in bomResult.Bom.BomProducts)
                                {
                                    if (product.IsReference != true && product.Parent == null)
                                    {
                                        IResource targetFeeder = feedDestinations.FindBomProductDestination(product);

                                        childFeedOrders.Add(
                                            (product.TargetEntity, material, targetFeeder ?? targetResource, (product.Quantity * material.PrimaryQuantity) ?? 0)
                                        );
                                    }
                                }
                            }
                        }
                    }

                    List<long> productionOrderIds = childFeedOrders
                        .Select(tuple => tuple.Item2.GetNativeValue<long>(Navigo.Common.Constants.ProductionOrder))
                        .Where(id => id > 0)
                        .ToList();

                    IProductionOrderCollection productionOrders = _entityFactory.CreateCollection<IProductionOrderCollection>(); ;
                    productionOrders.LoadByIDs<IProductionOrder, ProductionOrder>(productionOrderIds);

                    foreach (var (orderProduct, orderMaterial, orderResource, orderQuantity) in childFeedOrders)
                    {
                        var productionOrderId = orderMaterial.GetNativeValue<long>(Navigo.Common.Constants.ProductionOrder);
                        var productionOrder = productionOrders.FirstOrDefault(po => po.Id == productionOrderId);

                        if (productionOrder != null)
                        {
                            messages.Add(new WMSAutomationJobInput
                            {
                                IOType = type,
                                ItemID = orderProduct.Name,
                                ItemName = orderProduct.Description,
                                ManufacturingOrderName = productionOrder.Name,
                                Quantity = orderQuantity,
                                Destination = orderResource.Name,
                                Status = IKEAConstants.WMSAutomationJobFeedDefaulStatus,
                            });
                        }
                    }
                    break;
                case CustomWMSOrderRequestType.Move:
                    foreach (var material in operationMaterialCollection)
                    {
                        messages.Add(new WMSAutomationJobInput
                        {
                            IOType = type,
                            PalletID = material.Name,
                            Source = sourceResource.Name,
                            Destination = targetResource.Name,
                            ManufacturingOrderName = material.ProductionOrder?.Name,
                        });
                    }
                    break;
                case CustomWMSOrderRequestType.PutAway:
                    foreach (var material in operationMaterialCollection)
                    {
                        messages.Add(new WMSAutomationJobInput
                        {
                            IOType = type,
                            PalletID = material.Name,
                            Source = sourceResource.Name,
                            ManufacturingOrderName = material.ProductionOrder?.Name,
                        });
                    }
                    break;
                default:
                    throw _iKEAUtilities.LocalizedException(IKEAConstants.CustomWMSIOTypeFieldNotValidLocalizedMessage, type.ToString());
            }

            return messages;
        }

        /// <summary>
        /// Given a list of AutomationJob Input's (of type WMSOrderRequest), posts all of them to the DataPlatform to create the jobs and begin processing them
        /// </summary>
        /// <param name="jobInputs"></param>
        public void SendOrderAutomationJobInputs(IEnumerable<WMSAutomationJobInput> jobInputs)
        {
            AppProperties appProperties = new AppProperties()
            {
                ApplicationContext = "Order Request from MES for WMS",
                ApplicationName = Constants.MesSystemDesignation,
                EventDefinition = IKEAConstants.EventDefinitionWMSOrderRequest,
                EventTime = DateTime.Now
            };

            var iotEvents = jobInputs.Select(input => new PostEventInput
            {
                AppProperties = appProperties,
                Data = JObject.FromObject(input),
            }).ToList();

            PostMultipleIoTEventsInput postEventInput = new PostMultipleIoTEventsInput()
            {
                IoTEvents = iotEvents,
            };

            var output = _dataPlatformOrchestration.PostMultipleIoTEvents(postEventInput);

            if (output.HasErrors)
            {
                string errorMessage = output.ErrorCollection.SelectMany(pair => pair.Value).First();

                throw new Exception(errorMessage);
            }
        }

        /// <summary>
        /// Calculates the seasoning time of a material based on what time constraints it has applied to it.
        /// The biggest time constraing, of Type `Minimum` is used.
        /// </summary>
        /// <param name="material"></param>
        /// <returns></returns>
        public DateTime? GetMaterialSeasoningTime(IMaterial material)
        {
            DateTime? seasoningTime = null;

            var timeConstraints = material.GetAllTimeConstraints(false);

            if (timeConstraints.Count > 0)
            {
                foreach (IMaterialTimeConstraint materialTimeConstraint in timeConstraints)
                {
                    // Take the highest date for time constraint of type Minimum
                    if (materialTimeConstraint.Type == ConstraintType.Minimum &&
                        materialTimeConstraint.TimeLimitDate != null &&
                        (seasoningTime == null || materialTimeConstraint.TimeLimitDate > seasoningTime.Value))
                    {
                        seasoningTime = materialTimeConstraint.TimeLimitDate.Value;
                    }
                }
            }

            return seasoningTime;
        }

        public string GenerateNameForExistingMaterial(IMaterial material, string materialNameStartsWith, string nameGenerator)
        {
            materialNameStartsWith += ".";

            // Check if there base material name is already as a context in the name generator:
            INameGenerator gen = _entityFactory.Create<INameGenerator>();
            gen.Name = nameGenerator;
            //new NameGenerator() { Name = nameGenerator };
            gen.Load();

            IQueryObject query = new QueryObject();
            query.Description = "";
            query.EntityTypeName = "Material";
            query.Name = "GetLastMaterialOfBatch";
            query.Query = new Query();
            query.Query.Distinct = false;
            query.Query.Filters = new FilterCollection() {
                new Filter()
                {
                    Name = "Name",
                    ObjectName = "Material",
                    ObjectAlias = "Material_1",
                    Operator = Cmf.Foundation.Common.FieldOperator.StartsWith,
                    Value = materialNameStartsWith,
                    LogicalOperator = Cmf.Foundation.Common.LogicalOperator.Nothing,
                    FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                }
            };
            query.Query.Fields = new FieldCollection() {
                new Field()
                {
                    Alias = "Name",
                    ObjectName = "Material",
                    ObjectAlias = "Material_1",
                    IsUserAttribute = false,
                    Name = "Name",
                    Position = 0,
                    Sort = Cmf.Foundation.Common.FieldSort.Descending
                },
                new Field()
                {
                    Alias = "Id",
                    ObjectName = "Material",
                    ObjectAlias = "Material_1",
                    IsUserAttribute = false,
                    Name = "Id",
                    Position = 1,
                    Sort = Cmf.Foundation.Common.FieldSort.NoSort
                }
            };
            query.Query.Relations = new RelationCollection();

            DataSet resultDataSet = query.Execute(false, new QueryParameterCollection());
            if (resultDataSet.HasData())
            {

                List<int> materialCounters = new List<int>();
                foreach (DataRow materialsRows in resultDataSet.Tables[0].Rows)
                {
                    int materialCounter = 0;
                    if (int.TryParse(materialsRows.Field<string>("Name").Replace(materialNameStartsWith, ""), out materialCounter))
                    {
                        materialCounters.Add(materialCounter);
                    }
                }

                int numContexts = 0;
                gen.LoadGeneratorContexts(out numContexts);

                IGeneratorContext ctx = gen.Contexts.Where(CTX => CTX.Context.Equals(materialNameStartsWith)).FirstOrDefault();
                if (ctx == null)
                {
                    ctx = new GeneratorContext { Context = materialNameStartsWith, LastCounterValue = 0 };
                    gen.AddGeneratorContexts(new GeneratorContextCollection { ctx });
                    gen.Save();
                }

                //GeneratorContext ctx = gen.Contexts.Where(CTX => CTX.Context.Equals(materialNameStartsWith)).FirstOrDefault();
                if (ctx.LastCounterValue < materialCounters.Max())
                {
                    ctx.LastCounterValue = materialCounters.Max();
                    ctx.Save();
                }
            }
            //var nameGenerator = _entityFactory.Create<INameGenerator>();

            return gen.GenerateName(nameGenerator, material);
        }

        /// <summary>
        /// Calculate quantities based on quantity that is in the CustomWMSMaterialTrackerCollection query.
        /// Checks if material is GroupMO.
        /// </summary>
        /// <param name="manufacturingOrders">List of productionorders names</param>
        /// <param name="childAssociation">Dictionary of associations between ProductionOrders and Childs</param>
        private Dictionary<string, Dictionary<string, decimal>> GrabQueryDataPerListOfProductionOrderNames(List<string> manufacturingOrders, Dictionary<string, string> childAssociation)
        {
            #region Query
            IQueryObject query = new QueryObject();
            query.Description = "Lists all the trackers from the requests to WMS";
            query.EntityTypeName = "CustomWMSMaterialTracker";
            query.Name = "GetWMSMaterialTrackers";
            query.Query = new Query();
            query.Query.Distinct = false;
            query.Query.Filters = new FilterCollection()
            {
                new Filter()
                {
                    Name = "ManufacturingOrder",
                    ObjectName = "CustomWMSMaterialTracker",
                    ObjectAlias = "CustomWMSMaterialTracker_1",
                    Operator = Cmf.Foundation.Common.FieldOperator.In,
                    Value = manufacturingOrders,
                    LogicalOperator = Cmf.Foundation.Common.LogicalOperator.Nothing,
                    FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                }
            };

            query.Query.Fields = new FieldCollection() {
                 new Field()
                 {
                     Alias = "ManufacturingOrder",
                     ObjectName = "CustomWMSMaterialTracker",
                     ObjectAlias = "CustomWMSMaterialTracker_1",
                     IsUserAttribute = true,
                     Name = "ManufacturingOrder",
                     Position = 4,
                     Sort = Cmf.Foundation.Common.FieldSort.NoSort,
                     DisplayStyleName = "ManufacturingOrder"
                 },
                 new Field()
                 {
                     Alias = "ProductName",
                     ObjectName = "CustomWMSMaterialTracker",
                     ObjectAlias = "CustomWMSMaterialTracker_1",
                     IsUserAttribute = true,
                     Name = "ProductName",
                     Position = 5,
                     Sort = Cmf.Foundation.Common.FieldSort.NoSort,
                     DisplayStyleName = "ProductName"
                 },
                 new Field()
                 {
                     Alias = "RequestedQuantity",
                     ObjectName = "CustomWMSMaterialTracker",
                     ObjectAlias = "CustomWMSMaterialTracker_1",
                     IsUserAttribute = true,
                     Name = "RequestedQuantity",
                     Position = 7,
                     Sort = Cmf.Foundation.Common.FieldSort.NoSort,
                     DisplayStyleName = "RequestedQuantity"
                 },
                 new Field()
                 {
                     Alias = "DeliveredQuantity",
                     ObjectName = "CustomWMSMaterialTracker",
                     ObjectAlias = "CustomWMSMaterialTracker_1",
                     IsUserAttribute = true,
                     Name = "DeliveredQuantity",
                     Position = 8,
                     Sort = Cmf.Foundation.Common.FieldSort.NoSort,
                     DisplayStyleName = "DeliveredQuantity"
                 },

                 new Field()
                 {
                     Alias = "UniversalState",
                     ObjectName = "CustomWMSMaterialTracker",
                     ObjectAlias = "CustomWMSMaterialTracker_1",
                     IsUserAttribute = false,
                     Name = "UniversalState",
                     Position = 11,
                     Sort = Cmf.Foundation.Common.FieldSort.NoSort,
                     DisplayStyleName = "UniversalState"
                 }
            };

            #endregion

            query.Query.Relations = new RelationCollection();
            DataSet resultDataSet = query.Execute(false, new QueryParameterCollection());

            ICustomWMSMaterialTrackerCollection customWMSMaterialTrackersActive = _entityFactory.CreateCollection<ICustomWMSMaterialTrackerCollection>();

            if (resultDataSet.HasData())
            {
                foreach (DataRow materialsRows in resultDataSet.Tables[0].Rows)
                {
                    // If active return whatever is greater Math.Max( requested or delivered) else return delivered
                    decimal quantity = materialsRows.Field<int>("UniversalState") == (int)UniversalState.Active
                        ? Math.Max(materialsRows.Field<decimal>("RequestedQuantity"), materialsRows.Field<decimal>("DeliveredQuantity"))
                        : materialsRows.Field<decimal>("DeliveredQuantity");

                    string manufacturingOrder = materialsRows.Field<string>("ManufacturingOrder");

                    // If childassociation have the production order name
                    if (childAssociation.ContainsKey(manufacturingOrder))
                    {
                        // Replace the PO with child PO name
                        manufacturingOrder = childAssociation[manufacturingOrder];
                    }
                    var customWMSMaterialTracker = _entityFactory.Create<ICustomWMSMaterialTracker>();
                    customWMSMaterialTracker.ManufacturingOrder = manufacturingOrder;
                    customWMSMaterialTracker.ProductName = materialsRows.Field<string>("ProductName");
                    customWMSMaterialTracker.RequestedQuantity = quantity;
                    customWMSMaterialTrackersActive.Add(customWMSMaterialTracker);
                }
            }

            Dictionary<string, Dictionary<string, decimal>> quantitiesPerProduct = new Dictionary<string, Dictionary<string, decimal>>();
            foreach (var tracker in customWMSMaterialTrackersActive)
            {
                if (quantitiesPerProduct.ContainsKey(tracker.ProductName))
                {
                    quantitiesPerProduct.TryGetValue(tracker.ProductName, out Dictionary<string, decimal> quantitiesPerMO);
                    if (quantitiesPerMO.TryGetValue(tracker.ManufacturingOrder, out decimal sum))
                    {
                        sum += tracker.RequestedQuantity ?? 0;

                        quantitiesPerMO[tracker.ManufacturingOrder] = sum;
                    }
                    else
                    {
                        quantitiesPerMO.Add(tracker.ManufacturingOrder, tracker.RequestedQuantity ?? 0);
                    }

                }
                else
                {
                    Dictionary<string, decimal> quantitiesPerMO = new Dictionary<string, decimal>()
                    {
                        { tracker.ManufacturingOrder, tracker.RequestedQuantity ?? 0 }
                    };

                    quantitiesPerProduct.Add(tracker.ProductName, quantitiesPerMO);
                }
            }

            return quantitiesPerProduct;
        }

        /// <summary>
        /// Calculate quantities based on production order that is in the CustomWMSMaterialTrackerCollection query
        /// Checks if material is groupMO
        /// </summary>
        /// <param name="materials"></param>
        /// <param name="entityCache"></param>
        /// <param name="loadAttributes"></param>
        /// <param name="loadReleation"></param>
        /// <returns>
        /// Returns [ProductName] [ProductionOrderName] [Quantity]
        /// </returns>
        public Dictionary<string, Dictionary<string, decimal>> CalculateTotalRequestedQuantities(IMaterialCollection materials, EntityCache entityCache, bool loadAttributes, bool loadReleation)
        {
            // All the data about Quantity for all PO's
            Dictionary<string, Dictionary<string, decimal>> totalRequestedQuantity = new Dictionary<string, Dictionary<string, decimal>>();

            // Child PO.Name and parent.PO.Name
            Dictionary<string, string> childAssociation = new Dictionary<string, string>();

            // List of production order names
            List<string> productionOrderNames = new List<string>();

            foreach (IMaterial material in materials)
            {

                if (material.IsGroupMO(loadAttributes: false) == false)
                {
                    // Add productionorder name to the list
                    productionOrderNames.Add(material.ProductionOrder.Name);
                }
                else
                {
                    var childMaterialCollection = _iKEAUtilities.GetChildMaterialsFromGroupMO(material, loadAttributes, loadCollection: true, loadReleation);
                    var childOrderNames = childMaterialCollection.Select(childMO => childMO.ProductionOrder.GetNativeValue<string>("Name")).ToList();
                    entityCache.FetchAll<IProductionOrderCollection, IProductionOrder>(childOrderNames);
                    foreach (IMaterial childMaterial in childMaterialCollection)
                    {
                        childMaterial.ProductionOrder.Load();

                        childAssociation.Add(entityCache.Fetch(childMaterial.ProductionOrder).Name, material.Name);
                        productionOrderNames.Add(childMaterial.ProductionOrder.Name);
                    }

                }
            }
            // If we have some ProductionOrder.Names calculate the total requested quantities
            if (!productionOrderNames.IsNullOrEmpty())
            {
                totalRequestedQuantity = GrabQueryDataPerListOfProductionOrderNames(productionOrderNames, childAssociation);
            }

            return totalRequestedQuantity;

        }

    }
}
