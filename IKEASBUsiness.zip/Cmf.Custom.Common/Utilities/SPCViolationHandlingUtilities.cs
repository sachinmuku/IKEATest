﻿using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.SmartTables;
using Cmf.Foundation.Common;
using Cmf.Foundation.Security;
using Cmf.Navigo.BusinessObjects;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Foundation.Security.Abstractions;
using Cmf.Common.CustomActionUtilities;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Foundation.BusinessOrchestration.Abstractions;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Foundation.Common.LocalizationService;
using Cmf.Navigo.BusinessOrchestration.Abstractions;
using INotification = Cmf.Foundation.BusinessObjects.Abstractions.INotification;
using Cmf.Custom.IKEA.Common.Exceptions;
using INotificationCollection = Cmf.Foundation.BusinessObjects.Abstractions.INotificationCollection;

namespace Cmf.Custom.IKEA.Common.Utilities
{
    public class SPCViolationHandlingUtilities : ISPCViolationHandlingUtilities
    {
        private IEntityFactory _entityFactory;
        private IIKEAUtilities _iKEAUtilities;
        private IGenericUtilities _genericUtilities;
        private IGenericServiceOrchestration _genericServiceOrchestration;
        private ITableOrchestration _tableOrchestration;
        private IOrderOrchestration _orderOrchestration;
        //private IMaterialOrchestration _materialOrchestration;
        private ILocalizationService _localizationService;
        private IDeeContextUtilities _deeContextUtilities;
        private IAlarmHandlingUtilities _alarmHandlingUtilities;

        [Microsoft.Extensions.DependencyInjection.ActivatorUtilitiesConstructor]
        public SPCViolationHandlingUtilities(IEntityFactory entityFactory,
            IGenericUtilities genericUtilities,
            IGenericServiceOrchestration genericServiceOrchestration,
            IIKEAUtilities iKEAUtilities,
            ILocalizationService localizationService,
            IDeeContextUtilities deeContextUtilities,
            IOrderOrchestration orderOrchestration,
            ITableOrchestration tableOrchestration,
            IAlarmHandlingUtilities alarmHandlingUtilities)
        {
            _entityFactory = entityFactory;
            _genericUtilities = genericUtilities;
            _genericServiceOrchestration = genericServiceOrchestration;
            _iKEAUtilities = iKEAUtilities;
            _localizationService = localizationService;
            _deeContextUtilities = deeContextUtilities;
            _orderOrchestration = orderOrchestration;
            _tableOrchestration = tableOrchestration;
            _alarmHandlingUtilities = alarmHandlingUtilities;
        }
        private INotification CreateSPCViolationNotification(DataRow row, IResource resource, string logicalChartLink, IChartDataPoint chartDataPoint, IEmployee employee = null, IRole role = null)
        {
            #region Create message details
            //Notification title
            string SPCViolationNotificationTitle = _iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomSPCViolationNotificationHeader, resource.Name);
            Dictionary<String, String> notificationDetailsDict = new Dictionary<string, string>();

            //Notification Details
            if (!string.IsNullOrWhiteSpace(row.Field<string>(IKEAConstants.Facility)))
            {
                notificationDetailsDict.Add("Facility", row.Field<string>(IKEAConstants.Facility));
            }
            if (!string.IsNullOrWhiteSpace(row.Field<string>(IKEAConstants.Area)))
            {
                notificationDetailsDict.Add("Area", row.Field<string>(IKEAConstants.Area));
            }
            if (!string.IsNullOrWhiteSpace(row.Field<string>(IKEAConstants.Step)))
            {
                notificationDetailsDict.Add("Step", row.Field<string>(IKEAConstants.Step));
            }
            if (!string.IsNullOrWhiteSpace(row.Field<string>(IKEAConstants.Chart)))
            {
                notificationDetailsDict.Add("Chart", row.Field<string>(IKEAConstants.Chart));
            }
            if (!string.IsNullOrWhiteSpace(row.Field<string>(IKEAConstants.Parameter)))
            {
                notificationDetailsDict.Add("Parameter", row.Field<string>(IKEAConstants.Parameter));
            }
            if (!string.IsNullOrWhiteSpace(logicalChartLink))
            {
                notificationDetailsDict.Add("Logical Chart", logicalChartLink);
            }
            if (!string.IsNullOrWhiteSpace(row.Field<string>(IKEAConstants.Chart)) && chartDataPoint != null)
            {
                foreach (var context in chartDataPoint.ContextInformation)
                {
                    if (context.IsKey)
                    {
                        notificationDetailsDict.Add(context.Name, context.Value);
                    }
                }
            }

            //Generate Details data for notification
            string notificationDetails = "<table>";
            foreach (string element in notificationDetailsDict.Keys)
            {
                notificationDetails += "<tr><td>" + element + ": " + notificationDetailsDict[element] + "<tr><td>";
            }
            notificationDetails += "</table>";
            #endregion

            //Validate Severity in config
            string severity = _iKEAUtilities.GetValueFromConfigurationWithPath(IKEAConstants.DefaultNotificationSeverityConfig);

            if (severity.IsNullOrEmpty())
            {
                throw new IKEAException(IKEAConstants.CustomDefaultNotificationSeverityConfigNotDefined, IKEAConstants.DefaultNotificationSeverityConfig);
            }

            //Send notification to Employee
            var notification = _entityFactory.Create<INotification>();
            notification.Type = IKEAConstants.NotificationType;
            notification.Title = SPCViolationNotificationTitle;
            notification.Details = notificationDetails;
            notification.Severity = _iKEAUtilities.GetValueFromLookupTable(IKEAConstants.NotificationSeverityLookupTableName, severity, true);
            notification.AssignmentType = (NotificationAssignmentType)(employee != null ? AssignmentType.Employee : AssignmentType.Role);
            if(employee!=null)
            { notification.AssignedToUser = employee.User; }
                
    
            if(role!=null)
            { notification.AssignedToRole = role; }

            notification.SendEmailToAssignedParty = false;
            notification.DocumentationURL = logicalChartLink;
            return notification;

        }

        /// <summary>
        /// Class to handle SPC violation and Send Notification / Block Materials when violations occur
        /// </summary>
        /// <param name="chartDataPoint"></param>
        /// <param name="actions"></param>
        public void HandleSPCViolation(DataRow row, List<String> actions, IMaterialCollection materialsToBlock, List<String> resourceNames, string logicalChartLink = null, IChartDataPoint chartDataPoint = null)
        {
            IResource resource = _entityFactory.Create<IResource>();
            resource.Name = resourceNames.FirstOrDefault();
            List<long> alreadyNotifiedEmployeeID = new List<long>();
            List<long> alreadyNotifiedRoleID = new List<long>();
            INotificationCollection notifications = _entityFactory.CreateCollection<INotificationCollection>();
            bool hasSentEmails = false;

            // Verify if resource exist before loading
            if (!resource.ObjectExists())
            {
                throw new IKEAException(IKEAConstants.CustomBarcodeExceptionsResourceNotFoundLocalizedMessage, row.Field<string>(Constants.Resource));
            }

            resource.Load();
            // if context doesn't have any materials then vefiry if the resources have materials in progress
            if (materialsToBlock.Count == 0 && resourceNames.Count > 0)
            {
                IResourceCollection contextResources = _entityFactory.CreateCollection<IResourceCollection>();
                contextResources.AddRange(resourceNames.Select(ET =>
                {
                    var resource = _entityFactory.Create<IResource>();
                    resource.Name = ET;
                    return resource;
                }));
                contextResources.Load();
                foreach (IResource r in contextResources)
                {
                    r.LoadRelations(Constants.MaterialResource);
                    //get all materials at top most ressource
                    IMaterialCollection contextResourceMaterials = _entityFactory.CreateCollection<IMaterialCollection>();
                    if (r.RelationCollection.ContainsKey(Constants.MaterialResource))
                    {
                        contextResourceMaterials.AddRange(r.RelationCollection[Constants.MaterialResource].Select(ET => ET.SourceEntity as IMaterial).ToList());
                        //Collect all Materials in progress on the resource responsible for SPC violation
                        materialsToBlock.AddRange(contextResourceMaterials.Where(ET => ET.SystemState == MaterialSystemState.InProcess));
                    }
                }

            }

            foreach (String action in actions)
            {
                switch (action)
                {
                    //Iterate through all materials coming from input / resource that came in the input and block them
                    case "Block":
                        // Get default hold reason
                        string reasonToUse = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.SPCDefaultHoldReason);
                        foreach (IMaterial material in materialsToBlock)
                        {
                            _iKEAUtilities.HoldManufacturingOrder(material, reasonToUse);
                        }
                        break;

                    case IKEAConstants.Notify:

                        if (row != null)
                        {
                            if (!string.IsNullOrWhiteSpace(row.Field<string>(IKEAConstants.Employee)) || !string.IsNullOrWhiteSpace(row.Field<string>(IKEAConstants.Role)))
                            {
                                // Check if any role was defined                            
                                if (!string.IsNullOrWhiteSpace(row.Field<string>(IKEAConstants.Role)))
                                {

                                    IRole role = new Role()
                                    {
                                        Name = row.Field<string>(IKEAConstants.Role)
                                    };
                                    role.Load();

                                    // Send notification to Role                                    
                                    notifications.Add(CreateSPCViolationNotification(row, resource, logicalChartLink, chartDataPoint, role: role));
                                    alreadyNotifiedRoleID.Add(role.Id);
                                }

                                // Check if any employee was defined                           
                                if (!string.IsNullOrWhiteSpace(row.Field<string>(IKEAConstants.Employee)))
                                {

                                    IEmployee employee = _entityFactory.Create<IEmployee>();
                                    employee.Name = row.Field<string>(IKEAConstants.Employee);
                                    employee.Load(2);

                                    // check if employee already belong to a notified role so don't send notification
                                    if (employee.User.Roles.Select(x => x.Id).Intersect(alreadyNotifiedRoleID).Count() > 0)
                                    {
                                        alreadyNotifiedEmployeeID.Add(employee.Id);
                                    }
                                    else
                                    {
                                        //Send notification to Employee
                                        notifications.Add(CreateSPCViolationNotification(row, resource, logicalChartLink, chartDataPoint, employee: employee));
                                    }
                                }
                            }
                        }
                        break;

                    case IKEAConstants.NotifyCheckedInEmployees:

                        if (row != null)
                        {
                            // Check if necessary to notify Checked In employees
                            if (row.Field<bool>(IKEAConstants.NotifyCheckedInEmployees))
                            {
                                // get checkedin employees in both resources (context and specified in the table):
                                IEmployeeCollection employeesToBeNotified = _entityFactory.CreateCollection<IEmployeeCollection>();
                                employeesToBeNotified.AddRange(_genericUtilities.GetCheckedInEmployees(resource.Name));

                                if (!string.IsNullOrWhiteSpace(row.Field<string>("Resource")) && !row.Field<string>("Resource").Equals(resource.Name))
                                {
                                    employeesToBeNotified.AddRange(_genericUtilities.GetCheckedInEmployees(row.Field<string>("Resource")));
                                }

                                if (!employeesToBeNotified.IsNullOrEmpty())
                                {
                                    // Load employees with roles:
                                    employeesToBeNotified.Load(2);

                                    foreach (IEmployee employee in employeesToBeNotified)
                                    {
                                        // Check if Employee exists on the system
                                        if (alreadyNotifiedEmployeeID.Contains(employee.Id))
                                        {
                                            continue;
                                        }

                                        // check if employee already belong to a notified role so don't send notification
                                        if (employee.User.Roles.Select(x => x.Id).Intersect(alreadyNotifiedRoleID).Count() > 0)
                                        {
                                            alreadyNotifiedEmployeeID.Add(employee.Id);
                                            continue;
                                        }

                                        //Send notification to Employee
                                        notifications.Add(CreateSPCViolationNotification(row, resource, logicalChartLink, chartDataPoint, employee: employee));
                                        alreadyNotifiedEmployeeID.Add(employee.Id);
                                    }
                                }
                            }
                        }
                        break;

                    case IKEAConstants.EmailNotification:

                        if (row != null)
                        {
                            // Check if it is necessary to send emails:
                            if (row.Field<bool>(IKEAConstants.EmailNotification))
                            {
                                //string distributionList = null;
                                List<string> emailAddresses = new List<string>();

                                // Get the email addresses of the role if defined:
                                if (!string.IsNullOrWhiteSpace(row.Field<string>(IKEAConstants.Role)))
                                {
                                    IRole role = new Role()
                                    {
                                        Name = row.Field<string>(IKEAConstants.Role)
                                    };
                                    role.Load();

                                    string roleEmails = role.GetEmailAddressesAsDistributionList(null, true, true);
                                    emailAddresses.AddRange(roleEmails.Split(';'));
                                }

                                // Check if a distribution list was supplied:
                                if (!String.IsNullOrWhiteSpace(row.Field<string>(IKEAConstants.DistributionList)))
                                {
                                    emailAddresses.AddRange(row.Field<string>(IKEAConstants.DistributionList).Split(';'));
                                }

                                // Get the email from the employee if defined
                                if (!String.IsNullOrWhiteSpace(row.Field<string>(IKEAConstants.Employee)))
                                {
                                    IEmployee employee = _entityFactory.Create<IEmployee>();
                                    employee.Name = row.Field<string>(IKEAConstants.Employee);

                                    employee.Load();
                                    if (!employee.User.MailAddress.IsNullOrEmpty())
                                    {
                                        emailAddresses.Add(employee.User.MailAddress);
                                    }
                                }

                                // Validate the email list:
                                emailAddresses = _iKEAUtilities.ValidateEmailList(emailAddresses);

                                //Set option to send e-mail if EmailNotification is active
                                if (!emailAddresses.IsNullOrEmpty())
                                {
                                    #region Create message details
                                    //Notification title
                                    string SPCViolationNotificationTitle = _iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomSPCViolationNotificationHeader, resource.Name);
                                    Dictionary<String, String> notificationDetailsDict = new Dictionary<string, string>();

                                    //Notification Details
                                    if (!string.IsNullOrWhiteSpace(row.Field<string>(IKEAConstants.Facility)))
                                    {
                                        notificationDetailsDict.Add("Facility", row.Field<string>(IKEAConstants.Facility));
                                    }
                                    if (!string.IsNullOrWhiteSpace(row.Field<string>(IKEAConstants.Area)))
                                    {
                                        notificationDetailsDict.Add("Area", row.Field<string>(IKEAConstants.Area));
                                    }
                                    if (!string.IsNullOrWhiteSpace(row.Field<string>(IKEAConstants.Step)))
                                    {
                                        notificationDetailsDict.Add("Step", row.Field<string>(IKEAConstants.Step));
                                    }
                                    if (!string.IsNullOrWhiteSpace(row.Field<string>(IKEAConstants.Chart)))
                                    {
                                        notificationDetailsDict.Add("Chart", row.Field<string>(IKEAConstants.Chart));
                                    }

                                    notificationDetailsDict.Add("Date/Time", DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss.fff", System.Globalization.CultureInfo.InvariantCulture));

                                    if (!string.IsNullOrWhiteSpace(row.Field<string>(IKEAConstants.Parameter)))
                                    {
                                        notificationDetailsDict.Add("Parameter", row.Field<string>(IKEAConstants.Parameter));
                                    }
                                    if (!string.IsNullOrWhiteSpace(logicalChartLink))
                                    {
                                        notificationDetailsDict.Add("Logical Chart", "<a href=" + logicalChartLink + ">" + chartDataPoint.LogicalChart.Name + "</a>");
                                    }
                                    if (chartDataPoint != null)
                                    {
                                        foreach (var context in chartDataPoint.ContextInformation)
                                        {
                                            if (context.IsKey)
                                            {
                                                notificationDetailsDict.Add(context.Name, context.Value);
                                            }
                                        }
                                    }

                                    //Generate Details data for notification
                                    string notificationDetails = "<table>";
                                    foreach (string element in notificationDetailsDict.Keys)
                                    {
                                        notificationDetails += "<tr><td>" + element + ": " + notificationDetailsDict[element] + "<tr><td>";
                                    }
                                    notificationDetails += "</table>";
                                    #endregion

                                    hasSentEmails = true;

                                    _alarmHandlingUtilities.SendEmail(emailTo: string.Join(",", emailAddresses),
                                                            emailSubject: _iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomSPCViolationEmailTitle, row.Field<string>("Rule"), chartDataPoint.LogicalChart.Chart.Name),
                                                            emailMessage: notificationDetails,
                                                            emailIsBodyHTML: true);
                                }
                            }
                        }
                        break;

                    case IKEAConstants.MaintenanceActivity:
                        // Get Role to notify in case there is already MAO created in the system 
                        string roleName = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.RoleToNotify);
                        IRole roleToNotify = null;
                        if (!String.IsNullOrWhiteSpace(roleName))
                        {
                            roleToNotify = new Role();
                            roleToNotify.Load(roleName);
                        }

                        _iKEAUtilities.ResourceMAOHandling(resource.Name, row.Field<string>(IKEAConstants.MaintenanceActivity), null, roleToNotify, true, logicalChartLink: logicalChartLink);
                        break;

                    default:
                        break;
                }
            }

            if (notifications.IsNullOrEmpty() && !hasSentEmails)
            {
                // If no notifications or emails were sent, try to notify the owner role of the Maintenance Activity
                IMaintenanceActivity maintenanceActivity = _entityFactory.Create<IMaintenanceActivity>();
                maintenanceActivity.Name = row.Field<string>(IKEAConstants.MaintenanceActivity);

                if (!maintenanceActivity.Name.IsNullOrEmpty())
                {
                    maintenanceActivity.Load();
                    maintenanceActivity.MaintenancePlan.Load();

                    // Get the maintenance plan instances for this resource, that belong to the Maintenance Plan configured for this SPC Violation
                    IMaintenancePlanInstance mpi = _iKEAUtilities.GetResourceMPI(resource.Name, maintenanceActivity.MaintenancePlan.Name).FirstOrDefault();

                    if (mpi != null)
                    {
                        notifications.Add(CreateSPCViolationNotification(row, resource, logicalChartLink, chartDataPoint, role: mpi.OwnerRole));
                    }
                }
            }

            if (!notifications.IsNullOrEmpty())
            {
                notifications.Create();
            }
        }

        /// <summary>
        /// Resolve SPC Actions smart table for configured actions to take
        /// </summary>
        /// <returns></returns>
        public DataRow ResolveSmartTableCustomSPCViolationActions(IChartDataPoint chartDataPoint, string ruleName, string resource)
        {
            string step = String.Empty;
            string area = String.Empty;
            string facility = String.Empty;
            string chart = String.Empty;
            string parameter = String.Empty;
            DataRow resolvedDataRow = null;

            foreach (var contexInformation in chartDataPoint.ContextInformation)
            {
                switch (contexInformation.Name)
                {
                    case Constants.Resource:
                        if (String.IsNullOrWhiteSpace(resource))
                        {
                            resource = contexInformation.Value;
                        }
                        break;
                    case IKEAConstants.Step:
                        step = contexInformation.Value;
                        break;
                    case IKEAConstants.Area:
                        area = contexInformation.Value;
                        break;
                    case IKEAConstants.Facility:
                        facility = contexInformation.Value;
                        break;

                    default: break;
                }
            }

            chart = chartDataPoint.LogicalChart.Chart?.Name;
            parameter = chartDataPoint.LogicalChart.Chart?.Parameter?.Name;

            IResource r = _entityFactory.Create<IResource>(); ;
            r.Load(resource);
            if (string.IsNullOrWhiteSpace(area))
            {
                area = r.Area.Name;
            }
            if (string.IsNullOrWhiteSpace(facility))
            {
                facility = r.Area.Facility.Name;
            }


            ISmartTable customSPCViolationActions = new SmartTable();
            customSPCViolationActions.Load(IKEAConstants.CustomSPCViolationActions);

            //Create NgpDataRow with the configuration to be tested against the SmartTable
            INgpDataRow values = new NgpDataRow();
            values.Add(IKEAConstants.Facility, facility);
            values.Add(IKEAConstants.Area, area);
            values.Add(IKEAConstants.Step, step);
            values.Add(Constants.Resource, resource);
            values.Add(IKEAConstants.Chart, chart);
            values.Add(IKEAConstants.Parameter, parameter);
            values.Add(Constants.Rule, ruleName);

            //Resolve the smartTable 
            INgpDataSet nds = customSPCViolationActions.Resolve(values, true);

            if (nds != null)
            {
                //If the configuration was successfully found on the SmartTable
                DataSet ds = NgpDataSet.ToDataSet(nds);
                if (ds.HasData())
                {
                    resolvedDataRow = ds.Tables[0].Rows[0];
                }
            }

            return resolvedDataRow;
        }

    }
}