﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.SmartTables;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Cmf.Custom.IKEA.Common.Extensions;
using System.Collections.ObjectModel;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Foundation.BusinessOrchestration.Abstractions;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Foundation.Common.LocalizationService;
using Cmf.Navigo.BusinessOrchestration.Abstractions;
using Cmf.Custom.IKEA.Common.Exceptions;
using Cmf.Custom.IKEA.Common.Enums;

namespace Cmf.Custom.IKEA.Common.Utilities
{
    public class AutomaticPrintingUtilities : IAutomaticPrintingUtilities
    {
        private IEntityFactory _entityFactory;
        private IIKEAUtilities _iKEAUtilities;
        private IGenericUtilities _genericUtilities;
        private IGenericServiceOrchestration _genericServiceOrchestration;
        //private IMaterialOrchestration _materialOrchestration;
        private ILocalizationService _localizationService;

        [Microsoft.Extensions.DependencyInjection.ActivatorUtilitiesConstructor]
        public AutomaticPrintingUtilities(IEntityFactory entityFactory,
            IGenericUtilities genericUtilities,
            IGenericServiceOrchestration genericServiceOrchestration,
            IIKEAUtilities iKEAUtilities,
            ILocalizationService localizationService)
        {
            _entityFactory = entityFactory;
            _genericUtilities = genericUtilities;
            _genericServiceOrchestration = genericServiceOrchestration;
            _iKEAUtilities = iKEAUtilities;
            _localizationService = localizationService;
        }
        /// <summary>
        /// Queues Printing job for a collection of printable documents
        /// </summary>
        /// <param name="printableDocumentCollection"></param>
        /// <param name="material"></param>
        /// <param name="parameters"></param>
        private void PrintDocuments(IPrintableDocumentCollection printableDocumentCollection, IMaterial material, Dictionary<int, Dictionary<string, Object>> parameters)
        {
            if (printableDocumentCollection != null && printableDocumentCollection.Count > 0)
            {
                printableDocumentCollection.Print(false, material, parameters);
            }
        }

        /// <summary>
        /// Prepares Parameter Dictionary for Document Printing
        /// </summary>
        /// <param name="printableDocument"></param>
        /// <param name="printer"></param>
        /// <param name="material"></param>
        /// <returns></returns>
        private Dictionary<string, Object> PreparePrintDocuments(IPrintableDocument printableDocument, string printer, IMaterial material)
        {
            //if lot traveler => print with context
            //if not => print only with applies to
            Dictionary<string, object> parameters = new Dictionary<string, object>();
            parameters.Add(Constants.PrinterName, printer);

            if (printableDocument.Type == Constants.LotTravelerPrintableDocumentType)
            {
                parameters.Add(Constants.Flow, material.Flow);
                parameters.Add(Constants.FlowPath, material.FlowPath);
                parameters.Add(Constants.Step, material.Step);
            }
            return parameters;
        }

        /// <summary>
        /// Resolves Smart Table for automatic printing and triggers the printing process
        /// </summary>
        /// <param name="material"></param>
        /// <param name="step"></param>
        /// <param name="printingSequence"></param>
        /// <param name="isSplitMainMaterial"></param>
        public void ResolveAndPrintAutomaticPrintableDocuments(IMaterial material, IStep step, string printingSequence, IResource resource = null)
        {
            bool actionDone = false;

            DataSet ds = ResolveAutoPrintingContextSmartTable(material, printingSequence, step, resource: resource);

            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                bool resourceUsed = false;
                bool productUsed = false;
                bool productGroupUsed = false;

                Dictionary<string, Tuple<IPrintableDocumentCollection, Dictionary<int, Dictionary<string, object>>>> docsToPrintByPrinter = new Dictionary<string, Tuple<IPrintableDocumentCollection, Dictionary<int, Dictionary<string, object>>>>();
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    bool isEnabled = (row[IKEAConstants.CustomAutomaticPrintableDocumentContextIsEnabledCol] == null) ? false : (bool)row[IKEAConstants.CustomAutomaticPrintableDocumentContextIsEnabledCol];

                    if (isEnabled)
                    {

                        //if we have lines with and lines without product print only the ones with product.
                        if (!string.IsNullOrWhiteSpace(row[Constants.Product] as string))
                        {
                            productUsed = true;
                        }
                        else if (productUsed)
                        {
                            break;
                        }

                        //if we have lines with and lines without ProductGroup print only the ones with ProductGroup.
                        if (!string.IsNullOrWhiteSpace(row[Constants.ProductGroup] as string))
                        {
                            productGroupUsed = true;
                        }
                        else if (productGroupUsed)
                        {
                            break;
                        }

                        //if we have lines with and lines without resource print only the ones with resource.
                        if (!string.IsNullOrWhiteSpace(row[Constants.Resource] as string))
                        {
                            resourceUsed = true;
                        }
                        else if (resourceUsed)
                        {
                            break;
                        }

                        IPrintableDocument printDoc = null;
                        if (!string.IsNullOrWhiteSpace(row[IKEAConstants.CustomAutomaticPrintableDocumentContextPrintableDocumentCol] as string))
                        {
                            printDoc = _entityFactory.Create<IPrintableDocument>();
                            printDoc.Load(row[IKEAConstants.CustomAutomaticPrintableDocumentContextPrintableDocumentCol] as string);
                        }

                        string printer = row[IKEAConstants.CustomAutomaticPrintableDocumentContextPrinterCol] as string;

                        CustomPrintingOptionsEnum printingOptionsEnum = (CustomPrintingOptionsEnum)int.Parse(row["PrintOptions"].ToString());

                        IPrintableDocumentCollection docsToPrint = null;
                        Dictionary<int, Dictionary<string, object>> totalParams = null;

                        // separate printable documents by different printers.
                        if (!docsToPrintByPrinter.ContainsKey(printer) &&
                           (printingOptionsEnum.Equals(CustomPrintingOptionsEnum.Label) || printingOptionsEnum.Equals(CustomPrintingOptionsEnum.Both)))
                        {
                            docsToPrintByPrinter.Add(printer, new Tuple<IPrintableDocumentCollection, Dictionary<int, Dictionary<string, object>>>(_entityFactory.CreateCollection<IPrintableDocumentCollection>(), new Dictionary<int, Dictionary<string, object>>()));
                        }

                        if (docsToPrintByPrinter.Count > 0)
                        {
                            var docsToPrintTuple = docsToPrintByPrinter[printer];
                            docsToPrint = docsToPrintTuple.Item1;
                            totalParams = docsToPrintTuple.Item2;

                            Dictionary<string, object> parameters = PreparePrintDocuments(printDoc, printer, material);
                            if (parameters != null && parameters.Count > 0)
                            {
                                totalParams.Add(totalParams.Count, parameters);
                                docsToPrint.Add(printDoc);
                            }
                        }
                    }
                }

                // Print one PrintableDocumentCollection at a time
                foreach (var docsToPrintTuple in docsToPrintByPrinter?.Values)
                {
                    IPrintableDocumentCollection docsToPrint = docsToPrintTuple.Item1;
                    Dictionary<int, Dictionary<string, object>> totalParams = docsToPrintTuple.Item2;
                    PrintDocuments(docsToPrint, material, totalParams);

                    actionDone = true;
                }
            }

            if (actionDone)
            {
                RegisterMaterialLabelPrinted(material, step);
            }

        }

        /// <summary>
        /// Resolves the ResolveAndPrintSplitAutomaticPrintableDocuments ST
        /// </summary>
        /// <param name="materials"></param>
        /// <param name="mainMaterial"></param>
        /// <param name="printingSequence"></param>
        public void ResolveAndPrintSplitAutomaticPrintableDocuments(IMaterialCollection materials, IMaterial mainMaterial, string printingSequence)
        {
            ISmartTable printContext = new SmartTable();
            printContext.Load(IKEAConstants.CustomAutomaticPrintableDocumentContext);
            Dictionary<IMaterial, bool> actionsDone = new Dictionary<IMaterial, bool>();
            //bool actionDone = false;

            INgpDataRow values = new NgpDataRow();
            values.Add(Constants.Step, mainMaterial.Step.Name);
            values.Add(IKEAConstants.CustomAutomaticPrintableDocumentContextPrintingSequenceCol, printingSequence);

            if (mainMaterial.Product == null)
            {
                mainMaterial.Load();
            }

            if (mainMaterial.LastProcessedResource != null)
            {
                values.Add(Constants.Resource, mainMaterial.LastProcessedResource.Name);
            }

            values.Add(Constants.Product, mainMaterial.Product.Name);

            if (mainMaterial.Product.ProductGroup != null)
            {
                values.Add(Constants.ProductGroup, mainMaterial.Product.ProductGroup.Name);
            }

            INgpDataSet nds = printContext.FirstResolveOrder(values);

            if (mainMaterial.Product != null)
            {
                string baseProductName = mainMaterial.Product.GetRelatedAttributeValueOrDefault<string>(IKEAConstants.CustomProductAttributeBaseProduct, true);
                //Try to resolve using BaseProduct
                nds = _genericUtilities.ResolveBaseProduct(baseProductName, printContext, values, nds, true);
            }

            if (nds != null)
            {
                DataSet ds = NgpDataSet.ToDataSet(nds);

                Dictionary<long, Dictionary<string, Tuple<IPrintableDocumentCollection, Dictionary<int, Dictionary<string, object>>>>> docsByMaterial = new Dictionary<long, Dictionary<string, Tuple<IPrintableDocumentCollection, Dictionary<int, Dictionary<string, object>>>>>();

                if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow row in ds.Tables[0].Rows)
                    {

                        bool isEnabled = (row[IKEAConstants.CustomAutomaticPrintableDocumentContextIsEnabledCol] == null) ? false : (bool)row[IKEAConstants.CustomAutomaticPrintableDocumentContextIsEnabledCol];
                        if (isEnabled)
                        {

                            // If in the case of a main material, check if it is to print. if so, add it to material list:
                            bool isToPrintSourceSplitMaterial = (row[IKEAConstants.CustomAutomaticPrintableDocumentContextPrintSourceSplitMaterialCol] == null) ? false : (bool)row[IKEAConstants.CustomAutomaticPrintableDocumentContextPrintSourceSplitMaterialCol];
                            if (isToPrintSourceSplitMaterial)
                            {
                                materials.Add(mainMaterial);
                            }

                            foreach (IMaterial material in materials)
                            {

                                IPrintableDocument printDoc = null;
                                if (!string.IsNullOrWhiteSpace(row[IKEAConstants.CustomAutomaticPrintableDocumentContextPrintableDocumentCol] as string))
                                {
                                    printDoc = _entityFactory.Create<IPrintableDocument>();
                                    printDoc.Load(row[IKEAConstants.CustomAutomaticPrintableDocumentContextPrintableDocumentCol] as string);
                                }

                                string printer = row[IKEAConstants.CustomAutomaticPrintableDocumentContextPrinterCol] as string;

                                CustomPrintingOptionsEnum printingOptionsEnum = (CustomPrintingOptionsEnum)int.Parse(row["PrintOptions"].ToString());

                                IPrintableDocumentCollection docsToPrint = null;
                                Dictionary<int, Dictionary<string, object>> totalParams = null;

                                Dictionary<string, Tuple<IPrintableDocumentCollection, Dictionary<int, Dictionary<string, object>>>> docsToPrintByPrinter =
                                    new Dictionary<string, Tuple<IPrintableDocumentCollection, Dictionary<int, Dictionary<string, object>>>>();

                                // separate printable documents by different printers.
                                if (!docsToPrintByPrinter.ContainsKey(printer) &&
                                   (printingOptionsEnum.Equals(CustomPrintingOptionsEnum.Label) || printingOptionsEnum.Equals(CustomPrintingOptionsEnum.Both)))
                                {
                                    docsToPrintByPrinter.Add(printer, new Tuple<IPrintableDocumentCollection, Dictionary<int, Dictionary<string, object>>>(_entityFactory.CreateCollection<IPrintableDocumentCollection>(), new Dictionary<int, Dictionary<string, object>>()));
                                }

                                if (docsToPrintByPrinter.Count > 0)
                                {
                                    var docsToPrintTuple = docsToPrintByPrinter[printer];
                                    docsToPrint = docsToPrintTuple.Item1;
                                    totalParams = docsToPrintTuple.Item2;

                                    Dictionary<string, object> parameters = PreparePrintDocuments(printDoc, printer, material);
                                    if (parameters != null && parameters.Count > 0)
                                    {
                                        totalParams.Add(totalParams.Count, parameters);
                                        docsToPrint.Add(printDoc);
                                    }

                                    docsByMaterial.Add(material.Id, docsToPrintByPrinter);
                                }
                            }
                        }
                    }

                    // Check if there is anything to print
                    if (!docsByMaterial.IsNullOrEmpty())
                    {
                        // Print one PrintableDocumentCollection at a time
                        foreach (IMaterial material in materials)
                        {
                            if (docsByMaterial.ContainsKey(material.Id))
                            {
                                var docsToPrintTuple = docsByMaterial[material.Id].First().Value;

                                IPrintableDocumentCollection docsToPrint = docsToPrintTuple.Item1;
                                Dictionary<int, Dictionary<string, object>> totalParams = docsToPrintTuple.Item2;
                                PrintDocuments(docsToPrint, material, totalParams);

                                if (!actionsDone.Any(ad => ad.Key.Name.Equals(material.Name)))
                                {
                                    actionsDone.Add(material, true);
                                }
                            }

                        }
                    }
                }
            }

            foreach (var actionDone in actionsDone)
            {
                if (actionDone.Value)
                {
                    RegisterMaterialLabelPrinted(actionDone.Key, mainMaterial.Step);
                }
            }
        }

        /// <summary>
        /// Indicates if a material is configured for automatic printing on a given printing sequence
        /// </summary>
        /// <param name="material"></param>
        /// <param name="printingSequence"></param>
        /// <param name="printSourceMaterial"></param>
        /// <param name="resource"></param>
        /// <returns></returns>
        public bool HasAutomaticPrinting(IMaterial material, string printingSequence, out bool printSourceMaterial, IResource resource = null)
        {
            bool returnVeridict = false;
            printSourceMaterial = false;

            DataSet ds = ResolveAutoPrintingContextSmartTable(material, printingSequence, resource: resource);

            if (ds != null && ds.HasData())
            {
                // for printing to be considered enabled for this sequence, dataset must not be null and have data...
                returnVeridict = (ds.Tables[0].Rows[0][IKEAConstants.CustomAutomaticPrintableDocumentContextIsEnabledCol] == DBNull.Value) ? false : (bool)ds.Tables[0].Rows[0][IKEAConstants.CustomAutomaticPrintableDocumentContextIsEnabledCol];
                printSourceMaterial = (ds.Tables[0].Rows[0][IKEAConstants.CustomAutomaticPrintableDocumentContextPrintSourceSplitMaterialCol] == DBNull.Value) ? false : (bool)ds.Tables[0].Rows[0][IKEAConstants.CustomAutomaticPrintableDocumentContextPrintSourceSplitMaterialCol];
            }

            return returnVeridict;
        }

        /// <summary>
        /// Get DatatSet with the resolution of the SmartTable CustomAutomaticPrintableDocumentContext
        /// </summary>
        /// <param name="material"></param>
        /// <param name="printingSequence"></param>
        /// <param name="step"></param>
        /// <param name="resource"></param>
        /// <returns></returns>
        public DataSet ResolveAutoPrintingContextSmartTable(IMaterial material, string printingSequence, IStep step = null, IResource resource = null)
        {
            ISmartTable printContext = new SmartTable();
            printContext.Load(IKEAConstants.CustomAutomaticPrintableDocumentContext);

            INgpDataRow values = new NgpDataRow();
            values.Add(Constants.Step, step != null ? step.Name : material.Step.Name);
            values.Add(IKEAConstants.CustomAutomaticPrintableDocumentContextPrintingSequenceCol, printingSequence);

            if (material.Product == null)
            {
                material.Load();
            }

            if (resource != null)
            {
                values.Add(Constants.Resource, resource.Name);
            }
            else if (material.LastProcessedResource != null)
            {
                values.Add(Constants.Resource, material.LastProcessedResource.Name);
            }

            values.Add(Constants.Product, material.Product.Name);

            if (material.Product.ProductGroup != null)
            {
                values.Add(Constants.ProductGroup, material.Product.ProductGroup.Name);
            }

            if (material.Type != null)
            {
                values.Add(Constants.MaterialType, material.Type);
            }

            DataSet ds = null;
            INgpDataSet nds = printContext.FirstResolveOrder(values);
            if (nds != null)
            {
                ds = NgpDataSet.ToDataSet(nds);
            }

            if (ds == null || material.Product != null)
            {
                string baseProductName = material.Product.GetRelatedAttributeValueOrDefault<string>(IKEAConstants.CustomProductAttributeBaseProduct, true);

                //Try to resolve using BaseProduct
                if (!String.IsNullOrWhiteSpace(baseProductName))
                {
                    nds = _genericUtilities.ResolveBaseProduct(baseProductName, printContext, values, nds, true);

                    if (nds != null)
                    {
                        ds = NgpDataSet.ToDataSet(nds);
                    }
                }
            }

            return ds;
        }

        /// <summary>
        /// Creates and prints a label based on SmartTable configuration and input parameters
        /// </summary>
        /// <param name="material"></param>
        /// <param name="step"></param>
        /// <param name="printingSequence"></param>
        /// <param name="resource"></param>
        /// <param name="product"></param>
        /// <param name="printableDocument"></param>
        public void ResolveAndPrintAutomaticPrintableDocumentsCutting(IMaterial material, IStep step, string printingSequence, IResource resource, IProduct product, IPrintableDocument printableDocument)
        {
            ISmartTable printContext = new SmartTable();
            printContext.Load(IKEAConstants.CustomAutomaticPrintableDocumentContext);

            INgpDataRow values = new NgpDataRow();
            values.Add(Constants.Step, step.Name);
            values.Add(IKEAConstants.CustomAutomaticPrintableDocumentContextPrintingSequenceCol, printingSequence);

            if (resource != null)
            {
                values.Add(Constants.Resource, resource.Name);
            }

            if (product != null)
            {
                values.Add(Constants.Product, product.Name);
            }

            INgpDataSet nds = printContext.FirstResolveOrder(values);

            if (product != null)
            {
                string baseProductName = product.GetRelatedAttributeValueOrDefault<string>(IKEAConstants.CustomProductAttributeBaseProduct, true);
                //Try to resolve using BaseProduct
                nds = _genericUtilities.ResolveBaseProduct(baseProductName, printContext, values, nds, true);
            }

            if (nds != null)
            {
                DataSet ds = NgpDataSet.ToDataSet(nds);
                if (ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                {
                    bool resourceUsed = false;
                    bool productUsed = false;

                    Dictionary<string, Tuple<IPrintableDocumentCollection, Dictionary<int, Dictionary<string, object>>>> docsToPrintByPrinter = new Dictionary<string, Tuple<IPrintableDocumentCollection, Dictionary<int, Dictionary<string, object>>>>();
                    foreach (DataRow row in ds.Tables[0].Rows)
                    {
                        bool isEnabled = (row[IKEAConstants.CustomAutomaticPrintableDocumentContextIsEnabledCol] == null) ? false : (bool)row[IKEAConstants.CustomAutomaticPrintableDocumentContextIsEnabledCol];

                        if (isEnabled)
                        {

                            //if we have lines with and lines without product print only the ones with product.
                            if (!string.IsNullOrWhiteSpace(row[Constants.Product] as string))
                            {
                                productUsed = true;
                            }
                            else if (productUsed)
                            {
                                break;
                            }

                            //if we have lines with and lines without resource print only the ones with resource.
                            if (!string.IsNullOrWhiteSpace(row[Constants.Resource] as string))
                            {
                                resourceUsed = true;
                            }
                            else if (resourceUsed)
                            {
                                break;
                            }

                            IPrintableDocument printDoc = printableDocument;
                            string printer = row[IKEAConstants.CustomAutomaticPrintableDocumentContextPrinterCol] as string;

                            CustomPrintingOptionsEnum printingOptionsEnum = (CustomPrintingOptionsEnum)int.Parse(row["PrintOptions"].ToString());

                            IPrintableDocumentCollection docsToPrint = null;
                            Dictionary<int, Dictionary<string, object>> totalParams = null;

                            // separate printable documents by different printers.
                            if (!docsToPrintByPrinter.ContainsKey(printer) &&
                               (printingOptionsEnum.Equals(CustomPrintingOptionsEnum.Label) || printingOptionsEnum.Equals(CustomPrintingOptionsEnum.Both)))
                            {
                                docsToPrintByPrinter.Add(printer, new Tuple<IPrintableDocumentCollection, Dictionary<int, Dictionary<string, object>>>(_entityFactory.CreateCollection<IPrintableDocumentCollection>(), new Dictionary<int, Dictionary<string, object>>()));
                            }

                            if (docsToPrintByPrinter.Count > 0)
                            {
                                var docsToPrintTuple = docsToPrintByPrinter[printer];
                                docsToPrint = docsToPrintTuple.Item1;
                                totalParams = docsToPrintTuple.Item2;

                                Dictionary<string, object> parameters = PreparePrintDocuments(printDoc, printer, material);
                                if (parameters != null && parameters.Count > 0)
                                {
                                    totalParams.Add(totalParams.Count, parameters);
                                    docsToPrint.Add(printDoc);
                                }
                            }
                        }
                    }

                    // Print one PrintableDocumentCollection at a time
                    foreach (var docsToPrintTuple in docsToPrintByPrinter?.Values)
                    {
                        IPrintableDocumentCollection docsToPrint = docsToPrintTuple.Item1;
                        Dictionary<int, Dictionary<string, object>> totalParams = docsToPrintTuple.Item2;
                        PrintDocuments(docsToPrint, material, totalParams);
                    }
                }
            }
            else
            {
                throw new IKEAException(IKEAConstants.CustomLabelPrintingConfigNotFoundLocalizedMessage, IKEAConstants.CustomAutomaticPrintableDocumentContext);
            }
        }

        public void RegisterMaterialLabelPrinted(IMaterial material, IStep step)
        {
            step.Load();
            step.LoadAttributes();
            string attrValue = step.HasAttribute(IKEAConstants.CustomPrintOptions, true) ? step.Attributes[IKEAConstants.CustomPrintOptions].ToString() : CustomPrintingOptionsEnum.None.ToString();

            // If the print options is rfid or both it prints the rfid and sets the material attribute
            if (!attrValue.Equals(CustomPrintingOptionsEnum.None.ToString()))
            {
                IAttributeCollection attributes = new AttributeCollection
                {
                    { IKEAConstants.CustomIsRfidOrLabelPrinted, true }
                };
                material.SaveAttributes(attributes);
            }
        }

        public void RegisterMaterialLabelPrinted(Dictionary<IMaterial, IStep> materialAndSteps)
        {
            IMaterialCollection materialsToSave = _entityFactory.CreateCollection<IMaterialCollection>();

            if (materialAndSteps != null && materialAndSteps.Count > 0)
            {
                var eligibleMaterialsAndSteps = materialAndSteps.Where(E => E.Value != null && E.Value.Id > 0);
                var eligibleStepRecords = eligibleMaterialsAndSteps.Select(E => E.Value.Id).Distinct();
                IStepCollection allSteps = _entityFactory.CreateCollection<IStepCollection>();
                allSteps.LoadByIDs<IStep, Step>(eligibleStepRecords.ToList());
                allSteps.ToDictionary(E => E.Id, E => E);
                allSteps.LoadAttributes(new Collection<string>() { IKEAConstants.CustomPrintOptions });

                string noPrintingEnumVal = CustomPrintingOptionsEnum.None.ToString();

                foreach (IStep step in allSteps)
                {
                   //var printOption = step.GetAttributeValue(IKEAConstants.CustomPrintOptions, false);
                    if (step.HasAttribute(IKEAConstants.CustomPrintOptions, false)
                        && !string.IsNullOrWhiteSpace(Convert.ToString(step.GetAttributeValue(IKEAConstants.CustomPrintOptions, false)))
                        && !string.Equals(noPrintingEnumVal, Convert.ToString(step.GetAttributeValue(IKEAConstants.CustomPrintOptions, false)), StringComparison.InvariantCultureIgnoreCase))
                    {
                        materialsToSave.AddRange(eligibleMaterialsAndSteps.Where(E => E.Value.Id == step.Id).Select(E => E.Key));
                    }
                }
            }

            if (materialsToSave != null)
            {
                materialsToSave.SaveAttributes(new AttributeCollection
                {
                    { IKEAConstants.CustomIsRfidOrLabelPrinted, true }
                });
            }
        }

        /// <summary>
        /// This method creates a timer to trigger printing of labels
        /// </summary>
        public void GeneratePrintingTimers(List<Tuple<IMaterial, IStep, IResource>> materialsToPrintStep, string triggeringSequence)
        {
            if (materialsToPrintStep != null && materialsToPrintStep.Count > 0 && !String.IsNullOrWhiteSpace(triggeringSequence))
            {
                IRule ruleToExecute = _entityFactory.Create<IRule>();
                ruleToExecute.Load("CustomExecutePrintingTask");

                ICmfTimer timerToCreate = null;
                foreach (var element in materialsToPrintStep)
                {
                    IMaterial materialToPrint = element.Item1;
                    IStep materialStep = element.Item2;
                    IResource materialResource = element.Item3;

                    timerToCreate = _entityFactory.Create<ICmfTimer>();
                    timerToCreate.Name = String.Format("{0}_{1}_{2}_{3}_{4}"
                                                        , IKEAConstants.CustomExecutePrintingTask
                                                        , Guid.NewGuid().ToString().Replace("-", "").Replace("{", "").Replace("}", "")
                                                        , materialToPrint.Id
                                                        , materialStep.Id
                                                        , triggeringSequence);
                    timerToCreate.Description = String.Format("Automatically generated label printing timer for {0}{1} on Step {2}. TriggerSequence: {3}"
                                                                    , materialToPrint.Form, materialToPrint.Name, materialStep.Name, triggeringSequence);
                    timerToCreate.IsEnabled = true;
                    timerToCreate.Start = DateTime.Now.AddSeconds(2); // The start date needs to be a date after the timer is created
                    timerToCreate.Recurrence = CmfTimerRecurrence.OneTime;
                    timerToCreate.RecurrenceDefinedFrequency = 1;
                    timerToCreate.RecurrenceDefinedSeconds = 0;
                    timerToCreate.Rule = ruleToExecute;
                    timerToCreate.Scope = CmfTimerScope.General;
                    timerToCreate.SendEmailOnError = false;

                    if (materialResource != null)
                    {
                        timerToCreate.Attributes[IKEAConstants.CmfTimerAttributePrintCustomResource] = materialResource.Name;
                    }

                    timerToCreate.Create();
                }
            }
        }
    }
}
