﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.SmartTables;
using Cmf.Foundation.Common;
using Cmf.Foundation.Security;
using Cmf.Navigo.BusinessObjects;
using Cmf.Custom.IKEA.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Foundation.Security.Abstractions;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Common.CustomActionUtilities;
using Cmf.Foundation.BusinessObjects.QueryObject;
using Cmf.Foundation.BusinessOrchestration.GenericServiceManagement;
using Cmf.Foundation.BusinessOrchestration.GenericServiceManagement.InputObjects;
using Cmf.Custom.IKEA.BusinessObjects;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Foundation.BusinessOrchestration.Abstractions;
using INotification = Cmf.Navigo.BusinessObjects.Abstractions.INotification;

namespace Cmf.Custom.IKEA.Common.Utilities
{
    public class AlarmHandlingUtilities : IAlarmHandlingUtilities
    {
        private IEntityFactory _entityFactory;
        private IIKEAUtilities _iKEAUtilities;
        private IGenericUtilities _genericUtilities;
        private IGenericServiceOrchestration _genericServiceOrchestration;
        [Microsoft.Extensions.DependencyInjection.ActivatorUtilitiesConstructor]
        public AlarmHandlingUtilities(IEntityFactory entityFactory,
            IGenericUtilities genericUtilities,
            IGenericServiceOrchestration genericServiceOrchestration,
            IIKEAUtilities iKEAUtilities)
        {
            _entityFactory = entityFactory;
            _genericUtilities = genericUtilities;
            _genericServiceOrchestration = genericServiceOrchestration;
            _iKEAUtilities = iKEAUtilities;
        }
        /// <summary>
        /// Resolve CustomAlarmHandlingActions Smart Table
        /// </summary>
        /// <param name="alarmCode"></param>
        /// <param name="alarmCategory"></param>
        /// <param name="topMostResourceName"></param>
        /// <param name="areaName"></param>
        /// <param name="facilityName"></param>
        /// <returns>DataRow when data is defined, otherwise null</returns>
        public DataRow ResolveCustomAlarmHandlingActions(String alarmCode, String alarmCategory, String topMostResourceName, String areaName, String facilityName)
        {
            //Validate if provided eligible for any configured handling action against smart table CustomAlarmHandlingActions
            ISmartTable customAlarmHandlingActions = _entityFactory.Create<ISmartTable>();
            customAlarmHandlingActions.Load(IKEAConstants.CustomAlarmHandlingActionsSmartTable);

            //Create NgpDataRow with the configuration to be tested against the SmartTable
            NgpDataRow values = new NgpDataRow
            {
                { IKEAConstants.CustomAlarmHandlingActionsFacilityColumn, facilityName },
                { IKEAConstants.CustomAlarmHandlingActionsAreaColumn, areaName },
                { IKEAConstants.CustomAlarmHandlingActionsResourceColumn, topMostResourceName },
                { IKEAConstants.CustomAlarmHandlingActionsAlarmCodeColumn, alarmCode },
                { IKEAConstants.CustomAlarmHandlingActionsCategoryColumn, alarmCategory }
            };
            //Resolve the smartTable 
            INgpDataSet nds = customAlarmHandlingActions.Resolve(values, false);

            if (nds == null)
            {
                return null;
            }

            //If the configuration was successfully found on the SmartTable
            DataSet ds = NgpDataSet.ToDataSet(nds);

            //Resolving SmartTable return only one row so we can access the Row[0]
            return ds.HasData() ? ds.Tables[0].Rows[0] : null;
        }

        /// <summary>
        /// Handle alarm occurence
        /// </summary>
        /// <param name="AlarmCode"></param>
        /// <param name="AlarmCategory"></param>
        /// <param name="Resource"></param>
        /// <param name="TopMostResource"></param>
        /// <param name="Area"></param>
        /// <param name="Facility"></param>
        public void AlarmOccurrenceHandlingUtility(DataRow row, ICustomAlarmOccurrence alarm, String alarmCode, String alarmCategory, String resourceName, String topMostResourceName, String areaName, String facilityName, String adminNotificationDetails)
        {
            if (row != null)
            {
                //List of emails to be notified of a given alarm
                List<string> checkedInUserEmails = new List<string>();
                IEmployeeCollection employeesToBeNotified = _entityFactory.CreateCollection<IEmployeeCollection>();

                #region Setup notification contents
                //Notification to be sent when the alarm is on the TopMost resource
                string topMostAlarmNotificationContent = _iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomTopMostResourceAlarmLoggedLocalizedMessage
                    , alarmCode
                    , alarmCategory
                    , topMostResourceName
                    , areaName
                    , facilityName);
                //Notification to be sent when the alarm is on a SubResource
                string subResourceAlarmNotificationContent = _iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomSubResourceAlarmLoggedLocalizedMessage
                  , alarmCode
                  , alarmCategory
                  , topMostResourceName
                  , resourceName
                  , areaName
                  , facilityName);

                //Get checkedInEmplyees emails on the TopMost Resource to send the Alarm
                if (!string.IsNullOrWhiteSpace(topMostResourceName))
                {
                    checkedInUserEmails = GetCheckedInUserEmails(resourceName: topMostResourceName);
                    employeesToBeNotified = _genericUtilities.GetCheckedInEmployees(topMostResourceName);
                }

                // Check if any role was defined
                IRole role = new Role();
                if (!string.IsNullOrWhiteSpace(row.Field<string>(IKEAConstants.NotificatonRole)))
                {
                    role.Name = row.Field<string>(IKEAConstants.NotificatonRole);
                }
                #endregion

                NotificationsHandling(resourceName, topMostResourceName, checkedInUserEmails, employeesToBeNotified, topMostAlarmNotificationContent, subResourceAlarmNotificationContent, row, role, adminNotificationDetails, alarmCode);

                //Block all produces units for the MO's InProcess on the TopMost resource
                if (row[IKEAConstants.BlockProducedUnits] != null && !String.IsNullOrWhiteSpace(row[IKEAConstants.BlockProducedUnits].ToString()) && row.Field<bool>(IKEAConstants.BlockProducedUnits))
                {
                    //invoke HoldManufacturingOrder on TopMost Resource
                    IResource resource = _genericUtilities.GetEntityByName<IResource>(topMostResourceName);
                    resource.LoadRelations(Constants.MaterialResource);
                    //get all materials at top most ressource
                    IMaterialCollection materialsAtResource = _entityFactory.CreateCollection<IMaterialCollection>();
                    if (resource.RelationCollection.ContainsKey(Constants.MaterialResource))
                    {
                        materialsAtResource.AddRange(resource.RelationCollection[Constants.MaterialResource].Select(ET => ET.SourceEntity as IMaterial).ToList());
                        //Apply hold on all MO's in process on the ressource
                        string reasonToUse = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.AlarmHandlingHoldReason);

                        foreach (IMaterial materialAtRessource in materialsAtResource)
                        {
                            _iKEAUtilities.HoldManufacturingOrder(materialAtRessource, reasonToUse, isToHoldCurrentMaterial: false, isToHoldMOitself: false); ;
                        }
                    }
                }

                if (alarm != null && alarm.Id > 0 && row[IKEAConstants.MaintenanceActivity] != null && !String.IsNullOrWhiteSpace(row[IKEAConstants.MaintenanceActivity].ToString()))
                {
                    //Create a new Maintenance Activity Order if there is none active for Resource
                    _iKEAUtilities.ResourceMAOHandling(resourceName, row[IKEAConstants.MaintenanceActivity].ToString(), alarm);
                }
            }
        }

        /// <summary>
        /// Retrieves all active alarms for an entire line through topmost resource
        /// </summary>
        /// <param name="resource"></param>
        /// <returns>List of CustomAlarmOccurrence</returns>
        public List<ICustomAlarmOccurrence> GetLineActiveAlarms(IResource topMostResource)
        {
            IQueryObject query = new QueryObject();
            query.Description = "";
            query.EntityTypeName = "CustomAlarmOccurrence";
            query.Name = "CustomGetLineActiveAlarms";
            query.Query = new Query();
            query.Query.Distinct = false;
            query.Query.Filters = new FilterCollection() {
                new Filter()
                {
                    Name = "Name",
                    ObjectName = "Resource",
                    ObjectAlias = "CustomAlarmOccurrence_TopMostResource_2",
                    Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                    Value = topMostResource.Name,
                    LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND,
                    FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                },
                new Filter()
                {
                    Name = "UniversalState",
                    ObjectName = "CustomAlarmOccurrence",
                    ObjectAlias = "CustomAlarmOccurrence_1",
                    Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                    Value = 2,
                    LogicalOperator = Cmf.Foundation.Common.LogicalOperator.Nothing,
                    FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                }
            };
            query.Query.Fields = new FieldCollection() {
                new Field()
                {
                    Alias = "Id",
                    ObjectName = "CustomAlarmOccurrence",
                    ObjectAlias = "CustomAlarmOccurrence_1",
                    IsUserAttribute = false,
                    Name = "Id",
                    Position = 0,
                    Sort = Cmf.Foundation.Common.FieldSort.NoSort
                },
                new Field()
                {
                    Alias = "Name",
                    ObjectName = "CustomAlarmOccurrence",
                    ObjectAlias = "CustomAlarmOccurrence_1",
                    IsUserAttribute = false,
                    Name = "Name",
                    Position = 1,
                    Sort = Cmf.Foundation.Common.FieldSort.NoSort
                }
            };
            query.Query.Relations = new RelationCollection() {
                new Relation()
                {
                    Alias = "",
                    IsRelation = false,
                    Name = "",
                    SourceEntity = "CustomAlarmOccurrence",
                    SourceEntityAlias = "CustomAlarmOccurrence_1",
                    SourceJoinType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.JoinType.InnerJoin,
                    SourceProperty = "TopMostResourceId",
                    TargetEntity = "Resource",
                    TargetEntityAlias = "CustomAlarmOccurrence_TopMostResource_2",
                    TargetJoinType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.JoinType.InnerJoin,
                    TargetProperty = "Id"
                }
            };

            DataSet resultDataSet = query.Execute(false, new QueryParameterCollection());
            if (resultDataSet.HasData() && resultDataSet.Tables.Count > 0 && resultDataSet.Tables[0].Rows.Count > 0)
            {
                List<string> alarmNames = new List<string>();

                foreach (DataRow row in resultDataSet.Tables[0].Rows)
                {
                    alarmNames.Add(row.Field<string>("Name"));
                }

                Filter filter = new Filter()
                {
                    Name = "Name",
                    ObjectName = "CustomAlarmOccurrence",
                    Operator = FieldOperator.In,
                    Value = alarmNames,
                    LogicalOperator = LogicalOperator.Nothing,
                    FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal
                };

                FilterCollection filterColl = new FilterCollection() { filter };
                return _genericServiceOrchestration.GetObjectsByFilter(
                    new GetObjectsByFilterInput()
                    {
                        Filter = filterColl,
                        Type = _entityFactory.Create<ICustomAlarmOccurrence>()
                    }
                ).Instance.Cast<ICustomAlarmOccurrence>().ToList();
            }
            return null;
        }

        /// <summary>
        /// Handle Notifications to be sent when an Alarm occurs
        /// </summary>
        /// <param name="resourceName"></param>
        /// <param name="topMostResourceName"></param>
        /// <param name="checkedInUserEmails"></param>
        /// <param name="employeesToBeNotified"></param>
        /// <param name="topMostAlarmNotificationContent"></param>
        /// <param name="subResourceAlarmNotificationContent"></param>
        /// <param name="row"></param>
        /// <param name="role"></param>
        public void NotificationsHandling(string resourceName, string topMostResourceName, List<string> checkedInUserEmails, IEmployeeCollection employeesToBeNotified, string topMostAlarmNotificationContent, string subResourceAlarmNotificationContent, DataRow row, IRole role, String adminNotificationDetails, String alarmCode)
        {
            //Check if MES notification needs to be created
            if (row[IKEAConstants.MESNotification] != null && !String.IsNullOrWhiteSpace(row[IKEAConstants.MESNotification].ToString()) && row.Field<bool>(IKEAConstants.MESNotification))
            {
                // Check if the given role exists
                if (role.ObjectExists())
                {
                    role.Load();
                    //Validate if Severity exists in config
                    string severity = _iKEAUtilities.GetValueFromConfigurationWithPath(IKEAConstants.DefaultNotificationSeverityConfig);

                    if (severity.IsNullOrEmpty())
                    {
                        throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomDefaultNotificationSeverityConfigNotDefined, IKEAConstants.DefaultNotificationSeverityConfig));
                    }

                    // Create Notification
                    INotification notification = _entityFactory.Create<INotification>();

                    notification.Type = "System";
                    notification.Title = _iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomAlarmLoggedTitle, topMostResourceName);
                    notification.Severity = _iKEAUtilities.GetValueFromLookupTable(IKEAConstants.NotificationSeverityLookupTableName, severity, true);
                    notification.AssignmentType = (NotificationAssignmentType)AssignmentType.Role;
                    notification.AssignedToRole = role;
                    //if Email Notification is active > Send Email
                    notification.SendEmailToAssignedParty = (row[IKEAConstants.EmailNotification] != null && !String.IsNullOrWhiteSpace(row[IKEAConstants.EmailNotification].ToString()) && row.Field<bool>(IKEAConstants.EmailNotification));


                    if (role.Name.Equals(IKEAConstants.AdministratorRoleName))
                    {
                        notification.Details = !String.IsNullOrEmpty(adminNotificationDetails) ? adminNotificationDetails : _iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomAlarmLoggedButNotCheckedLocalizedMessage, alarmCode);
                    }
                    else
                    {
                        notification.Details = String.Equals(resourceName, topMostResourceName, StringComparison.InvariantCultureIgnoreCase) ? topMostAlarmNotificationContent : subResourceAlarmNotificationContent;
                    }

                    notification.Create();
                }
                //For each checked in user if NotifyCheckedInEmployees active
                if (row[IKEAConstants.NotifyCheckedInEmployees] != null && !String.IsNullOrWhiteSpace(row[IKEAConstants.NotifyCheckedInEmployees].ToString()) && row.Field<bool>(IKEAConstants.NotifyCheckedInEmployees))
                {
                    if (employeesToBeNotified.Count > 0)
                    {
                        //Validate if Severity exists in config
                        string severity = _iKEAUtilities.GetValueFromConfigurationWithPath(IKEAConstants.DefaultNotificationSeverityConfig);

                        if (severity.IsNullOrEmpty())
                        {
                            throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomDefaultNotificationSeverityConfigNotDefined, IKEAConstants.DefaultNotificationSeverityConfig));
                        }
                        // Create Notification
                        foreach (IEmployee employee in employeesToBeNotified)
                        {
                            employee.Load();
                            INotification notification = _entityFactory.Create<INotification>();

                            notification.Type = "System";
                            notification.Title = _iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomAlarmLoggedTitle, topMostResourceName);
                            notification.Details = String.Equals(resourceName, topMostResourceName, StringComparison.InvariantCultureIgnoreCase) ? topMostAlarmNotificationContent : subResourceAlarmNotificationContent;
                            notification.Severity = _iKEAUtilities.GetValueFromLookupTable(IKEAConstants.NotificationSeverityLookupTableName, severity, true);
                            notification.AssignmentType = (NotificationAssignmentType)AssignmentType.Employee;
                            notification.AssignedToUser = employee.User;
                            notification.SendEmailToAssignedParty = false;
                            
                            notification.Create();
                        }
                    }
                    //send email to the checkedIn users
                    try
                    {
                        //Set option to send e-mail if EmailNotification is active
                        if (checkedInUserEmails.Count > 0 && row[IKEAConstants.EmailNotification] != null && !String.IsNullOrWhiteSpace(row[IKEAConstants.EmailNotification].ToString()) && row.Field<bool>(IKEAConstants.EmailNotification))
                        {
                            SendEmail(emailTo: string.Join(",", checkedInUserEmails),
                                      emailSubject: _iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomAlarmLoggedTitle, topMostResourceName),
                                      emailMessage: String.Equals(resourceName, topMostResourceName, StringComparison.InvariantCultureIgnoreCase) ? topMostAlarmNotificationContent : subResourceAlarmNotificationContent,
                                      emailIsBodyHTML: true);
                        }
                    }
                    catch (Exception)
                    {
                        //Email sending error message
                        throw new CmfBaseException(IKEAConstants.CustomEmailSendError);
                    }
                }
            }

            //If MES Notification is not Active but EmailNotification is active
            else if (row[IKEAConstants.EmailNotification] != null && !String.IsNullOrWhiteSpace(row[IKEAConstants.EmailNotification].ToString()) && row.Field<bool>(IKEAConstants.EmailNotification))
            {
                //Send e-mail for Notificaton Role if defined
                if (role.ObjectExists())
                {
                    role.Load();
                    try
                    {
                        if (!string.IsNullOrWhiteSpace(role.DistributionList))
                        {
                            SendEmail(emailTo: role.DistributionList,
                                      emailSubject: _iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomAlarmLoggedTitle, topMostResourceName),
                                      emailMessage: String.Equals(resourceName, topMostResourceName, StringComparison.InvariantCultureIgnoreCase) ? topMostAlarmNotificationContent : subResourceAlarmNotificationContent,
                                      emailIsBodyHTML: true);
                        }
                    }
                    catch (Exception)
                    {
                        throw new CmfBaseException(IKEAConstants.CustomEmailSendError);
                    }
                }
                //Send e-mail for each checked in user if NotifyCheckedInEmployees active
                if (row[IKEAConstants.NotifyCheckedInEmployees] != null && !String.IsNullOrWhiteSpace(row[IKEAConstants.NotifyCheckedInEmployees].ToString()) && row.Field<bool>(IKEAConstants.NotifyCheckedInEmployees))
                {
                    //Send email to All CheckedIn Users
                    try
                    {
                        if (checkedInUserEmails.Count > 0)
                        {
                            SendEmail(emailTo: String.Join(",", checkedInUserEmails),
                                       emailSubject: _iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomAlarmLoggedTitle, topMostResourceName),
                                      emailMessage: String.Equals(resourceName, topMostResourceName, StringComparison.InvariantCultureIgnoreCase) ? topMostAlarmNotificationContent : subResourceAlarmNotificationContent,
                                      emailIsBodyHTML: true);
                        }
                    }
                    catch (Exception)
                    {
                        //Email sending error message
                        throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomEmailSendError));
                    }
                }
            }
        }

        /// <summary>
        /// Smart table that checks, for a specific context, if the alarm has to be logged in MES
        /// </summary>
        /// <param name="facilityName"></param>
        /// <param name="areaName"></param>
        /// <param name="resourceName"></param>
        /// <param name="alarmCode"></param>
        /// <param name="category"></param>
        /// <returns></returns>
        public bool? ResolveCustomAlarmTrackingConfiguration(string facilityName = null, string areaName = null, string resourceName = null, string alarmCode = null, string category = null)
        {
            bool? result = null;

            ISmartTable smartTable = new SmartTable();
            smartTable.Load(IKEAConstants.CustomAlarmTrackingConfigurationSmartTable);

            INgpDataRow values = new NgpDataRow();

            if (facilityName != null)
            {
                values.Add(IKEAConstants.CustomAlarmTrackingConfigurationFacilityColumn, facilityName);
            }
            if (areaName != null)
            {
                values.Add(IKEAConstants.CustomAlarmTrackingConfigurationAreaColumn, areaName);
            }
            if (resourceName != null)
            {
                values.Add(IKEAConstants.CustomAlarmTrackingConfigurationResourceColumn, resourceName);
            }
            if (alarmCode != null)
            {
                values.Add(IKEAConstants.CustomAlarmTrackingConfigurationAlarmCodeColumn, alarmCode);
            }
            if (category != null)
            {
                values.Add(IKEAConstants.CustomAlarmTrackingConfigurationCategoryColumn, category);
            }

            INgpDataSet ngpDataSet = smartTable.Resolve(values, true);
            if (ngpDataSet != null)
            {
                DataSet dataSet = NgpDataSet.ToDataSet(ngpDataSet);
                if (dataSet.HasData())
                {
                    result = dataSet.Tables[0].Rows[0][IKEAConstants.CustomAlarmTrackingConfigurationLogColumn] as bool?;
                }
            }

            return result;
        }

        /// <summary>
        /// Retrieves the list of Mail addresses of checkedIn users on a given Resource
        /// </summary>
        /// <param name="resourceName"></param>
        /// <returns>checkedInUserEmailList</returns>
        public List<string> GetCheckedInUserEmails(string resourceName)
        {
            List<string> checkedInUserEmailList = new List<string>();

            if (resourceName != null)
            {
                //Load resource received as parameter
                IResource resource = _genericUtilities.GetEntityByName<IResource>(resourceName);
                resource.LoadRelations("ResourceEmployee");
                //This relation grants that the Employee is checkedIn on the Resource
                if (resource.RelationCollection.ContainsKey("ResourceEmployee"))
                {
                    IEmployeeCollection employeeColection = _entityFactory.CreateCollection<IEmployeeCollection>();
                    employeeColection.AddRange(resource.RelationCollection["ResourceEmployee"].Select(ET => ET.TargetEntity as IEmployee).ToList());
                    //Load employees to get the list of Users
                    if (employeeColection != null && employeeColection.Any())
                    {
                        employeeColection.Load();
                        IUserCollection userCollection = new UserCollection();
                        userCollection.AddRange(employeeColection.Select(ET => ET.User as IUser).ToList());
                        //Load all users to get the MailAddress property
                        // UserCollection does not have the Load method
                        foreach (IUser usr in userCollection)
                        {
                            usr.Load();
                        }
                        checkedInUserEmailList.AddRange(userCollection.Where(ET => !string.IsNullOrWhiteSpace(ET.MailAddress)).Select(ET => ET.MailAddress).ToList());
                    }
                }
            }
            //Return the list of MailAdresses
            return checkedInUserEmailList;
        }

       
        /// <summary>
        /// Send email to a given list of users
        /// </summary>
        /// <param name="emailTo"></param>
        /// <param name="emailSubject"></param>
        /// <param name="emailMessage"></param>
        /// <param name="emailIsBodyHTML"></param>
        public void SendEmail(string emailTo, string emailSubject, string emailMessage, bool emailIsBodyHTML)
        {
            //Create a new CMFEmail with the configurations received
            CmfMail emailItem = new CmfMail();
            emailItem.To = emailTo;
            emailItem.Subject = emailSubject;
            emailItem.Message = emailMessage;
            emailItem.IsBodyHtml = emailIsBodyHTML;
            emailItem.SendMail();
        }

        /// <summary>
        /// Set Alarm Ack Date in alarm
        /// </summary>
        /// <param name="alarmOccurrence"></param>
        public void SetAlarmAckDateIfEmpty(ICustomAlarmOccurrence alarmOccurrence, DateTime? ackDateTime)
        {
            DateTime alarmAck = alarmOccurrence.GetAttributeValueOrDefault<DateTime>("AlarmAck", loadAttribute: true);
            if (alarmAck == null || alarmAck == DateTime.MinValue)
            {
                alarmOccurrence.Attributes["AlarmAck"] = ackDateTime;
                alarmOccurrence.SaveAttributes(alarmOccurrence.Attributes);
            }
        }
    }
}