﻿using System;
using System.Collections.Generic;
using System.Linq;
using Cmf.Foundation.Common;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Custom.IKEA.Common.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using Cmf.Foundation.Common.Abstractions;

namespace Cmf.Custom.IKEA.Common
{
    /// <summary>
    /// Utility class for caching repeated load calls for the same entity
    /// </summary>
    public class EntityCache
    {
        protected Dictionary<Type, Dictionary<long, object>> entitiesById = new Dictionary<Type, Dictionary<long, object>>();

        protected Dictionary<Type, Dictionary<string, object>> entitiesByName = new Dictionary<Type, Dictionary<string, object>>();
        private static IServiceProvider serviceProvider => ApplicationContext.CurrentServiceProvider.GetService<IServiceProvider>();

        /// <summary>
        /// Returns true if this entity Id is already cached
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="id"></param>
        /// <returns></returns>
        public bool HasCached<T>(long id)
        {
            Dictionary<long, object> dictionary;

            if (!entitiesById.TryGetValue(typeof(T), out dictionary))
            {
                return false;
            }

            return dictionary.ContainsKey(id);
        }

        /// <summary>
        /// Returns true if this entity Name is already cached
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="name"></param>
        /// <returns></returns>
        public bool HasCached<T>(string name)
        {
            Dictionary<string, object> dictionary;

            if (!entitiesByName.TryGetValue(typeof(T), out dictionary))
            {
                return false;
            }

            return dictionary.ContainsKey(name);
        }

        /// <summary>
        /// Helper method responsible for adding one instance to the cache
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="dictionaryIds"></param>
        /// <param name="dictionaryNames"></param>
        /// <param name="instance"></param>
        /// <param name="loadedByName"></param>
        protected void AddToCache<T>(Dictionary<long, object> dictionaryIds, Dictionary<string, object> dictionaryNames, T instance, bool loadedByName = false) where T : IEntity
        {
            dictionaryIds[instance.Id] = instance;

            if (loadedByName)
            {
                dictionaryNames[instance.Name] = instance;
            }
            else
            {
                #region Update the name dictionary if needed
                bool isVersioned = instance.EntityType.IsVersioned;

                if ((isVersioned && instance.UniversalState == Foundation.Common.Base.UniversalState.Effective) ||
                    (!isVersioned && instance.UniversalState == Foundation.Common.Base.UniversalState.Active))
                {
                    dictionaryNames[instance.Name] = instance;
                }
                #endregion
            }
        }

        /// <summary>
        /// Manually add an entity to the cache
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="instances"></param>
        /// <param name="loadedByName"></param>
        public void AddToCache<T>(IEnumerable<T> instances, bool loadedByName = false) where T : IEntity
        {
            Dictionary<long, object> dictionaryIds;
            Dictionary<string, object> dictionaryNames;

            if (!entitiesById.TryGetValue(typeof(T), out dictionaryIds))
            {
                dictionaryIds = new Dictionary<long, object>();

                entitiesById.Add(typeof(T), dictionaryIds);
            }

            if (!entitiesByName.TryGetValue(typeof(T), out dictionaryNames))
            {
                dictionaryNames = new Dictionary<string, object>();

                entitiesByName.Add(typeof(T), dictionaryNames);
            }

            foreach (T instance in instances)
            {
                AddToCache(dictionaryIds, dictionaryNames, instance, loadedByName);
            }
        }


        /// <summary>
        /// Retrieves a reusable entity based on their Name, from memory if possible, or loading it from the database if needed.
        /// If the name passed is null or empty, return null too.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="id"></param>
        /// <returns></returns>
        public T TryFetch<T>(string name) where T : IEntity
        {
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            if (string.IsNullOrEmpty(name))
            {
                return entityFactory.Create<T>();
            }

            return Fetch<T>(name);
        }

        /// <summary>
        /// Retrieves a reusable entity based on their Id, from memory if possible, or loading it from the database if needed.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="id"></param>
        /// <returns></returns>
        public T Fetch<T>(long id) where T : IEntity
        {
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            Dictionary<long, object> dictionary = null;

            if (!entitiesById.TryGetValue(typeof(T), out dictionary))
            {
                dictionary = new Dictionary<long, object>();

                entitiesById.Add(typeof(T), dictionary);
            }

            object objectInstance = null;

            if (!dictionary.TryGetValue(id, out objectInstance))
            {
                T typedObject = entityFactory.Create<T>();
                typedObject.Load(id);

                dictionary.Add(id, typedObject);

                // For versioned entities, this may happen when `id` is the definition Id
                if (typedObject.Id != id)
                {
                    dictionary.Add(typedObject.Id, id);
                }

                #region Update the name dictionary if needed
                bool isVersioned = typedObject.EntityType.IsVersioned;

                if ((isVersioned && typedObject.UniversalState == Foundation.Common.Base.UniversalState.Effective) ||
                    (!isVersioned && typedObject.UniversalState == Foundation.Common.Base.UniversalState.Active))
                {
                    Dictionary<string, object> dictionaryNames;

                    if (!entitiesByName.TryGetValue(typeof(T), out dictionaryNames))
                    {
                        dictionaryNames = new Dictionary<string, object>();

                        entitiesByName.Add(typeof(T), dictionaryNames);
                    }

                    dictionaryNames[typedObject.Name] = typedObject;
                }
                #endregion

                return typedObject;
            }
            else
            {
                return (T)objectInstance;
            }
        }

        /// <summary>
        /// Retrieves a reusable entity based on their Name, from memory if possible, or loading it from the database if needed.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="id"></param>
        /// <returns></returns>
        public T Fetch<T>(string name) where T : IEntity
        {
            Dictionary<string, object> dictionary = null;
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            if (!entitiesByName.TryGetValue(typeof(T), out dictionary))
            {
                dictionary = new Dictionary<string, object>();

                entitiesByName.Add(typeof(T), dictionary);
            }

            object objectInstance = null;

            if (!dictionary.TryGetValue(name, out objectInstance))
            {
                T typedObject = (T)entityFactory.Create<T>();
                if (typedObject is IEntityInstance)
                {
                    (typedObject as IEntityInstance).Load(name);
                }
                else if (typedObject is IEntityVersion)
                {
                    (typedObject as IEntityVersion).Load(name);
                }

                dictionary.Add(name, typedObject);

                #region Update the Id dictionary if needed
                Dictionary<long, object> dictionaryIds = null;

                if (!entitiesById.TryGetValue(typeof(T), out dictionaryIds))
                {
                    dictionaryIds = new Dictionary<long, object>();

                    entitiesById.Add(typeof(T), dictionaryIds);
                }

                dictionaryIds[typedObject.Id] = typedObject;
                #endregion

                return typedObject;
            }
            else
            {
                return (T)objectInstance;
            }
        }

        /// <summary>
        /// Retrieves a reusable entity based on their Id or Name, whichever is available, from memory if possible, 
        /// or loading it from the database if needed. The instance returned may not be the same as the one that is passed as an argument to the function
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="id"></param>
        /// <returns></returns>
        public T Fetch<T>(T entityObject) where T : IEntity
        {
            if (entityObject.Id > 0)
            {
                return Fetch<T>(entityObject.Id);
            }
            else if (entityObject.Name != null)
            {
                return Fetch<T>(entityObject.Name);
            }
            else
            {
                throw new ArgumentNullCmfException("Name and Id");
            }
        }

        /// <summary>
        /// Fetch a list of entities by their Names from the database at once and cache them. If any of them is already cached,
        /// then it is not fetched, and the cached version is returned instead
        /// </summary>
        /// <typeparam name="TC"></typeparam>
        /// <typeparam name="T"></typeparam>
        /// <param name="names"></param>
        /// <returns></returns>
        public TC FetchAll<TC, T>(IEnumerable<string> names) where TC : IEntityCollection<T> where T : IEntity
        {
            List<string> namesList = names.ToList();

            // List of unique names not yet in our cache
            List<string> missingNames = namesList.Where(name => !HasCached<T>(name)).Distinct().ToList();
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            if (missingNames.Any())
            {
                TC uncachedCollection = entityFactory.CreateCollection<TC>();
                uncachedCollection.AddRange(missingNames.Select(name =>
                {
                    var entity = entityFactory.Create<T>();

                    entity.Name = name;

                    return entity;
                }));

                // Call the Load method. The cast to dynamic is needed because EntityInstanceCollection and EntityVersionCollection
                // do not share a common ancestor that has the Load method.
                ((dynamic)uncachedCollection).Load();

                AddToCache(uncachedCollection, true);

                // If the list of uncached, loaded entities is exactly the same as the names requested, return it directly
                // to avoid initializing another list and retrieving each instance from the dictionary
                if (missingNames.Count == namesList.Count)
                {
                    return uncachedCollection;
                }
            }

            TC resultCollection = entityFactory.CreateCollection<TC>();

            resultCollection.AddRange(names.Distinct().Select(Fetch<T>));

            return resultCollection;
        }

        ///// <summary>
        ///// Fetch a list of entities by their Ids from the database at once and cache them. If any of them is already cached,
        ///// then it is not fetched, and the cached version is returned instead
        ///// </summary>
        ///// <typeparam name="TC"></typeparam>
        ///// <typeparam name="T"></typeparam>
        ///// <param name="ids"></param>
        ///// <returns></returns>
        //public TC FetchAll<TC, T>(IEnumerable<long> ids) where TC : IEntityCollection<T>, new() where T : IEntity, new()
        //{
        //    List<long> idsList = ids.ToList();

        //    // List of unique ids not yet in our cache
        //    List<long> missingIds = idsList.Where(id => !HasCached<T>(id)).Distinct().ToList();

        //    if (missingIds.Any())
        //    {
        //        TC uncachedCollection = new TC();
        //        uncachedCollection.LoadByIDs<T, T>(missingIds);

        //        AddToCache(uncachedCollection, false);

        //        // If the list of uncached, loaded entities is exactly the same as the names requested, return it directly
        //        // to avoid initializing another list and retrieving each instance from the dictionary
        //        if (missingIds.Count == idsList.Count)
        //        {
        //            return uncachedCollection;
        //        }
        //    }

        //    TC resultCollection = new TC();

        //    resultCollection.AddRange(ids.Distinct().Select(Fetch<T>));

        //    return resultCollection;
        //}

        /// <summary>
        /// Clears the entire memory cache
        /// </summary>
        public void Clear()
        {
            entitiesById.Clear();
            entitiesByName.Clear();
        }

        /// <summary>
        /// Clears the memory cache for a given Entity type
        /// </summary>
        public void Clear<T>()
        {
            entitiesById.Remove(typeof(T));
            entitiesByName.Remove(typeof(T));
        }
    }
}
