﻿using System;

namespace Cmf.Custom.IKEA.Common.NiceLabel
{
    /// <summary>
    /// Class that represent the base communication integration entry message MES > NiceLabel
    /// </summary>
    [Serializable]
    public class MESNiceLabelCommunication
    {
        /// <summary>
        /// Api endpoint
        /// </summary>
        public string API { get; set; }

        /// <summary>
        /// Json string message 
        /// </summary>
        public string Message { get; set; }

    }
}
