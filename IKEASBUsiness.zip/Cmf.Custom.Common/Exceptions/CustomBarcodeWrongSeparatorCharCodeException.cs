﻿using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Foundation.Common;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Common.Exceptions
{
    /// <summary>
    /// Represents an exception raised when the configuration contains a wrong separator code char
    /// </summary>
    public class CustomBarcodeWrongSeparatorCharCodeException : CmfBaseException
    {

        private static IIKEAUtilities ikeaUtilities => ApplicationContext.CurrentServiceProvider.GetService<IIKEAUtilities>();

        /// <summary>
        /// The default constructor by passing a string message and inner exception
        /// </summary>
        /// <param name="message">The message for the exception</param>
        /// <param name="innerException">The inner exception</param>
        /// <param name="parameters">Message Parameters</param>
        public CustomBarcodeWrongSeparatorCharCodeException(String message, Exception innerException, params String[] parameters)
            : base("100000",
                   8005,
                   String.Format(message, parameters),
                   String.Format(message, parameters),
                   innerException)
        {
        }

        /// <summary>
        /// The default constructor by passing a string message
        /// </summary>
        /// <param name="message">The message for the exception</param>
        /// <param name="parameters">Message Parameters</param>
        public CustomBarcodeWrongSeparatorCharCodeException(params String[] parameters)
            : base("100000",
                   8005,
                   ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomBarcodeExceptionsWrongSeparatorCharCodeLocalizedMessage, parameters),
                   ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomBarcodeExceptionsWrongSeparatorCharCodeLocalizedMessage, parameters))
        {
        }

        /// <summary>
        /// The default constructor by passing a string message and inner exception
        /// </summary>
        /// <param name="message">The message for the exception</param>
        /// <param name="innerException">The inner exception</param>
        /// <param name="parameters">Message Parameters</param>
        public CustomBarcodeWrongSeparatorCharCodeException(Exception innerException, params String[] parameters)
            : base("100000",
                   8005,
                   ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomBarcodeExceptionsWrongSeparatorCharCodeLocalizedMessage, parameters),
                   ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomBarcodeExceptionsWrongSeparatorCharCodeLocalizedMessage, parameters),
                   innerException)
        {
        }
    }
}
