﻿using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Foundation.Common;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Common.Exceptions
{

    /// <summary>
    /// Represents an exception raised when there are no Scanning Configurations configured
    /// </summary>
    public class CustomBarcodeNoScanningConfigurationFoundException : CmfBaseException
    {
        private static IIKEAUtilities ikeaUtilities => ApplicationContext.CurrentServiceProvider.GetService<IIKEAUtilities>();

        /// <summary>
        /// The default constructor by passing a string message and inner exception
        /// </summary>
        /// <param name="message">The message for the exception</param>
        /// <param name="innerException">The inner exception</param>
        /// <param name="parameters">Message Parameters</param>
        public CustomBarcodeNoScanningConfigurationFoundException(String message, Exception innerException, params String[] parameters)
            : base("100000",
                   8001,
                   String.Format(message, parameters),
                   String.Format(message, parameters),
                   innerException)
        {
        }

        /// <summary>
        /// The default constructor by passing a string message
        /// </summary>
        /// <param name="message">The message for the exception</param>
        /// <param name="parameters">Message Parameters</param>
        public CustomBarcodeNoScanningConfigurationFoundException(params String[] parameters)
            : base("100000",
                   8001,
                   ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomBarcodeExceptionsNoScanningConfigurationFoundLocalizedMessage, parameters),
                   ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomBarcodeExceptionsNoScanningConfigurationFoundLocalizedMessage, parameters))
        {
        }

        /// <summary>
        /// The default constructor by passing a string message and inner exception
        /// </summary>
        /// <param name="message">The message for the exception</param>
        /// <param name="innerException">The inner exception</param>
        /// <param name="parameters">Message Parameters</param>
        public CustomBarcodeNoScanningConfigurationFoundException(Exception innerException, params String[] parameters)
            : base("100000",
                   8001,
                   ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomBarcodeExceptionsNoScanningConfigurationFoundLocalizedMessage, parameters),
                   ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomBarcodeExceptionsNoScanningConfigurationFoundLocalizedMessage, parameters),
                   innerException)
        {
        }
    }
}
