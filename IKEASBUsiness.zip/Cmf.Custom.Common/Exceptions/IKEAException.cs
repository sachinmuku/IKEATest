﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Cmf.Custom.IKEA.Common.Utilities;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common;
using Microsoft.Extensions.DependencyInjection;

namespace Cmf.Custom.IKEA.Common.Exceptions
{

    public class IKEAException : CmfBaseException
    {
        /// <summary>
        /// The default constructor by passing a string message and inner exception
        /// </summary>
        /// <param name="message">The message for the exception</param>
        /// <param name="innerException">The inner exception</param>
        /// <param name="parameters">Message Parameters</param>
        public IKEAException(ILocalizedMessage message, string localizedMessage, params object[] parameters)
            : base("100000",
                   Convert.ToInt64("100000"),
                   string.Format(message.LoadLocalizedMessage(Thread.CurrentThread.CurrentCulture.Name, localizedMessage).MessageText, parameters),
                   string.Format(message.LoadLocalizedMessage(Thread.CurrentThread.CurrentCulture.Name, localizedMessage).MessageText, parameters))

        {
        }

        /// <summary>
        /// The default constructor by passing a string message
        /// </summary>
        /// <param name="message">The message for the exception</param>
        /// <param name="parameters">Message Parameters</param>
        public IKEAException(string localizedMessage, params object[] parameters)
           : base("100000",
                  Convert.ToInt64("100000"),
                  string.Format(ApplicationContext.CurrentServiceProvider.GetService<ILocalizedMessage>().LoadLocalizedMessage(Thread.CurrentThread.CurrentCulture.Name, localizedMessage).MessageText, parameters),
                  string.Format(ApplicationContext.CurrentServiceProvider.GetService<ILocalizedMessage>().LoadLocalizedMessage(Thread.CurrentThread.CurrentCulture.Name, localizedMessage).MessageText, parameters))

        {
        }
    }
}
