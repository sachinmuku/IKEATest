﻿using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Foundation.Common;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Common.Exceptions
{
    /// <summary>
    /// Represents an exception raised when a material is allocated in another production order.
    /// </summary>
    public class CustomMaterialAllocatedInAnotherProductionOrderException : CmfBaseException
    {

        private static IIKEAUtilities ikeaUtilities => ApplicationContext.CurrentServiceProvider.GetService<IIKEAUtilities>();

        /// <summary>
        /// The default constructor by passing a string message
        /// </summary>
        /// <param name="message">The message for the exception</param>
        /// <param name="parameters">Message Parameters</param>
        public CustomMaterialAllocatedInAnotherProductionOrderException(String message, params String[] parameters)
            : base("100000",
                   Convert.ToInt64("100000"),
                   String.Format(message, parameters),
                   String.Format(message, parameters))
        {
        }

        /// <summary>
        /// The default constructor by passing a string message and inner exception
        /// </summary>
        /// <param name="message">The message for the exception</param>
        /// <param name="innerException">The inner exception</param>
        /// <param name="parameters">Message Parameters</param>
        public CustomMaterialAllocatedInAnotherProductionOrderException(String message, Exception innerException, params String[] parameters)
            : base("100000",
                   Convert.ToInt64("100000"),
                   String.Format(message, parameters),
                   String.Format(message, parameters),
                   innerException)
        {
        }

        /// <summary>
        /// The default constructor by passing a string message
        /// </summary>
        /// <param name="message">The message for the exception</param>
        /// <param name="parameters">Message Parameters</param>
        public CustomMaterialAllocatedInAnotherProductionOrderException(params String[] parameters)
            : base("100000",
                   Convert.ToInt64("100000"),
                   ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomMaterialAllocationMaterialAllocatedInAnotherPOLocalizedMessage, parameters),
                   ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomMaterialAllocationMaterialAllocatedInAnotherPOLocalizedMessage, parameters))
        {
        }

        /// <summary>
        /// The default constructor by passing a string message and inner exception
        /// </summary>
        /// <param name="message">The message for the exception</param>
        /// <param name="innerException">The inner exception</param>
        /// <param name="parameters">Message Parameters</param>
        public CustomMaterialAllocatedInAnotherProductionOrderException(Exception innerException, params String[] parameters)
            : base("100000",
                   Convert.ToInt64("100000"),
                   ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomMaterialAllocationMaterialAllocatedInAnotherPOLocalizedMessage, parameters),
                   ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomMaterialAllocationMaterialAllocatedInAnotherPOLocalizedMessage, parameters),
                   innerException)
        {
        }
    }
}
