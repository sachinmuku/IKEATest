﻿using System;

namespace Cmf.Custom.IKEA.Common.ERP
{
    /// <summary>
    /// Handles the communication to request a new production order to ERP
    /// </summary>
    [Serializable]
    public class NewProductionOrderRequestCommunication : MESERPCommunication
    {
        /// <summary>
        /// The Group MO that requires the _entityFactory.Create<IProductionOrder>();.
        /// </summary>
        public string GroupMoName { get; set; }

    }
}
