﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Common.ERP
{
    public class ERPPalletizationLeftOversCommunication : BaseERPCommunication
    {
        [JsonProperty(PropertyName = "FACI")]
        public string Facility { get; set; }

        [JsonProperty(PropertyName = "MFNO")]
        public string ManufacturingOrderNumber { get; set; }

        [JsonProperty(PropertyName = "OPNO")]
        public string OperationNumber { get; set; }

        [JsonProperty(PropertyName = "MSEQ")]
        public string SequenceNumber { get; set; }

        [JsonProperty(PropertyName = "RPDT")]
        public string ReportingDate { get; set; }

        [JsonProperty(PropertyName = "RPTM")]
        public string ReportingTime { get; set; }

        [JsonProperty(PropertyName = "RPQA")]
        public string ReportedQuantity { get; set; }

        [JsonProperty(PropertyName = "WHSL")]
        public string Location { get; set; }

        [JsonProperty(PropertyName = "REND")]
        public string ManualCompletionFlag
        {
            get;
        } = "0";

        [JsonProperty(PropertyName = "DSP1")]
        public string WarningIndicator1
        {
            get;
        } = "1";

        [JsonProperty(PropertyName = "DSP2")]
        public string WarningIndicator2
        {
            get;
        } = "1";

        [JsonProperty(PropertyName = "DSP3")]
        public string WarningIndicator3
        {
            get;
        } = "1";

        [JsonProperty(PropertyName = "DSP6")]
        public string WarningIndicator6
        {
            get;
        } = "1";

        [JsonProperty(PropertyName = "CAMU")]
        public string MaterialName { get; set; } = "";

        [JsonProperty(PropertyName = "STAS")]
        public string StatusBalanceID { get; set; }
    }
}
