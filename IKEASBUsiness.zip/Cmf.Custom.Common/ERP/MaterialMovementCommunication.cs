﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Common.ERP
{
    /// <summary>
    /// Class that represent the communication of the Material Movement to the ERP
    /// </summary>
    [Serializable]
    public class MaterialMovementCommunication : BaseERPCommunication
    {
        [JsonProperty(PropertyName = "WHLO")]
        public string WarehouseLocation { get; set; } = "";

        [JsonProperty(PropertyName = "ITNO")]
        public string BaseProduct { get; set; } = "";

        [JsonProperty(PropertyName = "TWSL")]
        public string ToERPInventoryLocation { get; set; } = "";

        [JsonProperty(PropertyName = "TRQT")]
        public string MaterialQuantity { get; set; } = "";

        [JsonProperty(PropertyName = "WHSL")]
        public string FromERPInventoryLocation { get; set; } = "";

        [JsonProperty(PropertyName = "BANO")]
        public string ProductionOrderName { get; set; } = "";

        [JsonProperty(PropertyName = "CAMU")]
        public string MaterialName { get; set; } = "";

        [JsonProperty(PropertyName = "WROU")]
        public string WarningIndicator0 { get; } = "0";

        [JsonProperty(PropertyName = "DSP1")]
        public string WarningIndicator1 { get; } = "1";

    }
}
