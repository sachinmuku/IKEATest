﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Common.ERP
{
    /// <summary>
    /// Class that represent the communication of the Material Change Type to the ERP
    /// </summary>
    [Serializable]
    public class ChangeQualityTypeCommunication : BaseERPCommunication
    {
        [JsonProperty(PropertyName = "PRFL")]
        public string ProcessFlag { get; set; }

        [JsonProperty(PropertyName = "MSNR")]
        public string MessageNumber { get; } = String.Empty;

        [JsonProperty(PropertyName = "MSLN")]
        public string MessageLineNumber { get; } = String.Empty;

        [JsonProperty(PropertyName = "MSGS")]
        public string SequenceNumber { get; } = String.Empty;

        [JsonProperty(PropertyName = "GEDT")]
        public string DateGenerated { get; } = String.Empty;

        [JsonProperty(PropertyName = "GETM")]
        public string TimeGenerated { get; } = String.Empty;

        [JsonProperty(PropertyName = "E0PA")]
        public string Partner { get; set; }

        [JsonProperty(PropertyName = "E065")]
        public string MessageType { get; set; }

        [JsonProperty(PropertyName = "WHLO")]
        public string Warehouse { get; set; }

        [JsonProperty(PropertyName = "WHSL")]
        public string Location { get; set; }

        [JsonProperty(PropertyName = "ITNO")]
        public string ItemNumber { get; set; }

        [JsonProperty(PropertyName = "BANO")]
        public string LotNumber { get; } = String.Empty;

        [JsonProperty(PropertyName = "CAMU")]
        public string Container { get; set; }

        [JsonProperty(PropertyName = "REPN")]
        public string ReceivingNumber { get; } = String.Empty;

        [JsonProperty(PropertyName = "BREF")]
        public string LotReference1 { get; } = String.Empty;

        [JsonProperty(PropertyName = "BRE2")]
        public string LotReference2 { get; } = String.Empty;

        [JsonProperty(PropertyName = "BREM")]
        public string Remark { get; } = String.Empty;

        [JsonProperty(PropertyName = "POPN")]
        public string AliasNumber { get; } = String.Empty;

        [JsonProperty(PropertyName = "ALWQ")]
        public string AliasQualifier { get; } = String.Empty;

        [JsonProperty(PropertyName = "ALWT")]
        public string AliasType { get; } = String.Empty;

        [JsonProperty(PropertyName = "QLQT")]
        public string Quantity { get; } = String.Empty;

        [JsonProperty(PropertyName = "QLUN")]
        public string QualifierUnitOfMeasure { get; } = String.Empty;

        [JsonProperty(PropertyName = "QLDT")]
        public string TransactionDate { get; } = String.Empty;

        [JsonProperty(PropertyName = "NITN")]
        public string NewItemNumber { get; } = String.Empty;

        [JsonProperty(PropertyName = "NBAN")]
        public string NewLotNumber { get; } = String.Empty;

        [JsonProperty(PropertyName = "ALOC")]
        public string Allocatable { get; } = String.Empty;

        [JsonProperty(PropertyName = "CAWE")]
        public string CatchWeight { get; } = String.Empty;

        [JsonProperty(PropertyName = "RSCD")]
        public string TransactionReason { get; } = String.Empty;

        [JsonProperty(PropertyName = "STAS")]
        public string StatusBalanceID { get; set; }

        [JsonProperty(PropertyName = "USD1")]
        public string UserDefined1 { get; } = String.Empty;

        [JsonProperty(PropertyName = "USD2")]
        public string UserDefined2 { get; } = String.Empty;

        [JsonProperty(PropertyName = "USD3")]
        public string UserDefined3 { get; } = String.Empty;

        [JsonProperty(PropertyName = "USD4")]
        public string UserDefined4 { get; } = String.Empty;

        [JsonProperty(PropertyName = "USD5")]
        public string UserDefined5 { get; } = String.Empty;

        [JsonProperty(PropertyName = "PMSN")]
        public string ExternalMessageNumber { get; } = String.Empty;

        [JsonProperty(PropertyName = "RESP")]
        public string Responsible { get; set; }

        [JsonProperty(PropertyName = "CALT")]
        public string CalculationMethod { get; } = String.Empty;

        [JsonProperty(PropertyName = "QRBS")]
        public string QIRequestBasis { get; } = String.Empty;

    }
}
