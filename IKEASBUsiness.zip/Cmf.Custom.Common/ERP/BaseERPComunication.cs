﻿using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Foundation.Common;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Common.ERP
{
    /// <summary>
    /// Base Class for every ERP Communication class
    /// </summary>
    [Serializable]
    public class BaseERPCommunication
    {
        private static IGenericUtilities genericUtilities => ApplicationContext.CurrentServiceProvider.GetService<IGenericUtilities>();

        [JsonProperty(PropertyName = "CONO")]
        public string Company { get; set; }

        public BaseERPCommunication()
        {
            Company = genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.CompanyCodeConfig);
        }
    }
}
