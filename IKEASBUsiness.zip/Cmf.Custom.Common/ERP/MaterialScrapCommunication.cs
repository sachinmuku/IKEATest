﻿using Newtonsoft.Json;
using System;

namespace Cmf.Custom.IKEA.Common.ERP
{
    /// <summary>
    /// Class that represent the communication of the Material scrap loss to the ERP
    /// </summary>
    [Serializable]
    public class MaterialScrapCommunication : BaseERPCommunication
    {

        [JsonProperty(PropertyName = "ADID")]
        public string AddressId { get; set; }

        [JsonProperty(PropertyName = "ALQT")]
        public string AllocateQuantity { get; set; }

        [JsonProperty(PropertyName = "ALWQ")]
        public string AliasQualifier { get; } = string.Empty;

        [JsonProperty(PropertyName = "ALWT")]
        public string AliasType { get; } = string.Empty;

        [JsonProperty(PropertyName = "BANO")]
        public string LotNumber { get; } = string.Empty;

        [JsonProperty(PropertyName = "CAMU")]
        public string Container { get; set; }

        [JsonProperty(PropertyName = "CAWE")]
        public string CatchWeight { get; } = string.Empty;

        [JsonProperty(PropertyName = "CUNO")]
        public string CustomerNumber { get; } = string.Empty;

        [JsonProperty(PropertyName = "DLIX")]
        public string DeliveryNumberDlix { get; } = string.Empty;

        [JsonProperty(PropertyName = "DLQT")]
        public string DeliveryQuantity { get; set; } 

        [JsonProperty(PropertyName = "E065")]
        public string MessageType { get; set; }

        [JsonProperty(PropertyName = "E0PA")]
        public string Partner { get; set; }

        [JsonProperty(PropertyName = "E0PB")]
        public string PartnerId { get; set; }

        [JsonProperty(PropertyName = "GEDT")]
        public string DateGenerated { get; } = string.Empty;

        [JsonProperty(PropertyName = "GETM")]
        public string TimeGenerated { get; } = string.Empty;

        [JsonProperty(PropertyName = "ITNO")]
        public string ItemNumber { get; set; }

        [JsonProperty(PropertyName = "MSGN")]
        public string MessageNumber { get; } = string.Empty;

        [JsonProperty(PropertyName = "OPNO")]
        public string ERPOperation { get; set; }

        [JsonProperty(PropertyName = "PACN")]
        public string PackageNumber { get; set; }

        [JsonProperty(PropertyName = "PLSX")]
        public string PickingListSuffix { get; set; }

        [JsonProperty(PropertyName = "PMSN")]
        public string ExternalMessageNumber { get; } = string.Empty;

        [JsonProperty(PropertyName = "POPN")]
        public string AliasNumber { get; } = string.Empty;

        [JsonProperty(PropertyName = "PRMD")]
        public string ProcessFlag { get; set; }

        [JsonProperty(PropertyName = "RESP")]
        public string Responsible { get; set; }

        [JsonProperty(PropertyName = "RIDI")]
        public string DeliveryNumberRidi { get; set; }

        [JsonProperty(PropertyName = "RIDL")]
        public string OrderLine { get; set; }

        [JsonProperty(PropertyName = "RIDN")]
        public string OrderNumber { get; set; }

        [JsonProperty(PropertyName = "RIDX")]
        public string LineSuffix { get; set; }

        [JsonProperty(PropertyName = "RORC")]
        public string ReferenceOrderCategory { get; set; }

        [JsonProperty(PropertyName = "RORL")]
        public string ReferenceOrderLine { get; set; }

        [JsonProperty(PropertyName = "RORN")]
        public string ReferenceOrderNumber { get; set; }

        [JsonProperty(PropertyName = "RSCD")]
        public string TransactionReason { get; set; }

        [JsonProperty(PropertyName = "TRTP")]
        public string OrderType { get; set; }

        [JsonProperty(PropertyName = "TWSL")]
        public string ToLocation { get; set; }

        [JsonProperty(PropertyName = "USD1")]
        public string UserDefined1 { get; } = string.Empty;

        [JsonProperty(PropertyName = "USD2")]
        public string UserDefined2 { get; } = string.Empty;

        [JsonProperty(PropertyName = "USD3")]
        public string UserDefined3 { get; } = string.Empty;

        [JsonProperty(PropertyName = "USD4")]
        public string UserDefined4 { get; } = string.Empty;

        [JsonProperty(PropertyName = "USD5")]
        public string UserDefined5 { get; } = string.Empty;

        [JsonProperty(PropertyName = "WHLO")]
        public string Warehouse { get; set; }

        [JsonProperty(PropertyName = "WHSL")]
        public string Location { get; set; }

    }
}
