﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Common.ERP
{
    /// <summary>
    /// Class that represent the communication of the Material Change Type to the ERP
    /// </summary>
    [Serializable]
    public class DistributionOrderCommunication : BaseERPCommunication
    {
        [JsonProperty(PropertyName = "PRMD")]
        public string ProcessFlag { get; set; }

        [JsonProperty(PropertyName = "WHLO")]
        public string Warehouse { get; set; }

        [JsonProperty(PropertyName = "MSGN")]
        public string MessageNumber { get; } = String.Empty;

        [JsonProperty(PropertyName = "PACN")]
        public string PackageNumber { get; } = string.Empty;

        [JsonProperty(PropertyName = "GEDT")]
        public string DateGenerated { get; } = string.Empty;

        [JsonProperty(PropertyName = "GETM")]
        public string TimeGenerated { get; } = string.Empty;

        [JsonProperty(PropertyName = "E0PA")]
        public string Partner { get; set; }

        [JsonProperty(PropertyName = "E0PB")]
        public string PartnerId { get; set; }

        [JsonProperty(PropertyName = "E065")]
        public string MessageType { get; set; }

        [JsonProperty(PropertyName = "CUNO")]
        public string CustomerNumber { get; set; }

        [JsonProperty(PropertyName = "ADID")]
        public string AddressId { get; } = string.Empty;

        [JsonProperty(PropertyName = "ITNO")]
        public string ItemNumber { get; set; }

        [JsonProperty(PropertyName = "POPN")]
        public string AliasNumber { get; } = string.Empty;

        [JsonProperty(PropertyName = "ALWQ")]
        public string AliasQualifier { get; } = string.Empty;

        [JsonProperty(PropertyName = "ALWT")]
        public string AliasCategory { get; } = string.Empty;

        [JsonProperty(PropertyName = "WHSL")]
        public string Location { get; set; } = string.Empty;

        [JsonProperty(PropertyName = "TWSL")]
        public string ToLocation { get; set; }

        [JsonProperty(PropertyName = "BANO")]
        public string LotNumber { get; } = string.Empty;

        [JsonProperty(PropertyName = "CAMU")]
        public string Container { get; set; } = string.Empty;

        [JsonProperty(PropertyName = "ALQT")]
        public string AllocateQuantity { get; set; }

        [JsonProperty(PropertyName = "DLQT")]
        public string DeliveryQuantity { get; set; }

        [JsonProperty(PropertyName = "RIDN")]
        public string OrderNumber { get; } = string.Empty;

        [JsonProperty(PropertyName = "RIDL")]
        public string OrderLine { get; } = string.Empty;

        [JsonProperty(PropertyName = "RIDX")]
        public string LineSuffix { get; } = string.Empty;

        [JsonProperty(PropertyName = "RIDI")]
        public string DeliveryNumber { get; } = string.Empty;

        [JsonProperty(PropertyName = "PLSX")]
        public string PickingListSuffix { get; } = string.Empty;

        [JsonProperty(PropertyName = "DLIX")]
        public string DeliveryNumberDlix { get; } = string.Empty;

        [JsonProperty(PropertyName = "USD1")]
        public string UserDefined1 { get; } = string.Empty;

        [JsonProperty(PropertyName = "USD2")]
        public string UserDefined2 { get; } = string.Empty;

        [JsonProperty(PropertyName = "USD3")]
        public string UserDefined3 { get; } = string.Empty;

        [JsonProperty(PropertyName = "USD4")]
        public string UserDefined4 { get; } = string.Empty;

        [JsonProperty(PropertyName = "USD5")]
        public string UserDefined5 { get; } = string.Empty;

        [JsonProperty(PropertyName = "CAWE")]
        public string CatchWeight { get; } = string.Empty;

        [JsonProperty(PropertyName = "TRTP")]
        public string OrderType { get; set; }

        [JsonProperty(PropertyName = "RESP")]
        public string Responsible { get; set; }

        [JsonProperty(PropertyName = "PMSN")]
        public string ExternalMessageNumber { get; } = string.Empty;

        [JsonProperty(PropertyName = "OPNO")]
        public string ERPOperation { get; } = string.Empty;

        [JsonProperty(PropertyName = "RSCD")]
        public string TransactionReason { get; } = string.Empty;

        [JsonProperty(PropertyName = "RORC")]
        public string ReferenceOrderCategory { get; } = string.Empty;

        [JsonProperty(PropertyName = "RORN")]
        public string ReferenceOrderNumber { get; } = string.Empty;

        [JsonProperty(PropertyName = "RORL")]
        public string ReferenceOrderLine { get; } = string.Empty;

        [JsonProperty(PropertyName = "RORX")]
        public string LineSuffixRORX { get; } = string.Empty;

        [JsonProperty(PropertyName = "BREF")]
        public string LotReference1 { get; } = String.Empty;

        [JsonProperty(PropertyName = "BRE2")]
        public string LotReference2 { get; } = String.Empty;

        [JsonProperty(PropertyName = "RPDT")]
        public string ReportingDate { get; } = string.Empty;

        [JsonProperty(PropertyName = "RPTM")]
        public string ReportingTime { get; } = string.Empty;

        [JsonProperty(PropertyName = "REPN")]
        public string ReceivingNumber { get; } = String.Empty;

        [JsonProperty(PropertyName = "UTCM")]
        public string UTCMode { get; set; } = "0";
    }
}
