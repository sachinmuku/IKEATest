﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Common.ERP
{
    public class ERPPalletizationCompletionCommunication : BaseERPCommunication
    {
        [JsonProperty(PropertyName = "FACI")]
        public string Facility { get; set; }

        [JsonProperty(PropertyName = "PRNO")]
        public string ProductionNumber { get; set; }

        [JsonProperty(PropertyName = "MFNO")]
        public string ManufacturingOrderNumber { get; set; }

        [JsonProperty(PropertyName = "WOSQ")]
        public string ReportingNumber
        {
            get;
        } = string.Empty;

        [JsonProperty(PropertyName = "RPDT")]
        public string ReportingDate { get; set; }

        [JsonProperty(PropertyName = "RPTM")]
        public string ReportingTime { get; set; }

        [JsonProperty(PropertyName = "TRDT")]
        public string TransationDate
        {
            get
            {
                return ReportingDate;
            }
        }

        [JsonProperty(PropertyName = "TRTM")]
        public string TransationTime
        {
            get
            {
                return ReportingTime;
            }
        }

        [JsonProperty(PropertyName = "PRDT")]
        public string PriorityDate
        {
            get;
        } = string.Empty;

        [JsonProperty(PropertyName = "POCY")]
        public string NormalPotency
        {
            get;
        } = string.Empty;

        [JsonProperty(PropertyName = "RPQA")]
        public string ReportQuantityInAlternativeUnit { get; set; }

        [JsonProperty(PropertyName = "MAUN")]
        public string ManufacturingUnitsMeasurement { get; set; }

        [JsonProperty(PropertyName = "STAS")]
        public string Status { get; set; }

        [JsonProperty(PropertyName = "REND")]
        public string ManualCompletionFlag { get; set; }

        [JsonProperty(PropertyName = "WHSL")]
        public string Location { get; set; }

        [JsonProperty(PropertyName = "BANO")]
        public string LotNumber { get; set; }

        [JsonProperty(PropertyName = "CAMU")]
        public string Container { get; set; }

        [JsonProperty(PropertyName = "MAQA")]
        public string ManufacturedQuantity { get; set; }

        [JsonProperty(PropertyName = "SCQA")]
        public string ScrapQuantityAlternativeUnit { get; set; }

        [JsonProperty(PropertyName = "SCRE")]
        public string RejectionReason { get; set; }

        [JsonProperty(PropertyName = "PAC2")]
        public string Packaging2
        {
            get;
        } = string.Empty;

        [JsonProperty(PropertyName = "BREF")]
        public string LotReference1
        {
            get;
        } = string.Empty;

        [JsonProperty(PropertyName = "BRE2")]
        public string LotReference2
        {
            get;
        } = string.Empty;

        [JsonProperty(PropertyName = "CAWE")]
        public string CatchWeight
        {
            get;
        } = string.Empty;

        [JsonProperty(PropertyName = "TRPR")]
        public string InventoryAccountingPrice
        {
            get;
        } = string.Empty;

        [JsonProperty(PropertyName = "TRPC")]
        public string InventoryAccountingPriceQuantity
        {
            get;
        } = string.Empty;

        [JsonProperty(PropertyName = "CHID")]
        public string ChangedBy
        {
            get;
        } = string.Empty;

        [JsonProperty(PropertyName = "DSP1")]
        public string WarningIndicator1
        {
            get;
        } = "1";

        [JsonProperty(PropertyName = "DSP2")]
        public string WarningIndicator2
        {
            get;
        } = "1";

        [JsonProperty(PropertyName = "DSP3")]
        public string WarningIndicator3
        {
            get;
        } = "1";

        [JsonProperty(PropertyName = "DSP4")]
        public string WarningIndicator4
        {
            get;
        } = "1";

        [JsonProperty(PropertyName = "DSP5")]
        public string WarningIndicator5
        {
            get;
        } = "1";

        [JsonProperty(PropertyName = "DSP6")]
        public string WarningIndicator6
        {
            get;
        } = "1";

        [JsonProperty(PropertyName = "DSP7")]
        public string WarningIndicator7
        {
            get;
        } = "1";

        [JsonProperty(PropertyName = "DSP8")]
        public string WarningIndicator8
        {
            get;
        } = "1";

        [JsonProperty(PropertyName = "AT01")]
        public string AttributeId1
        {
            get;
        } = string.Empty;

        [JsonProperty(PropertyName = "AV01")]
        public string AttributeValue1
        {
            get;
        } = string.Empty;

        [JsonProperty(PropertyName = "AT02")]
        public string AttributeId2
        {
            get;
        } = string.Empty;

        [JsonProperty(PropertyName = "AV02")]
        public string AttributeValue2
        {
            get;
        } = string.Empty;

        [JsonProperty(PropertyName = "AT03")]
        public string AttributeId3
        {
            get;
        } = string.Empty;

        [JsonProperty(PropertyName = "AV03")]
        public string AttributeValue3
        {
            get;
        } = string.Empty;

        [JsonProperty(PropertyName = "AT04")]
        public string AttributeId4
        {
            get;
        } = string.Empty;

        [JsonProperty(PropertyName = "AV04")]
        public string AttributeValue4
        {
            get;
        } = string.Empty;

        [JsonProperty(PropertyName = "AT05")]
        public string AttributeId5
        {
            get;
        } = string.Empty;

        [JsonProperty(PropertyName = "AV05")]
        public string AttributeValue5
        {
            get;
        } = string.Empty;

        [JsonProperty(PropertyName = "AT06")]
        public string AttributeId6
        {
            get;
        } = string.Empty;

        [JsonProperty(PropertyName = "AV06")]
        public string AttributeValue6
        {
            get;
        } = string.Empty;

        [JsonProperty(PropertyName = "AT07")]
        public string AttributeId7
        {
            get;
        } = string.Empty;

        [JsonProperty(PropertyName = "AV07")]
        public string AttributeValue7
        {
            get;
        } = string.Empty;

        [JsonProperty(PropertyName = "AT08")]
        public string AttributeId8
        {
            get;
        } = string.Empty;

        [JsonProperty(PropertyName = "AV08")]
        public string AttributeValue8
        {
            get;
        } = string.Empty;

        [JsonProperty(PropertyName = "AT09")]
        public string AttributeId9
        {
            get;
        } = string.Empty;

        [JsonProperty(PropertyName = "AV09")]
        public string AttributeValue9
        {
            get;
        } = string.Empty;

        [JsonProperty(PropertyName = "AT010")]
        public string AttributeId10
        {
            get;
        } = string.Empty;

        [JsonProperty(PropertyName = "AV010")]
        public string AttributeValue10
        {
            get;
        } = string.Empty;

        [JsonProperty(PropertyName = "PAII")]
        public string IncludeInPackageNumber
        {
            get;
        } = string.Empty;

        [JsonProperty(PropertyName = "PACT")]
        public string Packaging
        {
            get;
        } = string.Empty;

        [JsonProperty(PropertyName = "LIRR")]
        public string LIRequestRule
        {
            get;
        } = string.Empty;

        [JsonProperty(PropertyName = "EXPI")]
        public string ExpirationDate
        {
            get;
        } = string.Empty;

        [JsonProperty(PropertyName = "HVDT")]
        public string HarvestedDate
        {
            get;
        } = string.Empty;
        
    }
}
