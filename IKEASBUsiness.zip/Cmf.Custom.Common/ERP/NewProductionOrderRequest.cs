﻿using Newtonsoft.Json;

namespace Cmf.Custom.IKEA.Common.ERP
{
    public class NewProductionOrderRequest : BaseERPCommunication
    {
        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("FACI")]
        public string Facility { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("PRNO")]
        public string ProductNumber { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("STRT")]
        public string ProductStructureType { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("ORQA")]
        public string OrderedQuantityAlt { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("WHST")]
        public string Status { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("STDT")]
        public string StartDate { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("FIDT")]
        public string FinishDate { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("BDCD")]
        public string Explosion { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("RESP")]
        public string Responsible { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("WHLO")] 
        public string Warehouse { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("ORTY")]
        public string OrderType { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("PROJ")]
        public string ProjectNumber { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("WCLN")]
        public string ProductionLine { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("RORC")]
        public string RefrenceOrderCategory { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("RORN")]
        public string RefrenceOrderNumber { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("RORL")]
        public string RefrenceOrderLine { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("RORX")]
        public string LineSuffix { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("BANO")]
        public string LotNumber { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("PRIO")]
        public string Priority { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("ELNO")]
        public string ProjectElement { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("NUC1")]
        public string NumberOfPutAwayCard { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("NUC2")]
        public string NumberOfMaterialReq { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("NUC3")]
        public string NumberOfLaborTicket { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("NUC4")]
        public string NumberOfShopTravel { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("NUC5")]
        public string NumberOfRoutingCard { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("NUC6")]
        public string NumberOfPickingList { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("NUC7")]
        public string NumberOfDesignDocument { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("SCHN")]
        public string ScheduleNumber { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("TX40")]
        public string Text { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("MAUN")]
        public string AlternateUnits { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("DSP1")]
        public string WARNING_DateEarlierThanToday { get; set; } = "1";

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("DSP2")]
        public string WARNING_StartDateMayBeEarlier { get; set; } = "1";

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("DSP3")]
        public string WARNING_DSP3 { get; set; } = "1";

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("DSP4")]
        public string WARNING_4 { get; set; } = "1";

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("DSP5")]
        public string WARNING_AlternativeRoutingIdentity { get; set; } = "1";

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("DSP6")]
        public string WARNING_IgnoreOrderMultiple { get; set; } = "1";

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("DSP7")]
        public string WARNING_7 { get; set; } = "1";

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("DSP8")]
        public string WARNING_8 { get; set; } = "1";

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("AOID")]
        public string AlternativeRouting { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("MEXP")]
        public string ManualExpirationDate { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("MSTI")]
        public string StartTime { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("MFTI")]
        public string FinishTime { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("MFPC")]
        public string Process { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("WHSL")]
        public string Location { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty("PCCO")]
        public string ProcessCode { get; set; }

        /// <summary>
        /// Default empty constructor.
        /// </summary>
        public NewProductionOrderRequest() : base()
        {
            //The company field is filled by calling the parent constructor
        }

    }
}
