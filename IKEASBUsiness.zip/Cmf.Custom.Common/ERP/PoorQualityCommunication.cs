﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cmf.Custom.IKEA.Common.ERP
{
    /// <summary>
    /// Class that represent the communication of the Material Defects to the ERP
    /// </summary>
    [Serializable]
    public class PoorQualityCommunication
    {
        public string PalletMaterialName { get; set; }
        public string PalletMaterialType { get; set; }
        public string PalletMaterialProduct { get; set; }
        public string PalletMaterialBaseProduct { get; set; }
        public string PalletMaterialQuantity { get; set; }
        public string ERPOperation { get; set; }
        public List<Loss> Losses { get; set; } = new List<Loss>();
        public string DateAndTime { get; set; }
    }

    [Serializable]
    public class Loss
    {
        [XmlAttribute]
        public string Code { get; set; }
        [XmlAttribute]
        public string Quantity { get; set; }
    }
}
