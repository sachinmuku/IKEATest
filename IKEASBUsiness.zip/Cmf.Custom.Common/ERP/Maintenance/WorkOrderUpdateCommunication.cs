﻿using Cmf.Common.CustomActionUtilities;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Linq;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Foundation.Common;
using Microsoft.Extensions.DependencyInjection;

namespace Cmf.Custom.IKEA.Common.ERP.Maintenance
{
    public class WorkOrderUpdateCommunication : BaseERPCommunication
    {
        private static IIKEAUtilities ikeaUtilities => ApplicationContext.CurrentServiceProvider.GetService<IIKEAUtilities>();
        private static IGenericUtilities genericUtilities => ApplicationContext.CurrentServiceProvider.GetService<IGenericUtilities>();

        /// <summary>
        /// Already handled by inheritance of BaseERPCommunication
        /// </summary>
        //[JsonProperty(PropertyName = "CONO")]
        //public string Company { get; set; }

        [JsonProperty(PropertyName = "MWNO")]
        public string WorkOrderNumber { get; set; }

        [JsonProperty(PropertyName = "OPNO")]
        public string OperationNumber { get; set; }

        [JsonProperty(PropertyName = "RPDT")]
        public string ReportingDate { get; set; }

        [JsonProperty(PropertyName = "RTM1")]
        public string ReportingTime { get; set; }

        [JsonProperty(PropertyName = "RPRE")]
        public string ReportingResponsible { get; set; }

        [JsonProperty(PropertyName = "EMNO")]
        public string EmployeeNumber { get; set; }

        [JsonProperty(PropertyName = "UMAS")]
        public string UsedLaborSetupTime { get; set; }

        [JsonProperty(PropertyName = "UMAT")]
        public string UsedLaborRunTime { get; set; }

        [JsonProperty(PropertyName = "UPIT")]
        public string UsedMachineRunTime { get; set; }

        [JsonProperty(PropertyName = "USET")]
        public string UsedMachineSetupTime { get; set; }

        [JsonProperty(PropertyName = "REND")]
        public string ManualCompletionFlag { get; set; }

        [JsonProperty(PropertyName = "SCQA")]
        public string ScrapQuantityAltUnit { get; set; }

        [JsonProperty(PropertyName = "SCRE")]
        public string RejectionReason { get; set; }

        [JsonProperty(PropertyName = "DPLG")]
        public string DeviatingWorkCenter { get; set; }

        [JsonProperty(PropertyName = "PCTP")]
        public string CostingType { get; set; }

        [JsonProperty(PropertyName = "FCLA")]
        public string FailureClass { get; }

        [JsonProperty(PropertyName = "FCL2")]
        public string ErrorCode2 { get; }

        [JsonProperty(PropertyName = "FCL3")]
        public string ErrorCode3 { get; }

        [JsonProperty(PropertyName = "DOWT")]
        public string DownTime { get; set; }

        [JsonProperty(PropertyName = "DLY1")]
        public string DelayTime1 { get; set; }

        [JsonProperty(PropertyName = "DLY2")]
        public string DelayTime2 { get; set; }

        [JsonProperty(PropertyName = "TXL1")]
        public string Text1 { get; set; }

        [JsonProperty(PropertyName = "TXL2")]
        public string Text2 { get; set; }

        /// <summary>
        /// Empty Constructor
        /// </summary>
        public WorkOrderUpdateCommunication()
        {
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="maintenanceActivityOrder">MaintenanceActivityOrder</param>
        public WorkOrderUpdateCommunication(IMaintenanceActivityOrder maintenanceActivityOrder)
        {

            // Load relations to check if there is effort from operators:
            maintenanceActivityOrder.LoadRelations();

            // Sum all effort from all operators:
            decimal workDuration = 0;
            if (maintenanceActivityOrder.HasRelations(IKEAConstants.MaintenanceActivityOrderEmployeeRelationName))
            {
                workDuration = maintenanceActivityOrder.RelationCollection[IKEAConstants.MaintenanceActivityOrderEmployeeRelationName]
                                                   .Select(MOE => (MOE as IMaintenanceActivityOrderEmployee).Duration.GetValueOrDefault())
                                                   .Sum();
            }

            // Get configured Employee number that will be associated to the effort declared:
            string erpEmployeeNumber = genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.ERPWorkOrderEmployeeNumber);

            // Get the error codes from the Generic table CustomERPMaintenanceTypesMapping:
            Dictionary<string, string> errorCodes = ikeaUtilities.GetErrorCodesFromErpMaintenanceMappingTable(maintenanceActivityOrder.Type);

            if (!errorCodes.IsNullOrEmpty())
            {

                if (maintenanceActivityOrder.HasAttribute(IKEAConstants.CustomWorkOrderIdAttribute, true))
                {
                    // CONO
                    // Already handled by inheritance of BaseERPCommunication
                    // MDWO
                    this.WorkOrderNumber = maintenanceActivityOrder.GetAttributeValue(IKEAConstants.CustomWorkOrderIdAttribute) as string;
                    // OPNO
                    this.OperationNumber = maintenanceActivityOrder.GetAttributeValue(IKEAConstants.CustomWorkOrderOperationNumberAttribute, true) as string;
                    // EMNO
                    this.EmployeeNumber = erpEmployeeNumber;
                    // UMAT
                    this.UsedLaborRunTime = workDuration.ToString("0.##");
                    // REND
                    this.ManualCompletionFlag = "0";
                    // FCLA
                    this.FailureClass = errorCodes["ErrorCode1"];
                    // FCL2
                    this.ErrorCode2 = errorCodes["ErrorCode2"];
                    // FCL3
                    this.ErrorCode3 = errorCodes["ErrorCode3"];

                }
            }
        }

        /// <summary>
        /// Send Update Work Order To ERP
        /// </summary>
        /// <param name="workDuration">Work Order Duration</param>
        /// <param name="notes">Notes</param>
        /// <param name="comments">Comments</param>
        /// <returns>Created IntegrationEntry</returns>
        public IIntegrationEntry SendUpdateWorkOrderToERP(decimal? workDuration = null, string notes = "", string comments = "")
        {
            IIntegrationEntry ie = null;

            // Concatenate both string messages. First 60 characters will be send in TXL1 field and the remain in the TXL2 field:
            string separator = (notes.IsNullOrEmpty() || comments.IsNullOrEmpty()) ? "" : "\n";
            string maintenanceActivityText = string.Format("{0}{1}{2}", notes, separator, comments);

            // UMAT
            if (workDuration.HasValue)
            {
                this.UsedLaborRunTime = workDuration.Value.ToString("0.##");
            }

            // TXL1 and TXL2 have each a limit of 60 characters in M3, which totals to 120 characters
            // To prevent from exceeding this limit, if the maintenanceActivityText has more than 120 characters:
            //   - TXL1 will have the first 60 characters;
            //   - TXL2 will be truncated to 59 characters, being the 60th one, an ellipsis (3 dots character), to signal that the text has been truncated

            // TXL1
            this.Text1 = maintenanceActivityText.Length > 60 ? maintenanceActivityText.Substring(0, 60) : maintenanceActivityText;

            // TXL2
            this.Text2 = maintenanceActivityText.Length > 60 ? maintenanceActivityText.Substring(60, maintenanceActivityText.Length > 120 ? 59 : maintenanceActivityText.Length - 60) : "";

            if (maintenanceActivityText.Length > 120)
            {
                string ellipsis = "\u2026";

                this.Text2 += ellipsis;
            }

            if (!this.WorkOrderNumber.IsNullOrEmpty())
            {
                // Create the Integration Entry
                ie = ikeaUtilities.CreateJsonIntegrationEntry(this,
                                                            IKEAConstants.ERPMaintenanceUpdateWorkOrder,
                                                            IKEAConstants.ERPMaintenanceHandleWorkOrderMessageType,
                                                            IKEAConstants.ERPMaintenanceUpdateWorkOrderEventName);
            }
            return ie;
        }

        /// <summary>
        /// Send Update Work Order To ERP
        /// </summary>
        /// <returns>Created IntegrationEntry</returns>
        public IIntegrationEntry SendStartWorkOrderToERP()
        {
            decimal minimalWorkDuration = 0.01M;
            return SendUpdateWorkOrderToERP(minimalWorkDuration);
        }
    }
}
