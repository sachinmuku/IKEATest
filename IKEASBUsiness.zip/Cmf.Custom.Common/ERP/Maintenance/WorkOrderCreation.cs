﻿using Cmf.Custom.IKEA.Common.ERP.Maintenance.M3;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cmf.Common.CustomActionUtilities;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Foundation.Common;
using Microsoft.Extensions.DependencyInjection;

namespace Cmf.Custom.IKEA.Common.ERP.Maintenance
{
	public class WorkOrderCreation
	{
        private static IIKEAUtilities ikeaUtilities => ApplicationContext.CurrentServiceProvider.GetService<IIKEAUtilities>();
        private static IGenericUtilities genericUtilities => ApplicationContext.CurrentServiceProvider.GetService<IGenericUtilities>();

        #region Private variables

        private SyncServiceOrder _syncServiceOrder = new SyncServiceOrder();

		#endregion

		#region Properties

		/// <summary>
		/// Work Order Id
		/// </summary>
		public string WorkOrderID
		{
			get
			{
				string workOrderId = string.Empty;

				if (_syncServiceOrder.DataArea != null
					&& !_syncServiceOrder.DataArea.ServiceOrder.IsNullOrEmpty()
					&& _syncServiceOrder.DataArea.ServiceOrder[0].ServiceOrderHeader != null
					&& _syncServiceOrder.DataArea.ServiceOrder[0].ServiceOrderHeader.DisplayID != null)
				{
					workOrderId = _syncServiceOrder.DataArea.ServiceOrder[0].ServiceOrderHeader.DisplayID.Value;
				}

				return workOrderId;
			}
		}

		/// <summary>
		/// Work Order Type
		/// </summary>
		public string WorkOrderType
		{
			get
			{
				string workOrderType = string.Empty;

				if (_syncServiceOrder.DataArea != null
					&& !_syncServiceOrder.DataArea.ServiceOrder.IsNullOrEmpty()
					&& !_syncServiceOrder.DataArea.ServiceOrder[0].ServiceOrderLine.IsNullOrEmpty()
					&& _syncServiceOrder.DataArea.ServiceOrder[0].ServiceOrderLine[0].ActivityTemplateCode != null)
				{
					workOrderType = _syncServiceOrder.DataArea.ServiceOrder[0].ServiceOrderLine[0].ActivityTemplateCode.Value.Substring(0, 20).Trim();
				}

				return workOrderType;
			}
		}

		/// <summary>
		/// Work Order Sub Type
		/// </summary>
		public string WorkOrderSubType
		{
			get
			{
				string workOrderType = string.Empty;

				if (_syncServiceOrder.DataArea != null
					&& !_syncServiceOrder.DataArea.ServiceOrder.IsNullOrEmpty()
					&& !_syncServiceOrder.DataArea.ServiceOrder[0].ServiceOrderLine.IsNullOrEmpty()
					&& _syncServiceOrder.DataArea.ServiceOrder[0].ServiceOrderLine[0].ActivityTemplateCode != null)
				{
					string value = _syncServiceOrder.DataArea.ServiceOrder[0].ServiceOrderLine[0].ActivityTemplateCode.Value;

					// Get last 3 chars
					workOrderType = value.Substring(value.Length - 3);
				}

				return workOrderType;
			}
		}

		/// <summary>
		/// Header Description
		/// </summary>
		public string Description
		{
			get
			{
				string description = string.Empty;

				if (_syncServiceOrder.DataArea != null
					&& !_syncServiceOrder.DataArea.ServiceOrder.IsNullOrEmpty()
					&& _syncServiceOrder.DataArea.ServiceOrder[0].ServiceOrderHeader != null
					&& !_syncServiceOrder.DataArea.ServiceOrder[0].ServiceOrderHeader.Description.IsNullOrEmpty())
				{
					description = string.Join("\n", _syncServiceOrder.DataArea.ServiceOrder[0].ServiceOrderHeader.Description.Select(d => d.Value));
				}

				return description;
			}
		}

		/// <summary>
		/// Header Notes
		/// </summary>
		public string Notes
		{
			get
			{
				string notes = string.Empty;

				if (_syncServiceOrder.DataArea != null
					&& !_syncServiceOrder.DataArea.ServiceOrder.IsNullOrEmpty()
					&& _syncServiceOrder.DataArea.ServiceOrder[0].ServiceOrderHeader != null
					&& !_syncServiceOrder.DataArea.ServiceOrder[0].ServiceOrderHeader.Note.IsNullOrEmpty())
				{
					notes = string.Join("\n", _syncServiceOrder.DataArea.ServiceOrder[0].ServiceOrderHeader.Note.Select(d => d.Value));
				}

				return notes;
			}
		}

		/// <summary>
		/// Work Order Lines
		/// </summary>
		public List<WorkOrderCreationDetail> WorkOrderLines
		{
			get;
			private set;
		}

		/// <summary>
		/// Work Order Lines
		/// </summary>
		public List<WorkOrderCreationDetail> WorkOrderHeaders
		{
			get;
			private set;
		}

		#endregion

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="xmlToDeserialise"></param>
		public WorkOrderCreation(string xmlToDeserialise)
		{
			_syncServiceOrder = genericUtilities.DeserializeXmlToObject<SyncServiceOrder>(xmlToDeserialise);

			if (_syncServiceOrder != null
				&& _syncServiceOrder.DataArea != null
				&& !_syncServiceOrder.DataArea.ServiceOrder.IsNullOrEmpty()
				&& !_syncServiceOrder.DataArea.ServiceOrder[0].ServiceOrderLine.IsNullOrEmpty())
			{
				bool merged = _syncServiceOrder.DataArea.ServiceOrder[0].ServiceOrderLine.Count > 1;

				WorkOrderLines = _syncServiceOrder.DataArea.ServiceOrder[0].ServiceOrderLine.Select(E => new WorkOrderCreationDetail(E, merged)).ToList();

				WorkOrderHeaders = new List<WorkOrderCreationDetail>
                {
                    new WorkOrderCreationDetail(_syncServiceOrder.DataArea.ServiceOrder[0].ServiceOrderHeader, merged)
                };
			}
		}

		/// <summary>
		/// Get comments from work order:
		///   - if ScheduleType is Adhoc:
		///      + the Description is sent in the Service Comments' input of the request (saved in [CoreDataModel].[T_MaintenanceActivityOrder].[AdhocRequestComment])
		///      + Notes are saved in [CoreDataModel].[T_MaintenanceActivityOrder].[Comment]
		///   - other Schedule types:
		///      + both Description and Notes are saved in [CoreDataModel].[T_MaintenanceActivityOrder].[Comment]
		/// The reason for this separation is related with the limitation of field AdhocRequestComment, which is limited to 512 characters,
		/// and was requested by the Customer as per info in Bug 216860, in order the maximize the number of characters available for ServiceComments for MAOs
		/// of type Adhoc (to prevent reaching the max of 512 char). The Customer also requested to discard the Description and Notes coming in the header
		/// of the work order, since the content of these was the same as in the Order Line.
		/// </summary>
		/// <param name="orderLineNumber">Specific Work Order Line</param>
		/// <param name="isAdhoc">Boolean to identify whether the schedule type is Adhoc</param>
		/// <returns>Comment for the Work Order Line</returns>
		public Dictionary<string, string> GetOrderLineComment(string orderLineNumber, bool isAdhoc)
		{
			WorkOrderCreationDetail orderLine = WorkOrderLines.FirstOrDefault(l => l.OrderLineNumber.CompareStrings(orderLineNumber));

			Dictionary<string, string> maoComments = new Dictionary<string, string>();

			StringBuilder adhocComment = new StringBuilder();

			StringBuilder notes = new StringBuilder();

			// If the Operation has description, add it to the comments
			if (!string.IsNullOrEmpty(orderLine.Description))
			{
				// If schedule type is Adhoc, separate the Description from the Notes
				if (isAdhoc)
				{
					adhocComment.AppendLine().AppendLine(ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomERPMaintenanceIntegrationCommentsOperationLocalizedMessage));

					adhocComment.AppendLine().Append(ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomERPMaintenanceIntegrationCommentsDescriptionLocalizedMessage, orderLine.Description));

				}
				else
				{
					notes.AppendLine().AppendLine(ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomERPMaintenanceIntegrationCommentsOperationLocalizedMessage));

					notes.AppendLine().Append(ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomERPMaintenanceIntegrationCommentsDescriptionLocalizedMessage, orderLine.Description));
				}
			}

			maoComments[IKEAConstants.CustomMaoAdhocComment] = adhocComment.ToString() ?? string.Empty;

			// If the Operation has notes, add them to the comments
			if (!string.IsNullOrEmpty(orderLine.Note))
			{
				// If schedule type is Adhoc, Notes are captured without the Description
				if (isAdhoc)
				{
					notes.AppendLine().AppendLine(ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomERPMaintenanceIntegrationCommentsOperationLocalizedMessage));

					notes.AppendLine().Append(ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomERPMaintenanceIntegrationCommentsNotesLocalizedMessage, orderLine.Note));
				}
				else
				{
					notes.AppendLine().Append(ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomERPMaintenanceIntegrationCommentsNotesLocalizedMessage, orderLine.Note));
				}
			}
			
			maoComments[IKEAConstants.CustomMaoNotes] = notes.ToString() ?? string.Empty;

			return maoComments;

		}
	}
}
