﻿using System;

namespace Cmf.Custom.IKEA.Common.ERP.Maintenance
{
    /// <summary>
    /// Class representing the MES to ERP communication integration entry message specific to Maintenance.
    /// </summary>
    [Serializable]
    public class MaintenanceMESERPCommunication : MESERPCommunication
    {
        /// <summary>
        /// The name of the MaintenanceActivityOrder.
        /// </summary>
        public string MaintenanceActivityOrderName { get; set; }
    }
}
