﻿using Cmf.Custom.IKEA.Common.ERP.Maintenance.M3;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cmf.Common.CustomActionUtilities;

namespace Cmf.Custom.IKEA.Common.ERP.Maintenance
{
	public class WorkOrderCreationDetail
	{

		#region Private Variables

		private ServiceOrderLine _serviceOrderLine;
		private ServiceOrderHeaderType _serviceOrderHeader;
		private DateTime? _scheduledEndtDate;
		private DateTime? _scheduledStartDate;
		private bool _merged;

		#endregion

		#region Properties

		/// <summary>
		/// Order Line Number
		/// </summary>
		public string OrderLineNumber
		{
			get
			{
				string orderLineNumber = string.Empty;

				if (_serviceOrderLine != null
					&& _serviceOrderLine.LineNumber != null)
				{
					orderLineNumber = _serviceOrderLine.LineNumber.Value;
				}

				return orderLineNumber;
			}
		}

		/// <summary>
		/// Work Order Type
		/// </summary>
		public string WorkOrderType
		{
			get
			{
				string workOrderType = string.Empty;

				if (_serviceOrderLine != null
					&& _serviceOrderLine.ActivityTemplateCode != null)
				{
					workOrderType = _serviceOrderLine.ActivityTemplateCode.Value;
				}

				return workOrderType;
			}
		}

		/// <summary>
		/// Equipment UID for Non-Merged Work Orders
		/// </summary>
		private string EquipmentUIDNonMerged
		{
			get
			{
				string equipmentUIDNonMerged = string.Empty;

				if (_serviceOrderLine != null
					&& !_serviceOrderLine.ConfiguredAsset.IsNullOrEmpty()
					&& _serviceOrderLine.ConfiguredAsset[0].ID != null)
				{
					equipmentUIDNonMerged = _serviceOrderLine.ConfiguredAsset[0].ID.Value.Substring(0, 8);
				}

				return equipmentUIDNonMerged;
			}
		}

		/// <summary>
		/// Equipment UID for Merged Work Orders
		/// </summary>
		private string EquipmentUIDMerged
		{
			get
			{
				string equipmentUIDNonMerged = string.Empty;

				if (_serviceOrderLine != null
					&& !_serviceOrderLine.Failure.IsNullOrEmpty()
					&& !_serviceOrderLine.Failure[0].ID.IsNullOrEmpty())
				{
					equipmentUIDNonMerged = _serviceOrderLine.Failure[0].ID[0].Value.Substring(0, 8);
				}

				return equipmentUIDNonMerged;
			}
		}
		
		/// <summary>
		/// Equipment UID
		/// </summary>
		public string EquipmentUID
		{
			get
			{
				return _merged ? EquipmentUIDMerged : EquipmentUIDNonMerged;
			}
		}

		/// <summary>
		/// Original Scheduled Start Date
		/// </summary>
		public string OriginalScheduledStartDateString
		{
			get
			{
				string scheduledStartDate = string.Empty;

				if (_serviceOrderLine != null
					&& _serviceOrderLine.PlannedTimePeriod != null)
				{
					scheduledStartDate = _serviceOrderLine.PlannedTimePeriod.StartDateTime;
				}

				return scheduledStartDate;
			}
		}

		/// <summary>
		/// Original Scheduled End Date
		/// </summary>
		public string OriginalScheduledEndDateString
		{
			get
			{
				string scheduledEndDate = string.Empty;

				if (_serviceOrderLine != null
					&& _serviceOrderLine.PlannedTimePeriod != null)
				{
					scheduledEndDate = _serviceOrderLine.PlannedTimePeriod.EndDateTime;
				}

				return scheduledEndDate;
			}
		}

		/// <summary>
		/// Scheduled Start Date
		/// </summary>
		public DateTime ScheduledStartDate
		{
			get
			{
				if (_scheduledStartDate == null)
				{
					_scheduledStartDate = DateTime.Parse(OriginalScheduledStartDateString);
					// Remove Milliseconds to prevent errors of comparisons
					_scheduledStartDate = _scheduledStartDate.Value.AddMilliseconds(-_scheduledStartDate.Value.Millisecond);
				}

				return _scheduledStartDate.Value;
			}
			set
			{
				_scheduledStartDate = value;
			}
		}

		/// <summary>
		/// Scheduled End Date
		/// </summary>
		public DateTime ScheduledEndDate
		{
			get
			{
				if (_scheduledEndtDate == null)
				{
					_scheduledEndtDate = DateTime.Parse(OriginalScheduledEndDateString);
					// Remove Milliseconds to prevent errors of comparisons
					_scheduledEndtDate = _scheduledEndtDate.Value.AddMilliseconds(-_scheduledEndtDate.Value.Millisecond);
				}

				return _scheduledEndtDate.Value;
			}
			set
			{
				_scheduledEndtDate = value;
			}
		}

		/// <summary>
		/// Description
		/// </summary>
		public string Description
		{
			get
			{
				string description = string.Empty;

				if (_serviceOrderLine != null
					&& !_serviceOrderLine.Description.IsNullOrEmpty())
				{
					description = string.Join("\n", _serviceOrderLine.Description.Select(d => d.Value).ToList());
				}

				return description;
			}
		}

		/// <summary>
		/// Note
		///  - Concatenates Note elements that have attributes
		/// </summary>
		public string Note
		{
			get
			{
				string note = string.Empty;

				if (_serviceOrderLine != null
					&& !_serviceOrderLine.Note.IsNullOrEmpty())
				{
					// The Work Order coming from ERP may have elements <Note> that only concatenate the previous <Note> elements.
					// These <Note> elements that only concatenate previous notes do not have attributes; they are being discarded to maximize
					// the number of characters available for ServiceComments, when requesting MAOs for Maintenance Activities
					// of schedule type Adhoc (has a limit of 512 characters).
					note = string.Join("\n", _serviceOrderLine.Note.Where(d => !string.IsNullOrEmpty(d.noteID)).Select(d => d.Value).ToList());
				}

				return note;
			}
		}

		/// <summary>
		/// Status
		/// </summary>
		public string Status
		{
			get
			{
				string status = string.Empty;

				if (_serviceOrderLine != null
					&& !_serviceOrderLine.Status.IsNullOrEmpty()
					&& _serviceOrderLine.Status[0].ReasonCode != null)
				{
					status = _serviceOrderLine.Status[0].ReasonCode.Value;
				}

				return status;
			}
		}


		/// <summary>
		/// CustomerTimePeriod - StartDateTime
		/// </summary>
		public string CustomerTimePeriodStartDateTime
		{
			get
			{
				string CustomerTimePeriodStartDateTime = string.Empty;

				if (_serviceOrderHeader != null
					&& _serviceOrderHeader.CustomerTimePeriod != null)
				{
					CustomerTimePeriodStartDateTime = _serviceOrderHeader.CustomerTimePeriod.StartDateTime;
				}

				return CustomerTimePeriodStartDateTime;
			}
		}

		#endregion

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="serviceOrderLine">Order Line</param>
		/// <param name="merged">Merged Work Order?</param>
		public WorkOrderCreationDetail(ServiceOrderLine serviceOrderLine, bool merged)
		{
			_serviceOrderLine = serviceOrderLine;
			_merged = merged;
		}

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="serviceOrderHeader"></param>
		/// <param name="merged"></param>
		public WorkOrderCreationDetail(ServiceOrderHeaderType serviceOrderHeader, bool merged)
		{
			_serviceOrderHeader = serviceOrderHeader;
			_merged = merged;
		}
	}
}
