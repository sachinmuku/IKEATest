﻿using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;

namespace Cmf.Custom.IKEA.Common.ERP.Maintenance
{
    public class WorkOrderCloseCommunication : WorkOrderUpdateCommunication
    {
        private static IIKEAUtilities ikeaUtilities => ApplicationContext.CurrentServiceProvider.GetService<IIKEAUtilities>();

        // Default constructor:
        public WorkOrderCloseCommunication() : base()
        {

        }

        // Constructor sets the workordernumer:
        public WorkOrderCloseCommunication(IMaintenanceActivityOrder maintenanceActivityOrder) : base(maintenanceActivityOrder)
        {
            this.ManualCompletionFlag = IKEAConstants.ERPDefaultManualCompletionFlag;
        }

        public IIntegrationEntry SendCloseWorkOrderToERP()
        {
            IIntegrationEntry ie = null;

            if (!string.IsNullOrEmpty(this.WorkOrderNumber))
            {
                // Create the Integration Entry
                ie = ikeaUtilities.CreateJsonIntegrationEntry(this,
                                                            IKEAConstants.ERPMaintenanceCloseWorkOrder,
                                                            IKEAConstants.ERPMaintenanceHandleWorkOrderMessageType,
                                                            IKEAConstants.ERPMaintenanceUpdateWorkOrderEventName);
            }
            return ie;
        }


    }
}
