﻿using System;
using Newtonsoft.Json;

namespace Cmf.Custom.IKEA.Common.ERP.Maintenance
{
    /// <summary>
    /// Class representing the payload sent when requesting a new Work Order from ERP.
    /// </summary>
    [Serializable]
    public class NewWorkOrderRequest : BaseERPCommunication
    {
        /// <summary>
        /// TailNumber/ERP Maintenance facility.
        /// </summary>
        [JsonProperty("TAIL")]
        public string ERPMaintenanceFacilityCode { get; set; }

        /// <summary>
        /// Equipment number in ERP.
        /// </summary>
        [JsonProperty("EQNO")]
        public string EquipmentNumber { get; set; }

        /// <summary>
        /// STRT.
        /// </summary>
        [JsonProperty("STRT")]
        public string STRT { get; } = "600";

        /// <summary>
        /// Maintenance Activity Order's type.
        /// </summary>
        [JsonProperty("SUFI")]
        public string MAOType { get; set; }

        /// <summary>
        /// RESP.
        /// </summary>
        [JsonProperty("RESP")]
        public string RESP { get; } = string.Empty;

        /// <summary>
        /// detailed Description.
        /// </summary>
        [JsonProperty("TX40")]
        public string TXT3 { get; set; }

        /// <summary>
        /// Description.
        /// </summary>
        [JsonProperty("TXT1")]
        public string TXT1 { get; set; }

        /// <summary>
        /// Signature.
        /// </summary>
        [JsonProperty("TXT2")]
        public string TXT2 { get; set; }

        /// <summary>
        /// ERP Facility (different from ERPMaintenanceFacility).
        /// </summary>
        [JsonProperty("FACI")]
        public string ERPFacility { get; set; }

        /// <summary>
        /// User requesting the Order.
        /// </summary>
        [JsonProperty("RREQ")]
        public string OrderRequestUser { get; set; }

        /// <summary>
        /// Employee's identifier. This is an optional field, used for autonomous maintenance.
        /// </summary>
        [JsonProperty("EMNO")]
        public string EmployeeId { get; set; }

        /// <summary>
        /// Workgroup.
        /// </summary>
        [JsonProperty("PLGR")]
        public string Workgroup { get; set; }

        /// <summary>
        /// ScheduleDate.
        /// </summary>
        [JsonProperty("RRSD")]
        public string ScheduleDate { get; set; }

        /// <summary>
        /// ScheduleTime.
        /// </summary>
        [JsonProperty("RRST")]
        public string ScheduleTime { get; set; }

        /// <summary>
        /// Default empty constructor.
        /// </summary>
        public NewWorkOrderRequest() : base()
        {
            //The company field is filled by calling the parent constructor
        }
    }
}
