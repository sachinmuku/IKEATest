﻿using Cmf.Custom.IKEA.Common.Exceptions;
using Cmf.Foundation.Common;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Common.ERP
{
    public class ERPBOMProduct
    {
        /// <summary>
        /// Product Name (MTNO)
        /// </summary>
        public string Product { get; set; }

        /// <summary>
        /// ERP BOM OperationSequence (MSEQ)
        /// </summary>
        public int ERPBOMOperationSequence { get; set; }

        /// <summary>
        /// Process Segment (ACTS)
        /// </summary>
        public string ProcessSegment { get; set; }

        /// <summary>
        /// Sub Process Segment (FMT2)
        /// </summary>
        public string SubProcessSegment { get; set; }

        /// <summary>
        /// Is By-Product Segment (BYPR)
        /// </summary>
        public bool IsByProductSegment { get; set; }

        /// <summary>
        /// IsReference (SPMT).
        /// If value is different that 2 than is reference
        /// </summary>
        public bool IsReference { get; set; }

        /// <summary>
        /// Quantity (CNQT)
        /// </summary>
        public decimal Quantity { get; set; }

        /// <summary>
        /// Units (PEUN)
        /// </summary>
        public string Units { get; set; }

        /// <summary>
        /// Empty Constructor
        /// </summary>
        public ERPBOMProduct()
        {
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="erpBOMOperationSequence">ERP BOM OperationSequence (MSEQ)</param>
        /// <param name="erpBOMProductDetails">ERP BOM Product details</param>
        public ERPBOMProduct(int erpBOMOperationSequence, Dictionary<string, string> erpBOMProductDetails)
        {
            ERPBOMOperationSequence = erpBOMOperationSequence;

            #region Validate required fields
            // Validate mandatory field ERP_SPMT:
            if (!erpBOMProductDetails.ContainsKey(IKEAConstants.ERP_SPMT))
            {
                throw new IKEAException(IKEAConstants.CustomERPOrderMissingFieldErrorLocalizedMessage, IKEAConstants.ERP_SPMT, erpBOMOperationSequence.ToString());
            }
            // Validate mandatory field ERP_CNQT:
            if (!erpBOMProductDetails.ContainsKey(IKEAConstants.ERP_CNQT))
            {
                throw new IKEAException(IKEAConstants.CustomERPOrderMissingFieldErrorLocalizedMessage, IKEAConstants.ERP_CNQT, erpBOMOperationSequence.ToString());
            }
            // Validate mandatory field ERP_PEUN:
            if (!erpBOMProductDetails.ContainsKey(IKEAConstants.ERP_PEUN))
            {
                throw new IKEAException(IKEAConstants.CustomERPOrderMissingFieldErrorLocalizedMessage, IKEAConstants.ERP_PEUN, erpBOMOperationSequence.ToString());
            }
            // Validate mandatory field ERP_MTNO:
            if (!erpBOMProductDetails.ContainsKey(IKEAConstants.ERP_MTNO))
            {
                throw new IKEAException(IKEAConstants.CustomERPOrderMissingFieldErrorLocalizedMessage, IKEAConstants.ERP_MTNO, erpBOMOperationSequence.ToString());
            }
            #endregion

            string isReference = erpBOMProductDetails[IKEAConstants.ERP_SPMT];

            // If value is different that 2 than is reference
            IsReference = string.IsNullOrWhiteSpace(isReference) || isReference.CompareStrings("2") ? false : true;

            if (erpBOMProductDetails.ContainsKey(IKEAConstants.ERP_ACTS))
            {
                ProcessSegment = erpBOMProductDetails[IKEAConstants.ERP_ACTS];
            }

            if (erpBOMProductDetails.ContainsKey(IKEAConstants.ERP_FMT2))
            {
                SubProcessSegment = erpBOMProductDetails[IKEAConstants.ERP_FMT2];
            }

            IsByProductSegment = false;

            if (erpBOMProductDetails.ContainsKey(IKEAConstants.ERP_BYPR))
            {
                string isByProductString = erpBOMProductDetails[IKEAConstants.ERP_BYPR];
                IsByProductSegment = !string.IsNullOrEmpty(isByProductString) && isByProductString.CompareStrings("1") ? true : false;
            }

            string quantity = erpBOMProductDetails[IKEAConstants.ERP_CNQT];
            Quantity = String.IsNullOrWhiteSpace(quantity) ? decimal.Zero : decimal.Parse(quantity, NumberStyles.Any, CultureInfo.InvariantCulture);

            Units = erpBOMProductDetails[IKEAConstants.ERP_PEUN].ToLower();
            Product = erpBOMProductDetails[IKEAConstants.ERP_MTNO];
        }


        /// <summary>
        /// Clone ERPBOMProduct
        /// </summary>
        /// <param name="source"></param>
        public void Clone(ERPBOMProduct source)
        {
            this.Product = source.Product;
            this.ERPBOMOperationSequence = source.ERPBOMOperationSequence;
            this.ProcessSegment = source.ProcessSegment;
            this.SubProcessSegment = source.SubProcessSegment;
            this.IsByProductSegment = source.IsByProductSegment;
            this.IsReference = source.IsReference;
            this.Quantity = source.Quantity;
            this.Units = source.Units;
        }
    }
}
