﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace Cmf.Custom.IKEA.Common.ERP
{

    /// <summary>
    /// Class representing the structure of the ERP Work Order response's body.
    /// </summary>
    [XmlRoot(ElementName = "miResult", Namespace = "http://lawson.com/m3/miaccess")]
    public class NewProductionOrderResponse
    {
        [XmlElement("Program")]
        public string Program { get; set; }

        [XmlElement("Transaction")]
        public string Transaction { get; set; }

        [XmlElement("Metadata")]
        public NewProductionOrderResponseMetadata Metadata { get; set; }

        [XmlElement("MIRecord")]
        public NewProductionOrderResponseMIRecord MIRecord { get; set; }
    }


    /// <summary>
    /// Wrapper class representing the Metadata element of the body.
    /// </summary>
    [XmlRoot("Metadata")]
    public class NewProductionOrderResponseMetadata
    {
        [XmlElement("Field")]
        public List<NewProductionOrderResponseMetadataField> Fields { get; set; }
    }

    /// <summary>
    /// Class representing the structure of metadata's Field elements.
    /// The metadata fields provide additional information for each NameValue element.
    /// </summary>
    [XmlRoot("Field")]
    public class NewProductionOrderResponseMetadataField
    {
        [XmlAttribute("name")]
        public string Name { get; set; }

        [XmlAttribute("type")]
        public string Type { get; set; }

        [XmlAttribute("length")]
        public string Length { get; set; }

        [XmlAttribute("description")]
        public string Description { get; set; }
    }

    /// <summary>
    /// Class representing the structure of the MIRecord element.
    /// </summary>
    [XmlRoot("MIRecord")]
    public class NewProductionOrderResponseMIRecord
    {
        [XmlElement("RowIndex")]
        public string RowIndex { get; set; }

        [XmlElement("NameValue")]
        public List<NewProductionOrderResponseNameValue> NameValues { get; set; }
    }

    /// <summary>
    /// Class representing the structure of MIRecord's NameValue elements.
    /// </summary>
    [XmlRoot("NameValue")]
    public class NewProductionOrderResponseNameValue
    {
        [XmlElement("Name")]
        public string Name { get; set; }

        [XmlElement("Value")]
        public string Value { get; set; }
    }






}
