﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Common.ERP
{
    [Serializable]
    public class WorkCenterDispatchCommunication
    {
        public string Resource;
        public string Material;
        public string ProductionOrder;
        public string Quantity;
        public string DateAndTime;
    }
}
