﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Common.ERP
{
    /// <summary>
    /// Class that represent the communication of the Material Split to the ERP
    /// </summary>
    [Serializable]
    public class MaterialSplitMergeCommunication : BaseERPCommunication
    {
        [JsonProperty(PropertyName = "PRFL")]
        public string ProcessFlag { get; set; }

        [JsonProperty(PropertyName = "MSNR")]
        public string MessageNumber { get; } = string.Empty;

        [JsonProperty(PropertyName = "MSLN")]
        public string MessageLineNumber { get; } = string.Empty;

        [JsonProperty(PropertyName = "MSGS")]
        public string SequenceNumber { get; } = string.Empty;

        [JsonProperty(PropertyName = "GEDT")]
        public string DateGenerated { get; } = string.Empty;

        [JsonProperty(PropertyName = "GETM")]
        public string TimeGenerated { get; } = string.Empty;

        [JsonProperty(PropertyName = "E0PA")]
        public string Partner { get; set; }

        [JsonProperty(PropertyName = "E065")]
        public string MessageType { get; set; }

        [JsonProperty(PropertyName = "WHLO")]
        public string Warehouse { get; set; }

        [JsonProperty(PropertyName = "WHSL")]
        public string Location { get; set; }

        [JsonProperty(PropertyName = "ITNO")]
        public string ItemNumber { get; set; }

        [JsonProperty(PropertyName = "BANO")]
        public string LotNumber { get; } = string.Empty;

        [JsonProperty(PropertyName = "CAMU")]
        public string Container { get; set; }

        [JsonProperty(PropertyName = "REPN")]
        public string ReceivingNumber { get; } = string.Empty;

        [JsonProperty(PropertyName = "POPN")]
        public string AliasNumber { get; } = string.Empty;

        [JsonProperty(PropertyName = "ALWQ")]
        public string AliasQualifier { get; } = string.Empty;

        [JsonProperty(PropertyName = "ALWT")]
        public string AliasType { get; } = string.Empty;

        [JsonProperty(PropertyName = "QLQT")]
        public string Quantity { get; set; }

        [JsonProperty(PropertyName = "QLUN")]
        public string QualifierUnitOfMeasure { get; } = string.Empty;

        [JsonProperty(PropertyName = "QLDT")]
        public string QualifierDate { get; } = string.Empty;

        [JsonProperty(PropertyName = "TWSL")]
        public string ToLocation { get; set; }

        [JsonProperty(PropertyName = "TOCA")]
        public string ToContainer { get; set; }

        [JsonProperty(PropertyName = "CAWE")]
        public string CatchWeight { get; } = string.Empty;

        [JsonProperty(PropertyName = "BREM")]
        public string Remark { get; } = string.Empty;

        [JsonProperty(PropertyName = "BREF")]
        public string LotReference1 { get; } = string.Empty;

        [JsonProperty(PropertyName = "BRE2")]
        public string LotReference2 { get; } = string.Empty;

        [JsonProperty(PropertyName = "USD1")]
        public string UserDefined1 { get; } = string.Empty;

        [JsonProperty(PropertyName = "USD2")]
        public string UserDefined2 { get; } = string.Empty;

        [JsonProperty(PropertyName = "USD3")]
        public string UserDefined3 { get; } = string.Empty;

        [JsonProperty(PropertyName = "USD4")]
        public string UserDefined4 { get; } = string.Empty;

        [JsonProperty(PropertyName = "USD5")]
        public string UserDefined5 { get; } = string.Empty;

        [JsonProperty(PropertyName = "TASN")]
        public string TaskNumber { get; } = string.Empty;

        [JsonProperty(PropertyName = "PMSN")]
        public string ExternalMessageNumber { get; } = string.Empty;

        [JsonProperty(PropertyName = "QLTM")]
        public string QualifierTime { get; } = string.Empty;

        [JsonProperty(PropertyName = "RESP")]
        public string Responsible { get; set; }
    }
}
