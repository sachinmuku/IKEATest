﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Common.ERP
{

    [Serializable]
    public class OrderMaterialCompletion : BaseERPCommunication
    {
        [JsonProperty(PropertyName = "FACI")]
        public string Facility { get; set; }

        [JsonProperty(PropertyName = "PRNO")]
        public string ProductionNumber { get; set; }

        [JsonProperty(PropertyName = "MFNO")]
        public string ManufacturingOrderNumber { get; set; }

        [JsonProperty(PropertyName = "OPNO")]
        public string ERPOperation { get; set; }

        [JsonProperty(PropertyName = "WOSQ")]
        public string ReportingNumber { get; } = string.Empty;

        [JsonProperty(PropertyName = "PLNO")]
        public string ProductionLotNumber { get; } = string.Empty;


        [JsonProperty(PropertyName = "RPDT")]
        public string ReportingDate { get; set; }

        // The RPTM field should always be left empty:
        [JsonProperty(PropertyName = "RPTM")]
        public string ReportingTime { get; }

        [JsonProperty(PropertyName = "PEWA")]
        public string PayrollPeriod { get; } = string.Empty;

        [JsonProperty(PropertyName = "UMAT")]
        public string UsedLaborRuntime { get; } = string.Empty;

        [JsonProperty(PropertyName = "UMAS")]
        public string UsedLaborSetupTime { get; } = string.Empty;

        [JsonProperty(PropertyName = "UPIT")]
        public string UsedMachineRuntime { get; } = string.Empty;

        [JsonProperty(PropertyName = "USET")]
        public string UsedMachineSetupTime { get; } = string.Empty;

        [JsonProperty(PropertyName = "RUDI")]
        public string RunDisturbance { get; } = string.Empty;

        [JsonProperty(PropertyName = "SEDI")]
        public string SetupDisturbance { get; } = string.Empty;

        [JsonProperty(PropertyName = "MAQA")]
        public string ManufacturedQuantity { get; set; }

        [JsonProperty(PropertyName = "MAUN")]
        public string ManufacturingUnitsOfMesurement { get; set; }

        [JsonProperty(PropertyName = "SCQA")]
        public string ScrapQuantityAlternativeUnit { get; set; } = string.Empty;

        [JsonProperty(PropertyName = "SCRE")]
        public string RejectionReason { get; set; } = string.Empty;

        [JsonProperty(PropertyName = "SCWC")]
        public string ScrapSourceWorkcenter { get; } = string.Empty;

        [JsonProperty(PropertyName = "REND")]
        public string ManualCompletionFlag { get; set; }

        [JsonProperty(PropertyName = "EMNO")]
        public string EmployeeNumber { get; } = string.Empty;

        [JsonProperty(PropertyName = "PCTP")]
        public string CostingType { get; } = string.Empty;

        [JsonProperty(PropertyName = "SHFC")]
        public string Shift { get; } = string.Empty;

        [JsonProperty(PropertyName = "MSNO")]
        public string Resource { get; set; }

        // The TRDT field should always be left empty:
        [JsonProperty(PropertyName = "TRDT")]
        public string TransationDate { get; }

        [JsonProperty(PropertyName = "TRTM")]
        public string TransactionTime { get; set; }

        [JsonProperty(PropertyName = "PRNP")]
        public string PlannedNumberOfWorkersRuntime { get; } = string.Empty;

        [JsonProperty(PropertyName = "SENP")]
        public string PlannedNumberOfWorkersSetup { get; } = string.Empty;

        [JsonProperty(PropertyName = "REWK")]
        public string Rework { get; } = "0";

        [JsonProperty(PropertyName = "DPLG")]
        public string DeviatingWorkcenter { get; set; } = string.Empty;

        [JsonProperty(PropertyName = "SEPR")]
        public string SetupPrice { get; } = string.Empty;

        [JsonProperty(PropertyName = "SUNO")]
        public string SupplierNumber { get; } = string.Empty;

        [JsonProperty(PropertyName = "PIPR")]
        public string UnitPrice { get; } = string.Empty;

        [JsonProperty(PropertyName = "TODL")]
        public string TotalAmountDirectLabor { get; } = string.Empty;

        [JsonProperty(PropertyName = "REMK")]
        public string Remark { get; } = string.Empty;

        [JsonProperty(PropertyName = "WAFA")]
        public string Timerate { get; } = string.Empty;

        [JsonProperty(PropertyName = "KIWG")]
        public string PayElement { get; } = string.Empty;

        [JsonProperty(PropertyName = "CHID")]
        public string Changedby { get; } = string.Empty;

        [JsonProperty(PropertyName = "DSP1")]
        public string WarningIndicator1 { get; } = "1";

        [JsonProperty(PropertyName = "DSP2")]
        public string WarningIndicator2 { get; } = "1";

        [JsonProperty(PropertyName = "DSP3")]
        public string WarningIndicator3 { get; } = "1";

        [JsonProperty(PropertyName = "DSP4")]
        public string WarningIndicator4 { get; } = "1";

        [JsonProperty(PropertyName = "CAMU")]
        public string Container { get; } = string.Empty;

        [JsonProperty(PropertyName = "BANO")]
        public string LotNumber { get; } = string.Empty;

        [JsonProperty(PropertyName = "DSPA")]
        public string CreateAttribute { get; } = string.Empty;

        [JsonProperty(PropertyName = "UTCM")]
        public string UTCMode { get; } = "0";

    }
}
