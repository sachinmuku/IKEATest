﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Common.ERP
{
    public class ERPOrderlessPalletizationCompletionCommunication : BaseERPCommunication
    {
        #region Mandatory Fields

        [JsonProperty(PropertyName = "WHLO")]
        public string Warehouse { get; set; }

        [JsonProperty(PropertyName = "PRNO")]
        public string ProductionNumber { get; set; }

        [JsonProperty(PropertyName = "STRT")]
        public string StructureType { get; set; }

        [JsonProperty(PropertyName = "ORQT")]
        public string OrderQuantity { get; set; }

        #endregion

        #region Optional Fields

        [JsonProperty(PropertyName = "CONO")]
        public string CompanyNumber { get; set; } = string.Empty;

        [JsonProperty(PropertyName = "WHSL")]
        public string Location { get; set; } = string.Empty;

        [JsonProperty(PropertyName = "BANO")]
        public string LotNumber { get; set; } = string.Empty;

        [JsonProperty(PropertyName = "CAMU")]
        public string Container { get; set; } = string.Empty;

        [JsonProperty(PropertyName = "PAC2")]
        public string Packaging2 { get; set; } = string.Empty;

        [JsonProperty(PropertyName = "CAWE")]
        public string CatchWeight { get; set; } = string.Empty;

        [JsonProperty(PropertyName = "POCY")]
        public string Potency { get; set; } = string.Empty;

        [JsonProperty(PropertyName = "MAUN")]
        public string AlternateUnitOfMeasure { get; set; } = string.Empty;

        [JsonProperty(PropertyName = "STAS")]
        public string BalanceStatus { get; set; } = string.Empty;

        [JsonProperty(PropertyName = "TRDT")]
        public string TransactionDate { get; set; } = string.Empty;

        [JsonProperty(PropertyName = "SHFC")]
        public string Shift { get; set; } = string.Empty;

        [JsonProperty(PropertyName = "PAII")]
        public string IncludedInPackageNumber { get; set; } = string.Empty;

        [JsonProperty(PropertyName = "PACT")]
        public string Packaging { get; set; } = string.Empty;

        [JsonProperty(PropertyName = "TDT2")]
        public string TransactionDate2 { get; set; } = string.Empty;

        [JsonProperty(PropertyName = "LIRR")]
        public string LIRequestRule { get; set; } = string.Empty;

        [JsonProperty(PropertyName = "HVDT")]
        public string HarvestedDate { get; set; } = string.Empty;

        [JsonProperty(PropertyName = "EXPI")]
        public string ExpirationDate { get; set; } = string.Empty;

        #endregion
    }
}
