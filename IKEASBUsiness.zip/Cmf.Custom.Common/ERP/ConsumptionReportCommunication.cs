﻿using Newtonsoft.Json;
using System;

namespace Cmf.Custom.IKEA.Common.ERP
{
    [Serializable]
    public class ConsumptionReportCommunication : BaseERPCommunication
    {
        [JsonProperty(PropertyName = "FACI")]
        public string Facility { get; set; }

        [JsonProperty(PropertyName = "PRNO")]
        public string ProductionNumber { get; set; }

        [JsonProperty(PropertyName = "MFNO")]
        public string ManufacturingOrderNumber { get; set; }

        [JsonProperty(PropertyName = "OPNO")]
        public string ERPOperation { get; set; }

        [JsonProperty(PropertyName = "MSEQ")]
        public string BOMSequenceNumber { get; set; } = "1";

        [JsonProperty(PropertyName = "WOSQ")]
        public string ReportingNumber { get; } = string.Empty;

        [JsonProperty(PropertyName = "MTNO")]
        public string BaseProduct { get; set; }

        [JsonProperty(PropertyName = "RPDT")]
        public string ReportingDate { get; set; }

        // The RPTM field should always be left empty:
        [JsonProperty(PropertyName = "RPTM")]
        public string ReportingTime { get; }

        // The TRDT field should always be left empty:
        [JsonProperty(PropertyName = "TRDT")]
        public string TransationDate { get; }

        [JsonProperty(PropertyName = "TRTM")]
        public string TransationTime { get; set; }

        [JsonProperty(PropertyName = "RPQA")]
        public string ReportQuantityInAlternativeUnit { get; set; }

        [JsonProperty(PropertyName = "PEUN")]
        public string BOMProductUnit { get; set; }

        [JsonProperty(PropertyName = "REND")]
        public string ManualCompletionFlag { get; } = "0";

        [JsonProperty(PropertyName = "WHSL")]
        public string Location { get; set; }

        [JsonProperty(PropertyName = "BANO")]
        public string LotNumber { get; } = string.Empty;

        [JsonProperty(PropertyName = "CAMU")]
        public string Container { get; set; }

        [JsonProperty(PropertyName = "BREF")]
        public string LotReference1 { get; } = string.Empty;

        [JsonProperty(PropertyName = "BRE2")]
        public string LotReference2 { get; } = string.Empty;

        [JsonProperty(PropertyName = "CAWE")]
        public string CatchWeight { get; } = string.Empty;

        [JsonProperty(PropertyName = "CHID")]
        public string ChangedBy { get; } = string.Empty;

        [JsonProperty(PropertyName = "DSP1")]
        public string WarningIndicator1 { get; } = "1";

        [JsonProperty(PropertyName = "DSP2")]
        public string WarningIndicator2 { get; } = "1";

        [JsonProperty(PropertyName = "DSP3")]
        public string WarningIndicator3 { get; } = "1";

        [JsonProperty(PropertyName = "DSP4")]
        public string WarningIndicator4 { get; } = "1";

        [JsonProperty(PropertyName = "DSP5")]
        public string WarningIndicator5 { get; } = "1";

        [JsonProperty(PropertyName = "DSP6")]
        public string WarningIndicator6 { get; } = "1";

        [JsonProperty(PropertyName = "DSP7")]
        public string WarningIndicator7 { get; } = "1";

    }
}
