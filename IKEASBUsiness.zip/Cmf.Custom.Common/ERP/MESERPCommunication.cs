﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Common.ERP
{
    /// <summary>
    /// Class that represent the base communication integration entry message MES > ERP
    /// </summary>
    [Serializable]
    public class MESERPCommunication
    {
        /// <summary>
        /// Api endpoint
        /// </summary>
        public string API { get; set; }

        /// <summary>
        /// Json string message 
        /// </summary>
        public string Message { get; set; }

        /// <summary>
        /// Optional Context string (used when necessary to handle the ERP response)
        /// </summary>
        public string Context { get; set; } = null;
    }
}
