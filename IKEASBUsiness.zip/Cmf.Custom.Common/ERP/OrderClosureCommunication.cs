﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Common.ERP
{
    /// <summary>
    /// Class that represent the order closure communication
    /// </summary>
    [Serializable]
    public class OrderClosureCommunication : BaseERPCommunication
    {
        [JsonProperty(PropertyName = "CONO")]
        public string Company { get; set; }

        [JsonProperty(PropertyName = "FACI")]
        public string Facility { get; set; }

        [JsonProperty(PropertyName = "PRNO")]
        public string ProductionNumber { get; set; }

        [JsonProperty(PropertyName = "MFNO")]
        public string ManufacturingOrderNumber { get; set; }

        [JsonProperty(PropertyName = "OPNO")]
        public string ERPOperation { get; set; }

        [JsonProperty(PropertyName = "WOSQ")]
        public string ReportingNumber { get; } = string.Empty;

        [JsonProperty(PropertyName = "PLNO")]
        public string ProductionLotNumber { get; } = string.Empty;

        [JsonProperty(PropertyName = "RPDT")]
        public string ReportingDate { get; set; }

        [JsonProperty(PropertyName = "RPDM")]
        public string ReportingTime { get; set; }

        [JsonProperty(PropertyName = "PEWA")]
        public string PayrollPeriod { get; set; } = string.Empty;

        [JsonProperty(PropertyName = "CHID")]
        public string ChangedBy { get; set; } = string.Empty;

        [JsonProperty(PropertyName = "UTCM")]
        public string UTCMode { get; set; } = "0";
    }
}
