﻿using Microsoft.AspNetCore.Mvc;
using Cmf.Custom.IKEA.Orchestration.Abstractions;
using Cmf.Custom.IKEA.Orchestration.InputObjects;
using Cmf.Custom.IKEA.Orchestration.OutputObjects;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Behaviors;
using System;
using System.Collections.Generic;

namespace Cmf.Custom.IKEA.Services
{
    /// <summary>
    /// IKEA Services
    /// </summary>
    [ApiController]
    [Route("api/[controller]/[action]")]
    public class IKEAController : ControllerBase
    {
        private readonly IIKEABusinessManagementOrchestration _iKEABusinessManagementOrchestration;

        private static String objectTypeName = "Cmf.Custom.IKEA.Services.IKEABusinessServices";

        /// <summary>
        /// Initializes a new instance of the <see cref="IKEAController"/> class.
        /// </summary>
        [Microsoft.Extensions.DependencyInjection.ActivatorUtilitiesConstructor]
        public IKEAController(IIKEABusinessManagementOrchestration iKEABusinessManagementOrchestration) : base()
        {
            _iKEABusinessManagementOrchestration = iKEABusinessManagementOrchestration;
        }

        /// <summary>
        /// Completes or aborts a Material on a resource
        /// </summary>
        /// <param name="customStopMaterialInput">Input Objects</param>
        /// <returns>Output Objects</returns>
        [HttpPost]
        public CustomStopMaterialOutput CustomStopMaterial(CustomStopMaterialInput customStopMaterialInput)
        {
            CustomStopMaterialOutput customStopMaterialOutput;

            Utilities.StartMethod(objectTypeName, "CustomStopMaterial",
                  new KeyValuePair<String, Object>("CustomStopMaterialInput", customStopMaterialInput));
            try
            {
                // Invoke orchestration
                customStopMaterialOutput = _iKEABusinessManagementOrchestration.CustomStopMaterial(customStopMaterialInput);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomStopMaterialInput", customStopMaterialInput),
                                                new KeyValuePair<String, Object>("CustomStopMaterialOutput", customStopMaterialOutput));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            return customStopMaterialOutput;
        }

        /// <summary>
        /// Performs the necessary operations to generate a new completed unit of a manufacturing order
        /// </summary>
        /// <param name="customUnitCompleteInput">Input Objects</param>
        /// <returns>Output Objects</returns>
        [HttpPost]
        public CustomUnitCompleteOutput CustomUnitComplete(CustomUnitCompleteInput customUnitCompleteInput)
        {
            CustomUnitCompleteOutput customUnitCompleteOutput;

            Utilities.StartMethod(objectTypeName, "CustomUnitComplete",
                  new KeyValuePair<String, Object>("CustomUnitCompleteInput", customUnitCompleteInput));
            try
            {
                // Invoke orchestration
                customUnitCompleteOutput = _iKEABusinessManagementOrchestration.CustomUnitComplete(customUnitCompleteInput);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomUnitCompleteInput", customUnitCompleteInput),
                                                new KeyValuePair<String, Object>("CustomUnitCompleteOutput", customUnitCompleteOutput));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            return customUnitCompleteOutput;
        }

        /// <summary>
        /// Receives the message from the ION and creates a new integration entry
        /// </summary>
        /// <param name="ikeaIonMessageInput">Input Objects</param>
        /// <returns>Output Objects</returns>
        [HttpPost]
        public IKEAAcknowledgeIonMessageOutput IKEAAcknowledgeIonMessage(IKEAAcknowledgeIonMessageInput ikeaIonMessageInput)
        {
            IKEAAcknowledgeIonMessageOutput ikeaIonMessageOutput;

            Utilities.StartMethod(objectTypeName, "IKEAAcknowledgeIonMessage",
                  new KeyValuePair<String, Object>("IKEAAcknowledgeIonMessageInput", ikeaIonMessageInput));
            try
            {
                // Invoke orchestration
                ikeaIonMessageOutput = _iKEABusinessManagementOrchestration.IKEAAcknowledgeIonMessage(ikeaIonMessageInput);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("IKEAAcknowledgeIonMessageInput", ikeaIonMessageInput),
                                                new KeyValuePair<String, Object>("IKEAAcknowledgeIonMessageOutput", ikeaIonMessageOutput));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            return ikeaIonMessageOutput;
        }

        /// <summary>
        /// Service to retrieve possible feeders and consumers of a Material
        /// </summary>
        /// <param name="customGetMOFutureConsumptionInformationInput">Input Object</param>
        /// <returns>Output Objects</returns>
        [HttpPost]
        public CustomGetMOFutureConsumptionInformationOutput CustomGetMOFutureConsumptionInformation(CustomGetMOFutureConsumptionInformationInput customGetMOFutureConsumptionInformationInput)
        {
            Utilities.StartMethod(objectTypeName, "CustomGetMOFutureConsumptionInformation",
                new KeyValuePair<String, Object>("CustomGetMOFutureConsumptionInformationInput", customGetMOFutureConsumptionInformationInput));

            CustomGetMOFutureConsumptionInformationOutput customGetMOFutureConsumptionInformationOutput = null;

            try
            {
                // Invoke orchestration
                customGetMOFutureConsumptionInformationOutput = _iKEABusinessManagementOrchestration.CustomGetMOFutureConsumptionInformation(customGetMOFutureConsumptionInformationInput);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomGetMOFutureConsumptionInformationInput", customGetMOFutureConsumptionInformationInput),
                                            new KeyValuePair<String, Object>("CustomGetMOFutureConsumptionInformationOutput", customGetMOFutureConsumptionInformationOutput));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            return customGetMOFutureConsumptionInformationOutput;

        }

        /// <summary>
        /// Service to postpone materials
        /// </summary>
        /// <param name="customPostponeMaterialInput">Input Object</param>
        /// <returns>Output Objects</returns>
        [HttpPost]
        public CustomPostponeMaterialOutput CustomPostponeMaterial(CustomPostponeMaterialInput customPostponeMaterialInput)
        {
            Utilities.StartMethod(objectTypeName, "CustomPostponeMaterial",
                new KeyValuePair<String, Object>("CustomPostponeMaterialInput", customPostponeMaterialInput));

            CustomPostponeMaterialOutput customPostponeMaterialOutput = null;

            try
            {
                // Invoke orchestration
                customPostponeMaterialOutput = _iKEABusinessManagementOrchestration.CustomPostponeMaterial(customPostponeMaterialInput);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomPostponeMaterialInput", customPostponeMaterialInput),
                                            new KeyValuePair<String, Object>("CustomPostponeMaterialOutput", customPostponeMaterialOutput));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            return customPostponeMaterialOutput;
        }

        /// <summary>
        /// Service to print label or rfid
        /// </summary>
        /// <param name="customPostponeMaterialInput">Input Object</param>
        /// <returns>Output Objects</returns>
        [HttpPost]
        public CustomPrintLabelOrRfidOutput CustomPrintLabelOrRfid(CustomPrintLabelOrRfidInput customPrintLabelOrRfidInput)
        {
            Utilities.StartMethod(objectTypeName, "CustomPrintLabelOrRfid",
                new KeyValuePair<String, Object>("CustomPrintLabelOrRfidInput", customPrintLabelOrRfidInput));

            CustomPrintLabelOrRfidOutput customPrintLabelOrRfidOutput = null;

            try
            {
                // Invoke orchestration
                customPrintLabelOrRfidOutput = _iKEABusinessManagementOrchestration.CustomPrintLabelOrRfid(customPrintLabelOrRfidInput);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomPrintLabelOrRfidInput", customPrintLabelOrRfidInput),
                                            new KeyValuePair<String, Object>("CustomPrintLabelOrRfidOutput", customPrintLabelOrRfidOutput));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            return customPrintLabelOrRfidOutput;
        }

        /// <summary>
        /// Service to report the consumption of a material
        /// </summary>
        /// <param name="customMaterialConsumptionReportInput">Input Object</param>
        /// <returns>Output Objects</returns>
        [HttpPost]
        public CustomMaterialConsumptionReportOutput CustomMaterialConsumptionReport(CustomMaterialConsumptionReportInput customMaterialConsumptionReportInput)
        {
            Utilities.StartMethod(objectTypeName, "CustomMaterialConsumptionReport",
                new KeyValuePair<String, Object>("CustomMaterialConsumptionReportInput", customMaterialConsumptionReportInput));

            CustomMaterialConsumptionReportOutput output = null;

            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomMaterialConsumptionReport(customMaterialConsumptionReportInput);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomMaterialConsumptionReportInput", customMaterialConsumptionReportInput),
                                            new KeyValuePair<String, Object>("CustomMaterialConsumptionReportOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            return output;
        }

        /// <summary>
        /// Service to scan a barcode and attach a Material
        /// </summary>
        /// <param name="CustomScanInMaterialInput">Input Object</param>
        /// <returns>Output Objects</returns>
        [HttpPost]
        public CustomScanInMaterialOutput CustomScanInMaterial(CustomScanInMaterialInput customScanInMaterialInput)
        {
            Utilities.StartMethod(objectTypeName, "CustomScanInMaterial",
                new KeyValuePair<String, Object>("CustomScanInMaterialInput", customScanInMaterialInput));

            CustomScanInMaterialOutput output = null;

            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomScanInMaterial(customScanInMaterialInput);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomScanInMaterialInput", customScanInMaterialInput),
                                            new KeyValuePair<String, Object>("CustomScanInMaterialOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            return output;
        }

        /// <summary>
        /// Service to receive a filterCollection ad retrieve filtered results for Last Pallet Location Page
        /// </summary>
        /// <param name="CustomGetDataForPalletLocationInput">Input Object</param>
        /// <returns>Output Objects</returns>
        [HttpPost]
        public CustomGetDataForPalletLocationOutput CustomGetDataForPalletLocation(CustomGetDataForPalletLocationInput customGetDataForPalletLocationInput)
        {
            Utilities.StartMethod(objectTypeName, "CustomGetDataForPalletLocation",
                new KeyValuePair<String, Object>("CustomGetDataForPalletLocationInput", customGetDataForPalletLocationInput));

            CustomGetDataForPalletLocationOutput output = null;

            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomGetDataForPalletLocation(customGetDataForPalletLocationInput);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomGetDataForPalletLocationInput", customGetDataForPalletLocationInput),
                                            new KeyValuePair<String, Object>("CustomGetDataForPalletLocationOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            return output;
        }

        /// <summary>
        /// Service to retrieve the BOM Information
        /// </summary>
        /// <param name="CustomGetDataForBOMInformationInput">Input Object</param>
        /// <returns>Output Objects</returns>
        [HttpPost]
        public CustomGetDataForBOMInformationOutput CustomGetDataForBOMInformation(CustomGetDataForBOMInformationInput customGetDataForBOMInformationInput)
        {
            Utilities.StartMethod(objectTypeName, "CustomGetDataForBOMInformation",
                new KeyValuePair<String, Object>("CustomGetDataForBOMInformationInput", customGetDataForBOMInformationInput));

            CustomGetDataForBOMInformationOutput output = null;

            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomGetDataForBOMInformation(customGetDataForBOMInformationInput);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomGetDataForBOMInformationInput", customGetDataForBOMInformationInput),
                                            new KeyValuePair<String, Object>("CustomGetDataForBOMInformationOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            return output;
        }

        /// <summary>
        /// Service to retrieve a list of Running MOs
        /// </summary>
        /// <param name="customGetRunningMOsInput">Input Object</param>
        /// <returns>Output Objects</returns>
        [HttpPost]
        public CustomGetRunningMOsOutput CustomGetRunningMOs(CustomGetRunningMOsInput customGetRunningMOsInput)
        {
            Utilities.StartMethod(objectTypeName, "CustomGetRunningMOs",
                new KeyValuePair<String, Object>("CustomGetRunningMOsInput", customGetRunningMOsInput));

            CustomGetRunningMOsOutput output = null;

            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomGetRunningMOs(customGetRunningMOsInput);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomGetRunningMOsInput", customGetRunningMOsInput),
                                            new KeyValuePair<String, Object>("CustomGetRunningMOsOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            return output;
        }

        /// <summary>
        /// Service that will be call to start a material
        /// </summary>
        /// <param name="CustomStartMaterialInput">Input Object</param>
        /// <returns>Output Objects</returns>
        [HttpPost]
        public CustomStartMaterialOutput CustomStartMaterial(CustomStartMaterialInput customStartMaterialInput)
        {
            Utilities.StartMethod(objectTypeName, "CustomStartMaterial",
                new KeyValuePair<String, Object>("CustomStartMaterialInput", customStartMaterialInput));

            CustomStartMaterialOutput output = null;

            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomStartMaterial(customStartMaterialInput);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomStartMaterialInput", customStartMaterialInput),
                                            new KeyValuePair<String, Object>("CustomStartMaterialOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            return output;
        }

        /// <summary>
        /// Service that will log or notify equipment alarms
        /// </summary>
        /// <param name="CustomLogAlarmOccurrenceInput">Input Object</param>
        /// <returns>Output Objects</returns>
        [HttpPost]
        public CustomLogAlarmOccurrenceOutput CustomLogAlarmOccurrence(CustomLogAlarmOccurrenceInput customLogAlarmOccurrenceInput)
        {
            Utilities.StartMethod(objectTypeName, "CustomLogAlarmOccurrence",
                new KeyValuePair<String, Object>("CustomLogAlarmOccurrenceInput", customLogAlarmOccurrenceInput));

            CustomLogAlarmOccurrenceOutput output = null;

            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomLogAlarmOccurrence(customLogAlarmOccurrenceInput);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomLogAlarmOccurrenceInput", customLogAlarmOccurrenceInput),
                                            new KeyValuePair<String, Object>("CustomLogAlarmOccurrenceOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            return output;
        }

        /// <summary>
        /// Service to retrive data for UIPages Widgets
        /// </summary>
        /// <param name="input">Input Object</param>
        /// <returns>Output Objects</returns>
        [HttpPost]
        public CustomGetDataForEPMOutput CustomGetDataForEPM(CustomGetDataForEPMInput customGetDataForEPMInput)
        {
            Utilities.StartMethod(objectTypeName, "CustomGetDataForEPM",
                new KeyValuePair<string, object>("CustomGetDataForEPMInput", customGetDataForEPMInput));

            CustomGetDataForEPMOutput output = null;
            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomGetDataForEPM(customGetDataForEPMInput);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomGetDataForEPMInput", customGetDataForEPMInput),
                                            new KeyValuePair<String, Object>("CustomGetDataForEPMOutput", output));

            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;
        }

        /// <summary>
        /// Service to retrieve data for UIPage widgets (AreaDashboard)
        /// </summary>
        /// <param name="customGetDataForOEEInput"></param>
        /// <returns></returns>
        [HttpPost]
        [CmfIsReadOnlyService]
        public CustomGetDataForOEEOutput CustomGetDataForOEE(CustomGetDataForOEEInput customGetDataForOEEInput)
        {
            Utilities.StartMethod(objectTypeName, "CustomGetDataForOEE",
                new KeyValuePair<string, object>("CustomGetDataForOEEInput", customGetDataForOEEInput));

            CustomGetDataForOEEOutput output = null;
            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomGetDataForOEE(customGetDataForOEEInput);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomGetDataForOEEInput", customGetDataForOEEInput),
                                            new KeyValuePair<String, Object>("CustomGetDataForOEEOutput", output));

            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;
        }

        /// <summary>
        /// Custom service to retrieve Resources KPIs
        /// </summary>
        /// <param name="customGetDataForEPMWithShiftInput"></param>
        /// <returns></returns>
        [HttpPost]
        [CmfIsReadOnlyService]
        public CustomGetDataForEPMWithShiftOutput CustomGetDataForEPMWithShift(CustomGetDataForEPMWithShiftInput customGetDataForEPMWithShiftInput)
        {
            Utilities.StartMethod(objectTypeName, "CustomGetDataForEPMWithShift",
                new KeyValuePair<string, object>("CustomGetDataForEPMWithShiftInput", customGetDataForEPMWithShiftInput));

            CustomGetDataForEPMWithShiftOutput output = null;
            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomGetDataForEPMWithShift(customGetDataForEPMWithShiftInput);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomGetDataForEPMWithShiftInput", customGetDataForEPMWithShiftInput),
                                            new KeyValuePair<String, Object>("CustomGetDataForEPMWithShiftOutput", output));

            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;
        }

        /// <summary>
        /// Custom service to retrieve Resources KPIs state summary
        /// </summary>
        /// <param name="customGetDataForEPMSummaryWithShiftInput"></param>
        /// <returns></returns>
        [HttpPost]
        [CmfIsReadOnlyService]
        public CustomGetDataForEPMSummaryWithShiftOutput CustomGetDataForEPMSummaryWithShift(CustomGetDataForEPMSummaryWithShiftInput customGetDataForEPMSummaryWithShiftInput)
        {
            Utilities.StartMethod(objectTypeName, "CustomGetDataForEPMSummaryWithShift",
                new KeyValuePair<string, object>("CustomGetDataForEPMSummaryWithShiftInput", customGetDataForEPMSummaryWithShiftInput));

            CustomGetDataForEPMSummaryWithShiftOutput output = null;
            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomGetDataForEPMSummaryWithShift(customGetDataForEPMSummaryWithShiftInput);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomGetDataForEPMSummaryWithShiftInput", customGetDataForEPMSummaryWithShiftInput),
                                            new KeyValuePair<String, Object>("CustomGetDataForEPMSummaryWithShiftOutput", output));

            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;
        }

        /// <summary>
        /// Test Service to retrieve status from MES > ERP communication
        /// </summary>
        /// <param name="customERPCommunicationTestInput">Input Object</param>
        /// <returns>Output Objects</returns>
        [HttpPost]
        public CustomERPCommunicationTestOutput CustomERPCommunicationTest(CustomERPCommunicationTestInput customERPCommunicationTestInput)
        {
            Utilities.StartMethod(objectTypeName, "CustomERPCommunicationTest",
                new KeyValuePair<string, object>("CustomERPCommunicationTestInput", customERPCommunicationTestInput));

            CustomERPCommunicationTestOutput output = null;
            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomERPCommunicationTest(customERPCommunicationTestInput);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomERPCommunicationTestInput", customERPCommunicationTestInput),
                                            new KeyValuePair<String, Object>("CustomERPCommunicationTestOutput", output));

            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;
        }

        /// <summary>
        /// Check Material Setup State
        /// </summary>
        /// <param name="customGetMaterialSetupStateInput">Input Object</param>
        /// <returns>Output Objects</returns>
        [HttpPost]
        public CustomGetMaterialSetupStateOutput CustomGetMaterialSetupState(CustomGetMaterialSetupStateInput customGetMaterialSetupStateInput)
        {
            Utilities.StartMethod(objectTypeName, "CustomGetMaterialSetupState",
                new KeyValuePair<string, object>("CustomGetMaterialSetupStateInput", customGetMaterialSetupStateInput));

            CustomGetMaterialSetupStateOutput output = null;
            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomGetMaterialSetupState(customGetMaterialSetupStateInput);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomGetMaterialSetupStateInput", customGetMaterialSetupStateInput),
                                            new KeyValuePair<String, Object>("CustomGetMaterialSetupStateOutput", output));

            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;
        }

        /// <summary>
        ///  Update the BomProduct relation attributes
        /// </summary>
        /// <param name="CustomUpdateBomProductsAttributes">Input Object</param>
        /// <returns>Output Objects</returns>
        [HttpPost]
        public CustomUpdateBomProductsAttributesOutput CustomUpdateBomProductsAttributes(CustomUpdateBomProductsAttributesInput customUpdateBomProductsAttributesInput)
        {
            Utilities.StartMethod(objectTypeName, "CustomUpdateBomProductsAttributes",
                new KeyValuePair<string, object>("CustomUpdateBomProductsAttributesInput", customUpdateBomProductsAttributesInput));

            CustomUpdateBomProductsAttributesOutput output = null;
            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomUpdateBomProductsAttributes(customUpdateBomProductsAttributesInput);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomUpdateBomProductsAttributesInput", customUpdateBomProductsAttributesInput),
                                            new KeyValuePair<String, Object>("CustomUpdateBomProductsAttributesOutput", output));

            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;
        }

        /// <summary>
        /// Creates a Notification to request a Material Transfer
        /// </summary>
        /// <param name="customRequestMaterialTransferInput">Input Object</param>
        /// <returns></returns>
        [HttpPost]
        public CustomRequestMaterialTransferOutput CustomRequestMaterialTransfer(CustomRequestMaterialTransferInput customRequestMaterialTransferInput)
        {
            Utilities.StartMethod(objectTypeName, "CustomRequestMaterialTransfer",
                new KeyValuePair<string, object>("CustomRequestMaterialTransferInput", customRequestMaterialTransferInput));

            CustomRequestMaterialTransferOutput output = null;
            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomRequestMaterialTransfer(customRequestMaterialTransferInput);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomRequestMaterialTransferInput", customRequestMaterialTransferInput),
                                            new KeyValuePair<String, Object>("CustomRequestMaterialTransferOutput", output));

            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;
        }

        /// <summary>
        /// Transfer the material to the given resource.
        ///     If resource is of type storage, stores material.
        ///     If resource is of type consumable feed, attaches it to the consumable feed.
        /// </summary>
        /// <param name="CustomLogMaterialMovementInput">Input Object</param>
        /// <returns>Output Objects</returns>
        [HttpPost]
        public CustomLogMaterialMovementOutput CustomLogMaterialMovement(CustomLogMaterialMovementInput customLogMaterialMovementInput)
        {
            Utilities.StartMethod(objectTypeName, "CustomLogMaterialMovement",
                new KeyValuePair<string, object>("CustomLogMaterialMovementInput", customLogMaterialMovementInput));

            CustomLogMaterialMovementOutput output = null;
            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomLogMaterialMovement(customLogMaterialMovementInput);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomLogMaterialMovementInput", customLogMaterialMovementInput),
                                            new KeyValuePair<String, Object>("CustomLogMaterialMovementOutput", output));

            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;
        }

        /// <summary>
        /// Service to scan a barcode and return list of parsed extracted values
        /// </summary>
        /// <param name="CustomParseReadingInput">Input Object</param>
        /// <returns>Output Objects</returns>
        [HttpPost]
        public CustomParseReadingOutput CustomParseReading(CustomParseReadingInput customParseReadingInput)
        {
            Utilities.StartMethod(objectTypeName, "CustomParseReading",
                new KeyValuePair<string, object>("CustomParseReadingInput", customParseReadingInput));

            CustomParseReadingOutput output = null;
            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomParseReading(customParseReadingInput);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomParseReadingInput", customParseReadingInput),
                                            new KeyValuePair<String, Object>("CustomParseReadingOutput", output));

            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;
        }

        /// <summary>
        /// Get all available forklift resources dor check in
        /// </summary>
        /// <param name="customGetResourcesForCheckInInput">Input Object</param>
        /// <returns>Output Objects</returns>
        [HttpPost]
        public CustomGetResourcesForCheckInOutput CustomGetResourcesForCheckIn(CustomGetResourcesForCheckInInput customGetResourcesForCheckInInput)
        {
            Utilities.StartMethod(objectTypeName, "CustomGetResourcesForCheckIn",
                new KeyValuePair<string, object>("CustomGetResourcesForCheckInInput", customGetResourcesForCheckInInput));

            CustomGetResourcesForCheckInOutput output = null;
            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomGetResourcesForCheckIn(customGetResourcesForCheckInInput);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomGetResourcesForCheckInInput", customGetResourcesForCheckInInput),
                                            new KeyValuePair<String, Object>("CustomGetResourcesForCheckInOutput", output));

            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="customGetEmployeeTasksAndAreaNotificationsInput">Input Object</param>
        /// <returns>Output Objects</returns>
        [HttpPost]
        public CustomGetEmployeeTasksAndAreaNotificationsOutput CustomGetEmployeeTasksAndAreaNotifications(CustomGetEmployeeTasksAndAreaNotificationsInput customGetEmployeeTasksAndAreaNotificationsInput)
        {
            Utilities.StartMethod(objectTypeName, "CustomGetEmployeeTasksAndAreaNotifications",
                new KeyValuePair<string, object>("CustomGetEmployeeTasksAndAreaNotificationsInput", customGetEmployeeTasksAndAreaNotificationsInput));

            CustomGetEmployeeTasksAndAreaNotificationsOutput output = null;
            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomGetEmployeeTasksAndAreaNotifications(customGetEmployeeTasksAndAreaNotificationsInput);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomGetEmployeeTasksAndAreaNotificationsInput", customGetEmployeeTasksAndAreaNotificationsInput),
                                            new KeyValuePair<String, Object>("CustomGetEmployeeTasksAndAreaNotificationsOutput", output));

            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;
        }

        /// <summary>
        /// Service for Canceling or Complete all tasks in a collection
        /// </summary>
        /// <param name="customTaskCompleteAndCancelInput">Input Object</param>
        /// <returns>Output Objects</returns>
        [HttpPost]
        public CustomTaskCompleteAndCancelOutput CustomTaskCompleteAndCancel(CustomTaskCompleteAndCancelInput customTaskCompleteAndCancelInput)
        {
            Utilities.StartMethod(objectTypeName, "CustomTaskCompleteAndCancel",
                new KeyValuePair<string, object>("CustomTaskCompleteAndCancelInput", customTaskCompleteAndCancelInput));

            CustomTaskCompleteAndCancelOutput output = null;
            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomTaskCompleteAndCancel(customTaskCompleteAndCancelInput);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomTaskCompleteAndCancelInput", customTaskCompleteAndCancelInput),
                                            new KeyValuePair<String, Object>("CustomTaskCompleteAndCancelOutput", output));

            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;
        }

        /// <summary>
        /// Service for Canceling or Complete all tasks in a collection
        /// </summary>
        /// <param name="customSetMaterialStateInput">Input Object</param>
        /// <returns>Output Objects</returns>
        [HttpPost]
        public CustomSetMaterialStateOutput CustomSetMaterialState(CustomSetMaterialStateInput customSetMaterialStateInput)
        {
            Utilities.StartMethod(objectTypeName, "CustomSetMaterialState",
                new KeyValuePair<string, object>("CustomSetMaterialStateInput", customSetMaterialStateInput));

            CustomSetMaterialStateOutput output = null;
            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomSetMaterialState(customSetMaterialStateInput);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomSetMaterialStateInput", customSetMaterialStateInput),
                                            new KeyValuePair<String, Object>("CustomSetMaterialStateOutput", output));

            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;
        }

        /// <summary>
        /// Service for Label printing in Cutting area
        /// </summary>
        /// <param name="customPrintLabelCuttingInput">Input Object</param>
        /// <returns>Output Objects</returns>
        [HttpPost]
        public CustomPrintLabelCuttingOutput CustomPrintLabelCutting(CustomPrintLabelCuttingInput customPrintLabelCuttingInput)
        {
            Utilities.StartMethod(objectTypeName, "CustomPrintLabelCutting",
                new KeyValuePair<string, object>("CustomPrintLabelCuttingInput", customPrintLabelCuttingInput));

            CustomPrintLabelCuttingOutput output = null;
            try
            {


                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomPrintLabelCutting(customPrintLabelCuttingInput);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomPrintLabelCuttingInput", customPrintLabelCuttingInput),
                                            new KeyValuePair<String, Object>("CustomPrintLabelCuttingOutput", output));

            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;
        }

        /// <summary>
        /// Service for clearing Material interlock admission
        /// </summary>
        /// <param name="customClearMaterialAdmissionInterlockInput">Input Object</param>
        /// <returns></returns>
        [HttpPost]
        public CustomClearMaterialAdmissionInterlockOutput CustomClearMaterialAdmissionInterlock(CustomClearMaterialAdmissionInterlockInput customClearMaterialAdmissionInterlockInput)
        {
            Utilities.StartMethod(objectTypeName, "CustomClearMaterialAdmissionInterlock",
                new KeyValuePair<string, object>("CustomClearMaterialAdmissionInterlockInput", customClearMaterialAdmissionInterlockInput));

            CustomClearMaterialAdmissionInterlockOutput output = null;
            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomClearMaterialAdmissionInterlock(customClearMaterialAdmissionInterlockInput);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomClearMaterialAdmissionInterlockInput", customClearMaterialAdmissionInterlockInput),
                                            new KeyValuePair<String, Object>("CustomClearMaterialAdmissionInterlockOutput", output));

            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;
        }

        /// <summary>
        /// Service for updating interlock admission
        /// </summary>
        /// <param name="customUpdateInterlockStatusInput">Input Object</param>
        /// <returns>Output Objects</returns>
        [HttpPost]
        public CustomUpdateInterlockStatusOutput CustomUpdateInterlockStatus(CustomUpdateInterlockStatusInput customUpdateInterlockStatusInput)
        {
            Utilities.StartMethod(objectTypeName, "CustomUpdateInterlockStatus",
                new KeyValuePair<string, object>("CustomUpdateInterlockStatusInput", customUpdateInterlockStatusInput));

            CustomUpdateInterlockStatusOutput output = null;
            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomUpdateInterlockStatus(customUpdateInterlockStatusInput);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomUpdateInterlockStatusInput", customUpdateInterlockStatusInput),
                                            new KeyValuePair<String, Object>("CustomUpdateInterlockStatusOutput", output));

            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;
        }

        /// <summary>
        /// Service to retrieve a the resource state history
        /// </summary>
        /// <param name="customGetResourceStateHistoryInput">Input Object</param>
        /// <returns>Output Objects</returns>
        [HttpPost]
        public CustomGetResourceStateHistoryOutput CustomGetResourceStateHistory(CustomGetResourceStateHistoryInput customGetResourceStateHistoryInput)
        {
            Utilities.StartMethod(objectTypeName, "CustomGetResourceStateHistory",
                new KeyValuePair<string, object>("CustomGetResourceStateHistoryInput", customGetResourceStateHistoryInput));

            CustomGetResourceStateHistoryOutput output = null;
            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomGetResourceStateHistory(customGetResourceStateHistoryInput);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomGetResourceStateHistoryInput", customGetResourceStateHistoryInput),
                                            new KeyValuePair<String, Object>("CustomGetResourceStateHistoryOutput", output));

            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;
        }

        /// <summary>
        /// Service to save the resource state reclassifications
        /// </summary>
        /// <param name="input">Input Object</param>
        /// <returns>Output Objects</returns>
        [HttpPost]
        public CustomSaveResourceStateReclassificationOutput CustomSaveResourceStateReclassification(CustomSaveResourceStateReclassificationInput input)
        {
            Utilities.StartMethod(objectTypeName, "CustomSaveResourceStateReclassification",
                new KeyValuePair<string, object>("CustomSaveResourceStateReclassificationInput", input));

            CustomSaveResourceStateReclassificationOutput output = null;
            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomSaveResourceStateReclassification(input);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomSaveResourceStateReclassificationInput", input),
                                            new KeyValuePair<String, Object>("CustomSaveResourceStateReclassificationOutput", output));

            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;
        }

        /// <summary>
        /// Service to get the outsorted quantity of a Material attach to a resource from EI
        /// </summary>
        /// <param name="input">CustomGetOutsortedUnitsInformationInput</param>
        /// <returns>CustomGetOutsortedUnitsInformationOutput</returns>
        /// <exception cref="Cmf.Foundation.Common.CmfBaseException">If any unexpected error occurs.</exception>
        [HttpPost]
        public CustomGetOutsortedUnitsInformationOutput CustomGetOutsortedUnitsInformation(CustomGetOutsortedUnitsInformationInput input)
        {
            Utilities.StartMethod(objectTypeName, "CustomGetOutsortedUnitsInformation",
                new KeyValuePair<string, object>("CustomGetOutsortedUnitsInformationInput", input));

            CustomGetOutsortedUnitsInformationOutput output = null;
            try
            {
                output = _iKEABusinessManagementOrchestration.CustomGetOutsortedUnitsInformation(input);

                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomGetOutsortedUnitsInformationInput", input),
                                            new KeyValuePair<string, object>("CustomGetOutsortedUnitsInformationOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            return output;
        }

        /// <summary>
        /// Service used to post data to a chart.
        /// </summary>
        /// <param name="customPostDataToChartsInput">Input Object</param>
        /// <returns>Output Object</returns>
        [HttpPost]
        public CustomPostDataToChartsOutput CustomPostDataToCharts(CustomPostDataToChartsInput customPostDataToChartsInput)
        {
            Utilities.StartMethod(objectTypeName, "CustomPostDataToCharts", new KeyValuePair<string, object>("CustomPostDataToChartsInput", customPostDataToChartsInput));

            CustomPostDataToChartsOutput output;

            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomPostDataToCharts(customPostDataToChartsInput);

                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomPostDataToChartsInput", customPostDataToChartsInput),
                                            new KeyValuePair<string, object>("CustomPostDataToChartsOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new CmfBaseException(e.Message, e);
            }
            return output;
        }

        /// <summary>
        /// Custom Get Data For PPM
        /// </summary>
        /// <param name="input">Input Object</param>
        /// <returns>Output Objects</returns>
        [HttpPost]
        [CmfIsReadOnlyService]
        public CustomGetDataForPPMOutput CustomGetDataForPPM(CustomGetDataForPPMInput input)
        {
            Utilities.StartMethod(objectTypeName, "CustomGetDataForPPM",
                new KeyValuePair<string, object>("CustomGetDataForPPMInput", input));

            CustomGetDataForPPMOutput output = null;
            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomGetDataForPPM(input);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomGetDataForPPMInput", input),
                                            new KeyValuePair<String, Object>("CustomGetDataForPPMOutput", output));

            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;
        }

        /// <summary>
        /// Service to force the Unit Completion of a MO
        /// </summary>
        /// <param name="input">Input Object</param>
        /// <returns>Output Objects</returns>
        [HttpPost]
        public CustomForceUnitCompletionOutput CustomForceUnitCompletion(CustomForceUnitCompletionInput input)
        {
            Utilities.StartMethod(objectTypeName, "CustomForceUnitCompletion",
                new KeyValuePair<string, object>("CustomForceUnitCompletionInput", input));

            CustomForceUnitCompletionOutput output = null;
            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomForceUnitCompletion(input);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomForceUnitCompletionInput", input),
                                            new KeyValuePair<String, Object>("CustomForceUnitCompletionOutput", output));

            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;
        }

        /// <summary>
        /// Service used for retrieving a Resource's history of stop states.
        /// </summary>
        /// <param name="customGetResourceStopStateHistoryInput">Input Object</param>
        /// <returns>Output Object</returns>
        [HttpPost]
        public CustomGetResourceStopStateHistoryOutput CustomGetResourceStopStateHistory(CustomGetResourceStopStateHistoryInput customGetResourceStopStateHistoryInput)
        {
            Utilities.StartMethod(objectTypeName, "CustomGetResourceStopStateHistory", new KeyValuePair<string, object>("CustomGetResourceStopStateHistoryInput", customGetResourceStopStateHistoryInput));

            CustomGetResourceStopStateHistoryOutput output;

            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomGetResourceStopStateHistory(customGetResourceStopStateHistoryInput);

                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomGetResourceStopStateHistoryInput", customGetResourceStopStateHistoryInput),
                                            new KeyValuePair<string, object>("CustomGetResourceStopStateHistoryOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new CmfBaseException(e.Message, e);
            }
            return output;
        }

        /// <summary>
        /// Service to Palletize Materials From Outsorted Cockpit
        /// </summary>
        /// <param name="input">Input Object</param>
        /// <returns>Output Objects</returns>
        [HttpPost]
        public CustomOutsourtedPalletizeOutput CustomOutsourtedPalletize(CustomOutsourtedPalletizeInput input)
        {
            Utilities.StartMethod(objectTypeName, "CustomOutsourtedPalletize",
                new KeyValuePair<string, object>("CustomOutsourtedPalletizeInput", input));

            CustomOutsourtedPalletizeOutput output = null;
            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomOutsourtedPalletize(input);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomOutsourtedPalletizeInput", input),
                                            new KeyValuePair<String, Object>("CustomOutsourtedPalletizeOutput", output));

            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;
        }
        /// <summary>
        /// Service to get all the possible return steps for the outsorted cockpit
        /// </summary>
        /// <param name="input">Input Object</param>
        /// <returns>Output Objects</returns>
        [HttpPost]
        public CustomGetOutsortedMaterialAllPossibleReturnStepsOutput CustomGetOutsortedMaterialAllPossibleReturnSteps(CustomGetOutsortedMaterialAllPossibleReturnStepsInput input)
        {
            Utilities.StartMethod(objectTypeName, "CustomGetOutsortedMaterialAllPossibleReturnSteps",
                new KeyValuePair<string, object>("CustomGetOutsortedMaterialAllPossibleReturnStepsInput", input));

            CustomGetOutsortedMaterialAllPossibleReturnStepsOutput output = null;
            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomGetOutsortedMaterialAllPossibleReturnSteps(input);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomGetOutsortedMaterialAllPossibleReturnStepsInput", input),
                                            new KeyValuePair<String, Object>("CustomGetOutsortedMaterialAllPossibleReturnStepsOutput", output));

            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;
        }

        /// <summary>
        /// Service to retrieve variables from the Automation layer.
        /// </summary>
        /// <param name="input">Input Object</param>
        /// <returns>Output Object</returns>
        [HttpPost]
        public CustomGetAutomationVariablesOutput CustomGetAutomationVariables(CustomGetAutomationVariablesInput input)
        {
            Utilities.StartMethod(objectTypeName, "CustomGetAutomationVariables",
                new KeyValuePair<string, object>("CustomGetAutomationVariablesInput", input));

            CustomGetAutomationVariablesOutput output = null;
            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomGetAutomationVariables(input);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomGetAutomationVariablesInput", input),
                                            new KeyValuePair<String, Object>("CustomGetAutomationVariablesOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new CmfBaseException(e.Message, e);
            }

            return output;
        }

        /// <summary>
        /// Service to enable or disable the relations of a consumable feed with a consumption provider (Tank)
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        [HttpPost]
        public CustomHandleConsumptionProviderOutput CustomHandleConsumptionProvider(CustomHandleConsumptionProviderInput input)
        {
            Utilities.StartMethod(objectTypeName, "CustomHandleConsumptionProvider",
                new KeyValuePair<string, object>("CustomHandleConsumptionProviderInput", input));

            CustomHandleConsumptionProviderOutput output = null;
            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomHandleConsumptionProvider(input);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomHandleConsumptionProviderInput", input),
                                            new KeyValuePair<String, Object>("CustomHandleConsumptionProviderOutput", output));

            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;
        }

        /// <summary>
        /// Post Data from Automation to an MES Data Collection
        /// </summary>
        /// <param name="CustomAutomationDataCollectionToMES">Input Objects</param>
        /// <returns>Output Objects</returns>  
        [HttpPost]
        public CustomAutomationDataCollectionToMESOutput CustomAutomationDataCollectionToMES(CustomAutomationDataCollectionToMESInput customAutomationDataCollectionToMESInput)
        {
            CustomAutomationDataCollectionToMESOutput customAutomationDataCollectionToMESOutput;

            Utilities.StartMethod(objectTypeName, "CustomAutomationDataCollectionToMES",
                  new KeyValuePair<String, Object>("CustomAutomationDataCollectionToMESInput", customAutomationDataCollectionToMESInput));
            try
            {
                // Invoke orchestration
                customAutomationDataCollectionToMESOutput = _iKEABusinessManagementOrchestration.CustomAutomationDataCollectionToMES(customAutomationDataCollectionToMESInput);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomAutomationDataCollectionToMESInput", customAutomationDataCollectionToMESInput),
                                                new KeyValuePair<String, Object>("CustomAutomationDataCollectionToMESOutput", customAutomationDataCollectionToMESOutput));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return customAutomationDataCollectionToMESOutput;
        }

        /// <summary>
        /// Service to provide information about material from feeder resource
        /// </summary>
        /// <param name="customGetOutSortedPalletFromFeederInput"></param>
        /// <returns></returns>
        [HttpPost]
        public CustomGetOutSortedPalletFromFeederOutput CustomGetOutSortedPalletFromFeeder(CustomGetOutSortedPalletFromFeederInput customGetOutSortedPalletFromFeederInput)
        {
            CustomGetOutSortedPalletFromFeederOutput customGetOutSortedPalletFromFeederOutput;

            Utilities.StartMethod(objectTypeName, "CustomGetOutSortedPalletFromFeeder",
                  new KeyValuePair<String, Object>("CustomGetOutSortedPalletFromFeederInput", customGetOutSortedPalletFromFeederInput));
            try
            {
                // Invoke orchestration
                customGetOutSortedPalletFromFeederOutput = _iKEABusinessManagementOrchestration.CustomGetOutSortedPalletFromFeeder(customGetOutSortedPalletFromFeederInput);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomGetOutSortedPalletFromFeederInput", customGetOutSortedPalletFromFeederInput),
                                                new KeyValuePair<String, Object>("CustomGetOutSortedPalletFromFeederOutput", customGetOutSortedPalletFromFeederOutput));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return customGetOutSortedPalletFromFeederOutput;
        }

        /// <summary>
        /// Service to calculate how many outsorted pallets are needed and their quantities
        /// </summary>
        /// <param name="customCalculateNeededOutsortedPalletInput"></param>
        /// <returns></returns>
        [HttpPost]
        public CustomCalculateNeededOutsortedPalletOutput CustomCalculateNeededOutsortedPallet(CustomCalculateNeededOutsortedPalletInput customCalculateNeededOutsortedPalletInput)
        {
            CustomCalculateNeededOutsortedPalletOutput customCalculateNeededOutsortedPalletOutput;

            Utilities.StartMethod(objectTypeName, "CustomCalculateNeededOutsortedPallet",
                  new KeyValuePair<String, Object>("CustomCalculateNeededOutsortedPalletInput", customCalculateNeededOutsortedPalletInput));
            try
            {
                // Invoke orchestration
                customCalculateNeededOutsortedPalletOutput = _iKEABusinessManagementOrchestration.CustomCalculateNeededOutsortedPallet(customCalculateNeededOutsortedPalletInput);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomCalculateNeededOutsortedPalletInput", customCalculateNeededOutsortedPalletInput),
                                                new KeyValuePair<String, Object>("CustomCalculateNeededOutsortedPalletOutput", customCalculateNeededOutsortedPalletOutput));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return customCalculateNeededOutsortedPalletOutput;
        }

        /// <summary>
        /// Service to Complete an outsorted pallet generated in the line
        /// </summary>
        /// <param name="customCompleteOutsortedPalletInput"></param>
        /// <returns></returns>
        [HttpPost]
        public CustomCompleteOutsortedPalletOutput CustomCompleteOutsortedPallet(CustomCompleteOutsortedPalletInput customCompleteOutsortedPalletInput)
        {
            CustomCompleteOutsortedPalletOutput customCompleteOutsortedPalletOutput;

            Utilities.StartMethod(objectTypeName, "CustomCompleteOutsortedPallet",
                  new KeyValuePair<String, Object>("CustomCompleteOutsortedPalletInput", customCompleteOutsortedPalletInput));
            try
            {
                // Invoke orchestration
                customCompleteOutsortedPalletOutput = _iKEABusinessManagementOrchestration.CustomCompleteOutsortedPallet(customCompleteOutsortedPalletInput);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomCompleteOutsortedPalletInput", customCompleteOutsortedPalletInput),
                                                new KeyValuePair<String, Object>("CustomCompleteOutsortedPalletOutput", customCompleteOutsortedPalletOutput));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return customCompleteOutsortedPalletOutput;
        }

        /// <summary>
        /// Service to retrieve details when outsorting pallets on the line.
        /// </summary>
        /// <param name="input">CustomGetDetailsForPalletOutsortingInput</param>
        /// <returns>CustomGetDetailsForPalletOutsortingOutput</returns>
        [HttpPost]
        public CustomGetDetailsForPalletOutsortingOutput CustomGetDetailsForPalletOutsorting(CustomGetDetailsForPalletOutsortingInput input)
        {
            CustomGetDetailsForPalletOutsortingOutput output;

            Utilities.StartMethod(objectTypeName, "CustomGetDetailsForPalletOutsorting",
                  new KeyValuePair<string, object>("CustomGetDetailsForPalletOutsortingInput", input));

            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomGetDetailsForPalletOutsorting(input);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomGetDetailsForPalletOutsortingInput", input),
                                                new KeyValuePair<string, object>("CustomGetDetailsForPalletOutsortingOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new CmfBaseException(e.Message, e);
            }
            return output;
        }

        /// <summary>
        /// Service to get datapoints for chart from current shift
        /// </summary>
        /// <param name="input">CustomGetChartCurrentShiftLimitsIntput</param>
        /// <returns>CustomGetChartCurrentShiftLimitsOutput</returns>
        [HttpPost]
        public CustomGetChartCurrentShiftLimitsOutput CustomGetChartCurrentShiftLimits(CustomGetChartCurrentShiftLimitsInput input)
        {
            CustomGetChartCurrentShiftLimitsOutput output;

            Utilities.StartMethod(objectTypeName, "CustomGetChartCurrentShiftLimits",
                  new KeyValuePair<string, object>("CustomGetChartCurrentShiftLimitsInput", input));

            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomGetChartCurrentShiftLimits(input);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomGetChartCurrentShiftLimitsInput", input),
                                                new KeyValuePair<string, object>("CustomGetChartCurrentShiftLimitsOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new CmfBaseException(e.Message, e);
            }
            return output;
        }

        /// <summary>
        /// Service to Run an statistical normality test against selected datapoints from a logical chart
        /// </summary>
        /// <param name="input">CustomDataPointsNormalityTestInput</param>
        /// <returns>CustomDataPointsNormalityTestOutput</returns>
        [HttpPost]
        public CustomDataPointsNormalityTestOutput CustomDataPointsNormalityTest(CustomDataPointsNormalityTestInput input)
        {
            CustomDataPointsNormalityTestOutput output;

            Utilities.StartMethod(objectTypeName, "CustomDataPointsNormalityTest",
                  new KeyValuePair<string, object>("CustomDataPointsNormalityTestInput", input));

            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomDataPointsNormalityTest(input);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomDataPointsNormalityTestInput", input),
                                                new KeyValuePair<string, object>("CustomDataPointsNormalityTestOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new CmfBaseException(e.Message, e);
            }
            return output;
        }

        /// <summary>
        /// Service to Run an the creation or update of group MO
        /// </summary>
        /// <param name="input">CustomHandleGroupManufacturingOrdersInput</param>
        /// <returns>CustomHandleGroupManufacturingOrders</returns>
        [HttpPost]
        public CustomHandleGroupManufacturingOrdersOutput CustomHandleGroupManufacturingOrders(CustomHandleGroupManufacturingOrdersInput input)
        {
            CustomHandleGroupManufacturingOrdersOutput output;

            Utilities.StartMethod(objectTypeName, "CustomHandleGroupManufacturingOrders",
                  new KeyValuePair<string, object>("CustomHandleGroupManufacturingOrders", input));

            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomHandleGroupManufacturingOrders(input);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomHandleGroupManufacturingOrdersInput", input),
                                                new KeyValuePair<string, object>("CustomHandleGroupManufacturingOrdersOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new CmfBaseException(e.Message, e);
            }
            return output;
        }

        /// <summary>
        /// Service to list all materials stored in a printing queue
        /// </summary>
        /// <param name="input">CustomGetFromPrintingQueueInput</param>
        /// <returns>CustomGetFromPrintingQueueOutput</returns>
        [HttpPost]
        public CustomGetFromPrintingQueueOutput CustomGetFromPrintingQueue(CustomGetFromPrintingQueueInput input)
        {
            CustomGetFromPrintingQueueOutput output;

            Utilities.StartMethod(objectTypeName, "CustomGetFromPrintingQueue",
                  new KeyValuePair<string, object>("CustomGetFromPrintingQueue", input));

            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomGetFromPrintingQueue(input);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomGetFromPrintingQueueInput", input),
                                                new KeyValuePair<string, object>("CustomGetFromPrintingQueueOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new CmfBaseException(e.Message, e);
            }
            return output;
        }

        /// <summary>
        /// Service to add a material to the last position of the printing queue
        /// </summary>
        /// <param name="input">CustomAddToPrintingQueueInput</param>
        /// <returns>CustomAddToPrintingQueueOutput</returns>
        [HttpPost]
        public CustomAddToPrintingQueueOutput CustomAddToPrintingQueue(CustomAddToPrintingQueueInput input)
        {
            CustomAddToPrintingQueueOutput output;

            Utilities.StartMethod(objectTypeName, "CustomAddToPrintingQueue",
                  new KeyValuePair<string, object>("CustomAddToPrintingQueue", input));

            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomAddToPrintingQueue(input);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomAddToPrintingQueueInput", input),
                                                new KeyValuePair<string, object>("CustomAddToPrintingQueueOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new CmfBaseException(e.Message, e);
            }
            return output;
        }

        /// <summary>
        /// Service to remove the last material from a printing queue
        /// </summary>
        /// <param name="input">CustomRenoveFromPrintingQueueInput</param>
        /// <returns>CustomRemoveFromPrintingQueueOutput</returns>
        [HttpPost]
        public CustomRemoveFromPrintingQueueOutput CustomRemoveFromPrintingQueue(CustomRemoveFromPrintingQueueInput input)
        {
            CustomRemoveFromPrintingQueueOutput output;

            Utilities.StartMethod(objectTypeName, "CustomRemoveFromPrintingQueue",
                  new KeyValuePair<string, object>("CustomRemoveFromPrintingQueue", input));

            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomRemoveFromPrintingQueue(input);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomRemoveFromPrintingQueueInput", input),
                                                new KeyValuePair<string, object>("CustomRemoveFromPrintingQueueOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new CmfBaseException(e.Message, e);
            }
            return output;
        }

        /// <summary>
        /// Service to terminate a group MO
        /// </summary>
        /// <param name="input">CustomTerminateGroupManufacturingOrdersInput</param>
        /// <returns>CustomTerminateGroupManufacturingOrders</returns>
        [HttpPost]
        public CustomTerminateGroupManufacturingOrdersOutput CustomTerminateGroupManufacturingOrders(CustomTerminateGroupManufacturingOrdersInput input)
        {
            CustomTerminateGroupManufacturingOrdersOutput output;

            Utilities.StartMethod(objectTypeName, "CustomTerminateGroupManufacturingOrders",
                  new KeyValuePair<string, object>("CustomTerminateGroupManufacturingOrders", input));

            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomTerminateGroupManufacturingOrders(input);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomTerminateGroupManufacturingOrdersInput", input),
                                                new KeyValuePair<string, object>("CustomTerminateGroupManufacturingOrdersOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new CmfBaseException(e.Message, e);
            }
            return output;
        }

        /// <summary>
        /// Service to scan durable
        /// </summary>
        /// <param name="input"CustomAttachDurableInput</param>
        /// <returns>CustomAttachDurableOutput</returns>
        [HttpPost]
        public CustomAttachDurableOutput CustomAttachDurable(CustomAttachDurableInput input)
        {
            CustomAttachDurableOutput output;

            Utilities.StartMethod(objectTypeName, "CustomAttachDurable",
                  new KeyValuePair<string, object>("CustomAttachDurable", input));

            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomAttachDurable(input);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomAttachDurableInput", input),
                                                new KeyValuePair<string, object>("CustomAttachDurableOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new CmfBaseException(e.Message, e);
            }
            return output;
        }

        /// <summary>
        /// Service to Suspend or Unspuspend a material on the line
        /// </summary>
        /// <param name="input">CustomSuspendMaterialInput</param>
        /// <returns>CustomSuspendMaterialOutput</returns>
        [HttpPost]
        public CustomSuspendMaterialOutput CustomSuspendMaterial(CustomSuspendMaterialInput input)
        {
            CustomSuspendMaterialOutput output;

            Utilities.StartMethod(objectTypeName, "CustomSuspendMaterial",
                  new KeyValuePair<string, object>("CustomSuspendMaterialInput", input));

            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomSuspendMaterial(input);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomSuspendMaterialInput", input),
                                                new KeyValuePair<string, object>("CustomSuspendMaterialOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new CmfBaseException(e.Message, e);
            }
            return output;
        }

        /// <summary>
        /// Service to Suspend or Unspuspend a material on the line
        /// </summary>
        /// <param name="input">CustomPrintLabelUnitLoadingInput</param>
        /// <returns>CustomPrintLabelUnitLoadingOutput</returns>
        [HttpPost]
        public CustomPrintLabelUnitLoadingOutput CustomPrintLabelUnitLoading(CustomPrintLabelUnitLoadingInput input)
        {
            CustomPrintLabelUnitLoadingOutput output;

            Utilities.StartMethod(objectTypeName, "CustomPrintLabelUnitLoading",
                  new KeyValuePair<string, object>("CustomPrintLabelUnitLoadingInput", input));

            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomPrintLabelUnitLoading(input);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomPrintLabelUnitLoadingInput", input),
                                                new KeyValuePair<string, object>("CustomPrintLabelUnitLoadingOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new CmfBaseException(e.Message, e);
            }
            return output;
        }

        /// <summary>
        /// Service toget logical charts for a resource or a product
        /// </summary>
        /// <param name="input">CustomLoadResourceLogicalChartInput</param>
        /// <returns>CustomLoadResourceLogicalChart</returns>
        [HttpPost]
        public CustomLoadResourceLogicalChartOutput CustomLoadResourceLogicalChart(CustomLoadResourceLogicalChartInput input)
        {
            CustomLoadResourceLogicalChartOutput output;

            Utilities.StartMethod(objectTypeName, "CustomLoadResourceLogicalChart",
                  new KeyValuePair<string, object>("CustomLoadResourceLogicalChartInput", input));

            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomLoadResourceLogicalChart(input);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomLoadResourceLogicalChartInput", input),
                                                new KeyValuePair<string, object>("CustomLoadResourceLogicalChartOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new CmfBaseException(e.Message, e);
            }
            return output;
        }

        /// <summary>
        ///  Service to send all information to be printed in Logopak to IoT
        /// </summary>
        /// <param name="input">CustomPrintLogopakULLLabelInput</param>
        /// <returns>CustomPrintLogopakULLLabelOutput</returns>
        [HttpPost]
        public CustomPrintLogopakULLLabelOutput CustomPrintLogopakULLLabel(CustomPrintLogopakULLLabelInput input)
        {
            CustomPrintLogopakULLLabelOutput output;

            Utilities.StartMethod(objectTypeName, "CustomPrintLogopakULLLabel",
                  new KeyValuePair<string, object>("CustomPrintLogopakULLLabelInput", input));

            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomPrintLogopakULLLabel(input);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomPrintLogopakULLLabelInput", input),
                                                new KeyValuePair<string, object>("CustomPrintLogopakULLLabelOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new CmfBaseException(e.Message, e);
            }
            return output;
        }

        /// <summary>
        /// Custom service to receive messages from the WMS
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        [HttpPost]
        public CustomWMSOrderProgressOutput CustomWMSOrderProgress(CustomWMSOrderProgressInput input)
        {
            CustomWMSOrderProgressOutput output;

            Utilities.StartMethod(objectTypeName, "CustomWMSOrderProgress",
                  new KeyValuePair<string, object>("CustomWMSOrderProgressInput", input));

            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomWMSOrderProgress(input);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomWMSOrderProgressInput", input),
                                            new KeyValuePair<string, object>("CustomWMSOrderProgressOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new CmfBaseException(e.Message, e);
            }
            return output;
        }

        /// <summary>
        /// Custom service to receive WMSOrder Additional quantity
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        [HttpPost]
        public CustomWMSGetMaxAdditionalQuantityOutput CustomWMSGetMaxAdditionalQuantity(CustomWMSGetMaxAdditionalQuantityInput input)
        {
            CustomWMSGetMaxAdditionalQuantityOutput output;

            Utilities.StartMethod(objectTypeName, "CustomWMSGetMaxAdditionalQuantity",
                  new KeyValuePair<string, object>("CustomWMSGetMaxAdditionalQuantityInput", input));

            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomWMSGetMaxAdditionalQuantity(input);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomWMSGetMaxAdditionalQuantityInput", input),
                                            new KeyValuePair<string, object>("CustomWMSGetMaxAdditionalQuantityOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new CmfBaseException(e.Message, e);
            }
            return output;
        }
        /// <summary>
        /// Serice to be invoked by Factory Automation for making requests to the WMS
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        [HttpPost]
        public CustomWMSOrderRequestOutput CustomWMSOrderRequest(CustomWMSOrderRequestInput input)
        {
            CustomWMSOrderRequestOutput output;

            Utilities.StartMethod(objectTypeName, "CustomWMSOrderRequest",
                  new KeyValuePair<string, object>("CustomWMSOrderRequestInput", input));

            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomWMSOrderRequest(input);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomWMSOrderRequestInput", input),
                                            new KeyValuePair<string, object>("CustomWMSOrderRequestOutput", output));
            }
            catch (CmfBaseException excep)
            {
                // Get the original exception message
                string exceptionMessage = !String.IsNullOrEmpty(excep.OriginalMessage) ? excep.OriginalMessage : excep.Message;

                // Check if the length is higher than the 256 chars required by database
                if (!String.IsNullOrEmpty(exceptionMessage) && exceptionMessage.Length > 256)
                {
                    exceptionMessage = exceptionMessage.Substring(0, 256);
                }

                throw new CmfBaseException(exceptionMessage);
            }
            catch (Exception e)
            {
                throw new CmfBaseException(e.Message, e);
            }
            return output;
        }

        /// <summary>
        /// Service to send a Cancel Request to IoT
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        [HttpPost]
        public CustomWMSCancelOrdersRequestOutput CustomWMSCancelOrdersRequest(CustomWMSCancelOrdersRequestInput input)
        {
            CustomWMSCancelOrdersRequestOutput output;

            Utilities.StartMethod(objectTypeName, "CustomWMSCancelOrdersRequest",
                  new KeyValuePair<string, object>("CustomWMSCancelOrdersRequestInput", input));

            try
            {
                output = _iKEABusinessManagementOrchestration.CustomWMSCancelOrdersRequest(input);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomWMSCancelOrderRequestInput", input),
                                                new KeyValuePair<string, object>("CustomWMSCancelOrderRequestOutput", output));

            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new CmfBaseException(e.Message, e);
            }
            return output;
        }

        /// <summary>
        /// Custom service to send feed request to the WMS
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        [HttpPost]
        public CustomWMSManualOrderRequestOutput CustomWMSManualOrderRequest(CustomWMSManualOrderRequestInput input)
        {
            CustomWMSManualOrderRequestOutput output;

            Utilities.StartMethod(objectTypeName, "CustomWMSManualOrderRequest",
                  new KeyValuePair<string, object>("CustomWMSManualOrderRequestInput", input));

            try
            {
                // Invoke orchestration

                output = _iKEABusinessManagementOrchestration.CustomWMSManualOrderRequest(input);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomWMSManualOrderRequestInput", input),
                                            new KeyValuePair<string, object>("CustomWMSManualOrderRequestOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new CmfBaseException(e.Message, e);
            }
            return output;
        }

        /// <summary>
        /// Changes the default completion quantity of a order in process
        /// If automation is online, then the new default completion quantity should be greater than or equal to the
        /// quantity counted in pallet by IoT
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        [HttpPost]
        public CustomChangeDefaultCompletionQuantityOutput CustomChangeDefaultCompletionQuantity(CustomChangeDefaultCompletionQuantityInput input)
        {
            CustomChangeDefaultCompletionQuantityOutput output;

            Utilities.StartMethod(objectTypeName, "CustomChangeDefaultCompletionQuantity",
                  new KeyValuePair<string, object>("CustomChangeDefaultCompletionQuantityInput", input));

            try
            {
                // Invoke orchestration

                output = _iKEABusinessManagementOrchestration.CustomChangeDefaultCompletionQuantity(input);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomChangeDefaultCompletionQuantityInput", input),
                                            new KeyValuePair<string, object>("CustomChangeDefaultCompletionQuantityOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new CmfBaseException(e.Message, e);
            }
            return output;
        }

        /// <summary>
        /// Custom service to force the completion of a Manufacturing order on lines with Automation Mode Online.
        /// 
        /// ## Pre-requisites:
        ///  - material.Form == Order
        ///  - material.SystemState == INPROCESS
        ///  - material.Attributes[InCompletion] == true
        ///  - material.Attributes[ForceOrderCompletionAllowed] == "Complete"
        ///  - resource.AutomationMode == Online
        /// 
        /// ## Assumptions
        ///  - IoT Reply has valid Decimal "ProcessLoss" field
        /// 
        /// </summary>
        /// <param name="input">Input Object</param>
        /// <returns>Output Object</returns>
        [HttpPost]
        public CustomForceOrderCompletionOutput CustomForceOrderCompletion(CustomForceOrderCompletionInput input)
        {
            CustomForceOrderCompletionOutput output;

            Utilities.StartMethod(objectTypeName, "CustomForceOrderCompletion", new KeyValuePair<string, object>("CustomForceOrderCompletionInput", input));
            try
            {
                // Invoke orchestration

                output = _iKEABusinessManagementOrchestration.CustomForceOrderCompletion(input);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomForceOrderCompletionInput", input),
                                            new KeyValuePair<string, object>("CustomForceOrderCompletionOutput", output));

            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;

        }

        /// <summary>
        /// Creates a Move or PutAway request in FactoryAutomation (to then be sent to WMS) for a specific Material
        /// </summary>
        /// <param name="input">Input Object</param>
        /// <returns>Output Object</returns>
        [HttpPost]
        public CustomWMSManualMoveRequestOutput CustomWMSManualMoveRequest(CustomWMSManualMoveRequestInput input)
        {
            CustomWMSManualMoveRequestOutput output;

            Utilities.StartMethod(objectTypeName, "CustomWMSManualMoveRequest", new KeyValuePair<string, object>("CustomWMSManualMoveRequestInput", input));
            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomWMSManualMoveRequest(input);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomWMSManualMoveRequestInput", input),
                                            new KeyValuePair<string, object>("CustomWMSManualMoveRequestOutput", output));

            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;

        }

        /// <summary>
        /// Creates a new orderless production and material order
        /// </summary>
        /// <param name="input">CustomCreateOrderlessProductionInput</param>
        /// <returns>CustomCreateOrderlessProductionOutput</returns>
        [HttpPost]
        public CustomCreateOrderlessProductionOutput CustomCreateOrderlessProduction(CustomCreateOrderlessProductionInput input)
        {
            CustomCreateOrderlessProductionOutput output;
            Utilities.StartMethod(objectTypeName, "CustomCreateOrderlessProduction", new KeyValuePair<string, object>("CustomCreateOrderlessProductionInput", input));
            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomCreateOrderlessProduction(input);
                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomCreateOrderlessProductionInput", input),
                                            new KeyValuePair<string, object>("CustomCreateOrderlessProductionOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;
        }

        /// <summary>
        /// Service to update Orderless Production Orders (PO)
        /// Right now is only used to update Group Orders when they are sent to the HPO, and are returned
        /// with new orders that need a BOM to be selected by the operator.
        /// </summary>
        /// <param name="input">CustomUpdateOrderlessProductionInput</param>
        /// <returns>CustomUpdateOrderlessProductionOutput</returns>
        [HttpPost]
        public CustomUpdateOrderlessProductionOutput CustomUpdateOrderlessProduction(CustomUpdateOrderlessProductionInput input)
        {
            CustomUpdateOrderlessProductionOutput output;

            Utilities.StartMethod(objectTypeName, "CustomUpdateOrderlessProduction", new KeyValuePair<string, object>("CustomUpdateOrderlessProductionInput", input));

            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomUpdateOrderlessProduction(input);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomUpdateOrderlessProductionInput", input),
                                            new KeyValuePair<string, object>("CustomUpdateOrderlessProductionOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            return output;
        }

        /// <summary>
        /// retrieves all orderless (attribute on the bom) boms from the given resource and product
        /// </summary>
        /// <param name="input">Input Object</param>
        /// <returns>Output Object</returns>
        [HttpPost]
        public CustomResolveOrderlessBOMsOutput CustomResolveOrderlessBOMs(CustomResolveOrderlessBOMsInput input)
        {
            CustomResolveOrderlessBOMsOutput output;

            Utilities.StartMethod(objectTypeName, "CustomResolveOrderlessBOMs", new KeyValuePair<string, object>("CustomResolveOrderlessBOMsInput", input));
            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomResolveOrderlessBOMs(input);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomResolveOrderlessBOMsInput", input),
                                            new KeyValuePair<string, object>("CustomResolveOrderlessBOMsOutput", output));

            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;

        }

        /// <summary>
        /// Receive messages from NiceLabel
        /// </summary>
        /// <param name="input">Input Object</param>
        /// <returns>Output Object</returns>
        [HttpPost]
        public CustomNiceLabelMessageOutput CustomNiceLabelMessage(CustomNiceLabelMessageInput input)
        {
            CustomNiceLabelMessageOutput output;

            Utilities.StartMethod(objectTypeName, "CustomNiceLabelMessage", new KeyValuePair<string, object>("CustomNiceLabelMessageInput", input));
            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomNiceLabelMessage(input);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomNiceLabelMessageInput", input),
                                            new KeyValuePair<string, object>("CustomNiceLabelMessageOutput", output));

            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;

        }

        /// <summary>
        /// Resolve alternative cycle times based on the existing columns of ideal cycle times
        /// </summary>
        /// <param name="input">Input Object</param>
        /// <returns>Output Object</returns>
        [HttpPost]
        public CustomResolveAlternativeCyclesTimesOutput CustomResolveAlternativeCyclesTimes(CustomResolveAlternativeCyclesTimesInput input)
        {
            CustomResolveAlternativeCyclesTimesOutput output;

            Utilities.StartMethod(objectTypeName, "CustomResolveAlternativeCyclesTimes", new KeyValuePair<string, object>("CustomResolveAlternativeCyclesTimesInput", input));
            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomResolveAlternativeCyclesTimes(input);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomResolveAlternativeCyclesTimesInput", input),
                                            new KeyValuePair<string, object>("CustomResolveAlternativeCyclesTimesOutput", output));

            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;

        }

        /// <summary>
        /// Service to reload the pending trackout queues on IoT after some partial trackout fails
        /// </summary>
        /// <param name="input">Input Object</param>
        /// <returns>Output Object</returns>
        [HttpPost]
        public CustomReloadPendingTrackOutsOutput CustomReloadPendingTrackOuts(CustomReloadPendingTrackOutsInput input)
        {
            CustomReloadPendingTrackOutsOutput output;

            Utilities.StartMethod(objectTypeName, "CustomReloadPendingTrackOuts", new KeyValuePair<string, object>("CustomReloadPendingTrackOutsInput", input));
            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomReloadPendingTrackOuts(input);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomReloadPendingTrackOutsInput", input),
                                            new KeyValuePair<string, object>("CustomReloadPendingTrackOutsOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;
        }

        /// <summary>
        /// Retrieve recipe parameters with the overwritten values
        /// </summary>
        /// <param name="input">Input Object</param>
        /// <returns>Output Object</returns>
        [HttpPost]
        public CustomRecipeOverwrittenValuesOutput CustomRecipeOverwrittenValues(CustomRecipeOverwrittenValuesInput input)
        {
            CustomRecipeOverwrittenValuesOutput output;

            Utilities.StartMethod(objectTypeName, "CustomRecipeOverwrittenValues", new KeyValuePair<string, object>("CustomRecipeOverwrittenValuesInput", input));
            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomRecipeOverwrittenValues(input);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomRecipeOverwrittenValuesInput", input),
                                            new KeyValuePair<string, object>("CustomRecipeOverwrittenValuesOutput", output));

            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;

        }

        /// <summary>
        /// Relation between Resource (that exists in the OriginalResources) and the list of alternative resources 
        /// (based on the GT CustomAlternativeSubResources)
        /// </summary>
        /// <param name="input">Input Object</param>
        /// <returns>Output Object</returns>
        [HttpPost]
        public CustomResolveAlternativeSubResourcesOutput CustomResolveAlternativeSubResources(CustomResolveAlternativeSubResourcesInput input)
        {
            CustomResolveAlternativeSubResourcesOutput output;

            Utilities.StartMethod(objectTypeName, "CustomResolveAlternativeSubResources", new KeyValuePair<string, object>("CustomResolveAlternativeSubResourcesInput", input));
            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomResolveAlternativeSubResources(input);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomResolveAlternativeSubResourcesInput", input),
                                            new KeyValuePair<string, object>("CustomResolveAlternativeSubResourcesOutput", output));

            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;

        }
        /// <summary>
        /// Retrive total quantity of product name per production order
        /// </summary>
        /// <param name="input">Input MaterialCollection</param>
        /// <returns>Output Object</returns>
        [HttpPost]
        public CustomResolveWMSQuantityOutput CustomResolveWMSQuantity(CustomResolveWMSQuantityInput input)
        {
            CustomResolveWMSQuantityOutput output;

            Utilities.StartMethod(objectTypeName, "CustomResolveWMSQuantity", new KeyValuePair<string, object>("CustomResolveWMSQuantityInput", input));
            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomResolveWMSQuantity(input);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomResolveWMSQuantityInput", input),
                                            new KeyValuePair<string, object>("CustomResolveWMSQuantityOutput", output));

            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;

        }

        /// <summary>
        /// This service creates an integration entry to request an order to the ERP
        /// </summary>
        /// <param name="input">Input Object</param>
        /// <returns>Output Object</returns>
        [HttpPost]
        public CustomERPRequestOrderOutput CustomERPRequestOrder(CustomERPRequestOrderInput input)
        {
            CustomERPRequestOrderOutput output;

            Utilities.StartMethod(objectTypeName, "CustomERPRequestOrder", new KeyValuePair<string, object>("CustomERPRequestOrderInput", input));
            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomERPRequestOrder(input);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomERPRequestOrderInput", input),
                                            new KeyValuePair<string, object>("CustomERPRequestOrderOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="input">Input Object</param>
        /// <returns>Output Object</returns>
        [HttpPost]
        public CustomWMSListGroupedMaterialTrackersOutput CustomWMSListGroupedMaterialTrackers(CustomWMSListGroupedMaterialTrackersInput input)
        {
            CustomWMSListGroupedMaterialTrackersOutput output;

            Utilities.StartMethod(objectTypeName, "CustomWMSListGroupedMaterialTrackers",
                new KeyValuePair<string, object>("CustomWMSListGroupedMaterialTrackersInput", input));
            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomWMSListGroupedMaterialTrackers(input);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomWMSListGroupedMaterialTrackersInput", input),
                                            new KeyValuePair<string, object>("CustomWMSListGroupedMaterialTrackersOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;

        }

        /// <summary>
        /// Calculates the SPC chart contexts that shall be automatically filled considering the provided inputs.
        /// </summary>
        /// <param name="input">The inputs to consider when calculating the context, namely: chart name, current resource and current material.</param>
        /// <returns>The SPC chart contexts that calculated according to <see cref="IKEAConstants.CustomChartContextTranslator"/> table.</returns>
        /// <exception cref="CmfBaseException">If an error occurs during the calculation.</exception>
        [HttpPost]
        public CustomGetChartContextFromChartContextTranslatorOutput CustomGetChartContextFromChartContextTranslator(CustomGetChartContextFromChartContextTranslatorInput input)
        {

            Utilities.StartMethod(objectTypeName, nameof(CustomGetChartContextFromChartContextTranslator), new KeyValuePair<String, Object>(nameof(CustomGetChartContextFromChartContextTranslatorInput), input));

            CustomGetChartContextFromChartContextTranslatorOutput output = null;
            try
            {
                output = _iKEABusinessManagementOrchestration.CustomGetChartContextFromChartContextTranslator(input);

                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>(nameof(CustomGetChartContextFromChartContextTranslator), input), new KeyValuePair<String, Object>(nameof(CustomGetChartContextFromChartContextTranslator), output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            return output;
        }


        /// <summary>
        /// Service called by IoT to Resolve Resource's OEE State when alarm required and if alarm action set on table CustomAlarmHandlingActions
        /// </summary>
        /// <param name="input">Input Object</param>
        /// <returns>Output Object</returns>
        [HttpPost]
        public CustomModelStateChangeWithActiveAlarmOutput CustomModelStateChangeWithActiveAlarm(CustomModelStateChangeWithActiveAlarmInput input)
        {
            CustomModelStateChangeWithActiveAlarmOutput output;

            Utilities.StartMethod(objectTypeName, "CustomModelStateChangeWithActiveAlarm",
                new KeyValuePair<string, object>("CustomModelStateChangeWithActiveAlarmInput", input));
            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomModelStateChangeWithActiveAlarm(input);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomModelStateChangeWithActiveAlarmInput", input),
                                            new KeyValuePair<string, object>("CustomModelStateChangeWithActiveAlarmOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="input">Input Object</param>
        /// <returns>Output Object</returns>
        [HttpPost]
        public MaterialLabelStorageOutput MaterialLabelStorage(MaterialLabelStorageInput input)
        {
            MaterialLabelStorageOutput output;

            Utilities.StartMethod(objectTypeName, "MaterialLabelStorage",
                new KeyValuePair<string, object>("MaterialLabelStorageInput", input));
            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.MaterialLabelStorage(input);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("MaterialLabelStorageInput", input),
                                            new KeyValuePair<string, object>("MaterialLabelStorageOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;

        }

        /// <summary>
        /// Service to generate an error notification to be displayed to the operator.
        /// </summary>
        /// <param name="input">Input Object - contains the topmost resource and the message to be displayed in the error notification</param>
        /// <returns>Output Object</returns>
        [HttpPost]
        public CustomGenerateErrorNotificationOutput CustomGenerateErrorNotification(CustomGenerateErrorNotificationInput input)
        {
            CustomGenerateErrorNotificationOutput output;

            Utilities.StartMethod(objectTypeName, "CustomGenerateErrorNotification",
                new KeyValuePair<string, object>("CustomGenerateErrorNotificationInput", input));
            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomGenerateErrorNotification(input);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomGenerateErrorNotificationInput", input),
                                            new KeyValuePair<string, object>("CustomGenerateErrorNotificationOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            return output;
        }

        /// <summary>
        /// Service to validate if counter part (in first line) of order in the second line has been completed or aborted
        /// </summary>
        /// <param name="input">Input Object</param>
        /// <returns>Output Object</returns>
        [HttpPost]
        public CustomDirectFeedingCounterPartValidationOutput CustomDirectFeedingCounterPartValidation(CustomDirectFeedingCounterPartValidationInput input)
        {
            CustomDirectFeedingCounterPartValidationOutput output;

            Utilities.StartMethod(objectTypeName, "CustomDirectFeedingCounterPartValidation",
                new KeyValuePair<string, object>("CustomDirectFeedingCounterPartValidationInput", input));
            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomDirectFeedingCounterPartValidation(input);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomDirectFeedingCounterPartValidationInput", input),
                                            new KeyValuePair<string, object>("CustomDirectFeedingCounterPartValidationOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;

        }

        /// <summary>
        /// Service to request IoT to create a virtual pallet. Request will be sent to resource counterpart in direct feeding.
        /// </summary>
        /// <param name="input">Input Object</param>
        /// <returns>Output Object</returns>
        [HttpPost]
        public CustomCreateVirtualPalletOutput CustomCreateVirtualPallet(CustomCreateVirtualPalletInput input)
        {
            CustomCreateVirtualPalletOutput output;

            Utilities.StartMethod(objectTypeName, "CustomCreateVirtualPallet",
                new KeyValuePair<string, object>("CustomCreateVirtualPalletInput", input));
            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomCreateVirtualPallet(input);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomCreateVirtualPalletInput", input),
                                            new KeyValuePair<string, object>("CustomCreateVirtualPalletOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;

        }

        /// <summary>
        /// Service that checks if MO in SecondLine is InProcess
        /// </summary>
        /// <param name="input">Input Object</param>
        /// <returns>Output Object</returns>
        [HttpPost]
        public CustomIsMOInSecondLineInProcessOutput CustomIsMOInSecondLineInProcess(CustomIsMOInSecondLineInProcessInput input)
        {
            CustomIsMOInSecondLineInProcessOutput output;

            Utilities.StartMethod(objectTypeName, "CustomIsMOInSecondLineInProcess",
                new KeyValuePair<string, object>("CustomIsMOInSecondLineInProcessInput", input));
            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomIsMOInSecondLineInProcess(input);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomIsMOInSecondLineInProcessInput", input),
                                            new KeyValuePair<string, object>("CustomIsMOInSecondLineInProcessOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;

        }

        /// <summary>
        /// Service is called by second line to clear interlock on the first line.
        /// </summary>
        /// <param name="input">Input Object</param>
        /// <returns>Output Object</returns>
        [HttpPost]
        public CustomRequestClearInterlockOnFirstLineOutput CustomRequestClearInterlockOnFirstLine(CustomRequestClearInterlockOnFirstLineInput input)
        {
            CustomRequestClearInterlockOnFirstLineOutput output;

            Utilities.StartMethod(objectTypeName, "CustomRequestClearInterlockOnFirstLine",
                new KeyValuePair<string, object>("CustomRequestClearInterlockOnFirstLineInput", input));
            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomRequestClearInterlockOnFirstLine(input);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomRequestClearInterlockOnFirstLineInput", input),
                                            new KeyValuePair<string, object>("CustomRequestClearInterlockOnFirstLineOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;

        }

        /// <summary>
        /// Custom service to force the abortion of a Manufacturing order on lines with Automation Mode Online.
        /// 
        /// ## Pre-requisites:
        ///  - material.Form == Order
        ///  - material.Attributes[InCompletion] == true
        ///  - material.Attributes[ForceOrderCompletionAllowed] == "Empty&Abort"
        ///  - resource.AutomationMode == Online
        /// 
        /// ## Assumptions
        ///  - IoT Reply has valid Decimal "ProcessLoss" field
        /// 
        /// </summary>
        /// <param name="input">Input Object</param>
        /// <returns>Output Object</returns>
        [HttpPost]
        public CustomForceOrderAbortOutput CustomForceOrderAbort(CustomForceOrderAbortInput input)
        {
            CustomForceOrderAbortOutput output;

            Utilities.StartMethod(objectTypeName, "CustomForceOrderAbort", new KeyValuePair<string, object>("CustomForceOrderAbortInput", input));
            try
            {
                // Invoke orchestration

                output = _iKEABusinessManagementOrchestration.CustomForceOrderAbort(input);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomForceOrderAbortInput", input),
                                            new KeyValuePair<string, object>("CustomForceOrderAbortOutput", output));

            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;
        }

        /// <summary>
        /// Service to validate complete button conditions
        /// </summary>
        /// <param name="input">Input Object - contains the topmost resource and the material selected when the button Complete is clicked</param>
        /// <returns>Output Object</returns>
        [HttpPost]
        public CustomValidateCompleteConditionsOutput CustomValidateCompleteConditions(CustomValidateCompleteConditionsInput input)
        {
            CustomValidateCompleteConditionsOutput output;

            Utilities.StartMethod(objectTypeName, "CustomValidateCompleteConditions",
                new KeyValuePair<string, object>("CustomValidateCompleteConditionsInput", input));
            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomValidateCompleteConditions(input);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomValidateCompleteConditionsInput", input),
                                            new KeyValuePair<string, object>("CustomValidateCompleteConditionsOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            return output;
        }

        /// <summary>
        /// Service that returns MOs not in any groupMO based on input filter
        /// </summary>
        [HttpPost]
        public CustomGetParentlessMOListByFilterOutput CustomGetParentlessMOListByFilter(CustomGetParentlessMOListByFilterInput input)
        {
            CustomGetParentlessMOListByFilterOutput output;

            Utilities.StartMethod(objectTypeName, "CustomGetParentlessMOListByFilter",
                new KeyValuePair<string, object>("CustomGetParentlessMOListByFilterInput", input));
            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomGetParentlessMOListByFilter(input);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomGetParentlessMOListByFilterInput", input),
                                            new KeyValuePair<string, object>("CustomGetParentlessMOListByFilterOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;

        }

        /// <summary>
        /// Service that MAke IOT Request for reset pallet ID
        /// </summary>
        [HttpPost]
        public CustomGetDispatchListForResourceOutput CustomGetDispatchListForResource(CustomGetDispatchListForResourceInput input)
        {
            CustomGetDispatchListForResourceOutput output;

            Utilities.StartMethod(objectTypeName, "CustomGetDispatchListForResource",
                new KeyValuePair<string, object>("CustomGetDispatchListForResourceInput", input));
            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomGetDispatchListForResource(input);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomGetDispatchListForResourceInput", input),
                                            new KeyValuePair<string, object>("CustomGetDispatchListForResourceOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;

        }
        /// <summary>
        /// Service that MAke IOT Request for reset pallet ID
        /// </summary>
        [HttpPost]
        public CustomResetPalletIDQueueOutput CustomResetPalletIDQueue(CustomResetPalletIDQueueInput input)
        {
            CustomResetPalletIDQueueOutput output;

            Utilities.StartMethod(objectTypeName, "CustomResetPalletIDQueue",
                new KeyValuePair<string, object>("CustomResetPalletIDQueueInput", input));
            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomResetPalletIDQueue(input);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomResetPalletIDQueueInput", input),
                                            new KeyValuePair<string, object>("CustomResetPalletIDQueueOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;

        }
        /// <summary>
        /// Service to Detach materials
        /// </summary>
        [HttpPost]
        public CustomDetachMaterialsOutput CustomDetachMaterials(CustomDetachMaterialsInput input)
        {
            CustomDetachMaterialsOutput output;

            Utilities.StartMethod(objectTypeName, "CustomDetachMaterials",
                new KeyValuePair<string, object>("CustomDetachMaterialsInput", input));
            try
            {
                // Invoke orchestration
                output = _iKEABusinessManagementOrchestration.CustomDetachMaterials(input);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomDetachMaterialsInput", input),
                                            new KeyValuePair<string, object>("CustomDetachMaterialsOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;

        }
    }
}