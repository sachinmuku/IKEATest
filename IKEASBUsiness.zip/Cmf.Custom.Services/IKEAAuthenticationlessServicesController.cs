﻿using Cmf.Custom.IKEA.Orchestration.InputObjects;
using Cmf.Foundation.Common;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using Cmf.Custom.IKEA.Orchestration.Abstractions;

namespace Cmf.Custom.IKEA.Services
{
    /// <summary>
    /// This class contains all web API service implementations for IKEA Customization Implementation that do not require authentication
    /// </summary>
	[ApiController]
    [Route("api/[controller]/[action]")]
    public class IKEAAuthenticationlessServicesController : ControllerBase
    {
        private readonly IIKEABusinessManagementOrchestration _iKEABusinessManagementOrchestration;
        private static String objectTypeName = "Cmf.Custom.IKEA.Services.IKEAAuthenticationlessServices";

        /// <summary>
        /// Initializes a new instance of the <see cref="IKEAAuthenticationlessServicesController"/> class.
        /// </summary>
        [Microsoft.Extensions.DependencyInjection.ActivatorUtilitiesConstructor]
        public IKEAAuthenticationlessServicesController(IIKEABusinessManagementOrchestration iKEABusinessManagementOrchestration) : base()
        {
            this._iKEABusinessManagementOrchestration = iKEABusinessManagementOrchestration;
        }

        /// <summary>
        /// Receives an Base64 URL encoded message from the ION and creates a new integration entry
        /// </summary>
        /// <param name="">input</param>
        /// <returns>true if successful entry was recorded, false otherwise</returns>
        [HttpPost]
        public bool IKEAAcknowledgeIonMessageBase64URL(IKEAAcknowledgeIonMessageBase64URLInput input)
        {
            bool returnResult = false; ;

            Utilities.StartMethod(objectTypeName, "IKEAAcknowledgeIonMessageBase64URL",
                  new KeyValuePair<String, Object>("IKEAAcknowledgeIonMessageBase64URLInput", input));
            try
            {
                // Invoke orchestration
                _iKEABusinessManagementOrchestration.IKEAAcknowledgeIonMessage(new IKEAAcknowledgeIonMessageInput() { IonMessage = input.IonMessage, IsBase64URL = true });
                returnResult = true;

                // Close service
                Utilities.EndMethod(-1, -1);
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            return returnResult;
        }

    }
}