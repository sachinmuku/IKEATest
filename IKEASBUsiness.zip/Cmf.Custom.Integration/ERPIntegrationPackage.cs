﻿using Cmf.Foundation.Common.Abstractions.IoC;
using Cmf.Foundation.Common.Integration;
using Cmf.Foundation.Common.IoC;
using Cmf.Foundation.Common.Logging;
using Cmf.Foundation.Integration.Abstractions;
using Cmf.Foundation.Integration.Generic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Integration
{
    public class ERPIntegrationPackage : GenericIntegrationPackage
    {
        private readonly ILoggingService _loggingService;
        private readonly IFactory<GenericIntegrationReceiver> _genericIntegrationReceiverFactory;
        private readonly IFactory<GenericIntegrationHandler> _genericIntegrationHandlerFactory;
        private readonly IFactory<GenericIntegrationSender> _genericIntegrationSenderFactory;
        //private IIntegrationConfigurationParser<IIntegrationConfiguration> _configurationParser;

        public ERPIntegrationPackage(ILoggingService loggingService, IFactory<GenericIntegrationReceiver> genericIntegrationReceiverFactory,
            IFactory<GenericIntegrationHandler> genericIntegrationHandlerFactory,
            IFactory<GenericIntegrationSender> genericIntegrationSenderFactory) 
            : base(loggingService, genericIntegrationReceiverFactory, genericIntegrationHandlerFactory, genericIntegrationSenderFactory)
        {
            _loggingService = loggingService;
            _genericIntegrationReceiverFactory = genericIntegrationReceiverFactory;
            _genericIntegrationHandlerFactory = genericIntegrationHandlerFactory;
            _genericIntegrationSenderFactory = genericIntegrationSenderFactory;
            _loggingService.LogCategory = "ERPIntegration";
        }


        #region Define the components life-cycle

        /// <summary>
        /// Gets the sender activation mode.
        /// </summary>
        /// <value>
        /// The sender activation mode.
        /// </value>
        public override ActivationMode SenderActivationMode
        {
            get
            {
                return ActivationMode.PerCall;
            }
        }

        /// <summary>
        /// Gets the handler activation mode.
        /// </summary>
        /// <value>
        /// The handler activation mode.
        /// </value>
        public override ActivationMode HandlerActivationMode
        {
            get
            {
                return ActivationMode.PerCall;
            }
        }

        #endregion

        #region define the components activation functions

        /// <summary>
        /// Gets the sender factory.
        /// </summary>
        /// <value>
        /// The sender factory.
        /// </value>
        protected override Func<IEdiHandler, ISender> SenderFactory
        {
            get
            {
                return CreateSender;
            }
        }

        /// <summary>
        /// Gets the handler factory.
        /// </summary>
        /// <value>
        /// The handler factory.
        /// </value>
        protected override Func<IEdiHandler> HandlerFactory
        {
            get
            {
                return CreateHandler;
            }
        }

        #endregion

        #region factory methods

        private ISender CreateSender(IEdiHandler processor)
        {
            var sender = new ERPIntegrationSender(_loggingService);
            sender.SenderPort = processor;

            return sender;
        }

        private IEdiHandler CreateHandler()
        {
            return new ERPIntegrationHandler(_loggingService);
        }

       
        #endregion
    }
}
