﻿using Cmf.Foundation.Common.Integration;
using Cmf.Foundation.Common.Logging;
using Cmf.Foundation.Integration.Abstractions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Integration
{
    public class ERPIntegrationSender : ISender
    {
        #region Private variables

        private ILoggingService _loggingService;

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the root handler where to send request.
        /// </summary>
        /// <value>
        /// The root handler.
        /// </value>
        public IEdiHandler SenderPort
        {
            get;
            set;
        }

        /// <summary>
        /// Gets a value indicating whether this instance is running.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is running; otherwise, <c>false</c>.
        /// </value>
        public bool IsConnected
        {
            get
            {
                // the current implementation uses a stateless connection. Just return true.
                return true;
            }
        }

        #endregion

        #region Constructor

        /// <summary>
        /// Default Constructor
        /// </summary>
        public ERPIntegrationSender(ILoggingService loggingService)
        {
            _loggingService = loggingService;
        }

        #endregion

        #region Public methods

        /// <summary>
        /// Open the connection to the system.
        /// </summary>
        public void Connect()
        {
            // the current implementation uses a stateless connection
            // nothing to do here
        }

        /// <summary>
        /// Reopen the connection to the system.
        /// </summary>
        /// <remarks>
        /// This is called when the connection is lost to recover it.
        /// </remarks>
        public void Reconnect()
        {
            // the current implementation uses a stateless connection
            // nothing to do here
        }

        #endregion
    }
}
