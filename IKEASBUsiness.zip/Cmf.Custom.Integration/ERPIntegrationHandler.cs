﻿using Cmf.Custom.IKEA.Common;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Logging;
using System;
using System.Collections.Generic;
using System.Text;
using DeeAction = Cmf.Foundation.Common.DynamicExecutionEngine.Action;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Integration.Abstractions;

namespace Cmf.Custom.IKEA.Integration
{
    /// <summary>
    /// ERP Integration handler
    /// </summary>
    public class ERPIntegrationHandler : IEdiHandler, IAcceptsHandlingContext
    {
        private readonly ILoggingService _loggingService;

        public bool IsCritical
        {
            get
            {
                return true;
            }
        }

        public string UniqueName
        {
            get
            {
                return typeof(ERPIntegrationHandler).Name;
            }
            set { }
        }

        public ERPIntegrationHandler(ILoggingService loggingService)
        {
            _loggingService = loggingService;
        }

        public IIntegrationEntry Handle(IIntegrationEntry entry)
        {
            return Handle(entry, null);
        }

        public IIntegrationEntry Handle(IIntegrationEntry entry, IHandlingContext handlingContext)
        {
            var direction = GetEventDirection(entry);
            if (direction == EdiDirection.Inbound)
            {
                return HandleInbound((IIntegrationEntry)entry, handlingContext);
            }
            else if (direction == EdiDirection.Outbound)
            {
                return HandleOutbound((IIntegrationEntry)entry, handlingContext);
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// Gets the event direction.
        /// </summary>
        /// <param name="ediEvent">The edi event.</param>
        /// <returns>
        /// The event direction.
        /// </returns>
        public EdiDirection GetEventDirection(IIntegrationEntry ediEvent)
        {
            if (IKEAConstants.ERPSystem.Equals(ediEvent.SourceSystem)
                && IKEAConstants.MESSystem.Equals(ediEvent.TargetSystem))
            {
                return EdiDirection.Inbound;
            }
            else if (IKEAConstants.ERPSystem.Equals(ediEvent.TargetSystem)
                && IKEAConstants.MESSystem.Equals(ediEvent.SourceSystem))
            {
                return EdiDirection.Outbound;
            }
            else
            {
                return EdiDirection.Unknown;
            }
        }

        /// <summary>
        /// Handles inbound integration entries
        /// </summary>
        private IIntegrationEntry HandleInbound(IIntegrationEntry entry, IHandlingContext handlingContext)
        {
            if (!entry.ObjectExists())
            {
                // It must exist for this to succeed
                throw new ObjectNotFoundCmfException("IntegrationEntry", entry.Name);
            }

            entry.Load();
            entry.LoadIntegrationMessage();

            if (entry.IntegrationMessage.Message != null)
            {
                if (handlingContext != null && handlingContext.Route != null)
                {
                    var actionName = handlingContext.Route.ActionName;
                    if (!string.IsNullOrEmpty(actionName))
                    {
                        try
                        {
                            string message = Encoding.UTF8.GetString(entry.IntegrationMessage.Message);

                            var inputDictionary = new Dictionary<string, object>();
                            inputDictionary.Add(IKEAConstants.IntegrationInput, message);
                            inputDictionary.Add(IKEAConstants.IntegrationInputName, entry.Name);

                            DeeAction.ExecuteAction(actionName, inputDictionary);
                        }
                        catch (Exception e)
                        {
                            _loggingService.Error(string.Format("An exception occurred while processing the DEE action '{0}'", actionName), e);
                            throw;
                        }
                    }
                }
            }

            return entry;
        }

        /// <summary>
        /// Handles outbound integration entries
        /// </summary>
        private IIntegrationEntry HandleOutbound(IIntegrationEntry entry, IHandlingContext handlingContext)
        {
            System.Console.WriteLine("Handle outbound message");

            if (!entry.ObjectExists())
            {
                // It must exist for this to succeed
                throw new ObjectNotFoundCmfException("IntegrationEntry", entry.Name);
            }

            entry.Load();
            entry.LoadIntegrationMessage();

            if (entry.IntegrationMessage.Message != null)
            {
                string message = Encoding.UTF8.GetString(entry.IntegrationMessage.Message);

                if (handlingContext != null && handlingContext.Route != null)
                {

                    var actionName = handlingContext.Route.ActionName;
                    Dictionary<string, object> deeResult = null;
                    if (!string.IsNullOrEmpty(actionName))
                    {
                        try
                        {
                            var inputDictionary = new Dictionary<string, object>()
                            {
                                { IKEAConstants.IntegrationInput, message },
                                { IKEAConstants.IntegrationInputName, entry.Name }
                            };

                            deeResult = DeeAction.ExecuteAction(actionName, inputDictionary);
                        }
                        catch (Exception e)
                        {
                            _loggingService.Error(string.Format("An exception occurred while processing the DEE action '{0}'", actionName), e);
                            throw;
                        }

                        if (deeResult != null && deeResult.ContainsKey("Result"))
                        {
                            string resultMessage = deeResult["Result"] as string;
                            entry.Load();
                            entry.SaveResultMessage(Encoding.UTF8.GetBytes(resultMessage));
                        }
                    }
                }
            }

            return entry;
        }
    }
}
