﻿using Cmf.Foundation.BusinessOrchestration;
using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    /// Input Data Contract for the CustomLogMaterialMovementInput service
    /// </summary>
    [DataContract(Name = "CustomLogMaterialMovementInput")]
    public class CustomLogMaterialMovementInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// Resource to transfer the material
        /// </summary>
        [DataMember(Name = "Resource", Order = 100)]
        public IResource TargetResource
        {
            get;
            set;
        }

        /// <summary>
        /// Material to be transfered
        /// </summary>
        [DataMember(Name = "MaterialToTransfer", Order = 100)]
        public IMaterial MaterialToTransfer
        {
            get;
            set;
        }

        /// <summary>
        /// Batch Material of the Material to be transfered
        /// </summary>
        [DataMember(Name = "MaterialBatch", Order = 100)]
        public IMaterial MaterialBatch
        {
            get;
            set;
        }

        /// <summary>
        /// Material names and quantities to merge
        /// </summary>
        [DataMember(Name = "MaterialQuantitiesToMerge", Order = 100)]
        public Dictionary<string, decimal> MaterialQuantitiesToMerge
        {
            get;
            set;
        }

        /// <summary>
        /// Used for the material movement on manual feeding of the line.
        /// The material must be attached at the beginning of the queue or
        /// by splitting the current pallet being consumed inserting the material
        /// between the splitted parent and splitted child
        /// </summary>
        [DataMember(Name = "IsManualLoading", Order = 100)]
        public bool IsManualLoading
        {
            get;
            set;
        }

        /// <summary>
        /// Used for the Expiration Date
        /// </summary>
        [DataMember(Name = "MaterialExpirationDate", Order = 100)]
        public DateTime? MaterialExpirationDate
        {
            get;
            set;
        }

        /// <summary>
        /// UpdateDimensionAttributes
        /// </summary>
        [DataMember(Name = "UpdateDimensionAttributes", Order = 150)]
        public bool UpdateDimensionAttributes
        {
            get;
            set;
        } = false;

        /// <summary>
        /// Used for the Length
        /// </summary>
        [DataMember(Name = "Length", Order = 200)]
        public decimal? Length
        {
            get;
            set;
        }

        /// <summary>
        /// Used for the Width
        /// </summary>
        [DataMember(Name = "Width", Order = 300)]
        public decimal? Width
        {
            get;
            set;
        }

        /// <summary>
        /// Used for the Thickness
        /// </summary>
        [DataMember(Name = "Thickness", Order = 400)]
        public decimal? Thickness
        {
            get;
            set;
        }

        /// <summary>
        /// Used for the Weight
        /// </summary>
        [DataMember(Name = "Weight", Order = 500)]
        public decimal? Weight
        {
            get;
            set;
        }

        /// <summary>
        /// Outsorting: Default Completion Quantity
        /// </summary>
        [DataMember(Name = "DefaultCompletionQuantity", Order = 600)]
        public decimal? DefaultCompletionQuantity
        {
            get;
            set;
        }

        /// <summary>
        /// Outsorting: Existing Pallet in Storage - Quantity to be added
        /// </summary>
        [DataMember(Name = "ExistingPalletQuantity", Order = 600)]
        public decimal? ExistingPalletQuantity
        {
            get;
            set;
        }

        /// <summary>
        /// Outsorting: Represented if Existing Pallet in Storage is to be Completed
        /// </summary>
        [DataMember(Name = "IsExistingPalletCompleted", Order = 600)]
        public bool? IsExistingPalletCompleted
        {
            get;
            set;
        }

        /// <summary>
        /// Outsorting: Number of New Pallets to be created - fully reach default completion quantity and be completed
        /// </summary>
        [DataMember(Name = "NumberOfCompletedPallets", Order = 600)]
        public decimal? NumberOfCompletedPallets
        {
            get;
            set;
        }

        /// <summary>
        /// Outsorting: Quantity to be added to a new pallet to be created and left in storage
        /// </summary>
        [DataMember(Name = "IncompletePalletQuantity", Order = 600)]
        public decimal? IncompletePalletQuantity
        {
            get;
            set;
        }

        /// <summary>
        /// Selected MO on the GUI
        /// </summary>
        [DataMember(Name = "SelectedMO", Order = 700)]
        public string SelectedMO
        {
            get;
            set;
        }

        /// <summary>
        /// Split quantity sent by scan wizard for the material to be split into
        /// </summary>
        [DataMember(Name = "SplitQuantity", Order = 800)]
        public decimal SplitQuantity
        {
            get;
            set;
        }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
