﻿
using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    /// Input Data Contract for the CustomTaskCompleteAndCancelInput service
    /// </summary>
    [DataContract(Name = "CustomTaskCompleteAndCancelInput")]
    public class CustomTaskCompleteAndCancelInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// String specifiying the operation to perfomr ('Complete', 'Cancel')
        /// </summary>
        [DataMember(Name = "TaskOperation", Order = 0)]
        public string TaskOperation { get; set; }

        /// <summary>
        /// Collection of Tasks
        /// </summary>
        [DataMember(Name = "Tasks", Order = 1)]
        public ITaskCollection Tasks { get; set; }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}

