﻿
using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Custom.IKEA.Common.Enums;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    /// Input Data Contract for the CustomWMSManualMoveRequest service
    /// </summary>
    [DataContract(Name = "CustomWMSManualMoveRequestInput")]
    public class CustomWMSManualMoveRequestInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties
        /// <summary>
        /// Order type of the Request (should be only Move or PutAway)
        /// </summary>
        [DataMember(Name = "OrderType", Order = 0)]
        public CustomWMSOrderRequestType OrderType { get; set; }

        /// <summary>
        /// The material to request the Move/PutAway
        /// </summary>
        [DataMember(Name = "Material", Order = 1)]
        public IMaterial Material { get; set; }

        /// <summary>
        /// Source Resource to Pickup the Material from
        /// </summary>
        [DataMember(Name = "SourceResource", Order = 2)]
        public IResource Source { get; set; }

        /// <summary>
        /// Destination Resource to Deliver the Material to (only when type is Move)
        /// </summary>
        [DataMember(Name = "DestinationResource", Order = 3)]
        public IResource Destination { get; set; }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
