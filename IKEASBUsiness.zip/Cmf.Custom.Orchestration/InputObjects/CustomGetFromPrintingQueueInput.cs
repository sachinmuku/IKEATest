﻿using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    /// Input Data Contract for the CustomGetFromPrintingQueue service
    /// </summary>
    [DataContract(Name = "CustomGetFromPrintingQueueInput")]
    public class CustomGetFromPrintingQueueInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// The resource associated with the line
        /// </summary>
        [DataMember(Name = "LineResource", Order = 0)]
        public IResource LineResource { get; set; }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
