﻿
using System.Collections.Generic;
using System.Runtime.Serialization;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Foundation.BusinessOrchestration;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    /// Input Data Contract for the CustomCreateVirtualPallet service
    /// </summary>
    [DataContract(Name = "CustomCreateVirtualPalletInput")]
    public class CustomCreateVirtualPalletInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties
        /// <summary>
        /// ResourceId
        /// </summary>
        [DataMember(Name = "ResourceId", Order = 0)]
        public string ResourceId { get; set; }

        /// <summary>
        /// Quantity of the resulted virtual pallet
        /// </summary>
        [DataMember(Name = "Quantity", Order = 0)]
        public decimal Quantity { get; set; }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
