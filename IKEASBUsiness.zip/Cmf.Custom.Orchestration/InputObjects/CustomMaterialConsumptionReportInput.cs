﻿using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    /// Input Data Contract for the CustomMaterialConsumptionReport service
    /// </summary>
    [DataContract(Name = "CustomMaterialConsumptionReportInput")]
    public class CustomMaterialConsumptionReportInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// Material to report the consumption
        /// </summary>
        [DataMember(Name = "Material", Order = 10)]
        public IMaterial Material { get; set; }

        /// <summary>
        /// OrderName to report the consumption
        /// </summary>
        [DataMember(Name = "OrderName", Order = 10)]
        public string OrderName { get; set; }

        /// <summary>
        /// Quantity that IoT reports as attached in the feeders
        /// </summary>
        [DataMember(Name = "InFeederQuantity", Order = 10)]
        public decimal InFeederQuantity { get; set; }

        /// <summary>
        /// Quantity that IoT reports as completed and still in the line.
        /// </summary>
        [DataMember(Name = "InBufferQuantity", Order = 10)]
        public decimal InBufferQuantity { get; set; }

        /// <summary>
        /// Indicates if the current cunsumption is for the last pallet
        /// </summary>
        [DataMember(Name = "IsLastPallet", Order = 10)]
        public bool IsLastPallet { get; set; }
        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
