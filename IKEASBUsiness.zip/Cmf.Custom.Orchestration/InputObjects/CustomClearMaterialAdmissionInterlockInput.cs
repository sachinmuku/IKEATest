﻿using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    /// Input Data Contract for the CustomClearMaterialAdmissionInterlock service
    /// </summary>
    [DataContract(Name = "CustomClearMaterialAdmissionInterlockInput")]
    public class CustomClearMaterialAdmissionInterlockInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// Resource for checking interlock clear
        /// </summary>
        [DataMember(Name = "Resource", Order = 100)]
        public IResource Resource
        {
            get;
            set;
        }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
