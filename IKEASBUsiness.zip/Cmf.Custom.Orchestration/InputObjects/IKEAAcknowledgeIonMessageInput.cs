﻿using Cmf.Foundation.BusinessOrchestration;
using Cmf.Navigo.BusinessObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    /// Input Data Contract for the IKEAAcknowledgeIonMessage service
    /// </summary>
    [DataContract(Name = "IKEAAcknowledgeIonMessageInput")]
    public class IKEAAcknowledgeIonMessageInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// Message sent from the ION
        /// </summary>
        [DataMember(Name = "IonMessage", Order = 10)]
        public String IonMessage { get; set; }

        /// <summary>
        /// Indicates if message is URL Base64 Encoded
        /// </summary>
        [DataMember(Name = "IsBase64URL", Order = 10)]
        public Boolean IsBase64URL { get; set; }
        
        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
