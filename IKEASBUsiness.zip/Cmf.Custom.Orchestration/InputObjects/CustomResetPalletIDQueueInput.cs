using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    /// CustomResetPalletIDQueueInput Input Object
    /// </summary>
    [DataContract(Name = "CustomResetPalletIDQueueInput")]
    public class CustomResetPalletIDQueueInput : BaseInput
    {
        /// <summary>
        /// Material to load to reset queue
        /// </summary>
        [DataMember(Name = "Material", Order = 0)]
        public string Material
        {
            get;
            set;
        }

    }
}
