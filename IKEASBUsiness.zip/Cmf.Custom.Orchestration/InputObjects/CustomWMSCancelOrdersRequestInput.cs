﻿
using Cmf.Foundation.BusinessOrchestration;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    [DataContract(Name = "CustomWMSCancelOrdersRequestInput")]
    public class CustomWMSCancelOrdersRequestInput : BaseInput
    {

        [DataMember(Name = "FactoryAutomationJobIds", Order = 10)]
        public List<long> FactoryAutomationJobIds { get; set; }

    }
}
