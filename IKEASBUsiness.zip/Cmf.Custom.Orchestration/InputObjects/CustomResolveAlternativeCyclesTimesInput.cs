﻿using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    ///  Input Data Contract for the CustomResolveAlternativeCyclesTimesInput service
    /// </summary>
    [DataContract(Name = "CustomResolveAlternativeCyclesTimesInput")]
    public class CustomResolveAlternativeCyclesTimesInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties
        /// <summary>
        /// MO Material
        /// </summary>
        [DataMember(Name = "Material", Order = 0)]
        public IMaterial Material { get; set; }

        /// <summary>
        /// Main Line Resource
        /// </summary>
        [DataMember(Name = "Resource", Order = 1)]
        public IResource Resource { get; set; }
        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
