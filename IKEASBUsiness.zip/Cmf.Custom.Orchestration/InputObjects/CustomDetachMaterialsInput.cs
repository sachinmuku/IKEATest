using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    /// CustomDetachMaterialsInput Input Object
    /// </summary>
    [DataContract(Name = "CustomDetachMaterialsInput")]
    public class CustomDetachMaterialsInput : BaseInput
    {
        /// <summary>
        /// Resource to load to reset queue
        /// </summary>
        [DataMember(Name = "Resource", Order = 0)]
        public string Resource
        {
            get;
            set;
        }

    }
}
