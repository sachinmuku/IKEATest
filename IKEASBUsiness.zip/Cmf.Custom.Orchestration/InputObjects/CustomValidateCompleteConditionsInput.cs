﻿using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{

    /// <summary>
    /// Input Data Contract for the CustomValidateCompleteConditions service
    /// </summary>
    [DataContract(Name = "CustomValidateCompleteConditionsInput")]
    public class CustomValidateCompleteConditionsInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables

        #endregion

        #region Properties

        /// <summary>
        /// Material
        /// </summary>
        [DataMember(Name = "Material", Order = 0)]
        public IMaterial Material { get; set; }

        /// <summary>
        /// Resource
        /// </summary>
        [DataMember(Name = "Resource", Order = 0)]
        public IResource Resource { get; set; }

        /// <summary>
        /// Allow to commit IoT abort command
        /// When abort is the only outcome possible, it's given the user the oportunity to confirm if he wants to proceed
        /// </summary>
        [DataMember(Name = "IsToCommitAbort", Order = 0)]
        public bool IsToCommitAbort { get; set; } = true;

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
