﻿using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{

    /// <summary>
    /// Input Data Contract for the CustomGetDetailsForPalletOutsorting service.
    /// </summary>
    [DataContract(Name = "CustomGetDetailsForPalletOutsorting")]
    public class CustomGetDetailsForPalletOutsortingInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// 
        /// </summary>
        [DataMember(Name = "IsNewMaterial", Order = 100)]
        public bool IsNewMaterial { get; set; }

        /// <summary>
        /// Material
        /// </summary>
        [DataMember(Name = "Material", Order = 200)]
        public IMaterial Material { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [DataMember(Name = "BatchName", Order = 300)]
        public string BatchName { get; set; }

        /// <summary>
        /// Resource
        /// </summary>
        [DataMember(Name = "Resource", Order = 400)]
        public IResource Resource { get; set; }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
