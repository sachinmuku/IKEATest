﻿using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    /// Input Data Contract for the CustomGetOutSortedPalletFromFeeder service
    /// </summary>
    [DataContract(Name = "CustomGetOutSortedPalletFromFeederInput")]
    public class CustomGetOutSortedPalletFromFeederInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// The resource associated with the feeder
        /// </summary>
        [DataMember(Name = "Feeder", Order = 0)]
        public IResource Feeder { get; set; }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
