﻿using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;
using Cmf.Foundation.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    /// Input Data Contract for the CustomGetDataForPalletLocationInput service
    /// </summary>
    [DataContract(Name = "CustomGetDataForPalletLocationInput")]
    public class CustomGetDataForPalletLocationInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets FilterCollection
        /// </summary>
        [DataMember(Name = "FilterCollection", Order = 0)]
        public IFilterCollection FilterCollection
        {
            get;

            set;
        }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
