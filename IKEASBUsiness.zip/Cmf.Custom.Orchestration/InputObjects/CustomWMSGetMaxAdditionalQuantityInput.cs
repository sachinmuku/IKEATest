﻿
using Cmf.Custom.IKEA.Common;
using Cmf.Foundation.BusinessOrchestration;
using Cmf.Navigo.BusinessObjects.Abstractions;
using System;
using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    [DataContract(Name = "CustomWMSGetMaxAdditionalQuantity")]
    public class CustomWMSGetMaxAdditionalQuantityInput : BaseInput
    {
        
        [DataMember(Name = "ManufacturingOrders", Order = 1)]
        public string ManufacturingOrders{ get; set; }

        [DataMember(Name = "WareHouseOrdersDetails", Order = 2)]
        public WareHouseOrders[] WareHouseOrdersDetails{ get; set; }
        
    }
    
    [DataContract(Namespace = "", IsReference = true,Name = "WareHouseOrders")]
    public class WareHouseOrders
    {
        [DataMember(Name = "Product", Order = 1)]
        public IProduct Product { get; set; }

        [DataMember(Name = "RemainingQuantity", Order = 2)]
        public decimal RemainingQuantity { get; set; }

        [DataMember(Name = "DestinationFeeder", Order = 3)]
        public IResource DestinationFeeder { get; set; }

    }
}
