﻿
using Cmf.Foundation.BusinessOrchestration;
using Cmf.Navigo.BusinessObjects;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{

    /// <summary>
    /// Input Data contract to CustomPostDataToCharts service
    /// </summary>
    [DataContract(Name = "CustomPostDataToChartsInput")]
    public class CustomPostDataToChartsInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// Resource related to collected data
        /// </summary>
        [DataMember(Name = "Resource", Order = 10)]
        public string Resource { get; set; }

        /// <summary>
        /// Readings containing chart name and List of point values to post
        /// </summary>
        [DataMember(Name = "Readings", Order = 10)]
        public Dictionary<string,List<decimal>> Readings { get; set; }

        /// <summary>
        /// Additional Context for Chart Data point enrichement
        /// </summary>
        [DataMember(Name = "AdditionalContext", Order = 10)]
        public Dictionary<string, string> AdditionalContext { get; set; }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
