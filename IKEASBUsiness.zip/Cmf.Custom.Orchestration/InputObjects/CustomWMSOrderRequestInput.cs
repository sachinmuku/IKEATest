﻿
using Cmf.Custom.IKEA.Common.Enums;
using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    [DataContract(Name = "CustomWMSOrderRequestInput")]
    public class CustomWMSOrderRequestInput : BaseInput
    {

        [DataMember(Name = "FactoryAutomationJobId", Order = 10)]
        public string FactoryAutomationJobId { get; set; }

        [DataMember(Name = "InventoryOrderType", Order = 10)]
        public CustomWMSOrderRequestType InventoryOrderType { get; set; }

        [DataMember(Name = "InventoryOrderId", Order = 10)]
        public long InventoryOrderId { get; set; }

        [DataMember(Name = "ProductName", Order = 10)]
        public string ProductName { get; set; }

        [DataMember(Name = "ManufacturingOrderName", Order = 10)]
        public string ManufacturingOrderName { get; set; }

        [DataMember(Name = "MaterialQuantity", Order = 10)]
        public decimal MaterialQuantity { get; set; }

        [DataMember(Name = "SourceResource", Order = 10)]
        public string SourceResource { get; set; }

        [DataMember(Name = "DestinationResource", Order = 10)]
        public string DestinationResource { get; set; }

        [DataMember(Name = "PalletName", Order = 10)]
        public string PalletName { get; set; }

        [DataMember(Name = "BatchID", Order = 10)]
        public string BatchID { get; set; }

        [DataMember(Name = "Status", Order = 10)]
        public string Status { get; set; }

    }
}
