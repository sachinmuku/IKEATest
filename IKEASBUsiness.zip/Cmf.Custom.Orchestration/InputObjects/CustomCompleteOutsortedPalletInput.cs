﻿using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    /// Output Data Contract for the CustomCompleteOutsortedPalletInput service
    /// </summary>
    [DataContract(Name = "CustomCompleteOutsortedPalletInput")]
    public class CustomCompleteOutsortedPalletInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// Resource where the storage is located
        /// </summary>
        [DataMember(Name = "Resource", Order = 100)]
        public IResource Resource
        {
            get;
            set;
        }

        /// <summary>
        /// Used for the Packaging Outsorting, it represents the outsorted quantity that should be deducted from the previous pallets.
        /// </summary>
        [DataMember(Name = "FeederOutsortingQuantity", Order = 100)]
        public decimal FeederOutsortingQuantity
        {
            get;
            set;
        }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion

    }
}
