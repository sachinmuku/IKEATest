﻿using Cmf.Foundation.BusinessOrchestration;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    /// Input Data Contract for the CustomGetResourcesForCheckInInput service
    /// </summary>
    [DataContract(Name = "CustomHandleGroupManufacturingOrdersInput")]
    public class CustomHandleGroupManufacturingOrdersInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties
        [DataMember(Name = "GroupMaterialOrder", Order = 0)]
        public IMaterial GroupMaterialOrder { get; set; }

        [DataMember(Name = "MaterialPartsPerCycle", Order = 1)]
        public Dictionary<IMaterial, decimal> MaterialPartsPerCycle { get; set; }

        [DataMember(Name = "ResourceToDispatch", Order = 2)]
        public IResource ResourceToDispatch { get; set; }

        [DataMember(Name = "IsHPOEnabled", Order = 3)]
        public bool IsHPOEnabled { get; set; }

        [DataMember(Name = "IsToDispatch", Order = 4)]
        public bool IsToDispatch { get; set; }

        [DataMember(Name = "IsToOptimize", Order = 5)]
        public bool IsToOptimize { get; set; }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
