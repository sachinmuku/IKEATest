﻿using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{

    /// <summary>
    /// Input Data Contract for the CustomForceOrderCompletion service
    /// </summary>
    [DataContract(Name = "CustomForceOrderCompletionInput")]
    public class CustomForceOrderCompletionInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables

        #endregion

        #region Properties

        /// <summary>
        /// Material to Force Completion
        /// </summary>
        [DataMember(Name = "Material", Order = 1)]
        public IMaterial Material { get; set; }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
