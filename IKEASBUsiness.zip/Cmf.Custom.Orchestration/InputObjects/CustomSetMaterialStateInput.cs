﻿using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    /// Input Data Contract for the CustomSetMaterialState service
    /// </summary>
    [DataContract(Name = "CustomSetMaterialStateInput")]
    public class CustomSetMaterialStateInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// Material for changing state
        /// </summary>
        [DataMember(Name = "Material", Order = 100)]
        public IMaterial Material
        {
            get;
            set;
        }

        /// <summary>
        /// Material id for changing state
        /// </summary>
        [DataMember(Name = "MaterialName", Order = 100)]
        public string MaterialName
        {
            get;
            set;
        }

        /// <summary>
        /// State for changing the Material
        /// </summary>
        [DataMember(Name = "State", Order = 100)]
        public string State
        {
            get;
            set;
        }

        /// <summary>
        /// Flag indicating if it is on Stop process
        /// </summary>
        [DataMember(Name = "IsToStopMaterial", Order = 100)]
        public bool IsToStopMaterial
        {
            get;
            set;
        }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
