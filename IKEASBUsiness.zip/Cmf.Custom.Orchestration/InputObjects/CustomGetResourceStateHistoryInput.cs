﻿using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Foundation.Security.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    /// Input Data Contract for the CustomGetResourceStateHistory service
    /// </summary>
    [DataContract(Name = "CustomGetResourceStateHistoryInput")]
    public class CustomGetResourceStateHistoryInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// User
        /// </summary>
        [DataMember(Name = "User", Order = 100)]
        public IUser User
        {
            get;
            set;
        }

        /// <summary>
        /// Resource
        /// </summary>
        [DataMember(Name = "Resource", Order = 100)]
        public IResource Resource
        {
            get;
            set;
        }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
