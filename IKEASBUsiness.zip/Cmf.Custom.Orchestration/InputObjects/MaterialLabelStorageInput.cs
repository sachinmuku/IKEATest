﻿using Cmf.Foundation.BusinessOrchestration;
using Cmf.Navigo.BusinessObjects;
using DocumentFormat.OpenXml.Wordprocessing;
using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    /// Input Data Contract for the MaterialLabelStorage service
    /// </summary>
    [DataContract(Name = "MaterialLabelStorageInput")]
    public class MaterialLabelStorageInput : BaseInput
    {

        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// Main resource feeder where the attribute is and where the material will be attached
        /// </summary>
        [DataMember(Name = "MainFeeder", Order = 0)]
        public String MainFeeder { get; set; }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion

    }
}
