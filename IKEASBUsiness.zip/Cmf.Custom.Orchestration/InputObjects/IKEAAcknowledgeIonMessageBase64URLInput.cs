﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;
using Cmf.Foundation.BusinessOrchestration;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    /// Input Data Contract for IKEAAcknowledgeIonMessageBase64URL service.
    /// </summary>
    [DataContract(Name = "IKEAAcknowledgeIonMessageBase64URLInput")]
    public class IKEAAcknowledgeIonMessageBase64URLInput : BaseInput
    {
        [DataMember(Order = 10)]
        public string IonMessage { get; set; }
    }
}
