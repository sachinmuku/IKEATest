﻿using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    /// Input Data Contract for the CustomHandleConsumptionProvider service
    /// </summary>
    [DataContract(Name = "CustomHandleConsumptionProviderInput")]
    public class CustomHandleConsumptionProviderInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// Consumable Feed
        /// </summary>
        [DataMember(Name = "ConsumableFeed", Order = 100)]
        public IResource ConsumableFeed
        {
            get;
            set;
        }

        /// <summary>
        /// ConsumptionProvider used by the feeder
        /// </summary>
        [DataMember(Name = "ConsumptionProvider", Order = 100)]
        public IResource ConsumptionProvider
        {
            get;
            set;
        }

        /// <summary>
        /// Aditional consumption providers used together with the main feeder
        /// </summary>
        [DataMember(Name = "DistributedConsumptionProviders", Order = 100)]
        public IResourceCollection DistributedConsumptionProviders
        {
            get;
            set;
        }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
