﻿
using System.Collections.Generic;
using System.Runtime.Serialization;
using Cmf.Foundation.BusinessOrchestration;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{

    /// <summary>
    /// Input Data Contract for the CustomGetParentlessMOListByFilterInput service
    /// </summary>
    [DataContract(Name = "CustomGetParentlessMOListByFilterInput")]
    public class CustomGetParentlessMOListByFilterInput : BaseInput
    {
        /// <summary>
        /// Resource to get material dispatch list.
        /// </summary>
        [DataMember(Name = "Resource", Order = 0)]
        public IResource Resource { get; set; }

        /// <summary>
        /// Filter material list response based on product
        /// </summary>
        [DataMember(Name = "ProductFilter", Order = 0)]
        public IProduct ProductFilter { get; set; }

        /// <summary>
        /// Filter material list response based on Material Name
        /// </summary>
        [DataMember(Name = "MaterialNameFilter", Order = 0)]
        public string MaterialNameFilter { get; set; }

        /// <summary>
        /// Exclude materials based on the ExcludedMaterials List
        /// </summary>
        [DataMember(Name = "ExcludedMaterials", Order = 0)]
        public List<IMaterial> ExcludedMaterials { get; set; }

    }
}
