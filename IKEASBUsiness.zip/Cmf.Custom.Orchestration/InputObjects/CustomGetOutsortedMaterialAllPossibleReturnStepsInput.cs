﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using Cmf.Foundation.BusinessOrchestration;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    /// Input Data Contract for the CustomGetOutsortedMaterialAllPossibleReturnSteps service
    /// </summary>
    [DataContract(Name = "CustomGetOutsortedMaterialAllPossibleReturnStepsInput")]
    public class CustomGetOutsortedMaterialAllPossibleReturnStepsInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// Outsorted material name for which we need to get all possible return steps
        /// </summary>
        [DataMember(Name = "MaterialName", Order = 0)]
        public string MaterialName { get; set; }

        /// <summary>
        /// Outsorted material new material type (going to change) for which we need to get all possible return steps
        /// </summary>
        [DataMember(Name = "NewMaterialType", Order = 1)]
        public string NewMaterialType { get; set; }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion
    }
}
