﻿using Cmf.Foundation.BusinessOrchestration;
using Cmf.Navigo.BusinessObjects;
using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    /// Input Data Contract for CustomAutomationDataCollectionToMES service.
    /// </summary>
    [DataContract(Name = "CustomAutomationDataCollectionToMESInput")]
    public class CustomAutomationDataCollectionToMESInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// Data Collection Name
        /// </summary>
        [DataMember(Name = "DataCollectionName", Order = 10)]
        public string DataCollectionName { get; set; }

        /// <summary>
        /// Resource Name
        /// </summary>
        [DataMember(Name = "ResourceName", Order = 10)]
        public string ResourceName { get; set; }

        /// <summary>
        /// Material Name
        /// </summary>
        [DataMember(Name = "MaterialName", Order = 10)]
        public string MaterialName { get; set; }

        /// <summary>
        /// DataCollection Instance ExecutionMode
        /// </summary>
        [DataMember(Name = "DataCollectionInstanceExecutionMode", Order = 10)]
        public DataCollectionInstanceExecutionMode DataCollectionInstanceExecutionMode { get; set; }

        /// <summary>
        /// Data To Collect
        /// </summary>
        [DataMember(Name = "DataToCollect", Order = 10)]
        public Dictionary<String, Object> DataToCollect { get; set; }

        /// <summary>
        /// SampleId
        /// </summary>
        [DataMember(Name = "SampleId", Order = 10)]
        public String SampleId { get; set; }

        /// <summary>
        /// Operation Name
        /// </summary>
        [DataMember(Name = "OperationName", Order = 10)]
        public String OperationName { get; set; }

        /// <summary>
        /// Skip DataCollection Validation
        /// </summary>
        [DataMember(Name = "SkipDcValidation", Order = 10)]
        public Boolean SkipDcValidation { get; set; }

        /// <summary>
        /// Add Readings
        /// </summary>
        [DataMember(Name = "AddReadings", Order = 10)]
        public Boolean AddReadings { get; set; }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion

    }
}
