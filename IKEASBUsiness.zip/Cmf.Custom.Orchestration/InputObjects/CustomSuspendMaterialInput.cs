﻿using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    /// Input Data Contract for the CustomSuspendMaterial service
    /// </summary>
    [DataContract(Name = "CustomSuspendMaterialInput")]
    public class CustomSuspendMaterialInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// The material to suspend
        /// </summary>
        [DataMember(Name = "Material", Order = 0)]
        public IMaterial Material { get; set; }

        /// <summary>
        /// Unsuspend flag to indicate to the service that it should unsuspend the material instead of suspending
        /// </summary>
        [DataMember(Name = "Unsuspend", Order = 1)]
        public bool Unsuspend { get; set; }

        /// <summary>
        /// IsIOTSource flag to identify if request is comming from Equipment
        /// </summary>
        [DataMember(Name = "IsIOTSource", Order = 2)]
        public bool IsIOTSource { get; set; }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
