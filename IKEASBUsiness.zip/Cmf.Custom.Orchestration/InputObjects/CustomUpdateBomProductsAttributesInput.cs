﻿using Cmf.Foundation.BusinessOrchestration;
using Cmf.Navigo.BusinessObjects;
using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    /// Input Data Contract for the CustomUpdateBomProductsAttributes service
    /// </summary>
    [DataContract(Name = "CustomUpdateBomProductsAttributesInput")]
    public class CustomUpdateBomProductsAttributesInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// List of bomproducts to update
        /// </summary>
        [DataMember(Name = "ProductsToUpdate", Order = 100)]
        public Dictionary<string, Dictionary<string, object>> ProductsToUpdate
        {
            get;
            set;
        }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
