﻿
using Cmf.Custom.IKEA.Common.Enums;
using Cmf.Foundation.BusinessOrchestration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    /// Input Data Contract for the CustomLogAlarmOccurrenceInput service
    /// </summary>
    [DataContract(Name = "CustomLogAlarmOccurrenceInput")]
    public class CustomLogAlarmOccurrenceInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// Alarm Operation
        /// </summary>
        [DataMember(Name = "AlarmOperation", Order = 0)]
        public CustomAlarmOccurrenceOperationEnum AlarmOperation { get; set; }

        /// <summary>
        /// Alarm Code
        /// </summary>
        [DataMember(Name = "AlarmCode", Order = 1)]
        public string AlarmCode { get; set; }

        /// <summary>
        /// Alarm Category
        /// </summary>
        [DataMember(Name = "AlarmCategory", Order = 2)]
        public string AlarmCategory { get; set; }

        /// <summary>
        /// Alarm Category
        /// </summary>
        [DataMember(Name = "AlarmMessage", Order = 3)]
        public string AlarmMessage { get; set; }

        /// <summary>
        /// Material Name
        /// </summary>
        [DataMember(Name = "Material", Order = 4)]
        public string Material { get; set; }

        /// <summary>
        /// Resource Name
        /// </summary>
        [DataMember(Name = "Resource", Order = 5)]
        public string Resource { get; set; }

        /// <summary>
        /// Flag that indicates if service should Log 
        /// </summary>
        [DataMember(Name = "Log", Order = 6)]
        public bool Log { get; set; }

        /// <summary>
        /// AlarmOccurrence Unique ID
        /// </summary>
        [DataMember(Name = "AlarmOccurrenceUID", Order = 7)]
        public long? AlarmOccurrenceUID { get; set; }

        /// <summary>
        /// Occurence Start date time 
        /// </summary>
        [DataMember(Name = "StartDate", Order = 8)]
        public DateTime? StartDate { get; set; }

        /// <summary>
        /// Occurence End date time
        /// </summary>
        [DataMember(Name = "EndDate", Order = 9)]
        public DateTime? EndDate { get; set; }

        /// <summary>
        /// Occurence Ack date time
        /// </summary>
        [DataMember(Name = "AckDate", Order = 10)]
        public DateTime? AckDate { get; set; }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
