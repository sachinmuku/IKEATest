﻿using Cmf.Foundation.BusinessOrchestration;
using Cmf.Foundation.Security;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessOrchestration.KPIManagement.InputObjects;
using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{

    /// <summary>
    /// Input Data Contract for the CustomGetDataForPPM service
    /// </summary>
    [DataContract(Name = "CustomGetDataForPPMInput")]
    public class CustomGetDataForPPMInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// TimeFrame
        /// </summary>
        [DataMember(Name = "TimeFrame", Order = 0)]
        public TimeFrame TimeFrame { get; set; }

        /// <summary>
        /// GetActual - If yes, it will return the data until the current date, otherwise, get data until yesterday
        /// </summary>
        [DataMember(Name = "GetActual", Order = 0)]
        public Boolean GetActual { get; set; }

        /// <summary>
        /// FacilityName
        /// </summary>
        [DataMember(Name = "FacilityName", Order = 0)]
        public String FacilityName { get; set; }

        /// <summary>
        /// AreaName
        /// </summary>
        [DataMember(Name = "AreaName", Order = 0)]
        public String AreaName { get; set; }

        /// <summary>
        /// Resources
        /// </summary>
        [DataMember(Name = "Resources", Order = 0)]
        public List<String> Resources { get; set; }

        /// <summary>
        /// Steps
        /// </summary>
        [DataMember(Name = "Steps", Order = 0)]
        public List<String> Steps { get; set; }

        /// <summary>
        /// Products
        /// </summary>
        [DataMember(Name = "Products", Order = 0)]
        public List<String> Products { get; set; }

        /// <summary>
        /// ProductGroupName
        /// </summary>
        [DataMember(Name = "ProductGroupName", Order = 0)]
        public String ProductGroupName { get; set; }

        /// <summary>
        /// ProductType
        /// </summary>
        [DataMember(Name = "ProductType", Order = 0)]
        public String ProductType { get; set; }

        /// <summary>
        /// StepTypes
        /// </summary>
        [DataMember(Name = "StepTypes", Order = 0)]
        public List<String> StepTypes { get; set; }

        /// <summary>
        /// ResourceType
        /// </summary>
        [DataMember(Name = "ResourceTypes", Order = 0)]
        public List<String> ResourceTypes { get; set; }

        /// <summary>
        /// ResourceResourceType
        /// </summary>
        [DataMember(Name = "ResourceResourceTypes", Order = 0)]
        public List<String> ResourceResourceTypes { get; set; }

        /// <summary>
        /// Gets or sets the cycle time scale.
        /// </summary>
        /// <value>
        /// The cycle time scale.
        /// </value>
        [DataMember(Name = "CycleTimeScale", Order = 0)]
        public Navigo.Common.TimeScale CycleTimeScale { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is material cycle time.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is material cycle time; otherwise, <c>false</c>.
        /// </value>
        [DataMember(Name = "IsMaterialCycleTime", Order = 0)]
        public bool IsMaterialCycleTime { get; set; }

        /// <summary>
        /// Shift Definition
        /// </summary>
        [DataMember(Name = "ShiftDefinition", Order = 0)]
        public string ShiftDefinition { get; set; }

        /// <summary>
        /// Shifts
        /// </summary>
        [DataMember(Name = "Shifts", Order = 0)]
        public List<string> Shifts { get; set; }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
