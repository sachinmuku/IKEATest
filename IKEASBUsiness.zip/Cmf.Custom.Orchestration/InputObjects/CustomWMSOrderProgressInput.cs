﻿using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using Cmf.Foundation.BusinessOrchestration;
using System;
using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    [DataContract(Name = "CustomWMSOrderProgressInput")]
    public class CustomWMSOrderProgressInput : BaseInput, IWMSIntegrationMessage
    {
        [DataMember(Name = "_id", Order = 10)]
        public string _id { get; set; }

        [DataMember(Name = "Request", Order = 10)]
        public int Request { get; set; }

        [DataMember(Name = "Response", Order = 10)]
        public CustomWMSOrderResponseType Response { get; set; }

        [DataMember(Name = "Details", Order = 10)]
        public string Details { get; set; }

        [DataMember(Name = "IOType", Order = 10)]
        public CustomWMSOrderRequestType IOType { get; set; }

        [DataMember(Name = "Command", Order = 10)]
        public int Command { get; set; }

        [DataMember(Name = "CommandParameter1", Order = 10)]
        public int CommandParameter1 { get; set; }

        [DataMember(Name = "State", Order = 10)]
        public CustomWMSOrderStateEnum State { get; set; }

        [DataMember(Name = "IOID", Order = 10)]
        public long? IOID { get; set; }

        [DataMember(Name = "ItemID", Order = 10)]
        public string ItemID { get; set; }

        [DataMember(Name = "ItemName", Order = 10)]
        public string ItemName { get; set; }

        [DataMember(Name = "Quantity", Order = 10)]
        public decimal Quantity { get; set; }

        [DataMember(Name = "DeliveredQuantity", Order = 10)]
        public decimal DeliveredQuantity { get; set; }

        [DataMember(Name = "Source", Order = 10)]
        public string Source { get; set; }

        [DataMember(Name = "Destination", Order = 10)]
        public string Destination { get; set; }

        [DataMember(Name = "PalletID", Order = 10)]
        public string PalletID { get; set; }

        [DataMember(Name = "PalletQuantity", Order = 10)]
        public decimal PalletQuantity { get; set; }

        [DataMember(Name = "BatchID", Order = 10)]
        public string BatchID { get; set; }

        [DataMember(Name = "Status", Order = 10)]
        public int Status { get; set; }

        [DataMember(Name = "StartTime", Order = 10)]
        public DateTime StartTime { get; set; } = DateTime.Now;

        [DataMember(Name = "PalletDimension0", Order = 10)]
        public decimal PalletDimension0 { get; set; }

        [DataMember(Name = "PalletDimension1", Order = 10)]
        public decimal PalletDimension1 { get; set; }

        [DataMember(Name = "PalletDimension2", Order = 10)]
        public decimal PalletDimension2 { get; set; }

        [DataMember(Name = "BaseboardDimension0", Order = 10)]
        public decimal BaseboardDimension0 { get; set; }

        [DataMember(Name = "BaseboardDimension1", Order = 10)]
        public decimal BaseboardDimension1 { get; set; }

        [DataMember(Name = "BaseboardDimension2", Order = 10)]
        public decimal BaseboardDimension2 { get; set; }

        [DataMember(Name = "ManufacturingOrderName", Order = 10)]
        public string ManufacturingOrderName { get; set; }
    }
}
