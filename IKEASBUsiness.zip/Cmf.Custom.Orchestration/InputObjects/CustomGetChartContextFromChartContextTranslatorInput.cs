﻿using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    /// Defines the inputs available for the chart context automation resolution,
    /// which occurs when a user starts gathering SPC data.
    /// </summary>
    public class CustomGetChartContextFromChartContextTranslatorInput : BaseInput
    {
        /// <summary>
        /// The users current resource.
        /// </summary>
        [DataMember()]
        public IResource Resource { get; set; }

        /// <summary>
        /// The users material.
        /// </summary>
        [DataMember()]
        public IMaterial Material { get; set; }

        /// <summary>
        /// The SPC chart for which data will be gathered.
        /// </summary>
        [DataMember(IsRequired = true)]
        public string ChartName { get; set; }
    }
}
