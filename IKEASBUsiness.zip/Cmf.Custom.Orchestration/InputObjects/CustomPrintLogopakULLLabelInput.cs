﻿using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    /// Service that sends all information to be printed to IoT
    /// </summary>
    [DataContract(Name = "CustomPrintLogopakULLLabelInput")]
    public class CustomPrintLogopakULLLabelInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// Main line
        /// </summary>
        [DataMember(Name = "ResourceId", Order = 100)]
        public string ResourceId
        {
            get;
            set;
        }

        /// <summary>
        /// Sub-Resource of type Printer (represents the logopak printer)
        /// </summary>
        [DataMember(Name = "PrinterName", Order = 100)]
        public string PrinterName
        {
            get;
            set;
        }

        /// <summary>
        /// information collection of all necessary fileds to the ULL label
        /// </summary>
        [DataMember(Name = "UllLabelInfo", Order = 100)]
        public UllLabelFields UllLabelInfo
        {
            get;
            set;
        }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
