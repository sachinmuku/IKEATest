using Cmf.Foundation.BusinessOrchestration;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    /// Input Data Contract for the CustomCreateOrderlessProduction service
    /// </summary>
    [DataContract(Name = "CustomCreateOrderlessProductionInput")]
    public class CustomCreateOrderlessProductionInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties
        /// <summary>
        /// List of orderless production creations
        /// </summary>
        [DataMember(Name = "Orders", Order = 0)]
        public List<OrderlessCreation> Orders { get; set; }

        /// <summary>
        /// Flag to check if it's a group order
        /// </summary>
        [DataMember(Name = "IsGroupOrder", Order = 1)]
        public bool IsGroupOrder { get; set; }

        /// <summary>
        /// Flag to check if it is to optimize
        /// </summary>
        [DataMember(Name = "IsToOptimize", Order = 2)]
        public bool IsToOptimize { get; set; }

        /// <summary>
        /// Resource to be used
        /// </summary>
        [DataMember(Name = "Resource", Order = 3)]
        public IResource Resource { get; set; }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
