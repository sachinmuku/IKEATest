﻿using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{

    /// <summary>
    /// Input Data Contract for the CustomGetMOFutureConsumptionInformationInput service
    /// </summary>
    [DataContract(Name = "CustomGetMOFutureConsumptionInformationInput")]
    public class CustomGetMOFutureConsumptionInformationInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// Material for which possible future consumers and possible feeders will be retrieved
        /// </summary>
        [DataMember(Name = "Material", Order = 10)]
        public IMaterial Material { get; set; }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
