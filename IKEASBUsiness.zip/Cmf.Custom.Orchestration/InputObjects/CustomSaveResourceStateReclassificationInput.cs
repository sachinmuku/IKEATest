﻿using Cmf.Foundation.BusinessOrchestration;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Cmf.Custom.IKEA.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{

    /// <summary>
    /// Input Data Contract for the CustomSaveResourceStateReclassification service
    /// </summary>
    [DataContract(Name = "CustomSaveResourceStateReclassificationInput")]
    public class CustomSaveResourceStateReclassificationInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// Dictionary that contains the previous State as key and the new one as value
        /// </summary>
        [DataMember(Name = "ResourceStateReclassifications", Order = 100)]
        public Dictionary<ICustomResourceStateReclassification, ICustomResourceStateReclassification> ResourceStateReclassifications
        {
            get;
            set;
        }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
