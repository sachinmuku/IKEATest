﻿using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    /// Input Data Contract for the CustomCalculateNeededOutsortedPalletInput service
    /// </summary>
    [DataContract(Name = "CustomCalculateNeededOutsortedPalletInput")]
    public class CustomCalculateNeededOutsortedPalletInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// Represents the outsorted quantity that should be deducted from the previous pallets.
        /// </summary>
        [DataMember(Name = "OutsortingQuantity", Order = 100)]
        public decimal OutsortingQuantity
        {
            get;
            set;
        }

        /// <summary>
        /// Outsorted pallet in line or newly created mock pallet for UI
        /// </summary>
        [DataMember(Name = "OutsortedPallet", Order = 100)]
        public IMaterial OutsortedPallet
        {
            get;
            set;
        }

        /// <summary>
        /// Inserted or created material via scan wizard
        /// </summary>
        [DataMember(Name = "WizardMaterial", Order = 100)]
        public IMaterial WizardMaterial
        {
            get;
            set;
        }

        /// <summary>
        /// Resource configured to resolve CustomDefaultCompletionQuantity
        /// </summary>
        [DataMember(Name = "Resource", Order = 100)]
        public IResource Resource
        {
            get;
            set;
        }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion

    }
}
