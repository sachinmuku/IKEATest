﻿using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    /// Input Data Contract for the CustomDetachMaterialInput service
    /// </summary>
    [DataContract(Name = "CustomDetachMaterialInput")]
    public class CustomDetachMaterialInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// Material to Detach
        /// </summary>
        [DataMember(Name = "Material", Order = 10)]
        public IMaterial Material { get; set; }

        /// <summary>
        /// Resource where the material is dispatched
        /// </summary>
        [DataMember(Name = "Resource", Order = 10)]
        public IResource Resource { get; set; }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
