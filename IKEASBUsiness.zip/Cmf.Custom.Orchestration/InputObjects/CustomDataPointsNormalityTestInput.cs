﻿using Cmf.Foundation.BusinessOrchestration;
using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    [DataContract(Name = "CustomDataPointsNormalityTestInput")]
    public class CustomDataPointsNormalityTestInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// LogicalChart Name to get the Data points from
        /// </summary>
        [DataMember(Name = "LogicalChartName", Order = 100)]
        public string LogicalChartName
        {
            get;
            set;
        }

        /// <summary>
        /// The normality test to be executed
        /// </summary>
        [DataMember(Name = "NormalityTestName", Order = 100)]
        public string NormalityTestName
        {
            get;
            set;
        }

        /// <summary>
        /// Data points IDs to be excluded
        /// </summary>
        [DataMember(Name = "DataPointsIdsToExclude", Order = 100)]
        public List<long> DataPointsIdsToExclude
        {
            get;
            set;
        }

        /// <summary>
        /// The test will check the last N datapoints posted in the Logical Chart
        /// </summary>
        [DataMember(Name = "LastDataPoints", Order = 100)]
        public int? LastDataPoints
        {
            get;
            set;
        }

        /// <summary>
        /// StartDate - The test will check the Data points in a timeframe
        /// </summary>
        [DataMember(Name = "DataPointsStartDate", Order = 100)]
        public DateTime? DataPointsStartDate
        {
            get;
            set;
        }

        /// <summary>
        /// EndDate - The test will check the Data points in a timeframe
        /// </summary>
        [DataMember(Name = "DataPointsEndDate", Order = 100)]
        public DateTime? DataPointsEndDate
        {
            get;
            set;
        }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
