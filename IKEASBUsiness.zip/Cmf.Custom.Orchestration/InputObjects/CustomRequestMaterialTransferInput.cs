﻿using Cmf.Foundation.BusinessObjects.QueryObject;
using Cmf.Foundation.BusinessOrchestration;
using Cmf.Navigo.BusinessObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    /// Input Data Contract for the CustomRequestMaterialTransfer service
    /// </summary>
    [DataContract(Name = "CustomRequestMaterialTransferInput")]
    public class CustomRequestMaterialTransferInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// Source Area where a Material is being transfered from
        /// </summary>
        [DataMember(Name = "FromArea", Order = 100)]
        public string FromArea { get; set; }

        /// <summary>
        /// Source Location where a Material is being transfered from
        /// </summary>
        [DataMember(Name = "FromLocation", Order = 100)]
        public string FromLocation { get; set; }

        /// <summary>
        /// Source Facility where a Material is being transfered from
        /// </summary>
        [DataMember(Name = "FromFacility", Order = 100)]
        public string FromFacility { get; set; }

        /// <summary>
        /// Product to be transfered
        /// </summary>
        [DataMember(Name = "RequiredProduct", Order = 100)]
        public string RequiredProduct { get; set; }

        /// <summary>
        /// Quantity to be transfered
        /// </summary>
        [DataMember(Name = "RequiredQuantity", Order = 100)]
        public decimal? RequiredQuantity { get; set; }

        /// <summary>
        /// Material to be transfered
        /// </summary>
        [DataMember(Name = "RequiredMaterial", Order = 100)]
        public string RequiredMaterial { get; set; }

        /// <summary>
        /// Destination Area where a Material will be transfered to
        /// </summary>
        [DataMember(Name = "ToArea", Order = 100)]
        public string ToArea { get; set; }

        /// <summary>
        /// Destination Location where a Material will be transfered to
        /// </summary>
        [DataMember(Name = "ToLocation", Order = 100)]
        public string ToLocation { get; set; }

        /// <summary>
        /// Destination Facility where a Material will be transfered to
        /// </summary>
        [DataMember(Name = "ToFacility", Order = 100)]
        public string ToFacility { get; set; }

        /// <summary>
        /// Indicates the material request that originated this request
        /// </summary>
        [DataMember(Name = "SourceMaterialRequestId", Order = 100)]
        public long SourceMaterialRequestId { get; set; }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
