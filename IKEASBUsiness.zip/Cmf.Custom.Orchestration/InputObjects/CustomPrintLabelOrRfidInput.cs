﻿using Cmf.Foundation.BusinessOrchestration;
using Cmf.Navigo.BusinessObjects;
using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    /// Input Data Contract for the CustomPrintLabelOrRfidInput service
    /// </summary>
    [DataContract(Name = "CustomPrintLabelOrRfidInput")]
    public class CustomPrintLabelOrRfidInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// <see cref="PrintableDocumentCollection"/> of objects to preview
        /// </summary>
        [DataMember(Name = "PrintableDocuments", Order = 0)]
        public IPrintableDocumentCollection PrintableDocuments { get; set; }

        /// <summary>
        /// The Parameter values to use in Preview calculation
        /// </summary>
        [DataMember(Name = "Parameters", Order = 0)]
        public Dictionary<Int32, Dictionary<String, Object>> Parameters { get; set; }

        /// <summary>
        /// The Entity to use for the AppliesTo parameter.
        /// </summary>
        [DataMember(Name = "Material", Order = 0)]
        public IMaterial Material { get; set; }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
