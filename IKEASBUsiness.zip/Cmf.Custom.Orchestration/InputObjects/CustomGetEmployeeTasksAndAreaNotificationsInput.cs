﻿using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    /// Input Data Contract for the CustomGetEmployeeTasksAndAreaNotificationsInput service
    /// </summary>
    [DataContract(Name = "CustomGetEmployeeTasksAndAreaNotificationsInput")]
    public class CustomGetEmployeeTasksAndAreaNotificationsInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// Employee Entity to CheckIn
        /// </summary>
        [DataMember(Name = "Employee", Order = 1)]
        public IEmployee Employee { get; set; }


        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
