﻿using Cmf.Foundation.BusinessOrchestration;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Cmf.Custom.IKEA.Common.WMS;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    /// Input Data Contract for the CustomWMSManualOrderRequest service
    /// </summary>
    [DataContract(Name = "CustomWMSManualOrderRequestInput")]
    public class CustomWMSManualOrderRequestInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// The resource
        /// </summary>
        [DataMember(Name = "Resource", Order = 0)]
        public IResource Resource { get; set; }

        /// <summary>
        /// The resource, Status, BatchID and PalletID
        /// </summary>
        [DataMember(Name = "ProductMaterialQuantities", Order = 100)]
        public Dictionary<string, Dictionary<string, WMSOrderRequestFields>> ProductMaterialQuantities { get; set; }

        /// <summary>
        /// The resource
        /// </summary>
        [DataMember(Name = "Destinations", Order = 200)]
        public Dictionary<string, string> Destinations { get; set; }
        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
