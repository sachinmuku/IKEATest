﻿
using Cmf.Foundation.BusinessOrchestration;
using Cmf.Navigo.BusinessObjects;
using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
    {

    /// <summary>
    /// Input Data contract to CustomStopMaterial service
    /// </summary>
    [DataContract(Name = "CustomStopMaterialInput")]
    public class CustomStopMaterialInput : BaseInput
        {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// Material to be stopped
        /// </summary>
        [DataMember(Name = "MaterialName", Order = 10)]
        public string MaterialName { get; set; }

        /// <summary>
        /// Stop Reason
        /// </summary>
        [DataMember(Name = "StopReason", Order = 10)]
        public string StopReason { get; set; }

        /// <summary>
        /// IsIOTSource flag to identify if request is comming from Equipment
        /// </summary>
        [DataMember(Name = "IsIOTSource", Order = 10)]
        public bool IsIOTSource { get; set; }

        /// <summary>
        /// IsStopOperation flag that indicates wheather it is a stop operation.
        /// </summary>
        [DataMember(Name = "IsStopOperation", Order = 20)]
        public bool IsStopOperation { get; set; }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
    }
