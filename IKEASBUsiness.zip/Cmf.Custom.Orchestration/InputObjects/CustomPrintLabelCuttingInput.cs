﻿using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    /// Input Data Contract for the CustomPrintLabelCutting service
    /// </summary>
    [DataContract(Name = "CustomPrintLabelCuttingInput")]
    public class CustomPrintLabelCuttingInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// Material Name
        /// </summary>
        [DataMember(Name = "MOName", Order = 10)]
        public string MOName { get; set; }

        /// <summary>
        /// Pallet Name
        /// </summary>
        [DataMember(Name = "PalletName", Order = 10)]
        public string PalletName { get; set; }

        /// <summary>
        /// Product 
        /// </summary>
        [DataMember(Name = "Product", Order = 10)]
        public IProduct Product { get; set; }

        /// <summary>
        /// Quantity
        /// </summary>
        [DataMember(Name = "Quantity", Order = 10)]
        public decimal Quantity { get; set; }

        /// <summary>
        /// Resource (workcenter)
        /// </summary>
        [DataMember(Name = "Resource", Order = 10)]
        public IResource Resource { get; set; }


        /// <summary>
        /// Step 
        /// </summary>
        [DataMember(Name = "Step", Order = 10)]
        public IStep Step { get; set; }

        /// <summary>
        /// PrintableDocument to use
        /// </summary>
        [DataMember(Name = "PrintableDocumentName", Order = 10)]
        public string PrintableDocumentName { get; set; }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
