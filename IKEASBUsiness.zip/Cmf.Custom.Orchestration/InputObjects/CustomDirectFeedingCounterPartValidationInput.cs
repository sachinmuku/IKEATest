﻿using System.Runtime.Serialization;
using Cmf.Foundation.BusinessOrchestration;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    /// Input Data Contract for CustomDirectFeedingCounterPartValidation service.
    /// </summary>
    [DataContract(Name = "CustomDirectFeedingCounterPartValidationInput")]
    public class CustomDirectFeedingCounterPartValidationInput : BaseInput
    {

        [DataMember(Name = "OrderName", Order = 0)]
        public string OrderName { get; set; }

    }
}
