﻿using Cmf.Foundation.BusinessOrchestration;
using Cmf.Navigo.BusinessObjects;
using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    /// CustomGetDataForEPMWithShift Input Object
    /// </summary>
    [DataContract(Name = "CustomGetDataForEPMWithShiftInput")]
    public class CustomGetDataForEPMWithShiftInput : BaseInput 
    {
        #region Properties
        /// <summary>
        /// TimeFrame
        /// </summary>
        [DataMember(Name = "TimeFrame", Order = 0)]
        public TimeFrame TimeFrame { get; set; }

        /// <summary>
        /// GetActual - If yes, it will return the data until the current date, otherwise, get data until yesterday
        /// </summary>
        [DataMember(Name = "GetActual", Order = 0)]
        public Boolean GetActual { get; set; }

        /// <summary>
        /// Resource name list
        /// </summary>
        [DataMember(Name = "Resources", Order = 0)]
        public List<String> Resources { get; set; }

        /// <summary>
        /// ResourceType
        /// </summary>
        [DataMember(Name = "ResourceTypes", Order = 0)]
        public List<String> ResourceTypes { get; set; }

        /// <summary>
        /// ResourceResourceType
        /// </summary>
        [DataMember(Name = "ResourceResourceTypes", Order = 0)]
        public List<String> ResourceResourceTypes { get; set; }

        /// <summary>
        /// ShiftDefinition
        /// </summary>
        [DataMember(Name = "ShiftDefinition", Order = 0)]
        public string ShiftDefinition { get; set; }

        /// <summary>
        /// Shifts
        /// </summary>
        [DataMember(Name = "Shifts", Order = 0)]
        public List<string> Shifts { get; set; }

        /// <summary>
        /// In this dictionary the Key is the name of the column to be returned and the Value is a list of all the fields to be sumed
        /// </summary>
        [DataMember(Name = "StatesMapping", Order = 100)]
        public Dictionary<string, List<string>> StatesMapping
        {
            get;
            set;
        }
        #endregion
    }
}
