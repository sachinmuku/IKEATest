﻿using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    /// Input Data Contract for the CustomGetAutomationVariables service
    /// </summary>
    [DataContract(Name = "CustomGetAutomationVariablesInput")]
    public class CustomGetAutomationVariablesInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties


        /// <summary>
        /// Material Name
        /// </summary>
        [DataMember(Name = "Material", Order = 1)]
        public IMaterial Material
        {
            get;
            set;
        }

        /// <summary>
        /// Resource Name
        /// </summary>
        [DataMember(Name = "Resource", Order = 2)]
        public IResource Resource
        {
            get;
            set;
        }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
