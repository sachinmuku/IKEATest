﻿
using Cmf.Foundation.BusinessOrchestration;
using Cmf.Navigo.BusinessObjects;
using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    /// Input Data for the NiceLabel messages
    /// </summary>
    [DataContract(Name = "CustomNiceLabelMessageInput")]
    public class CustomNiceLabelMessageInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties
        
        /// <summary>
        /// NiceLabel Message - Resource name
        /// </summary>
        [DataMember(Name = "Workcenter", Order = 100)]
        public string Workcenter { get; set; }

        /// <summary>
        /// NiceLabel Message - Material name
        /// </summary>
        [DataMember(Name = "MOID", Order = 200)]
        public string MOID { get; set; }

        /// <summary>
        /// NiceLabel Message - SSCC
        /// </summary>
        [DataMember(Name = "SSCC", Order = 300)]
        public long SSCC { get; set; }

        /// <summary>
        /// NiceLabel Message - PalletID
        /// </summary>
        [DataMember(Name = "PalletID", Order = 400)]
        public string PalletID { get; set; }
        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
