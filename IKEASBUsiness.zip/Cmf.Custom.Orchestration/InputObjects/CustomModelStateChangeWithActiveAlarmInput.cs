﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;
using Cmf.Foundation.BusinessOrchestration;
using DocumentFormat.OpenXml.Wordprocessing;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    /// Input Data Contract for the CustomPostDataToCharts service
    /// </summary>
    [DataContract(Name = "CustomModelStateChangeWithActiveAlarmInput")]
    public class CustomModelStateChangeWithActiveAlarmInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// Resource related to collected data
        /// </summary>
        [DataMember(Name = "Resources", Order = 1)]
        public IEnumerable<string> Resources { get; set; }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
