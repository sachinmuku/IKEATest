﻿using Cmf.Foundation.BusinessOrchestration;
using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;


namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{

    /// <summary>
    /// Input Data Contract for the CustomGetResourceStopStateHistory service
    /// </summary>
    [DataContract(Name = "CustomGetResourceStopStateHistoryInput")]
    public class CustomGetResourceStopStateHistoryInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// Starting date
        /// </summary>
        [DataMember(Name = "FromDate", Order = 100)]
        public DateTime FromDate { get; set; }

        /// <summary>
        /// Ending date
        /// </summary>
        [DataMember(Name = "ToDate", Order = 200)]
        public DateTime ToDate { get; set; }

        /// <summary>
        /// Ignore microstop threshold flag
        /// </summary>
        [DataMember(Name = "IgnoreThreshold", Order = 300)]
        public bool IgnoreThreshold { get; set; }

        /// <summary>
        /// Resource
        /// </summary>
        [DataMember(Name = "Resource", Order = 400)]
        public IResource Resource { get; set; }

        /// <summary>
        /// StateModelStateAttributeFilters
        /// </summary>
        [DataMember(Name = "StateModelStateAttributeFilters", Order = 500)]
        public Dictionary<string, List<string>> StateModelStateAttributeFilters { get; set; }

        /// <summary>
        /// StateModelStateFilters
        /// </summary>
        [DataMember(Name = "StateModelStateFilters", Order = 600)]
        public string StateModelStateFilters { get; set; }

        /// <summary>
        /// StateModelStateReasonAttributeFilters
        /// </summary>
        [DataMember(Name = "StateModelStateReasonFilters", Order = 700)]
        public string StateModelStateReasonFilters { get; set; }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
