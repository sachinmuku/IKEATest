﻿using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    /// Input Data Contract for the CustomChangeDefaultCompletionQuantity service
    /// </summary>
    [DataContract(Name = "CustomChangeDefaultCompletionQuantityInput")]
    public class CustomChangeDefaultCompletionQuantityInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties
        [DataMember(Name = "Material", Order = 0)]
        public IMaterial Material { get; set; }

        [DataMember(Name = "DefaultCompletionQuantity", Order = 1)]
        public decimal DefaultCompletionQuantity { get; set; }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
