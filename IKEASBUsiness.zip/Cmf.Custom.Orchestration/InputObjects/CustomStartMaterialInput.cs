﻿using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    /// Input Data Contract for the CustomStartMaterial service
    /// </summary>
    [DataContract(Name = "CustomStartMaterialInput")]
    public class CustomStartMaterialInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// Material to start
        /// </summary>
        [DataMember(Name = "Material", Order = 100)]
        public IMaterial Material
        {
            get;
            set;
        }

        /// <summary>
        /// Is being invoke by Automation
        /// </summary>
        [DataMember(Name = "IsAutomationInvoke", Order = 100)]
        public bool IsAutomationInvoke
        {
            get;
            set;
        }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
