﻿using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    /// Input Data Contract for the CustomReloadPendingTrackOuts service
    /// </summary>
    [DataContract(Name = "CustomReloadPendingTrackOutsInput")]
    public class CustomReloadPendingTrackOutsInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// The resource associated with the line
        /// </summary>
        [DataMember(Name = "LineResource", Order = 0)]
        public IResource LineResource { get; set; }

        /// <summary>
        /// The selected material to reload pending track-out
        /// </summary>
        [DataMember(Name = "SelectedMaterial", Order = 100)]
        public string? SelectedMaterial { get; set; }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
