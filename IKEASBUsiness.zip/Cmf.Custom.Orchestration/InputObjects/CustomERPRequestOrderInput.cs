﻿using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    [DataContract(Name = "CustomERPRequestOrderInput")]
    public class CustomERPRequestOrderInput : BaseInput
    {

        [DataMember(Name = "Product", Order = 10)]
        public IProduct Product { get; set; }

        [DataMember(Name = "StructureType", Order = 20)]
        public string StructureType { get; set; }

        [DataMember(Name = "Quantity", Order = 30)]
        public decimal Quantity { get; set; }

        [DataMember(Name = "Resource", Order = 40)]
        public IResource Resource { get; set; }

        [DataMember(Name = "ScheduleNumber", Order = 50)]
        public string ScheduleNumber { get; set; }
    }
}
