﻿using Cmf.Foundation.BusinessOrchestration;
using Cmf.Navigo.BusinessObjects;
using DocumentFormat.OpenXml.Wordprocessing;
using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    /// Input data to generate an error Notification
    /// </summary>
    [DataContract(Name = "CustomGenerateErrorNotificationInput")]
    public class CustomGenerateErrorNotificationInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// The topmost Resource name
        /// </summary>
        [DataMember(Name = "ResourceName", Order = 0)]
        public string ResourceName { get; set; }

        /// <summary>
        /// The notification title
        /// </summary>
        [DataMember(Name = "Title", Order = 0)]
        public string Title { get; set; }

        /// <summary>
        /// Error Message to be displayed in the notification
        /// </summary>
        [DataMember(Name = "ErrorMessage", Order = 0)]
        public string ErrorMessage { get; set; }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion
    }
}
