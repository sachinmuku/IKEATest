﻿using Cmf.Foundation.BusinessOrchestration;
using Cmf.Navigo.BusinessObjects;
using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    /// Input Data Contract for the CustomGetResourcesForCheckInInput service
    /// </summary>
    [DataContract(Name = "CustomGetChartCurrentShiftLimitsInput")]
    public class CustomGetChartCurrentShiftLimitsInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties
        [DataMember(Name = "LogicalChartName", Order = 0)]
        public string LogicalChartName { get; set; }
        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
