﻿
using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    /// Input Data Contract for the CustomLoadResourceLogicalChart service
    /// </summary>
    [DataContract(Name = "CustomLoadResourceLogicalChartInput")]
    public class CustomLoadResourceLogicalChartInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// Parameter
        /// </summary>
        [DataMember(Name = "Material", Order = 1)]
        public IMaterial Material { get; set; }

        /// <summary>
        /// Resource
        /// </summary>
        [DataMember(Name = "Resource", Order = 10)]
        public IResource Resource { get; set; }

        /// <summary>
        /// Product
        /// </summary>
        [DataMember(Name = "Product", Order = 20)]
        public IProduct Product { get; set; }

        /// <summary>
        /// ProductGroup
        /// </summary>
        [DataMember(Name = "ProductGroup", Order = 30)]
        public IProductGroup ProductGroup { get; set; }

        /// <summary>
        /// ChartType
        /// </summary>
        [DataMember(Name = "ChartType", Order = 40)]
        public string ChartType { get; set; }

        /// <summary>
        /// Parameter
        /// </summary>
        [DataMember(Name = "Parameter", Order = 50)]
        public IParameter Parameter { get; set; }



        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
