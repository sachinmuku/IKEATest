﻿using Cmf.Custom.IKEA.Orchestration.DataStructures;
using Cmf.Foundation.BusinessOrchestration;
using Cmf.Foundation.Security;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    /// Input Data Contract for the CustomOutsourtedPalletizeInput service
    /// </summary>
    [DataContract(Name = "CustomOutsourtedPalletizeInput")]
    public class CustomOutsourtedPalletizeInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// Materials To Palletize
        /// </summary>
        [DataMember(Name = "MaterialsToPalletize", Order = 100)]
        public OutsortedMaterialPalletizeCollection MaterialsToPalletize
        {
            get;
            set;
        }

        /// <summary>
        /// Return Flow Path after palletize the outsorted materails
        /// </summary>
        [DataMember(Name = "ReturnFlowPath", Order = 100)]
        public string ReturnFlowPath
        {
            get;
            set;
        }

        /// <summary>
        /// Return Flow after palletize the outsorted materails
        /// </summary>
        [DataMember(Name = "ReturnFlow", Order = 100)]
        public IFlow ReturnFlow
        {
            get;
            set;
        }

        /// <summary>
        /// Return Step after palletize the outsorted materails
        /// </summary>
        [DataMember(Name = "ReturnStep", Order = 100)]
        public IStep ReturnStep
        {
            get;
            set;
        }   
        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
