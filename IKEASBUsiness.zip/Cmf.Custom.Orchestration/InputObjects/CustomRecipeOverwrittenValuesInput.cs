﻿using System.Runtime.Serialization;
using Cmf.Foundation.BusinessOrchestration;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    /// Input Data Contract for the CustomRecipeOverwrittenValues service
    /// </summary>
    [DataContract(Name = "CustomRecipeOverwrittenValuesInput")]
    public class CustomRecipeOverwrittenValuesInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties
        [DataMember(Name = "Recipe", Order = 0)]
        public IRecipe Recipe { get; set; }

        [DataMember(Name = "Material", Order = 1)]
        public IMaterial Material { get; set; }
        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
