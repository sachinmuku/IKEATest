﻿using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;
using Cmf.Foundation.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    /// Input Data Contract for the CustomGetRunningMOs service
    /// </summary>
    [DataContract(Name = "CustomGetRunningMOsInput")]
    public class CustomGetRunningMOsInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// Facility where to search for the running materials. Filters property takes precedence over this
        /// </summary>
        [DataMember(Name = "FacilityName", Order = 100)]
        public string FacilityName { get; set; }

        /// <summary>
        /// Area where to search for the running materials. Filters property takes precedence over this
        /// </summary>
        [DataMember(Name = "AreaName", Order = 100)]
        public string AreaName { get; set; }

        /// <summary>
        /// Resource where to search for the running materials. Filters property takes precedence over this
        /// </summary>
        [DataMember(Name = "ResourceName", Order = 100)]
        public string ResourceName { get; set; }

        /// <summary>
        /// Filter collection to be applied. if not defined other property filters are used
        /// </summary>
        [DataMember(Name = "Filters", Order = 10)]
        public IFilterCollection Filters { get; set; }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
