﻿using Cmf.Foundation.BusinessOrchestration;
using Cmf.Navigo.BusinessObjects;
using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    /// CustomGetDataForOEEInput Input Object
    /// </summary>
    [DataContract(Name = "CustomGetDataForOEEInput")]
    public class CustomGetDataForOEEInput : BaseInput
    {
        #region Properties
        /// <summary>
        /// TimeFrame
        /// </summary>
        [DataMember(Name = "TimeFrame", Order = 0)]
        public TimeFrame TimeFrame { get; set; }

        /// <summary>
        /// GetActual - If yes, it will return the data until the current date, otherwise, get data until yesterday
        /// </summary>
        [DataMember(Name = "GetActual", Order = 0)]
        public Boolean GetActual { get; set; }

        /// <summary>
        /// FacilityName
        /// </summary>
        [DataMember(Name = "FacilityName", Order = 0)]
        public String FacilityName { get; set; }

        /// <summary>
        /// AreaName
        /// </summary>
        [DataMember(Name = "AreaName", Order = 0)]
        public String AreaName { get; set; }

        /// <summary>
        /// Resources
        /// </summary>
        [DataMember(Name = "Resources", Order = 0)]
        public List<String> Resources { get; set; }

        /// <summary>
        /// ResourceType
        /// </summary>
        [DataMember(Name = "ResourceTypes", Order = 0)]
        public List<String> ResourceTypes { get; set; }

        /// <summary>
        /// ResourceResourceType
        /// </summary>
        [DataMember(Name = "ResourceResourceTypes", Order = 0)]
        public List<String> ResourceResourceTypes { get; set; }

        /// <summary>
        /// ShiftDefinition
        /// </summary>
        [DataMember(Name = "ShiftDefinition", Order = 0)]
        public string ShiftDefinition { get; set; }

        /// <summary>
        /// Shifts
        /// </summary>
        [DataMember(Name = "Shifts", Order = 0)]
        public List<string> Shifts { get; set; }
        #endregion
    }
}
