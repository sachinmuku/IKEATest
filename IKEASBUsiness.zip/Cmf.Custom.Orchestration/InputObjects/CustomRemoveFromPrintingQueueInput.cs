﻿using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    /// Input Data Contract for the CustomRemoveFromPrintingQueue service
    /// </summary>
    [DataContract(Name = "CustomRemoveFromPrintingQueueInput")]
    public class CustomRemoveFromPrintingQueueInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// The resource associated with the line
        /// </summary>
        [DataMember(Name = "LineResource", Order = 0)]
        public IResource LineResource { get; set; }

        /// <summary>
        /// Optional expected material to be removed from the queue. If any other material is the last one, then throw an error
        /// </summary>
        [DataMember(Name = "ExpectedPalletMaterial", Order = 1)]
        public IMaterial ExpectedPalletMaterial { get; set; }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
