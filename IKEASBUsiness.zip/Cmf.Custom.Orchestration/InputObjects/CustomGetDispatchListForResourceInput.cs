﻿using Cmf.Foundation.BusinessOrchestration;
using Cmf.Navigo.BusinessOrchestration.DispatchManagement.InputObjects;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    /// CustomGetDispatchListForResourceInput Input Object
    /// </summary>
    [DataContract(Name = "CustomGetDispatchListForResource")]
    public class CustomGetDispatchListForResourceInput : BaseInput
    {
        [DataMember(Name = "Input", Order = 0)]
        public GetDispatchListForResourceInput Input { get; set; }

        [DataMember(Name = "Filters", Order = 1)]
        public Dictionary<string, object> Filters { get; set; }
    }
}
