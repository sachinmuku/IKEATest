﻿using Cmf.Foundation.BusinessOrchestration;
using Cmf.Navigo.BusinessObjects;
using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    /// Input Data Contract for the CustomUpdateInterlockStatus service
    /// </summary>
    [DataContract(Name = "CustomUpdateInterlockStatusInput")]
    public class CustomUpdateInterlockStatusInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// Resource for setting interlock status
        /// </summary>
        [DataMember(Name = "ResourceId", Order = 100)]
        public string ResourceId
        {
            get;
            set;
        }

        /// <summary>
        /// Material for setting interlock status
        /// </summary>
        [DataMember(Name = "MaterialName", Order = 101)]
        public string MaterialName
        {
            get;
            set;
        }

        /// <summary>
        /// Interlock Status to be set on resource
        /// </summary>
        [DataMember(Name = "InterlockStatus", Order = 100)]
        public string InterlockStatus
        {
            get;
            set;
        }

        /// <summary>
        /// ResponseCode for IOT to inform if an warning/error occurred
        /// </summary>
        [DataMember(Name = "ResponseCode", Order = 100)]
        public string ResponseCode
        {
            get;
            set;
        }

        /// <summary>
        /// ResponseMessage for IOT to inform the message of warning/error that occurred
        /// </summary>
        [DataMember(Name = "ResponseMessage", Order = 100)]
        public string ResponseMessage
        {
            get;
            set;
        }

        /// <summary>
        /// When true, will activate the attribute "PalletizeErrorHandleEnabled" on the resource
        /// </summary>
        [DataMember(Name = "EnableErrorHandler", Order = 100)]
        public bool EnableErrorHandler
        {
            get;
            set;
        }


        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
