﻿using Cmf.Foundation.BusinessOrchestration;
using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    /// Input Data Contract for the CustomUnitCompleteInput service
    /// </summary>
    [DataContract(Name = "CustomUnitCompleteInput")]
    public class CustomUnitCompleteInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// Material from where the completed tracking unit is being generated
        /// </summary>
        [DataMember(Name = "ProcessOrderMaterial", Order = 10)]
        public IMaterial ProcessOrderMaterial { get; set; }

        /// <summary>
        /// Total completed primary quantity
        /// </summary>
        [DataMember(Name = "CompletedPrimaryQuantity", Order = 10)]
        public Decimal? CompletedPrimaryQuantity { get; set; }

        /// <summary>
        /// Total completed secondary quantity
        /// </summary>
        [DataMember(Name = "CompletedSecondaryQuantity", Order = 10)]
        public Decimal? CompletedSecondaryQuantity { get; set; }

        /// <summary>
        /// Indicates if TrackOut of the completed unit should be ignored
        /// </summary>
        [DataMember(Name = "ExcludeTrackout", Order = 10)]
        public Boolean ExcludeTrackout { get; set; }

        /// <summary>
        /// Indicates if validation that source order material must be in process should be skipped.
        /// </summary>
        [DataMember(Name = "IgnoreOrderMaterialState", Order = 10)]
        public Boolean IgnoreOrderMaterialState { get; set; }

        /// <summary>
        /// Indicates the type of the tracking unit being completed.
        /// </summary>
        [DataMember(Name = "CompletedUnitType", Order = 10)]
        public String CompletedUnitType { get; set; }

        /// <summary>
        /// Indicates if the request is coming from automation or GUI
        /// </summary>
        [DataMember(Name = "IsAutomationInvoke", Order = 10)]
        public Boolean IsAutomationInvoke { get; set; }

        /// <summary>
        /// Indicates if the request is a process loss
        /// </summary>
        [DataMember(Name = "IsProcessLoss", Order = 10)]
        public Boolean IsProcessLoss { get; set; }

        /// <summary>
        /// Indicates the materials to be consumed at track out
        /// NOTE: If contains values, it will use them instead of the ones in the feeders
        /// </summary>
        [DataMember(Name = "MaterialsToConsume", Order = 10)]
        public Dictionary<IResource, List<IMaterial>> MaterialsToConsume { get; set; }

        /// <summary>
        /// Resource to use for palletize
        /// </summary>
        [DataMember(Name = "PalletizeResource", Order = 100)]
        public IResource PalletizeResource { get; set; }


        /// <summary>
        /// Optional attributes to set in the newly-generated unit material
        /// </summary>
        [DataMember(Name = "UnitAttributes", Order = 100)]
        public IAttributeCollection UnitAttributes { get; set; }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
