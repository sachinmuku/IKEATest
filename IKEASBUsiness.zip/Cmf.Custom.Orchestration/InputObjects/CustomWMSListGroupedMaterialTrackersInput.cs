﻿
using Cmf.Foundation.BusinessOrchestration;
using System;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Custom.IKEA.Common.Enums;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    /// Input Data Contract for the CustomWMSListGroupedMaterialTrackers service
    /// </summary>
    [DataContract(Name = "CustomWMSListGroupedMaterialTrackersInput")]
    public class CustomWMSListGroupedMaterialTrackersInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// IOType
        /// </summary>
        [DataMember(Name = "IOType", Order = 0)]
        public CustomWMSOrderRequestType IOType { get; set; }

        /// <summary>
        /// MainLine
        /// </summary>
        [DataMember(Name = "MainLine", Order = 1)]
        public IResource MainLine { get; set; }


        /// <summary>
        /// ManufacturingOrderFilter
        /// </summary>
        [DataMember(Name = "ManufacturingOrderFilter", Order = 2)]
        public IMaterial ManufacturingOrderFilter { get; set; }

        /// <summary>
        /// DestinationResourceFilter
        /// </summary>
        [DataMember(Name = "DestinationResourceFilter", Order = 3)]
        public IResource DestinationResourceFilter { get; set; }

        /// <summary>
        /// ProductFilter
        /// </summary>
        [DataMember(Name = "ProductFilter", Order = 4)]
        public IProduct ProductFilter { get; set; }

        /// <summary>
        /// StartDateFilter
        /// </summary>
        [DataMember(Name = "StartDateFilter", Order = 5)]
        public DateTime? StartDateFilter { get; set; }

        /// <summary>
        /// EndDateFilter
        /// </summary>
        [DataMember(Name = "EndDateFilter", Order = 6)]
        public DateTime? EndDateFilter { get; set; }

        /// <summary>
        /// ProductGrouping
        /// </summary>
        [DataMember(Name = "ProductGrouping", Order = 7)]
        public bool ProductGrouping { get; set; }

        /// <summary>
        /// ManufacturingOrderGrouping
        /// </summary>
        [DataMember(Name = "ManufacturingOrderGrouping", Order = 8)]
        public bool ManufacturingOrderGrouping { get; set; }

        /// <summary>
        /// DestinationResourceGrouping
        /// </summary>
        [DataMember(Name = "DestinationResourceGrouping", Order = 9)]
        public bool DestinationResourceGrouping { get; set; }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
