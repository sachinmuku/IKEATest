﻿using Cmf.Custom.IKEA.BusinessObjects;
using Cmf.Foundation.BusinessOrchestration;
using Cmf.Navigo.BusinessObjects;
using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    /// Input Data Contract for the CustomAttachDurable service
    /// </summary>
    [DataContract(Name = "CustomAttachDurableInput")]
    public class CustomAttachDurableInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties
        [DataMember(Name = "Material", Order = 0)]
        public string Material { get; set; }

        [DataMember(Name = "Product", Order = 1)]
        public string Product { get; set; }

        [DataMember(Name = "Quantity", Order = 2)]
        public decimal Quantity { get; set; }

        [DataMember(Name = "Resource", Order = 3)]
        public string Resource { get; set; }

        /// <summary>
        /// Used for the Expiration Date
        /// </summary>
        [DataMember(Name = "MaterialExpirationDate", Order = 4)]
        public DateTime? MaterialExpirationDate
        {
            get;
            set;
        }

		[DataMember(Name = "Position", Order = 5)]
		public int Position { get; set; }

		#endregion

		#region Constructors
		#endregion

		#region Private & Internal Methods
		#endregion

		#region Public Methods
		#endregion

		#region Event handling Methods
		#endregion
	}
}
