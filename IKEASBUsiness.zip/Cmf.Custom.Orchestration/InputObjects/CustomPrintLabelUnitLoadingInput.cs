﻿using Cmf.Custom.IKEA.Common;
using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Custom.IKEA.Common.DataStructures;

namespace Cmf.Custom.IKEA.Orchestration.InputObjects
{
    /// <summary>
    /// Input Data Contract for the CustomPrintLabelUnitLoading service
    /// </summary>
    [DataContract(Name = "CustomPrintLabelUnitLoadingInput")]
    public class CustomPrintLabelUnitLoadingInput : BaseInput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties
        [DataMember(Name = "MainLineResource", Order = 0)]
        public IResource MainLineResource { get; set; }

        [DataMember(Name = "PrintableDocument", Order = 1)]
        public IPrintableDocument PrintableDocument { get; set; }

        [DataMember(Name = "PrinterCode", Order = 2)]
        public int PrinterCode { get; set; }

        [DataMember(Name = "FactoryCode", Order = 3)]
        public int FactoryCode { get; set; }

        [DataMember(Name = "LabelFields", Order = 4)]
        public UllLabelFields LabelFields { get; set; }
        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
