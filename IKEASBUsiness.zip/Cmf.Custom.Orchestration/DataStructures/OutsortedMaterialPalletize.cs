﻿using System.Collections.Generic;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.DataStructures
{
    /// <summary>
    /// Class representing the Reason and quantity per reason when palletizing in the Outsorted Cockpit
    /// </summary>
    [DataContract(Namespace = "", IsReference = true, Name = "OutsortedMaterialPalletize")]
    public class OutsortedMaterialPalletize
    {
        /// <summary>
        /// Original Material
        /// </summary>
        [DataMember(Name = "Material", Order = 10)]
        public IMaterial Material
        {
            get;
            set;
        }

        /// <summary>
        /// Dictionary containing the MaterialType and the loss reason with the quantity
        /// </summary>
        [DataMember(Name = "MaterialTypeQuantity", Order = 10)]
        public Dictionary<string, OutsortedMaterialTypeQuantityCollection> MaterialTypeQuantity
        {
            get;
            set;
        }

    }
}
