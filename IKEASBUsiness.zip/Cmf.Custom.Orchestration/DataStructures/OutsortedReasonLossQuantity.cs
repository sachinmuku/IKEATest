﻿using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Orchestration.DataStructures
{
    /// <summary>
    /// Input Data Contract for the OutsortedReasonLossQuantity service
    /// </summary>
    [DataContract(Name = "OutsortedReasonLossQuantity")]
    class OutsortedReasonLossQuantity
    {
        /// <summary>
        /// ID of the Entity 
        /// </summary>
        [DataMember(Name = "ReasonLossQuantity", Order = 1)]
        public Dictionary<string, int> ReasonLossQuantity { get; set; }
    }
}
