﻿using Cmf.Navigo.BusinessObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Orchestration.DataStructures
{
    /// <summary>
    /// Location of a Material of type Pallet in the System
    /// </summary>
    [DataContract(Namespace = "", IsReference = true, Name = "PalletLocation")]
    public class PalletLocation
    {
        /// <summary>
        /// Gets or sets Material
        /// </summary>
        [DataMember(Name = "Material", Order = 0)]
        public SimplifiedMESEntity Material
        {
            get;

            set;
        }

        /// <summary>
        /// Gets or sets LastProcessedResource
        /// </summary>
        [DataMember(Name = "LastProcessedResource", Order = 1)]
        public SimplifiedMESEntity LastProcessedResource
        {
            get;

            set;
        }

        /// <summary>
        /// Gets or sets Resource
        /// </summary>
        [DataMember(Name = "Resource", Order = 2)]
        public SimplifiedMESEntity Resource
        {
            get;

            set;
        }

        /// <summary>
        /// Gets or sets Product
        /// </summary>
        [DataMember(Name = "Product", Order = 3)]
        public SimplifiedMESEntity Product
        {
            get;

            set;
        }

        /// <summary>
        /// Gets or sets Facility
        /// </summary>
        [DataMember(Name = "Facility", Order = 4)]
        public SimplifiedMESEntity Facility
        {
            get;

            set;
        }

        /// <summary>
        /// Gets or sets Area
        /// </summary>
        [DataMember(Name = "Area", Order = 5)]
        public SimplifiedMESEntity Area
        {
            get;

            set;
        }

        /// <summary>
        /// Gets or sets PrimaryQuantity
        /// </summary>
        [DataMember(Name = "PrimaryQuantity", Order = 6)]
        public string PrimaryQuantity
        {
            get;

            set;
        }

        /// <summary>
        /// Gets or sets SecondaryQuantity
        /// </summary>
        [DataMember(Name = "SecondaryQuantity", Order = 7)]
        public string SecondaryQuantity
        {
            get;

            set;
        }

        /// <summary>
        /// Gets or sets Type
        /// </summary>
        [DataMember(Name = "Type", Order = 8)]
        public string Type
        {
            get;

            set;
        }

        /// <summary>
        /// Gets or sets Type
        /// </summary>
        [DataMember(Name = "MaterialTypeColor", Order = 9)]
        public string MaterialTypeColor
        {
            get;

            set;
        }
    }
}
