﻿using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Orchestration.DataStructures
{
    /// <summary>
    /// Class to Send compact Information from services to GUI
    /// </summary>
    [DataContract(Namespace = "", IsReference = true, Name = "SimplifiedMESEntity")]
    public class SimplifiedMESEntity
    {
        /// <summary>
        /// ID of the Entity 
        /// </summary>
        [DataMember(Name = "Id", Order = 0)]
        public long Id { get; set; }
        /// <summary>
        /// Name of the Entity 
        /// </summary>
        [DataMember(Name = "Name", Order = 0)]
        public string Name { get; set; }
    }
}