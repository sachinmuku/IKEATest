﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using Cmf.Navigo.BusinessObjects;

namespace Cmf.Custom.IKEA.Orchestration.DataStructures
{
    /// <summary>
    /// Class representing the Reason and quantity per reason when palletizing in the Outsorted Cockpit
    /// </summary>
    [DataContract(Namespace = "", IsReference = true, Name = "OutsortedMaterialTypeQuantity")]
    public class OutsortedMaterialTypeQuantity
    {
        /// <summary>
        /// Reason
        /// </summary>
        [DataMember(Name = "Reason", Order = 10)]
        public string Reason
        {
            get;
            set;
        }

        /// <summary>
        /// Quantity per Reason
        /// </summary>
        [DataMember(Name = "Quantity", Order = 10)]
        public decimal Quantity
        {
            get;
            set;
        }
    }
}