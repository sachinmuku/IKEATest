﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace Cmf.Custom.IKEA.Orchestration.DataStructures
{

    /// <summary>
    /// Location of a Material of type Pallet in the System
    /// </summary>
    [DataContract(Namespace = "", IsReference = true, Name = "ResourceAlternativeCycleTime")]
    public class ResourceAlternativeCycleTime
    {
        /// <summary>
        /// The value of the Row Id
        /// </summary>
        [DataMember(Name = "Id", Order = 0)]
        public long Id { get; set; }

        /// <summary>
        /// The value of the TimeScale column
        /// </summary>
        [DataMember(Name = "TimeScaleValue", Order = 1)]
        public string TimeScaleValue { get; set; }


        /// <summary>
        /// The value of the TimePerUnit column
        /// </summary>
        [DataMember(Name = "TimePerUnitValue", Order = 2)]
        public decimal TimePerUnitValue { get; set; }

    }
}
