﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Orchestration.DataStructures
{
        /// <summary>
        /// Output Object PalletLocationCollection
        /// </summary>
        /// <seealso cref="Collection{PalletLocation}" />
        [CollectionDataContract(Namespace = "", IsReference = true, Name = "PalletLocationCollection", ItemName = "PalletLocation")]
        public class PalletLocationCollection : Collection<PalletLocation>
        {

        }
}
