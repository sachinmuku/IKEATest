﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Orchestration.DataStructures
{
    /// <summary>
    /// Output Object OutsortedMaterialTypeQuantityCollection
    /// </summary>
    /// <seealso cref="Collection{OutsortedMaterialTypeQuantityCollection}" />
    [CollectionDataContract(Namespace = "", IsReference = true, Name = "OutsortedMaterialTypeQuantityCollection", ItemName = "OutsortedMaterialTypeQuantity")]
    public class OutsortedMaterialTypeQuantityCollection : Collection<OutsortedMaterialTypeQuantity>
    {

    }
}
