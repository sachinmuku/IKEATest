﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Orchestration.DataStructures
{

    /// <summary>
    /// Output object OutsortedMaterialPalletizeCollection
    /// </summary>
    /// <seealso cref="Collection{CustomSetupConsumptionDetail}"/>
    [CollectionDataContract(Namespace = "", IsReference = true, Name = "OutsortedMaterialPalletizeCollection", ItemName = "OutsortedMaterialPalletize")]
    public class OutsortedMaterialPalletizeCollection : Collection<OutsortedMaterialPalletize>
    {
    }
}
