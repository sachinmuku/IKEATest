﻿using Cmf.Custom.IKEA.Orchestration.InputObjects;
using Cmf.Custom.IKEA.Orchestration.OutputObjects;
using Cmf.Foundation.Common;

namespace Cmf.Custom.IKEA.Orchestration.Abstractions
{
    /// <summary>
    /// IKEA Core Orchestration Methods
    /// </summary>
    public interface IIKEABusinessManagementOrchestration
    {
        /// <summary>
        /// Completes or aborts a Material on a resource
        /// </summary>
        /// <param name="customStopMaterialInput">Input Object</param>
        /// <returns></returns>
        CustomStopMaterialOutput CustomStopMaterial(CustomStopMaterialInput customStopMaterialInput);

        /// <summary>
        /// Indicates the completion of a tracking unit at the exit of the production line
        /// </summary>
        /// <param name="customUnitCompleteOutput">Input Object</param>
        /// <returns></returns>
        CustomUnitCompleteOutput CustomUnitComplete(CustomUnitCompleteInput customUnitCompleteInput);

        /// <summary>
        /// Service that will be call to start a material
        /// </summary>
        /// <param name="CustomStartMaterialInput">Input Object</param>
        /// <returns>Output Objects</returns>
        CustomStartMaterialOutput CustomStartMaterial(CustomStartMaterialInput customStartMaterialInput);

        /// <summary>
        /// Receives the message from the ION and creates a new integration entry
        /// </summary>
        /// <param name="ikeaIonMessageInput">Input Object</param>
        /// <returns></returns>
        IKEAAcknowledgeIonMessageOutput IKEAAcknowledgeIonMessage(IKEAAcknowledgeIonMessageInput ikeaIonMessageInput);

        /// <summary>
        /// Service to retrieve possible feeders and consumers of a Material
        /// </summary>
        /// <param name="customGetMOFutureConsumptionInformationInput">Input Object</param>
        /// <returns>Output Objects</returns>
        CustomGetMOFutureConsumptionInformationOutput CustomGetMOFutureConsumptionInformation(CustomGetMOFutureConsumptionInformationInput customGetMOFutureConsumptionInformationInput);

        /// <summary>
        /// Service to postpone materials
        /// </summary>
        /// <param name="customPostponeMaterialInput">Input Object</param>
        /// <returns></returns>
        CustomPostponeMaterialOutput CustomPostponeMaterial(CustomPostponeMaterialInput customPostponeMaterialInput);

        /// <summary>
        /// Service to print label or rfid
        /// </summary>
        /// <param name="customPrintLabelOrRfidInput">Input Object</param>
        /// <returns>Output Objects</returns>
        CustomPrintLabelOrRfidOutput CustomPrintLabelOrRfid(CustomPrintLabelOrRfidInput customPrintLabelOrRfidInput);

        /// <summary>
        /// Service to report the consumption of a material
        /// </summary>
        /// <param name="customMaterialConsumptionReportInput">Input Object</param>
        /// <returns>Output Objects</returns>
        CustomMaterialConsumptionReportOutput CustomMaterialConsumptionReport(CustomMaterialConsumptionReportInput customMaterialConsumptionReportInput);

        /// <summary>
        /// Service to receive a message from a barcode reader and attach the Material received in the message
        /// </summary>
        /// <param name="customScanInMaterialInput"></param>
        /// <returns>Output Object</returns>
        CustomScanInMaterialOutput CustomScanInMaterial(CustomScanInMaterialInput customScanInMaterialInput);

        /// <summary>
        /// Service to retrieve the BOM Information
        /// </summary>
        /// <param name="customGetDataForBOMInformationInput"></param>
        /// <returns>Output Object</returns>
        CustomGetDataForBOMInformationOutput CustomGetDataForBOMInformation(CustomGetDataForBOMInformationInput input);

        /// <summary>
        /// Service to receive a filterCollection ad retrieve filtered results for Last Pallet Location Page
        /// </summary>
        /// <param name="CustomGetDataForPalletLocationInput"></param>
        /// <returns>Output Object</returns>
        CustomGetDataForPalletLocationOutput CustomGetDataForPalletLocation(CustomGetDataForPalletLocationInput customGetDataForPalletLocationInput);

        /// <summary>
        /// Service to retrieve a list of Running MOs
        /// </summary>
        /// <param name="customGetRunningMOsInput">Input Object</param>
        /// <returns>Output Objects</returns>
        CustomGetRunningMOsOutput CustomGetRunningMOs(CustomGetRunningMOsInput customGetRunningMOsInput);

        /// <summary>
        /// Service that will log or notify equipment alarms
        /// </summary>
        /// <param name="CustomLogAlarmOccurrenceInput">Input Object</param>
        /// <returns>Output Objects</returns>
        CustomLogAlarmOccurrenceOutput CustomLogAlarmOccurrence(CustomLogAlarmOccurrenceInput customLogAlarmOccurrenceInput);

        /// <summary>
        /// Service to return time per state data
        /// </summary>
        /// <param name="input">Input Object</param>
        /// <returns>Output Object</returns>
        CustomGetDataForEPMOutput CustomGetDataForEPM(CustomGetDataForEPMInput input);

        /// <summary>
        /// Service that will test MES > ERP communication
        /// </summary>
        /// <param name="customERPCommunicationTestInput">Input Object</param>
        /// <returns>Output Objects</returns>
        CustomERPCommunicationTestOutput CustomERPCommunicationTest(CustomERPCommunicationTestInput customERPCommunicationTestInput);

        /// <summary>
        /// Retrieve the setup state for a selected material
        /// </summary>
        /// <param name="customGetMaterialSetupStateInput">Input Object</param>
        /// <returns>Output Objects</returns>
        CustomGetMaterialSetupStateOutput CustomGetMaterialSetupState(CustomGetMaterialSetupStateInput customGetMaterialSetupStateInput);

        /// <summary>
        /// Update the BomProduct relation attributes
        /// </summary>
        /// <param name="customUpdateBomProductsAttributesInput">Input Object</param>
        /// <returns>Output Objects</returns>
        CustomUpdateBomProductsAttributesOutput CustomUpdateBomProductsAttributes(CustomUpdateBomProductsAttributesInput customUpdateBomProductsAttributesInput);

        /// <summary>
        /// Transfer the material to the given resource.
        ///     If resource is of type storage, stores material.
        ///     If resource is of type consumable feed, attaches it to the consumable feed.
        /// </summary>
        /// <param name="CustomLogMaterialMovementInput">Input Object</param>
        /// <returns>Output Objects</returns>
        CustomLogMaterialMovementOutput CustomLogMaterialMovement(CustomLogMaterialMovementInput customLogMaterialMovementInput);

        /// <summary>
        /// Creates a Notification to request a Material Transfer
        /// </summary>
        /// <param name="customRequestMaterialTransferInput"></param>
        /// <returns></returns>
        CustomRequestMaterialTransferOutput CustomRequestMaterialTransfer(CustomRequestMaterialTransferInput customRequestMaterialTransferInput);

        /// <summary>
        /// /// Service to scan a barcode and return list of parsed extracted values
        /// </summary>
        /// <param name="customParseReadingInput"></param>
        /// <returns></returns>
        CustomParseReadingOutput CustomParseReading(CustomParseReadingInput customParseReadingInput);

        /// <summary>
        /// Get all available forklift resources dor check in
        /// </summary>
        /// <param name="customGetResourcesForCheckInInput">Input Object</param>
        /// <returns>Output Objects</returns>
        CustomGetResourcesForCheckInOutput CustomGetResourcesForCheckIn(CustomGetResourcesForCheckInInput customGetResourcesForCheckInInput);

        /// <summary>
        /// Gets the Employee Tasks and area notifications
        /// </summary>
        /// <param name="customGetEmployeeTasksAndAreaNotificationsInput">Input Object</param>
        /// <returns>Output Objects</returns>
        CustomGetEmployeeTasksAndAreaNotificationsOutput CustomGetEmployeeTasksAndAreaNotifications(CustomGetEmployeeTasksAndAreaNotificationsInput customGetEmployeeTasksAndAreaNotificationsInput);

        /// <summary>
        /// Service for Canceling or Complete all tasks in a collection
        /// </summary>
        /// <param name="customTaskCompleteAndCancelInput"></param>
        /// <returns></returns>
        CustomTaskCompleteAndCancelOutput CustomTaskCompleteAndCancel(CustomTaskCompleteAndCancelInput customTaskCompleteAndCancelInput);

        /// <summary>
        /// Service for changing the state of a material
        /// </summary>
        /// <param name="CustomSetMaterialState"></param>
        /// <returns></returns>
        CustomSetMaterialStateOutput CustomSetMaterialState(CustomSetMaterialStateInput customSetMaterialStateInput);

        /// <summary>
        /// Service for Label printing in Cutting area
        /// </summary>
        /// <param name="customPrintLabelCuttingInput">Input Object</param>
        /// <returns>Output Objects</returns>
        CustomPrintLabelCuttingOutput CustomPrintLabelCutting(CustomPrintLabelCuttingInput customPrintLabelCuttingInput);

        /// <summary>
        /// Service for clearing Material interlock admission
        /// </summary>
        /// <param name="customClearMaterialAdmissionInterlockInput">Input Object</param>
        /// <returns></returns>
        CustomClearMaterialAdmissionInterlockOutput CustomClearMaterialAdmissionInterlock(CustomClearMaterialAdmissionInterlockInput customClearMaterialAdmissionInterlockInput);

        /// <summary>
        /// Service for updating interlock admission
        /// </summary>
        /// <param name="customUpdateInterlockStatusInput">Input Object</param>
        /// <returns></returns>
        CustomUpdateInterlockStatusOutput CustomUpdateInterlockStatus(CustomUpdateInterlockStatusInput customUpdateInterlockStatusInput);

        /// <summary>
        /// Service to retrieve a the resource state history
        /// </summary>
        /// <param name="customGetResourceStateHistoryInput">Input Object</param>
        /// <returns>Output Objects</returns>
        CustomGetResourceStateHistoryOutput CustomGetResourceStateHistory(CustomGetResourceStateHistoryInput customGetResourceStateHistoryInput);

        /// <summary>
        /// Service to save the resource state reclassifications
        /// </summary>
        /// <param name="input">Input Object</param>
        /// <returns>Output Objects</returns>
        CustomSaveResourceStateReclassificationOutput CustomSaveResourceStateReclassification(CustomSaveResourceStateReclassificationInput input);

        /// <summary>
        /// Posts data points to one or more charts
        /// </summary>
        /// <param name="customPostDataToChartsInput">Input Object</param>
        /// <returns></returns>
        CustomPostDataToChartsOutput CustomPostDataToCharts(CustomPostDataToChartsInput customPostDataToChartsInput);

        /// <summary>
        /// Service to get the outsorted quantity of a Material attach to a resource from EI
        /// </summary>
        /// <param name="input">CustomGetOutsortedUnitsInformationInput</param>
        /// <returns>CustomGetOutsortedUnitsInformationOutput</returns>
        /// <exception cref="Cmf.Foundation.Common.CmfBaseException">If any unexpected error occurs.</exception>
        CustomGetOutsortedUnitsInformationOutput CustomGetOutsortedUnitsInformation(CustomGetOutsortedUnitsInformationInput input);

        /// <summary>
        /// Custom Get Data For PPM
        /// </summary>
        /// <param name="input">CustomGetDataForPPM Input</param>
        /// <returns>CustomGetDataForPPM Output</returns>
        /// <exception cref="Cmf.Foundation.Common.CmfBaseException">If any unexpected error occurs.</exception>
        CustomGetDataForPPMOutput CustomGetDataForPPM(CustomGetDataForPPMInput input);

        /// <summary>
        /// Forces the Unit Completion of a MO
        /// </summary>
        /// <param name="input">CustomForceUnitCompletion Input</param>
        /// <returns>CustomForceUnitCompletion Output</returns>
        /// <exception cref="Cmf.Foundation.Common.CmfBaseException">If any unexpected error occurs.</exception>
        CustomForceUnitCompletionOutput CustomForceUnitCompletion(CustomForceUnitCompletionInput input);

        /// <summary>
        /// Service used for retrieving a Resource's history of stop states.
        /// </summary>
        /// <param name="customGetResourceStopStateHistoryInput">Input Object</param>
        /// <returns>Output Object</returns>
        CustomGetResourceStopStateHistoryOutput CustomGetResourceStopStateHistory(CustomGetResourceStopStateHistoryInput customGetResourceStopStateHistoryInput);

        /// <summary>
        /// Service to Palletize Materials From Outsorted Cockpit
        /// </summary>
        /// <param name="input">CustomOutsourtedPalletize Input</param>
        /// <returns>CustomOutsourtedPalletize Output</returns>
        /// <exception cref="Cmf.Foundation.Common.CmfBaseException">If any unexpected error occurs.</exception>
        CustomOutsourtedPalletizeOutput CustomOutsourtedPalletize(CustomOutsourtedPalletizeInput input);

        /// <summary>
        /// Service for retrieving data from the equipment
        /// </summary>
        /// <param name="input">CustomGetAutomationVariables Input</param>
        /// <returns>CustomGetAutomationVariables Output</returns>
        /// <exception cref="Cmf.Foundation.Common.CmfBaseException">If any unexpected error occurs.</exception>
        CustomGetAutomationVariablesOutput CustomGetAutomationVariables(CustomGetAutomationVariablesInput input);

        /// <summary>
        /// Service to enable or disable the relations of a consumable feed with a consumption provider (Tank)
        /// </summary>
        /// <param name="customHandleConsumptionProviderInput"></param>
        /// <returns></returns>
        CustomHandleConsumptionProviderOutput CustomHandleConsumptionProvider(CustomHandleConsumptionProviderInput customHandleConsumptionProviderInput);

        /// <summary>
        /// Service to Post Data from Automation to an MES Data Collection
        /// </summary>
        /// <param name="customAutomationDataCollectionToMESInput"></param>
        /// <returns></returns>
        CustomAutomationDataCollectionToMESOutput CustomAutomationDataCollectionToMES(CustomAutomationDataCollectionToMESInput customAutomationDataCollectionToMESInput);

        /// <summary>
        /// Service to get information from outsorted pallet resource
        /// </summary>
        /// <param name="customGetOutSortedPalletFromFeederInput"></param>
        /// <returns></returns>
        CustomGetOutSortedPalletFromFeederOutput CustomGetOutSortedPalletFromFeeder(CustomGetOutSortedPalletFromFeederInput customGetOutSortedPalletFromFeederInput);

        /// <summary>
        /// Service to Complete an outsorted pallet generated in the line
        /// </summary>
        /// <param name="customAutomationDataCollectionToMESInput"></param>
        /// <returns></returns>
        CustomCompleteOutsortedPalletOutput CustomCompleteOutsortedPallet(CustomCompleteOutsortedPalletInput customCompleteOutsortedPalletInput);

        /// <summary>
        /// Service to calculate how many outsorted pallets are needed and their quantities
        /// </summary>
        /// <param name="customCalculateNeededOutsortedPalletInput"></param>
        /// <returns></returns>
        CustomCalculateNeededOutsortedPalletOutput CustomCalculateNeededOutsortedPallet(CustomCalculateNeededOutsortedPalletInput customCalculateNeededOutsortedPalletInput);

        /// <summary>
        /// Service to retrieve details when outsorting pallets on the line.
        /// </summary>
        /// <param name="input">CustomGetDetailsForPalletOutsortingInput</param>
        /// <returns>CustomGetDetailsForPalletOutsortingOutput</returns>
        CustomGetDetailsForPalletOutsortingOutput CustomGetDetailsForPalletOutsorting(CustomGetDetailsForPalletOutsortingInput input);

        /// <summary>
        /// Service to get datapoints chart from current shift
        /// </summary>
        /// <param name="customAutomationDataCollectionToMESInput"></param>
        /// <returns></returns>
        CustomGetChartCurrentShiftLimitsOutput CustomGetChartCurrentShiftLimits(CustomGetChartCurrentShiftLimitsInput customGetChartCurrentShiftLimitsInput);

        /// <summary>
        /// Service to run a statistical normality test from selected datapoints of a logical chart
        /// This service uses the Accord.NET framework for all statistical calculations.
        /// Website:
        /// http://accord-framework.net/
        /// License:
        /// http://accord-framework.net/license.html
        /// GitHub:
        /// https://github.com/accord-net/framework
        /// NuGet:
        /// https://www.nuget.org/packages/Accord/3.8.0
        /// https://www.nuget.org/packages/Accord.Statistics/3.8.0
        /// </summary>
        /// <param name="customDataPointsNormalityTestInput"></param>
        /// <returns></returns>
        CustomDataPointsNormalityTestOutput CustomDataPointsNormalityTest(CustomDataPointsNormalityTestInput customDataPointsNormalityTestInput);

        /// <summary>
        /// Service to check if all MO are available to be in a Group of MO
        /// </summary>
        /// <param name="customHandleGroupManufacturingOrdersInput"></param>
        /// <returns></returns>
        CustomHandleGroupManufacturingOrdersOutput CustomHandleGroupManufacturingOrders(CustomHandleGroupManufacturingOrdersInput customHandleGroupManufacturingOrdersInput);

        /// <summary>
        /// Service to list all materials attached to a printing queue
        /// </summary>
        /// <param name="customGetFromPrintingQueueInput"></param>
        /// <returns></returns>
        CustomGetFromPrintingQueueOutput CustomGetFromPrintingQueue(CustomGetFromPrintingQueueInput customGetFromPrintingQueueInput);

        /// <summary>
        /// Service to store a material in a printing queue
        /// </summary>
        /// <param name="customAddToPrintingQueueInput"></param>
        /// <returns></returns>
        CustomAddToPrintingQueueOutput CustomAddToPrintingQueue(CustomAddToPrintingQueueInput customAddToPrintingQueueInput);

        /// <summary>
        /// Service to remove the last material from a printing queue
        /// </summary>
        /// <param name="customRemoveFromPrintingQueueInput"></param>
        /// <returns></returns>
        CustomRemoveFromPrintingQueueOutput CustomRemoveFromPrintingQueue(CustomRemoveFromPrintingQueueInput customRemoveFromPrintingQueueInput);

        /// <summary>
        /// Service to print a ULL label
        /// </summary>
        /// <param name="customPrintLabelUnitLoadingInput"></param>
        /// <returns></returns>
        CustomPrintLabelUnitLoadingOutput CustomPrintLabelUnitLoading(CustomPrintLabelUnitLoadingInput customPrintLabelUnitLoadingInput);

        /// <summary>
        /// Service to send to IoT all the information to be printed in a Logopak printer
        /// </summary>
        /// <param name="customPrintLogopakULLLabelInput"></param>
        /// <returns></returns>
        CustomPrintLogopakULLLabelOutput CustomPrintLogopakULLLabel(CustomPrintLogopakULLLabelInput customPrintLogopakULLLabelInput);

        /// <summary>
        /// Service to Terminate group MO
        /// </summary>
        /// <param name="customTerminateGroupManufacturingOrdersInput"></param>
        /// <returns></returns>
        CustomTerminateGroupManufacturingOrdersOutput CustomTerminateGroupManufacturingOrders(CustomTerminateGroupManufacturingOrdersInput customTerminateGroupManufacturingOrdersInput);

        /// <summary>
        /// Service to attach and create durables if they do not exist
        ///
        /// The position on which the durable is attached is calculated based on the following rules:
        ///
        /// First tries to find a matching BOM Position for this product in any of the Durable BOMs
        /// of the Dispatched or InProcess orders in the resource.
        ///
        /// If there are BOMs, but none mentioned this product, or the ones that do, have their positions already
        /// occupied by other attached durables, then throws an exception.
        ///
        /// On the other hand, if there are no BOMs configured for the MOs in the resource, tries to find any free
        /// durabel position between 1 and Resource.DurablePositions (including). If no free position is found,
        /// throws an exception as well.
        /// </summary>
        /// <param name="CustomAttachDurableInput"></param>
        /// <returns></returns>
        CustomAttachDurableOutput CustomAttachDurable(CustomAttachDurableInput customAttachDurableInput);

        /// <summary>
        /// Service to Suspend or Unspuspend a material on the line
        /// </summary>
        /// <param name="customSuspendMaterialInput"></param>
        /// <returns></returns>
        CustomSuspendMaterialOutput CustomSuspendMaterial(CustomSuspendMaterialInput customSuspendMaterialInput);

        /// <summary>
        /// Service to print a ULL label
        /// </summary>
        /// <param name="CustomLoadResourceLogicalChart"></param>
        /// <returns></returns>
        CustomLoadResourceLogicalChartOutput CustomLoadResourceLogicalChart(CustomLoadResourceLogicalChartInput customLoadResourceLogicalChartInput);

        /// <summary>
        /// Custom GetDataForOEE service
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        CustomGetDataForOEEOutput CustomGetDataForOEE(CustomGetDataForOEEInput input);

        /// <summary>
        /// Custom service to retrieve Resources KPIs
        /// </summary>
        /// <param name="input">Input Object</param>
        /// <returns>Output Object</returns>
        CustomGetDataForEPMWithShiftOutput CustomGetDataForEPMWithShift(CustomGetDataForEPMWithShiftInput input);

        /// <summary>
        /// Custom service to retrieve Resources KPIs
        /// </summary>
        /// <param name="input">Input Object</param>
        /// <returns>Output Object</returns>
        CustomGetDataForEPMSummaryWithShiftOutput CustomGetDataForEPMSummaryWithShift(CustomGetDataForEPMSummaryWithShiftInput input);

        /// <summary>
        /// Custom service to recieve messages from the WMS
        /// </summary>
        /// <param name="input">Input Object</param>
        /// <returns>Output Object</returns>
        CustomWMSOrderProgressOutput CustomWMSOrderProgress(CustomWMSOrderProgressInput input);

        /// <summary>
        /// Custom service to get max additional quantity
        /// </summary>
        /// <param name="input">Input Object</param>
        /// <returns>Output Object</returns>
        CustomWMSGetMaxAdditionalQuantityOutput CustomWMSGetMaxAdditionalQuantity(CustomWMSGetMaxAdditionalQuantityInput input);

        /// <summary>
        /// Service to be invoked by Factory Automation for making requests to the WMS
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        CustomWMSOrderRequestOutput CustomWMSOrderRequest(CustomWMSOrderRequestInput input);

        /// <summary>
        /// Service to send a Cancel Request to IoT
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        CustomWMSCancelOrdersRequestOutput CustomWMSCancelOrdersRequest(CustomWMSCancelOrdersRequestInput input);

        /// <summary>
        /// Custom service to send a request order to WMS
        /// </summary>
        /// <param name="input">Input Object</param>
        /// <returns>Output Object</returns>
        CustomWMSManualOrderRequestOutput CustomWMSManualOrderRequest(CustomWMSManualOrderRequestInput input);

        /// <summary>
        /// Custom service to force the completion of a Manufacturing order on lines with Automation Mode Online.
        ///
        /// ## Pre-requisites:
        ///  - material.Form == Order
        ///  - material.SystemState == InProcess
        ///  - material.CurrentState == INPROCESS
        ///  - material.Attributes[InCompletion] == true
        ///  - material.Attributes[ForceOrderCompletionAllowed] == "Complete"
        ///  - resource.AutomationMode == Online
        ///
        /// ## Assumptions
        ///  - IoT Reply has valid Numeric field
        ///
        /// </summary>
        /// <param name="input">Input Object</param>
        /// <returns>Output Object</returns>
        CustomForceOrderCompletionOutput CustomForceOrderCompletion(CustomForceOrderCompletionInput input);

        /// <summary>
        /// Changes the default completion quantity of a order in process
        /// If automation is online, then the new default completion quantity should be greater than or equal to the
        /// quantity counted in pallet by IoT
        /// </summary>
        /// <param name="input">Input Object</param>
        /// <returns>Output Object</returns>
        CustomChangeDefaultCompletionQuantityOutput CustomChangeDefaultCompletionQuantity(CustomChangeDefaultCompletionQuantityInput input);

        /// <summary>
        /// Creates a Move or PutAway request in FactoryAutomation (to then be sent to WMS) for a specific Material
        /// </summary>
        /// <param name="input">Input Object</param>
        /// <returns>Output Object</returns>
        CustomWMSManualMoveRequestOutput CustomWMSManualMoveRequest(CustomWMSManualMoveRequestInput input);

        /// <summary>
        /// Service to resolve Orderless BOMs that can be used for a particular main line
        /// Resource/Product combination.
        /// </summary>
        /// <param name="input">Input Object</param>
        /// <returns>Output Object</returns>
        CustomResolveOrderlessBOMsOutput CustomResolveOrderlessBOMs(CustomResolveOrderlessBOMsInput input);

        /// <summary>
        /// Service to create Orderless Production Orders (PO)
        /// </summary>
        /// <param name="input">CustomCreateOrderlessProductionInput</param>
        /// <returns>CustomCreateOrderlessProductionOutput</returns>
        CustomCreateOrderlessProductionOutput CustomCreateOrderlessProduction(CustomCreateOrderlessProductionInput input);

        /// <summary>
        /// Service to update Orderless Production Orders (PO)
        /// Right now is only used to update Group Orders when they are sent to the HPO, and are returned
        /// with new orders that need a BOM to be selected by the operator.
        /// </summary>
        /// <param name="input">CustomUpdateOrderlessProductionInput</param>
        /// <returns>CustomUpdateOrderlessProductionOutput</returns>
        CustomUpdateOrderlessProductionOutput CustomUpdateOrderlessProduction(CustomUpdateOrderlessProductionInput input);

        /// <summary>
        /// Service to receive messaged from NiceLabel
        /// </summary>
        /// <param name="input">CustomNiceLabelMessageInput</param>
        /// <returns>CustomNiceLabelMessageOutput</returns>
        CustomNiceLabelMessageOutput CustomNiceLabelMessage(CustomNiceLabelMessageInput input);

        /// <summary>
        /// Service to resolve the alternative cycle times
        /// </summary>
        /// <param name="input">CustomResolveAlternativeCyclesTimesInput</param>
        /// <returns>CustomResolveAlternativeCyclesTimesOutput</returns>
        CustomResolveAlternativeCyclesTimesOutput CustomResolveAlternativeCyclesTimes(CustomResolveAlternativeCyclesTimesInput input);

        /// <summary>
        /// Service to reload the pending trackout queues on IoT after some partial trackout fails
        /// </summary>
        /// <param name="input">CustomReloadPendingTrackOutsInput</param>
        /// <returns>CustomReloadPendingTrackOutsOutput</returns>
        CustomReloadPendingTrackOutsOutput CustomReloadPendingTrackOuts(CustomReloadPendingTrackOutsInput input);

        /// <summary>
        /// Service to get the recipe overwritten values
        /// </summary>
        /// <param name="input">CustomRecipeOverwrittenValuesInput</param>
        /// <returns>CustomRecipeOverwrittenValuesOutput</returns>
        CustomRecipeOverwrittenValuesOutput CustomRecipeOverwrittenValues(CustomRecipeOverwrittenValuesInput input);

        /// <summary>
        /// Resolves the BOM for the Material and Resource, and creates a list of which BOM Products accept alternative resources to be used for them.
        /// </summary>
        /// <param name="input">CustomResolveAlternativeSubResourcesInput</param>
        /// <returns>CustomResolveAlternativeSubResourcesOutput</returns>
        CustomResolveAlternativeSubResourcesOutput CustomResolveAlternativeSubResources(CustomResolveAlternativeSubResourcesInput input);

        /// <summary>
        /// Service to get the quantities
        /// </summary>
        /// <param name="input">CustomResolveWMSQuantityInput</param>
        /// <returns>CustomResolveWMSQuantityOutput</returns>
        CustomResolveWMSQuantityOutput CustomResolveWMSQuantity(CustomResolveWMSQuantityInput input);

        /// <summary>
        /// Service to request ERP for an Ad-Hoc Production Order (for type Rework or Repair)
        /// </summary>
        /// <param name="input">Input object CustomERPRequestOrderInput</param>
        /// <returns>CustomERPRequestOrderOutput</returns>
        /// <exception cref="CmfBaseException"></exception>
        CustomERPRequestOrderOutput CustomERPRequestOrder(CustomERPRequestOrderInput input);

        /// <summary>
        /// Returns the CustomWMSMaterialTracker collection to be displayed in the GUI 'Warehouse Order Requests', for each IOType:
        ///   - FEED: material moved from the wharehouse into the production line
        ///   - MOVE: material moved from a production line, any of its feeder(s) or main stocking point, into another production line, any of its feeder(s) or stocking point
        ///   - PUTAWAY: material moved from the production line, any of its feeder(s) or stocking point, into the wharehouse
        /// </summary>
        /// <param name="input">CustomWMSListGroupedMaterialTrackersInput</param>
        /// <returns>CustomWMSListGroupedMaterialTrackersOutput</returns>
        CustomWMSListGroupedMaterialTrackersOutput CustomWMSListGroupedMaterialTrackers(CustomWMSListGroupedMaterialTrackersInput input);

        /// <summary>
        /// Service to get the chart context from material or resource
        /// </summary>
        /// <param name="input">CustomGetChartContextFromChartContextTranslatorInput</param>
        /// <returns>CustomGetChartContextFromChartContextTranslatorOutput</returns>
        CustomGetChartContextFromChartContextTranslatorOutput CustomGetChartContextFromChartContextTranslator(CustomGetChartContextFromChartContextTranslatorInput input);

        /// <summary>
        /// Service called by IoT to Resolve Resource's OEE State when alarm required and if alarm action set on table CustomAlarmHandlingActions
        /// </summary>
        /// <param name="input">Input Object</param>
        /// <returns>Output Object</returns>
        CustomModelStateChangeWithActiveAlarmOutput CustomModelStateChangeWithActiveAlarm(CustomModelStateChangeWithActiveAlarmInput input);

        /// <summary>
        /// Service to get the first scanned material in storage resource defined in the attribute LabelStorageResource on the mainFeeder provided
        /// After that, attach the same material to the mainFeeder
        /// </summary>
        /// <param name="input">MaterialLabelStorageInput</param>
        /// <returns>MaterialLabelStorageOutput</returns>
        MaterialLabelStorageOutput MaterialLabelStorage(MaterialLabelStorageInput input);

        /// <summary>
        /// Service to generate an error notification to be displayed to the operator.
        /// </summary>
        /// <param name="input">CustomGenerateErrorNotificationInput</param>
        /// <returns>CustomGenerateErrorNotificationOutput</returns>
        CustomGenerateErrorNotificationOutput CustomGenerateErrorNotification(CustomGenerateErrorNotificationInput input);

        /// <summary>
        /// Service to request IoT to create a virtual pallet. Request will be sent to resource counterpart in direct feeding .
        /// </summary>
        /// <param name="input">CustomCreateVirtualPalletInput</param>
        /// <returns>CustomCreateVirtualPalletOutput</returns>
        CustomCreateVirtualPalletOutput CustomCreateVirtualPallet(CustomCreateVirtualPalletInput input);

        /// <summary>
        /// Service to validate if counter part (in first line) of order in the second line has been completed or aborted
        /// </summary>
        /// <param name="input">CustomDirectFeedingCounterPartValidationInput</param>
        /// <returns>CustomDirectFeedingCounterPartValidationOutput</returns>
        CustomDirectFeedingCounterPartValidationOutput CustomDirectFeedingCounterPartValidation(CustomDirectFeedingCounterPartValidationInput input);

        /// <summary>
        /// Service that checks if MO in SecondLine is InProcess
        /// </summary>
        /// <param name="input">CustomIsMOInSecondLineInProcessInput</param>
        /// <returns>CustomIsMOInSecondLineInProcessOutput</returns>
        CustomIsMOInSecondLineInProcessOutput CustomIsMOInSecondLineInProcess(CustomIsMOInSecondLineInProcessInput input);

        /// <summary>
        /// Service is called by second line to clear interlock on the first line.
        /// </summary>
        /// <param name="input">CustomIsMOInSecondLineInProcessInput</param>
        /// <returns>CustomRequestClearInterlockOnFirstLine</returns>
        CustomRequestClearInterlockOnFirstLineOutput CustomRequestClearInterlockOnFirstLine(CustomRequestClearInterlockOnFirstLineInput input);

        /// <summary>
        /// Custom service to force the abortion of a Manufacturing order on lines with Automation Mode Online.
        ///
        /// ## Pre-requisites:
        ///  - material.Form == Order
        ///  - material.Attributes[InCompletion] == true
        ///  - material.Attributes[ForceOrderCompletionAllowed] == "Empty&Abort"
        ///  - resource.AutomationMode == Online
        ///
        /// ## Assumptions
        ///  - IoT Reply has valid Numeric field
        ///
        /// </summary>
        /// <param name="input">Input Object</param>
        /// <returns>Output Object</returns>
        CustomForceOrderAbortOutput CustomForceOrderAbort(CustomForceOrderAbortInput input);

        /// Service to validate complete button conditions
        /// </summary>
        /// <param name="input">CustomValidateCompleteConditionsInput</param>
        /// <returns>CustomValidateCompleteConditionsOutput</returns>
        CustomValidateCompleteConditionsOutput CustomValidateCompleteConditions(CustomValidateCompleteConditionsInput input);

        /// <summary>
        /// Service that returns MOs not in any groupMO based on input filter
        /// </summary>
        CustomGetParentlessMOListByFilterOutput CustomGetParentlessMOListByFilter(CustomGetParentlessMOListByFilterInput input);

        /// <summary>
        /// Service that returns the dispatch list for a specific resource
        /// </summary>
        CustomGetDispatchListForResourceOutput CustomGetDispatchListForResource(CustomGetDispatchListForResourceInput input);
        
        /// <summary>
        /// Service to request IoT to create a virtual pallet. Request will be sent to resource counterpart in direct feeding .
        /// </summary>
        /// <param name="input">CustomCreateVirtualPalletInput</param>
        /// <returns>CustomCreateVirtualPalletOutput</returns>
        CustomResetPalletIDQueueOutput CustomResetPalletIDQueue(CustomResetPalletIDQueueInput input);
        /// <summary>
        /// Service that returns the all the possible return steps for the outsorted material
        /// </summary>
        CustomGetOutsortedMaterialAllPossibleReturnStepsOutput CustomGetOutsortedMaterialAllPossibleReturnSteps(CustomGetOutsortedMaterialAllPossibleReturnStepsInput input);

        /// <summary>
        /// Service to detach materials
        /// </summary>
        /// <param name="CustomDetachMaterialInput">Input Object</param>
        /// <returns></returns>
        CustomDetachMaterialsOutput CustomDetachMaterials(CustomDetachMaterialsInput CustomDetachMaterialInput);
    }
}