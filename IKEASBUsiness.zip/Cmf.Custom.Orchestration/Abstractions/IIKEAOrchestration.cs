namespace Cmf.Custom.IKEA;

public interface IIKEAOrchestration
{
    
}