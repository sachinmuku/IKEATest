﻿using Accord.Math;
using Accord.Statistics;
using Accord.Statistics.Visualizations;
using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.BusinessObjects;
using Cmf.Custom.IKEA.BusinessObjects.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using Cmf.Custom.IKEA.Common.ERP;
using Cmf.Custom.IKEA.Common.Extensions;
using Cmf.Custom.IKEA.Common.Extensions.BOM;
using Cmf.Custom.IKEA.Common.Utilities;
using Cmf.Custom.IKEA.Common.WMS;
using Cmf.Custom.IKEA.Orchestration.Abstractions;
using Cmf.Custom.IKEA.Orchestration.DataStructures;
using Cmf.Custom.IKEA.Orchestration.InputObjects;
using Cmf.Custom.IKEA.Orchestration.OutputObjects;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessObjects.QueryObject;
using Cmf.Foundation.BusinessObjects.SmartTables;
using Cmf.Foundation.BusinessOrchestration;
using Cmf.Foundation.BusinessOrchestration.Abstractions;
using Cmf.Foundation.BusinessOrchestration.AlarmManagement.InputObjects;
using Cmf.Foundation.BusinessOrchestration.AlarmManagement.OutputObjects;
using Cmf.Foundation.BusinessOrchestration.ChangeSetManagement.InputObjects;
using Cmf.Foundation.BusinessOrchestration.DynamicExecutionEngineManagement.InputObjects;
using Cmf.Foundation.BusinessOrchestration.GenericServiceManagement.InputObjects;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Foundation.Common.Base;
using Cmf.Foundation.Common.LocalizationService;
using Cmf.Foundation.Security;
using Cmf.Foundation.Security.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessObjects.KPIManagement;
using Cmf.Navigo.BusinessOrchestration.Abstractions;
using Cmf.Navigo.BusinessOrchestration.DispatchManagement.OutputObjects;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects;
using Cmf.Navigo.BusinessOrchestration.ResourceManagement.InputObjects;
using Cmf.Navigo.BusinessOrchestration.ResourceManagement.OutputObjects;
using Cmf.Navigo.Common;
using Cmf.ReportingServices.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json;
using Stimulsoft.Svg;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Transactions;
using System.Xml;
using DataSet = System.Data.DataSet;
using INotification = Cmf.Navigo.BusinessObjects.Abstractions.INotification;
using INotificationCollection = Cmf.Navigo.BusinessObjects.Abstractions.INotificationCollection;
namespace Cmf.Custom.IKEA.Orchestration
{
    /// <summary>
    /// IKEA Core Orchestration Methods
    /// </summary>
    public partial class IKEABusinessManagementOrchestration : IIKEABusinessManagementOrchestration
    {
        #region Private Variables
        private readonly IResourceOrchestration _resourceOrchestration;
        private readonly IMaterialOrchestration _materialOrchestration;
        private readonly IChangeSetOrchestration _changeSetOrchestration;
        private readonly IGenericServiceOrchestration _genericServiceOrchestration;
        private readonly IAlarmOrchestration _alarmOrchestration;
        private readonly IEntityFactory _entityFactory;
        private readonly IIKEAUtilities _iKEAUtilities;
        private readonly IGenericUtilities _genericUtilities;
        private readonly IDirectFeedingUtilities _directFeedingUtilities;
        private readonly IDispatchOrchestration _dispatchOrchestration;
        private readonly IDeeContextUtilities _deeContextUtilities;
        private readonly IERPUtilities _erpUtilities;
        private readonly IBarcodeUtilities _barcodeUtilities;
        private readonly IAutomaticMaterialCreationUtilities _automaticMaterialCreationUtilities;
        private readonly IAlarmHandlingUtilities _alarmHandlingUtilities;
        private readonly IAutomaticPrintingUtilities _automaticPrintingUtilities;
        private readonly IWMSUtilities _wmsUtilities;
        private readonly IProductionOrderHandlingUtilities _productionOrderHandlingUtilities;
        private readonly INiceLabelUtilities _niceLabelUtilities;
        private readonly IServiceProvider _serviceProvider;

        private const string OBJECT_TYPE_NAME = "Cmf.Custom.IKEA.Orchestration.IKEABusinessManagementOrchestration";
        //private static String OBJECT_TYPE_NAME = typeof(IKEABusinessOrchestration).FullName;

        /// <summary>
        /// Initializes a new instance of the <see cref="IKEABusinessManagementOrchestration"/> class.
        /// </summary>
        [Microsoft.Extensions.DependencyInjection.ActivatorUtilitiesConstructor]
        public IKEABusinessManagementOrchestration(IEntityFactory entityFactory,
            IGenericUtilities genericUtilities,
            IGenericServiceOrchestration genericServiceOrchestration,
            IIKEAUtilities iKEAUtilities,
            IDeeContextUtilities deeContextUtilities,
            IDispatchOrchestration dispatchOrchestration,
            IMaterialOrchestration materialOrchestration,
            IDirectFeedingUtilities directFeedingUtilities,
            IERPUtilities erpUtilities,
            ILaborOrchestration laborOrchestration,
            IChangeSetOrchestration changeSetOrchestration,
            IMaintenanceUtilities maintenanceUtilities,
            IServiceProvider serviceProvider,
            IAlarmOrchestration alarmOrchestration,
            IResourceOrchestration resourceOrchestration,
            IAlarmHandlingUtilities alarmHandlingUtilities,
            IAutomaticMaterialCreationUtilities automaticMaterialCreationUtilities,
            IBarcodeUtilities barcodeUtilities,
            IAutomaticPrintingUtilities automaticPrintingUtilities,
            IWMSUtilities wmsUtilities,
            IProductionOrderHandlingUtilities productionOrderHandlingUtilities,
            INiceLabelUtilities niceLabelUtilities)
        {
            _entityFactory = entityFactory;
            _genericUtilities = genericUtilities;
            _genericServiceOrchestration = genericServiceOrchestration;
            _iKEAUtilities = iKEAUtilities;
            _deeContextUtilities = deeContextUtilities;
            _dispatchOrchestration = dispatchOrchestration;
            _materialOrchestration = materialOrchestration;
            _directFeedingUtilities = directFeedingUtilities;
            _erpUtilities = erpUtilities;
            _serviceProvider = serviceProvider;
            _changeSetOrchestration = changeSetOrchestration;
            _alarmOrchestration = alarmOrchestration;
            _resourceOrchestration = resourceOrchestration;
            _alarmHandlingUtilities = alarmHandlingUtilities;
            _automaticMaterialCreationUtilities = automaticMaterialCreationUtilities;
            _barcodeUtilities = barcodeUtilities;
            _automaticPrintingUtilities = automaticPrintingUtilities;
            _wmsUtilities = wmsUtilities;
            _productionOrderHandlingUtilities = productionOrderHandlingUtilities;
            _niceLabelUtilities = niceLabelUtilities;
        }


        #endregion Private Variables

        #region Orchestration Methods

        /// <summary>
        /// Completes or aborts a Material on a resource
        /// </summary>
        /// <param name="customStopMaterialInput">Input Object</param>
        /// <returns></returns>
        public CustomStopMaterialOutput CustomStopMaterial(CustomStopMaterialInput customStopMaterialInput)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomStopMaterial", new KeyValuePair<String, Object>("CustomStopMaterialInput", customStopMaterialInput));
            CustomStopMaterialOutput customStopMaterialOutput = null;



            try
            {
                //Set Output:
                customStopMaterialOutput = new CustomStopMaterialOutput();
                //Validate Input:
                Utilities.ValidateNullInput(customStopMaterialInput);

                //Log service comments if existing:
                if (!String.IsNullOrWhiteSpace(customStopMaterialInput.ServiceComments)) ApplicationContext.CallContext.AddServiceComments(customStopMaterialInput.ServiceComments);

                //Load Material:
                IMaterial material = _entityFactory.Create<IMaterial>();
                material.Name = customStopMaterialInput.MaterialName;
                material.Load();

                if (material.LastProcessedResource == null)
                {
                    throw new Exception(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomOrderMaterialNotInProcessMessage, material.Name));
                }
                //Get resource from material:
                IResource resource = material.LastProcessedResource;
                resource.Load();

                //Get Material-Resource relation:
                material.LoadRelations(Cmf.Navigo.Common.Constants.MaterialResource);
                IMaterialResource materialResource = material.MaterialResourceRelations.Where(mr => mr.TargetEntity.ProcessingType == ProcessingType.Process).FirstOrDefault();

                CustomMaterialStopReasonEnum stopReason = (CustomMaterialStopReasonEnum)Enum.Parse(typeof(CustomMaterialStopReasonEnum), customStopMaterialInput.StopReason);
                CustomDirectFeedingModeEnum directFeedingMode = material.GetAttributeValueOrDefault<CustomDirectFeedingModeEnum>(IKEAConstants.CustomMaterialAttributeDirectFeedingMode, loadAttribute: true);
                bool isDirectFeedingEnabled = _genericUtilities.GetConfigurationValueByPath<bool>(IKEAConstants.EnableDirectFeedingConfig);
                bool isFirstLineDirectFeeding = resource.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomResourceDirectFeedingIsFirstLine, loadAttribute: true);

                // In case of Stop Operation, called by IoT CustomSetMaterial state to aborted, then need to bypass DirectFeeding validation of second line can only be aborted if first line is finished.
                // Also call CustomUnitCompletion for the DF outfeeder of DF1
                if (customStopMaterialInput.IsStopOperation && directFeedingMode == CustomDirectFeedingModeEnum.DirectFeeding && isDirectFeedingEnabled && !isFirstLineDirectFeeding)
                {
                    _deeContextUtilities.SetContextParameter(IKEAConstants.DirectFeedingAbortByStopOperationContextKey, true);

                    // Get counterpart MO
                    string firstLineMaterialName = material.GetAttributeValueOrDefault<string>(IKEAConstants.CustomMaterialAttributeDirectFeedingCounterPart, loadAttribute: true);
                    IMaterial firstLineMaterial = _entityFactory.Create<IMaterial>();
                    firstLineMaterial.Load(firstLineMaterialName);

                    // Get resource counterpart
                    IResource firstLineResource = _directFeedingUtilities.GetDirectFeedingCounterpartResource(resource);
                    firstLineResource.Load();

                    // Get counterpart DirectFeeding outfeeder
                    string firstLineOutfeederName = firstLineResource.GetAttributeValueOrDefault<string>(IKEAConstants.CustomDirectFeedingOutfeederResource, loadAttribute: true);
                    IResource firstLineOutfeeder = _entityFactory.Create<IResource>();
                    firstLineOutfeeder.Load(firstLineOutfeederName);

                    _iKEAUtilities.CustomForceUnitCompletionHelper(firstLineMaterial, firstLineOutfeeder);
                }

                // In case of Direct Feeding (and stopping the order), check if counterpart of MO has already been finished, if it hasn't, then an error will be sent. Bypass this if Stop Operation.
                if (!customStopMaterialInput.IsStopOperation && directFeedingMode == CustomDirectFeedingModeEnum.DirectFeeding && isDirectFeedingEnabled && (stopReason == CustomMaterialStopReasonEnum.Abort || stopReason == CustomMaterialStopReasonEnum.Complete))
                {
                    _genericUtilities.VerifyOrderCounterPart(material, resource);
                }

                // Check if source call is comming from IOT
                if (customStopMaterialInput.IsIOTSource)
                {
                    //If service call reason is Abort > Abort
                    if (stopReason == CustomMaterialStopReasonEnum.Abort)
                    {
                        material = _iKEAUtilities.SetMaterialBackInQueue(customStopMaterialInput.StopReason, material, resource, materialResource);
                    }
                    //Service call with reason complete
                    else if (stopReason == CustomMaterialStopReasonEnum.Complete)
                    {
                        // Completes and terminates the Material
                        _iKEAUtilities.CompleteMaterial(material);
                    }
                }
                else
                {
                    if (stopReason == CustomMaterialStopReasonEnum.Stop)
                    {
                        if (resource.AutomationMode == ResourceAutomationMode.Online)
                        {
                            //Handle Online resource mode
                            IAutomationControllerInstance controllerInstance = resource.GetAutomationControllerInstance();
                            if (controllerInstance != null)
                            {
                                // Get EI default timeout
                                int requestTimeout = _genericUtilities.GetConfigurationValueByPath<int>(IKEAConstants.DownloadOrderToAutomationSendRequestDefaultTimeout);
                                object parsedReply = null;


                                if (material.CurrentMainState.CurrentState.Name == IKEAConstants.MaterialStateModelAborted || material.CurrentMainState.CurrentState.Name == IKEAConstants.MaterialStateModelCompleted)
                                {
                                    material = _iKEAUtilities.SetMaterialBackInQueue(customStopMaterialInput.StopReason, material, resource, materialResource);
                                }
                                else
                                {
                                    // Prepare material details to send order stop
                                    Dictionary<string, string> materialDetails = new()
                                {
                                    { "MaterialName", material.Name },
                                    { "Reason", customStopMaterialInput.StopReason }
                                };
                                    // Send Asynchronous request to automation to request Order to be Stopped
                                    var eiReply = _genericUtilities.RequestFromIoT<Dictionary<string, object>>(controllerInstance, IKEAConstants.AutomationRequestTypeStopMaterial, materialDetails.ToJsonString());
                                    eiReply.TryGetValue(IKEAConstants.AutomationRequestReplyField, out parsedReply);

                                    if (parsedReply is string reply)
                                    {
                                        if (!string.IsNullOrWhiteSpace(reply) && reply.Contains("Error trying to get an order property"))
                                        {
                                            material = _iKEAUtilities.SetMaterialBackInQueue(customStopMaterialInput.StopReason, material, resource, materialResource);
                                        }

                                    }
                                    if (parsedReply is bool status && !status)
                                    {
                                        //Throw connect IOT / Line controller error
                                        throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomStopMaterialNoReasonSuppliedMessage));
                                    }
                                }
                            }
                        }
                        else
                        {
                            material = _iKEAUtilities.SetMaterialBackInQueue(customStopMaterialInput.StopReason, material, resource, materialResource);
                        }
                    }
                    else
                    {

                        // check InCompletion value in advance
                        material.LoadAttribute(IKEAConstants.CustomMaterialAttributeInCompletion);
                        bool isInCompletion = material.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomMaterialAttributeInCompletion);

                        //Save InCompletionAttribute at MO level with True value
                        if (!isInCompletion)
                        {
                            material.SaveAttributes(new AttributeCollection { { IKEAConstants.CustomMaterialAttributeInCompletion, true },
                                                                                {IKEAConstants.CustomMaterialAttributeForceOrderCompletionAllowed, stopReason } });
                        }


                        //Handle Quantity > 0 
                        if (material.PrimaryQuantity > 0)
                        {
                            if (resource.AutomationMode == ResourceAutomationMode.Online)
                            {
                                if (!isInCompletion)
                                {
                                    IAutomationControllerInstance controllerInstance = resource.GetAutomationControllerInstance();
                                    if (controllerInstance != null)
                                    {
                                        // Get EI default timeout
                                        int requestTimeout = _genericUtilities.GetConfigurationValueByPath<int>(IKEAConstants.DownloadOrderToAutomationSendRequestDefaultTimeout);

                                        // Prepare material details to send order stop
                                        Dictionary<string, string> materialDetails = new Dictionary<string, string>();
                                        materialDetails.Add("MaterialName", material.Name);
                                        materialDetails.Add("Reason", customStopMaterialInput.StopReason);

                                        // Send Synchronous request to automation to request Order to be Stopped
                                        _genericUtilities.RequestFromIoT<Dictionary<string, object>>(controllerInstance, IKEAConstants.AutomationRequestTypeStopMaterial, materialDetails.ToJsonString());
                                    }
                                    else
                                    {
                                        // Throw connect IOT / Line controller error
                                        throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomStopMaterialNoReasonSuppliedMessage));
                                    }
                                }
                            }
                            else
                            {
                                //If reason is abort or empty and abort > Abort the material and set in back in queue
                                if (stopReason == CustomMaterialStopReasonEnum.Abort || stopReason == CustomMaterialStopReasonEnum.EmptyAndAbort)
                                {
                                    material = _iKEAUtilities.SetMaterialBackInQueue(customStopMaterialInput.StopReason, material, resource, materialResource);
                                }
                                else if (stopReason == CustomMaterialStopReasonEnum.Complete)
                                {
                                    _iKEAUtilities.CompleteMaterial(material);
                                }
                            }
                        }
                        //Handle Quantity = 0 
                        else
                        {
                            if (!isInCompletion && resource.AutomationMode == ResourceAutomationMode.Online)
                            {
                                IAutomationControllerInstance controllerInstance = resource.GetAutomationControllerInstance();
                                if (controllerInstance != null)
                                {
                                    // Get EI default timeout
                                    int requestTimeout = _genericUtilities.GetConfigurationValueByPath<int>(IKEAConstants.DownloadOrderToAutomationSendRequestDefaultTimeout);

                                    // Prepare material details to send order stop
                                    Dictionary<string, string> materialDetails = new Dictionary<string, string>();
                                    materialDetails.Add("MaterialName", material.Name);
                                    materialDetails.Add("Reason", customStopMaterialInput.StopReason);

                                    // Send Synchronous request to automation to request Order to be Stopped
                                    _genericUtilities.RequestFromIoT<Dictionary<string, object>>(controllerInstance, IKEAConstants.AutomationRequestTypeStopMaterial, materialDetails.ToJsonString());
                                }
                                else
                                {
                                    //Throw connect IOT / Line controller error
                                    throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomStopMaterialNoReasonSuppliedMessage));
                                }
                            }
                            else if (stopReason == CustomMaterialStopReasonEnum.Complete && resource.AutomationMode != ResourceAutomationMode.Online)
                            {
                                //If reason is complete > Complete the MO
                                _iKEAUtilities.CompleteMaterial(material);
                            }
                        }


                    }
                }

                //Saves Material to output:
                customStopMaterialOutput.Material = material;

                //Log method exit:
                long objectInstanceId = -1;
                long objectTypeId = -1;
                Utilities.EndMethod(objectTypeId, objectInstanceId, new KeyValuePair<String, Object>("CustomStopMaterialInput", customStopMaterialInput),
                                                                    new KeyValuePair<String, Object>("CustomStopMaterialOutput", customStopMaterialOutput));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            return customStopMaterialOutput;
        }

        /// <summary>
        /// Indicates the completion of a tracking unit at the exit of the production line
        /// </summary>
        /// <param name="customUnitCompleteOutput">Input Object</param>
        /// <returns></returns>
        public CustomUnitCompleteOutput CustomUnitComplete(CustomUnitCompleteInput customUnitCompleteInput)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomUnitComplete", new KeyValuePair<String, Object>("CustomUnitCompleteInput", customUnitCompleteInput));

            CustomUnitCompleteOutput customUnitCompleteOutput = null;

            try
            {
                ISmartTable smartTable = _entityFactory.Create<ISmartTable>();
                smartTable.Load(IKEAConstants.CustomERPReportablePalletTypesSmartTable);

                decimal? processedOutsortedQuantity = null;
                decimal? knownOutsortedQuantity = null;
                bool? resourceLossPiecesClassified = null;
                bool? resultResolveCustomERPReportableTypes = null;
                bool wasERPReportablePalletTypesResolved = false;

                // set output object
                customUnitCompleteOutput = new CustomUnitCompleteOutput();

                // Validate input and log service comments if existing
                Utilities.ValidateNullInput(customUnitCompleteInput, new List<string> { "PalletizeResource", "UnitAttributes" });

                // Log service comments
                if (!String.IsNullOrWhiteSpace(customUnitCompleteInput.ServiceComments))
                    ApplicationContext.CallContext.AddServiceComments(customUnitCompleteInput.ServiceComments);

                // Get Material Order Form
                String orderMaterialForm = _iKEAUtilities.GetOrderMaterialForm();
                if (String.IsNullOrWhiteSpace(orderMaterialForm))
                {
                    throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomOrderMaterialFormNotSetMessage));
                }

                // Validate order format against source material
                if (!String.Equals(orderMaterialForm, customUnitCompleteInput.ProcessOrderMaterial.Form, StringComparison.InvariantCultureIgnoreCase))
                {
                    throw new CmfBaseException(String.Format(
                                                    _iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomUnitCompleteInvalidSourceMaterialFormMessage)
                                                    , customUnitCompleteInput.ProcessOrderMaterial.Form, orderMaterialForm));
                }

                // Validate Source Material State
                if (!customUnitCompleteInput.IgnoreOrderMaterialState && customUnitCompleteInput.ProcessOrderMaterial.SystemState != MaterialSystemState.InProcess)
                {
                    throw new CmfBaseException(String.Format(
                                                _iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomOrderMaterialNotInProcessMessage)
                                                , customUnitCompleteInput.ProcessOrderMaterial.Name));
                }

                // Needs load to fill automation mode
                IResource resource = customUnitCompleteInput.ProcessOrderMaterial.LastProcessedResource;
                resource.Load();

                resource.LoadAttributes(new Collection<string>() {
                    IKEAConstants.CustomResourceAttributeUnitCompletionMode,
                    IKEAConstants.CustomAutomationTrackingMode,
                    IKEAConstants.CustomAllowAlternativeOverproduction,
                    IKEAConstants.WorkCenter,
                    IKEAConstants.CustomEnableManualProcessLoss,
                });

                // Validate unit complete mode of resource
                CustomUnitCompletionModeEnum unitCompletionMode = resource.GetAttributeValueOrDefault<CustomUnitCompletionModeEnum>(IKEAConstants.CustomResourceAttributeUnitCompletionMode, false);

                //Prevent Automatic trackout since resource automation is not Online
                if (customUnitCompleteInput.IsAutomationInvoke && resource.AutomationMode != ResourceAutomationMode.Online)
                {
                    throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomTrackoutMaterialAutomaticStartNotAllowed, customUnitCompleteInput.ProcessOrderMaterial.Form, customUnitCompleteInput.ProcessOrderMaterial.Name, resource.Name));
                }

                //Prevent Manual trackout since resource automation is Online
                if (!customUnitCompleteInput.IsAutomationInvoke && resource.AutomationMode == ResourceAutomationMode.Online && unitCompletionMode == CustomUnitCompletionModeEnum.Manual)
                {
                    throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomTrackoutMaterialManualStartNotAllowed, customUnitCompleteInput.ProcessOrderMaterial.Form, customUnitCompleteInput.ProcessOrderMaterial.Name, resource.Name));
                }

                // Validate completed quantity
                if (customUnitCompleteInput.CompletedPrimaryQuantity.GetValueOrDefault() < 0 || customUnitCompleteInput.CompletedSecondaryQuantity.GetValueOrDefault() < 0)
                {
                    throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomUnitCompleteInvalidQuantityMessage));
                }

                // completed quantity must total a value greater than 0 when it's not a process loss
                // if process loss, must greater or equal to zero (may not have process losses)
                decimal totalQuantity = customUnitCompleteInput.CompletedPrimaryQuantity.GetValueOrDefault() + customUnitCompleteInput.CompletedSecondaryQuantity.GetValueOrDefault();
                if (
                    (customUnitCompleteInput.IsProcessLoss && totalQuantity < 0)
                    ||
                    (!customUnitCompleteInput.IsProcessLoss && totalQuantity <= 0)
                   )
                {
                    throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomUnitCompleteInvalidQuantityMessage));
                }

                // Retrieve target palletization form. A target form must be resolved
                String completedForm = _iKEAUtilities.GetCompletedMaterialForm(customUnitCompleteInput.ProcessOrderMaterial);
                if (String.IsNullOrWhiteSpace(completedForm))
                {
                    throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomCompletedUnitFormNotSetMessage));
                }

                // Validate unit complete mode of resource
                unitCompletionMode = resource.GetAttributeValueOrDefault<CustomUnitCompletionModeEnum>(IKEAConstants.CustomResourceAttributeUnitCompletionMode, false);

                string processLossMaterialType = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.CustomProcessLossMaterialDefaultTypePath);
                // If resource UnitCompletionMode = Automation and invoke is not coming through automation disallow operation (create localized message)
                if (!customUnitCompleteInput.IsAutomationInvoke && unitCompletionMode == CustomUnitCompletionModeEnum.Automation && customUnitCompleteInput.CompletedUnitType != processLossMaterialType)
                {

                    throw new CmfBaseException(String.Format(
                             _iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomTrackoutMaterialManuallyUnitCompleteModeAutomation),
                             resource.Name,
                             IKEAConstants.ResourceUnitCompleteModeModeAutomation));
                }

                IMaterial sourceMaterial = customUnitCompleteInput.ProcessOrderMaterial;
                if (customUnitCompleteInput.IsProcessLoss)
                {
                    // Save the value, to not have to load it again
                    resourceLossPiecesClassified = true;

                    // saves the area where the material was marked as completed in an attribute.
                    IAttributeCollection attributes = new AttributeCollection { { IKEAConstants.CustomMaterialAttributeResourceLossPiecesClassified, resourceLossPiecesClassified.GetValueOrDefault() } };
                    sourceMaterial.SaveAttributes(attributes);
                    sourceMaterial.Load();
                }

                if (totalQuantity > 0)
                {
                    // Retrieve corresponding name generator and load it to ensure it exists
                    String completedFormNameGeneratorName = _iKEAUtilities.GetMaterialNameGenerator(completedForm);
                    INameGenerator completedFormNameGenerator = _entityFactory.Create<INameGenerator>();
                    completedFormNameGenerator.Load(completedFormNameGeneratorName);

                    ApplicationContext.CallContext.SetInformationContext("CustomMaterialAssembleRework_CompleteUnit", true);

                    //Get ReRun, DirectRepair, ProcessLoss and Outsorted Material types
                    string reRunMaterialType = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.CustomReRunMaterialDefaultTypePath);
                    string directRepairMaterialType = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.CustomDirectRepairMaterialDefaultTypePath);
                    string defaultGoodMaterialType = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.DefaultGoodTypeConfig);

                    // Validate InLine attribute
                    bool isInline = customUnitCompleteInput.ProcessOrderMaterial.GetAttributeValueOrDefault<bool>(IKEAConstants.MaterialAttributeIsInLineDirectRepair, true);

                    // Check if the CompletedUnitType is Loss. (Also ensure that, if the 'IsProcessLoss' input is true, the input 'CompletedUnitType' is set to Processloss)
                    if (customUnitCompleteInput.IsProcessLoss)
                    {
                        customUnitCompleteInput.CompletedUnitType = processLossMaterialType;
                    }
                    bool isProcessLoss = String.Equals(customUnitCompleteInput.CompletedUnitType, processLossMaterialType, StringComparison.InvariantCultureIgnoreCase);

                    // if manual reporting of loss. 
                    if (!customUnitCompleteInput.IsAutomationInvoke && unitCompletionMode != CustomUnitCompletionModeEnum.Manual && isProcessLoss)
                    {
                        CustomAutomationTrackingModeEnum trackingMode = resource.GetAttributeValueOrDefault<CustomAutomationTrackingModeEnum>(IKEAConstants.CustomAutomationTrackingMode, false);

                        if (trackingMode == CustomAutomationTrackingModeEnum.ExplicitTracking)
                        {
                            Dictionary<IResource, List<IMaterial>> materialsToConsumeMap = new Dictionary<IResource, List<IMaterial>>();
                            Dictionary<string, decimal> result = _genericUtilities.IoTManualProcessLossRequest<Dictionary<string, decimal>>(customUnitCompleteInput.ProcessOrderMaterial, customUnitCompleteInput.CompletedPrimaryQuantity);


                            foreach (var consumableId in result)
                            {
                                IMaterial mat = _entityFactory.Create<IMaterial>();
                                mat.Load(Int64.Parse(consumableId.Key));
                                mat.PrimaryQuantity = consumableId.Value;


                                IResource feeder = null;
                                if (mat.HasRelations("MaterialResource", true))
                                {
                                    feeder = mat.RelationCollection["MaterialResource"][0].TargetEntity as IResource;
                                }

                                if (feeder == null)
                                {
                                    // Get only the online feeders of the main line:
                                    var onlineConsumableFeedsMaterials = _iKEAUtilities.GetOnlineConsumableFeedsMaterials(resource);
                                    foreach (var consumableFeedMaterials in onlineConsumableFeedsMaterials)
                                    {
                                        // Load attribute CustomSourceConsumptionMaterial in all materials:
                                        consumableFeedMaterials.Value.LoadAttributes(new Collection<string> { IKEAConstants.CustomSourceConsumptionMaterial });

                                        // Check if any material contains the name of the source material in the attribute (the material from where it was splitted):
                                        if (consumableFeedMaterials.Value.Where(CFM => CFM.GetAttributeValueOrDefault<string>(IKEAConstants.CustomSourceConsumptionMaterial).CompareStrings(mat.Name)).Any())
                                        {
                                            feeder = consumableFeedMaterials.Key;
                                            break;
                                        }
                                    }
                                }

                                if (materialsToConsumeMap.Any(f => f.Key.Id == feeder.Id))
                                {
                                    materialsToConsumeMap.Where(f => f.Key.Id == feeder.Id).FirstOrDefault().Value.Add(mat);
                                }
                                else
                                {
                                    materialsToConsumeMap.Add(feeder, new List<IMaterial>() { mat });
                                }


                            }

                            customUnitCompleteInput.MaterialsToConsume = materialsToConsumeMap;
                        }
                        else
                        {
                            bool result = _genericUtilities.IoTManualProcessLossRequest<bool>(customUnitCompleteInput.ProcessOrderMaterial, customUnitCompleteInput.CompletedPrimaryQuantity);
                        }
                    }


                    // Get the material to be consumed
                    Dictionary<long, Dictionary<CustomBOMProductInformation, CustomBOMConsumptionInformation>> quantitiesToAssemble = new Dictionary<long, Dictionary<CustomBOMProductInformation, CustomBOMConsumptionInformation>>();
                    IAssembleMaterialCollection assembleMaterials = customUnitCompleteInput.ProcessOrderMaterial.CalculateMaterialsToConsume(customUnitCompleteInput.CompletedPrimaryQuantity.GetValueOrDefault()
                            , materialsToDirectConsume: customUnitCompleteInput.MaterialsToConsume
                            , quantitiesToAssemble: quantitiesToAssemble);

                    // Load the CurrentIteration of all the materials
                    IMaterialCollection materialsToConsume = _entityFactory.CreateCollection<IMaterialCollection>(); ;
                    materialsToConsume.AddRange(assembleMaterials.Select(am => am.Material));
                    materialsToConsume.LoadAttributes(new Collection<string>() { IKEAConstants.CustomMaterialAttributeCurrentIteration, IKEAConstants.CustomMaterialAttributeCreationArea });

                    // Get max iteration from source material and the current iteration from the completed unit
                    int maxIterations = customUnitCompleteInput.ProcessOrderMaterial.GetAttributeValueOrDefault<int>(IKEAConstants.CustomMaterialAttributeMaxIterations, true);

                    // Get the max ReRun Iterations from materials that match the same Area that the source material:
                    int reRunMaterialCurrentIteration = materialsToConsume.Where(m => m.GetAttributeValueOrDefault<string>(IKEAConstants.CustomMaterialAttributeCreationArea).CompareStrings(sourceMaterial.LastProcessedResource.Area.Name) &&
                                                                                      m.Attributes.ContainsKey(IKEAConstants.CustomMaterialAttributeCurrentIteration))
                                                                          .Select(m => m.GetAttributeValueOrDefault<int>(IKEAConstants.CustomMaterialAttributeCurrentIteration))
                                                                          .DefaultIfEmpty()
                                                                          .Max() + 1;

                    // Check if the MO allows ReRuns and if the current number of ReRuns is inferior to the max allowed
                    bool isReRun = (maxIterations > 1 && reRunMaterialCurrentIteration < maxIterations && !isProcessLoss);
                    bool isDirectRepair = (customUnitCompleteInput.CompletedUnitType == directRepairMaterialType && isInline);

                    customUnitCompleteInput.ProcessOrderMaterial.LoadAttribute(IKEAConstants.CustomMaterialAttributeDefaultCompletedQuantity);

                    if (customUnitCompleteInput.CompletedUnitType == reRunMaterialType && !isReRun)
                    {
                        throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomUnitCompleteReRunWrongIterationMessage));
                    }

                    if (!customUnitCompleteInput.IsAutomationInvoke && unitCompletionMode == CustomUnitCompletionModeEnum.ManualOutsorting
                    && customUnitCompleteInput.CompletedUnitType == defaultGoodMaterialType && isReRun)
                    {
                        throw new CmfBaseException(string.Format(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomUnitCompleteGoodWrongIterationMessage, reRunMaterialCurrentIteration, maxIterations)));
                    }

                    // If it is a re run or a in line direct repair the name generator should add a prefix to the material name
                    if (isReRun || isDirectRepair)
                    {
                        string materialType = isDirectRepair ? directRepairMaterialType : reRunMaterialType;
                        _deeContextUtilities.SetContextParameter(IKEAConstants.CustomUnitCompletePalletTypeContextKey, materialType);
                    }

                    // Prepare split settings
                    ISplitInputParametersCollection splitSettings = new SplitInputParametersCollection();
                    // generate split name
                    var completedFormNameGeneratorUnit = _entityFactory.Create<INameGenerator>();

                    String completedMaterialName = completedFormNameGeneratorUnit.GenerateName(completedFormNameGeneratorName, customUnitCompleteInput.ProcessOrderMaterial);

                    ISplitInputParameters splitSettingParameters = new SplitInputParameters()
                    {
                        PrimaryQuantity = customUnitCompleteInput.CompletedPrimaryQuantity.GetValueOrDefault()
                        ,
                        SecondaryQuantity = customUnitCompleteInput.CompletedSecondaryQuantity == null ? (String.IsNullOrEmpty(customUnitCompleteInput.ProcessOrderMaterial.SecondaryUnits) ? null : 0) : customUnitCompleteInput.CompletedSecondaryQuantity.GetValueOrDefault()
                        ,
                        Name = completedMaterialName
                    };
                    splitSettings.Add(splitSettingParameters);

                    IAttributeCollection moAttributes = null;

                    // Valitdate and update Outsorted completed quantity
                    if (customUnitCompleteInput.CompletedPrimaryQuantity.HasValue
                    && !customUnitCompleteInput.IsAutomationInvoke && unitCompletionMode == CustomUnitCompletionModeEnum.ManualOutsorting && !isProcessLoss && !sourceMaterial.IsChildOfGroupMO())
                    {
                        //if palletize resource is empty or null none of the palletize resorces were selected
                        if (customUnitCompleteInput.PalletizeResource == null)
                        {
                            throw _iKEAUtilities.LocalizedException(IKEAConstants.CustomPalletizeNotSelectedNotificationLocalizedMessage);
                        }

                        // Get the outsorted quantity from IoT reply:
                        var eiReply = _iKEAUtilities.GetOutsortedQuantityFromEI(resource, sourceMaterial.Name);

                        if (!eiReply.IsNullOrEmpty() && eiReply.Where(R => R.Name.CompareStrings(customUnitCompleteInput.PalletizeResource.Name)).Any())
                        {
                            // Get the relation for this specific resource:
                            var resourceRelation = _iKEAUtilities.GetManufacturingOrderOutFeederRelation(sourceMaterial, customUnitCompleteInput.PalletizeResource);
                            if (resourceRelation != null)
                            {
                                // Get current values:
                                decimal eiCurrentKnownOutsortedQuantity = eiReply.Where(R => R.Name.CompareStrings(customUnitCompleteInput.PalletizeResource.Name)).FirstOrDefault().TotalQuantity;
                                decimal currentProcessedOutsortedQuantity = resourceRelation.CurrentProcessedOutsortedQuantity.Value;

                                // Do not allow TrackOut if completed quantity surpasses queue outsorted quantity on the line
                                if (customUnitCompleteInput.CompletedPrimaryQuantity.GetValueOrDefault() + currentProcessedOutsortedQuantity > eiCurrentKnownOutsortedQuantity)
                                {
                                    throw new CmfBaseException(String.Format(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomTrackoutMaterialOutsortedQuantityExceeded),
                                    sourceMaterial.Name));
                                }

                                // Calculate the values to include the actual value out-sorting:
                                processedOutsortedQuantity = customUnitCompleteInput.CompletedPrimaryQuantity.GetValueOrDefault() + currentProcessedOutsortedQuantity;
                                knownOutsortedQuantity = eiCurrentKnownOutsortedQuantity;

                                // Update the current values:
                                resourceRelation.CurrentProcessedOutsortedQuantity = processedOutsortedQuantity;
                                resourceRelation.CurrentKnownOutsortedQuantity = eiCurrentKnownOutsortedQuantity;
                                resourceRelation.Save();
                            }
                        }
                        else
                        {
                            //Equipment integration parse failed, could not validate
                            throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomCurrentKnownOutsortedQuantityParseError));
                        }
                    }

                    string sourceMaterialType = sourceMaterial.Type;

                    bool changedMaxConcurrentMaterialsInProcess = false;

                    // Save the source material primary quantity for the cases where the value needs to be reset
                    // to the original value
                    decimal sourceMaterialPrimaryQuantity = sourceMaterial.PrimaryQuantity.GetValueOrDefault();

                    // Check if there MaxConcurrentMaterialsInProcess is defined and already reached
                    if (resource.MaxConcurrentMaterialsInProcess.GetValueOrDefault() > 0
                        && resource.MaxConcurrentMaterialsInProcess == resource.GetMaterialsInProcessCount())
                    {
                        // Change the MaxConcurrentMaterialsInProcess to allow one more material
                        resource.MaxConcurrentMaterialsInProcess += 1;
                        resource.Save();
                        changedMaxConcurrentMaterialsInProcess = true;
                    }

                    resource.RemoveFromInstanceCache();
                    resource.Load();

                    // Validate if split quantity is higher then the MO quantity
                    bool enoughQuantityToSplit = splitSettings.FirstOrDefault().PrimaryQuantity <= customUnitCompleteInput.ProcessOrderMaterial.PrimaryQuantity;

                    if (!enoughQuantityToSplit)
                    {
                        bool isAlternateOverproductionActive = resource.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomAllowAlternativeOverproduction, false);
                        if (isAlternateOverproductionActive)
                        {
                            IMaterialCollection activeMOsFromPO = _entityFactory.CreateCollection<IMaterialCollection>();
                            customUnitCompleteInput.ProcessOrderMaterial.ProductionOrder.LoadMaterials();
                            activeMOsFromPO.AddRange(customUnitCompleteInput.ProcessOrderMaterial.ProductionOrder.Materials.Where(m => m.Form == _iKEAUtilities.GetOrderMaterialForm()));

                            if (activeMOsFromPO.Count > 0)
                            {
                                activeMOsFromPO.LoadAttributes(new Collection<string> { IKEAConstants.CustomMaterialAttributeCompletedQuantity });

                                int totalCompletedQuantity = 0;
                                foreach (IMaterial activeMOFromPO in activeMOsFromPO)
                                {
                                    totalCompletedQuantity += Convert.ToInt32(activeMOFromPO.GetAttributeValueOrDefault<decimal>(IKEAConstants.CustomMaterialAttributeCompletedQuantity, false));
                                }

                                string workcenter = resource.GetAttributeValueOrDefault<string>(IKEAConstants.WorkCenter, false);
                                // Resolve ST CustomOverProductionResolution for Overproduction limit
                                Tuple<decimal, decimal?> resultOverProduction = _iKEAUtilities.ResolveCustomOverProductionResolution(facilityToResolve: resource.Area.Facility,
                                                                                                                                    areaToResolve: resource.Area,
                                                                                                                                    resourceToResolve: resource,
                                                                                                                                    workcenter: workcenter,
                                                                                                                                    productToResolve: customUnitCompleteInput.ProcessOrderMaterial.Product,
                                                                                                                                    productGroupToResolve: customUnitCompleteInput.ProcessOrderMaterial.Product.ProductGroup);

                                if (_iKEAUtilities.IsToExecuteOverProduction(resultOverProduction))
                                {
                                    decimal originalQuantity = Convert.ToDecimal(customUnitCompleteInput.ProcessOrderMaterial.ProductionOrder.Quantity);
                                    decimal maximumOverProductionQuantity = ((resultOverProduction.Item1 / 100) * originalQuantity) + originalQuantity;
                                    if (resultOverProduction.Item2.HasValue && (resultOverProduction.Item2.Value + originalQuantity) < maximumOverProductionQuantity)
                                    {
                                        maximumOverProductionQuantity = resultOverProduction.Item2.Value + originalQuantity;
                                    }

                                    // Validate if after trackout we are still below or at the maximum PO overproduction quantity
                                    if ((totalCompletedQuantity + splitSettings.FirstOrDefault().PrimaryQuantity) <= maximumOverProductionQuantity)
                                    {
                                        customUnitCompleteInput.ProcessOrderMaterial.ChangeQuantity(splitSettings.FirstOrDefault().PrimaryQuantity, 0, null, null, null);
                                    }
                                }
                            }
                        }
                    }



                    // perform split and update source material
                    _deeContextUtilities.SetContextParameter(IKEAConstants.CustomUnitCompletePalletizationSplitContextKey, true);
                    SplitMaterialOutput splitMaterialOutput = _materialOrchestration.SplitMaterial(new SplitMaterialInput() { ChildMaterials = splitSettings, Material = customUnitCompleteInput.ProcessOrderMaterial, TerminateOnZeroQuantity = false, ToCopyFutureHolds = true, SplitMode = MaterialSplitMode.SplitNotAssembled });
                    _deeContextUtilities.SetContextParameter(IKEAConstants.CustomUnitCompletePalletizationSplitContextKey, false);
                    // Check if MaxConcurrentMaterialsInProcess was changed 
                    if (changedMaxConcurrentMaterialsInProcess)
                    {
                        resource.Load();
                        // Change the MaxConcurrentMaterialsInProcess back to the initial value
                        resource.MaxConcurrentMaterialsInProcess -= 1;
                        resource.Save();
                    }

                    if (splitMaterialOutput.ChildMaterials != null && splitMaterialOutput.ChildMaterials.Count > 0)
                    {
                        customUnitCompleteOutput.CompletedUnit = splitMaterialOutput.ChildMaterials[0];
                    }

                    // retrieve source material in output and retrieve it
                    customUnitCompleteOutput.ProcessOrderMaterial = customUnitCompleteInput.ProcessOrderMaterial;
                    customUnitCompleteOutput.ProcessOrderMaterial.Load();

                    // change form and type?
                    bool changeType = false;
                    // get completed unit type SampleTesting
                    string materialTypeToUse = String.Empty;

                    if (customUnitCompleteOutput.CompletedUnit != null)
                    {
                        customUnitCompleteOutput.CompletedUnit.Form = completedForm;
                        customUnitCompleteOutput.CompletedUnit.Save();

                        // Only change the pallet type when it is not a sample testing otherwise keep the type that came from the MO
                        string sampleTesting = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.MaterialTypeSampleTestingConfig);
                        if (sourceMaterialType != sampleTesting)
                        {
                            materialTypeToUse = String.IsNullOrWhiteSpace(customUnitCompleteInput.CompletedUnitType) ? _iKEAUtilities.GetDefaultcompletedUnitType() : customUnitCompleteInput.CompletedUnitType;

                            // validate if type is valid
                            if (!_iKEAUtilities.IsMaterialTypeValifForForm(completedForm, materialTypeToUse))
                            {
                                throw new CmfBaseException(String.Format(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomUnitCompleteInvalidTypeMessage)
                                                                        , materialTypeToUse, completedForm));
                            }

                            // Check if the material uses ReRuns and if the current iteration is below the max
                            if (isReRun && !isDirectRepair
                            && !(!customUnitCompleteInput.IsAutomationInvoke && unitCompletionMode == CustomUnitCompletionModeEnum.ManualOutsorting))
                            {
                                // Set the material type to ReRun type
                                materialTypeToUse = reRunMaterialType;
                            }

                            resultResolveCustomERPReportableTypes = _iKEAUtilities.ResolveCustomERPReportableTypes(smartTable, sourceMaterial.Facility, _iKEAUtilities.GetAreaFromMaterial(sourceMaterial),
                                sourceMaterial.LastProcessedResource, materialTypeToUse, IKEAConstants.CustomERPReportablePalletTypesCollumnUnitComplete);
                            wasERPReportablePalletTypesResolved = true;

                            // In the cases where the materials is a Re Run or a in line direct repair, we need to reset the MO to the original quantity
                            if (resultResolveCustomERPReportableTypes != null && !resultResolveCustomERPReportableTypes.Value)
                            {
                                // Set the completed quantity to 0
                                customUnitCompleteOutput.CompletedQuantity = 0;

                                _deeContextUtilities.SetContextParameter(IKEAConstants.CustomUnitCompleteDoNotUpdateScheduledQuantityContextKey, true);
                                sourceMaterial.ChangeQuantity(sourceMaterialPrimaryQuantity, sourceMaterial.SecondaryQuantity, null, null, null);
                                _deeContextUtilities.SetContextParameter(IKEAConstants.CustomUnitCompleteDoNotUpdateScheduledQuantityContextKey, null);
                            }
                            else
                            {
                                // Set the completed quantity with the one in the Completed Unit
                                customUnitCompleteOutput.CompletedQuantity = customUnitCompleteOutput.CompletedUnit.PrimaryQuantity.GetValueOrDefault();
                            }

                            // If the CompletedUnit type is the same as the material type to use, do not change material type:
                            if (!customUnitCompleteOutput.CompletedUnit.Type.CompareStrings(materialTypeToUse))
                            {
                                changeType = true;
                            }
                        }

                        sourceMaterial.Load();

                        // Update the material TrackIn date attribute, but only if MO is not terminated:
                        if (sourceMaterial.UniversalState != Foundation.Common.Base.UniversalState.Terminated)
                        {
                            IAttributeCollection trackinAttributes = new AttributeCollection
                            {
                                { IKEAConstants.CustomMaterialAttributeInternalTrackInDate, DateTime.Now }
                            };
                            sourceMaterial.SaveAttributes(trackinAttributes);
                        }

                        // Set Batch for the material
                        _automaticMaterialCreationUtilities.SetMaterialBatch(sourceMaterial, customUnitCompleteOutput.CompletedUnit);

                        // saves the area where the material was marked as completed in an attribute.
                        IAttributeCollection attributes = new AttributeCollection
                                                        {
                                                            { IKEAConstants.CustomMaterialAttributeCreationArea, customUnitCompleteOutput.CompletedUnit.LastProcessedResource.Area.Name },
                                                            { IKEAConstants.CustomMaterialAttributeCompletedQuantity, 0 },
                                                            { IKEAConstants.CustomMaterialAttributeERPBlockedMovementReport, true }
                                                        };

                        // Save any Custom Attributes that the Service Caller provided to set on the newly generated Unit Material
                        if (customUnitCompleteInput.UnitAttributes.IsNullOrEmpty() == false)
                        {
                            attributes.AddRange((AttributeCollection)customUnitCompleteInput.UnitAttributes);
                        }

                        IMaterial parentMaterial = customUnitCompleteInput.ProcessOrderMaterial;

                        bool isAutomationOutfeederDefined = _deeContextUtilities.GetContextParameter(IKEAConstants.OutfeederName) != null ? true : false;
                        bool isAutomationInvokeWithOutfeederDefined = customUnitCompleteInput.IsAutomationInvoke && isAutomationOutfeederDefined;
                        bool isOperatorInvokeWithOutfeederDefined = !customUnitCompleteInput.IsAutomationInvoke && customUnitCompleteInput.PalletizeResource != null;

                        bool isToUpdateShiftQuantities = false;

                        resource.LoadAttributes(new Collection<string>() { IKEAConstants.AutomationPalletOutMode });
                        bool isMultpleOrdersOutSignal =
                            resource.Attributes.ContainsKey(IKEAConstants.AutomationPalletOutMode)
                            && resource.Attributes[IKEAConstants.AutomationPalletOutMode] == CustomPalletOutModeEnum.MultipleOrdersOutSignal.ToString()
                                ? true : false;

                        bool isAutomationModeOnline = resource.AutomationMode == ResourceAutomationMode.Online;

                        if (isAutomationModeOnline && !isMultpleOrdersOutSignal)
                        {
                            // Automation Mode is Online and Service Call performed by Cockpit
                            if (isOperatorInvokeWithOutfeederDefined)
                            {
                                isToUpdateShiftQuantities = true;
                            }

                            // Automation Mode is Online and Service Call performed by Automation and Outfeeder is setted
                            if (isAutomationInvokeWithOutfeederDefined)
                            {
                                isToUpdateShiftQuantities = true;
                            }
                        }


                        if (isToUpdateShiftQuantities)
                        {
                            decimal? initialShiftQuantityFromAutomation = _deeContextUtilities.GetContextParameter("InitialShiftQuantity") as decimal?;
                            if (initialShiftQuantityFromAutomation != null)
                            {
                                // Path where Initial Shift Quantity is from Automation
                                attributes.Add(IKEAConstants.CustomMaterialAttributeInitialShiftQuantity, initialShiftQuantityFromAutomation);
                            }
                            else
                            {
                                // Path to calculate Initial Shift Quantity from MO/Outfeeder relation
                                // Trackout invoked by automation

                                Material infeederMaterial = (Material)parentMaterial;

                                if (parentMaterial.IsChildOfGroupMO())
                                {
                                    infeederMaterial = (Material)parentMaterial.GetGroupMOFromChild();
                                }

                                infeederMaterial.LoadRelations(IKEAConstants.CustomManufacturingOrderOutFeeder);

                                IEntityRelationCollection<IEntityRelation> moOutFeeders = infeederMaterial.RelationCollection
                                    .Where(rc => rc.Key == IKEAConstants.CustomManufacturingOrderOutFeeder)
                                    .FirstOrDefault()
                                    .Value;

                                string outfeederResourceName = isOperatorInvokeWithOutfeederDefined ?
                                    customUnitCompleteInput.PalletizeResource.Name
                                    : _deeContextUtilities.GetContextParameter(IKEAConstants.OutfeederName) as string;



                                IEntityRelation moOutFeeder = moOutFeeders
                                    .Where(moof => moof.TargetEntity.Name == outfeederResourceName
                                        )
                                    .FirstOrDefault();

                                if (moOutFeeder != null)
                                {
                                    moOutFeeder.LoadAttributes(new Collection<string>() { IKEAConstants.CustomInitialShiftQuantity });
                                    moOutFeeder.Attributes.TryGetValue(IKEAConstants.CustomInitialShiftQuantity, out object attributeValue);

                                    if (attributeValue is decimal)
                                    {
                                        if (parentMaterial.IsChildOfGroupMO())
                                        {
                                            decimal? previousGmoInitialShiftQuantity = _deeContextUtilities.GetContextParameter(IKEAConstants.GmoInitialShiftQuantity) as decimal?;

                                            IMaterial gmo = parentMaterial.GetGroupMOFromChild(true);
                                            gmo.LoadRelations(IKEAConstants.CustomGroupMaterialManufacturingOrder);
                                            IEntityRelationCollection<IEntityRelation> groupMoRelations = gmo.RelationCollection
                                                    .Where(
                                                         rc => rc.Key == IKEAConstants.CustomGroupMaterialManufacturingOrder
                                                    )
                                                    .FirstOrDefault()
                                                    .Value;

                                            decimal partsPerCycle = groupMoRelations
                                                .Where(
                                                    r => r.TargetEntity.Name
                                                        == customUnitCompleteOutput.ProcessOrderMaterial.Name
                                                )
                                                .Select(
                                                    r => (r as CustomGroupMaterialManufacturingOrder)
                                                )
                                                .FirstOrDefault()
                                                .PartsPerCycle.Value
                                                ;

                                            // In case of Group MOs, this service is called once per output material
                                            // On the first instance, the attribute InitialShiftQuantity of the ManufacturingOrderOutfeeder is reduced,
                                            // therefore is necessary to store the original value on a DEE context parameter, to be reused on the next
                                            // instances.
                                            if (previousGmoInitialShiftQuantity != null)
                                            {
                                                attributeValue = previousGmoInitialShiftQuantity * partsPerCycle;
                                            }
                                            else
                                            {
                                                _deeContextUtilities.SetContextParameter(IKEAConstants.GmoInitialShiftQuantity, attributeValue);
                                                attributeValue = (decimal)attributeValue * partsPerCycle;
                                            }

                                        }

                                        attributes.Add(IKEAConstants.CustomMaterialAttributeInitialShiftQuantity, attributeValue);

                                        decimal completedQuantity = customUnitCompleteInput.CompletedPrimaryQuantity.GetValueOrDefault();
                                        decimal quantityLeftOnMo = 0;

                                        if (completedQuantity < (decimal)attributeValue)
                                        {
                                            quantityLeftOnMo = (decimal)attributeValue - completedQuantity;
                                        }

                                        // Reset ManufacturingOrderAttributeCollection attribute to 0 (CustomInitialShiftQuantity)
                                        IAttributeCollection outfeederAttributesToUpdate = new AttributeCollection()
                                        {
                                            { IKEAConstants.CustomManufacturingOrderOutFeederInitialShiftQuantity, quantityLeftOnMo}
                                        };
                                        moOutFeeder.SaveAttributes(outfeederAttributesToUpdate);
                                    }
                                }
                            }
                        }

                        customUnitCompleteOutput.CompletedUnit.SaveAttributes(attributes);
                    }

                    // Update the CompletedQuantity on the MO, but only if pallet type unit complete is reportable
                    if (!wasERPReportablePalletTypesResolved)
                    {
                        resultResolveCustomERPReportableTypes = _iKEAUtilities.ResolveCustomERPReportableTypes(smartTable, sourceMaterial.Facility, _iKEAUtilities.GetAreaFromMaterial(sourceMaterial),
                       sourceMaterial.LastProcessedResource, materialTypeToUse, IKEAConstants.CustomERPReportablePalletTypesCollumnUnitComplete);
                    }
                    if (resultResolveCustomERPReportableTypes != null && resultResolveCustomERPReportableTypes.Value)
                    {
                        if (customUnitCompleteInput.CompletedPrimaryQuantity.HasValue)
                        {
                            // Calculate completed quantity based on MO attribute
                            decimal updatedcompletedQuantity = customUnitCompleteInput.CompletedPrimaryQuantity.GetValueOrDefault();

                            sourceMaterial.LoadAttributes(new Collection<string>(){IKEAConstants.CustomMaterialAttributeCompletedQuantity,
                                    IKEAConstants.CustomMaterialAttributeProducedPallets,
                                    IKEAConstants.CustomMaterialAttributeCompletedOutsortedQuantity});

                            updatedcompletedQuantity += sourceMaterial.GetAttributeValueOrDefault<decimal>(IKEAConstants.CustomMaterialAttributeCompletedQuantity, false);


                            // Get value of MO produced pallets and increment a new one:
                            int producedPallets = 1 + sourceMaterial.GetAttributeValueOrDefault<int>(IKEAConstants.CustomMaterialAttributeProducedPallets, false);


                            // Calculate outsorted quantity based on MO attribute:
                            decimal completedOutsortedQuantity = sourceMaterial.GetAttributeValueOrDefault<decimal>(IKEAConstants.CustomMaterialAttributeCompletedOutsortedQuantity, false);

                            if (!customUnitCompleteInput.CompletedUnitType.CompareStrings(defaultGoodMaterialType))
                            {
                                completedOutsortedQuantity += customUnitCompleteInput.CompletedPrimaryQuantity.GetValueOrDefault();
                            }
                            // Set updated completed quantity, produced pallets and outsorted quantity on MO attribute
                            moAttributes = new AttributeCollection()
                                        {
                                        { IKEAConstants.CustomMaterialAttributeCompletedQuantity, updatedcompletedQuantity },
                                        { IKEAConstants.CustomMaterialAttributeProducedPallets, producedPallets },
                                        { IKEAConstants.CustomMaterialAttributeCompletedOutsortedQuantity, completedOutsortedQuantity }
                                        };

                            bool manualProcessLossEnabled = resource.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomEnableManualProcessLoss, false);
                        }
                    }

                    //Clear attribute CustomManualCompletionInProgress in case of an automation invoke and MO has a manual completion in progress:
                    bool manualCompletionInProgress = sourceMaterial.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomMaterialAttributeManualCompletionInProgress, true);
                    if (customUnitCompleteInput.IsAutomationInvoke && manualCompletionInProgress)
                    {
                        if (moAttributes.IsNullOrEmpty())
                        {
                            moAttributes = new AttributeCollection();
                        }

                        // Set updated completed quantity and produced pallets on MO attribute
                        moAttributes.Add(IKEAConstants.CustomMaterialAttributeManualCompletionInProgress, false);
                    }

                    // if there are any attribute to update, update them
                    if (!moAttributes.IsNullOrEmpty())
                    {
                        // Save MO attributes
                        sourceMaterial.LoadAttributes();
                        sourceMaterial.SaveAttributes(moAttributes);

                        sourceMaterial.Load();
                    }

                    // Perform Custom Automatic Assemble
                    customUnitCompleteOutput.CompletedUnit.CustomPerformAutomaticAssemble(assembleCollection: assembleMaterials, materialsToDirectConsume: customUnitCompleteInput.MaterialsToConsume, quantitiesToAssemble: quantitiesToAssemble);
                    customUnitCompleteOutput.CompletedUnit.Load();
                    _deeContextUtilities.SetContextParameter(IKEAConstants.CustomUnitCompletePalletTypeContextKey, null);

                    if (changeType)
                    {
                        // Set the context for the CustomERPChangeTypeReport indicating that the change type is being done by the unit completion
                        _deeContextUtilities.SetContextParameter(IKEAConstants.ERPChangeTypeReportUnitCompletion, true);

                        // change type
                        customUnitCompleteOutput.CompletedUnit.Type = materialTypeToUse;
                        ChangeMaterialTypeOutput changeMaterialTypeOutput = _materialOrchestration.ChangeMaterialType(new ChangeMaterialTypeInput() { Material = customUnitCompleteOutput.CompletedUnit });
                        if (changeMaterialTypeOutput != null)
                        {
                            customUnitCompleteOutput.CompletedUnit = changeMaterialTypeOutput.Material;
                        }
                    }


                    // if process loss, split completed unit in as much pallets as the default completed quantity is defined
                    IMaterialCollection generatedPalletsListToTrackout = _entityFactory.CreateCollection<IMaterialCollection>(); ;
                    if (isProcessLoss)
                    {

                        if (!customUnitCompleteInput.IsAutomationInvoke && resource.AutomationMode == ResourceAutomationMode.Online && unitCompletionMode != CustomUnitCompletionModeEnum.Manual)
                        {

                            bool result = _genericUtilities.IoTManualProcessLossRequest<bool>(customUnitCompleteInput.ProcessOrderMaterial, customUnitCompleteOutput.CompletedUnit.PrimaryQuantity, true);

                        }
                        else
                        {
                            decimal defaultPalletQuantity = customUnitCompleteInput.ProcessOrderMaterial.GetAttributeValueOrDefault(IKEAConstants.CustomMaterialAttributeDefaultCompletedQuantity,
                                                            customUnitCompleteOutput.CompletedUnit.PrimaryQuantity.GetValueOrDefault());

                            if (defaultPalletQuantity < customUnitCompleteOutput.CompletedUnit.PrimaryQuantity)
                            {
                                ISplitInputParametersCollection splitCompletedSettings = new SplitInputParametersCollection();

                                decimal quantityToDistribute = customUnitCompleteOutput.CompletedUnit.PrimaryQuantity.GetValueOrDefault() - defaultPalletQuantity;
                                while (quantityToDistribute > 0)
                                {
                                    // generate split name
                                    var customUnitCompleteInputNameGenerator = _entityFactory.Create<INameGenerator>();
                                    string splitMaterialName = customUnitCompleteInputNameGenerator.GenerateName(completedFormNameGeneratorName, customUnitCompleteInput.ProcessOrderMaterial);
                                    decimal quantityToTake = quantityToDistribute > defaultPalletQuantity ? defaultPalletQuantity : quantityToDistribute;
                                    quantityToDistribute -= quantityToTake;

                                    ISplitInputParameters splitCompletedSettingParameters = new SplitInputParameters()
                                    {
                                        PrimaryQuantity = quantityToTake
                                        ,
                                        SecondaryQuantity = customUnitCompleteInput.CompletedSecondaryQuantity == null ? (String.IsNullOrEmpty(customUnitCompleteInput.ProcessOrderMaterial.SecondaryUnits) ? null : 0) : customUnitCompleteInput.CompletedSecondaryQuantity.GetValueOrDefault()
                                        ,
                                        Name = splitMaterialName
                                    };
                                    splitCompletedSettings.Add(splitCompletedSettingParameters);
                                }

                                _deeContextUtilities.SetContextParameter(IKEAConstants.CustomUnitCompletePalletizationSplitContextKey, true);
                                SplitMaterialOutput splitCompletedMaterialOutput = _materialOrchestration.SplitMaterial(new SplitMaterialInput() { ChildMaterials = splitCompletedSettings, Material = customUnitCompleteOutput.CompletedUnit, TerminateOnZeroQuantity = false, ToCopyFutureHolds = true, SplitMode = MaterialSplitMode.SplitAssembled });
                                _deeContextUtilities.SetContextParameter(IKEAConstants.CustomUnitCompletePalletizationSplitContextKey, false);

                                customUnitCompleteOutput.CompletedUnit.Load();
                                generatedPalletsListToTrackout.AddRange(splitCompletedMaterialOutput.ChildMaterials);

                            }
                        }
                    }

                    if (!customUnitCompleteInput.ExcludeTrackout)
                        generatedPalletsListToTrackout.Add(customUnitCompleteOutput.CompletedUnit);

                    // Perform trackout if indicated
                    if (generatedPalletsListToTrackout.Count > 0 && customUnitCompleteOutput.CompletedUnit.SystemState == MaterialSystemState.InProcess)
                    {
                        generatedPalletsListToTrackout.TrackOut();
                        generatedPalletsListToTrackout.CheckAndPerformFutureActions();
                    }


                    // Check if the resource is Online and the completion mode is manual outsorted or automation:
                    if (resource.AutomationMode == ResourceAutomationMode.Online &&
                        (
                            unitCompletionMode == CustomUnitCompletionModeEnum.ManualOutsorting ||
                            unitCompletionMode == CustomUnitCompletionModeEnum.Automation
                        )
                    )
                    {

                        // Check if Resource Loss Pieces Classified is defined
                        if (!resourceLossPiecesClassified.HasValue)
                        {
                            resourceLossPiecesClassified = sourceMaterial.GetAttributeValueOrDefault<bool?>(IKEAConstants.CustomMaterialAttributeResourceLossPiecesClassified, true);
                        }

                        // Check if the Processed Outsorted Quantity and Known Outsorted Quantity are the same:
                        if (!processedOutsortedQuantity.HasValue && !knownOutsortedQuantity.HasValue)
                        {
                            sourceMaterial.LoadRelations(IKEAConstants.CustomManufacturingOrderOutFeeder);
                        }

                        if (_iKEAUtilities.CheckIfAllOutsortedPartsAreProcessed(sourceMaterial, false, false))
                        {
                            // Get the InCompletion attribute from material
                            bool inCompletion = sourceMaterial.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomMaterialAttributeInCompletion, true);

                            // Check if we are processing a Loss Piece, the MO is in completion
                            // and MO is not terminated
                            if ((resourceLossPiecesClassified == null || resourceLossPiecesClassified.GetValueOrDefault())
                                && inCompletion
                                && sourceMaterial.UniversalState != Foundation.Common.Base.UniversalState.Terminated)
                            {
                                if (sourceMaterial.CurrentMainState.CurrentState.Name == IKEAConstants.MaterialStateModelCompleted)
                                {
                                    // Get configured the Order Completion Reason Name
                                    string orderCompletionReasonName = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.OrderCompletionReason);

                                    // Check if there has any configured Order Completion Reason Name
                                    if (!string.IsNullOrWhiteSpace(orderCompletionReasonName))
                                    {
                                        // Load Order Completion Reason
                                        IReason orderCompletionReason = _entityFactory.Create<IReason>();
                                        orderCompletionReason.Load(orderCompletionReasonName);

                                        // Terminate the materials
                                        var sourceMaterialCollection = _entityFactory.CreateCollection<IMaterialCollection>();
                                        sourceMaterialCollection.Add(sourceMaterial);
                                        _materialOrchestration.TerminateMaterials(new TerminateMaterialsInput()
                                        {
                                            Materials = sourceMaterialCollection,
                                            LossReason = orderCompletionReason
                                        });
                                        sourceMaterial.Load();
                                    }
                                }
                                else if (sourceMaterial.CurrentMainState.CurrentState.Name == IKEAConstants.MaterialStateModelAborted)
                                {
                                    //Get Material-Resource relation:
                                    sourceMaterial.LoadRelations(Cmf.Navigo.Common.Constants.MaterialResource);
                                    IMaterialResource materialResource = sourceMaterial.MaterialResourceRelations.Where(mr => mr.TargetEntity.ProcessingType == ProcessingType.Process).FirstOrDefault();
                                    _iKEAUtilities.SetMaterialBackInQueue(null, sourceMaterial, resource, materialResource);
                                }
                            }
                        }
                    }
                }


                // log method exit
                long objectInstanceId = -1;
                long objectTypeId = -1;
                Utilities.EndMethod(objectTypeId, objectInstanceId, new KeyValuePair<String, Object>("CustomUnitCompleteInput", customUnitCompleteInput),
                                                                    new KeyValuePair<String, Object>("CustomUnitCompleteOutput", customUnitCompleteOutput));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            return customUnitCompleteOutput;
        }

        /// <summary>
        /// Service that will be call to start a material
        /// </summary>
        /// <param name="CustomStartMaterialInput">Input Object</param>
        /// <returns>Output Objects</returns>
        public CustomStartMaterialOutput CustomStartMaterial(CustomStartMaterialInput customStartMaterialInput)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomStartMaterial",
                new KeyValuePair<String, Object>("CustomStartMaterialInput", customStartMaterialInput));

            CustomStartMaterialOutput output = new CustomStartMaterialOutput();

            try
            {
                // Validate Inputs
                Utilities.ValidateNullInput(customStartMaterialInput);

                // Validate state of the material
                IMaterial material = Utilities.ValidateServiceConditions<IMaterial>(customStartMaterialInput.ServiceComments, customStartMaterialInput.IgnoreLastServiceId, customStartMaterialInput.Material);

                material.Load();

                IResource resource = material.LastProcessedResource;

                // Check if the Material is in the Setup state and is In Process
                if (material.SystemState == MaterialSystemState.InProcess
                    && material.CurrentMainState.CurrentState.Name.CompareStrings(IKEAConstants.MaterialStateModelSetup))
                {

                    // Check if the material is a group MO:
                    IMaterialCollection moMaterials = _entityFactory.CreateCollection<IMaterialCollection>(); ;

                    // Add current MO (Group MO or Not)
                    moMaterials.Add(material);

                    // Add Group MOs childs:
                    if (material.IsGroupMO())
                    {
                        moMaterials.AddRange(_iKEAUtilities.GetChildMaterialsFromGroupMO(material, loadAttributes: false));
                    }


                    foreach (var moMaterial in moMaterials)
                    {

                        if ((customStartMaterialInput.IsAutomationInvoke && resource.AutomationMode == ResourceAutomationMode.Online)
                            || !customStartMaterialInput.IsAutomationInvoke && resource.AutomationMode != ResourceAutomationMode.Online)
                        {

                            string readyForProductionAttribute = IKEAConstants.ReadyToStartIsReadyForProduction;

                            moMaterial.LoadAttributes(new Collection<string>() { readyForProductionAttribute });

                            // check if order is ready for production
                            if (moMaterial.GetAttributeValueOrDefault<bool>(readyForProductionAttribute))
                            {
                                _genericUtilities.ChangeMaterialStateModel(moMaterial, IKEAConstants.MaterialStateModelInProcess);
                            }
                            else
                            {
                                throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomStartMaterialNotReadyForProductionMessage, moMaterial.Form, moMaterial.Name));
                            }

                            // Update the material TrackIn date attribute:
                            IAttributeCollection attributes = new AttributeCollection
                            {
                                { IKEAConstants.CustomMaterialAttributeInternalTrackInDate, DateTime.Now }
                            };
                            moMaterial.SaveAttributes(attributes);

                        }
                        else
                        {
                            if (customStartMaterialInput.IsAutomationInvoke)
                            {
                                throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomStartMaterialResourceNotOnlineLocalizedMessage, resource.Name));
                            }
                            else
                            {
                                throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomStartMaterialManualStartNotAllowedLocalizedMessage, moMaterial.Form, moMaterial.Name, resource.Name));
                            }
                        }
                    }

                }
                else
                {
                    throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomStartMaterialNotSetupStateLocalizedMessage, material.Form, material.Name));
                }
                //Set the return objects
                output.Material = material;

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomStartMaterialInput", customStartMaterialInput),
                                            new KeyValuePair<String, Object>("CustomStartMaterialOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            return output;
        }

        /// <summary>
        /// Receives the message from the ION and creates a new integration entry
        /// </summary>
        /// <param name="ikeaIonMessageInput">Input Object</param>
        /// <returns></returns>
        public IKEAAcknowledgeIonMessageOutput IKEAAcknowledgeIonMessage(IKEAAcknowledgeIonMessageInput ikeaIonMessageInput)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "IKEAAcknowledgeIonMessage", new KeyValuePair<String, Object>("IKEAAcknowledgeIonMessageInput", ikeaIonMessageInput));

            IKEAAcknowledgeIonMessageOutput ikeaIonMessageOutput = null;

            try
            {
                // set output object
                ikeaIonMessageOutput = new IKEAAcknowledgeIonMessageOutput();

                // Validate input and log service comments if existing
                Utilities.ValidateNullInput(ikeaIonMessageInput);

                // check the need to transfor the input message from URL Encoded Base64
                if (ikeaIonMessageInput.IsBase64URL)
                {
                    // remove url encoding
                    string urlDecodedBase64Message = ikeaIonMessageInput.IonMessage;
                    urlDecodedBase64Message = urlDecodedBase64Message.Replace('-', '+'); // 62nd char of encoding
                    urlDecodedBase64Message = urlDecodedBase64Message.Replace('_', '/'); // 63rd char of encoding
                    switch (urlDecodedBase64Message.Length % 4) // Pad with trailing '='s
                    {
                        case 0: break; // No pad chars in this case
                        case 2: urlDecodedBase64Message += "=="; break; // Two pad chars
                        case 3: urlDecodedBase64Message += "="; break; // One pad char
                        default:
                            throw new System.Exception("Illegal base64url string!");
                    }

                    // convert from base 64
                    byte[] parsedString64 = Convert.FromBase64String(urlDecodedBase64Message);
                    string parsedString = System.Text.Encoding.UTF8.GetString(parsedString64);

                    ikeaIonMessageInput.IonMessage = parsedString.Replace("&lt;", "<").Replace("&gt;", ">");
                }

                // Log service comments
                if (!String.IsNullOrWhiteSpace(ikeaIonMessageInput.ServiceComments))
                    ApplicationContext.CallContext.AddServiceComments(ikeaIonMessageInput.ServiceComments);

                if (!String.IsNullOrWhiteSpace(ikeaIonMessageInput.IonMessage))
                {
                    XmlDocument xmlMessage = new XmlDocument();
                    // check if xmlDocument can be loaded and if so its loaded
                    if (!_iKEAUtilities.CanLoadXML(ikeaIonMessageInput.IonMessage, ref xmlMessage))
                    {
                        if (ikeaIonMessageInput.IsBase64URL)
                        {
                            //check if configuration escapeCharacters is set as true
                            if (_genericUtilities.GetConfigurationValueByPath<bool>(IKEAConstants.IonMessageEscapeCharactersInXMLConfig))
                            {

                                // pattern for & character
                                string pattern1 = @"(?<=.)&(?=[^>]*<[\/[\w]+>)|(?<=[^<]*>[^<]*)&(?=[^<]*>)";
                                ikeaIonMessageInput.IonMessage = Regex.Replace(ikeaIonMessageInput.IonMessage, pattern1, "&amp;");

                                // pattern for < character
                                string pattern2 = @"(?<=.)<(?=[^>]*<[\/[\w]+>)";
                                ikeaIonMessageInput.IonMessage = Regex.Replace(ikeaIonMessageInput.IonMessage, pattern2, "&lt;");

                                // pattern for > character
                                string pattern3 = @"(?<=[^<]*>[^<]*)>";
                                ikeaIonMessageInput.IonMessage = Regex.Replace(ikeaIonMessageInput.IonMessage, pattern3, "&gt;");

                                xmlMessage.LoadXml(ikeaIonMessageInput.IonMessage);
                            }
                            else
                            {
                                throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomIonMessageErrorAndEscapeCharacterConfigValueSetToFalseLocalizedMessage));
                            }
                        }
                        else
                        {
                            throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomIonMessageCouldNotBeLoadedLocalizedMessage));
                        }
                    }
                    string verbObj = xmlMessage.DocumentElement.Name;

                    IFilterCollection filterCollection = new FilterCollection() {
                        new Filter()
                        {
                            Name = "MessageType",
                            Operator = FieldOperator.IsEqualTo,
                            Value = verbObj,
                        }
                    };


                    DataSet result = TableHelper.GetDataFromSmartTable(IKEAConstants.IntegrationHandlerResolution, filterCollection);
                    string messageType = IKEAConstants.Unknown;
                    string fromSystem = IKEAConstants.ERPSystem;
                    if (result != null && result.HasData())
                    {
                        messageType = verbObj;
                        fromSystem = result.Tables[0].Rows[0].Field<string>("FromSystem");
                    }

                    ikeaIonMessageOutput.Result = _iKEAUtilities.CreateIntegrationEntry(sourceSystem: fromSystem,
                                                                                      targetSystem: IKEAConstants.MESSystem,
                                                                                      messageType: messageType,
                                                                                      eventName: IKEAConstants.EventNameIONMessageReceived,
                                                                                      xmlMessage: xmlMessage);
                }
                else
                {
                    throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomIkeaIonMessageEmptyLocalizedMessage));
                }

                // log method exit
                long objectInstanceId = -1;
                long objectTypeId = -1;
                Utilities.EndMethod(objectTypeId, objectInstanceId, new KeyValuePair<String, Object>("IKEAAcknowledgeIonMessageInput", ikeaIonMessageInput),
                                                                    new KeyValuePair<String, Object>("IKEAAcknowledgeIonMessageOutput", ikeaIonMessageOutput));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            return ikeaIonMessageOutput;
        }

        /// <summary>
        /// Service to retrieve possible feeders and consumers of a Material
        /// </summary>
        /// <param name="customGetMOFutureConsumptionInformationInput">Input Object</param>
        /// <returns>Output Objects</returns>
        public CustomGetMOFutureConsumptionInformationOutput CustomGetMOFutureConsumptionInformation(CustomGetMOFutureConsumptionInformationInput customGetMOFutureConsumptionInformationInput)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomGetMOFutureConsumptionInformation", new KeyValuePair<String, Object>("CustomGetMOFutureConsumptionInformationInput", customGetMOFutureConsumptionInformationInput));

            CustomGetMOFutureConsumptionInformationOutput customGetMOFutureConsumptionInformationOutput = new CustomGetMOFutureConsumptionInformationOutput();

            try
            {
                // Validate input and log service comments if existing
                Utilities.ValidateNullInput(customGetMOFutureConsumptionInformationInput);

                // ensure we Material Id is available
                if (customGetMOFutureConsumptionInformationInput.Material.Id <= 0)
                    customGetMOFutureConsumptionInformationInput.Material.Load();

                // Get Order Material Form
                String orderMaterialForm = _iKEAUtilities.GetOrderMaterialForm();

                // Get Feeder / Consumer MOs
                SqlParameter sqlMaterialId = new SqlParameter(IKEAConstants.CustomGetFeederConsumerInformationSPMaterialIdParam, SqlDbType.BigInt) { Value = customGetMOFutureConsumptionInformationInput.Material.Id };
                SqlParameter sqlRestrictToForm = new SqlParameter(IKEAConstants.CustomGetFeederConsumerInformationSPRestrictToFormParam, SqlDbType.NVarChar, 512) { Value = orderMaterialForm };
                DataSet dataSet = _iKEAUtilities.ExecuteReader(IKEAConstants.CustomGetFeederConsumerInformationSP, CommandType.StoredProcedure, sqlMaterialId, sqlRestrictToForm);
                if (dataSet != null && dataSet.Tables.Count == 2)
                {
                    DataSet feedersDs = new DataSet();
                    feedersDs.Tables.Add(dataSet.Tables[0].Copy());

                    DataSet consumersDs = new DataSet();
                    consumersDs.Tables.Add(dataSet.Tables[1].Copy());

                    customGetMOFutureConsumptionInformationOutput.PossibleFeeders = NgpDataSet.FromDataSet(feedersDs);
                    customGetMOFutureConsumptionInformationOutput.PossibleConsumers = NgpDataSet.FromDataSet(consumersDs);
                }

                // log method exit
                long objectInstanceId = -1;
                long objectTypeId = -1;
                Utilities.EndMethod(objectTypeId, objectInstanceId, new KeyValuePair<String, Object>("CustomGetMOFutureConsumptionInformationInput", customGetMOFutureConsumptionInformationInput),
                                                                    new KeyValuePair<String, Object>("CustomGetMOFutureConsumptionInformationOutput", customGetMOFutureConsumptionInformationOutput));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            return customGetMOFutureConsumptionInformationOutput;
        }

        /// <summary>
        /// Service to postpone materials
        /// </summary>
        /// <param name="customPostponeMaterialInput">Input Object</param>
        /// <returns></returns>
        public CustomPostponeMaterialOutput CustomPostponeMaterial(CustomPostponeMaterialInput customPostponeMaterialInput)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomPostponeMaterial", new KeyValuePair<String, Object>("CustomPostponeMaterialInput", customPostponeMaterialInput));

            CustomPostponeMaterialOutput customPostponeMaterialOutput = new CustomPostponeMaterialOutput
            {
                Result = false
            };

            try
            {
                // Validate input and log service comments if existing
                Utilities.ValidateNullInput(customPostponeMaterialInput);

                // Validate state of the material
                customPostponeMaterialOutput.Material = Utilities.ValidateServiceConditions<IMaterial>(customPostponeMaterialInput.ServiceComments, customPostponeMaterialInput.IgnoreLastServiceId, customPostponeMaterialInput.Material);

                // Assign resource to output and load it to ensure it is up to date
                customPostponeMaterialOutput.Resource = customPostponeMaterialInput.Resource;
                customPostponeMaterialOutput.Resource.Load();

                // Log service comments
                if (!String.IsNullOrWhiteSpace(customPostponeMaterialInput.ServiceComments))
                {
                    ApplicationContext.CallContext.AddServiceComments(customPostponeMaterialInput.ServiceComments);
                }

                bool postponeTracking = _genericUtilities.GetConfigurationValueByPath<bool>(IKEAConstants.PostponeTracking);

                // Check if the postpone tracking is enabled
                if (postponeTracking)
                {
                    // Check if the material is dispatched
                    if (customPostponeMaterialOutput.Material.SystemState == MaterialSystemState.Dispatched)
                    {
                        IStep step = customPostponeMaterialOutput.Material.Step;

                        IArea area = null;

                        if (step != null)
                        {
                            // Get Area from step
                            area = step.GetFacilityArea(customPostponeMaterialOutput.Material.Facility);
                        }

                        // Get the maximum allowed of postpones from the configuration
                        int? maxPostponeConfig = _iKEAUtilities.ResolveMaximumAllowedPostpones(customPostponeMaterialOutput.Material.Facility.Name, area.Name, step.Name, customPostponeMaterialOutput.Resource.Name);

                        // Get the actual number of postpones of the material
                        int postponeCount = customPostponeMaterialOutput.Material.GetAttributeValueOrDefault<int>(IKEAConstants.CustomMaterialAttributePostponeCount, true);

                        // Check if the postpone count is inferior to the max allowed
                        if (maxPostponeConfig == null || postponeCount < maxPostponeConfig)
                        {
                            // Get Dispatch List of the resource
                            Dictionary<IMaterial, decimal> materialOrders = _iKEAUtilities.GetMaterialsFromResourceByState(customPostponeMaterialOutput.Resource.Id, true);

                            IMaterialCollection materials = _entityFactory.CreateCollection<IMaterialCollection>(); ;
                            materials.AddRange(materialOrders.OrderBy(mo => mo.Value).Select(mo => mo.Key));

                            #region Check if there is a groupMO and if so if they are the only material presented in the list (excluding its children)

                            bool onlyOneGroupMO = false;

                            materials.Load();
                            var listOfGMO = materials.Select(m => m.GetGroupMOFromChild()).Where(_m => _m != null)?.DistinctBy(__m => __m.Name);

                            // If there is only one groupMO and its children and no more individual MOs, then it can't postpone, since there will only be presented one item on the dispatch list
                            if (listOfGMO.Count() == 1)
                            {
                                int groupMOAllElementsCount = _iKEAUtilities.GetChildMaterialsFromGroupMO(listOfGMO.First()).Count + 1; // Plus one to account for GMO material
                                onlyOneGroupMO = (groupMOAllElementsCount == materials.Count);
                            }

                            #endregion

                            // Only Change the position of the material if there are more than one
                            if (!materials.IsNullOrEmpty() && materials.Count > 1 && !onlyOneGroupMO)
                            {

                                int position;
                                IMaterial materialBeingPostPoned = materials.FirstOrDefault(m => m.Name == customPostponeMaterialOutput.Material.Name);

                                // If material being postponed is a groupMO check if there is any child in a higher order than it
                                // if yes then organize their order correctly
                                if (materialBeingPostPoned.IsGroupMO())
                                {
                                    int parentPosition = materials.IndexOf(materialBeingPostPoned);
                                    IMaterialCollection children = _iKEAUtilities.GetChildMaterialsFromGroupMO(materialBeingPostPoned);

                                    int lowestIndexChild = materials.IndexOf(children.OrderBy(m => materials.IndexOf(m)).FirstOrDefault());

                                    if (lowestIndexChild < parentPosition)
                                    {
                                        // Switch positions
                                        (materials[parentPosition], materials[lowestIndexChild]) = (materials[lowestIndexChild], materials[parentPosition]);
                                        materials.Load();
                                    }
                                }

                                position = materials.IndexOf(materialBeingPostPoned);


                                // Check if the material being postponed is the first one on the Resource dispatched list
                                if (position == 0)
                                {
                                    postponeCount++;

                                    IAttributeCollection attributes = new AttributeCollection
                                    {
                                        { IKEAConstants.CustomMaterialAttributePostponeCount, postponeCount }
                                    };

                                    // Increment the postpone count
                                    customPostponeMaterialOutput.Material.SaveAttributes(attributes);

                                    // Replace the instance of the material in the list so that it has the last service Id
                                    materials[position] = customPostponeMaterialOutput.Material;

                                    // Moves the materials in-place in the materials collection, taking into account if the current material or the next (or both)
                                    // are Group MOs (in which case, their children are moved with them as well).
                                    _iKEAUtilities.MoveDownManufacturingOrder(materials, position);

                                    Dictionary<IMaterial, int> materialOrder = new Dictionary<IMaterial, int>();

                                    int order = 1;

                                    // Change the order of all the materials in the dispatch list
                                    foreach (IMaterial dispatchedMaterial in materials)
                                    {
                                        materialOrder.Add(dispatchedMaterial, order);

                                        order++;
                                    }

                                    // Update the dispatch order in the resource
                                    customPostponeMaterialOutput.Resource = customPostponeMaterialOutput.Resource.ChangeDispatchListOrder(materialOrder);

                                    // Indicate that the postpone was done
                                    customPostponeMaterialOutput.Result = true;
                                }
                                else
                                {
                                    throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomMaterialNotAllowedPostponeLocalizedMessage));
                                }
                            }
                            else
                            {
                                throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomMaterialPostponeNotEnoughMaterialsLocalizedMessage));
                            }
                        }
                        else
                        {
                            throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomMaterialMaxAllowedPostponeLocalizedMessage));
                        }
                    }
                    else
                    {
                        throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomMaterialNotInDispatchStateLocalizedMessage));
                    }
                }

                // log method exit
                long objectInstanceId = -1;
                long objectTypeId = -1;
                Utilities.EndMethod(objectTypeId, objectInstanceId, new KeyValuePair<String, Object>("CustomPostponeMaterialInput", customPostponeMaterialInput),
                                                                    new KeyValuePair<String, Object>("CustomPostponeMaterialOutput", customPostponeMaterialOutput));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            return customPostponeMaterialOutput;
        }

        /// <summary>
        /// Service to print label or rfid
        /// </summary>
        /// <param name="customPrintLabelOrRfidInput">Input Object</param>
        /// <returns>Output Objects</returns>
        public CustomPrintLabelOrRfidOutput CustomPrintLabelOrRfid(CustomPrintLabelOrRfidInput customPrintLabelOrRfidInput)
        {
            CustomPrintLabelOrRfidOutput customPrintLabelOrRfidOutput = null;

            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomPrintLabelOrRfid",
                new KeyValuePair<String, Object>("CustomPrintLabelOrRfidInput", customPrintLabelOrRfidInput));
            try
            {
                //verify if the input parameter is null
                Utilities.ValidateNullInput(customPrintLabelOrRfidInput, new List<string>() { "Material" });

                IStep step = _entityFactory.Create<IStep>();
                step = customPrintLabelOrRfidInput.Material.Step;
                step.Load();

                string attrValue = step.HasAttribute(IKEAConstants.CustomPrintOptions, true) ? step.Attributes[IKEAConstants.CustomPrintOptions].ToString() : CustomPrintingOptionsEnum.None.ToString();

                // Prints label if no print options defined or the options are not RFID
                if (attrValue.Equals(CustomPrintingOptionsEnum.None.ToString()) || !attrValue.Equals(CustomPrintingOptionsEnum.RFId.ToString()))
                {
                    customPrintLabelOrRfidOutput = new CustomPrintLabelOrRfidOutput();
                    var repeatedDocs = from d1 in customPrintLabelOrRfidInput.PrintableDocuments
                                       from d2 in customPrintLabelOrRfidInput.PrintableDocuments
                                       where d1.Id == d2.Id && d1 != d2
                                       select d1;

                    if (repeatedDocs != null && repeatedDocs.Any())
                    {
                        customPrintLabelOrRfidOutput.PrintableDocuments = _entityFactory.CreateCollection<IPrintableDocumentCollection>();
                        foreach (IPrintableDocument doc in customPrintLabelOrRfidInput.PrintableDocuments)
                        {
                            customPrintLabelOrRfidOutput.PrintableDocuments.Add(
                                Utilities.ValidateServiceConditions<IPrintableDocument>(
                                    customPrintLabelOrRfidInput.ServiceComments,
                                    customPrintLabelOrRfidInput.IgnoreLastServiceId,
                                    doc));
                        }
                    }
                    else
                    {
                        customPrintLabelOrRfidOutput.PrintableDocuments = UtilitiesMethods.ValidateEntityCollectionConditions<IPrintableDocumentCollection, IPrintableDocument>(
                            customPrintLabelOrRfidInput.PrintableDocuments,
                            customPrintLabelOrRfidInput.IgnoreLastServiceId,
                            false);
                    }

                    customPrintLabelOrRfidOutput.PrintableDocuments.Print(false,
                        appliesToValue: customPrintLabelOrRfidInput.Material,
                        parameters: customPrintLabelOrRfidInput.Parameters,
                        operationAttributeCollection: customPrintLabelOrRfidInput.OperationAttributes);

                    // Sets the material attribute true is the print options are defined or different from none
                    if (!attrValue.Equals(CustomPrintingOptionsEnum.None.ToString()))
                    {
                        if (customPrintLabelOrRfidOutput.PrintableDocuments.Count() > 0)
                        {
                            IAttributeCollection attributes = new AttributeCollection
                            {
                                { IKEAConstants.CustomIsRfidOrLabelPrinted, true }
                            };

                            customPrintLabelOrRfidInput.Material.SaveAttributes(attributes);
                        }
                    }
                }
                // If the print options is rfid or both it prints the rfid and sets the material attribute
                if (attrValue.Equals(CustomPrintingOptionsEnum.RFId.ToString()) || attrValue.Equals(CustomPrintingOptionsEnum.Both.ToString()))
                {
                    customPrintLabelOrRfidOutput = new CustomPrintLabelOrRfidOutput();
                    customPrintLabelOrRfidOutput.PrintedRfid = true;

                    IAttributeCollection attributes = new AttributeCollection
                    {
                        { IKEAConstants.CustomIsRfidOrLabelPrinted, true }
                    };

                    customPrintLabelOrRfidInput.Material.SaveAttributes(attributes);
                }

                Utilities.EndMethod(
                    ((customPrintLabelOrRfidOutput.PrintableDocuments != null && customPrintLabelOrRfidOutput.PrintableDocuments.Count > 0) ? customPrintLabelOrRfidOutput.PrintableDocuments[0].EntityType.Id : -1),
                    customPrintLabelOrRfidOutput.PrintableDocuments,
                    new KeyValuePair<String, Object>("PrintPrintableDocumentsInput", customPrintLabelOrRfidInput),
                    new KeyValuePair<String, Object>("PrintPrintableDocumentsOutput", customPrintLabelOrRfidOutput));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            return customPrintLabelOrRfidOutput;
        }

        /// <summary>
        /// Service to report the consumption of a material
        /// </summary>
        /// <param name="customMaterialConsumptionReportInput">Input Object</param>
        /// <returns>Output Objects</returns>
        public CustomMaterialConsumptionReportOutput CustomMaterialConsumptionReport(CustomMaterialConsumptionReportInput customMaterialConsumptionReportInput)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomMaterialConsumptionReport",
                new KeyValuePair<String, Object>("CustomMaterialConsumptionReportInput", customMaterialConsumptionReportInput));

            CustomMaterialConsumptionReportOutput output = null;

            try
            {
                // Verify if the input parameter is null
                Utilities.ValidateNullInput(customMaterialConsumptionReportInput);

                if (customMaterialConsumptionReportInput.Material.ObjectExists())
                {
                    customMaterialConsumptionReportInput.Material.LoadRelations(Cmf.Navigo.Common.Constants.MaterialResource);

                    // Check if there is any resource associated
                    if (!customMaterialConsumptionReportInput.Material.MaterialResourceRelations.IsNullOrEmpty())
                    {
                        // Get Consumable Feed
                        IMaterialResource materialResource = customMaterialConsumptionReportInput.Material.MaterialResourceRelations.Where(mr => mr.TargetEntity.ProcessingType == ProcessingType.ConsumableFeed).FirstOrDefault();

                        if (materialResource != null)
                        {
                            IResource consumableFeed = materialResource.TargetEntity;

                            IMaterialCollection materials = _entityFactory.CreateCollection<IMaterialCollection>();
                            materials.Add(customMaterialConsumptionReportInput.Material);

                            // Report the material consumption
                            _iKEAUtilities.ReportMaterialConsumption(true,
                                                                    consumableFeed,
                                                                    materials,
                                                                    customMaterialConsumptionReportInput.InFeederQuantity,
                                                                    customMaterialConsumptionReportInput.InBufferQuantity,
                                                                    customMaterialConsumptionReportInput.IsLastPallet,
                                                                    orderName: customMaterialConsumptionReportInput.OrderName);

                            output = new CustomMaterialConsumptionReportOutput()
                            {
                                Material = materials.FirstOrDefault()
                            };
                        }
                    }
                }

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomMaterialConsumptionReportInput", customMaterialConsumptionReportInput),
                                            new KeyValuePair<String, Object>("CustomMaterialConsumptionReportOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            return output;
        }

        /// <summary>
        /// Service to receive a message from a barcode reader and attach the Material received in the message
        /// </summary>
        /// <param name="customScanInMaterialInput"></param>
        /// <returns>Output Object</returns>
        public CustomScanInMaterialOutput CustomScanInMaterial(CustomScanInMaterialInput customScanInMaterialInput)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomScanInMaterial",
                new KeyValuePair<String, Object>("CustomScanInMaterialInput", customScanInMaterialInput));

            CustomScanInMaterialOutput output = null;

            try
            {
                // Verify if the input parameter is null
                Utilities.ValidateNullInput(customScanInMaterialInput);

                IResource resource = _entityFactory.Create<IResource>();
                resource.Name = customScanInMaterialInput.Resource;


                if (resource.ObjectExists())
                {
                    resource.Load();

                    Dictionary<string, string> serviceTokenList = _barcodeUtilities.ExtractBarcodeInformation(customScanInMaterialInput.BarcodeInputString, resource);

                    //Validate that it has Material Token
                    if (serviceTokenList.ContainsKey(Navigo.Common.Constants.Material))
                    {

                        output = new CustomScanInMaterialOutput();
                        output.FeedbackMessages = new Collection<FeedbackMessage>();

                        string conf_enabled = _iKEAUtilities.GetValueFromConfigurationWithPath(IKEAConstants.AutomaticMaterialCreationEnable);
                        string materialName = serviceTokenList.Where(x => x.Key == Navigo.Common.Constants.Material).Select(x => x.Value).FirstOrDefault();
                        IMaterial material = _entityFactory.Create<IMaterial>();
                        material.Name = materialName;


                        //Material does not exists and must be created
                        if (!material.ObjectExists())
                        {
                            if (!conf_enabled.IsNullOrEmpty() && bool.Parse(conf_enabled))
                            {

                                material = _automaticMaterialCreationUtilities.CustomCreateScannedMaterialAutomaticallyUtility(resource, serviceTokenList);
                                if (material != null)
                                {

                                    //Add create material success message
                                    output.FeedbackMessages.Add(new FeedbackMessage()
                                    {
                                        MessageType = FeedbackMessageType.Success,
                                        Message = _iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomAutoMaterialCreationSuccessMessage, material.Name, material.Product.Name, material.PrimaryQuantity.ToString())
                                    });

                                }
                            }
                            //Error: Material does not exists and it was not created:
                            else
                            {
                                throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomBarcodeExceptionsMaterialNotFoundLocalizedMessage, material.Name));
                            }
                        }


                        //Attach the material to the resource:
                        material.Load();

                        // Verify if the material to attach is of type = ReRun
                        if (material.Type == _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.CustomReRunMaterialDefaultTypePath))
                        {
                            // Verify if ReRun pallet is in the correct step before being attached to the Consumable feed, according to the expected step in the BOM Product
                            _iKEAUtilities.ValidateReRunPalletCurrentAndExpectedStepAtAttach(material);
                        }

                        IMaterialResource materialResourceRelation = _entityFactory.Create<IMaterialResource>();
                        materialResourceRelation.SourceEntity = material;
                        materialResourceRelation.TargetEntity = resource;

                        IMaterialCollection materialColl = _entityFactory.CreateCollection<IMaterialCollection>(); ;
                        materialColl.Add(material);
                        Dictionary<IResource, IMaterialCollection> resourceMatCollection = new Dictionary<IResource, IMaterialCollection>
                        {
                            { resource, materialColl }
                        };

                        IResource topMost = resource.GetTopMostResource();

                        Navigo.BusinessOrchestration.ResourceManagement.InputObjects.ManageResourceConsumableFeedsInput input = new Navigo.BusinessOrchestration.ResourceManagement.InputObjects.ManageResourceConsumableFeedsInput()
                        {
                            ConsumablesToAttach = resourceMatCollection,
                            Resource = topMost,

                        };
                        _resourceOrchestration.ManageResourceConsumableFeeds(input);

                        // Checks if the material needs to increment the MO quantity, and removes 'IncreasesMOQuantity' attribute if exists:
                        var mc = _entityFactory.CreateCollection<IMaterialCollection>();
                        mc.Add(material);
                        _iKEAUtilities.IncrementMOQuantityByMaterialAttribute(mc);

                        //Add attach success message:
                        output.FeedbackMessages.Add(new FeedbackMessage()
                        {
                            MessageType = FeedbackMessageType.Success,
                            Message = _iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomBarcodeSuccessMessageLocalizedMessage, material.Name, resource.Name)
                        });

                        // Set batch name as base material
                        if (serviceTokenList.ContainsKey(IKEAConstants.AutomaticScanningMaterialCreationBatchToken))
                        {
                            material.SaveAttributes(new AttributeCollection(){
                            { IKEAConstants.CustomMaterialAttributeBaseMaterial, serviceTokenList[IKEAConstants.AutomaticScanningMaterialCreationBatchToken]}});
                        }

                        material.Load();
                        output.Material = material;

                    }
                    else
                    {
                        //Material token not found in the scanned barcode
                        throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomBarcodeExceptionsMaterialTokenNotFoundLocalizedMessage, resource.Name));
                    }
                }
                else
                {
                    //Resouce not in MEs
                    throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomBarcodeExceptionsResourceNotFoundLocalizedMessage, resource.Name));
                }

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomScanInMaterialInput", customScanInMaterialInput),
                                            new KeyValuePair<String, Object>("CustomScanInMaterialOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            return output;
        }

        /// <summary>
        /// Service to retrieve the BOM Information
        /// </summary>
        /// <param name="customGetDataForBOMInformationInput"></param>
        /// <returns>Output Object</returns>
        public CustomGetDataForBOMInformationOutput CustomGetDataForBOMInformation(CustomGetDataForBOMInformationInput input)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomGetDataForBOMInformation",
                new KeyValuePair<String, Object>("CustomGetDataForBOMInformationInput", input));

            CustomGetDataForBOMInformationOutput output = null;

            try
            {
                Utilities.ValidateNullInput(input,
                     new List<string>() { "MaterialLevelsToLoad", "Resource", "Material" });

                // the resource is mandatory for DispatchAndTrackIn operation
                if (input.Resource == null)
                {
                    throw new ArgumentNullCmfException("Resource");
                }

                output = new CustomGetDataForBOMInformationOutput();

                //load the material with levels to load = 0 in order to have the native properties for the rest of the process
                output.Material = input.Material;
                output.Material.Load();
                output.Material.LoadAttributes();


                var bomDataInput = new BomDataInput
                {
                    BomLevelsToLoad = 1,
                    BOMProductLevelsToLoad = 1,
                    Material = input.Material,
                    MaterialLevelsToLoad = input.MaterialLevelsToLoad,
                    Operation = GetDataForTrackInOperation.TrackIn,
                    Resource = input.Resource,
                    ResourceLevelsToLoad = input.ResourceLevelsToLoad,
                    TopMostMaterialLevelsToLoad = 0,
                };

                BomDataOutput item = _iKEAUtilities.GetDispatchedAndInProgressMaterialBOMData(bomDataInput);
                output.Bom = item.Bom;
                output.BOMAssemblyType = item.BOMAssemblyType;

                #region If Bom is valid get Data for BOM

                Dictionary<long, List<IBOMProduct>> productBomProduct = new Dictionary<long, List<IBOMProduct>>();
                if (output.Bom != null)
                {
                    //load the Bom effective version
                    output.BOMSetupInformation = new BOMSetupInformation();

                    output.BOMSetupInformation.BOMProductToConsumableFeed = new Dictionary<long, long>();

                    //load the BOMAssemblyType                    
                    output.BOMSetupInformation.BOMAssemblyType = output.BOMAssemblyType;


                    output.BOMSetupInformation.BOM = _entityFactory.Create<IBOM>();
                    output.BOMSetupInformation.BOM.Load(output.Bom.Id);

                    //load BOMProduct relations
                    output.BOMSetupInformation.BOM.LoadRelations("BOMProduct", 1);

                    if (ApplicationContext.CallContext.SecurityLevel.ObjectLevel)
                    {
                        if (output.BOMSetupInformation.BOM.ObjectLocked && output.BOMSetupInformation.BOM.LockType == LockType.NoAccess)
                        {
                            throw new UserDoesNotHaveSecurityLevelToAccessObjectCmfException(Utilities.DomainUserName, output.BOMSetupInformation.BOM.Name, output.BOMSetupInformation.BOM.EntityType.Name);
                        }

                        if (output.BOMSetupInformation.BOM.BomProducts != null && output.BOMSetupInformation.BOM.BomProducts.Count > 0)
                        {
                            var qry = output.BOMSetupInformation.BOM.BomProducts.Where(O => O.TargetEntity.ObjectLocked && O.TargetEntity.LockType == LockType.NoAccess);
                            if (qry.Count() > 0)
                            {
                                throw new UserDoesNotHaveSecurityLevelToAccessObjectCmfException(Utilities.DomainUserName, qry.First().TargetEntity.Name, qry.First().TargetEntity.EntityType.Name);
                            }
                        }
                    }

                    if (output.BOMSetupInformation.BOM.BomProducts != null && output.BOMSetupInformation.BOM.BomProducts.Count > 0)
                    {
                        foreach (var bp in output.BOMSetupInformation.BOM.BomProducts)
                        {
                            if (!productBomProduct.ContainsKey(bp.TargetEntity.Id))
                            {
                                productBomProduct.Add(bp.TargetEntity.Id, new List<IBOMProduct>() { bp });
                            }
                            else
                            {
                                productBomProduct[bp.TargetEntity.Id].Add(bp);
                            }
                        }
                    }
                    IResource resourceToUse = input.Resource;
                    if (resourceToUse == null)
                    {
                        resourceToUse = item.Resources.First();
                    }
                    resourceToUse.LoadRelations("SubResource");
                    output.Resource = resourceToUse;
                    IEntityRelationCollection<IEntityRelation> subResources = null;
                    if (resourceToUse.RelationCollection.TryGetValue("SubResource", out subResources))
                    {
                        IEnumerable<IEntityRelation> allConsumableFeeds = subResources.Where<IEntityRelation>(sr => ((IResource)sr.TargetEntity).ProcessingType == ProcessingType.ConsumableFeed);

                        output.BOMSetupInformation.ConsumableFeedResources = _entityFactory.CreateCollection<IResourceCollection>();
                        output.BOMSetupInformation.ConsumableFeedPossibleMaterials = new Dictionary<long, INgpDataSet>();
                        output.BOMSetupInformation.ConsumableFeedResources.AddRange(allConsumableFeeds.Cast<ISubResource>().Select<ISubResource, IResource>(cs => cs.TargetEntity));

                        foreach (var consFeed in output.BOMSetupInformation.ConsumableFeedResources)
                        {
                            consFeed.LoadRelations(Cmf.Navigo.Common.Constants.MaterialResource, 1);
                            IEntityRelationCollection<IEntityRelation> materialResources = null;
                            if (consFeed.RelationCollection.TryGetValue(Cmf.Navigo.Common.Constants.MaterialResource, out materialResources))
                            {
                                foreach (IEntityRelation materialResource in materialResources)
                                {
                                    IMaterial materialInConsumableFeed = (IMaterial)materialResource.SourceEntity;
                                    long prodId = materialInConsumableFeed.Product.Id;
                                    long stepId = materialInConsumableFeed.Step.Id;
                                    string primaryUnit = materialInConsumableFeed.GetNativeValue<string>("PrimaryUnits");
                                    if (productBomProduct.ContainsKey(prodId))
                                    {
                                        IBOMProduct bomProduct = productBomProduct[prodId].First();

                                        if (bomProduct.GetNativeValue<string>("Units") == primaryUnit && bomProduct.GetNativeValue<long>("Step") == stepId)
                                        {
                                            long bomProductIdKey = (bomProduct.Parent != null && bomProduct.Parent.Id > 0 ? bomProduct.Parent.Id : bomProduct.Id);
                                            if (!output.BOMSetupInformation.BOMProductToConsumableFeed.ContainsKey(bomProductIdKey))
                                            {
                                                output.BOMSetupInformation.BOMProductToConsumableFeed.Add(bomProductIdKey, consFeed.Id);

                                                productBomProduct[prodId].Remove(bomProduct);

                                                if (productBomProduct[prodId].Count == 0)
                                                {
                                                    productBomProduct.Remove(prodId);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                #endregion

                // Close service\
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomGetDataForBOMInformationInput", input),
                                    new KeyValuePair<String, Object>("CustomGetDataForBOMInformationOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            return output;
        }

        /// <summary>
        /// Service to receive a filterCollection ad retrieve filtered results for Last Pallet Location Page
        /// </summary>
        /// <param name="CustomGetDataForPalletLocationInput"></param>
        /// <returns>Output Object</returns>
        public CustomGetDataForPalletLocationOutput CustomGetDataForPalletLocation(CustomGetDataForPalletLocationInput customGetDataForPalletLocationInput)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomGetDataForPalletLocation",
                new KeyValuePair<String, Object>("CustomGetDataForPalletLocationInput", customGetDataForPalletLocationInput));

            CustomGetDataForPalletLocationOutput output = null;
            string matName = null;
            string facilityName = null;
            string resourceName = null;
            string areaName = null;
            string productName = null;
            string typeName = null;
            long outputLong;

            try
            {
                PalletLocationCollection outputCollection = new PalletLocationCollection();
                output = new CustomGetDataForPalletLocationOutput();
                output.PalletLocationCollection = new PalletLocationCollection();

                if (!customGetDataForPalletLocationInput.FilterCollection.IsNullOrEmpty())
                {
                    foreach (IFilter filter in customGetDataForPalletLocationInput.FilterCollection)
                    {
                        // Needs to use LastProcessedResource Filters because Relations are not Supported on Filters
                        switch (filter.Name)
                        {
                            case "Name":
                                matName = filter.Value as string;
                                break;
                            case "Facility.Name":
                                facilityName = filter.Value as string;
                                break;
                            case "LastProcessedResource.Area.Name":
                                areaName = filter.Value as string;
                                break;
                            case "LastProcessedResource.Name":
                                resourceName = filter.Value as string;
                                break;
                            case "Product.Name":
                                productName = filter.Value as string;
                                break;
                            case "Type":
                                typeName = filter.Value as string;
                                break;
                        }
                    }
                }

                //Call procedure to extract data using the given fields

                // Setup Stored Procedure Parameters ( Filters )
                SqlParameter sqlMaterialName = new SqlParameter("@MaterialName", SqlDbType.NVarChar, 512) { Value = matName };
                SqlParameter sqlFacilityName = new SqlParameter("FacilityName", SqlDbType.NVarChar, 512) { Value = facilityName };
                SqlParameter sqlAreaName = new SqlParameter("AreaName", SqlDbType.NVarChar, 512) { Value = areaName };
                SqlParameter sqlResourceName = new SqlParameter("ResourceName", SqlDbType.NVarChar, 512) { Value = resourceName };
                SqlParameter sqlProductName = new SqlParameter("ProductName", SqlDbType.NVarChar, 512) { Value = productName };
                SqlParameter sqlTypeName = new SqlParameter("Type", SqlDbType.NVarChar, 512) { Value = typeName };

                DataSet dataSet = _iKEAUtilities.ExecuteReader("[Custom].[P_GetPalletLocationInformation]",
                                                                CommandType.StoredProcedure,
                                                                sqlMaterialName,
                                                                sqlFacilityName,
                                                                sqlAreaName,
                                                                sqlResourceName,
                                                                sqlProductName,
                                                                sqlTypeName
                                                            );
                // Handle StoredProcedure Output
                if (dataSet.HasData())
                {
                    Dictionary<string, string> materialTypeColor = new Dictionary<string, string>();
                    IFilterCollection filterCollection = new FilterCollection();

                    DataSet result = TableHelper.GetDataFromGenericTable(IKEAConstants.CustomMaterialTypeColorMapping, filterCollection);

                    if (result != null && result.HasData())
                    {
                        materialTypeColor.AddRange(result.Tables[0].AsEnumerable()
                            .ToDictionary(row => row.Field<string>("MaterialType"), row => row.Field<string>("Color")));
                    }

                    var resultDS = dataSet.Tables[0].Rows.Cast<DataRow>().Select(E => new
                    {
                        MaterialName = Convert.ToString(E["MaterialName"])
                        ,
                        MaterialId = long.TryParse(Convert.ToString(E["MaterialId"]), out outputLong) ? outputLong : 0
                        ,
                        StorageLocationName = Convert.ToString(E["StorageLocationName"])
                        ,
                        StorageLocationId = long.TryParse(Convert.ToString(E["StorageLocationId"]), out outputLong) ? outputLong : 0
                        ,
                        LastLocationName = Convert.ToString(E["LastLocationName"])
                        ,
                        LastLocationId = long.TryParse(Convert.ToString(E["LastLocationId"]), out outputLong) ? outputLong : 0
                        ,
                        ProductName = Convert.ToString(E["ProductName"])
                        ,
                        ProductId = long.TryParse(Convert.ToString(E["ProductId"]), out outputLong) ? outputLong : 0
                        ,
                        FacilityName = Convert.ToString(E["FacilityName"])
                        ,
                        FacilityId = long.TryParse(Convert.ToString(E["FacilityId"]), out outputLong) ? outputLong : 0
                        ,
                        AreaName = Convert.ToString(E["AreaName"])
                        ,
                        AreaId = long.TryParse(Convert.ToString(E["AreaId"]), out outputLong) ? outputLong : 0
                        ,
                        Type = Convert.ToString(E["Type"])
                        ,
                        PrimaryQuantity = Convert.ToString(E["PrimaryQuantity"])
                        ,
                        SecondaryQuantity = Convert.ToString(E["SecondaryQuantity"])
                    });

                    //Fill the Output with data to send to the GUI
                    outputCollection.AddRange(resultDS.Select(E => new PalletLocation()
                    {
                        Area = new SimplifiedMESEntity()
                        {
                            Id = E.AreaId,
                            Name = E.AreaName
                        },
                        Facility = new SimplifiedMESEntity()
                        {
                            Id = E.FacilityId,
                            Name = E.FacilityName
                        },
                        LastProcessedResource = new SimplifiedMESEntity()
                        {
                            Id = E.LastLocationId,
                            Name = E.LastLocationName
                        },
                        Material = new SimplifiedMESEntity()
                        {
                            Id = E.MaterialId,
                            Name = E.MaterialName
                        },
                        Product = new SimplifiedMESEntity()
                        {
                            Id = E.ProductId,
                            Name = E.ProductName
                        },
                        Resource = new SimplifiedMESEntity()
                        {
                            Id = E.StorageLocationId,
                            Name = E.StorageLocationName
                        },
                        Type = E.Type,
                        PrimaryQuantity = E.PrimaryQuantity,
                        SecondaryQuantity = E.SecondaryQuantity,
                        MaterialTypeColor = materialTypeColor.FirstOrDefault(f => f.Key == E.Type).Value
                    }));
                }

                //Set the return object
                output.PalletLocationCollection = outputCollection;

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomGetDataForPalletLocationInput", customGetDataForPalletLocationInput),
                                            new KeyValuePair<String, Object>("CustomGetDataForPalletLocationOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;
        }

        /// <summary>
        /// Service to retrieve a list of Running MOs
        /// </summary>
        /// <param name="customGetRunningMOsInput">Input Object</param>
        /// <returns>Output Objects</returns>
        public CustomGetRunningMOsOutput CustomGetRunningMOs(CustomGetRunningMOsInput customGetRunningMOsInput)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomGetRunningMOs",
                new KeyValuePair<String, Object>("CustomGetRunningMOsInput", customGetRunningMOsInput));

            CustomGetRunningMOsOutput output = new CustomGetRunningMOsOutput();

            try
            {
                // Verify if the input parameter is null
                Utilities.ValidateNullInput(customGetRunningMOsInput, new List<string>() { "FacilityName", "AreaName", "ResourceName", "Filters" });

                string areaName = null;
                string facilityName = null;
                string resourceName = null;

                // filter collection takes precedence over other properties
                if (customGetRunningMOsInput.Filters != null && customGetRunningMOsInput.Filters.Count > 0)
                {
                    var inAreaName = customGetRunningMOsInput.Filters.FirstOrDefault(E => String.Equals(E.Name, "LastProcessedResource.Area.Name", StringComparison.InvariantCultureIgnoreCase));
                    if (inAreaName != null)
                        areaName = Convert.ToString(inAreaName.Value);

                    var inFacilityName = customGetRunningMOsInput.Filters.FirstOrDefault(E => String.Equals(E.Name, "Facility.Name", StringComparison.InvariantCultureIgnoreCase));
                    if (inFacilityName != null)
                        facilityName = Convert.ToString(inFacilityName.Value);

                    var inResourceName = customGetRunningMOsInput.Filters.FirstOrDefault(E => String.Equals(E.Name, "LastProcessedResource.Name", StringComparison.InvariantCultureIgnoreCase));
                    if (inResourceName != null)
                        resourceName = Convert.ToString(inResourceName.Value);
                }

                // if none of the expected tokens could be obtained from the filter collection, fallback to the other properties
                if (String.IsNullOrWhiteSpace(facilityName) && String.IsNullOrWhiteSpace(areaName) && String.IsNullOrWhiteSpace(resourceName))
                {
                    areaName = customGetRunningMOsInput.AreaName;
                    facilityName = customGetRunningMOsInput.FacilityName;
                    resourceName = customGetRunningMOsInput.ResourceName;
                }

                SqlParameter sqlResourceName = new SqlParameter("@ResourceName", SqlDbType.NVarChar, 512) { Value = resourceName };
                SqlParameter sqlFacilityName = new SqlParameter("@FacilityName", SqlDbType.NVarChar, 512) { Value = facilityName };
                SqlParameter sqlAreaName = new SqlParameter("@AreaName", SqlDbType.NVarChar, 512) { Value = areaName };

                DataSet dataSet = _iKEAUtilities.ExecuteReader("[Custom].[P_GetRunningMOs]",
                                                                CommandType.StoredProcedure,
                                                                sqlResourceName,
                                                                sqlFacilityName,
                                                                sqlAreaName);

                if (dataSet.HasData())
                {
                    output.Materials = dataSet.ToNgpDataSet();
                }

                output.RefreshRate = _genericUtilities.GetConfigurationValueByPath<int>(IKEAConstants.RunningMOsRefreshRate);

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomGetRunningMOsInput", customGetRunningMOsInput),
                                            new KeyValuePair<String, Object>("CustomGetRunningMOsOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            return output;
        }

        /// <summary>
        /// Service that will log or notify equipment alarms
        /// </summary>
        /// <param name="CustomLogAlarmOccurrenceInput">Input Object</param>
        /// <returns>Output Objects</returns>
        public CustomLogAlarmOccurrenceOutput CustomLogAlarmOccurrence(CustomLogAlarmOccurrenceInput customLogAlarmOccurrenceInput)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomLogAlarmOccurrence",
               new KeyValuePair<String, Object>("CustomLogAlarmOccurrenceInput", customLogAlarmOccurrenceInput));

            CustomLogAlarmOccurrenceOutput output = new CustomLogAlarmOccurrenceOutput();
            ICustomAlarmOccurrence inputAlarmOccurrence = _entityFactory.Create<ICustomAlarmOccurrence>();

            _deeContextUtilities.SetContextParameter(IKEAConstants.CustomTerminateAlarmFromAutomation, true);

            try
            {
                // Validate Inputs
                Utilities.ValidateNullInput(customLogAlarmOccurrenceInput);


                // If AlarmOccurrenceUID set -> Acknowledge, Terminate
                if (customLogAlarmOccurrenceInput.AlarmOccurrenceUID != null)
                {
                    // If Log flag active
                    if (customLogAlarmOccurrenceInput.Log)
                    {
                        //Load AlarmOccurence
                        GetObjectByIdInput alarmOccurrenceInput = new GetObjectByIdInput()
                        {
                            Id = customLogAlarmOccurrenceInput.AlarmOccurrenceUID.Value,
                            Type = _entityFactory.Create<ICustomAlarmOccurrence>()
                        };
                        ICustomAlarmOccurrence alarmOccurrence = _genericServiceOrchestration.GetObjectById(alarmOccurrenceInput).Instance as ICustomAlarmOccurrence;
                        if (alarmOccurrence == null)
                        {
                            throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomAlarmNotFound, customLogAlarmOccurrenceInput.AlarmOccurrenceUID.ToString()));
                        }
                        alarmOccurrence.Load();
                        //If terminated > Ignore call
                        if (alarmOccurrence.UniversalState != Foundation.Common.Base.UniversalState.Terminated)
                        {
                            if (customLogAlarmOccurrenceInput.AlarmOperation == CustomAlarmOccurrenceOperationEnum.ToUpdate) // Shift or Update Ack
                            {
                                // Is to Ack
                                if (customLogAlarmOccurrenceInput.AckDate != null && customLogAlarmOccurrenceInput.AckDate > DateTime.MinValue)
                                {
                                    _alarmHandlingUtilities.SetAlarmAckDateIfEmpty(alarmOccurrence, customLogAlarmOccurrenceInput.AckDate);
                                }
                            }
                            if (customLogAlarmOccurrenceInput.AlarmOperation == CustomAlarmOccurrenceOperationEnum.ToEnd)
                            {
                                _alarmHandlingUtilities.SetAlarmAckDateIfEmpty(alarmOccurrence, DateTime.Now);
                                alarmOccurrence.AlarmEnd = DateTime.Now;
                                alarmOccurrence.Save();
                                alarmOccurrence.Terminate();

                                // Obtain all the hold future actions of the material
                                string reasonToUse = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.AlarmHandlingHoldReason);

                                // Get the hold reason to be used
                                IReason reason = _entityFactory.Create<IReason>();
                                reason.Name = reasonToUse;

                                IResource resource = _entityFactory.Create<IResource>();
                                resource.Name = customLogAlarmOccurrenceInput.Resource;

                                if (reason.ObjectExists() && resource.ObjectExists())
                                {
                                    reason.Load();
                                    resource.Load();

                                    IResource topMostResource = resource.GetTopMostResource();
                                    topMostResource.Load();

                                    // get all manufacturing orders
                                    IMaterialCollection manufacturingOrdersAtResource = topMostResource.GetProcessingManufacturingOrders();

                                    foreach (IMaterial manufacturingOrder in manufacturingOrdersAtResource)
                                    {
                                        IFutureActionCollection futureActionsFromMaterial = manufacturingOrder.GetMaterialFutureActionsByType(FutureActionType.Hold);

                                        // Check if the material has any hold future actions
                                        if (!futureActionsFromMaterial.IsNullOrEmpty())
                                        {
                                            IFutureActionCollection futureActionsToRemove = _entityFactory.CreateCollection<IFutureActionCollection>();
                                            futureActionsToRemove.Add(futureActionsFromMaterial.Where(fa => fa.GetNativeValue<long>("Reason") == reason.Id).FirstOrDefault());

                                            // Remove the future action from the material
                                            if (!futureActionsToRemove.IsNullOrEmpty())
                                            {
                                                _materialOrchestration.ManageFutureActions(
                                                                        new ManageFutureActionsInput()
                                                                        {
                                                                            RemovedFutureActions = futureActionsToRemove
                                                                        });

                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    output.AlarmOccurrenceUID = customLogAlarmOccurrenceInput.AlarmOccurrenceUID.Value;
                }
                // If AlarmOccurrenceUID not set
                else
                {
                    IResource resource = _entityFactory.Create<IResource>();
                    resource.Name = customLogAlarmOccurrenceInput.Resource;
                    //only proceeds if there is a resource defined
                    if (resource.ObjectExists())
                    {
                        resource.Load();
                        // If alarm Operation is not CLOSE proceed, otherwise ignore
                        if (customLogAlarmOccurrenceInput.AlarmOperation != CustomAlarmOccurrenceOperationEnum.ToEnd)
                        {
                            string resolvedCategory = null;
                            string resolvedType = null;
                            string resolvedSeverity = null;
                            string notificationDetail = null;
                            string severity = null;
                            string type = null;
                            string category;
                            output.IsToBlockFeeder = false;

                            //Resolve smart table and retrieve Category, Type and Severity information
                            Dictionary<string, string> dictionaryToReturn = new Dictionary<string, string>();
                            dictionaryToReturn = _iKEAUtilities.ResolveCustomAlarmCategoryBreakdown(customLogAlarmOccurrenceInput.AlarmCategory, resource.Area.Facility, resource.Area, resource.ResourceType, resource);

                            if (!dictionaryToReturn.IsNullOrEmpty())
                            {
                                resolvedCategory = dictionaryToReturn["Category"];
                                resolvedType = dictionaryToReturn["Type"];
                                resolvedSeverity = dictionaryToReturn["Severity"];

                                if (!customLogAlarmOccurrenceInput.AlarmMessage.IsNullOrEmpty())
                                {
                                    notificationDetail = _iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomAlarmLoggedAndCheckedLocalizedMessage
                                                                                           , resolvedType
                                                                                           , resolvedCategory
                                                                                           , resolvedSeverity
                                                                                           , customLogAlarmOccurrenceInput.AlarmMessage);
                                }
                                else
                                {
                                    notificationDetail = _iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomAlarmLoggedAndCheckedNoDetailsLocalizedMessage
                                                                                           , resolvedType
                                                                                           , resolvedCategory
                                                                                           , resolvedSeverity);
                                }
                            }

                            // Set Severity:
                            severity = resolvedSeverity != null ? resolvedSeverity : _iKEAUtilities.GetValueFromConfigurationWithPath(IKEAConstants.DefaultNotificationSeverityConfig);
                            severity = _iKEAUtilities.GetValueFromLookupTable(IKEAConstants.NotificationSeverityLookupTableName, severity, true);

                            // Set Type:
                            type = resolvedType != null ? resolvedType : "System";

                            // Set Category:
                            category = resolvedCategory != null ? resolvedCategory : customLogAlarmOccurrenceInput.AlarmCategory;

                            // //If log flag is active, check if it is necessary to log the alarm in MES
                            bool? logAlarm = false;
                            if (customLogAlarmOccurrenceInput.Log)
                            {
                                logAlarm = _alarmHandlingUtilities.ResolveCustomAlarmTrackingConfiguration(resource.Area.Facility.Name,
                                                                                                 resource.Area.Name,
                                                                                                 resource.Name,
                                                                                                 customLogAlarmOccurrenceInput.AlarmCode,
                                                                                                 customLogAlarmOccurrenceInput.AlarmCategory);
                            }

                            if (logAlarm ?? false)
                            {
                                DateTime? start = customLogAlarmOccurrenceInput.StartDate;
                                DateTime? ack = null;
                                DateTime? end = null;
                                bool isMicroStop = customLogAlarmOccurrenceInput.AlarmCode.CompareStrings(_genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.MicroStopIdentifier));
                                if (isMicroStop)
                                {
                                    ack = customLogAlarmOccurrenceInput.AckDate;
                                    end = customLogAlarmOccurrenceInput.EndDate;

                                    if (start == null || end == null || end < start)
                                    {
                                        throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomLogMicroStopAlarmOccurrenceError));
                                    }
                                }
                                IResource topMostResource = resource.GetTopMostResource();


                                string alarmMaterial = String.Empty;

                                if (!String.IsNullOrEmpty(customLogAlarmOccurrenceInput.Material))
                                {
                                    alarmMaterial = customLogAlarmOccurrenceInput.Material;
                                }
                                else
                                {
                                    IMaterialCollection materialMOCollection = topMostResource.GetProcessingManufacturingOrders();

                                    if (materialMOCollection != null && materialMOCollection.FirstOrDefault() != null)
                                    {
                                        alarmMaterial = materialMOCollection.FirstOrDefault().Name;
                                    }
                                }

                                ICustomAlarmOccurrence alarmOccurrence = _entityFactory.Create<ICustomAlarmOccurrence>();
                                alarmOccurrence.Resource = resource;
                                alarmOccurrence.Area = resource.Area;
                                alarmOccurrence.Facility = resource.Area.Facility;
                                alarmOccurrence.AlarmStart = start;
                                // AlarmAck is set as attribute
                                alarmOccurrence.AlarmEnd = end;
                                alarmOccurrence.AlarmCategory = category;
                                alarmOccurrence.AlarmSeverity = severity;
                                alarmOccurrence.AlarmType = type;
                                alarmOccurrence.AlarmMessage = customLogAlarmOccurrenceInput.AlarmMessage;
                                alarmOccurrence.AlarmCode = customLogAlarmOccurrenceInput.AlarmCode;
                                //MainStateModelStateReason = resource.CurrentMainState.Reason,
                                alarmOccurrence.TopMostResource = topMostResource;
                                alarmOccurrence.Material = alarmMaterial;

                                //Create new CustomAlarmOccurrence entry based on input parameters. use GenericServiceManagement.CreateObject 
                                //to ensure default name generator is used. do not set a Name for the object as this will be handled by the Core orchestration
                                CreateObjectInput alarmOccurrenceInput = new CreateObjectInput()
                                {
                                    Object = alarmOccurrence,
                                    NameGeneratorName = IKEAConstants.AlarmNotificationNameGeneratorName,
                                };
                                alarmOccurrence = _genericServiceOrchestration.CreateObject(alarmOccurrenceInput).Object as ICustomAlarmOccurrence;
                                if (customLogAlarmOccurrenceInput.AckDate != null)
                                {
                                    alarmOccurrence.LoadAttribute("AlarmAck");
                                    alarmOccurrence.Attributes["AlarmAck"] = DateTime.Now;
                                    alarmOccurrence.SaveAttributes(alarmOccurrence.Attributes);
                                }

                                //Set Alarm UID in the output
                                output.AlarmOccurrenceUID = alarmOccurrence.Id;

                                // If it is a Micro Stop terminate object
                                if (isMicroStop)
                                {
                                    alarmOccurrence.Terminate();
                                }
                                inputAlarmOccurrence = alarmOccurrence;
                            }

                            string areaName = resource.Area.Name;
                            string facilityName = resource.Area.Facility.Name;
                            string topMostResourceName = resource.GetTopMostResource().Name;

                            //Resolve CustomAlarmHandlingActions Smart Table
                            DataRow datarow = _alarmHandlingUtilities.ResolveCustomAlarmHandlingActions(customLogAlarmOccurrenceInput.AlarmCode
                                , customLogAlarmOccurrenceInput.AlarmCategory
                                , topMostResourceName
                                , areaName
                                , facilityName);

                            if (datarow != null)
                            {
                                //Invoke AlarmHandlerUtility
                                _alarmHandlingUtilities.AlarmOccurrenceHandlingUtility(datarow
                                    , inputAlarmOccurrence
                                    , customLogAlarmOccurrenceInput.AlarmCode
                                    , customLogAlarmOccurrenceInput.AlarmCategory
                                    , customLogAlarmOccurrenceInput.Resource
                                    , topMostResourceName
                                    , areaName
                                    , facilityName
                                    , notificationDetail);

                                if (!String.IsNullOrWhiteSpace((datarow[IKEAConstants.BlockFeeder] ?? String.Empty).ToString()))
                                {
                                    output.IsToBlockFeeder = datarow.Field<bool>(IKEAConstants.BlockFeeder);
                                }
                            }
                        }
                    }
                    else
                    {
                        throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomResourceNotFound, resource.Name));
                    }
                }

            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            finally
            {
                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomLogAlarmOccurrenceInput", customLogAlarmOccurrenceInput),
                                            new KeyValuePair<String, Object>("CustomLogAlarmOccurrenceOutput", output));
            }

            return output;
        }

        /// <summary>
        /// Service to return time per state data
        /// </summary>
        /// <param name="input">Input Object</param>
        /// <returns>Output Object</returns>
        public CustomGetDataForEPMOutput CustomGetDataForEPM(CustomGetDataForEPMInput input)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomGetDataForEPM",
                new KeyValuePair<String, Object>("CustomGetDataForEPMInput", input));

            CustomGetDataForEPMOutput output = new CustomGetDataForEPMOutput();

            try
            {
                Utilities.ValidateNullInput(input);

                TransactionOptions options = new TransactionOptions();
                INgpDataSet ngpStateSummary = new NgpDataSet();

                //Validate if the input is a list with a single string, if so, send null in the resource list to the KPIManager service
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Suppress, options))
                {
                    ngpStateSummary = (input.Resources != null && input.Resources.Count == 1 && input.Resources[0] != "")
                        ? KPIManager.GetResourcePerfomanceStateChangeSummary(input.TimeFrame, input.GetActual, input.Resources, input.ResourceTypes, input.ResourceResourceTypes)
                        : KPIManager.GetResourcePerfomanceStateChangeSummary(input.TimeFrame, input.GetActual, null, input.ResourceTypes, input.ResourceResourceTypes);
                }

                // Create a Dataset to parse data
                DataSet dsStateSummary = NgpDataSet.ToDataSet(ngpStateSummary);
                // Validate if dataset has values 
                // > Need to use full namespace because HasData is defined in two DLL's so call would be ambiguous
                if (dsStateSummary.HasData())
                {
                    if (input.StatesMapping != null)
                    {
                        System.Data.DataTable newDataTable = dsStateSummary.Tables[0].Clone();

                        // Get Values from DataTable aggregating them depending on input.StatesMapping
                        foreach (var item in input.StatesMapping)
                        {
                            if (!item.Key.CompareStrings("$id"))
                            {
                                StringBuilder stringBuilder = new StringBuilder();
                                // Serialization sets "Item.Value" to NULL when the Key is equal to Value and there is only one value in the Value list
                                // If it has values > State in (list_of_values)
                                if (!item.Value.IsNullOrEmpty())
                                {
                                    stringBuilder.AppendFormat("State IN ('{0}')", string.Join("','", item.Value));
                                }
                                else
                                {
                                    // else state is the key value of the Dictionary
                                    stringBuilder.AppendFormat("State = '{0}' ", item.Key);
                                }

                                // Build filter to find Rows to sum
                                DataRow[] dataRows = dsStateSummary.Tables[0].Select(stringBuilder.ToString());

                                decimal? duration = dataRows != null ? dataRows.Where(row => row["Duration"] != null)
                                                                               .Sum(row => row.Field<decimal?>("Duration"))
                                                                     : null;

                                decimal? ratio = dataRows != null ? dataRows.Where(row => row["Ratio"] != null)
                                                                            .Sum(row => row.Field<decimal>("Ratio"))
                                                                  : null;

                                // Add Values to new DataTable
                                DataRow rowToAdd = newDataTable.NewRow();
                                rowToAdd["State"] = item.Key;
                                rowToAdd["Duration"] = duration;
                                rowToAdd["Ratio"] = ratio;
                                newDataTable.Rows.Add(rowToAdd);
                            }
                        }

                        dsStateSummary.Tables[0].Rows.Clear();
                        foreach (DataRow item in newDataTable.Rows)
                        {
                            dsStateSummary.Tables[0].ImportRow(item);
                        }
                    }
                    else
                    {
                        // Return all the data set columns without column 'Total'
                        foreach (DataRow row in dsStateSummary.Tables[0].Select())
                        {
                            if (row.Field<string>("State").CompareStrings("TOTAL"))
                            {
                                dsStateSummary.Tables[0].Rows.Remove(row);
                            }
                        }
                    }

                    dsStateSummary.Tables[0].AcceptChanges();
                    output.StateSummary = NgpDataSet.FromDataSet(dsStateSummary);

                }
                //No data was retrieved
                else
                {
                    output.StateSummary = new NgpDataSet();
                }

                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomGetDataForEPMInput", input),
                                            new KeyValuePair<String, Object>("CustomGetDataForEPMOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            return output;
        }

        /// <summary>
        /// Service that will test MES > ERP communication
        /// </summary>
        /// <param name="customERPCommunicationTestInput">Input Object</param>
        /// <returns>Output Objects</returns>
        public CustomERPCommunicationTestOutput CustomERPCommunicationTest(CustomERPCommunicationTestInput customERPCommunicationTestInput)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomERPCommunicationTest",
               new KeyValuePair<String, Object>("CustomERPCommunicationTestInput", customERPCommunicationTestInput));

            CustomERPCommunicationTestOutput output = new CustomERPCommunicationTestOutput();

            try
            {
                string cono = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.CompanyCodeConfig);
                // Mandatory property to send in request
                Dictionary<string, string> values = new Dictionary<string, string>();
                values.Add("CONO", cono);

                // Call API on LstDivisions to test token access and request with token
                output.ServiceOutput = _erpUtilities.SendERPMessage(values, "MNS100MI/LstDivisions");

                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomERPCommunicationTestInput", customERPCommunicationTestInput),
                                            new KeyValuePair<String, Object>("CustomERPCommunicationTestOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            return output;
        }

        /// <summary>
        /// Retrieve the setup state for a selected material
        /// </summary>
        /// <param name="customGetMaterialSetupStateInput">Input Object</param>
        /// <returns>Output Objects</returns>
        public CustomGetMaterialSetupStateOutput CustomGetMaterialSetupState(CustomGetMaterialSetupStateInput customGetMaterialSetupStateInput)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomGetMaterialSetupState",
               new KeyValuePair<String, Object>("CustomGetMaterialSetupStateInput", customGetMaterialSetupStateInput));

            CustomGetMaterialSetupStateOutput output = new CustomGetMaterialSetupStateOutput();

            try
            {
                Utilities.ValidateNullInput(customGetMaterialSetupStateInput);

                customGetMaterialSetupStateInput.Material.Load();
                IMaterial mainMaterial = customGetMaterialSetupStateInput.Material;

                CustomSetupConsumptionDetailCollection customSetupConsumptionDetail = new CustomSetupConsumptionDetailCollection();

                // Get SetupConsumptionDetail of the MO, multiple MOs in case of groupMO
                if (mainMaterial.IsGroupMO())
                {
                    // Get all materials inside of GroupMO
                    List<IMaterial> materialsToIterate = new List<IMaterial>();
                    materialsToIterate.AddRange(_iKEAUtilities.GetChildMaterialsFromGroupMO(mainMaterial));

                    // For each child, iterate through all setup consumption details
                    foreach (IMaterial child in materialsToIterate)
                    {
                        CustomSetupConsumptionDetailCollection childConsumptionDetailCollection = _iKEAUtilities.SetupConsumptionUtility(child);

                        // For every details, check if collection already has it (validated through the Consumable feed, attached product and expected product), if it has then add to total order requirement
                        // Use this to eliminate repeated expected products from list to show the total requirement for each product for all groupMO instead for each individual MO
                        foreach (CustomSetupConsumptionDetail detail in childConsumptionDetailCollection)
                        {
                            var consumptionDetail = customSetupConsumptionDetail.Where(csc => csc.ExpectedProduct.Equals(detail.ExpectedProduct)
                                                                                                && csc.ConsumableFeed.Name.Equals(detail.ConsumableFeed.Name)
                                                                                                && ((csc.CurrentlyAttachedProduct == null && detail.CurrentlyAttachedProduct == null) ||
                                                                                                csc.CurrentlyAttachedProduct.Equals(detail.CurrentlyAttachedProduct))
                                                                                                ).FirstOrDefault();

                            // Caculate the necessary quantity to produce one pallet
                            decimal toProduce = 0;
                            foreach (IBOMProduct bp in detail.BOM.BomProducts)
                            {
                                if (bp.TargetEntity.Name.Equals(detail.ExpectedProduct.Name))
                                {
                                    toProduce += bp.Quantity ?? 0;
                                }
                            }
                            detail.ToProducePallet = toProduce;

                            // If Setup Consumption Detail already exists for this product then just add it. Used to not have repeated entry in the BOM tab of setupState
                            if (consumptionDetail != null)
                            {
                                int index = customSetupConsumptionDetail.IndexOf(consumptionDetail);
                                customSetupConsumptionDetail[index].TotalOrderRequirement += detail.TotalOrderRequirement;
                                customSetupConsumptionDetail[index].ToProducePallet += detail.ToProducePallet;
                            }
                            else
                            {
                                customSetupConsumptionDetail.Add(detail);
                            }
                        }
                    }

                    // Calculate the necessary quantity for all the pallets according to the numberOfCycles of the GroupMO to display
                    // Quantity neccessary for one pallet * number of pallets in default
                    decimal numberOfCycles = mainMaterial.GetAttributeValueOrDefault<decimal>("DefaultCompletedQuantity", true);
                    foreach (CustomSetupConsumptionDetail detail in customSetupConsumptionDetail)
                    {
                        detail.ToProducePallet *= numberOfCycles;
                    }

                }
                else
                {
                    customSetupConsumptionDetail = _iKEAUtilities.SetupConsumptionUtility(customGetMaterialSetupStateInput.Material);
                }

                if (customSetupConsumptionDetail != null && customSetupConsumptionDetail.Count() > 0)
                {
                    output.CustomSetupConsumptionDetail = customSetupConsumptionDetail;

                    customGetMaterialSetupStateInput.Material.LoadAttributes();
                    output.Material = customGetMaterialSetupStateInput.Material;

                    // Get Past Consumption
                    if (customGetMaterialSetupStateInput.Material.LastProcessedResource != null)
                    {
                        //If it's a groupMO it gets all the past consumption of each child
                        if (mainMaterial.IsGroupMO())
                        {
                            // To store the consumptions
                            Dictionary<string, List<PalletConsumptionStructure>> gmoPastConsumptions = new Dictionary<string, List<PalletConsumptionStructure>>();

                            // Get all materials inside of GroupMO
                            List<IMaterial> materialsToIterate = new List<IMaterial>();
                            materialsToIterate.AddRange(_iKEAUtilities.GetChildMaterialsFromGroupMO(mainMaterial));

                            // List with current consumption of the MOs
                            Dictionary<string, List<PalletConsumptionStructure>> currentConsumption = new Dictionary<string, List<PalletConsumptionStructure>>();

                            foreach (IMaterial child in materialsToIterate)
                            {
                                // Get Past Consumption of child
                                Dictionary<string, List<PalletConsumptionStructure>> childPastConsumption = _iKEAUtilities.GetPastConsumption(mainMaterial.LastProcessedResource, child);


                                // Iterate through the consumption in order to verify if there already is a value for each specific feeder
                                // and if there is, add the consumption to the list
                                foreach (string feeder in childPastConsumption.Keys)
                                {
                                    if (gmoPastConsumptions.ContainsKey(feeder))
                                    {
                                        // Add child consumption to already existing list and organize it by date
                                        gmoPastConsumptions[feeder].AddRange(childPastConsumption[feeder]);
                                        gmoPastConsumptions[feeder] = gmoPastConsumptions[feeder].OrderBy(c => c.ConsumptionFinishedOn).ToList();
                                    }
                                    else
                                    {
                                        gmoPastConsumptions.Add(feeder, childPastConsumption[feeder]);
                                    }
                                }
                            }

                            output.PastConsumptions = gmoPastConsumptions;
                        }
                        else
                        {
                            output.PastConsumptions = _iKEAUtilities.GetPastConsumption(customGetMaterialSetupStateInput.Material.LastProcessedResource, customGetMaterialSetupStateInput.Material);
                        }
                    }
                }

                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomGetMaterialSetupStateInput", customGetMaterialSetupStateInput),
                                            new KeyValuePair<String, Object>("CustomGetMaterialSetupStateOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            return output;
        }

        /// <summary>
        /// Update the BomProduct relation attributes
        /// </summary>
        /// <param name="customUpdateBomProductsAttributesInput">Input Object</param>
        /// <returns>Output Objects</returns>
        public CustomUpdateBomProductsAttributesOutput CustomUpdateBomProductsAttributes(CustomUpdateBomProductsAttributesInput customUpdateBomProductsAttributesInput)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomUpdateBomProductsAttributes",
               new KeyValuePair<String, Object>("CustomUpdateBomProductsAttributesInput", customUpdateBomProductsAttributesInput));

            CustomUpdateBomProductsAttributesOutput output = new CustomUpdateBomProductsAttributesOutput();

            try
            {
                Utilities.ValidateNullInput(customUpdateBomProductsAttributesInput);

                if (customUpdateBomProductsAttributesInput.ProductsToUpdate.Count > 0)
                {
                    Dictionary<IBOMProduct, IAttributeCollection> bomCollection = new Dictionary<IBOMProduct, IAttributeCollection>();
                    foreach (var relation in customUpdateBomProductsAttributesInput.ProductsToUpdate)
                    {
                        IBOMProduct bomProduct = _entityFactory.Create<IBOMProduct>();
                        bomProduct.Load(Int64.Parse(relation.Key));
                        IAttributeCollection aCol = new AttributeCollection();
                        aCol.AddRange(relation.Value);
                        bomCollection.Add(bomProduct, aCol);
                    }
                    _iKEAUtilities.SaveAttributesToMultipleBOMProducts(bomCollection);
                }

                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomUpdateBomProductsAttributesInput", customUpdateBomProductsAttributesInput),
                                            new KeyValuePair<String, Object>("CustomUpdateBomProductsAttributesOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            return output;
        }

        /// <summary>
        /// Transfer the material to the given resource.
        ///     If resource is of type storage, stores material.
        ///     If resource is of type consumable feed, attaches it to the consumable feed.
        /// </summary>
        /// <param name="CustomLogMaterialMovementInput">Input Object</param>
        /// <returns>Output Objects</returns>
        public CustomLogMaterialMovementOutput CustomLogMaterialMovement(CustomLogMaterialMovementInput customLogMaterialMovementInput)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomLogMaterialMovement",
               new KeyValuePair<String, Object>("CustomLogMaterialMovementInput", customLogMaterialMovementInput));

            CustomLogMaterialMovementOutput output = new CustomLogMaterialMovementOutput();



            try
            {
                IMaterial materialGenerated = null;
                Utilities.ValidateNullInput(customLogMaterialMovementInput, new List<string>() { "MaterialBatch", "TargetResource", "SelectedMO" });

                IMaterialCollection materialsToTransfer = _entityFactory.CreateCollection<IMaterialCollection>();
                materialsToTransfer.Add(customLogMaterialMovementInput.MaterialToTransfer);
                IMaterial materialToTransferFromInput = customLogMaterialMovementInput.MaterialToTransfer;


                IMaterial selectedMO = _entityFactory.Create<IMaterial>();
                if (customLogMaterialMovementInput.SelectedMO != null)
                {
                    selectedMO.Name = customLogMaterialMovementInput.SelectedMO;
                    selectedMO.Load();
                }


                // reset ERP Original Name if incoming
                materialToTransferFromInput.Attributes[IKEAConstants.CustomMaterialAttributeERPOriginalName] = null;

                IMaterial batchMaterial = customLogMaterialMovementInput.MaterialBatch;

                bool materialExists = materialToTransferFromInput.ObjectExists();

                // Get the input flag that indicates if the the scan is for manual loading of the line:
                bool isManualLoading = customLogMaterialMovementInput.IsManualLoading;

                string originalMaterialName = null;

                // Check if the given material already exists or needs to be created
                if (materialExists)
                {
                    // Verify if the material to attach is of type = ReRun
                    if (materialToTransferFromInput.Type == _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.CustomReRunMaterialDefaultTypePath))
                    {
                        // Verify if ReRun pallet is in the correct step before being attached to the Consumable feed, according to the expected step in the BOM Product
                        _iKEAUtilities.ValidateReRunPalletCurrentAndExpectedStepAtAttach(materialToTransferFromInput);
                    }

                    // Check if no Primary quantity was set, if so, load the material to get the primary quantity
                    if (!materialToTransferFromInput.PrimaryQuantity.HasValue)
                    {
                        materialToTransferFromInput.Load();
                    }

                    // Store the name of the material:
                    originalMaterialName = materialToTransferFromInput.Name;

                    // PrimaryQuantity is set on GUI with the quantity inserted on the Wizard, it must be stored before doing Loading the Material 
                    decimal materialToTransferInputQuantity = materialToTransferFromInput.PrimaryQuantity.GetValueOrDefault();

                    decimal materialToTransferInputSecondaryQuantity = materialToTransferFromInput.SecondaryQuantity.GetValueOrDefault();

                    // Load the material to get the original values
                    materialToTransferFromInput.Load();
                    materialToTransferFromInput.LoadAttributes(new Collection<string>() { IKEAConstants.CustomMaterialAttributeCurrentIteration, IKEAConstants.CustomMaterialAttributeCreationArea });

                    if (materialToTransferInputQuantity <= decimal.Zero && materialToTransferInputSecondaryQuantity <= decimal.Zero)
                    {
                        //If the request quantity and secondary quantity are not greater than zero, an exception is throw
                        throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomMaterialTransferMovementInvalidQuantity, materialToTransferInputQuantity.ToString(),
                                                                                                                                                  materialToTransferFromInput.Name));
                    }
                    else if (materialToTransferInputQuantity > materialToTransferFromInput.PrimaryQuantity)
                    {
                        // If the requested quantity is superior to the one available in the material, an exception needs to be displayed
                        throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomMaterialTransferMovementInsufficientQuantityLocalizedMessage, materialToTransferInputQuantity.ToString(),
                                                                                                                                                                        materialToTransferFromInput.PrimaryQuantity.GetValueOrDefault().ToString(),
                                                                                                                                                                        materialToTransferFromInput.Form,
                                                                                                                                                                        materialToTransferFromInput.Name));
                    }
                    else if ((materialToTransferInputQuantity == materialToTransferFromInput.PrimaryQuantity.GetValueOrDefault() && isManualLoading)
                                || (materialToTransferInputQuantity < materialToTransferFromInput.PrimaryQuantity.GetValueOrDefault() && customLogMaterialMovementInput.SplitQuantity == decimal.Zero))
                    {
                        // Just in the case of manual loading we can split the whole quantity (the parent with 0 parts will be terminated)
                        // Split the material using the quantity to transfer

                        IMaterialCollection materials = materialToTransferFromInput.SplitMaterial(primaryQuantity: materialToTransferInputQuantity,
                                                                                        allowAutomaticFeederMaterialSplit: isManualLoading);

                        if (!materials.IsNullOrEmpty())
                        {
                            materialsToTransfer[0] = materials[0];
                            materialGenerated = materials[0];
                            materialsToTransfer.FirstOrDefault().Load();
                        }
                    }
                    else if (customLogMaterialMovementInput.SplitQuantity > decimal.Zero)
                    {
                        IMaterial materialToSplit = materialToTransferFromInput;
                        materialsToTransfer.RemoveAt(0);

                        decimal currentMaterialQuantity = materialToTransferInputQuantity;
                        int numberOfSplits = (int)Math.Ceiling(materialToTransferInputQuantity / customLogMaterialMovementInput.SplitQuantity);

                        for (int i = 0; i < numberOfSplits; i++)
                        {
                            materialToSplit.Load();
                            decimal quantityToSplit = currentMaterialQuantity > customLogMaterialMovementInput.SplitQuantity ? customLogMaterialMovementInput.SplitQuantity : currentMaterialQuantity;
                            materialsToTransfer.Add(materialToSplit.SplitMaterial(primaryQuantity: quantityToSplit, terminateOnZeroQuantity: true)[0]);
                            currentMaterialQuantity -= customLogMaterialMovementInput.SplitQuantity;
                        }

                    }
                    else
                    {
                        // If it is not to split nor manual loading, add the material from input to the material collection
                        materialsToTransfer[0] = materialToTransferFromInput;
                    }


                    // CHeck if there are any material quantities to be merged
                    if (!customLogMaterialMovementInput.MaterialQuantitiesToMerge.IsNullOrEmpty())
                    {
                        string materialArea = materialsToTransfer.FirstOrDefault().GetAttributeValueOrDefault<string>(IKEAConstants.CustomMaterialAttributeCreationArea);
                        int materialIteration = materialsToTransfer.FirstOrDefault().GetAttributeValueOrDefault<int>(IKEAConstants.CustomMaterialAttributeCurrentIteration);

                        // Load the material to be merged
                        IMaterialCollection materials = _entityFactory.CreateCollection<IMaterialCollection>(); ;
                        materials.AddRange(customLogMaterialMovementInput.MaterialQuantitiesToMerge.Select(mq => { var m = _entityFactory.Create<IMaterial>(); m.Name = mq.Key; return m; }));
                        materials.Load();

                        materials.LoadAttributes(new Collection<string>() { IKEAConstants.CustomMaterialAttributeCurrentIteration, IKEAConstants.CustomMaterialAttributeCreationArea });

                        // Check if any of the materials to merge don't match with the one to transfer
                        List<string> invalidMaterials = materials
                            .Where(m => !m.Form.CompareStrings(materialsToTransfer.FirstOrDefault().Form)
                                    || !m.Type.CompareStrings(materialsToTransfer.FirstOrDefault().Type)
                                    || !m.GetAttributeValueOrDefault<string>(IKEAConstants.CustomMaterialAttributeCreationArea).CompareStrings(materialArea)
                                    || (
                                        // Prevent merge of materials with different iterations only if type is 'DirectRepair' or 'ReRun'.
                                        // All other types can ignore differnt iterations.
                                        m.GetAttributeValueOrDefault<int>(IKEAConstants.CustomMaterialAttributeCurrentIteration) != materialIteration)
                                        && (m.Type == IKEAConstants.MaterialTypeDirectRepair || m.Type == IKEAConstants.MaterialTypeReRun)
                                        )
                            .Select(m => m.Name).ToList();

                        if (!invalidMaterials.IsNullOrEmpty())
                        {
                            throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomMaterialTransferInvalidMergeMaterialsLocalizedMessage, string.Join(", ", invalidMaterials)));
                        }

                        Dictionary<IMaterial, IMergeMaterialParameters> materialsToMerge = new Dictionary<IMaterial, IMergeMaterialParameters>();

                        // Go through all the materials to merge and check if any of them need to be split before merge
                        foreach (var material in materials)
                        {
                            decimal quantityToUse = customLogMaterialMovementInput.MaterialQuantitiesToMerge[material.Name];

                            if (quantityToUse <= decimal.Zero)
                            {
                                throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomMaterialTransferMovementInvalidQuantity, quantityToUse.ToString(),
                                                                                                                                                  material.Name));
                            }
                            else if (quantityToUse > material.PrimaryQuantity.GetValueOrDefault())
                            {
                                throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomMaterialTransferMovementInsufficientQuantityLocalizedMessage, quantityToUse.ToString(),
                                                                                                                                                material.PrimaryQuantity.GetValueOrDefault().ToString(),
                                                                                                                                                material.Form,
                                                                                                                                                material.Name));
                            }
                            else if (material.PrimaryQuantity.GetValueOrDefault() > quantityToUse)
                            {
                                // When the quantity in the material is superior to the one that should be use
                                // we need to split the quantity to use from the material

                                IMaterialCollection materialsSplit = material.SplitMaterial(primaryQuantity: quantityToUse);

                                foreach (var mat in materialsSplit)
                                {
                                    materialsToMerge.Add(mat, new MergeMaterialParameters());
                                }
                            }
                            else
                            {
                                materialsToMerge.Add(material, new MergeMaterialParameters());
                            }
                        }

                        //Check if necessary to detach the material before merge. Disallow merging pallets in state consumable into material of state queued
                        foreach (var material in materialsToMerge.Keys)
                        {
                            switch (material.SystemState)
                            {
                                case MaterialSystemState.Consumable:
                                    if (materialsToTransfer.FirstOrDefault().SystemState == MaterialSystemState.Queued)
                                    {
                                        material.LoadRelations(Navigo.Common.Constants.MaterialResource);

                                        if (material.MaterialResourceRelations.Count > 0)
                                        {
                                            IResource resourceToDetach = material.MaterialResourceRelations[0].TargetEntity;
                                            var mc = _entityFactory.CreateCollection<IMaterialCollection>();
                                            mc.Add(material);
                                            resourceToDetach.DetachConsumablesFromResource(mc);
                                            material.Load();
                                        }
                                        else
                                        {
                                            throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomStopMaterialResourceNotFoundMessage, material.Name));
                                        }
                                    }
                                    break;

                                case MaterialSystemState.Queued:
                                    if (materialsToTransfer.FirstOrDefault().SystemState == MaterialSystemState.Consumable)
                                    {
                                        throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomMaterialTransferMovementAttachMaterialLocalizedMessage, material.Name));
                                    }
                                    break;
                            }
                        }

                        // Merge all the materials into the material to transfer
                        materialsToTransfer.FirstOrDefault().Merge(materialsToMerge);
                    }
                }

                if (customLogMaterialMovementInput.TargetResource != null)
                {
                    IResource resource = customLogMaterialMovementInput.TargetResource;
                    resource.Load();
                    // Only Move the material if the resource is a Storage or a Consumable Feed
                    if (resource.ProcessingType == ProcessingType.Storage || resource.ProcessingType == ProcessingType.ConsumableFeed)
                    {
                        decimal existingPalletQuantity = customLogMaterialMovementInput.ExistingPalletQuantity ?? 0;
                        bool isExistingPalletCompleted = customLogMaterialMovementInput.IsExistingPalletCompleted ?? false;
                        decimal numberOfCompletedPallets = customLogMaterialMovementInput.NumberOfCompletedPallets ?? 0;
                        decimal defaultCompletionQuantity = customLogMaterialMovementInput.DefaultCompletionQuantity ?? 0;
                        decimal incompletePalletQuantity = customLogMaterialMovementInput.IncompletePalletQuantity ?? 0;

                        // Get the input flag that indicates if the the scan contains outsorting pieces:
                        bool isFeederOutsorting = existingPalletQuantity > 0 || numberOfCompletedPallets > 0 || incompletePalletQuantity > 0;

                        // Check table 'CustomManualLoadingConfiguration' to validate if manual loading is enabled for this feeder:
                        if (isManualLoading)
                        {
                            if (!_iKEAUtilities.GetManualLoadingStatus(resource))
                            {
                                throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomManualLoadingNotAllowedForResourceLocalizedMessage, resource.Name));
                            }
                        }

                        // Check table 'CustomFeederOutSortingConfiguration' to validate if feeder outsorting is enabled for this feeder:
                        if (isFeederOutsorting)
                        {
                            if (!_iKEAUtilities.GetFeederOutsortedStatus(resource))
                            {
                                throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomFeederOutsortingNotAllowedForResourceLocalizedMessage, resource.Name));
                            }
                        }

                        // If the resource automation mode is not Online, the flag should be overriden with False:
                        if (resource.AutomationMode != ResourceAutomationMode.Online)
                        {
                            isManualLoading = false;
                        }

                        // If the material does not exist then creates it, based on the information already set in the instance
                        if (!materialExists)
                        {
                            if (materialToTransferFromInput.Product != null)
                            {
                                // Check if the material's Product is a substitute of a product of a SFG in the current BOM
                                // If so throw an exception with the BOMs 
                                IBOMCollection bomInProcess = _iKEAUtilities.GetBOMOfMaterialsInProgressInResource(resource.Id, true);
                                if (bomInProcess.Count > 0)
                                {
                                    bomInProcess.LoadBomProducts(materialToTransferFromInput.Step, materialToTransferFromInput.LogicalFlowPath);
                                    materialToTransferFromInput.Product.Load();
                                    List<IBOM> boms = new List<IBOM>();

                                    List<IBOM> bomWithMaterialProduct = bomInProcess.Where(bom => bom.BomProducts.Any(bomProduct => bomProduct.TargetEntity.Id == materialToTransferFromInput.Product.Id)).ToList();

                                    string semiFinishGoodProductType = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.CustomSemiFinishGoodProductType);

                                    foreach (var bom in bomWithMaterialProduct)
                                    {
                                        List<IBOMProduct> listOfSubstitutes = bom.BomProducts.Where(bOMProduct => bOMProduct.SourceEntity.UniversalState == UniversalState.Effective && bOMProduct.TargetEntity.Id == materialToTransferFromInput.Product.Id && bOMProduct.Parent != null
                                            && bOMProduct.Parent.TargetEntity.Id != materialToTransferFromInput.Product.Id && (bOMProduct.Parent.TargetEntity.Type == semiFinishGoodProductType || bOMProduct.Parent.TargetEntity.ProductType == ProductType.SemiFinishedGood)).ToList();
                                        if (!listOfSubstitutes.IsNullOrEmpty())
                                        {
                                            // Get the BOM names as a comma-separated string
                                            List<IBOM> bomsToAdd = listOfSubstitutes.Select(e => e.SourceEntity).ToList();
                                            boms.AddRange(bomsToAdd);
                                        }
                                    }
                                    if (!boms.IsNullOrEmpty())
                                    {
                                        throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomScanSubstituteProductFromSFG, string.Join(", ", boms.Select(bom => bom.Name))));
                                    }
                                }
                            }
                            #region Test mandatory expiration date
                            IArea area = resource.Area;
                            string facilityName = null;
                            if (area != null)
                            {
                                area.Load();
                                facilityName = area.Facility?.Name ?? null;
                            }
                            if (_iKEAUtilities.ResolveCustomExpirationDateRequirementContext(facilityName: facilityName, areaName: area.Name, resourceName: resource.Name, productName: materialToTransferFromInput.Product.Name))
                            {
                                if (customLogMaterialMovementInput.MaterialExpirationDate == null)
                                {
                                    throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomMaterialExpirationDateIsMandatoryLocalizedMessage));
                                }
                            }
                            #endregion

                            string batchName = null;

                            IProduct product = materialToTransferFromInput.Product;
                            product.Load(materialToTransferFromInput.Product.Name);
                            materialToTransferFromInput.Product = product;

                            if (materialToTransferFromInput.Facility == null)
                            {
                                materialToTransferFromInput.Facility = resource.Area.Facility;
                            }

                            if (string.IsNullOrWhiteSpace(materialToTransferFromInput.PrimaryUnits))
                            {
                                materialToTransferFromInput.PrimaryUnits = product.DefaultUnits;
                            }

                            // Check if the material batch exists
                            if (batchMaterial != null && !string.IsNullOrWhiteSpace(batchMaterial.Name))
                            {
                                // Get Batch material name from the relation
                                batchName = batchMaterial.Name;

                                // Set the batch as the base material of the new material
                                materialToTransferFromInput.Attributes[IKEAConstants.CustomMaterialAttributeBaseMaterial] = batchMaterial.Name;

                                // Associate batch to the material
                                _automaticMaterialCreationUtilities.SetMaterialBatch(batchName, ref materialToTransferFromInput);
                            }

                            String nameGeneratorToUse = null;
                            if (string.IsNullOrWhiteSpace(materialToTransferFromInput.Name) && !string.IsNullOrWhiteSpace(batchName))
                            {
                                // name generator to be used for generating the name
                                nameGeneratorToUse = _iKEAUtilities.GetMaterialNameGenerator(materialToTransferFromInput.Form);

                                // Fall back to standard material name generator
                                if (String.IsNullOrWhiteSpace(nameGeneratorToUse))
                                {
                                    nameGeneratorToUse = "MaterialNameGenerator";
                                }

                                // generate name
                                string generatorName = null;
                                if (!string.IsNullOrWhiteSpace(nameGeneratorToUse))
                                {
                                    var ng = _entityFactory.Create<INameGenerator>();
                                    generatorName = ng.GenerateName(nameGeneratorToUse, materialToTransferFromInput);
                                }

                                // report to erp with batch name
                                materialToTransferFromInput.Attributes[IKEAConstants.CustomMaterialAttributeERPOriginalName] = batchName;

                                materialToTransferFromInput.Name = generatorName;
                            }

                            // If no flow path is defined, try to automatically set it
                            if (string.IsNullOrWhiteSpace(materialToTransferFromInput.FlowPath))
                            {
                                materialToTransferFromInput.FlowPath = _iKEAUtilities.ResolveFlowPathFromMaterialResource(materialToTransferFromInput, resource);
                            }

                            // Set the creation area to the current area
                            if (materialToTransferFromInput.Attributes.ContainsKey(IKEAConstants.CustomMaterialAttributeCreationArea))
                            {
                                materialToTransferFromInput.Attributes[IKEAConstants.CustomMaterialAttributeCreationArea] = resource.Area.Name;
                            }
                            else
                            {
                                materialToTransferFromInput.Attributes.Add(IKEAConstants.CustomMaterialAttributeCreationArea, resource.Area.Name);
                            }

                            // Create the material
                            CreateMaterialOutput createMaterialOutput = _materialOrchestration.CreateMaterial(new CreateMaterialInput() { Material = materialToTransferFromInput });

                            // Update the material to transfer
                            materialToTransferFromInput = createMaterialOutput.Material;
                            materialGenerated = createMaterialOutput.Material;

                            // If it is to split, then split the newly created material
                            if (customLogMaterialMovementInput.SplitQuantity > decimal.Zero)
                            {
                                IMaterial materialToSplit = materialToTransferFromInput;
                                materialsToTransfer.RemoveAt(0);

                                materialToTransferFromInput.Load();
                                decimal currentMaterialQuantity = materialToTransferFromInput.PrimaryQuantity.Value;
                                int numberOfSplits = (int)Math.Ceiling(currentMaterialQuantity / customLogMaterialMovementInput.SplitQuantity);

                                for (int i = 0; i < numberOfSplits; i++)
                                {
                                    decimal quantityToSplit = currentMaterialQuantity > customLogMaterialMovementInput.SplitQuantity ? customLogMaterialMovementInput.SplitQuantity : currentMaterialQuantity;
                                    materialsToTransfer.Add(materialToSplit.SplitMaterial(primaryQuantity: quantityToSplit, terminateOnZeroQuantity: true)[0]);
                                    currentMaterialQuantity -= customLogMaterialMovementInput.SplitQuantity;
                                }

                            }
                            else
                            {
                                // If it is not to split, add the material from input to the material collection
                                materialsToTransfer[0] = materialToTransferFromInput;
                            }

                        }

                        if (materialsToTransfer != null && materialsToTransfer.FirstOrDefault().Id > 0)
                        {
                            // Save dimensions
                            if (customLogMaterialMovementInput.UpdateDimensionAttributes)
                            {
                                materialsToTransfer.SetDimensionAttributes(customLogMaterialMovementInput.Length ?? 0,
                                    customLogMaterialMovementInput.Width ?? 0,
                                    customLogMaterialMovementInput.Thickness ?? 0,
                                    customLogMaterialMovementInput.Weight ?? 0);
                            }

                            #region Manual Outsorting
                            // Check if there is an outsorting quantity to declare:
                            if (isFeederOutsorting)
                            {
                                if (existingPalletQuantity > 0)
                                {
                                    // If there is a pallet in storage, complete it or add quantity to it
                                    _iKEAUtilities.ProcessOutsortedFromFeeder(existingPalletQuantity, resource, materialsToTransfer.FirstOrDefault().Product, isExistingPalletCompleted);
                                }

                                if (numberOfCompletedPallets > 0)
                                {
                                    // New pallets are to be created, add default completion quantity to them, and then complete them
                                    for (int i = 0; i < numberOfCompletedPallets; i++)
                                    {
                                        _iKEAUtilities.CreateNewOutsortedPallet(resource, materialsToTransfer.FirstOrDefault());
                                        _iKEAUtilities.ProcessOutsortedFromFeeder(defaultCompletionQuantity, resource, materialsToTransfer.FirstOrDefault().Product, true);
                                    }
                                }

                                if (incompletePalletQuantity > 0)
                                {
                                    // New pallet is to be created, add quantity to it, and leave it in storage
                                    _iKEAUtilities.CreateNewOutsortedPallet(resource, materialsToTransfer.FirstOrDefault());
                                    _iKEAUtilities.ProcessOutsortedFromFeeder(incompletePalletQuantity, resource, materialsToTransfer.FirstOrDefault().Product);
                                }
                            }
                            #endregion

                            #region Apply Actions
                            // Invoke utility for managing necessary operations for Attaching or Storing:
                            string operation = string.Empty;
                            if (resource.ProcessingType == ProcessingType.Storage)
                            {
                                operation = "Store";
                            }
                            else if (resource.ProcessingType == ProcessingType.ConsumableFeed)
                            {
                                operation = "Attach";
                            }

                            _iKEAUtilities.ApplyOperationActionsInCollection(materialsToTransfer, resource, operation, isManualLoading, originalMaterialName, selectedMO);
                            materialsToTransfer.Load();

                            #endregion
                            List<string> materialsToTransferNames = materialsToTransfer.Select(materialToTransfer => materialToTransfer.Name).ToList();

                            #region Manage Notifications
                            // Get all the notifications related with the material transfer for the given material
                            INotificationCollection notifications = (INotificationCollection)_iKEAUtilities.GetMaterialTransferRequestNotificationsForMaterial(materialsToTransferNames);

                            if (!notifications.IsNullOrEmpty())
                            {
                                // Load the necessary attributes
                                notifications.LoadAttributes(new Collection<string>() { IKEAConstants.MaterialTransferToLocation, IKEAConstants.MaterialTransferToArea });

                                INotificationCollection notificationsToTerminate = _entityFactory.CreateCollection<INotificationCollection>();
                                notificationsToTerminate.AddRange(notifications.Where(n => n.GetAttributeValueOrDefault<string>(IKEAConstants.MaterialTransferToLocation) == resource.Name || n.GetAttributeValueOrDefault<string>(IKEAConstants.MaterialTransferToArea) == resource.Area.Name));

                                // Terminate the notifications
                                if (!notificationsToTerminate.IsNullOrEmpty())
                                {
                                    // load attributes to generate GUI Refresh messages
                                    notificationsToTerminate.LoadAttributes();

                                    // collect all task attributes
                                    var notificationsToSend = notificationsToTerminate.Select(E => new
                                    {
                                        Facility = E.GetAttributeValueOrDefault<string>(IKEAConstants.MaterialTransferFromFacility) ?? String.Empty
                                        ,
                                        Area = E.GetAttributeValueOrDefault<string>(IKEAConstants.MaterialTransferFromArea) ?? String.Empty
                                        ,
                                        Resource = E.GetAttributeValueOrDefault<string>(IKEAConstants.MaterialTransferFromLocation) ?? String.Empty
                                    }).Distinct();

                                    foreach (var entry in notificationsToSend)
                                    {
                                        _iKEAUtilities.PublishMaterialMovementEvent(entry.Facility, entry.Area, entry.Resource);
                                    }

                                    notificationsToTerminate.Terminate();
                                }
                            }
                            #endregion

                            #region Manage Tasks
                            // Get all the tasks related with the material transfer for the given material
                            ITaskCollection tasks = _iKEAUtilities.GetMaterialTransferRequestTasksForMaterial(materialsToTransferNames);

                            if (!tasks.IsNullOrEmpty())
                            {
                                // Load the necessary attributes
                                tasks.LoadAttributes(new Collection<string>() { IKEAConstants.MaterialTransferToLocation, IKEAConstants.MaterialTransferToArea });

                                ITaskCollection tasksToTerminate = _entityFactory.CreateCollection<ITaskCollection>();
                                tasksToTerminate.AddRange(tasks.Where(t => t.GetAttributeValueOrDefault<string>(IKEAConstants.MaterialTransferToLocation) == resource.Name || t.GetAttributeValueOrDefault<string>(IKEAConstants.MaterialTransferToArea) == resource.Area.Name));

                                // Cancel the tasks
                                if (!tasksToTerminate.IsNullOrEmpty())
                                {
                                    tasksToTerminate.ToList().ForEach(t => t.Progress = 100);

                                    tasksToTerminate.Perform(new OperationAttributeCollection());
                                }
                            }
                            #endregion
                        }
                    }
                    else
                    {
                        throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomLogMaterialMovementWrongProcessingTypeLocalizedMessage, resource.Name));
                    }
                }
                else if (materialExists)
                {
                    // Save dimensions
                    if (customLogMaterialMovementInput.UpdateDimensionAttributes)
                    {
                        materialsToTransfer.SetDimensionAttributes(customLogMaterialMovementInput.Length ?? 0,
                            customLogMaterialMovementInput.Width ?? 0,
                            customLogMaterialMovementInput.Thickness ?? 0,
                            customLogMaterialMovementInput.Weight ?? 0);
                    }

                    // Invoke utility for managing necessary operations for Attaching or Storing:
                    string operation = string.Empty;

                    _iKEAUtilities.ApplyOperationActionsInCollection(materialsToTransfer, null, operation);
                    materialsToTransfer.Load();
                }

                if (customLogMaterialMovementInput.MaterialExpirationDate != null)
                {
                    foreach (var materialToTransfer in materialsToTransfer)
                    {
                        materialToTransfer.ExpirationDate = customLogMaterialMovementInput.MaterialExpirationDate;
                    }
                    materialsToTransfer.Save();
                }

                if (materialsToTransfer.FirstOrDefault() != null && materialsToTransfer.FirstOrDefault().Id > 0)
                {
                    output.Material = materialsToTransfer.FirstOrDefault();
                }

                if (materialGenerated != null || !materialExists || materialsToTransfer.Count > 1)
                {
                    if (output.FeedbackMessages == null)
                        output.FeedbackMessages = new Collection<FeedbackMessage>();

                    foreach (IMaterial materialToTransfer in materialsToTransfer)
                    {
                        output.FeedbackMessages.Add(new FeedbackMessage()
                        {
                            Message = _iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomMaterialSplitCreatedNewMaterial, materialToTransfer.Name, materialToTransfer.Form, materialToTransfer.PrimaryQuantity.ToString()),
                            MessageType = FeedbackMessageType.Information
                        });
                    }

                }

                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomLogMaterialMovementInput", customLogMaterialMovementInput),
                                            new KeyValuePair<String, Object>("CustomLogMaterialMovementOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            return output;
        }

        /// <summary>
        /// Creates a Notification to request a Material Transfer
        /// </summary>
        /// <param name="customRequestMaterialTransferInput"></param>
        /// <returns></returns>
        public CustomRequestMaterialTransferOutput CustomRequestMaterialTransfer(CustomRequestMaterialTransferInput customRequestMaterialTransferInput)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomRequestMaterialTransfer",
                new KeyValuePair<String, Object>("CustomRequestMaterialTransferInput", customRequestMaterialTransferInput));

            CustomRequestMaterialTransferOutput output = new CustomRequestMaterialTransferOutput();

            try
            {
                // Get the material types that are allowed to be reported to the ERP upon pallet creation
                List<string> reportableTypes = TableHelper.GetLookupTableValues(IKEAConstants.NotificationSeverityLookupTableName);

                string severity = _iKEAUtilities.GetValueFromConfigurationWithPath(IKEAConstants.DefaultMaterialTransferNotificationSeverityConfig);
                string role = _iKEAUtilities.GetValueFromConfigurationWithPath(IKEAConstants.DefaultForkliftRoleConfig);
                //IRole forkliftOperatorRole = null;
                var forkliftOperatorRole = _entityFactory.Create<IRole>();

                if (severity.IsNullOrEmpty())
                {
                    throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomDefaultNotificationSeverityConfigNotDefined, IKEAConstants.DefaultNotificationSeverityConfig));
                }

                if (role.IsNullOrEmpty())
                {
                    throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomDefaultNotificationRoleConfigNotDefined, IKEAConstants.DefaultForkliftRoleConfig));
                }
                //forkliftOperatorRole = new Role() { Name = role };
                forkliftOperatorRole.Name = role;
                forkliftOperatorRole.Load();
                INotification notification = _entityFactory.Create<INotification>();
                notification.Type = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.CustomMaterialTransferRequestTypePath);
                notification.Title = _iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomMaterialTransferMovementRequestNotificationTitle);
                notification.ClearanceMode = ClearanceMode.ManualSingleUser;
                notification.AssignmentType = (NotificationAssignmentType)AssignmentType.Role;
                notification.AssignedToRole = forkliftOperatorRole;
                notification.Severity = _iKEAUtilities.GetValueFromLookupTable(IKEAConstants.NotificationSeverityLookupTableName, severity, true);


                notification.Attributes.AddRange(new AttributeCollection() {
                    {IKEAConstants.MaterialTransferFromArea, customRequestMaterialTransferInput.FromArea },
                    {IKEAConstants.MaterialTransferFromLocation,customRequestMaterialTransferInput.FromLocation },
                    {IKEAConstants.MaterialTransferFromFacility, customRequestMaterialTransferInput.FromFacility},
                    {IKEAConstants.MaterialTransferRequiredProduct, customRequestMaterialTransferInput.RequiredProduct },
                    {IKEAConstants.MaterialTransferRequiredQuantity, customRequestMaterialTransferInput.RequiredQuantity},
                    {IKEAConstants.MaterialTransferRequiredMaterial, customRequestMaterialTransferInput.RequiredMaterial },
                    {IKEAConstants.MaterialTransferToArea, customRequestMaterialTransferInput.ToArea},
                    {IKEAConstants.MaterialTransferToLocation, customRequestMaterialTransferInput.ToLocation},
                    {IKEAConstants.MaterialTransferToFacility, customRequestMaterialTransferInput.ToFacility},
                    {IKEAConstants.SourceMaterialRequestId, customRequestMaterialTransferInput.SourceMaterialRequestId},
                });

                //Save input object to be handled in Utilities
                Dictionary<string, string> materialRequestInput = new Dictionary<string, string>
                {
                    { IKEAConstants.MaterialTransferFromFacility, customRequestMaterialTransferInput.FromFacility },
                    { IKEAConstants.MaterialTransferFromArea, customRequestMaterialTransferInput.FromArea },
                    { IKEAConstants.MaterialTransferFromLocation, customRequestMaterialTransferInput.FromLocation },
                    { IKEAConstants.MaterialTransferRequiredMaterial, customRequestMaterialTransferInput.RequiredMaterial },
                    { IKEAConstants.MaterialTransferRequiredProduct, customRequestMaterialTransferInput.RequiredProduct },
                    { IKEAConstants.MaterialTransferRequiredQuantity, customRequestMaterialTransferInput.RequiredQuantity.ToString() },
                    { IKEAConstants.MaterialTransferToFacility, customRequestMaterialTransferInput.ToFacility },
                    { IKEAConstants.MaterialTransferToArea, customRequestMaterialTransferInput.ToArea },
                    { IKEAConstants.MaterialTransferToLocation, customRequestMaterialTransferInput.ToLocation }
                };

                #region Set context on Notification

                // Set notification context > If SourceArea is defined, set Area
                if (!string.IsNullOrEmpty(customRequestMaterialTransferInput.FromArea))
                {
                    IArea notificationArea = _entityFactory.Create<IArea>();
                    notificationArea.Name = customRequestMaterialTransferInput.FromArea;
                    if (notificationArea.ObjectExists())
                    {
                        notificationArea.Load();
                        notification.Area = notificationArea;
                    }
                }
                // Set notification context > If SourceArea is not defined but SourceFacility is defined, set Facility
                else if (!string.IsNullOrEmpty(customRequestMaterialTransferInput.FromFacility))
                {
                    IFacility notificationFacility = _entityFactory.Create<IFacility>();
                    notificationFacility.Name = customRequestMaterialTransferInput.FromFacility;
                    if (notificationFacility.ObjectExists())
                    {
                        notificationFacility.Load();
                        notification.Facility = notificationFacility;
                    }
                }

                #endregion

                #region Transfer Material 

                // If material is defined use localized to transfer a Material
                if (!string.IsNullOrEmpty(customRequestMaterialTransferInput.RequiredMaterial))
                {
                    notification.Details = _iKEAUtilities.HandleNotificationDetails(materialRequestInput, isToTransferMaterial: true);
                }

                #endregion

                #region Transfer Product & Quantity

                // If Product, quantity and at least one of the target property is defined, request material transfer
                else if (!string.IsNullOrEmpty(customRequestMaterialTransferInput.RequiredProduct)
                    && customRequestMaterialTransferInput.RequiredQuantity.HasValue && customRequestMaterialTransferInput.RequiredQuantity.Value > 0
                    && (!string.IsNullOrEmpty(customRequestMaterialTransferInput.ToFacility)
                     || !string.IsNullOrEmpty(customRequestMaterialTransferInput.ToArea)
                     || !string.IsNullOrEmpty(customRequestMaterialTransferInput.ToLocation)))
                {

                    notification.Details = _iKEAUtilities.HandleNotificationDetails(materialRequestInput, isToTransferMaterial: false);
                }

                #endregion

                //Create the Notification
                if (!string.IsNullOrEmpty(notification.Details))
                {
                    notification.Create();
                    _iKEAUtilities.PublishMaterialMovementEvent(customRequestMaterialTransferInput.FromFacility, customRequestMaterialTransferInput.FromArea, customRequestMaterialTransferInput.FromLocation);
                    output.RequestMaterialMovementNotification = notification;
                }

                // log method exit
                long objectInstanceId = -1;
                long objectTypeId = -1;
                Utilities.EndMethod(objectTypeId, objectInstanceId, new KeyValuePair<String, Object>("CustomRequestMaterialTransferInput", customRequestMaterialTransferInput),
                                                                    new KeyValuePair<String, Object>("CustomRequestMaterialTransferOutput", output));

            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            return output;
        }

        /// <summary>
        /// /// Service to scan a barcode and return list of parsed extracted values
        /// </summary>
        /// <param name="customParseReadingInput"></param>
        /// <returns></returns>
        public CustomParseReadingOutput CustomParseReading(CustomParseReadingInput customParseReadingInput)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomParseReading",
            new KeyValuePair<String, Object>("CustomParseReadingInput", customParseReadingInput));

            CustomParseReadingOutput output = null;

            try
            {
                // Verify if the input parameter is null
                Utilities.ValidateNullInput(customParseReadingInput);
                output = new CustomParseReadingOutput();
                output.ExtractedData = _barcodeUtilities.ExtractBarcodeInformation(customParseReadingInput.BarcodeInputString);

                // retrieve known objects back
                if (output.ExtractedData != null)
                {
                    // prepare return data objects
                    output.ExtractedDataObjects = output.ExtractedData.ToDictionary(E => E.Key.ToUpper(), E => (object)null);

                    // use internal dictionary in upper case to improve search
                    Dictionary<string, string> innerDictionary = output.ExtractedData.ToDictionary(E => E.Key.ToUpper(), E => E.Value);

                    // check for the existence of material token and if so try to load the read material name
                    string materialToken = Navigo.Common.Constants.Material.ToUpper();
                    if (output.ExtractedDataObjects.ContainsKey(Navigo.Common.Constants.Material.ToUpper()))
                    {
                        IMaterial materialObject = _entityFactory.Create<IMaterial>();
                        materialObject.Name = innerDictionary[materialToken];
                        if (materialObject.ObjectExists())
                        {
                            materialObject.Load();
                            materialObject.LoadRelations(IKEAConstants.CustomMaterialBatchRelation);
                            materialObject.Product.Load();
                            output.ExtractedDataObjects[materialToken] = materialObject;
                        }
                    }
                }


                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomParseReadingInput", customParseReadingInput),
                                            new KeyValuePair<String, Object>("CustomParseReadingOutput", output));

            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            return output;
        }

        /// <summary>
        /// Get all available forklift resources dor check in
        /// </summary>
        /// <param name="customGetResourcesForCheckInInput">Input Object</param>
        /// <returns>Output Objects</returns>
        public CustomGetResourcesForCheckInOutput CustomGetResourcesForCheckIn(CustomGetResourcesForCheckInInput customGetResourcesForCheckInInput)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomGetResourcesForCheckIn",
               new KeyValuePair<String, Object>("CustomGetResourcesForCheckInInput", customGetResourcesForCheckInInput));

            CustomGetResourcesForCheckInOutput output = new CustomGetResourcesForCheckInOutput();

            try
            {
                Utilities.ValidateNullInput(customGetResourcesForCheckInInput);

                IEmployee employee = customGetResourcesForCheckInInput.EmployeeToCheckIn ?? _iKEAUtilities.GetCurrentEmployee(); ;

                List<IResource> list = new List<IResource>();

                employee.LoadRelations(Cmf.Navigo.Common.Constants.ResourceEmployee);

                if ((employee.RelationCollection != null
                    && employee.RelationCollection.ContainsKey(Cmf.Navigo.Common.Constants.ResourceEmployee)))
                {
                    list = _iKEAUtilities.GetAllAvailableResources(employee.RelationCollection[Cmf.Navigo.Common.Constants.ResourceEmployee].Select(r => r.SourceEntity.Id).ToArray());
                }
                else
                {
                    long[] t = new long[1];
                    t[0] = 0;
                    list = _iKEAUtilities.GetAllAvailableResources(t);
                }

                output.ResourcesForCheckIn = list;

                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomUpdateBomProductsAttributesInput", customGetResourcesForCheckInInput),
                                            new KeyValuePair<String, Object>("CustomGetMaterialSetupStateOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            return output;
        }

        /// <summary>
        /// Gets the Employee Tasks and area notifications
        /// </summary>
        /// <param name="customGetEmployeeTasksAndAreaNotificationsInput">Input Object</param>
        /// <returns>Output Objects</returns>
        public CustomGetEmployeeTasksAndAreaNotificationsOutput CustomGetEmployeeTasksAndAreaNotifications(CustomGetEmployeeTasksAndAreaNotificationsInput customGetEmployeeTasksAndAreaNotificationsInput)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomGetEmployeeTasksAndAreaNotifications",
               new KeyValuePair<String, Object>("CustomGetEmployeeTasksAndAreaNotificationsInput", customGetEmployeeTasksAndAreaNotificationsInput));

            CustomGetEmployeeTasksAndAreaNotificationsOutput output = new CustomGetEmployeeTasksAndAreaNotificationsOutput();

            try
            {
                Utilities.ValidateNullInput(customGetEmployeeTasksAndAreaNotificationsInput);
                string requestType = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.CustomMaterialTransferRequestTypePath);
                IEmployee employee = customGetEmployeeTasksAndAreaNotificationsInput.Employee ?? _iKEAUtilities.GetCurrentEmployee();

                ITaskCollection tasks = _iKEAUtilities.GetAllTasksPerEmployee(employee);

                GetNotificationsForUserInput input = new GetNotificationsForUserInput();
                input.User = employee.User;

                GetNotificationsForUserOutput notificationsOutput = _alarmOrchestration.GetNotificationsForUser(input);

                Collection<long> areaIds = new Collection<long>();

                if (employee != null && employee.ObjectExists())
                {
                    Navigo.BusinessOrchestration.ResourceManagement.InputObjects.GetCheckInResourcesForEmployeeInput getCheckInResourcesForEmployeeInput =
                     new Navigo.BusinessOrchestration.ResourceManagement.InputObjects.GetCheckInResourcesForEmployeeInput
                     {
                         Employee = employee

                     };
                    Navigo.BusinessOrchestration.ResourceManagement.OutputObjects.GetCheckInResourcesForEmployeeOutput getCheckInResourcesForEmployeeOutput = _resourceOrchestration.GetCheckInResourcesForEmployee(getCheckInResourcesForEmployeeInput);

                    getCheckInResourcesForEmployeeOutput.ResourceCollection.Load();
                    areaIds.AddRange(getCheckInResourcesForEmployeeOutput.ResourceCollection.Select(E => E.GetNativeValue<long>("Area")).Distinct());
                }
                var notifications = notificationsOutput.Notifications.Where(n => n.Type == requestType && areaIds.Contains(n.GetNativeValue<long>("Area")));

                List<MaterialRequest> materialRequests = new List<MaterialRequest>();
                foreach (ITask task in tasks)
                {
                    MaterialRequest materialRequest = _iKEAUtilities.CreateMaterialRequest("Task", task.Id);
                    materialRequests.Add(materialRequest);
                }

                foreach (INotification notification in notifications)
                {
                    MaterialRequest materialRequest = _iKEAUtilities.CreateMaterialRequest("Notification", notification.Id);
                    materialRequests.Add(materialRequest);
                }

                output.EmployeeTasksAndAreaNotification = materialRequests;
                output.EmployeeCheckedInAreaIDs = areaIds.ToList();

                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomGetEmployeeTasksAndAreaNotificationsInput", customGetEmployeeTasksAndAreaNotificationsInput),
                                            new KeyValuePair<String, Object>("CustomGetEmployeeTasksAndAreaNotificationsOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            return output;
        }

        /// <summary>
        /// Service for Canceling or Complete all tasks in a collection
        /// </summary>
        /// <param name="customTaskCompleteAndCancelInput"></param>
        /// <returns></returns>
        public CustomTaskCompleteAndCancelOutput CustomTaskCompleteAndCancel(CustomTaskCompleteAndCancelInput customTaskCompleteAndCancelInput)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomTaskCompleteAndCancel",
            new KeyValuePair<String, Object>("CustomTaskCompleteAndCancelInput", customTaskCompleteAndCancelInput));

            CustomTaskCompleteAndCancelOutput output = null;

            try
            {
                // Verify if the input parameter is null
                Utilities.ValidateNullInput(customTaskCompleteAndCancelInput);
                output = new CustomTaskCompleteAndCancelOutput();

                // Get input data:
                ITaskCollection taskCollection = customTaskCompleteAndCancelInput.Tasks;
                string taskOperation = customTaskCompleteAndCancelInput.TaskOperation;

                if (!taskCollection.IsNullOrEmpty())
                {
                    // Cancel all tasks in collection:
                    if (taskOperation.Equals("Cancel", StringComparison.InvariantCultureIgnoreCase))
                    {
                        taskCollection.Cancel(new OperationAttributeCollection());
                    }

                    // Complete all the tasks in collection:
                    else if (taskOperation.Equals("Complete", StringComparison.InvariantCultureIgnoreCase))
                    {
                        // Update progress:
                        taskCollection.ToList().ForEach(t => t.Progress = 100);
                        // Perfonr tasks:
                        taskCollection.Perform(new OperationAttributeCollection());

                        // load attributes
                        taskCollection.LoadAttributes();

                        // collect all task attributes
                        var notificationsToSend = taskCollection.Select(E => new
                        {
                            Facility = E.GetAttributeValueOrDefault<string>(IKEAConstants.MaterialTransferFromFacility) ?? String.Empty
                            ,
                            Area = E.GetAttributeValueOrDefault<string>(IKEAConstants.MaterialTransferFromArea) ?? String.Empty
                            ,
                            Resource = E.GetAttributeValueOrDefault<string>(IKEAConstants.MaterialTransferFromLocation) ?? String.Empty
                        }).Distinct();

                        foreach (var entry in notificationsToSend)
                        {
                            _iKEAUtilities.PublishMaterialMovementEvent(entry.Facility, entry.Area, entry.Resource);
                        }
                    }
                }

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomTaskCompleteAndCancelInput", customTaskCompleteAndCancelInput),
                                            new KeyValuePair<String, Object>("CustomTaskCompleteAndCancelOutput", output));

            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            return output;
        }

        /// <summary>
        /// Service for changing the state of a material
        /// </summary>
        /// <param name="CustomSetMaterialState"></param>
        /// <returns></returns>
        public CustomSetMaterialStateOutput CustomSetMaterialState(CustomSetMaterialStateInput customSetMaterialStateInput)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomSetMaterialState",
            new KeyValuePair<String, Object>("CustomSetMaterialStateInput", customSetMaterialStateInput));

            CustomSetMaterialStateOutput output = null;

            try
            {

                // Verify if the input parameter is null
                Utilities.ValidateNullInput(customSetMaterialStateInput, new List<string> {
                    nameof(customSetMaterialStateInput.Material),
                    nameof(customSetMaterialStateInput.MaterialName)
                });

                output = new CustomSetMaterialStateOutput();

                // Get input data:
                IMaterial material = customSetMaterialStateInput.Material;

                // If no material is supplied, load it by Id:
                if (material == null)
                {
                    material = _entityFactory.Create<IMaterial>();

                    if (!customSetMaterialStateInput.MaterialName.IsNullOrEmpty())
                    {
                        material = _entityFactory.Create<IMaterial>();
                        material.Name = customSetMaterialStateInput.MaterialName;
                        material.Load();
                    }
                }

                if (material.CurrentMainState.StateModel.States == null || material.CurrentMainState.StateModel.StateTransitions == null)
                {
                    material.CurrentMainState.StateModel.Load();
                }

                // Get all available transitions for the material actual state:
                IStateModelTransitionCollection availableTransitions = material.CurrentMainState.StateModel.GetPossibleTransitionsForState(material.CurrentMainState.CurrentState);

                // If a valid transition is not found, throw an exception


                if (!availableTransitions.Any(at => at.ToState.Name.Equals(customSetMaterialStateInput.State, StringComparison.InvariantCultureIgnoreCase)))
                {
                    throw new CmfBaseException(String.Format(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomStateTransitionNoValidTransitionMessage), material.CurrentMainState.StateModel.Name, material.CurrentMainState.CurrentState.Name, customSetMaterialStateInput.State));
                }

                // Change material State:
                _genericUtilities.ChangeMaterialStateModel(material, customSetMaterialStateInput.State);

                // If state is Complete or Aborted, validate all preconditions to finish material:
                if (customSetMaterialStateInput.State.CompareStrings(IKEAConstants.MaterialStateModelAborted) ||
                    customSetMaterialStateInput.State.CompareStrings(IKEAConstants.MaterialStateModelCompleted) ||
                    customSetMaterialStateInput.State.CompareStrings(IKEAConstants.MaterialStateModelAborting) ||
                    customSetMaterialStateInput.State.CompareStrings(IKEAConstants.MaterialStateModelCompleting))
                {
                    material.SaveAttributes(new AttributeCollection { { IKEAConstants.CustomMaterialAttributeInCompletion, true } });
                }

                bool isToCallStopMaterial = false;
                // If state is Complete or Aborted, validate all preconditions to finish material:
                if (customSetMaterialStateInput.State.Equals(IKEAConstants.MaterialStateModelAborted, StringComparison.InvariantCultureIgnoreCase) ||
                    customSetMaterialStateInput.State.Equals(IKEAConstants.MaterialStateModelCompleted, StringComparison.InvariantCultureIgnoreCase))
                {
                    IResource resource = material.LastProcessedResource;
                    // Check if the resource is in Automation mode Online:
                    if (resource != null && resource.AutomationMode == ResourceAutomationMode.Online)
                    {
                        //Get unit completion mode for resource
                        CustomUnitCompletionModeEnum unitCompletionMode = resource.GetAttributeValueOrDefault<CustomUnitCompletionModeEnum>(IKEAConstants.CustomResourceAttributeUnitCompletionMode, true);

                        //If Automation, call StopMaterial
                        if (unitCompletionMode == CustomUnitCompletionModeEnum.Automation)
                        {
                            isToCallStopMaterial = true;
                        }
                        else if (unitCompletionMode == CustomUnitCompletionModeEnum.ManualOutsorting)
                        {
                            // Get material attributes 'ResourceLossPiecesClassified' and 'CurrentProcessedOutsortedQuantity':
                            material.LoadAttributes(new Collection<string> { IKEAConstants.CustomMaterialAttributeCurrentProcessedOutsortedQuantity ,
                                                                            IKEAConstants.CustomMaterialAttributeResourceLossPiecesClassified});

                            // Check ResourceLossPiecesClassified attribute. If true, we need to compare the processed outsorted quantities with outsorted from IoT:
                            bool isGroupMo = material.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomMaterialAttributeIsGroupMO, true);
                            bool resourceLossPiecesClassified;
                            if (isGroupMo)
                            {
                                resourceLossPiecesClassified = _iKEAUtilities.CheckIfChildMOsPiecesAreClassified(material);
                            }
                            else
                            {
                                resourceLossPiecesClassified = material.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomMaterialAttributeResourceLossPiecesClassified);
                            }
                            if (resourceLossPiecesClassified)
                            {
                                isToCallStopMaterial = _iKEAUtilities.CheckIfAllOutsortedPartsAreProcessed(material, true);

                                // If there are still pieces pending ManualOutsort, CustomStopMaterial will not be called, so operation to change ERPScheduledQuantity needs to be done here
                                if (!(isToCallStopMaterial || customSetMaterialStateInput.IsToStopMaterial)
                                    && !customSetMaterialStateInput.State.Equals(IKEAConstants.MaterialStateModelAborted, StringComparison.InvariantCultureIgnoreCase)
                                    && !customSetMaterialStateInput.State.Equals(IKEAConstants.MaterialStateModelAborting, StringComparison.InvariantCultureIgnoreCase))
                                {

                                    // Get pending ManualOutsort quantity
                                    decimal pendingManualOutsortQuantity = _iKEAUtilities.GetTotalPendingManualOutsortQuantity(material, resource);

                                    // Update ERPScheduledQuantity, removing primary quantity and adding pending ManualOutsort quantity, so that operation can be sent to ERP
                                    _iKEAUtilities.RemoveScheduledQuantityFromCustomERPOperationTracking(material, pendingManualOutsortQuantity);

                                }
                            }
                        }
                    }
                    if (isToCallStopMaterial || customSetMaterialStateInput.IsToStopMaterial)
                    {
                        if (customSetMaterialStateInput.State.Equals(IKEAConstants.MaterialStateModelAborted, StringComparison.InvariantCultureIgnoreCase))
                        {
                            // Invoke CustomStopMaterial service with Aborted reason:
                            CustomStopMaterial(new CustomStopMaterialInput()
                            {
                                MaterialName = material.Name,
                                StopReason = CustomMaterialStopReasonEnum.Abort.ToString(),
                                IsIOTSource = true,
                                IsStopOperation = customSetMaterialStateInput.IsToStopMaterial,
                            });
                        }
                        else if (customSetMaterialStateInput.State.Equals(IKEAConstants.MaterialStateModelCompleted, StringComparison.InvariantCultureIgnoreCase))
                        {
                            // Invoke CustomStopMaterial service with Completed reason:
                            CustomStopMaterial(new CustomStopMaterialInput()
                            {
                                MaterialName = material.Name,
                                StopReason = CustomMaterialStopReasonEnum.Complete.ToString(),
                                IsIOTSource = true
                            });
                        }
                    }
                }

                output.Material = material;

                // Close service:
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomSetMaterialStateInput", customSetMaterialStateInput),
                                            new KeyValuePair<String, Object>("CustomSetMaterialStateOutput", output));

            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            return output;
        }

        /// <summary>
        /// Service for Label printing in Cutting area
        /// </summary>
        /// <param name="customPrintLabelCuttingInput">Input Object</param>
        /// <returns>Output Objects</returns>
        public CustomPrintLabelCuttingOutput CustomPrintLabelCutting(CustomPrintLabelCuttingInput customPrintLabelCuttingInput)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomPrintLabelCutting",
                new KeyValuePair<String, Object>("CustomPrintLabelCuttingInput", customPrintLabelCuttingInput));

            CustomPrintLabelCuttingOutput output = new CustomPrintLabelCuttingOutput();

            Utilities.ValidateNullInput(customPrintLabelCuttingInput, new List<string> { "PalletName" });

            try
            {
                customPrintLabelCuttingInput.Product.Load();
                customPrintLabelCuttingInput.Step.Load();
                customPrintLabelCuttingInput.Resource.Load();

                //Create material with data received from GUI
                IMaterial material = _entityFactory.Create<IMaterial>();
                material.Attributes[IKEAConstants.CustomMaterialAttributeBaseMaterial] = customPrintLabelCuttingInput.MOName;
                material.Product = customPrintLabelCuttingInput.Product;
                material.PrimaryQuantity = customPrintLabelCuttingInput.Quantity;
                material.LastProcessedResource = customPrintLabelCuttingInput.Resource;

                //Pallet name is defined
                if (!string.IsNullOrWhiteSpace(customPrintLabelCuttingInput.PalletName))
                {
                    //If Pallet name is defined, override name and use pallet name instead
                    material.Name = customPrintLabelCuttingInput.PalletName;
                }
                //Pallet name is NOT defined
                else
                {
                    // Get the complete form for the material
                    string completedForm = _iKEAUtilities.GetCompletedMaterialForm(material);
                    // Retrieve corresponding name generator and load it to ensure it exists
                    String completedFormNameGeneratorName = _iKEAUtilities.GetMaterialNameGenerator(completedForm);
                    INameGenerator completedFormNameGenerator = _entityFactory.Create<INameGenerator>();
                    completedFormNameGenerator.Load(completedFormNameGeneratorName);

                    // Generate name
                    material.Name = completedFormNameGenerator.GenerateName(completedFormNameGeneratorName, material);
                }
                IPrintableDocument printableDocument = _entityFactory.Create<IPrintableDocument>();
                printableDocument.Name = customPrintLabelCuttingInput.PrintableDocumentName;
                if (printableDocument.ObjectExists())
                {
                    printableDocument.Load();
                }


                _automaticPrintingUtilities.ResolveAndPrintAutomaticPrintableDocumentsCutting(material,
                                                                                customPrintLabelCuttingInput.Step,
                                                                                IKEAConstants.AutomaticPrintingSequenceOnCreate,
                                                                                customPrintLabelCuttingInput.Resource,
                                                                                customPrintLabelCuttingInput.Product,
                                                                                printableDocument);

                //Add create material success message
                output.FeedbackMessages = new Collection<FeedbackMessage>
                    { new FeedbackMessage()
                        {
                            MessageType = FeedbackMessageType.Success,
                            Message = _iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomLabelPrintingSuccessLocalizedMessage),
                        }
                    };


                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomPrintLabelCuttingInput", customPrintLabelCuttingInput),
                                            new KeyValuePair<String, Object>("CustomPrintLabelCuttingOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            return output;
        }

        /// <summary>
        /// Service for clearing Material interlock admission
        /// </summary>
        /// <param name="customClearMaterialAdmissionInterlockInput">Input Object</param>
        /// <returns></returns>
        public CustomClearMaterialAdmissionInterlockOutput CustomClearMaterialAdmissionInterlock(CustomClearMaterialAdmissionInterlockInput customClearMaterialAdmissionInterlockInput)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomClearMaterialAdmissionInterlock",
            new KeyValuePair<String, Object>("CustomClearMaterialAdmissionInterlockInput", customClearMaterialAdmissionInterlockInput));

            CustomClearMaterialAdmissionInterlockOutput output = null;

            try
            {

                // Verify if the input parameter is null
                Utilities.ValidateNullInput(customClearMaterialAdmissionInterlockInput);

                output = new CustomClearMaterialAdmissionInterlockOutput();

                // Get input data:
                IResource resource = customClearMaterialAdmissionInterlockInput.Resource;

                // check if resource received exists 
                if (resource.ObjectExists())
                {
                    resource.Load();
                    List<int> systemStatesInProgress = new List<int>();
                    systemStatesInProgress.Add((int)MaterialSystemState.InProcess);

                    IResource topMostResource = resource.GetTopMostResource();

                    // Get all active alarms
                    List<ICustomAlarmOccurrence> alarms = _alarmHandlingUtilities.GetLineActiveAlarms(topMostResource);

                    if (alarms != null && alarms.Count > 0)
                    {
                        foreach (ICustomAlarmOccurrence alarm in alarms)
                        {
                            //Resolve CustomAlarmHandlingActions Smart Table
                            DataRow datarow = _alarmHandlingUtilities.ResolveCustomAlarmHandlingActions(alarm.AlarmCode
                                , alarm.AlarmCategory
                                , resource.Name
                                , alarm.Area.Name
                                , alarm.Facility.Name);

                            if (datarow != null)
                            {
                                if (!String.IsNullOrWhiteSpace((datarow[IKEAConstants.BlockFeeder] ?? String.Empty).ToString()) && datarow.Field<bool>(IKEAConstants.BlockFeeder))
                                {
                                    _iKEAUtilities.NotifyOnInterlockNotifications(
                                        resource,
                                        _iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomClearInterlockErrorTitleMessageLocalizedMessage, resource.Name),
                                        _iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomAlarmBlockFeederStillActiveRemainsInterlock, alarm.Name)
                                    );
                                    Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomClearMaterialAdmissionInterlockInput", customClearMaterialAdmissionInterlockInput),
                                           new KeyValuePair<String, Object>("CustomClearMaterialAdmissionInterlockOutput", output));
                                    return output;
                                }
                            }
                        }
                    }
                    // Query for all materials in progress on the Resource ordered by MaterialResource Order
                    // Get all material tracked-in in the resource
                    Dictionary<IMaterial, decimal> trackedInMaterials = _iKEAUtilities.GetMaterialsFromResourceByState(resource.Id, true, MaterialSystemState.InProcess);

                    // Get All InProcess Materials that contain an active interlock (Attribute InterlockAdmissionState set to Closed) or are in MSM states INPROCESS | SETUP | UNSUSPENDING | SUSPENDED
                    List<IMaterial> interlockMaterials = trackedInMaterials
                        .OrderBy(pair => pair.Value)
                        .Select(pair => pair.Key)
                        .FilterChildMOsFromList()
                        .Where(mo =>
                        {
                            mo.LoadAttribute(IKEAConstants.CustomInterlockAdmissionState);
                            CustomInterlockAdmissionStateEnum currentInterlockState = mo.GetAttributeValueOrDefault<CustomInterlockAdmissionStateEnum>(IKEAConstants.CustomInterlockAdmissionState);

                            bool isInterlockStateClosed = currentInterlockState == CustomInterlockAdmissionStateEnum.Closed;

                            bool isMaterialInStateOfInterest = mo.CurrentMainState.CurrentState.Name == IKEAConstants.MaterialStateModelInProcess
                                                                || mo.CurrentMainState.CurrentState.Name == IKEAConstants.MaterialStateModelSetup
                                                                 || mo.CurrentMainState.CurrentState.Name == IKEAConstants.MaterialStateModelUnsuspending
                                                                  || mo.CurrentMainState.CurrentState.Name == IKEAConstants.MaterialStateModelSuspended;

                            return isInterlockStateClosed || isMaterialInStateOfInterest;
                        })
                        .ToList();

                    bool hasInProcessOrUnsuspendingOrders = interlockMaterials.Any(mo => mo.CurrentMainState.CurrentState.Name == IKEAConstants.MaterialStateModelInProcess || mo.CurrentMainState.CurrentState.Name == IKEAConstants.MaterialStateModelUnsuspending);

                    // If there is any order in process or unsuspending, remove all orders in setup that have open interlocks
                    if (hasInProcessOrUnsuspendingOrders)
                    {
                        interlockMaterials.RemoveAll(mo =>
                        {
                            mo.LoadAttribute(IKEAConstants.CustomInterlockAdmissionState);
                            CustomInterlockAdmissionStateEnum currentInterlockState = mo.GetAttributeValueOrDefault<CustomInterlockAdmissionStateEnum>(IKEAConstants.CustomInterlockAdmissionState);

                            bool isInterlockStateClosed = currentInterlockState == CustomInterlockAdmissionStateEnum.Closed;

                            bool isStateInSetup = mo.CurrentMainState.CurrentState.Name == IKEAConstants.MaterialStateModelSetup;

                            return isStateInSetup && !isInterlockStateClosed;
                        });
                    }
                    else
                    {
                        // Get all orders in Setup and have Open interlock
                        List<IMaterial> setupOpenOrders = interlockMaterials.Where(mo =>
                        {

                            mo.LoadAttribute(IKEAConstants.CustomInterlockAdmissionState);
                            CustomInterlockAdmissionStateEnum currentInterlockState = mo.GetAttributeValueOrDefault<CustomInterlockAdmissionStateEnum>(IKEAConstants.CustomInterlockAdmissionState);

                            bool isInterlockStateClosed = currentInterlockState == CustomInterlockAdmissionStateEnum.Closed;
                            bool isMaterialInSetup = mo.CurrentMainState.CurrentState.Name == IKEAConstants.MaterialStateModelSetup;

                            return !isInterlockStateClosed && isMaterialInSetup;

                        }).ToList();

                        IAutomationControllerInstance controllerInstance = resource.GetAutomationControllerInstance();

                        foreach (IMaterial setupOpenOrder in setupOpenOrders)
                        {
                            // Prepare material details
                            Dictionary<string, string> materialDetails = new Dictionary<string, string>
                                {
                                    { "MaterialName", setupOpenOrder.Name }
                                };

                            object parsedReply = null;

                            // Get order state from 
                            int orderIoTState = 0;
                            var eiReply = _genericUtilities.RequestFromIoT<Dictionary<string, object>>(controllerInstance, IKEAConstants.AutomationRequestGetOrderStateOnEquipment, materialDetails.ToJsonString());
                            if (eiReply != null && eiReply.ContainsKey(IKEAConstants.AutomationRequestReplyField))
                            {
                                eiReply.TryGetValue(IKEAConstants.AutomationRequestReplyField, out parsedReply);

                                string resultString = JsonConvert.DeserializeObject<string>(parsedReply?.ToJsonString());

                                int.TryParse(resultString, out orderIoTState);
                            }

                            bool shouldDelete = orderIoTState != 3 && orderIoTState != 6;

                            if (shouldDelete)
                            {
                                interlockMaterials.Remove(setupOpenOrder);
                            }
                        }
                    }

                    bool anyMaterialFailedToClear = false;
                    bool noAvailableOrdersToBeCleared = false;
                    if (interlockMaterials.Count == 0)
                    {
                        anyMaterialFailedToClear = true;
                        noAvailableOrdersToBeCleared = true;
                    }

                    foreach (IMaterial interlockMaterial in interlockMaterials)
                    {
                        interlockMaterial.LoadAttributes(new Collection<string>()
                            {
                                IKEAConstants.CustomMaterialAttributeIsReadyForProduction,
                                IKEAConstants.CustomMaterialAttributeCheckListCorrectlySetup,
                                IKEAConstants.CustomMaterialAttributeConsumablesCorrectlySetup,
                                IKEAConstants.CustomMaterialAttributeDurablesCorrectlySetup,
                            });

                        bool isReadyForProduction = false;
                        bool isCheckListCorrectlySetup = false;
                        bool isConsumableCorrectlySetup = false;
                        bool isDurableCorrectlySetup = false;


                        // Validate isReadyForProduction
                        isReadyForProduction = interlockMaterial.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomMaterialAttributeIsReadyForProduction, false);

                        // Get the state from all indicators (Checklist, Consumable and Durable are setup correctly):  
                        isCheckListCorrectlySetup = interlockMaterial.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomMaterialAttributeCheckListCorrectlySetup, false);
                        isConsumableCorrectlySetup = interlockMaterial.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomMaterialAttributeConsumablesCorrectlySetup, false);
                        isDurableCorrectlySetup = interlockMaterial.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomMaterialAttributeDurablesCorrectlySetup, false);

                        //If setup order is correctly set up, send IOT information to clear interlock and change resource state to InProcess
                        if (isReadyForProduction)
                        {
                            IAutomationControllerInstance controllerInstance = resource.GetAutomationControllerInstance();
                            if (controllerInstance != null)
                            {
                                // Set the default request type to the ClearInterlock
                                string requestType = IKEAConstants.AutomationRequestClearInterlock;
                                // Set the default request data to the MO Name
                                Dictionary<string, string> requestDataDictionary = new Dictionary<string, string>() {
                                        { IKEAConstants.AutomationRequestMaterialName, interlockMaterial?.Name }
                                    };

                                // Check if there is a top most resource that contains a StateModelState defined
                                if (interlockMaterial != null
                                    && interlockMaterial.CurrentMainState != null
                                    && interlockMaterial.CurrentMainState.CurrentState != null)
                                {
                                    // Get the name of the StateModelState
                                    string stateModelState = interlockMaterial.CurrentMainState.CurrentState.Name;

                                    // Prevent Clear Interlock from running when the order is in SUSPENDED state
                                    if (stateModelState.CompareStrings(IKEAConstants.MaterialStateModelSuspended))
                                    {
                                        if (interlockMaterials.Count > 1)
                                        {
                                            continue;
                                        }
                                        else
                                        {
                                            throw _iKEAUtilities.LocalizedException(IKEAConstants.CustomClearInterlockFailOrderSuspendedLocalizedMessage,
                                                resource.Name,
                                                interlockMaterial.Name
                                            );
                                        }
                                    }

                                    // If the order is in the state completing, the request type should be ClearInterlockCompleting
                                    if (stateModelState.CompareStrings(IKEAConstants.MaterialStateModelCompleting))
                                    {
                                        requestType = IKEAConstants.AutomationRequestClearInterlockCompleting;
                                    }
                                    // If the order is in the state completing, the request type should be ClearInterlockAborting
                                    else if (stateModelState.CompareStrings(IKEAConstants.MaterialStateModelAborting))
                                    {
                                        requestType = IKEAConstants.AutomationRequestClearInterlockAborting;
                                    }
                                }

                                // Send Synchronous request to automation to request interlock clear 
                                Dictionary<string, string> clearInterlockResponse = _genericUtilities.RequestFromIoT<Dictionary<string, string>>(controllerInstance, requestType, requestDataDictionary.ToJsonString());

                                // Check if there is a reply from IoT
                                if (!clearInterlockResponse.IsNullOrEmpty()
                                    && clearInterlockResponse.ContainsKey(IKEAConstants.AutomationRequestReplyField)
                                    && !string.IsNullOrEmpty(clearInterlockResponse[IKEAConstants.AutomationRequestReplyField]))
                                {
                                    bool isInterlockClear;

                                    // If the reply is parsable to bool it means that the reply is the Interlock state
                                    // If not, it means that the reply is a error code
                                    bool parseSuccessfull = bool.TryParse(clearInterlockResponse[IKEAConstants.AutomationRequestReplyField], out isInterlockClear);


                                    // Check if it was able to parse to bool
                                    if (!parseSuccessfull)
                                    {
                                        anyMaterialFailedToClear = true;
                                        IEmployeeCollection employeesToBeNotified = _genericUtilities.GetCheckedInEmployees(resource.Name);

                                        // Check if there are any employees to be notified
                                        if (!employeesToBeNotified.IsNullOrEmpty())
                                        {
                                            // Get localized message by response code
                                            string localizedMessage = _iKEAUtilities.GetIoTLocalizedMessageFromResponseCode(clearInterlockResponse[IKEAConstants.AutomationRequestReplyField]);

                                            if (clearInterlockResponse.ContainsKey(IKEAConstants.AutomationRequestMessageField))
                                            {
                                                string responseMessage = clearInterlockResponse[IKEAConstants.AutomationRequestMessageField];
                                                if (!responseMessage.IsNullOrEmpty())
                                                {
                                                    localizedMessage = String.Format("{0}. Trace: {1}", localizedMessage, responseMessage);
                                                }
                                            }

                                            _iKEAUtilities.NotifyOnInterlockNotifications(
                                                resource,
                                                _iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomClearInterlockErrorTitleMessageLocalizedMessage, resource.Name),
                                                localizedMessage);
                                        }
                                    }
                                    else if (parseSuccessfull && !isInterlockClear)
                                    {
                                        anyMaterialFailedToClear = true;
                                    }
                                    else if (parseSuccessfull && isInterlockClear)
                                    {
                                        interlockMaterial.RemoveFromInstanceCache();
                                        interlockMaterial.Load();
                                        IAttributeCollection materialAttributes = new AttributeCollection();
                                        materialAttributes[IKEAConstants.CustomInterlockAdmissionState] = CustomInterlockAdmissionStateEnum.Open;
                                        interlockMaterial.SaveAttributes(materialAttributes);
                                    }
                                }
                            }
                        }
                        else
                        {
                            anyMaterialFailedToClear = true;
                            // Get localized message according to the reason why the MO is not ready to production:
                            string localizedMessage = string.Empty;

                            // No orders in process:
                            if (interlockMaterial == null)
                            {
                                localizedMessage = string.Format(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomClearInterlockNoMaterialsMessage, resource.Name));
                            }
                            // Missing checklist:
                            else if (!isCheckListCorrectlySetup)
                            {
                                localizedMessage = string.Format(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomClearInterlockMissingCheckListMessage, resource.Name));
                            }
                            // Missing durables:
                            else if (!isDurableCorrectlySetup)
                            {
                                localizedMessage = string.Format(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomClearInterlockNoDurablesMessage, resource.Name));
                            }
                            // Missing consumables:
                            else
                            {
                                localizedMessage = string.Format(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomClearInterlockNoConsumablesMessage, resource.Name));
                            }

                            _iKEAUtilities.NotifyOnInterlockNotifications(
                                resource,
                                _iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomClearInterlockErrorTitleMessageLocalizedMessage, resource.Name),
                                localizedMessage);
                        }

                    }

                    // If there are no orders with the necessary conditions to call IoT, show message to operator
                    if (noAvailableOrdersToBeCleared)
                    {
                        string localizedMessage = _iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomClearInterlockNoOrdersMeetConditions);
                        _iKEAUtilities.NotifyOnInterlockNotifications(
                            resource,
                            _iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomClearInterlockErrorTitleMessageLocalizedMessage, resource.Name),
                            localizedMessage);
                    }

                    resource.RemoveFromInstanceCache();
                    resource.Load();

                    // Update InterlockAdmissionState attribute 
                    IAttributeCollection attributes = new AttributeCollection
                            {
                                { IKEAConstants.CustomResourceAttributeInterlockAdmissionState, anyMaterialFailedToClear ? CustomInterlockAdmissionStateEnum.Closed : CustomInterlockAdmissionStateEnum.Open}
                            };
                    resource.SaveAttributes(attributes);

                    // Spreads message stating line condition has changed to trigger refresh                                    
                    string messageSubject = String.Format("{0}{1}", IKEAConstants.MessageBusResourceAndMaterialEventsPrefix, resource.Id);
                    List<string> refreshItems = new List<string>
                            {
                                "ResourceState",
                                "ActionButtons"
                            };
                    _iKEAUtilities.PublishCockpitTransactionalMessages(messageSubject, refreshItems: refreshItems);
                }

                // Close service:
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomClearMaterialAdmissionInterlockInput", customClearMaterialAdmissionInterlockInput),
                                            new KeyValuePair<String, Object>("CustomClearMaterialAdmissionInterlockOutput", output));

            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            return output;
        }

        /// <summary>
        /// Service for updating interlock admission
        /// </summary>
        /// <param name="customUpdateInterlockStatusInput">Input Object</param>
        /// <returns></returns>
        public CustomUpdateInterlockStatusOutput CustomUpdateInterlockStatus(CustomUpdateInterlockStatusInput customUpdateInterlockStatusInput)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomUpdateInterlockStatus",
            new KeyValuePair<String, Object>("CustomUpdateInterlockStatusInput", customUpdateInterlockStatusInput));

            CustomUpdateInterlockStatusOutput output = null;

            try
            {


                // Verify if the input parameter is null
                Utilities.ValidateNullInput(customUpdateInterlockStatusInput, new List<string>() { "ResponseCode" });

                output = new CustomUpdateInterlockStatusOutput();

                #region Get input data

                long resourceId = long.Parse(customUpdateInterlockStatusInput.ResourceId);
                IResource resource = _entityFactory.Create<IResource>();
                resource.Load(resourceId);

                CustomInterlockAdmissionStateEnum interlockAdmissionState = (CustomInterlockAdmissionStateEnum)Enum.Parse(typeof(CustomInterlockAdmissionStateEnum), customUpdateInterlockStatusInput.InterlockStatus);

                #endregion

                string localizedMessage = String.Empty;

                if (resource.ObjectExists())
                {
                    resource.Load();

                    IAttributeCollection resourceAttributes = new AttributeCollection();


                    #region Check InterlockAdmissionState on resource

                    resource.LoadAttributes(new Collection<string>
                    {
                        IKEAConstants.CustomInterlockAdmissionState
                    });

                    CustomInterlockAdmissionStateEnum currentResourceInterlockAdmissionState = resource.GetAttributeValueOrDefault<CustomInterlockAdmissionStateEnum>(IKEAConstants.CustomInterlockAdmissionState);

                    if (currentResourceInterlockAdmissionState != interlockAdmissionState)
                    {
                        resourceAttributes[IKEAConstants.CustomInterlockAdmissionState] = interlockAdmissionState;
                    }
                    else
                    {
                        string status = currentResourceInterlockAdmissionState.ToString();
                        localizedMessage = String.Format("Error: {0} ", _iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomNotificationDidNotUpdateInterlockStatus, status));
                    }

                    #endregion

                    #region Check Response Code

                    // Check if the we receive a response code and if that code is not empty
                    if (!string.IsNullOrWhiteSpace(customUpdateInterlockStatusInput.ResponseCode))
                    {
                        IEmployeeCollection employeesToBeNotified = _genericUtilities.GetCheckedInEmployees(resource.Name);

                        // Check if there are any employees to be notified
                        if (!employeesToBeNotified.IsNullOrEmpty())
                        {
                            // Get localized message by response code
                            localizedMessage = String.Format("{0} {1}", localizedMessage, _iKEAUtilities.GetIoTLocalizedMessageFromResponseCode(customUpdateInterlockStatusInput.ResponseCode));

                            // Get Error message from IoT response
                            if (!customUpdateInterlockStatusInput.ResponseMessage.IsNullOrEmpty())
                            {
                                localizedMessage = String.Format("{0}. Trace: {1}", localizedMessage, customUpdateInterlockStatusInput.ResponseMessage);
                            }

                            // Get Top Most Resource information
                            IResource topMostResource = resource.GetTopMostResource();

                            _iKEAUtilities.NotifyOnInterlockNotifications(
                                topMostResource,
                                _iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomAutomationAttachErrorTitleMessageLocalizedMessage, resource.Name),
                                localizedMessage);

                            resource.Load();
                        }
                    }

                    #endregion

                    #region EnableErrorHandler

                    resource.LoadAttributes(new Collection<string>
                    {
                        IKEAConstants.CustomResourcePalletizeErrorHandleEnabledAttribute,
                    });
                    bool errorHandleEnabled = resource.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomResourcePalletizeErrorHandleEnabledAttribute);

                    // If the input instructs us to enable the error handler and it is not already enabled
                    if (customUpdateInterlockStatusInput.EnableErrorHandler && !errorHandleEnabled)
                    {
                        resourceAttributes[IKEAConstants.CustomResourcePalletizeErrorHandleEnabledAttribute] = true;
                    }

                    #endregion

                    if (resourceAttributes.Any())
                    {
                        resource.SaveAttributes(resourceAttributes);
                        resource.Load();

                        // Spreads message stating line condition has changed to trigger refresh
                        string messageSubject = String.Format("{0}{1}", IKEAConstants.MessageBusResourceAndMaterialEventsPrefix, resource.Id);
                        List<string> refreshItems = new List<string>
                        {
                            "ResourceState",
                            "ActionButtons"
                        };
                        _iKEAUtilities.PublishCockpitTransactionalMessages(messageSubject, refreshItems: refreshItems);
                    }
                }

                if (!string.IsNullOrEmpty(customUpdateInterlockStatusInput.MaterialName))
                {
                    string materialName = customUpdateInterlockStatusInput.MaterialName;
                    IMaterial material = _entityFactory.Create<IMaterial>();
                    material.Load(materialName);

                    if (material.ObjectExists())
                    {
                        IAttributeCollection materialAttributes = new AttributeCollection();
                        material.LoadAttributes(new Collection<string>
                        {
                            IKEAConstants.CustomInterlockAdmissionState
                        });

                        CustomInterlockAdmissionStateEnum currentMaterialInterlockAdmissionState = material.GetAttributeValueOrDefault<CustomInterlockAdmissionStateEnum>(IKEAConstants.CustomInterlockAdmissionState);

                        if (currentMaterialInterlockAdmissionState != interlockAdmissionState)
                        {
                            materialAttributes[IKEAConstants.CustomInterlockAdmissionState] = interlockAdmissionState;
                        }

                        if (materialAttributes.Any())
                        {
                            material.SaveAttributes(materialAttributes);
                            material.Load();
                        }
                    }
                }


                // Close service:
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomUpdateInterlockStatusInput", customUpdateInterlockStatusInput),
                                            new KeyValuePair<String, Object>("CustomUpdateInterlockStatusOutput", output));

            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            return output;
        }

        /// <summary>
        /// Service to retrieve a the resource state history
        /// </summary>
        /// <param name="customGetResourceStateHistoryInput">Input Object</param>
        /// <returns>Output Objects</returns>
        public CustomGetResourceStateHistoryOutput CustomGetResourceStateHistory(CustomGetResourceStateHistoryInput customGetResourceStateHistoryInput)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomGetResourceStateHistory",
                new KeyValuePair<String, Object>("CustomGetResourceStateHistoryInput", customGetResourceStateHistoryInput));

            CustomGetResourceStateHistoryOutput output = new CustomGetResourceStateHistoryOutput();

            try
            {
                // Verify if the input parameter is null
                Utilities.ValidateNullInput(customGetResourceStateHistoryInput);

                DataSet dataSet = _iKEAUtilities.GetResourceStateHistoryDataSet(customGetResourceStateHistoryInput.User, customGetResourceStateHistoryInput.Resource);

                if (dataSet.HasData())
                {
                    output.ResourceStateHistory = dataSet.ToNgpDataSet();
                }

                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomGetResourceStateHistoryInput", customGetResourceStateHistoryInput),
                                            new KeyValuePair<String, Object>("CustomGetResourceStateHistoryOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            return output;
        }

        /// <summary>
        /// Service to save the resource state reclassifications
        /// </summary>
        /// <param name="input">Input Object</param>
        /// <returns>Output Objects</returns>
        public CustomSaveResourceStateReclassificationOutput CustomSaveResourceStateReclassification(CustomSaveResourceStateReclassificationInput input)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomSaveResourceStateReclassification",
                new KeyValuePair<string, object>("CustomSaveResourceStateReclassificationInput", input));

            CustomSaveResourceStateReclassificationOutput output = new CustomSaveResourceStateReclassificationOutput();

            try
            {
                // Verify if the input parameter is null
                Utilities.ValidateNullInput(input);

                if (!String.IsNullOrWhiteSpace(input.ServiceComments))
                {
                    ApplicationContext.CallContext.AddServiceComments(input.ServiceComments);
                }

                Dictionary<ICustomResourceStateReclassification, ICustomResourceStateReclassification> resourceStateReclassifications = input.ResourceStateReclassifications;

                ICustomResourceStateReclassificationCollection stateReclassifications = _entityFactory.CreateCollection<ICustomResourceStateReclassificationCollection>();
                stateReclassifications.AddRange(resourceStateReclassifications.Values);

                // Get current user
                IUser currentUser = new Foundation.Security.User();
                currentUser.Load(Utilities.DomainUserName);

                //Get Resource being reclassified
                IResource resource = _entityFactory.Create<IResource>();
                resource.Load(stateReclassifications.First().ResourceId.GetValueOrDefault());

                //By merging data from state history, we are ensuring the input's previous state data integrity
                DataSet historyDataSet = _iKEAUtilities.GetResourceStateHistoryDataSet(currentUser, resource);

                if (historyDataSet.HasData())
                {
                    IEnumerable<DataRow> dataRows = historyDataSet.Tables[0].AsEnumerable();

                    IEnumerable<Tuple<ICustomResourceStateReclassification, DataRow>> historyAndReclassificationJoinData = resourceStateReclassifications.Keys.Join(dataRows,
                        sr => new { sr.ServiceHistoryIdStart, sr.ServiceHistoryIdEnd, sr.OperationHistorySequenceStart, sr.OperationHistorySequenceEnd },
                        dr => new
                        {
                            ServiceHistoryIdStart = dr.Field<long?>("StartServiceHistoryId"),
                            ServiceHistoryIdEnd = dr.Field<long?>("EndServiceHistoryId"),
                            OperationHistorySequenceStart = dr.Field<long?>("StartOperationHistorySeq"),
                            OperationHistorySequenceEnd = dr.Field<long?>("EndOperationHistorySeq")
                        },
                        (sr, dr) => Tuple.Create(sr, dr));

                    foreach (Tuple<ICustomResourceStateReclassification, DataRow> tuple in historyAndReclassificationJoinData)
                    {
                        var stateReclassification = tuple.Item1;
                        var dataRow = tuple.Item2;

                        stateReclassification.StateModelId = dataRow.Field<long?>("MainStateModelId");
                        stateReclassification.StateModelStateId = dataRow.Field<long?>("MainStateModelStateId");
                        stateReclassification.StateModelStateReason = dataRow.Field<string>("MainStateModelStateReason");
                    }

                    // Validate if the user is able to reclassify the states of the resource
                    _iKEAUtilities.ValidateReclassificationPermissions(resourceStateReclassifications, currentUser, input.ServiceComments);

                    long resourceId = stateReclassifications.First().ResourceId.GetValueOrDefault();

                    // Get existing reclassifications
                    ICustomResourceStateReclassificationCollection existingStateReclassifications = _iKEAUtilities.GetCustomResourceStateReclassifications(stateReclassifications);

                    // Check if there are any existing reclassification for the give service history Ids
                    if (!existingStateReclassifications.IsNullOrEmpty())
                    {
                        // Because the reclassifications are terminated we need to unterminate them, 
                        // update them and then terminate them again
                        existingStateReclassifications.Unterminate();

                        // Update the existing reclassification with the new states
                        foreach (ICustomResourceStateReclassification existingStateReclassification in existingStateReclassifications)
                        {
                            ICustomResourceStateReclassification newStateReclassification = stateReclassifications.First(sr => sr.ResourceId == existingStateReclassification.ResourceId
                                                                                                                                && sr.ServiceHistoryIdStart == existingStateReclassification.ServiceHistoryIdStart
                                                                                                                                && sr.OperationHistorySequenceStart == existingStateReclassification.OperationHistorySequenceStart
                                                                                                                                && sr.ServiceHistoryIdEnd == existingStateReclassification.ServiceHistoryIdEnd
                                                                                                                                && sr.OperationHistorySequenceEnd == existingStateReclassification.OperationHistorySequenceEnd);

                            existingStateReclassification.StateModelId = newStateReclassification.StateModelId;
                            existingStateReclassification.StateModelStateId = newStateReclassification.StateModelStateId;
                            existingStateReclassification.StateModelStateReason = newStateReclassification.StateModelStateReason;

                            existingStateReclassification.Save();

                            // Update reclassification attributes
                            var comment = newStateReclassification.GetAttributeValue(ResourceStateReclassificationConstants.CustomCommentAttribute);
                            var stateReasonDetails = newStateReclassification.GetAttributeValue(ResourceStateReclassificationConstants.StateReasonDetails);
                            var wo = newStateReclassification.GetAttributeValue(ResourceStateReclassificationConstants.WO);

                            existingStateReclassification.SaveAttributes(new AttributeCollection
                            {
                                { ResourceStateReclassificationConstants.CustomCommentAttribute, comment },
                                { ResourceStateReclassificationConstants.StateReasonDetails, stateReasonDetails },
                                { ResourceStateReclassificationConstants.WO, wo }
                            });
                            // Remove the reclassification from the ones that are going to be created
                            stateReclassifications.Remove(newStateReclassification);
                        }


                        existingStateReclassifications.Save();
                        existingStateReclassifications.Terminate();
                    }

                    // Check if there are any reclassifications to be created
                    if (!stateReclassifications.IsNullOrEmpty())
                    {
                        // Generate a name for the reclassifications
                        stateReclassifications.ToList().ForEach(E => E.Name = DateTime.Now.ToFileTime().ToString());

                        // Crete the reclassification and terminate it right after
                        stateReclassifications.Create();
                        stateReclassifications.Terminate();
                    }

                    output.CustomResourceStateReclassificationCollection = stateReclassifications;
                }


                // Close service
                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomSaveResourceStateReclassificationInput", input),
                                            new KeyValuePair<String, Object>("CustomSaveResourceStateReclassificationOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            return output;
        }

        /// <summary>
        /// Posts data points to one or more charts
        /// </summary>
        /// <param name="customPostDataToChartsInput">Input Object</param>
        /// <returns></returns>
        public CustomPostDataToChartsOutput CustomPostDataToCharts(CustomPostDataToChartsInput customPostDataToChartsInput)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomPostDataToCharts", new KeyValuePair<String, Object>("CustomPostDataToChartsInput", customPostDataToChartsInput));
            CustomPostDataToChartsOutput customPostDataToChartsOutput = null;

            try
            {
                //Set Output:
                customPostDataToChartsOutput = new CustomPostDataToChartsOutput();
                //Validate Input:
                Utilities.ValidateNullInput(customPostDataToChartsInput, new List<string>() { "AdditionalContext" });

                //Log service comments if existing:
                if (!String.IsNullOrWhiteSpace(customPostDataToChartsInput.ServiceComments)) ApplicationContext.CallContext.AddServiceComments(customPostDataToChartsInput.ServiceComments);

                //Load Resource               
                IResource resource = _entityFactory.Create<IResource>();
                resource.Name = customPostDataToChartsInput.Resource;
                resource.Load();

                //Load Charts
                IChartCollection chartsToPost = _entityFactory.CreateCollection<IChartCollection>();
                foreach (var parameter in customPostDataToChartsInput.Readings.Keys)
                {
                    var chart = _entityFactory.Create<IChart>();
                    chart.Name = parameter;
                    chartsToPost.Add(chart);
                }
                chartsToPost.Load();


                //Prepare Chart Data Points Context
                Dictionary<string, string> chartContext = _iKEAUtilities.BuildChartDataPointContext(resource, customPostDataToChartsInput.AdditionalContext);

                //Post data points to chart
                foreach (IChart chart in chartsToPost)
                {
                    IPostChartDataPointParametersCollection points = new PostChartDataPointParametersCollection();

                    points.Add(new PostChartDataPointParameters());
                    points[0].Readings = new Collection<KeyValuePair<string, decimal>>();

                    int readingNumber = 0;
                    foreach (var reading in customPostDataToChartsInput.Readings[chart.Name])
                    {
                        points[0].Readings.Add(new KeyValuePair<string, decimal>(readingNumber.ToString(), Convert.ToDecimal(reading)));
                        readingNumber++;
                    }
                    points[0].SampleSize = 1;
                    points[0].SampleId = DateTime.UtcNow.ToString("ddMMyyyyHHmmssfff");

                    chart.LoadContextInformation();
                    chartContext = _iKEAUtilities.UpdateChartContextsWithRevision(chartContextInfo: chart.ContextInformation, chartContext: chartContext);

                    chart.PostDataPoints(chartContext, points, ReadingsMode.IndividualValues);
                }
                chartsToPost.Load();

                customPostDataToChartsOutput.Charts = chartsToPost;

                //Log method exit:
                long objectInstanceId = -1;
                long objectTypeId = -1;
                Utilities.EndMethod(objectTypeId, objectInstanceId, new KeyValuePair<String, Object>("CustomPostDataToChartsInput", customPostDataToChartsInput),
                                                                    new KeyValuePair<String, Object>("CustomPostDataToChartsOutput", customPostDataToChartsOutput));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            return customPostDataToChartsOutput;
        }

        /// <summary>
        /// Service to get the outsorted quantity of a Material attach to a resource from EI
        /// </summary>
        /// <param name="input">CustomGetOutsortedUnitsInformationInput</param>
        /// <returns>CustomGetOutsortedUnitsInformationOutput</returns>
        /// <exception cref="Cmf.Foundation.Common.CmfBaseException">If any unexpected error occurs.</exception>
        public CustomGetOutsortedUnitsInformationOutput CustomGetOutsortedUnitsInformation(CustomGetOutsortedUnitsInformationInput input)
        {
            Utilities.StartMethod(
                OBJECT_TYPE_NAME,
                "CustomGetOutsortedUnitsInformation",
                new KeyValuePair<string, object>("CustomGetOutsortedUnitsInformationInput", input));

            CustomGetOutsortedUnitsInformationOutput output = null;
            try
            {
                Utilities.ValidateNullInput(input);

                output = new CustomGetOutsortedUnitsInformationOutput();

                IMaterial material = _entityFactory.Create<IMaterial>();
                material.Load(input.MaterialID);

                List<ProductionCounterStructure> eiCurrentKnownOutsortedQuantities = _iKEAUtilities.GetOutsortedQuantityFromEI(input.Resource, material.Name);

                //If outsorted quantity retrieved from Equipment Integration was successfully parsed
                if (!eiCurrentKnownOutsortedQuantities.IsNullOrEmpty())
                {
                    // Get the material relations to the outfeeders and outsorters
                    material.LoadRelations(IKEAConstants.CustomManufacturingOrderOutFeeder);
                    if (material.HasRelations(IKEAConstants.CustomManufacturingOrderOutFeeder))
                    {
                        // Get the relation collection from the MO:
                        var relationCollection = material.RelationCollection[IKEAConstants.CustomManufacturingOrderOutFeeder].Select(RC => (RC as ICustomManufacturingOrderOutFeeder));
                        foreach (var eiCurrentKnownOutsortedQuantity in eiCurrentKnownOutsortedQuantities)
                        {
                            // Get the relation for this specific resource:
                            var resourceRelation = relationCollection.Where(RC => RC.TargetEntity.Name.CompareStrings(eiCurrentKnownOutsortedQuantity.Name)).FirstOrDefault();
                            if (resourceRelation != null)
                            {
                                // Get the quantity from the specified resource:
                                decimal processedQuantity = resourceRelation.CurrentProcessedOutsortedQuantity.Value;

                                // Set pallet quantity with the value that can be outsorted:
                                decimal finalValue = eiCurrentKnownOutsortedQuantity.TotalQuantity - processedQuantity;
                                eiCurrentKnownOutsortedQuantity.PalletQuantity = finalValue;
                            }
                        }
                    }

                    output.EIReply = eiCurrentKnownOutsortedQuantities;
                }
                else
                {
                    //Equipment integration parse failed, could not validate
                    throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomCurrentKnownOutsortedQuantityParseError));
                }

                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomGetOutsortedUnitsInformationInput", input),
                                            new KeyValuePair<string, object>("CustomGetOutsortedUnitsInformationOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw new CmfBaseException(ex.Message, ex);
            }

            return output;
        }

        /// <summary>
        /// Custom Get Data For PPM
        /// </summary>
        /// <param name="input">CustomGetDataForPPM Input</param>
        /// <returns>CustomGetDataForPPM Output</returns>
        /// <exception cref="Cmf.Foundation.Common.CmfBaseException">If any unexpected error occurs.</exception>
        public CustomGetDataForPPMOutput CustomGetDataForPPM(CustomGetDataForPPMInput input)
        {
            Utilities.StartMethod(
                OBJECT_TYPE_NAME,
                "CustomGetDataForPPM",
                new KeyValuePair<string, object>("CustomGetDataForPPMInput", input));

            CustomGetDataForPPMOutput output = null;
            try
            {
                Cmf.Foundation.Common.Utilities.ValidateNullInput(input);

                ApplicationContext.CallContext.AddServiceComments(input.ServiceComments);
                output = new CustomGetDataForPPMOutput();

                TransactionOptions options = new TransactionOptions();
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Suppress, options))
                {
                    DataSet reasonsFrequencyAndPercentage = _iKEAUtilities.GetReasonsFrequencyAndPercentage(input.TimeFrame,
                                                                                                        input.FacilityName,
                                                                                                        input.AreaName,
                                                                                                        input.Resources,
                                                                                                        input.Steps,
                                                                                                        input.ProductGroupName,
                                                                                                        input.ProductType,
                                                                                                        input.Products,
                                                                                                        input.StepTypes,
                                                                                                        input.ResourceTypes,
                                                                                                        input.ResourceResourceTypes,
                                                                                                        input.ShiftDefinition,
                                                                                                        input.Shifts);

                    output.ReasonsFrequencyAndPercentage = NgpDataSet.FromDataSet(reasonsFrequencyAndPercentage);
                    output.YieldAndCycleTime = KPIManager.GetYieldAndCycleTime(input.TimeFrame, input.GetActual, input.FacilityName, input.AreaName, input.Resources, input.Steps, input.ProductGroupName,
                        input.ProductType, input.Products, input.StepTypes, input.ResourceTypes, input.ResourceResourceTypes, input.CycleTimeScale, input.IsMaterialCycleTime);
                }

                Utilities.EndMethod(
                    -1,
                    -1,
                    new KeyValuePair<string, object>("CustomGetDataForPPMInput", input),
                    new KeyValuePair<string, object>("CustomGetDataForPPMOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw new CmfBaseException(ex.Message, ex);
            }

            return output;
        }

        /// <summary>
        /// Forces the Unit Completion of a MO
        /// </summary>
        /// <param name="input">CustomForceUnitCompletion Input</param>
        /// <returns>CustomForceUnitCompletion Output</returns>
        /// <exception cref="Cmf.Foundation.Common.CmfBaseException">If any unexpected error occurs.</exception>
        public CustomForceUnitCompletionOutput CustomForceUnitCompletion(CustomForceUnitCompletionInput input)
        {
            Utilities.StartMethod(
                OBJECT_TYPE_NAME,
                "CustomForceUnitCompletion",
                new KeyValuePair<string, object>("CustomForceUnitCompletionInput", input));

            CustomForceUnitCompletionOutput output = null;
            try
            {
                Utilities.ValidateNullInput(input);

                output = new CustomForceUnitCompletionOutput();

                output.Success = _iKEAUtilities.CustomForceUnitCompletionHelper(input.Material, input.ForceCompletionResource);

                Utilities.EndMethod(
                    -1,
                    -1,
                    new KeyValuePair<string, object>("CustomForceUnitCompletionInput", input),
                    new KeyValuePair<string, object>("CustomForceUnitCompletionOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw new CmfBaseException(ex.Message, ex);
            }

            return output;
        }

        /// <summary>
        /// Service used for retrieving a Resource's history of stop states.
        /// </summary>
        /// <param name="customGetResourceStopStateHistoryInput">Input Object</param>
        /// <returns>Output Object</returns>
        public CustomGetResourceStopStateHistoryOutput CustomGetResourceStopStateHistory(CustomGetResourceStopStateHistoryInput customGetResourceStopStateHistoryInput)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomGetResourceStopStateHistory", new KeyValuePair<string, object>("CustomGetResourceStopStateHistoryInput", customGetResourceStopStateHistoryInput));

            CustomGetResourceStopStateHistoryOutput output;

            try
            {
                Utilities.ValidateNullInput(customGetResourceStopStateHistoryInput, new List<string>() { "StateModelStateAttributeFilters" });

                output = new CustomGetResourceStopStateHistoryOutput();

                CustomMicrostopThresholdFilterEnum microstopFilter = customGetResourceStopStateHistoryInput.IgnoreThreshold ? CustomMicrostopThresholdFilterEnum.ExcludeMicrostops : CustomMicrostopThresholdFilterEnum.All;

                DataSet resultDataset = _iKEAUtilities.GetResourceStateHistoryForStopReclassificationDataSet(customGetResourceStopStateHistoryInput.FromDate, customGetResourceStopStateHistoryInput.ToDate,
                    customGetResourceStopStateHistoryInput.Resource, microstopFilter, customGetResourceStopStateHistoryInput.StateModelStateAttributeFilters);

                // filtering row according to filters

                for (int i = 0; i < resultDataset.Tables[0].Rows.Count; i++)
                {
                    string mainStateModelStateName = (string)resultDataset.Tables[0].Rows[i]["MainStateModelStateName"];
                    string mainStateModelStateReason = (string)resultDataset.Tables[0].Rows[i]["MainStateModelStateReason"];
                    if (!customGetResourceStopStateHistoryInput.StateModelStateFilters.IsNullOrEmpty() &&
                        !customGetResourceStopStateHistoryInput.StateModelStateFilters.Equals(mainStateModelStateName))
                    {
                        resultDataset.Tables[0].Rows[i].Delete();
                    }
                    else if (!customGetResourceStopStateHistoryInput.StateModelStateReasonFilters.IsNullOrEmpty() &&
                       !customGetResourceStopStateHistoryInput.StateModelStateReasonFilters.Equals(mainStateModelStateReason))
                    {
                        resultDataset.Tables[0].Rows[i].Delete();
                    }
                }
                resultDataset.AcceptChanges();

                output.ResourceStopStateHistory = NgpDataSet.FromDataSet(resultDataset);

            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw new CmfBaseException(ex.Message, ex);
            }

            Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomGetResourceStopStateHistoryInput", customGetResourceStopStateHistoryInput),
                            new KeyValuePair<string, object>("CustomGetResourceStopStateHistoryOutput", output));

            return output;
        }

        /// <summary>
        /// Service to Palletize Materials From Outsorted Cockpit
        /// </summary>
        /// <param name="input">CustomOutsourtedPalletize Input</param>
        /// <returns>CustomOutsourtedPalletize Output</returns>
        /// <exception cref="Cmf.Foundation.Common.CmfBaseException">If any unexpected error occurs.</exception>
        public CustomOutsourtedPalletizeOutput CustomOutsourtedPalletize(CustomOutsourtedPalletizeInput input)
        {
            Utilities.StartMethod(
                OBJECT_TYPE_NAME,
                "CustomOutsourtedPalletize",
                new KeyValuePair<string, object>("CustomOutsourtedPalletizeInput", input));

            CustomOutsourtedPalletizeOutput output = null;
            try
            {
                Utilities.ValidateNullInput(input, new List<string> { "ReturnFlowPath", "ReturnFlow", "ReturnStep" });

                output = new CustomOutsourtedPalletizeOutput();

                Dictionary<IMaterial, IRecordLossParameters> materialLosses = new Dictionary<IMaterial, IRecordLossParameters>();
                Dictionary<IMaterial, ISplitInputParametersCollection> materialSplits = new Dictionary<IMaterial, ISplitInputParametersCollection>();

                IMaterialCollection materials = _entityFactory.CreateCollection<IMaterialCollection>(); ;
                materials.AddRange(input.MaterialsToPalletize.Select(m => m.Material));
                materials.Load();

                Dictionary<string, IMaterial> loadedMaterials = materials.ToDictionary(m => m.Name, m => m);

                Dictionary<string, Dictionary<string, decimal>> materialMaterialTypeQuantities = new Dictionary<string, Dictionary<string, decimal>>();

                // Load all reasons
                IReasonCollection reasons = _entityFactory.CreateCollection<IReasonCollection>();
                reasons.AddRange(input.MaterialsToPalletize.Where(mt => !mt.MaterialTypeQuantity.Values.IsNullOrEmpty()).SelectMany(mt => mt.MaterialTypeQuantity.Values.SelectMany(mtq => mtq.Where(r => !string.IsNullOrWhiteSpace(r.Reason)).Select(r =>
                { var reason = _entityFactory.Create<IReason>(); reason.Name = r.Reason; return reason; }))));
                reasons.Load();

                // Get the good type quantity
                string goodType = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.DefaultGoodTypeConfig);

                // Get Configured Pallet Form
                string palletForm = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.PalletMaterialForm);

                // Get Configured Order Form
                string orderForm = _iKEAUtilities.GetOrderMaterialForm();

                // Get Configured Intermediate ChangeType
                string intermediateChangeTypeName = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.MaterialTypeIntermediateChangeTypeConfig);

                // Get a dictionary with all the reasons
                Dictionary<string, IReason> loadedReasons = reasons.DistinctBy(r => r.Name).ToDictionary(r => r.Name, r => r);

                foreach (OutsortedMaterialPalletize materialPalletize in input.MaterialsToPalletize)
                {
                    IEnumerable<OutsortedMaterialTypeQuantity> materialTypeQuantities = materialPalletize.MaterialTypeQuantity.Values.SelectMany(r => r);

                    // Get Completed Form for the material
                    String completedForm = _iKEAUtilities.GetCompletedMaterialForm(materialPalletize.Material);

                    // Retrieve corresponding name generator
                    String completedFormNameGeneratorName = _iKEAUtilities.GetMaterialNameGenerator(completedForm);
                    var completedFormNameGenerator = _entityFactory.Create<INameGenerator>();

                    #region Prepare Record Losses

                    // Create a LossBonusAffectedQuantity Collections
                    ILossBonusAffectedQuantityCollection lossBonus = new LossBonusAffectedQuantityCollection();
                    foreach (string reasonName in loadedReasons.Keys)
                    {
                        decimal reasonPrimaryQuantity = materialTypeQuantities.Where(mt => !string.IsNullOrWhiteSpace(mt.Reason) && mt.Reason.Equals(reasonName)).Select(mt => mt.Quantity).Sum();
                        lossBonus.Add(new LossBonusAffectedQuantity { Reason = loadedReasons[reasonName], ReasonPrimaryQuantity = reasonPrimaryQuantity });
                    }

                    if (!lossBonus.IsNullOrEmpty())
                    {
                        IRecordLossParameters lossParameters = new RecordLossParameters()
                        {
                            LossReasons = lossBonus
                        };

                        materialLosses.Add(materialPalletize.Material, lossParameters);
                    }

                    #endregion

                    #region Prepare First Split

                    Dictionary<string, decimal> typeQuantity = materialPalletize.MaterialTypeQuantity.ToDictionary(mt => mt.Key, mt => mt.Value.Sum(r => r.Quantity));

                    // Prepare the parameters for the first split of the materials
                    ISplitInputParametersCollection splitInputs = new SplitInputParametersCollection();
                    splitInputs.AddRange(typeQuantity.Select(q => new SplitInputParameters()
                    {
                        PrimaryQuantity = q.Key == goodType ? q.Value : 0,
                        SecondaryQuantity = q.Key == goodType ? 0 : q.Value,
                        Name = completedFormNameGenerator.GenerateName(completedFormNameGeneratorName, materialPalletize.Material)
                    }));

                    materialSplits.Add(materialPalletize.Material, splitInputs);

                    materialMaterialTypeQuantities.Add(materialPalletize.Material.Name, typeQuantity);

                    #endregion
                }

                #region Record Losses

                // Record losses in the original pallets
                if (!materialLosses.IsNullOrEmpty())
                {
                    materials.RecordLoss(materialLosses, new OperationAttributeCollection());
                }

                #endregion

                #region Split Quantities

                Dictionary<string, IMaterialCollection> splitMaterials = new Dictionary<string, IMaterialCollection>();
                // Do the first split of the materials
                if (!materialSplits.IsNullOrEmpty())
                {
                    IMaterialCollection mainMaterials = _entityFactory.CreateCollection<IMaterialCollection>(); ;
                    mainMaterials.AddRange(materialSplits.Keys);
                    mainMaterials.LoadRelations(IKEAConstants.CustomMaterialLoss);

                    foreach (var materialToSplit in materialSplits)
                    {
                        if (materialToSplit.Key.GetNativeValue<long>("ProductionOrder") > 0)
                        {
                            // We need to load the production order because, if we are dealing with
                            // material of the same PO an error will appear indicating that
                            // data has changed since last viewed
                            materialToSplit.Key.ProductionOrder.Load();
                        }

                        splitMaterials.Add(materialToSplit.Key.Name, materialToSplit.Key.Split(materialToSplit.Value, true));
                    }
                }

                #endregion

                #region Merge Materials

                // Merge the materials by type
                if (!splitMaterials.IsNullOrEmpty())
                {
                    IMaterialCollection mergedMaterials = _entityFactory.CreateCollection<IMaterialCollection>(); ;


                    var materialByTypes = input.MaterialsToPalletize.SelectMany(m => m.MaterialTypeQuantity.Select(mt => new { Type = mt.Key, Material = m.Material.Name, Quantity = mt.Value.Sum(r => r.Quantity), Reasons = mt.Value.Where(r => !string.IsNullOrWhiteSpace(r.Reason)).Select(r => new LossBonusAffectedQuantity() { Reason = loadedReasons[r.Reason], ReasonPrimaryQuantity = r.Quantity, ReasonSecondaryQuantity = 0 }) }))
                                                                     .GroupBy(m => m.Type)
                                                                     .ToDictionary(mt => mt.Key, mt => mt.ToList());

                    Dictionary<IMaterial, string> materialNewTypes = new Dictionary<IMaterial, string>();
                    Dictionary<IMaterial, string> materialInterimType = new Dictionary<IMaterial, string>();

                    // Group the material by type
                    foreach (var materialByType in materialByTypes)
                    {
                        IMaterial mainMaterialToMerge = null;

                        Dictionary<IMaterial, IMergeMaterialParameters> materialMergeMaterials = new Dictionary<IMaterial, IMergeMaterialParameters>();

                        Dictionary<IMaterial, ILossBonusAffectedQuantityCollection> materialsLossesToCopy = new Dictionary<IMaterial, ILossBonusAffectedQuantityCollection>();

                        foreach (var type in materialByType.Value)
                        {
                            ILossBonusAffectedQuantityCollection lossesToCopy = new LossBonusAffectedQuantityCollection();

                            IMaterial materialToMerge = splitMaterials[type.Material].FirstOrDefault(m => (type.Type == goodType && m.PrimaryQuantity == type.Quantity) || (type.Type != goodType && m.SecondaryQuantity == type.Quantity));

                            if (mainMaterialToMerge == null)
                            {
                                mainMaterialToMerge = materialToMerge;
                            }
                            else
                            {
                                materialMergeMaterials.Add(materialToMerge, new MergeMaterialParameters());
                            }

                            // If there is any multiple reasons of the same type, add their quantity together
                            Dictionary<IReason, decimal?> lossesQuantity = new Dictionary<IReason, decimal?>();
                            foreach (ILossBonusAffectedQuantity singleLoss in type.Reasons)
                            {
                                if (lossesQuantity.ContainsKey(singleLoss.Reason))
                                {
                                    lossesQuantity[singleLoss.Reason] += singleLoss.ReasonPrimaryQuantity;
                                }
                                else
                                {
                                    lossesQuantity.Add(singleLoss.Reason, singleLoss.ReasonPrimaryQuantity);
                                }
                            }

                            // Create LossBonusAffectedQuantity for every different reason with the previous calculated quantity
                            foreach (IReason lossQuantityKey in lossesQuantity.Keys)
                            {
                                lossesToCopy.Add(new LossBonusAffectedQuantity()
                                {
                                    Reason = lossQuantityKey,
                                    ReasonPrimaryQuantity = lossesQuantity[lossQuantityKey],
                                    ReasonSecondaryQuantity = 0
                                });
                            }

                            materialsLossesToCopy.Add(loadedMaterials[type.Material], lossesToCopy);

                            // Remove the material being used
                            splitMaterials[type.Material].Remove(materialToMerge);
                        }

                        if (mainMaterialToMerge != null && !materialMergeMaterials.IsNullOrEmpty())
                        {
                            if (mainMaterialToMerge.GetNativeValue<long>("ProductionOrder") > 0)
                            {
                                // We need to load the production order because, if we are dealing with
                                // material of the same PO an error will appear indicating that
                                // data has changed since last viewed
                                mainMaterialToMerge.ProductionOrder.Load();
                            }

                            mainMaterialToMerge.Merge(materialMergeMaterials);

                        }

                        if (!materialsLossesToCopy.IsNullOrEmpty())
                        {
                            // Copy CustomMaterialLoss to new materials
                            _iKEAUtilities.CopyCustomMaterialLoss(materialsLossesToCopy, mainMaterialToMerge, true);
                        }

                        mergedMaterials.Add(mainMaterialToMerge);

                        if (!mainMaterialToMerge.Type.CompareStrings(intermediateChangeTypeName))
                        {
                            materialNewTypes.Add(mainMaterialToMerge, materialByType.Key);
                            materialInterimType.Add(mainMaterialToMerge, intermediateChangeTypeName);
                        }
                    }

                    #region Change Material Types to the new ones

                    // Change the type of the materials
                    if (!materialNewTypes.IsNullOrEmpty())
                    {
                        // Change to InterimType
                        mergedMaterials.ChangeType(materialInterimType, false, new OperationAttributeCollection());

                        IMaterialCollection matNewTypes = _entityFactory.CreateCollection<IMaterialCollection>(); ;
                        foreach (var materialNewType in materialNewTypes)
                        {
                            materialNewType.Key.Type = materialNewType.Value;
                        }
                        matNewTypes.AddRange(materialNewTypes.Select(m => m.Key));

                        // Change to correct type
                        var changeMaterialTypeOutput = _materialOrchestration.ChangeMaterialsType(new ChangeMaterialsTypeInput()
                        {
                            Materials = matNewTypes,
                        });
                    }

                    #endregion
                    #region Change Flow and Step based on the return FlowPath

                    // If return flow path received in service input
                    if (!input.ReturnFlowPath.IsNullOrEmpty())
                    {
                        IMaterialCollection materialsToUpdateFlowPath = _entityFactory.CreateCollection<IMaterialCollection>();
                        // Add materials to updateFlowPath collection if it's not in store, only add if the flowPath is different
                        materialsToUpdateFlowPath.AddRange(mergedMaterials.Where(mat => mat.FlowPath != input.ReturnFlowPath && mat.IsInStore.GetValueOrDefault() == false));

                        //IMaterialOrchestration materialOrchestration = new MaterialOrchestration();
                        IMaterialCollection materialsToRetrieve = _entityFactory.CreateCollection<IMaterialCollection>();
                        // Add material to retrieve collection if it's already in store, this list used to retrieve materials from store, only add if the flowPath is different
                        materialsToRetrieve.AddRange(mergedMaterials.Where(mat => mat.FlowPath != input.ReturnFlowPath && mat.IsInStore.GetValueOrDefault() == true));
                        if (materialsToRetrieve != null && materialsToRetrieve.Count > 0)
                        {
                            // Retrieve materials are in store and add to updateFlowPath collection
                            RetrieveMaterialsOutput retrieveMaterialsOutput = _materialOrchestration.RetrieveMaterials(new RetrieveMaterialsInput() { Materials = materialsToRetrieve });
                            materialsToUpdateFlowPath.AddRange(retrieveMaterialsOutput.Materials);
                        }

                        if (materialsToUpdateFlowPath != null && materialsToUpdateFlowPath.Count > 0)
                        {
                            // materialOrchestration.ChangeMaterialFlowAndStep is triggered instead of MaterialCollection.ChangeFlowAndStep to resolve CustomMaterialMovementConfiguration & trigger material transfer if configured
                            foreach (IMaterial mat in materialsToUpdateFlowPath)
                            {
                                _materialOrchestration.ChangeMaterialFlowAndStep(new ChangeMaterialFlowAndStepInput() { Material = mat, FlowPath = input.ReturnFlowPath, Step = input.ReturnStep, Flow = input.ReturnFlow });
                            }
                        }
                        // Load material to use it in next section
                        mergedMaterials.Load();
                    }

                    #endregion
                    #region Create Pallets

                    StringBuilder generatedMaterials = new StringBuilder();

                    Dictionary<IMaterial, string> splitMaterialNewTypes = new Dictionary<IMaterial, string>();
                    Dictionary<IMaterial, string> splitMaterialInterimType = new Dictionary<IMaterial, string>();
                    IEntityFactory entityFactory = _serviceProvider.GetRequiredService<IEntityFactory>();
                    IMaterialCollection createdPallets = _entityFactory.CreateCollection<IMaterialCollection>();

                    // Create The Final Pallets
                    if (!mergedMaterials.IsNullOrEmpty())
                    {
                        generatedMaterials.Append(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomOutsortedPalletizeSuccessMessageLocalizedMessage));

                        mergedMaterials.LoadAttributes(new Collection<string>() { IKEAConstants.CustomMaterialAttributeDefaultCompletedQuantity });

                        Dictionary<IMaterial, ISplitInputParametersCollection> generatedPallets = new Dictionary<IMaterial, ISplitInputParametersCollection>();

                        foreach (IMaterial mergedMaterial in mergedMaterials)
                        {
                            bool goodMaterial = mergedMaterial.Type == goodType;

                            decimal materialQuantity = goodMaterial ? mergedMaterial.PrimaryQuantity.GetValueOrDefault() : mergedMaterial.SecondaryQuantity.GetValueOrDefault();

                            decimal defaultPalletQuantity = mergedMaterial.GetAttributeValueOrDefault<decimal>(IKEAConstants.CustomMaterialAttributeDefaultCompletedQuantity);

                            // if there isn't any default pallet quantity, use the entire quantity of the material
                            defaultPalletQuantity = defaultPalletQuantity == 0 ? materialQuantity : defaultPalletQuantity;

                            if (defaultPalletQuantity > 0)
                            {
                                String completedForm = _iKEAUtilities.GetCompletedMaterialForm(mergedMaterial);

                                // Retrieve corresponding name generator
                                String completedFormNameGeneratorName = _iKEAUtilities.GetMaterialNameGenerator(completedForm);

                                int numberOfPalletsToCreate = decimal.ToInt32(Math.Ceiling(materialQuantity / defaultPalletQuantity));

                                decimal lastPalletQuantity;

                                // if the default pallet quantity is 1 then we will use it to define the last pallet
                                if (defaultPalletQuantity == 1)
                                {
                                    lastPalletQuantity = defaultPalletQuantity;
                                }
                                else
                                {
                                    // if the default pallet quantity is grater then 1 then we will calculate the last pallet
                                    lastPalletQuantity = (materialQuantity <= defaultPalletQuantity) ? materialQuantity : Math.Abs((numberOfPalletsToCreate * defaultPalletQuantity) - materialQuantity - defaultPalletQuantity);
                                }

                                ISplitInputParametersCollection splitInputs = new SplitInputParametersCollection();

                                // If only one pallet outsort and quantity less than defaultPalletQuantity then do not not split the pallet again
                                if (input.MaterialsToPalletize.Count == 1 && numberOfPalletsToCreate == 1 && mergedMaterial.Form == palletForm)
                                {
                                    // Save the generated Pallets to present in the feedback messages
                                    generatedMaterials.Append(string.Join(",", mergedMaterial.Name)).Append(",");
                                    // Add to createdPallets collection
                                    createdPallets.Add(mergedMaterial);
                                }
                                else if (input.MaterialsToPalletize.Count == 1 && numberOfPalletsToCreate == 1 && mergedMaterial.Form == orderForm)
                                {
                                    // Change OrderForm to PalletForm and Trigger ChangeType, Since OrderForm does not generate ChangeType to ERP
                                    mergedMaterial.Load();
                                    mergedMaterial.Form = palletForm;
                                    mergedMaterial.Save();

                                    string previousType = mergedMaterial.Type;
                                    mergedMaterial.ChangeType(intermediateChangeTypeName, false, new OperationAttributeCollection());

                                    mergedMaterial.Type = previousType;
                                    var changeMaterialTypeOutput = _materialOrchestration.ChangeMaterialType(new ChangeMaterialTypeInput()
                                    {
                                        Material = mergedMaterial,
                                    });

                                    // Save the generated Pallets to present in the feedback messages
                                    generatedMaterials.Append(string.Join(",", mergedMaterial.Name)).Append(",");
                                    // Add to createdPallets collection
                                    createdPallets.Add(mergedMaterial);
                                }
                                else
                                {
                                    // Generate the Split parameters for all the pallets
                                    for (int i = 0; i < numberOfPalletsToCreate; i++)
                                    {
                                        decimal newQuantity = (i == (numberOfPalletsToCreate - 1) ? lastPalletQuantity : defaultPalletQuantity);
                                        var completedFormNameGenerator = _entityFactory.Create<INameGenerator>();
                                        splitInputs.Add(new SplitInputParameters()
                                        {
                                            PrimaryQuantity = goodMaterial ? newQuantity : 0,
                                            SecondaryQuantity = goodMaterial ? 0 : newQuantity,
                                            Name = completedFormNameGenerator.GenerateName(completedFormNameGeneratorName, mergedMaterial)
                                        });
                                    }

                                    if (splitInputs != null && splitInputs.Count > 0)
                                    {
                                        // Using the orchestration here so that it prints a label if necessary
                                        SplitMaterialOutput splitMaterialOutput = _materialOrchestration.SplitMaterial(new SplitMaterialInput()
                                        {
                                            Material = mergedMaterial,
                                            ChildMaterials = splitInputs,
                                            TerminateOnZeroQuantity = true,
                                            SplitMode = MaterialSplitMode.SplitNotAssembled
                                        });

                                        if (splitMaterialOutput.ChildMaterials != null && splitMaterialOutput.ChildMaterials.Count > 0)
                                        {
                                            splitMaterialNewTypes = new Dictionary<IMaterial, string>();
                                            splitMaterialInterimType = new Dictionary<IMaterial, string>();

                                            foreach (var splitMaterial in splitMaterialOutput.ChildMaterials)
                                            {
                                                if (splitMaterial.Form.CompareStrings(orderForm))
                                                {
                                                    splitMaterial.Form = completedForm;
                                                    splitMaterial.Save();
                                                }

                                                if (!splitMaterial.Type.CompareStrings(intermediateChangeTypeName))
                                                {
                                                    splitMaterialNewTypes.Add(splitMaterial, mergedMaterial.Type);
                                                    splitMaterialInterimType.Add(splitMaterial, intermediateChangeTypeName);
                                                }
                                            }

                                            // Change the type of the split materials
                                            if (!splitMaterialNewTypes.IsNullOrEmpty())
                                            {
                                                // Change to InterimType
                                                splitMaterialOutput.ChildMaterials.ChangeType(splitMaterialInterimType, false, new OperationAttributeCollection());

                                                IMaterialCollection splitMatNewTypes = _entityFactory.CreateCollection<IMaterialCollection>(); ;
                                                foreach (var splitMaterialNewType in splitMaterialNewTypes)
                                                {
                                                    splitMaterialNewType.Key.Type = splitMaterialNewType.Value;
                                                }
                                                splitMatNewTypes.AddRange(splitMaterialNewTypes.Select(m => m.Key));

                                                // Change to Correct Type
                                                var changeMaterialTypeOutput = _materialOrchestration.ChangeMaterialsType(new ChangeMaterialsTypeInput()
                                                {
                                                    Materials = splitMatNewTypes,
                                                });
                                            }

                                            splitMaterialOutput.ChildMaterials.Load();
                                        }

                                        mergedMaterial.Load();

                                        _iKEAUtilities.CopyCustomMaterialLoss(mergedMaterial, splitMaterialOutput.ChildMaterials, terminateOriginalLosses: true);

                                        if (mergedMaterial.UniversalState != UniversalState.Terminated && mergedMaterial.PrimaryQuantity.GetValueOrDefault() == 0 && mergedMaterial.SecondaryQuantity.GetValueOrDefault() == 0)
                                        {
                                            mergedMaterial.Terminate();
                                        }
                                        // Save the generated Pallets to present in the feedback messages
                                        generatedMaterials.Append(string.Join(",", splitMaterialOutput.ChildMaterials.Select(m => m.Name))).Append(",");
                                        // Add to createdPallets collection
                                        createdPallets.AddRange(splitMaterialOutput.ChildMaterials);
                                    }
                                }
                            }
                        }
                    }
                    // Store Good Material to Storage Resource
                    if (createdPallets != null && createdPallets.Count > 0)
                    {
                        IMaterialCollection goodCreatedPalletsNotInStore = entityFactory.CreateCollection<IMaterialCollection>();
                        // Get CreatedPallet, Not in Store, Good Type and Step has QueuedStorageService & ProcessedStorageService property
                        goodCreatedPalletsNotInStore.AddRange(createdPallets.Where(x => x.IsInStore == false && x.Type == goodType && x.Step.GetNativeValue<long>(IKEAConstants.StepPropertyQueuedStorageService) > 0 && x.Step.GetNativeValue<long>(IKEAConstants.StepPropertyProcessedStorageService) > 0));
                        if (goodCreatedPalletsNotInStore != null && goodCreatedPalletsNotInStore.Count > 0)
                        {
                            Dictionary<string, object> newInput = new Dictionary<string, object>();
                            newInput.Add(Cmf.Navigo.Common.Constants.MaterialCollection, goodCreatedPalletsNotInStore);
                            GetActionByNameInput deeInput = new GetActionByNameInput
                            {
                                Name = IKEAConstants.CustomAddToPrintingQueueResource
                            };
                            var dynamicExecutionEngineOrchestration = _serviceProvider.GetService<IDynamicExecutionEngineOrchestration>();
                            Cmf.Foundation.Common.Abstractions.IAction action = dynamicExecutionEngineOrchestration.GetActionByName(deeInput).Action;
                            ExecuteActionInput execute = new ExecuteActionInput()
                            {
                                Action = action,
                                Input = newInput
                            };
                            dynamicExecutionEngineOrchestration.ExecuteAction(execute);
                        }
                    }

                    // Present the Generated pallets in the feedback messages
                    if (generatedMaterials.Length > 0)
                    {
                        // Remove last comma
                        generatedMaterials.Length--;

                        output.FeedbackMessages = new Collection<FeedbackMessage>
                        {
                            new FeedbackMessage() { Message = generatedMaterials.ToString(), MessageType = FeedbackMessageType.Success }
                        };
                    }

                    #endregion
                }

                #endregion

                Utilities.EndMethod(
                    -1,
                    -1,
                    new KeyValuePair<string, object>("CustomOutsourtedPalletizeInput", input),
                    new KeyValuePair<string, object>("CustomOutsourtedPalletizeOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw new CmfBaseException(ex.Message, ex);
            }

            return output;
        }

        /// <summary>
        /// Service for retrieving data from the equipment
        /// </summary>
        /// <param name="input">CustomGetAutomationVariables Input</param>
        /// <returns>CustomGetAutomationVariables Output</returns>
        /// <exception cref="Cmf.Foundation.Common.CmfBaseException">If any unexpected error occurs.</exception>
        public CustomGetAutomationVariablesOutput CustomGetAutomationVariables(CustomGetAutomationVariablesInput input)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomGetAutomationVariables", new KeyValuePair<string, object>("CustomGetAutomationVariablesInput", input));

            CustomGetAutomationVariablesOutput output = null;

            try
            {
                Cmf.Foundation.Common.Utilities.ValidateNullInput(input);

                output = new CustomGetAutomationVariablesOutput();

                //Load both the resource and the material
                input.Material.Load();
                input.Resource.Load();

                //The material needs to be tracked into the resource
                if (input.Material.LastProcessState == LastProcessState.InProcess && input.Material.LastProcessedResource.Name.Equals(input.Resource.Name))
                {
                    //The results should already come ordered by the 'Order' field
                    System.Data.DataTable result = _iKEAUtilities.GetCustomAutomationVariableReadingsConfigurationForResource(input.Resource.Name);

                    //Only bother performing the rest if variables have been configured
                    if (result != null && result.HasData())
                    {
                        output.FeedbackMessages = new Collection<FeedbackMessage>();

                        //Source -> VariableName -> Variable Data to Send to Automation
                        //NOTE: This dictionary is used to prevent adding duplicate variable readings for each source. The variable + source combination is not unique, since multiple filters can be applied
                        Dictionary<string, Dictionary<string, object>> requestedVariables = new Dictionary<string, Dictionary<string, object>>();

                        //NOTE: This dictionary will store all loaded localized messages in order to prevent loading the same one multiple times when iterating through the table
                        Dictionary<string, string> localizedMessagesDictionary = new Dictionary<string, string>();

                        //loop through this table for creating request data object
                        foreach (DataRow dataRow in result.Rows)
                        {
                            string source = dataRow.Field<string>(IKEAConstants.CustomAutomationVariableReadingsConfigurationSource);
                            string variable = dataRow.Field<string>(IKEAConstants.CustomAutomationVariableReadingsConfigurationVariable);
                            string dataType = dataRow.Field<string>(IKEAConstants.CustomAutomationVariableReadingsConfigurationDataType);

                            string localizedMessage = dataRow.Field<string>(IKEAConstants.CustomAutomationVariableReadingsConfigurationLocalizedMessage);

                            if (!localizedMessagesDictionary.ContainsKey(localizedMessage))
                            {
                                localizedMessagesDictionary.Add(localizedMessage, _iKEAUtilities.GetLocalizedMessage(localizedMessage));
                            }

                            if (!requestedVariables.ContainsKey(source))
                            {
                                requestedVariables.Add(source, new Dictionary<string, object>());
                            }

                            if (!requestedVariables[source].ContainsKey(variable))
                            {
                                var eiVariableObject = new
                                {
                                    VariableName = variable,
                                    DataType = dataType
                                };

                                requestedVariables[source].Add(variable, eiVariableObject);
                            }
                        }

                        //Object containing IoT request data
                        var requestData = new
                        {
                            MaterialId = input.Material.Id.ToString(),
                            MaterialName = input.Material.Name,
                            Variables = requestedVariables.ToDictionary(var => var.Key, var => var.Value.Values)
                        };

                        //Source -> VariableName -> Variable Reading
                        CMFMap<string, CMFMap<string, object>> automationResponse =
                            _genericUtilities.RequestFromIoT<CMFMap<string, CMFMap<string, object>>>(input.Resource.GetAutomationControllerInstance(), IKEAConstants.AutomationRequestGetAutomationVariables, requestData);

                        #region Add values to the custom object from IOT returned data

                        string automationNoVariableFoundLocalizedMessage = _iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomAutomationVariableNotFoundMessage);
                        string automationCheckVariableConfigurationLocalizedMessage = _iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomAutomationVariableCheckConfigurationMessage);

                        foreach (DataRow dataRow in result.Rows)
                        {
                            string source = dataRow.Field<string>(IKEAConstants.CustomAutomationVariableReadingsConfigurationSource);
                            string variable = dataRow.Field<string>(IKEAConstants.CustomAutomationVariableReadingsConfigurationVariable);
                            string localizedMessage = localizedMessagesDictionary[dataRow.Field<string>(IKEAConstants.CustomAutomationVariableReadingsConfigurationLocalizedMessage)];
                            string identifierProperty = dataRow.Field<string>(IKEAConstants.CustomAutomationVariableReadingsConfigurationIdentifierProperty);
                            string valueProperty = dataRow.Field<string>(IKEAConstants.CustomAutomationVariableReadingsConfigurationValueProperty);
                            string filterValue = dataRow.Field<string>(IKEAConstants.CustomAutomationVariableReadingsConfigurationFilterValue);
                            string displayUnit = dataRow.Field<string>(IKEAConstants.CustomAutomationVariableReadingsConfigurationDisplayUnit);

                            object variableReading = automationResponse[source][variable];

                            var details = _iKEAUtilities.GetAutomationVariableDetails(variableReading, source, variable, localizedMessage, identifierProperty, valueProperty, filterValue, displayUnit,
                                    automationNoVariableFoundLocalizedMessage, automationCheckVariableConfigurationLocalizedMessage);

                            output.CustomGetAutomationVariableDetailCollection.AddRange(details.Item1);

                            //Convert all warning strings to feedback messages
                            IEnumerable<FeedbackMessage> warningFeedbackMessages = details.Item2.Select(message => new FeedbackMessage() { Message = message, MessageType = FeedbackMessageType.Warning });

                            output.FeedbackMessages.AddRange(warningFeedbackMessages);
                        }

                        #endregion
                    }

                }

                Utilities.EndMethod(-1, -1,
                    new KeyValuePair<string, object>("CustomGetAutomationVariablesInput", input),
                    new KeyValuePair<string, object>("CustomGetAutomationVariablesOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw new CmfBaseException(ex.Message, ex);
            }

            return output;
        }

        /// <summary>
        /// Service to enable or disable the relations of a consumable feed with a consumption provider (Tank)
        /// </summary>
        /// <param name="customHandleConsumptionProviderInput"></param>
        /// <returns></returns>
        public CustomHandleConsumptionProviderOutput CustomHandleConsumptionProvider(CustomHandleConsumptionProviderInput customHandleConsumptionProviderInput)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomHandleConsumptionProvider", new KeyValuePair<string, object>("CustomHandleConsumptionProviderInput", customHandleConsumptionProviderInput));

            CustomHandleConsumptionProviderOutput output;

            try
            {
                // Validate Input: ConsumableFeed and ConsumptionProvider must NOT be null. DistributedConsumptionProviders can be null.
                Utilities.ValidateNullInput(customHandleConsumptionProviderInput, new List<string> { "DistributedConsumptionProviders" });

                // Get selected consumable feed
                IResource selectedConsumableFeed = customHandleConsumptionProviderInput.ConsumableFeed;
                selectedConsumableFeed.Load();


                // Get the main line:
                IResource topMost = selectedConsumableFeed.GetTopMostResource();

                // Get selected consumption provider
                IResource selectedConsumptionProvider = customHandleConsumptionProviderInput.ConsumptionProvider;
                selectedConsumptionProvider.Load();

                // Get selected distribution consumption providers if they exist:
                IResourceCollection distributedConsumptionProviders = customHandleConsumptionProviderInput.DistributedConsumptionProviders;
                if (!distributedConsumptionProviders.IsNullOrEmpty())
                {
                    distributedConsumptionProviders.Load();
                }

                #region Validations

                // Validate if the consumable feed is of the correct type:
                if (selectedConsumableFeed.ProcessingType != ProcessingType.ConsumableFeed)
                {
                    throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomResourceWrongProcessingTypeLocalizedMessage, selectedConsumableFeed.Name));
                }

                // Validate if the consumable feed has a parent resource:
                if (selectedConsumableFeed.ParentResourcesCount == 0)
                {
                    throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomResourceFeederDoesNotHaveParentResourceLocalizedMessage, selectedConsumableFeed.Name));
                }

                if (selectedConsumableFeed.Id != selectedConsumptionProvider.Id)
                {
                    // Validate if the consumption provider is of the correct type:
                    if (selectedConsumptionProvider.ProcessingType != ProcessingType.ConsumableFeed)
                    {
                        throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomResourceWrongProcessingTypeLocalizedMessage, selectedConsumptionProvider.Name));
                    }

                    // Validate if the consumption provider is not a feeder of a different resource:
                    if (selectedConsumptionProvider.ParentResourcesCount > 0)
                    {
                        throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomResourceProviderHasParentResourceLocalizedMessage, selectedConsumptionProvider.Name));
                    }
                }


                if (!distributedConsumptionProviders.IsNullOrEmpty())
                {

                    // Validate if all of the distributed consumption providers are of the correct type:
                    if (distributedConsumptionProviders.Where(DCP => DCP.ProcessingType != ProcessingType.ConsumableFeed).Any())
                    {
                        throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomDistributedResourceWrongProcessingTypeLocalizedMessage));
                    }


                    // Validate if the all of the distributed consumption provider are not feeders of a different resource:
                    if (!distributedConsumptionProviders.Where(DCP => DCP.ParentResourcesCount > 0).Any())
                    {
                        throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomDistributedResourceProviderHasDifferentParentResourceLocalizedMessage));
                    }
                    else
                    {
                        IResource selectedConsumableFeedTopMost = selectedConsumableFeed.GetTopMostResource();

                        foreach (var distributedConsumptionProvider in distributedConsumptionProviders)
                        {
                            IResource distributedConsumptionProviderTopMost = distributedConsumptionProvider.GetTopMostResource();
                            if (distributedConsumptionProviderTopMost.Id != selectedConsumableFeedTopMost.Id)
                            {
                                throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomDistributedResourceProviderHasDifferentParentResourceLocalizedMessage));
                            }
                        }
                    }
                }
                #endregion

                // Configure the output and set the consumableFeed as the default Consumption Provider:
                output = new CustomHandleConsumptionProviderOutput();
                output.ConsumptionProvider = selectedConsumableFeed;


                // Load all ConsumptionProvider relations for this feeder:
                selectedConsumableFeed.LoadRelations(IKEAConstants.CustomResourceConsumptionProvider);

                // Check if there are relations to shared consumption providers (shared Tanks)
                if (selectedConsumableFeed.RelationCollection != null)
                {
                    if (selectedConsumableFeed.RelationCollection.ContainsKey(IKEAConstants.CustomResourceConsumptionProvider))
                    {

                        // Gets a collection with all the CustomResourceConsumptionProvider relations in this main feeder:
                        ICustomResourceConsumptionProviderCollection consumptionProviderRelations = _entityFactory.CreateCollection<ICustomResourceConsumptionProviderCollection>();
                        var relations = selectedConsumableFeed.RelationCollection[IKEAConstants.CustomResourceConsumptionProvider].Select(ER => ER as ICustomResourceConsumptionProvider);
                        consumptionProviderRelations.AddRange(relations);


                        // Check that there are orders in process in the line and there are changes in the distributed feeders:
                        List<int> systemStateInProgress = new List<int> { (int)MaterialSystemState.InProcess };
                        IMaterialCollection materialsInProcess = _iKEAUtilities.GetMaterialsInProgressOnMainLine(topMost.Id, systemStateInProgress, true);
                        if (!materialsInProcess.IsNullOrEmpty())
                        {
                            consumptionProviderRelations.LoadAttributes(new Collection<string> { IKEAConstants.IsEnabledResourceConsumptionProvider });
                            foreach (var consumptionProviderRelation in consumptionProviderRelations)
                            {
                                if (consumptionProviderRelation.ConsumptionMode == (int)CustomConsumptionModeEnum.DistributedConsumption)
                                {
                                    // Checks if the distributed feeder was originally enabled:
                                    bool originalState = consumptionProviderRelation.GetAttributeValueOrDefault<bool>(IKEAConstants.IsEnabledResourceConsumptionProvider, false);

                                    // Checks if the distributed feeder state was changed in the GUI:
                                    bool selectedState = distributedConsumptionProviders.IsNullOrEmpty() ? false : distributedConsumptionProviders.Any(R => R.Id == consumptionProviderRelation.TargetEntity.Id);

                                    // Trying to change the state of a distributed feeder with orders in process generates an error:
                                    if (selectedState != originalState)
                                    {
                                        throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomDistributedResourceProviderChangeWhenOrdersInProcessLocalizedMessage));
                                    }
                                }
                            }
                        }


                        // Set all relations attribute to false (disable all relations)
                        consumptionProviderRelations.SaveAttributes(new AttributeCollection { { IKEAConstants.IsEnabledResourceConsumptionProvider, false } });

                        // SHARED TANKS
                        // Check the selected consumption provider. If it is not the same as the consumable feed, get the one to enable.
                        if (selectedConsumableFeed.Id != selectedConsumptionProvider.Id)
                        {
                            // If the selected consumption provider exists in the relation collection:
                            if (consumptionProviderRelations.Any(x => x.TargetEntity.Id.Equals(selectedConsumptionProvider.Id)))
                            {
                                // Get the selected consumption provider relation:
                                var consumptionProviderRelation = consumptionProviderRelations.Where(x => x.TargetEntity.Id.Equals(selectedConsumptionProvider.Id)).FirstOrDefault();

                                // Enable the relation by setting the 'IsEnabled' attribute to 'true':
                                consumptionProviderRelation.SaveAttributes(new AttributeCollection { { IKEAConstants.IsEnabledResourceConsumptionProvider, true } });

                                // Set the output consumption provider with the selected:
                                output.ConsumptionProvider = selectedConsumptionProvider;
                            }
                        }

                        // DISTRIBUTED CONSUMPTION
                        // Aditional feeders may be added to provide material together with the main feeder:
                        else if (!distributedConsumptionProviders.IsNullOrEmpty())
                        {
                            // Get the aditional feeders Ids:
                            var resourcesIds = distributedConsumptionProviders.Select(DCP => DCP.Id);


                            // Check if the resources selected are all related to the feeder as DistributedConsumption
                            if (consumptionProviderRelations.Where(PR => PR.ConsumptionMode != (int)CustomConsumptionModeEnum.DistributedConsumption
                                                                   && resourcesIds.Contains(PR.TargetEntity.Id))
                                                           .Any())
                            {
                                throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomDistributedResourceProviderWrongConsumptionModeLocalizedMessage));
                            }

                            // Check if any of the aditional feeders has a different conumption mode than the main feeder. If so throw error:
                            distributedConsumptionProviders.LoadAttributes(new Collection<string> { IKEAConstants.CustomResourceAttributeFeederConsumptionMode });
                            var feederConsumptionMode = selectedConsumableFeed.GetAttributeValueOrDefault<CustomFeederConsumptionModeEnum>(IKEAConstants.CustomResourceAttributeFeederConsumptionMode);

                            if (distributedConsumptionProviders.Where(CP => CP.GetAttributeValueOrDefault<CustomFeederConsumptionModeEnum>(IKEAConstants.CustomResourceAttributeFeederConsumptionMode) != feederConsumptionMode).Any())
                            {
                                throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomDistributedResourceProviderIncompatibleConsumptionModeLocalizedMessage, feederConsumptionMode.ToString()));
                            }


                            // In the case of distributed consumption, validate if the materials being attached are of the same product than the already existing ones.
                            if (!_iKEAUtilities.ValidateProductsInAllDistributedFeeders(selectedConsumableFeed, distributedConsumptionProviders))
                            {
                                throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomDistributedConsumptionAddFeederIncompatibleProductLocalizedMessage));
                            }

                            // Get only the ones that have a relation to the main feeder:
                            ICustomResourceConsumptionProviderCollection distributedConsumptionProviderRelations = _entityFactory.CreateCollection<ICustomResourceConsumptionProviderCollection>();
                            var distributedRelations = consumptionProviderRelations.Where(PR => resourcesIds.Contains(PR.TargetEntity.Id));
                            distributedConsumptionProviderRelations.AddRange(distributedRelations);


                            // If the selected consumption provider exists in the relation collection:
                            if (!distributedConsumptionProviderRelations.IsNullOrEmpty())
                            {
                                // Set all relations attribute to true:
                                distributedConsumptionProviderRelations.SaveAttributes(new AttributeCollection { { IKEAConstants.IsEnabledResourceConsumptionProvider, true } });

                                // Set the output consumption provider with the selected aditional resources:
                                output.DistributedConsumptionProviders = _entityFactory.CreateCollection<IResourceCollection>();
                                output.DistributedConsumptionProviders.AddRange(distributedConsumptionProviderRelations.Select(DCP => DCP.TargetEntity));
                            }
                        }
                    }
                }
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw new CmfBaseException(ex.Message, ex);
            }

            Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomHandleConsumptionProviderInput", customHandleConsumptionProviderInput),
                                        new KeyValuePair<string, object>("CustomHandleConsumptionProviderOutput", output));

            return output;
        }

        /// <summary>
        /// Service to Post Data from Automation to an MES Data Collection
        /// </summary>
        /// <param name="customAutomationDataCollectionToMESInput"></param>
        /// <returns></returns>
        public CustomAutomationDataCollectionToMESOutput CustomAutomationDataCollectionToMES(CustomAutomationDataCollectionToMESInput customAutomationDataCollectionToMESInput)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomAutomationDataCollectionToMES",
                new KeyValuePair<string, object>("CustomAutomationDataCollectionToMESInput", customAutomationDataCollectionToMESInput));

            IDataCollectionInstance inputDCInstance = _entityFactory.Create<IDataCollectionInstance>();
            inputDCInstance.DataCollectionPoints = _entityFactory.CreateCollection<IDataCollectionPointCollection>();
            IDataCollectionParameterCollection dcParameterCollection = null;
            var postType = customAutomationDataCollectionToMESInput.DataCollectionInstanceExecutionMode;
            IMaterial material = null;
            bool skipDcValidation = false;

            #region Get Material Object from MES if it exists.

            if (!string.IsNullOrWhiteSpace(customAutomationDataCollectionToMESInput.MaterialName))
            {
                material = _entityFactory.Create<IMaterial>();
                material.Name = customAutomationDataCollectionToMESInput.MaterialName;
                if (!material.ObjectExists())
                {
                    throw new ObjectNotFoundCmfException("Material", customAutomationDataCollectionToMESInput.MaterialName);
                }
                material.Load();
            }

            #endregion

            #region Create the DataCollectionInstance object

            // Is there any Data to be sent?
            if (customAutomationDataCollectionToMESInput.DataToCollect.Count == 0)
            {
                throw new NoDataFoundCmfException("No data to post to MES");
            }


            if (postType == DataCollectionInstanceExecutionMode.ImmediateAdHoc || postType == DataCollectionInstanceExecutionMode.Immediate)
            {
                inputDCInstance.Name = customAutomationDataCollectionToMESInput.ResourceName + "_" + DateTime.Now.ToString("yyyyMMddHHmmssfffffff");

                if (postType == DataCollectionInstanceExecutionMode.Immediate)
                {
                    if (string.IsNullOrWhiteSpace(customAutomationDataCollectionToMESInput.DataCollectionName))
                    {
                        throw new ArgumentNullCmfException("Data Collection Name");
                    }
                    inputDCInstance.DataCollection = _entityFactory.Create<IDataCollection>();
                    inputDCInstance.DataCollection.Name = customAutomationDataCollectionToMESInput.DataCollectionName;

                    if (!inputDCInstance.DataCollection.ObjectExists())
                    {
                        throw new ObjectNotFoundCmfException("Data Collection", customAutomationDataCollectionToMESInput.DataCollectionName);
                    }
                }
            }
            else if (postType == DataCollectionInstanceExecutionMode.LongRunning)
            {
                if (material == null)
                {
                    throw new ArgumentNullCmfException("Material Name");
                }

                inputDCInstance = material.CurrentDataCollectionInstance;

                if (!inputDCInstance.DataCollection.ObjectExists())
                {
                    throw new MissingMandatoryPropertyCmfException("DataCollectionInstance", material.CurrentDataCollectionInstance.Name);
                }
                inputDCInstance.LoadRelations();

            }
            #endregion

            //If Data Collection is Immediate or Long Running get Data Collection Parameter Collection
            if (postType != DataCollectionInstanceExecutionMode.ImmediateAdHoc)
            {
                if (postType == DataCollectionInstanceExecutionMode.LongRunning)
                {
                    inputDCInstance.DataCollection.Load();
                    inputDCInstance.DataCollection.LoadRelations(Navigo.Common.Constants.DataCollectionParameter);
                    dcParameterCollection = inputDCInstance.DataCollection.DataCollectionParameters;
                }
                else
                {
                    IDataCollection dc = _entityFactory.Create<IDataCollection>();
                    dc.Load(customAutomationDataCollectionToMESInput.DataCollectionName);
                    dc.LoadRelations(Navigo.Common.Constants.DataCollectionParameter);
                    dcParameterCollection = dc.DataCollectionParameters;
                    inputDCInstance.DataCollection = dc;
                }

                //if empty throw exception
                if (dcParameterCollection == null)
                {
                    throw new InvalidNullInstanceValuesForMandatoryPropertyException("DataCollectionParameters");
                }
            }

            #region Get Resource Object

            IResource resource = _entityFactory.Create<IResource>();
            resource.Name = customAutomationDataCollectionToMESInput.ResourceName;
            if (!resource.ObjectExists())
            {
                throw new ObjectNotFoundCmfException("Resource", resource.Name);
            }
            resource.Load();

            #endregion

            #region Get Step, Product, Flow and Flowpath from material

            IStep step = null;
            IProduct product = null;
            IFlow flow = null;
            String flowPath = null;

            if (material != null)
            {
                // Get Step
                step = material.Step;

                // Get Product
                product = material.Product;

                // Get Flow
                flow = material.Flow;

                // Get FlowPath
                flowPath = material.FlowPath;
            }

            #endregion

            #region Extract Special meaning Parameters

            #region Sample Id
            String sampleId = customAutomationDataCollectionToMESInput.SampleId;
            if (String.IsNullOrEmpty(sampleId))
            {
                sampleId = DateTime.Now.ToString("yyyyMMddhhmmssfffffff");
            }
            #endregion

            #region Operation Name
            String operationName = customAutomationDataCollectionToMESInput.OperationName;
            #endregion

            #region Service Comments
            String serviceComments = customAutomationDataCollectionToMESInput.ServiceComments;
            #endregion

            #region SkipDcValidation
            skipDcValidation = customAutomationDataCollectionToMESInput.SkipDcValidation;
            #endregion

            #endregion

            IDataCollectionPointCollection pointCollection = _entityFactory.CreateCollection<IDataCollectionPointCollection>();
            IDataCollectionPointCollection currentPointCollection = _entityFactory.CreateCollection<IDataCollectionPointCollection>();

            //Check if the samples should be replaced or added
            bool addReadings = customAutomationDataCollectionToMESInput.AddReadings;

            if (postType == DataCollectionInstanceExecutionMode.LongRunning && addReadings)
            {
                currentPointCollection = inputDCInstance.DataCollectionPoints;
            }
            Object paramValue = null;
            IEnumerable<Object> paramValues = null;
            Int32 paramReadingsCount = 0;
            foreach (String paramName in customAutomationDataCollectionToMESInput.DataToCollect.Keys)
            {
                try
                {

                    Cmf.Navigo.BusinessObjects.Abstractions.IParameter parameter = null;
                    if (postType == DataCollectionInstanceExecutionMode.Immediate || postType == DataCollectionInstanceExecutionMode.LongRunning)
                    {
                        // Check if parameter exists on data collection                        
                        var parameterCollectionItem = dcParameterCollection.FirstOrDefault(p => string.Equals(p.TargetEntity.Name, paramName, StringComparison.OrdinalIgnoreCase));
                        // if parameter does not exist in navigo ignore it and go to the next one
                        if (parameterCollectionItem == null)
                        {
                            // ConnectKernel.CurrentKernel.WriteApplicationLogForEquipment(resource.Name, "There is no Parameter with name \"" + paramName + "\" in MES");
                            continue;
                        }

                        parameter = parameterCollectionItem.TargetEntity;
                    }
                    else
                    {   // If post type is Immediate Add Hoc, get the Parameter object from MES:
                        parameter = _entityFactory.Create<IParameter>();
                        parameter.Name = paramName;
                        parameter.Load();
                    }

                    // Now Add the readings
                    paramValue = customAutomationDataCollectionToMESInput.DataToCollect[paramName];
                    if (paramValue is ICollection)
                    {
                        paramValues = (paramValue as ICollection).Cast<Object>();
                        paramReadingsCount = (paramValue as ICollection).Count;
                    }
                    else
                    {
                        paramReadingsCount = 1;
                        paramValues = new List<Object>() { paramValue };
                    }

                    Int32 readingNr = 0;
                    if (addReadings)
                    {
                        if (currentPointCollection != null && currentPointCollection.Count != 0)
                        {
                            readingNr = currentPointCollection.Count(p => p.TargetEntity.Name == parameter.Name && p.SampleId == sampleId) - currentPointCollection.Count(p => p.TargetEntity.Name == parameter.Name && p.SampleId == sampleId && p.ReadingNumber == 0);
                        }
                    }
                    foreach (Object value in paramValues)
                    {
                        readingNr++;

                        IDataCollectionPoint point = _entityFactory.Create<IDataCollectionPoint>();
                        point.TargetEntity = parameter;
                        point.SampleId = sampleId;
                        point.ReadingNumber = readingNr;
                        //ConnectKernel.CurrentKernel.WriteApplicationLogForEquipment(resource.Name, "Sample Id: " + point.SampleId + "Reading Number: " + point.ReadingNumber + " ThreadId: " + thisThreadId);

                        switch (parameter.DataType)
                        {
                            case ParameterDataType.DateTime:
                                if (!(value is String) || String.IsNullOrEmpty(parameter.DataFormat))
                                {
                                    point.Value = Convert.ChangeType(value, (new DateTime()).GetType(), CultureInfo.InvariantCulture);
                                }
                                else
                                {
                                    point.Value = DateTime.ParseExact((String)value, parameter.DataFormat, CultureInfo.InvariantCulture, DateTimeStyles.AssumeLocal | DateTimeStyles.NoCurrentDateDefault);
                                }
                                break;

                            case ParameterDataType.Decimal:
                                point.Value = Convert.ChangeType(value, (new Decimal()).GetType(), CultureInfo.InvariantCulture);
                                break;

                            case ParameterDataType.Duration:
                                #region TimeSpan
                                TimeSpan tsVal;
                                long lVal;
                                #region value is DateTime or TimeSpan
                                if (value is DateTime)
                                {
                                    // We assume the DateTime is containing the number of ticks for the TimeSpan
                                    point.Value = TimeSpan.FromTicks(((DateTime)value).Ticks);
                                    break;
                                }
                                else if (value is TimeSpan)
                                {
                                    point.Value = (TimeSpan)value;
                                    break;
                                }
                                #endregion

                                String valueAsString = null;
                                long? valueAsLong = null;
                                if (value is IConvertible)
                                {   // Lets get the value as String and as Long
                                    #region Value is IConvertible
                                    if (value is String)
                                    {
                                        valueAsString = (String)value;
                                    }
                                    else
                                    {
                                        valueAsString = (String)Convert.ChangeType(value, typeof(String), CultureInfo.InvariantCulture);
                                    }

                                    try
                                    {
                                        valueAsLong = (long)Convert.ChangeType(value, typeof(long), CultureInfo.InvariantCulture);
                                    }
                                    catch (FormatException)
                                    {
                                        // Convertion to Long failed so keep valueAsLong stays null and we continue
                                    }
                                    #endregion
                                }
                                else
                                {
                                    // In this case we get the value as String and keep the valueAsLong set to null
                                    valueAsString = value.ToString();
                                }

                                if (!String.IsNullOrEmpty(valueAsString))
                                {   // There a String value, so first lets try to parse it to a TimeSpan directly
                                    if (TimeSpan.TryParse(valueAsString, CultureInfo.InvariantCulture, out tsVal))
                                    {
                                        point.Value = tsVal;
                                        break;
                                    }
                                    else
                                    {   // It Failed, so let's try to parse it to long first
                                        if (long.TryParse(valueAsString, NumberStyles.Any, CultureInfo.InvariantCulture, out lVal))
                                        {
                                            point.Value = TimeSpan.FromTicks(lVal);
                                            break;
                                        }
                                    }
                                }

                                if (valueAsLong != null)
                                {   // There a Long value, so lets use it as number of ticks to create the TimeSpan
                                    point.Value = TimeSpan.FromTicks(valueAsLong ?? 0);
                                    break;
                                }

                                if (value == null)
                                {
                                    point.Value = null;
                                    break;
                                }
                                else
                                {   // If we reached here than the convertion failed every step of the way
                                    throw new InvalidObjectTypeCmfException(paramName, value.GetType().Name, "TimeSpan");
                                }
                            #endregion

                            case ParameterDataType.Long:
                                if (value is IConvertible)
                                {
                                    try
                                    {
                                        point.Value = Convert.ChangeType(value, typeof(long), CultureInfo.InvariantCulture);
                                        break;
                                    }
                                    catch (FormatException)
                                    {
                                    }
                                }

                                if (value == null)
                                {
                                    point.Value = 0;
                                    break;
                                }
                                else
                                {
                                    point.Value = long.Parse(value.ToString(), CultureInfo.InvariantCulture);
                                }
                                break;

                            case ParameterDataType.String:
                            case ParameterDataType.Url:
                                point.Value = value.ToString();
                                break;

                            default:
                                throw new InvalidPropertyValueCmfException(parameter.DataType.ToString(), "Parameter.DataType");
                        }
                        pointCollection.Add(point);
                    }
                }
                catch (Exception)
                {
                    // Ignore error
                }
            }

            if (pointCollection == null || pointCollection.Count == 0)
            {
                throw new NoDataFoundCmfException("No data to Post");
            }

            #region Set properties in DataCollectionInstance object
            if (postType != DataCollectionInstanceExecutionMode.LongRunning)
            {
                inputDCInstance.Resource = resource;
                inputDCInstance.Material = material;
                inputDCInstance.Step = step;
                inputDCInstance.Product = product;
                inputDCInstance.Flow = flow;
                inputDCInstance.FlowPath = flowPath;
                foreach (IDataCollectionPoint item in pointCollection)
                {
                    if (inputDCInstance.RelationCollection == null)
                    {
                        inputDCInstance.RelationCollection ??= _serviceProvider.GetService<ICmfEntityRelationCollection>();
                    }

                    inputDCInstance.RelationCollection.Add(item);
                }
            }
            #endregion

            #region Execute PerformImmediateDataCollection/PostDataCollectionPoints Service     
            IPostDataCollectionPointsResult res = new PostDataCollectionPointsResult();
            switch (postType)
            {
                case DataCollectionInstanceExecutionMode.Immediate:
                    inputDCInstance.MaterialOperation = String.IsNullOrWhiteSpace(operationName) ? "PerformImmediate" : operationName;
                    res = inputDCInstance.PerformImmediate(skipDcValidation);
                    break;

                case DataCollectionInstanceExecutionMode.ImmediateAdHoc:
                    inputDCInstance.MaterialOperation = String.IsNullOrWhiteSpace(operationName) ? "PerformImmediate" : operationName;
                    res = inputDCInstance.PerformImmediate(skipDcValidation);
                    break;

                case DataCollectionInstanceExecutionMode.LongRunning:
                    res = inputDCInstance.Post(pointCollection, null, null, null, skipDCValidation: skipDcValidation);
                    break;
            }

            #endregion

            CustomAutomationDataCollectionToMESOutput output = new CustomAutomationDataCollectionToMESOutput();

            Utilities.EndMethod(
                    -1,
                    -1,
                    new KeyValuePair<string, object>("CustomAutomationDataCollectionToMESInput", customAutomationDataCollectionToMESInput),
                    new KeyValuePair<string, object>("CustomAutomationDataCollectionToMESOutput", output));

            #region Fill output
            return output;
            #endregion
        }

        /// <summary>
        /// Service to get information from outsorted pallet resource
        /// </summary>
        /// <param name="customGetOutSortedPalletFromFeederInput"></param>
        /// <returns></returns>
        public CustomGetOutSortedPalletFromFeederOutput CustomGetOutSortedPalletFromFeeder(CustomGetOutSortedPalletFromFeederInput customGetOutSortedPalletFromFeederInput)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomGetOutSortedPalletFromFeeder",
                new KeyValuePair<string, object>("CustomGetOutSortedPalletFromFeederInput", customGetOutSortedPalletFromFeederInput));

            CustomGetOutSortedPalletFromFeederOutput output = new CustomGetOutSortedPalletFromFeederOutput();
            IMaterial outsortedPallet = null;

            try
            {
                Utilities.ValidateNullInput(customGetOutSortedPalletFromFeederInput);
                outsortedPallet = _iKEAUtilities.GetOutSortedPalletFromFeeder(feeder: customGetOutSortedPalletFromFeederInput.Feeder);
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            Utilities.EndMethod(
                    -1,
                    -1,
                    new KeyValuePair<string, object>("CustomGetOutSortedPalletFromFeederInput", customGetOutSortedPalletFromFeederInput),
                    new KeyValuePair<string, object>("CustomGetOutSortedPalletFromFeederOutput", output));

            #region Fill output
            output.OutsortedPallet = outsortedPallet;
            return output;
            #endregion
        }

        /// <summary>
        /// Service to Complete an outsorted pallet generated in the line
        /// </summary>
        /// <param name="customAutomationDataCollectionToMESInput"></param>
        /// <returns></returns>
        public CustomCompleteOutsortedPalletOutput CustomCompleteOutsortedPallet(CustomCompleteOutsortedPalletInput customCompleteOutsortedPalletInput)
        {
            // Note: Changes made to logic here, likely will have to be 

            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomCompleteOutsortedPalletInput",
                new KeyValuePair<string, object>("CustomCompleteOutsortedPalletInput", customCompleteOutsortedPalletInput));


            CustomCompleteOutsortedPalletOutput output = new CustomCompleteOutsortedPalletOutput();
            IMaterial outsortedPallet = null;

            try
            {
                Utilities.ValidateNullInput(customCompleteOutsortedPalletInput);


                outsortedPallet = _iKEAUtilities.ProcessOutsortedFromFeeder(outsortingQuantity: customCompleteOutsortedPalletInput.FeederOutsortingQuantity,
                                                                           feeder: customCompleteOutsortedPalletInput.Resource,
                                                                           completePallet: true);

            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            Utilities.EndMethod(
                    -1,
                    -1,
                    new KeyValuePair<string, object>("CustomCompleteOutsortedPalletInput", customCompleteOutsortedPalletInput),
                    new KeyValuePair<string, object>("CustomCompleteOutsortedPalletOutput", output));

            #region Fill output
            output.Material = outsortedPallet;
            return output;
            #endregion
        }

        /// <summary>
        /// Service to calculate how many outsorted pallets are needed and their quantities
        /// </summary>
        /// <param name="customCalculateNeededOutsortedPalletInput"></param>
        /// <returns></returns>
        public CustomCalculateNeededOutsortedPalletOutput CustomCalculateNeededOutsortedPallet(CustomCalculateNeededOutsortedPalletInput customCalculateNeededOutsortedPalletInput)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomCalculateNeededOutsortedPalletInput",
                new KeyValuePair<string, object>("CustomCalculateNeededOutsortedPalletInput", customCalculateNeededOutsortedPalletInput));


            CustomCalculateNeededOutsortedPalletOutput output = new CustomCalculateNeededOutsortedPalletOutput();
            Dictionary<string, decimal> results = null;

            try
            {
                Utilities.ValidateNullInput(customCalculateNeededOutsortedPalletInput);


                results = _iKEAUtilities.CalculateNeededOutsortedQuantity(outsortingQuantity: customCalculateNeededOutsortedPalletInput.OutsortingQuantity,
                                                                           outsortedPallet: customCalculateNeededOutsortedPalletInput.OutsortedPallet,
                                                                           wizardMaterial: customCalculateNeededOutsortedPalletInput.WizardMaterial,
                                                                           resource: customCalculateNeededOutsortedPalletInput.Resource);

            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            Utilities.EndMethod(
                    -1,
                    -1,
                    new KeyValuePair<string, object>("CustomCalculateNeededOutsortedPalletInput", customCalculateNeededOutsortedPalletInput),
                    new KeyValuePair<string, object>("CustomCalculateNeededOutsortedPalletOutput", output));

            #region Fill output

            output.DefaultCompletionQuantity = results["DefaultCompletionQuantity"];
            output.ExistingPalletQuantity = results["ExistingPalletQuantity"];
            output.IsExistingPalletCompleted = results["IsExistingPalletCompleted"] == 1;
            output.NumberOfCompletedPallets = results["NumberOfCompletedPallets"];
            output.IncompletePalletQuantity = results["IncompletePalletQuantity"];

            return output;

            #endregion
        }

        /// <summary>
        /// Service to retrieve details when outsorting pallets on the line.
        /// </summary>
        /// <param name="input">CustomGetDetailsForPalletOutsortingInput</param>
        /// <returns>CustomGetDetailsForPalletOutsortingOutput</returns>
        public CustomGetDetailsForPalletOutsortingOutput CustomGetDetailsForPalletOutsorting(CustomGetDetailsForPalletOutsortingInput input)
        {
            // Note: This method reflects the logic employed on CustomCompleteOutsortedPallet

            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomGetDetailsForPalletOutsorting",
                  new KeyValuePair<string, object>("CustomGetDetailsForPalletOutsortingInput", input));

            CustomGetDetailsForPalletOutsortingOutput output = new CustomGetDetailsForPalletOutsortingOutput();

            try
            {
                List<string> propertiesToIgnore = new List<string>(1)
                {
                    input.IsNewMaterial ? "Material" : "BatchName"
                };

                Utilities.ValidateNullInput(input, propertiesToIgnore);

                IResource resource = input.Resource;
                resource.Load();

                bool canOutsort = _iKEAUtilities.GetFeederOutsortedStatus(resource);

                if (canOutsort)
                {
                    resource.LoadAttribute(IKEAConstants.CustomOutsortingStorageResource);

                    string outsortingStorageResourceName = resource.GetAttributeValueOrDefault<string>(IKEAConstants.CustomOutsortingStorageResource);

                    if (!outsortingStorageResourceName.IsNullOrEmpty())
                    {
                        IResource outsortingResource = _entityFactory.Create<IResource>();
                        outsortingResource.Name = outsortingStorageResourceName;

                        if (outsortingResource.ObjectExists())
                        {
                            outsortingResource.Load();

                            if (outsortingResource.ProcessingType == ProcessingType.Storage)
                            {
                                outsortingResource.LoadRelations(Navigo.Common.Constants.MaterialResource);

                                //We're only handling cases where there's only one pallet on the resource
                                if (outsortingResource.RelationCollection.ContainsKey(Navigo.Common.Constants.MaterialResource))
                                {
                                    if (outsortingResource.RelationCollection.Count == 1)
                                    {
                                        output.OutsortedPallet = outsortingResource.RelationCollection[Navigo.Common.Constants.MaterialResource].Select(mr => mr.SourceEntity as IMaterial).First();
                                    }
                                }
                                else
                                {
                                    output.OutsortedPallet = _entityFactory.Create<IMaterial>();
                                    output.OutsortedPallet.Name = _iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomNewOutsortingPalletWillBeCreatedLocalizedMessage);

                                }
                            }
                        }
                    }
                }

                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomGetDetailsForPalletOutsortingInput", input),
                                new KeyValuePair<string, object>("CustomGetDetailsForPalletOutsortingOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new CmfBaseException(e.Message, e);
            }
            return output;
        }

        /// <summary>
        /// Service to get datapoints chart from current shift
        /// </summary>
        /// <param name="customAutomationDataCollectionToMESInput"></param>
        /// <returns></returns>
        public CustomGetChartCurrentShiftLimitsOutput CustomGetChartCurrentShiftLimits(CustomGetChartCurrentShiftLimitsInput customGetChartCurrentShiftLimitsInput)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomGetChartCurrentShiftLimits",
                  new KeyValuePair<string, object>("CustomGetChartCurrentShiftLimitsInputInput", customGetChartCurrentShiftLimitsInput));

            CustomGetChartCurrentShiftLimitsOutput output = new CustomGetChartCurrentShiftLimitsOutput();

            try
            {
                // initialize output
                output.HasShift = false;
                output.StartShift = TimeSpan.Zero;
                output.EndShift = TimeSpan.Zero;

                ILogicalChart logicalChart = _entityFactory.Create<ILogicalChart>();
                logicalChart.Name = customGetChartCurrentShiftLimitsInput.LogicalChartName;

                if (logicalChart.ObjectExists())
                {
                    logicalChart.Load();
                    if (logicalChart.ContextKeys.Length > 0)
                    {
                        String[] LogicalChartCtxVals = logicalChart.ContextKeys.Split(new String[] { Cmf.Navigo.Common.Constants.LogicalChartContextSpliter }, StringSplitOptions.None);
                        Cmf.Navigo.BusinessObjects.Abstractions.ICalendar calendar = null;
                        Dictionary<string, Cmf.Navigo.BusinessObjects.Abstractions.ICalendar> dictionary = new Dictionary<string, Cmf.Navigo.BusinessObjects.Abstractions.ICalendar>();
                        IResource resource = _entityFactory.Create<IResource>();
                        IArea area = _entityFactory.Create<IArea>();
                        IFacility facility = _entityFactory.Create<IFacility>();

                        Cmf.Navigo.BusinessObjects.Abstractions.ICalendar resourceCalendar = null,
                            areaCalendar = null,
                            facilityCalendar = null;

                        foreach (string contextName in LogicalChartCtxVals)
                        {
                            // loop on context keys to find what the keys are related to
                            resource.Name = contextName;
                            area.Name = contextName;
                            facility.Name = contextName;

                            if (resource.ObjectExists() && resourceCalendar == null)
                            {
                                resource.Load();
                                area = resource.Area;
                                if (area != null)
                                {
                                    resourceCalendar = area.Calendar;
                                }
                            }
                            else if (area.ObjectExists() && areaCalendar == null)
                            {
                                areaCalendar = area.Calendar;
                            }
                            else if (facility.ObjectExists() && facilityCalendar == null)
                            {
                                facility.Load();
                                facilityCalendar = facility.DefaultCalendar;
                            }
                        }

                        // get the calendar according to priority
                        calendar = resourceCalendar ?? areaCalendar ?? facilityCalendar;

                        IShiftDefinition shiftDefinition = null;
                        if (calendar != null)
                        {
                            switch (DateTime.Now.DayOfWeek)
                            {
                                case DayOfWeek.Monday:
                                    shiftDefinition = calendar.DefaultMondayShiftDefinition;
                                    break;
                                case DayOfWeek.Tuesday:
                                    shiftDefinition = calendar.DefaultTuesdayShiftDefinition;
                                    break;
                                case DayOfWeek.Wednesday:
                                    shiftDefinition = calendar.DefaultWednesdayShiftDefinition;
                                    break;
                                case DayOfWeek.Thursday:
                                    shiftDefinition = calendar.DefaultThursdayShiftDefinition;
                                    break;
                                case DayOfWeek.Friday:
                                    shiftDefinition = calendar.DefaultFridayShiftDefinition;
                                    break;
                                case DayOfWeek.Saturday:
                                    shiftDefinition = calendar.DefaultSaturdayShiftDefinition;
                                    break;
                                case DayOfWeek.Sunday:
                                    shiftDefinition = calendar.DefaultSundayShiftDefinition;
                                    break;
                                default:
                                    break;
                            }
                        }
                        if (shiftDefinition != null)
                        {
                            IShiftDefinitionShiftCollection shiftDefinitionShiftCollection = shiftDefinition.ShiftsCollection;
                            IShiftDefinitionShift currentShift = null;
                            TimeSpan nowTime = DateTime.Now.TimeOfDay;
                            foreach (IShiftDefinitionShift shiftDefinitionShift in shiftDefinitionShiftCollection)
                            {
                                if (shiftDefinitionShift.StartTime.Value < shiftDefinitionShift.EndTime.Value)
                                {   // no date change during shift
                                    if (shiftDefinitionShift.StartTime.Value <= nowTime &&
                                       shiftDefinitionShift.EndTime.Value > nowTime)
                                    {
                                        currentShift = shiftDefinitionShift;
                                    }
                                }
                                else
                                {   //day change between start and end
                                    if (shiftDefinitionShift.StartTime.Value <= nowTime || nowTime < shiftDefinitionShift.EndTime.Value)
                                    {
                                        currentShift = shiftDefinitionShift;
                                    }
                                }
                            }
                            if (currentShift != null)
                            {
                                output.HasShift = true;
                                output.StartShift = (TimeSpan)currentShift.StartTime;
                                output.EndShift = (TimeSpan)currentShift.EndTime;
                                output.Calendar = calendar;

                            }
                        }

                    }
                }
                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomGetChartCurrentShiftLimitsInput", customGetChartCurrentShiftLimitsInput),
                                new KeyValuePair<string, object>("CustomGetChartCurrentShiftLimitsOutput", output));
            }

            catch (Exception e)
            {
                throw new CmfBaseException(e.Message, e);
            }
            return output;
        }

        /// <summary>
        /// Service to run a statistical normality test from selected datapoints of a logical chart
        /// This service uses the Accord.NET framework for all statistical calculations.
        /// Website:
        /// http://accord-framework.net/
        /// License:
        /// http://accord-framework.net/license.html
        /// GitHub: 
        /// https://github.com/accord-net/framework
        /// NuGet:
        /// https://www.nuget.org/packages/Accord/3.8.0
        /// https://www.nuget.org/packages/Accord.Statistics/3.8.0
        /// </summary>
        /// <param name="customDataPointsNormalityTestInput"></param>
        /// <returns></returns>
        public CustomDataPointsNormalityTestOutput CustomDataPointsNormalityTest(CustomDataPointsNormalityTestInput customDataPointsNormalityTestInput)
        {

            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomDataPointsNormalityTest",
                new KeyValuePair<string, object>("CustomDataPointsNormalityTestInput", customDataPointsNormalityTestInput));

            CustomDataPointsNormalityTestOutput output = new CustomDataPointsNormalityTestOutput();

            try
            {
                #region Validate null values
                List<string> propertiesToIgnore = new List<string>()
                {
                    "DataPointsIdsToExclude"
                };

                if (customDataPointsNormalityTestInput.LastDataPoints.HasValue)
                {
                    propertiesToIgnore.Add("DataPointsStartDate");
                    propertiesToIgnore.Add("DataPointsEndDate");
                }
                else
                {
                    propertiesToIgnore.Add("LastDataPoints");
                }
                Utilities.ValidateNullInput(customDataPointsNormalityTestInput, propertiesToIgnore);
                #endregion

                #region Get datapoints from logical chart:

                // Load the selected Logical Chart:
                ILogicalChart logicalChart = _entityFactory.Create<ILogicalChart>();
                logicalChart.Name = customDataPointsNormalityTestInput.LogicalChartName;
                logicalChart.Load();

                // Create an empty list:
                List<IChartDataPoint> dataPoints = new List<IChartDataPoint>();
                List<double> dataPointsValues = new List<double>();


                // If the user selected the last N Data Points:
                if (customDataPointsNormalityTestInput.LastDataPoints.HasValue && customDataPointsNormalityTestInput.LastDataPoints.Value > 0)
                {
                    logicalChart.LoadChartDataPoints(customDataPointsNormalityTestInput.LastDataPoints.Value);
                    dataPoints = logicalChart.ChartDataPoints.Where(DP => DP.Value1.HasValue).ToList();
                }
                // If the user selected a time range:
                else if (customDataPointsNormalityTestInput.DataPointsStartDate.HasValue && customDataPointsNormalityTestInput.DataPointsEndDate.HasValue)
                {
                    logicalChart.LoadChartDataPoints();
                    dataPoints = logicalChart.ChartDataPoints.Where(DP => DP.CreatedOn >= customDataPointsNormalityTestInput.DataPointsStartDate.Value &&
                                                                          DP.CreatedOn <= customDataPointsNormalityTestInput.DataPointsEndDate.Value &&
                                                                          DP.Value1.HasValue).ToList();
                }


                if (!dataPoints.IsNullOrEmpty())
                {
                    // Data points must be sorted ascending!
                    // Check if there are datapoints to exclude:
                    if (!customDataPointsNormalityTestInput.DataPointsIdsToExclude.IsNullOrEmpty())
                    {
                        dataPointsValues = dataPoints.Where(DP => customDataPointsNormalityTestInput.DataPointsIdsToExclude.All(DPE => DPE != DP.Id))
                                                     .OrderBy(O => O.Value1.Value)
                                                     .Select(DP => (double)DP.Value1.Value)
                                                     .ToList();
                    }
                    else
                    {
                        dataPointsValues = dataPoints.OrderBy(O => O.Value1.Value)
                                                     .Select(DP => (double)DP.Value1.Value)
                                                     .ToList();
                    }
                }
                #endregion

                if (!dataPointsValues.IsNullOrEmpty())
                {
                    string errorMessage = string.Empty;

                    // Check the normality test selected by the user:
                    if (customDataPointsNormalityTestInput.NormalityTestName.CompareStrings("AndersonDarling"))
                    {
                        var datapointValueDoubleArray = dataPointsValues.ToArray();
                        #region Get Basic Statistics
                        // Get Mean
                        var mean = Measures.Mean(datapointValueDoubleArray);
                        // Get Median
                        var median = Measures.Median(datapointValueDoubleArray);
                        // Get Standard Deviation
                        var standardDeviation = Measures.StandardDeviation(datapointValueDoubleArray);
                        // Get Variance
                        var variance = Measures.Variance(datapointValueDoubleArray);
                        // Get Skewness
                        var skewness = Measures.Skewness(datapointValueDoubleArray);
                        // Get Kurtosis
                        var kurtosis = Measures.Kurtosis(datapointValueDoubleArray);
                        #endregion

                        #region Get Output values: Inverse Normal Distribution & Linear regression Trend line

                        IList<double> trendLine = new List<double>();
                        IList<double> invNormDistOutputValues = new List<double>();
                        try
                        {
                            // Get Inverse Normal Distribution
                            invNormDistOutputValues = _iKEAUtilities.GetInverseNormalDistributionFunction(dataPointsValues);

                            // Get Trendline
                            trendLine = _iKEAUtilities.CalculateLinearRegressionTrendLine(dataPointsValues, invNormDistOutputValues);
                        }
                        catch (Exception ex)
                        {
                            errorMessage = ex.Message;
                        }

                        #endregion

                        #region Get Histogram

                        // Get Histogram of datapoints:											
                        INormalDistributionIntervalCollection normalDistributionIntervalCollection = new NormalDistributionIntervalCollection();
                        Dictionary<double, double> gaussianCurve = new Dictionary<double, double>();
                        Histogram histogram = new Histogram();

                        if (errorMessage.IsNullOrEmpty())
                        {
                            histogram.Compute(dataPointsValues.ToArray());

                            if (histogram.Bins.Count == 2 || histogram.Bins.Count == 4)
                            {
                                int numberOfBins = histogram.Bins.Count + 1;

                                histogram = new Histogram();
                                histogram.AutoAdjustmentRule = BinAdjustmentRule.None;
                                histogram.Compute(dataPointsValues.ToArray(), numberOfBins);
                            }

                            foreach (var bin in histogram.Bins)
                            {
                                INormalDistributionInterval normalDistributionInterval = new NormalDistributionInterval()
                                {
                                    UpperBound = (Decimal)bin.Range.Max,
                                    LowerBound = (Decimal)bin.Range.Min,
                                    NumberOfChartDataPoints = bin.Value
                                };
                                normalDistributionIntervalCollection.Add(normalDistributionInterval);
                            }

                            // Get Gaussian curve							
                            if (!double.IsNaN(mean) && !double.IsNaN(standardDeviation) && !double.IsNaN(variance))
                            {
                                gaussianCurve = _iKEAUtilities.GetGaussianCurve(histogram, (Decimal)mean, (Decimal)standardDeviation, (Decimal)variance);
                            }
                        }

                        #endregion

                        #region Get Anderson-Darling Test

                        double pValue = double.NaN;
                        double statistic = double.NaN;
                        bool andersonDarlingTestSucess = false;

                        if (errorMessage.IsNullOrEmpty())
                        {
                            andersonDarlingTestSucess = _iKEAUtilities.GetAndersonDarlingTest(dataPointsValues, out statistic, out pValue);
                        }
                        #endregion

                        #region Update service output

                        // Basic statistics:
                        output.Mean = mean;
                        output.Median = median;
                        output.StdDeviation = standardDeviation;
                        output.Variance = variance;
                        output.Skewness = skewness;
                        output.Kurtosis = kurtosis;

                        // data series: Inverse Normal Distribution and Trend line
                        output.DataPointsX = dataPointsValues;
                        output.DataPointsY = invNormDistOutputValues;
                        output.TrendLineX = dataPointsValues;
                        output.TrendLineY = trendLine;

                        // Histogram and Gaussian curve:
                        output.Histogram = normalDistributionIntervalCollection;
                        output.HistogramUpperBound = histogram.Range.Min;
                        output.HistogramLowerBound = histogram.Range.Max;
                        output.GaussianCurve = gaussianCurve;

                        // Anderson-Darling results
                        output.AndersonDarlingAD = statistic;
                        output.AndersonDarlingPValue = pValue;
                        output.AndersonDarlingTestSucess = andersonDarlingTestSucess;

                        // Error message:
                        output.ErrorMessage = errorMessage;

                        #endregion
                    }
                }
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            Utilities.EndMethod(-1,
                                -1,
                                new KeyValuePair<string, object>("CustomCompleteOutsortedPalletInput", customDataPointsNormalityTestInput),
                                new KeyValuePair<string, object>("CustomCompleteOutsortedPalletOutput", output));

            return output;
        }

        /// <summary>
        /// Service to check if all MO are available to be in a Group of MO
        /// </summary>
        /// <param name="customHandleGroupManufacturingOrdersInput"></param>
        /// <returns></returns>
        public CustomHandleGroupManufacturingOrdersOutput CustomHandleGroupManufacturingOrders(CustomHandleGroupManufacturingOrdersInput customHandleGroupManufacturingOrdersInput)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomHandleGroupManufacturingOrders",
                  new KeyValuePair<string, object>("CustomHandleGroupManufacturingOrdersInput", customHandleGroupManufacturingOrdersInput));

            IResource resource = customHandleGroupManufacturingOrdersInput.ResourceToDispatch;
            IMaterial groupMaterial = customHandleGroupManufacturingOrdersInput.GroupMaterialOrder;
            bool isOptimizedMaterialResource = _iKEAUtilities.CheckIfGroupMOOnOptimizedResource(groupMaterial);
            bool isOptimizedInputResource = _iKEAUtilities.CheckIfOptimizedResource(resource);
            bool isHPOEnabledAndOptimizable = isOptimizedInputResource && customHandleGroupManufacturingOrdersInput.IsHPOEnabled;

            CustomHandleGroupManufacturingOrdersOutput output = new CustomHandleGroupManufacturingOrdersOutput();
            if (customHandleGroupManufacturingOrdersInput.IsHPOEnabled && customHandleGroupManufacturingOrdersInput.MaterialPartsPerCycle.Count < 1)
            {
                throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomAtLeastOneMemberInGroupMOForHPOLocalizedMessage));
            }
            if (!customHandleGroupManufacturingOrdersInput.IsHPOEnabled && customHandleGroupManufacturingOrdersInput.MaterialPartsPerCycle.Count < 2)
            {
                throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomAtLeastTwoMembersInGroupMOLocalizedMessage));
            }

            try
            {
                // Get child MOs:
                IMaterialCollection childMaterials = _entityFactory.CreateCollection<IMaterialCollection>(); ;
                childMaterials.AddRange(customHandleGroupManufacturingOrdersInput.MaterialPartsPerCycle.Keys);
                childMaterials.Load();
                // Load attributes:
                childMaterials.LoadAttributes(new Collection<string> { IKEAConstants.CustomMaterialAttributeDefaultCompletedQuantity, IKEAConstants.CustomMaterialIsOrderlessAttribute });

                string primaryUnits = childMaterials.FirstOrDefault().PrimaryUnits;

                #region Check Children relations and removes them

                // Load relations to group MOs:
                childMaterials.LoadRelations(IKEAConstants.CustomGroupMaterialManufacturingOrder);

                foreach (IMaterial childMaterial in childMaterials)
                {
                    // Validate if this is a group MO parent:
                    if (childMaterial.IsGroupMO(loadRelations: false))
                    {
                        throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomMaterialIsGroupMOLocalizedMessage, childMaterial.Name));
                    }
                    // Check if the child material has any group associated					
                    else if (childMaterial.IsChildOfGroupMO())
                    {
                        if ((groupMaterial == null || !childMaterial.IsChildOfGroupMO(groupMaterial)))
                        {
                            {
                                throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomMaterialAlreadyInGroupMOLocalizedMessage, childMaterial.Name));
                            }
                        }
                    }
                    if (!childMaterial.SystemState.Equals(MaterialSystemState.Queued))
                    {
                        throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomMaterialNotQueuedGroupMOLocalizedMessage, childMaterial.Name));
                    }

                    //Check if child MO has different UoM
                    if (childMaterial.PrimaryUnits != primaryUnits)
                    {
                        throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomChildMOsDifferentUnitsOfMeasureMessage));
                    }
                }

                // Clear all relations
                if (groupMaterial != null)
                {
                    groupMaterial.Load();
                    if (!groupMaterial.SystemState.Equals(MaterialSystemState.Queued))
                    {
                        throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomMaterialNotQueuedGroupMOLocalizedMessage, groupMaterial.Name));
                    }

                    groupMaterial.LoadRelations(IKEAConstants.CustomGroupMaterialManufacturingOrder);

                    if (groupMaterial.RelationCollection.ContainsKey(IKEAConstants.CustomGroupMaterialManufacturingOrder) &&
                       !groupMaterial.RelationCollection[IKEAConstants.CustomGroupMaterialManufacturingOrder].IsNullOrEmpty())
                    {
                        // remove all relations
                        ICmfEntityRelationCollection relationCollection = _serviceProvider.GetService<ICmfEntityRelationCollection>();
                        relationCollection.Add(groupMaterial.RelationCollection[IKEAConstants.CustomGroupMaterialManufacturingOrder]);

                        groupMaterial.RemoveRelations(relationCollection);
                    }
                }
                #endregion

                #region Validate Order Quantities only for non optimized resources
                // Validate Order Quantities 
                // (Order Quantity / Parts per Cycle) A = (Order Quantity / Parts per Cycle) B =(Order Quantity / Parts per Cycle) C
                if (!isHPOEnabledAndOptimizable)
                {
                    decimal ratio = -1;
                    foreach (KeyValuePair<IMaterial, decimal> pair in customHandleGroupManufacturingOrdersInput.MaterialPartsPerCycle)
                    {
                        if (pair.Value != 0)
                        {
                            pair.Key.Load();
                            decimal currentRatio = (decimal)(pair.Key.PrimaryQuantity / pair.Value);
                            if (ratio == -1)
                            {
                                // ratio not set yet
                                ratio = currentRatio;
                            }
                            if (ratio != currentRatio)
                            {
                                throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomPartsPerCycleNotCompatibleWithPatternLocalizedMessage));
                            }
                            if (currentRatio < 1)
                            {
                                throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomPartsPerCycleLargerThanOrderQuantityLocalizedMessage));
                            }
                        }
                    }
                }
                #endregion

                #region Quantity calculation and DefaultCompletedQuantity set to 0 in children

                decimal groupMOQuantity = 0;
                List<string> productNameList = new List<string>();

                // Compute sum quantity
                groupMOQuantity = childMaterials.Sum(CM => CM.PrimaryQuantity.Value);

                // Add products name to list:
                productNameList.AddRange(childMaterials.Select(CM => CM.Product.Name).ToList());

                // Set attributes to zero:
                childMaterials.SaveAttributes(new AttributeCollection()
                {
                    { IKEAConstants.CustomMaterialAttributeDefaultCompletedQuantity, 0 }
                });

                #endregion

                #region Check if children are all orderless or not
                if (childMaterials.Select(CM => CM.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomMaterialIsOrderlessAttribute)).Distinct().Count() != 1)
                {
                    // all children attribute IsOrderless should be indentical
                    throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomDifferentChildOrderlessAttributeLocalizedMessage));
                }

                #endregion

                #region Check flow path of child products
                if (childMaterials.Select(CM => CM.Product.FlowPath).Distinct().Count() != 1)
                {
                    // all products have to have the same flow Path
                    throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomDifferentChildFlowPathProductGroupMOLocalizedMessage));
                }

                #endregion

                #region Group MO Product Creation

                // Create Name of Dummy Product
                productNameList.Sort();

                string dummyProductName = null;
                if (productNameList.Distinct().Count() == 1)
                {
                    dummyProductName = productNameList.First();
                }
                else
                {
                    dummyProductName = "GroupProduct_" + string.Join("_", productNameList.Distinct());
                }

                IProduct moProduct = _entityFactory.Create<IProduct>();
                moProduct.Name = dummyProductName;

                IProduct firstProduct = customHandleGroupManufacturingOrdersInput.MaterialPartsPerCycle.Keys.First().Product;
                firstProduct.Load();

                if (!moProduct.ObjectExists())
                {
                    // Create the change set
                    var changeSetObject = _entityFactory.Create<IChangeSet>();

                    changeSetObject.Name = dummyProductName;
                    changeSetObject.Type = "General";
                    changeSetObject.Description = "Change Set Created for Grouping MO product";
                    changeSetObject.MakeEffectiveOnApproval = true;

                    IChangeSet changeSet = _changeSetOrchestration.CreateChangeSet(
                        new CreateChangeSetInput
                        {
                            ChangeSet = changeSetObject
                        }
                    ).ChangeSet;

                    moProduct.Description = "Generated Product from " + dummyProductName + " Products";
                    moProduct.ChangeSet = changeSet;
                    moProduct.Type = firstProduct.Type;
                    moProduct.ProductType = firstProduct.ProductType;
                    moProduct.DefaultUnits = firstProduct.DefaultUnits;
                    moProduct.FlowPath = firstProduct.FlowPath;
                    moProduct.Flow = firstProduct.Flow;
                    moProduct.Step = firstProduct.Step;

                    // Create Version
                    Common.GenericExtensions.CreateNewEntityVersion(moProduct);
                }
                else
                {
                    // update dummy product if there is changes on it. If not, just load it
                    moProduct.Load();

                    if (productNameList.Distinct().Count() > 1 &&
                        (!moProduct.Type.Equals(firstProduct.Type) ||
                        moProduct.DefaultUnits.Equals(firstProduct.DefaultUnits) ||
                        moProduct.FlowPath.Equals(firstProduct.FlowPath)))
                    {

                        // Create the change set
                        IChangeSet changeSet = _iKEAUtilities.CreateChangeSet(true);

                        moProduct.ChangeSet = changeSet;
                        moProduct.Type = firstProduct.Type;
                        moProduct.ProductType = firstProduct.ProductType;
                        moProduct.DefaultUnits = firstProduct.DefaultUnits;
                        moProduct.FlowPath = firstProduct.FlowPath;
                        moProduct.Flow = firstProduct.Flow;
                        moProduct.Step = firstProduct.Step;

                        Common.GenericExtensions.CreateNewEntityVersion(moProduct);
                    }
                }

                // Set IsGroupMOProduct attribute only to products that were created specificaly to Group MOs:
                if (productNameList.Distinct().Count() > 1)
                {
                    moProduct.SaveRelatedAttributes(new AttributeCollection()
                    {
                        { IKEAConstants.CustomProductAttributeIsGroupMOProduct, true }
                    });
                }

                #endregion

                #region Group MO creation
                // Get the complete form for the material
                string orderForm = _iKEAUtilities.GetOrderMaterialForm();

                // Load name generator to ensure it exists:				
                INameGenerator groupOrderNameGenerator = _entityFactory.Create<INameGenerator>();
                groupOrderNameGenerator.Load(IKEAConstants.CustomGroupMOMaterialNameGenerator);

                // Generate name
                string materialName = groupOrderNameGenerator.GenerateName(IKEAConstants.CustomGroupMOMaterialNameGenerator);

                // Group MO creation
                if (groupMaterial == null)
                {
                    groupMaterial = _entityFactory.Create<IMaterial>();
                    groupMaterial.Name = materialName;
                    groupMaterial.Description = "Group MO " + materialName;
                    groupMaterial.PrimaryQuantity = groupMOQuantity;
                    groupMaterial.PrimaryUnits = customHandleGroupManufacturingOrdersInput.MaterialPartsPerCycle.Keys.First().PrimaryUnits;
                    groupMaterial.FlowPath = customHandleGroupManufacturingOrdersInput.MaterialPartsPerCycle.Keys.First().FlowPath;
                    groupMaterial.Flow = customHandleGroupManufacturingOrdersInput.MaterialPartsPerCycle.Keys.First().Flow;
                    groupMaterial.Step = customHandleGroupManufacturingOrdersInput.MaterialPartsPerCycle.Keys.First().Step;
                    groupMaterial.Product = moProduct;
                    groupMaterial.Type = customHandleGroupManufacturingOrdersInput.MaterialPartsPerCycle.Keys.First().Type;
                    groupMaterial.Form = customHandleGroupManufacturingOrdersInput.MaterialPartsPerCycle.Keys.First().Form;
                    groupMaterial.Facility = customHandleGroupManufacturingOrdersInput.MaterialPartsPerCycle.Keys.First().Facility;

                    CreateMaterialOutput createMaterialOutput = _materialOrchestration.CreateMaterial(new CreateMaterialInput() { Material = groupMaterial });
                    groupMaterial = createMaterialOutput.Material;
                }
                else
                {
                    #region Check states before allowing update
                    bool wasHPOEnabled = groupMaterial.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomMaterialAttributeGroupOrderHPOEnabled, loadAttribute: true);

                    if (wasHPOEnabled &&
                        CustomGroupOrderStateEnum.Created != groupMaterial.GetAttributeValueOrDefault<CustomGroupOrderStateEnum>(IKEAConstants.CustomMaterialAttributeGroupOrderState, true)
                    )
                    {
                        throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomUpdateInvalidGroupOrderStateLocalizedMessage));
                    }
                    #endregion

                    // Set a flag indicating that the data of the group MO is being changed in the Edip page:
                    _deeContextUtilities.SetContextParameter(IKEAConstants.CustomHandleGroupManufacturingOrdersEditGroupMOContextKey, true);

                    groupMaterial.ChangeQuantity(groupMOQuantity, 0, null, null, null, primaryUnits);
                    groupMaterial.PrimaryUnits = customHandleGroupManufacturingOrdersInput.MaterialPartsPerCycle.Keys.First().PrimaryUnits;
                    groupMaterial.Type = customHandleGroupManufacturingOrdersInput.MaterialPartsPerCycle.Keys.First().Type;
                    groupMaterial.Form = customHandleGroupManufacturingOrdersInput.MaterialPartsPerCycle.Keys.First().Form;
                    groupMaterial.Facility = customHandleGroupManufacturingOrdersInput.MaterialPartsPerCycle.Keys.First().Facility;

                    if (!groupMaterial.Product.Name.Equals(moProduct.Name))
                    {
                        groupMaterial.SpecialChangeProduct(moProduct);
                    }
                    groupMaterial.ChangeFlowAndStep(customHandleGroupManufacturingOrdersInput.MaterialPartsPerCycle.Keys.First().Flow,
                                                    customHandleGroupManufacturingOrdersInput.MaterialPartsPerCycle.Keys.First().FlowPath,
                                                    customHandleGroupManufacturingOrdersInput.MaterialPartsPerCycle.Keys.First().Step, null);
                    groupMaterial.Save();

                    // Clear flag:
                    _deeContextUtilities.SetContextParameter(IKEAConstants.CustomHandleGroupManufacturingOrdersEditGroupMOContextKey, false);
                }
                // Set the attribute indicating this MO is the parent
                groupMaterial.SaveAttributes(new AttributeCollection()
                    {
                        { IKEAConstants.CustomMaterialAttributeGroupOrderHPOEnabled, isHPOEnabledAndOptimizable },
                        { IKEAConstants.CustomMaterialAttributeIsGroupMO, true },
                        { IKEAConstants.CustomMaterialAttributeGroupOrderResource, resource.Name},
                        { IKEAConstants.CustomMaterialAttributeGroupOrderState, isHPOEnabledAndOptimizable ? CustomGroupOrderStateEnum.Created : CustomGroupOrderStateEnum.Ready },
                        { IKEAConstants.CustomMaterialIsOrderlessAttribute, childMaterials.Select(CM => CM.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomMaterialIsOrderlessAttribute)).First() }
                    });
                #endregion

                #region Relations creation

                // If there are any relation then save them
                ICmfEntityRelationCollection collection = _serviceProvider.GetService<ICmfEntityRelationCollection>();

                foreach (IMaterial childMaterial in childMaterials)
                {
                    // link all the materials to the group MO

                    //create the relation
                    ICustomGroupMaterialManufacturingOrder customGroupMaterialManufacturingOrder = _entityFactory.Create<ICustomGroupMaterialManufacturingOrder>();
                    customGroupMaterialManufacturingOrder.PartsPerCycle = isHPOEnabledAndOptimizable
                        ? 0 : customHandleGroupManufacturingOrdersInput.MaterialPartsPerCycle[childMaterial];
                    customGroupMaterialManufacturingOrder.SourceEntity = groupMaterial;
                    customGroupMaterialManufacturingOrder.TargetEntity = childMaterial;
                    collection.Add(customGroupMaterialManufacturingOrder);

                }

                groupMaterial.AddRelations(collection);
                output.GroupMaterialOrder = groupMaterial;
                #endregion

                #region Service call to generate file for optimizer
                OptimizerResourceStructure optimizerResourceStructure = groupMaterial.GetHPOConfiguration();

                if ((optimizerResourceStructure?.AllowToDispatchNotOptimizedGroupOrders ?? true) == false && !isHPOEnabledAndOptimizable)
                {
                    throw _iKEAUtilities.LocalizedException(IKEAConstants.CustomGroupOrderRequiredHPOLocalizedMessage);
                }

                if (resource != null
                    && groupMaterial.GetAttributeValueOrDefault<CustomGroupOrderStateEnum>(IKEAConstants.CustomMaterialAttributeGroupOrderState) == CustomGroupOrderStateEnum.Created
                    && isHPOEnabledAndOptimizable
                    && customHandleGroupManufacturingOrdersInput.IsToOptimize)
                {
                    _iKEAUtilities.CreateOptimizerImportFile(optimizerResourceStructure.SendFileFolder, groupMaterial);

                    // Get automation controller - HPO_File manager
                    IAutomationControllerInstance controllerInstance = _iKEAUtilities.GetAutomationControllerInstanceForFileHandler(resource);

                    // Send message to IoT to log the creation of a new file

                    if (controllerInstance != null)
                    {
                        controllerInstance.Publish(IKEAConstants.AutomationRequestTypeHPOFile, optimizerResourceStructure.SendFileFolder + "\\" + groupMaterial.Name + ".csv");
                    }

                    groupMaterial.SaveAttributes(new AttributeCollection
                    {
                        { IKEAConstants.CustomMaterialAttributeGroupOrderState, CustomGroupOrderStateEnum.WaitingForHPO }
                    });
                }

                #endregion

                #region Auto dispatch
                if (resource != null
                    && customHandleGroupManufacturingOrdersInput.IsToDispatch
                    && !isHPOEnabledAndOptimizable
                    && (optimizerResourceStructure?.AllowToDispatchNotOptimizedGroupOrders ?? true))
                {
                    if (!groupMaterial.IsDispatchable.GetValueOrDefault())
                    {
                        _materialOrchestration.SetOrUnSetMaterialDispatchable(new SetOrUnSetMaterialDispatchableInput { Material = groupMaterial, IsDispatchable = true });
                    }
                    Dictionary<IMaterial, IDispatchMaterialParameters> materials = new Dictionary<IMaterial, IDispatchMaterialParameters>
                        {
                            { groupMaterial, new DispatchMaterialParameters { Resource = resource } }
                        };

                    _materialOrchestration.DispatchMaterials(new DispatchMaterialsInput() { Materials = materials });
                }
                #endregion

                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomHandleGroupManufacturingOrdersInput", customHandleGroupManufacturingOrdersInput),
                                    new KeyValuePair<string, object>("CustomHandleGroupManufacturingOrdersOutput", output));
            }

            catch (Exception)
            {
                throw;
            }
            return output;
        }

        /// <summary>
        /// Service to list all materials attached to a printing queue
        /// </summary>
        /// <param name="customGetFromPrintingQueueInput"></param>
        /// <returns></returns>
        public CustomGetFromPrintingQueueOutput CustomGetFromPrintingQueue(CustomGetFromPrintingQueueInput customGetFromPrintingQueueInput)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomGetFromPrintingQueue",
                  new KeyValuePair<string, object>("CustomGetFromPrintingQueue", customGetFromPrintingQueueInput));

            CustomGetFromPrintingQueueOutput output = new CustomGetFromPrintingQueueOutput();

            try
            {
                Utilities.ValidateNullInput(customGetFromPrintingQueueInput);

                var lineResource = customGetFromPrintingQueueInput.LineResource;
                lineResource.Load();

                #region Get the materials from the printing queue resource
                var printingResource = _iKEAUtilities.GetAssociatedPrintingQueueResource(lineResource);

                if (printingResource == null)
                {
                    output.HasPrintingQueue = false;
                    output.Materials = _entityFactory.CreateCollection<IMaterialResourceCollection>();
                }
                else
                {
                    output.HasPrintingQueue = true;
                    output.Materials = _iKEAUtilities.GetMaterialsInPrintingQueue(printingResource, sort: true);
                }
                #endregion

                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomGetFromPrintingQueueInput", customGetFromPrintingQueueInput),
                                    new KeyValuePair<string, object>("CustomGetFromPrintingQueueOutput", output));
            }
            catch (Exception)
            {
                throw;
            }
            return output;
        }

        /// <summary>
        /// Service to store a material in a printing queue
        /// </summary>
        /// <param name="customAddToPrintingQueueInput"></param>
        /// <returns></returns>
        public CustomAddToPrintingQueueOutput CustomAddToPrintingQueue(CustomAddToPrintingQueueInput customAddToPrintingQueueInput)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomAddToPrintingQueue",
                  new KeyValuePair<string, object>("CustomAddToPrintingQueueInput", customAddToPrintingQueueInput));

            CustomAddToPrintingQueueOutput output = new CustomAddToPrintingQueueOutput();

            try
            {
                Utilities.ValidateNullInput(customAddToPrintingQueueInput);

                var material = customAddToPrintingQueueInput.PalletMaterial;
                material.Load();

                var lineResource = customAddToPrintingQueueInput.LineResource;
                lineResource.Load();

                #region Validate if the Material can be added to this Queue
                if (material.LastProcessedResource?.Name != lineResource.Name)
                {
                    throw _iKEAUtilities.LocalizedException(
                        IKEAConstants.CustomProcessedResourceNoMatchPrintingQueueLocalizedMessage,
                        material.LastProcessedResource?.Name ?? "(undefined)",
                        lineResource.Name
                    );
                }

                if (material.Form != _iKEAUtilities.GetCompletedMaterialForm(material))
                {
                    throw _iKEAUtilities.LocalizedException(
                        IKEAConstants.CustomMaterialFormNotCompletedForPrintingQueueLocalizedMessage,
                        _iKEAUtilities.GetCompletedMaterialForm(material),
                        material.Form
                    );
                }
                #endregion

                #region Change pallet type to Good
                string goodType = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.DefaultGoodTypeConfig);

                if (goodType != material.Type)
                {
                    material.Type = goodType;

                    var changeMaterialTypeOutput = _materialOrchestration.ChangeMaterialType(new ChangeMaterialTypeInput()
                    {
                        Material = material,
                    });
                    material.Load();
                }
                #endregion

                #region Add the material to the tail of the printing queue resource
                var printingResource = _iKEAUtilities.GetAssociatedPrintingQueueResource(lineResource);

                if (printingResource == null)
                {
                    throw _iKEAUtilities.LocalizedException(IKEAConstants.CustomNoPrintingQueueConfiguredForResourceLocalizedMessage, customAddToPrintingQueueInput.LineResource.Name);
                }

                _iKEAUtilities.AddMaterialToPrintingQueue(printingResource, material);
                #endregion

                output.Material = material;
                output.Material.Load();

                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomAddToPrintingQueueInput", customAddToPrintingQueueInput),
                                    new KeyValuePair<string, object>("CustomAddToPrintingQueueOutput", output));
            }
            catch (Exception)
            {
                throw;
            }
            return output;
        }

        /// <summary>
        /// Service to remove the last material from a printing queue
        /// </summary>
        /// <param name="customRemoveFromPrintingQueueInput"></param>
        /// <returns></returns>
        public CustomRemoveFromPrintingQueueOutput CustomRemoveFromPrintingQueue(CustomRemoveFromPrintingQueueInput customRemoveFromPrintingQueueInput)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomRemoveFromPrintingQueue",
                  new KeyValuePair<string, object>("CustomRemoveFromPrintingQueueInput", customRemoveFromPrintingQueueInput));

            CustomRemoveFromPrintingQueueOutput output = new CustomRemoveFromPrintingQueueOutput();
            string errorMessage = string.Empty;
            try
            {
                Utilities.ValidateNullInput(customRemoveFromPrintingQueueInput, new List<string> { nameof(customRemoveFromPrintingQueueInput.ExpectedPalletMaterial) });

                IResource lineResource = customRemoveFromPrintingQueueInput.LineResource;
                lineResource.Load();

                IMaterial expectedMaterial = customRemoveFromPrintingQueueInput.ExpectedPalletMaterial;
                if (expectedMaterial != null)
                {
                    expectedMaterial.Load();
                }

                #region Remove the last material from the printing queue
                var printingResource = _iKEAUtilities.GetAssociatedPrintingQueueResource(lineResource);

                if (printingResource == null)
                {
                    throw _iKEAUtilities.LocalizedException(IKEAConstants.CustomNoPrintingQueueConfiguredForResourceLocalizedMessage, customRemoveFromPrintingQueueInput.LineResource.Name);
                }

                var material = _iKEAUtilities.RemoveMaterialFromPrintingQueue(printingResource, out errorMessage, CustomPrintingQueuePosition.Tail, expectedMaterial);

                if (material == null)
                {
                    throw _iKEAUtilities.LocalizedException(IKEAConstants.CustomNoMaterialInPrintingQueueLocalizedMessage, printingResource.Name);
                }
                #endregion

                #region Change pallet type to outsorted
                string outsortedType = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.CustomOutsortedMaterialDefaultTypePath);

                if (material.Type != outsortedType)
                {
                    material.Type = outsortedType;

                    var changeMaterialTypeOutput = _materialOrchestration.ChangeMaterialType(new ChangeMaterialTypeInput()
                    {
                        Material = material,
                    });
                }
                #endregion

                output.Material = material;

                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomRemoveFromPrintingQueueInput", customRemoveFromPrintingQueueInput),
                                            new KeyValuePair<string, object>("CustomRemoveFromPrintingQueueOutput", output));
            }
            catch (Exception)
            {
                throw;
            }
            return output;
        }

        /// <summary>
        /// Service to print a ULL label
        /// </summary>
        /// <param name="customPrintLabelUnitLoadingInput"></param>
        /// <returns></returns>
        public CustomPrintLabelUnitLoadingOutput CustomPrintLabelUnitLoading(CustomPrintLabelUnitLoadingInput customPrintLabelUnitLoadingInput)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomPrintLabelUnitLoading",
                  new KeyValuePair<string, object>("CustomPrintLabelUnitLoadingInput", customPrintLabelUnitLoadingInput));

            CustomPrintLabelUnitLoadingOutput output = new CustomPrintLabelUnitLoadingOutput();

            Utilities.ValidateNullInput(customPrintLabelUnitLoadingInput);

            try
            {
                IPrintableDocument printableDocument = customPrintLabelUnitLoadingInput.PrintableDocument;
                printableDocument.Load();

                UllLabelFields labelFields = customPrintLabelUnitLoadingInput.LabelFields;

                IResource resource = customPrintLabelUnitLoadingInput.MainLineResource;
                resource.Load();
                resource.Area.Load();
                resource.Area.Facility.Load();
                resource.Area.Facility.LoadAttributes(new Collection<string> {
                    IKEAConstants.CustomInternationalABPrefix,
                    IKEAConstants.CustomNameOfUnit
                });

                #region "Input validation and sanitization"

                if (labelFields.DateStamp == null || Regex.IsMatch(labelFields.DateStamp, @"^\s*[0-9]{4}\s*$") == false)
                {
                    throw _iKEAUtilities.LocalizedException(IKEAConstants.CustomLabelPrintingDateStampIncorrectFormatLocalizedMessage);
                }

                labelFields.DateStamp = labelFields.DateStamp.Trim();

                if (labelFields.Quantity < 0)
                {
                    throw _iKEAUtilities.LocalizedException(IKEAConstants.CustomLabelPrintingFieldLessThanValueLocalizedMessage, nameof(labelFields.Quantity), "0");
                }

                if (labelFields.UnitLoadFootPrintLength < 0)
                {
                    throw _iKEAUtilities.LocalizedException(IKEAConstants.CustomLabelPrintingFieldLessThanValueLocalizedMessage, nameof(labelFields.UnitLoadFootPrintLength), "0");
                }

                if (labelFields.UnitLoadFootPrintWidth < 0)
                {
                    throw _iKEAUtilities.LocalizedException(IKEAConstants.CustomLabelPrintingFieldLessThanValueLocalizedMessage, nameof(labelFields.UnitLoadFootPrintWidth), "0");
                }

                if (labelFields.UnitLoadStackingCapacity < 0)
                {
                    throw _iKEAUtilities.LocalizedException(IKEAConstants.CustomLabelPrintingFieldLessThanValueLocalizedMessage, nameof(labelFields.UnitLoadStackingCapacity), "0");
                }

                if (_iKEAUtilities.IsValueInLookupTable(IKEAConstants.CustomUnitLoadingPrinterCodeLookupTable, customPrintLabelUnitLoadingInput.PrinterCode.ToString()) == false)
                {
                    throw _iKEAUtilities.LocalizedException(IKEAConstants.CustomValueNotInLookupTableLocalizedMessage, "PrinterCode", customPrintLabelUnitLoadingInput.PrinterCode.ToString(), IKEAConstants.CustomUnitLoadingPrinterCodeLookupTable);
                }

                if (_iKEAUtilities.IsValueInLookupTable(IKEAConstants.CustomUnitLoadingPalletTypeLookupTable, labelFields.PalletType) == false)
                {
                    throw _iKEAUtilities.LocalizedException(IKEAConstants.CustomValueNotInLookupTableLocalizedMessage, "PalletType", labelFields.PalletType, IKEAConstants.CustomUnitLoadingPalletTypeLookupTable);
                }

                #endregion

                string palletNumber = _iKEAUtilities.GenerateUnitLoadingLabelPalletNumber(
                    customPrintLabelUnitLoadingInput.FactoryCode,
                    customPrintLabelUnitLoadingInput.PrinterCode,
                    counterValue: labelFields.PalletCounter?.ToString()
                );

                string palletNumberShort = _iKEAUtilities.GenerateUnitLoadingLabelPalletNumberShortForm(palletNumber);

                // Get the facility associated with our main line resource
                IFacility facility = resource.Area.Facility;

                string internalABPrefix = facility.GetAttributeValueOrDefault<string>(IKEAConstants.CustomInternationalABPrefix);
                string nameOfUnit = facility.GetAttributeValueOrDefault<string>(IKEAConstants.CustomNameOfUnit);

                if (internalABPrefix == null)
                {
                    throw _iKEAUtilities.LocalizedException(IKEAConstants.CustomMissingAttributeInEntityLocalizedMessage, IKEAConstants.CustomInternationalABPrefix, "Facility", facility.Name);
                }

                if (nameOfUnit == null)
                {
                    throw _iKEAUtilities.LocalizedException(IKEAConstants.CustomMissingAttributeInEntityLocalizedMessage, IKEAConstants.CustomNameOfUnit, "Facility", facility.Name);
                }

                // First calculate the SSCC barcode without the control digit, and then append it, calculating it from the code itself
                string ssccBarcode = string.Format("{0}{1}{2}", internalABPrefix, nameOfUnit, palletNumber);
                ssccBarcode += _iKEAUtilities.CalculateUnitLoadingLabelControlDigit(ssccBarcode);

                printableDocument.Print(null, new Dictionary<string, object>
                {
                    { "unitLoadStackingCapacity", labelFields.UnitLoadStackingCapacity },
                    { "unitLoadFootPrintWidth", labelFields.UnitLoadFootPrintWidth },
                    { "unitLoadFootPrintLength", labelFields.UnitLoadFootPrintLength },
                    { "palletType", labelFields.PalletType },
                    { "factorySignature", labelFields.FactorySignature },
                    { "articleName", labelFields.ArticleName },
                    { "palletNumber", palletNumberShort },
                    { "productNumber", labelFields.ProductNumber },
                    { "supplierNumber", labelFields.SupplierNumber },
                    { "dateStamp", labelFields.DateStamp },
                    { "quantity", labelFields.Quantity },
                    { "grossWeight", labelFields.GrossWeight },
                    { "generatedULLId", ssccBarcode },
                });

                output.PalletNumber = palletNumber;
                output.SsccBarcode = ssccBarcode;

                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomPrintLabelUnitLoadingInput", customPrintLabelUnitLoadingInput),
                                            new KeyValuePair<string, object>("CustomPrintLabelUnitLoadingOutput", output));
            }
            catch (Exception)
            {
                throw;
            }

            return output;
        }

        /// <summary>
        /// Service to send to IoT all the information to be printed in a Logopak printer
        /// </summary>
        /// <param name="customPrintLogopakULLLabelInput"></param>
        /// <returns></returns>
        public CustomPrintLogopakULLLabelOutput CustomPrintLogopakULLLabel(CustomPrintLogopakULLLabelInput customPrintLogopakULLLabelInput)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomPrintLogopakULLLabel",
                                                   new KeyValuePair<string, object>("CustomPrintLogopakULLLabelInput", customPrintLogopakULLLabelInput));

            CustomPrintLogopakULLLabelOutput output = new CustomPrintLogopakULLLabelOutput();

            Utilities.ValidateNullInput(customPrintLogopakULLLabelInput, new List<string> { "UllLabelInfo" });

            IMaterial pallet = null;
            UllLabelFields ullLabelInfo = null;

            try
            {

                // Load resource that represent the Logopak printer:
                IResource printerResource = _entityFactory.Create<IResource>();
                printerResource.Load(customPrintLogopakULLLabelInput.PrinterName);

                // Loads the main line resource:
                IResource mainLineResource = _entityFactory.Create<IResource>();
                mainLineResource.Load(long.Parse(customPrintLogopakULLLabelInput.ResourceId));


                // If the request comes from IoT, collect all the necessary info. (input property UllLabelInfo is empty)
                if (customPrintLogopakULLLabelInput.UllLabelInfo == null)
                {
                    // Get all info from material:
                    ullLabelInfo = _iKEAUtilities.GetInfoForULLLabel(mainLineResource, printerResource, out pallet);
                }
                // The request comes from the GUI:
                else
                {
                    // Validate and complete the information from the GUI:
                    ullLabelInfo = _iKEAUtilities.GetInfoForULLLabel(customPrintLogopakULLLabelInput.UllLabelInfo, mainLineResource, printerResource);
                }

                // Save the SSCC barcode we're using to print for this pallet
                if (pallet != null && ullLabelInfo != null)
                {
                    pallet.SaveAttributes(new AttributeCollection
                    {
                        { IKEAConstants.CustomMaterialSSCCAttribute, ullLabelInfo.SSCCBarcode }
                    });
                }

                // Prepare a new object to send for IOT:
                Dictionary<string, object> printerInfo = new Dictionary<string, object>();
                printerInfo.Add("LabelInfo", ullLabelInfo);
                printerInfo.Add("Printer", customPrintLogopakULLLabelInput.PrinterName);

                // Send to IoT:
                _iKEAUtilities.SendUllLabelInformationToLogopak(mainLineResource, printerInfo);


                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomPrintLogopakULLLabelInput", customPrintLogopakULLLabelInput),
                                            new KeyValuePair<String, Object>("CustomPrintLogopakULLLabelOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            output.UllLabelInfo = ullLabelInfo;
            return output;
        }

        /// <summary>
        /// Service to Terminate group MO
        /// </summary>
        /// <param name="customTerminateGroupManufacturingOrdersInput"></param>
        /// <returns></returns>
        public CustomTerminateGroupManufacturingOrdersOutput CustomTerminateGroupManufacturingOrders(CustomTerminateGroupManufacturingOrdersInput customTerminateGroupManufacturingOrdersInput)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomTerminateGroupManufacturingOrders",
                  new KeyValuePair<string, object>("CustomTerminateGroupManufacturingOrdersInput", customTerminateGroupManufacturingOrdersInput));

            CustomTerminateGroupManufacturingOrdersOutput output = new CustomTerminateGroupManufacturingOrdersOutput();

            try
            {
                IMaterial groupMO = customTerminateGroupManufacturingOrdersInput.GroupMaterialOrder;
                if (groupMO != null)
                {
                    #region Check if possible to terminate
                    if (groupMO.SystemState != MaterialSystemState.Queued)
                    {
                        throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomTerminateInvalidGroupMOSystemStateLocalizedMessage));
                    }

                    // Find if resource is "optimized"
                    if (_iKEAUtilities.CheckIfGroupMOOnOptimizedResource(groupMO))
                    {
                        CustomGroupOrderStateEnum groupOrderState = groupMO.GetAttributeValueOrDefault<CustomGroupOrderStateEnum>(IKEAConstants.CustomMaterialAttributeGroupOrderState, true);
                        bool groupOrderHPOEnabled = groupMO.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomMaterialAttributeGroupOrderHPOEnabled, loadAttribute: true);

                        if (groupOrderHPOEnabled && CustomGroupOrderStateEnum.Created != groupOrderState)
                        {
                            throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomTerminateInvalidGroupOrderStateLocalizedMessage));
                        }
                    }
                    #endregion

                    #region Update Primary Quantity to 0
                    // set flag to avoid some DEE controls
                    _deeContextUtilities.SetContextParameter(IKEAConstants.CustomHandleGroupManufacturingOrdersEditGroupMOContextKey, true);

                    groupMO.ChangeQuantity(0, 0, null, null, null);

                    // Clear flag:
                    _deeContextUtilities.SetContextParameter(IKEAConstants.CustomHandleGroupManufacturingOrdersEditGroupMOContextKey, false);
                    #endregion

                    #region Terminate the group
                    groupMO.Terminate();
                    #endregion
                }
                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomTerminateGroupManufacturingOrdersInput", customTerminateGroupManufacturingOrdersInput),
                                            new KeyValuePair<string, object>("CustomTerminateGroupManufacturingOrdersOutput", output));
            }
            catch (Exception)
            {
                throw;
            }
            return output;
        }

        /// <summary>
        /// Service to attach and create durables if they do not exist
        /// 
        /// The position on which the durable is attached is calculated based on the following rules:
        /// 
        /// First tries to find a matching BOM Position for this product in any of the Durable BOMs
        /// of the Dispatched or InProcess orders in the resource.
        /// 
        /// If there are BOMs, but none mentioned this product, or the ones that do, have their positions already
        /// occupied by other attached durables, then throws an exception.
        /// 
        /// On the other hand, if there are no BOMs configured for the MOs in the resource, tries to find any free 
        /// durabel position between 1 and Resource.DurablePositions (including). If no free position is found,
        /// throws an exception as well.
        /// </summary>
        /// <param name="CustomAttachDurableInput"></param>
        /// <returns></returns>
        public CustomAttachDurableOutput CustomAttachDurable(CustomAttachDurableInput customAttachDurableInput)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomAttachDurable",
                  new KeyValuePair<string, object>("CustomAttachDurableInput", customAttachDurableInput));

            CustomAttachDurableOutput output = new CustomAttachDurableOutput();

            try
            {
                // Verify if the input parameter is null
                Utilities.ValidateNullInput(customAttachDurableInput);

                IResource resource = _entityFactory.Create<IResource>();
                resource.Name = customAttachDurableInput.Resource;

                IProduct product = _entityFactory.Create<IProduct>();
                product.Name = customAttachDurableInput.Product;
                if (product.ObjectExists())
                {
                    product.Load();
                    if (product.ProductType != ProductType.Durable)
                    {
                        throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomExceptionProductNotDurableLocalizedMessage, customAttachDurableInput.Product));
                    }
                }
                else
                {
                    throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomExceptionProductNotFoundLocalizedMessage, customAttachDurableInput.Product));
                }


                if (resource.ObjectExists())
                {
                    resource.Load();

                    output = new CustomAttachDurableOutput
                    {
                        FeedbackMessages = new Collection<FeedbackMessage>()
                    };

                    string conf_enabled = _iKEAUtilities.GetValueFromConfigurationWithPath(IKEAConstants.AutomaticMaterialCreationEnable);
                    string materialName = customAttachDurableInput.Material;

                    // If there is not Material token, generate a material name
                    if (materialName.IsNullOrEmpty())
                    {
                        // Load name generator to ensure it exists:				
                        INameGenerator groupOrderNameGenerator = _entityFactory.Create<INameGenerator>();
                        groupOrderNameGenerator.Load(IKEAConstants.CustomDurableMaterialNameGenerator);

                        // Generate name
                        materialName = groupOrderNameGenerator.GenerateName(IKEAConstants.CustomDurableMaterialNameGenerator);
                    }

                    IMaterial material = _entityFactory.Create<IMaterial>();
                    material.Name = materialName;


                    //Material does not exists and must be created
                    if (!material.ObjectExists())
                    {
                        if (!conf_enabled.IsNullOrEmpty() && bool.Parse(conf_enabled))
                        {
                            #region Test mandatory expiration date
                            IArea area = resource.Area;
                            string facilityName = null;
                            if (area != null)
                            {
                                area.Load();
                                facilityName = area.Facility?.Name ?? null;
                            }
                            if (_iKEAUtilities.ResolveCustomExpirationDateRequirementContext(facilityName: facilityName, areaName: area.Name, resourceName: resource.Name, productName: product.Name))
                            {
                                if (customAttachDurableInput.MaterialExpirationDate == null)
                                {
                                    throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomMaterialExpirationDateIsMandatoryLocalizedMessage));
                                }
                            }
                            #endregion

                            material = _automaticMaterialCreationUtilities.CustomCreateScannedDurableAutomaticallyUtility(materialName, customAttachDurableInput.Product, customAttachDurableInput.Quantity, resource);

                            if (material != null)
                            {

                                //Add create material success message
                                output.FeedbackMessages.Add(new FeedbackMessage()
                                {
                                    MessageType = FeedbackMessageType.Success,
                                    Message = _iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomAutoMaterialCreationSuccessMessage, material.Name, material.Product.Name, material.PrimaryQuantity.ToString())
                                });

                            }
                        }
                        //Error: Material does not exists and it was not created:
                        else
                        {
                            throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomBarcodeExceptionsMaterialNotFoundLocalizedMessage, material.Name));
                        }
                    }

                    //Attach the material to the resource:
                    material.Load();

                    // update expiration date if provided
                    if (customAttachDurableInput.MaterialExpirationDate != null)
                    {
                        material.ExpirationDate = customAttachDurableInput.MaterialExpirationDate;
                        material.Save();
                    }

                    IResource topMost = resource.GetTopMostResource();

                    IResourceDurable materialResourceRelation = _entityFactory.Create<IResourceDurable>();
                    materialResourceRelation.SourceEntity = resource;
                    materialResourceRelation.TargetEntity = material;
                    materialResourceRelation.Position = customAttachDurableInput.Position;
                    var resourceDurableCollection = _entityFactory.CreateCollection<IResourceDurableCollection>();
                    resourceDurableCollection.Add(materialResourceRelation);
                    bool ByPassDurableValidation = _genericUtilities.GetConfigurationValueByPath<bool>(IKEAConstants.ResourceByPassDurableValidation);
                    ManageResourceDurablesInput input = new ManageResourceDurablesInput()
                    {
                        DurableToAttachCollection = resourceDurableCollection,
                        BypassDurablesContextValidation = ByPassDurableValidation,
                        Resource = topMost,
                    };
                    _resourceOrchestration.ManageResourceDurables(input);

                    //Add attach success message:
                    output.FeedbackMessages.Add(new FeedbackMessage()
                    {
                        MessageType = FeedbackMessageType.Success,
                        Message = _iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomBarcodeSuccessMessageLocalizedMessage, material.Name, resource.Name)
                    });

                    material.Load();
                    output.Material = material;
                }
                else
                {
                    //Resouce not in MEs
                    throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomBarcodeExceptionsResourceNotFoundLocalizedMessage, resource.Name));
                }

                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomAttachDurableInput", customAttachDurableInput),
                                            new KeyValuePair<string, object>("CustomAttachDurableOutput", output));
            }
            catch (Exception)
            {
                throw;
            }
            return output;
        }

        /// <summary>
        /// Service to Suspend or Unspuspend a material on the line
        /// </summary>
        /// <param name="customSuspendMaterialInput"></param>
        /// <returns></returns>
        public CustomSuspendMaterialOutput CustomSuspendMaterial(CustomSuspendMaterialInput customSuspendMaterialInput)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomSuspendMaterial",
                  new KeyValuePair<string, object>("CustomSuspendMaterialInput", customSuspendMaterialInput));

            CustomSuspendMaterialOutput output = new CustomSuspendMaterialOutput();

            Utilities.ValidateNullInput(customSuspendMaterialInput);

            try
            {
                var material = customSuspendMaterialInput.Material;
                material.Load();

                if (material.LastProcessedResource == null)
                {
                    throw _iKEAUtilities.LocalizedException(IKEAConstants.CustomOrderMaterialNotInProcessMessage, material.Name);
                }

                //Get resource from material:
                IResource resource = material.LastProcessedResource;
                resource.Load();

                if (resource.AutomationMode == ResourceAutomationMode.Online)
                {
                    IAutomationControllerInstance controllerInstance = resource.GetAutomationControllerInstance();
                    if (controllerInstance != null)
                    {
                        // Get EI default timeout
                        int requestTimeout = _genericUtilities.GetConfigurationValueByPath<int>(IKEAConstants.DownloadOrderToAutomationSendRequestDefaultTimeout);

                        // Prepare material details to send order stop
                        Dictionary<string, string> materialDetails = new Dictionary<string, string>();
                        materialDetails.Add("MaterialName", material.Name);

                        string message = customSuspendMaterialInput.Unsuspend
                            ? IKEAConstants.AutomationRequestTypeUnsuspendMaterial
                            : IKEAConstants.AutomationRequestTypeSuspendMaterial;

                        // Send Asynchronous request to automation to request Order to be Suspended/Unsuspended
                        var eiReply = _genericUtilities.RequestFromIoT<Dictionary<string, object>>(controllerInstance, message, materialDetails.ToJsonString());

                        object parsedReply = null;
                        eiReply.TryGetValue(IKEAConstants.AutomationRequestReplyField, out parsedReply);

                        if (Convert.ToBoolean(parsedReply) != true)
                        {
                            //Throw connect IOT / Line controller error
                            throw _iKEAUtilities.LocalizedException(IKEAConstants.CustomStopMaterialNoReasonSuppliedMessage);
                        }
                    }
                }
                material.Load();
                output.Material = material;

                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomSuspendMaterialInput", customSuspendMaterialInput),
                                            new KeyValuePair<string, object>("CustomSuspendMaterialOutput", output));
            }
            catch (Exception)
            {
                throw;
            }

            return output;
        }

        /// <summary>
        /// Service to print a ULL label
        /// </summary>
        /// <param name="CustomLoadResourceLogicalChart"></param>
        /// <returns></returns>
        public CustomLoadResourceLogicalChartOutput CustomLoadResourceLogicalChart(CustomLoadResourceLogicalChartInput customLoadResourceLogicalChartInput)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomLoadResourceLogicalChart",
                  new KeyValuePair<string, object>("CustomLoadResourceLogicalChartInput", customLoadResourceLogicalChartInput));

            CustomLoadResourceLogicalChartOutput output = new CustomLoadResourceLogicalChartOutput();

            try
            {
                if (customLoadResourceLogicalChartInput.Resource == null)
                {
                    throw new ArgumentNullCmfException(nameof(customLoadResourceLogicalChartInput.Resource));
                }

                EntityCache entityCache = new EntityCache();

                List<string> entityNames = new List<string>();
                IProductCollection filterProducts = _entityFactory.CreateCollection<IProductCollection>();
                IProductGroupCollection filterProductGroups = _entityFactory.CreateCollection<IProductGroupCollection>();

                // Resource
                if (customLoadResourceLogicalChartInput.Resource != null)
                {
                    entityNames.Add(customLoadResourceLogicalChartInput.Resource.Name);
                }

                // Product
                if (customLoadResourceLogicalChartInput.Product != null)
                {
                    filterProducts.Add(customLoadResourceLogicalChartInput.Product);
                }

                // ProductGroup
                if (customLoadResourceLogicalChartInput.ProductGroup != null)
                {
                    filterProductGroups.Add(customLoadResourceLogicalChartInput.ProductGroup);
                }

                // Material
                if (customLoadResourceLogicalChartInput.Material != null)
                {
                    IMaterial material = entityCache.Fetch(customLoadResourceLogicalChartInput.Material);

                    if (customLoadResourceLogicalChartInput.Material.IsGroupMO())
                    {
                        IMaterialCollection materialColection = _iKEAUtilities.GetChildMaterialsFromGroupMO(customLoadResourceLogicalChartInput.Material, loadAttributes: false);
                        foreach (IMaterial childMaterial in materialColection)
                        {
                            childMaterial.Product = entityCache.Fetch(childMaterial.Product);

                            if (!filterProducts.Any(product => product.Name == childMaterial.Product.Name))
                            {
                                filterProducts.Add(childMaterial.Product);
                            }

                            // ProductGroup
                            if (childMaterial.Product.ProductGroup != null)
                            {
                                childMaterial.Product.ProductGroup = entityCache.Fetch(childMaterial.Product.ProductGroup);

                                if (!filterProductGroups.Any(productGroup => productGroup.Name == childMaterial.Product.ProductGroup.Name))
                                {
                                    filterProductGroups.Add(childMaterial.Product.ProductGroup);
                                }
                            }
                        }
                    }
                    else
                    {
                        if (customLoadResourceLogicalChartInput.Material.Product == null)
                        {
                            customLoadResourceLogicalChartInput.Material.Load();
                        }

                        IProduct materialProduct = entityCache.Fetch(customLoadResourceLogicalChartInput.Material.Product);

                        // Product
                        if (!filterProducts.Any(product => product.Name == materialProduct.Name))
                        {
                            filterProducts.Add(customLoadResourceLogicalChartInput.Material.Product);
                        }

                        // ProductGroup
                        if (materialProduct.ProductGroup != null)
                        {
                            materialProduct.ProductGroup = entityCache.Fetch(materialProduct.ProductGroup);

                            if (!filterProductGroups.Any(productGroup => productGroup.Name == materialProduct.ProductGroup.Name))
                            {
                                filterProductGroups.Add(materialProduct.ProductGroup);
                            }
                        }
                    }
                }

                entityNames.AddRange(filterProducts.Select(product => product.Name + Cmf.Navigo.Common.Constants.LogicalChartRevisionContextSpliter + product.Revision));
                entityNames.AddRange(filterProductGroups.Select(productGroup => productGroup.Name + Cmf.Navigo.Common.Constants.LogicalChartRevisionContextSpliter + productGroup.Revision));

                ILogicalChartCollection logicalCharts = _iKEAUtilities.GetLogicalCharts(entityNames);
                ILogicalChartCollection matchedLogicalCharts = _entityFactory.CreateCollection<ILogicalChartCollection>();

                // Store the filters
                IResource filterResource = customLoadResourceLogicalChartInput.Resource;
                IParameter filterParameter = customLoadResourceLogicalChartInput.Parameter;
                string filterChartType = customLoadResourceLogicalChartInput.ChartType;

                Dictionary<long, IChart> chartsById = new Dictionary<long, IChart>();
                Dictionary<long, IParameter> parametersById = new Dictionary<long, IParameter>();

                foreach (ILogicalChart logicalChart in logicalCharts)
                {
                    logicalChart.Load();
                    logicalChart.Chart = entityCache.Fetch(logicalChart.Chart);

                    if (filterChartType != null && logicalChart.Chart.Type != filterChartType)
                    {
                        continue;
                    }

                    logicalChart.Chart.Parameter = entityCache.Fetch(logicalChart.Chart.Parameter);

                    if (filterParameter != null && logicalChart.Chart.Parameter.Name != filterParameter.Name)
                    {
                        continue;
                    }

                    if (logicalChart.Chart.ContextInformation == null)
                    {
                        logicalChart.Chart.LoadContextInformation();
                    }

                    bool anyResourceContext = false;
                    bool matchesResource = false;

                    bool anyProductGroupContext = false;
                    bool matchesProductGroup = false;

                    bool anyProductContext = false;
                    bool matchesProduct = false;

                    string[] keys = logicalChart.ContextKeys.Split(new string[] { Cmf.Navigo.Common.Constants.LogicalChartContextSpliter }, StringSplitOptions.None);

                    var index = 0;
                    foreach (IChartContextInformation context in logicalChart.Chart.ContextInformation.Where(ctx => ctx.IsKey).OrderBy(ctx => ctx.KeyOrder))
                    {
                        // Make sure we are never out of bounds
                        if (index >= keys.Length) break;

                        string contextKey = keys[index].Split(new string[] { Cmf.Navigo.Common.Constants.LogicalChartRevisionContextSpliter }, StringSplitOptions.None).FirstOrDefault();

                        // Ignore context variables that are not entities or not keys
                        if (context.ContextType != ChartContextInformationType.Object)
                        {
                            index += 1;
                            continue;
                        }

                        if (!matchesResource && context.ContextSource == "Resource")
                        {
                            anyResourceContext = true;

                            if (filterResource != null && contextKey == filterResource.Name)
                            {
                                matchesResource = true;
                            }
                        }
                        else if (!matchesProduct && context.ContextSource == "Product")
                        {
                            anyProductContext = true;

                            if (filterProducts.Any(product => contextKey == product.Name))
                            {
                                matchesProduct = true;
                            }
                        }
                        else if (!matchesProductGroup && context.ContextSource == "ProductGroup")
                        {
                            anyProductGroupContext = true;

                            if (filterProductGroups.Any(productGroup => contextKey == productGroup.Name))
                            {
                                matchesProductGroup = true;
                            }
                        }

                        index += 1;
                    }

                    // When filtering by product we only want to see that specific product
                    if (customLoadResourceLogicalChartInput.Product != null && !anyProductContext)
                    {
                        continue;
                    }

                    // If none of the contexts are of the types we want, then we can skip this logical chart
                    if (!anyResourceContext && !anyProductContext && !anyProductGroupContext)
                    {
                        // Skip logical chart
                        continue;
                    }

                    // We consider a match if no context of that type was present as well
                    matchesResource = matchesResource || !anyResourceContext;
                    matchesProduct = matchesProduct || !anyProductContext || filterProducts.Any() == false;
                    matchesProductGroup = matchesProductGroup || !anyProductGroupContext || filterProductGroups.Any() == false;

                    if (!matchesResource || !matchesProduct || !matchesProductGroup)
                    {
                        // Skip logical chart
                        continue;
                    }

                    matchedLogicalCharts.Add(logicalChart);
                }

                output.LogicalCharts = matchedLogicalCharts;

                Utilities.EndMethod(-1, -1, new KeyValuePair<string, object>("CustomLoadResourceLogicalChartInput", customLoadResourceLogicalChartInput),
                                            new KeyValuePair<string, object>("CustomLoadResourceLogicalChartOutput", output));
            }
            catch (Exception)
            {
                throw;
            }

            return output;
        }

        /// <summary>
        /// Custom GetDataForOEE service
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public CustomGetDataForOEEOutput CustomGetDataForOEE(CustomGetDataForOEEInput input)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME,
                                  "CustomGetDataForOEE",
                                  new KeyValuePair<string, object>("CustomGetDataForOEEInput", input));

            CustomGetDataForOEEOutput output = null;

            try
            {
                Cmf.Foundation.Common.Utilities.ValidateNullInput(input);

                ApplicationContext.CallContext.AddServiceComments(input.ServiceComments);
                output = new CustomGetDataForOEEOutput();

                TransactionOptions options = new TransactionOptions();
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Suppress, options))
                {
                    DataSet data = _iKEAUtilities.GetDataForOEE(input.TimeFrame,
                                                           input.GetActual,
                                                           input.FacilityName,
                                                           input.AreaName,
                                                           input.Resources,
                                                           input.ResourceTypes,
                                                           input.ResourceResourceTypes,
                                                           input.ShiftDefinition,
                                                           input.Shifts);

                    output.Data = NgpDataSet.FromDataSet(data);

                    output.ShowDecimals = _iKEAUtilities.GetShowDecimalsValue();
                }

                Utilities.EndMethod(
                    -1,
                    -1,
                    new KeyValuePair<string, object>("CustomGetDataForOEEInput", input),
                    new KeyValuePair<string, object>("CustomGetDataForOEEOutput", output));

            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw new CmfBaseException(ex.Message, ex);
            }

            return output;
        }

        /// <summary>
        /// Custom service to retrieve Resources KPIs
        /// </summary>
        /// <param name="input">Input Object</param>
        /// <returns>Output Object</returns>
        public CustomGetDataForEPMWithShiftOutput CustomGetDataForEPMWithShift(CustomGetDataForEPMWithShiftInput input)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomGetDataForEPMWithShift",
                new KeyValuePair<String, Object>("CustomGetDataForEPMWithShiftInput", input));

            CustomGetDataForEPMWithShiftOutput output = new CustomGetDataForEPMWithShiftOutput();

            try
            {
                Utilities.ValidateNullInput(input);

                Dictionary<string, INgpDataSet> ngpStateChanges = new Dictionary<string, INgpDataSet>();
                INgpDataSet ngpStateSummary = new NgpDataSet();
                INgpDataSet ngpData = new NgpDataSet();

                TransactionOptions options = new TransactionOptions();
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Suppress, options))
                {

                    //ngpStateChanges = (input.Resources != null && input.Resources.Count == 1 && input.Resources[0] != "")
                    //    ? _iKEAUtilities.GetResourcePerformanceStateChange(input.TimeFrame, input.GetActual, input.Resources, input.ResourceTypes, input.ResourceResourceTypes, input.ShiftDefinition, input.Shifts)
                    //    : _iKEAUtilities.GetResourcePerformanceStateChange(input.TimeFrame, input.GetActual, null, input.ResourceTypes, input.ResourceResourceTypes, input.ShiftDefinition, input.Shifts);

                    ngpStateSummary = (input.Resources != null && input.Resources.Count == 1 && input.Resources[0] != "")

                        ? _iKEAUtilities.GetResourcePerformanceStateChangeSummary(input.TimeFrame, input.GetActual, input.Resources, input.ResourceTypes, input.ResourceResourceTypes, input.ShiftDefinition, input.Shifts)
                        : _iKEAUtilities.GetResourcePerformanceStateChangeSummary(input.TimeFrame, input.GetActual, null, input.ResourceTypes, input.ResourceResourceTypes, input.ShiftDefinition, input.Shifts);

                    ngpData = (input.Resources != null && input.Resources.Count == 1 && input.Resources[0] != "")
                        ? _iKEAUtilities.GetResourcePerformance(input.TimeFrame, input.GetActual, input.Resources, input.ResourceTypes, input.ResourceResourceTypes, input.ShiftDefinition, input.Shifts)
                        : _iKEAUtilities.GetResourcePerformance(input.TimeFrame, input.GetActual, null, input.ResourceTypes, input.ResourceResourceTypes, input.ShiftDefinition, input.Shifts);
                }

                // update state summary output:
                output.StateSummary = ngpStateSummary;

                // update state changes output:
                output.StateChanges = ngpStateChanges;

                // update data output:
                output.Data = ngpData;


                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomGetDataForEPMWithShiftInput", input),
                                            new KeyValuePair<String, Object>("CustomGetDataForEPMWithShiftOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            return output;
        }

        /// <summary>
        /// Custom service to retrieve Resources KPIs
        /// </summary>
        /// <param name="input">Input Object</param>
        /// <returns>Output Object</returns>
        public CustomGetDataForEPMSummaryWithShiftOutput CustomGetDataForEPMSummaryWithShift(CustomGetDataForEPMSummaryWithShiftInput input)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomGetDataForEPMSummaryWithShift",
                new KeyValuePair<String, Object>("CustomGetDataForEPMSummaryWithShiftInput", input));

            CustomGetDataForEPMSummaryWithShiftOutput output = new CustomGetDataForEPMSummaryWithShiftOutput();

            try
            {
                Utilities.ValidateNullInput(input, new List<string> { "ShiftDefinition", "ShiftDefinitionShift" });

                //Dictionary<string, NgpDataSet> ngpStateChanges = new Dictionary<string, NgpDataSet>();
                INgpDataSet ngpStateSummary = new NgpDataSet();
                //NgpDataSet ngpData = new NgpDataSet();

                TransactionOptions options = new TransactionOptions();
                using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Suppress, options))
                {

                    string shiftDefinition = null;
                    List<string> shiftDefinitionShifts = null;
                    if (input.ShiftDefinition != null)
                    {
                        shiftDefinition = input.ShiftDefinition.Name;
                    }

                    if (input.ShiftDefinitionShift != null)
                    {
                        shiftDefinitionShifts = new List<string> { input.ShiftDefinitionShift.Name };
                    }

                    ngpStateSummary = (input.Resources != null && input.Resources.Count == 1 && input.Resources[0] != "")

                        ? _iKEAUtilities.GetResourcePerformanceStateChangeSummary(input.TimeFrame, input.GetActual, input.Resources, input.ResourceTypes, input.ResourceResourceTypes, shiftDefinition, shiftDefinitionShifts)
                        : _iKEAUtilities.GetResourcePerformanceStateChangeSummary(input.TimeFrame, input.GetActual, null, input.ResourceTypes, input.ResourceResourceTypes, shiftDefinition, shiftDefinitionShifts);
                }


                #region Build Custom State Summary
                // Create a Dataset to parse data
                DataSet dsCustomStateSummary = NgpDataSet.ToDataSet(ngpStateSummary);
                // Validate if dataset has values 
                // > Need to use full namespace because HasData is defined in two DLL's so call would be ambiguous
                if (dsCustomStateSummary.HasData())
                {
                    if (input.StatesMapping != null)
                    {
                        System.Data.DataTable newDataTable = dsCustomStateSummary.Tables[0].Clone();

                        // Get Values from DataTable aggregating them depending on input.StatesMapping
                        foreach (var item in input.StatesMapping)
                        {
                            if (!item.Key.CompareStrings("$id"))
                            {
                                StringBuilder stringBuilder = new StringBuilder();
                                // Serialization sets "Item.Value" to NULL when the Key is equal to Value and there is only one value in the Value list
                                // If it has values > State in (list_of_values)
                                if (!item.Value.IsNullOrEmpty())
                                {
                                    stringBuilder.AppendFormat("State IN ('{0}')", string.Join("','", item.Value));
                                }
                                else
                                {
                                    // else state is the key value of the Dictionary
                                    stringBuilder.AppendFormat("State = '{0}' ", item.Key);
                                }

                                // Build filter to find Rows to sum
                                DataRow[] dataRows = dsCustomStateSummary.Tables[0].Select(stringBuilder.ToString());

                                decimal? duration = dataRows != null ? dataRows.Where(row => row["Duration"] != null)
                                                                               .Sum(row => row.Field<decimal?>("Duration"))
                                                                     : null;

                                decimal? ratio = dataRows != null ? dataRows.Where(row => row["Ratio"] != null)
                                                                            .Sum(row => row.Field<decimal>("Ratio"))
                                                                  : null;

                                // Add Values to new DataTable
                                DataRow rowToAdd = newDataTable.NewRow();
                                rowToAdd["State"] = item.Key;
                                rowToAdd["Duration"] = duration;
                                rowToAdd["Ratio"] = ratio;
                                newDataTable.Rows.Add(rowToAdd);
                            }
                        }

                        dsCustomStateSummary.Tables[0].Rows.Clear();
                        foreach (DataRow item in newDataTable.Rows)
                        {
                            dsCustomStateSummary.Tables[0].ImportRow(item);
                        }
                    }
                    else
                    {
                        // Return all the data set columns without column 'Total'
                        foreach (DataRow row in dsCustomStateSummary.Tables[0].Select())
                        {
                            if (row.Field<string>("State").CompareStrings("TOTAL"))
                            {
                                dsCustomStateSummary.Tables[0].Rows.Remove(row);
                            }
                        }
                    }

                    dsCustomStateSummary.Tables[0].AcceptChanges();
                    output.CustomStateSummary = NgpDataSet.FromDataSet(dsCustomStateSummary);

                }
                //No data was retrieved
                else
                {
                    output.CustomStateSummary = new NgpDataSet();
                }
                #endregion


                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomGetDataForEPMSummaryWithShiftInput", input),
                                            new KeyValuePair<String, Object>("CustomGetDataForEPMSummaryWithShiftOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            return output;
        }

        /// <summary>
        /// Custom service to recieve messages from the WMS
        /// </summary>
        /// <param name="input">Input Object</param>
        /// <returns>Output Object</returns>
        public CustomWMSOrderProgressOutput CustomWMSOrderProgress(CustomWMSOrderProgressInput input)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomWMSOrderProgress",
                 new KeyValuePair<String, Object>("CustomWMSOrderProgressInput", input));

            // Update the service output with the same data as the service input:
            CustomWMSOrderProgressOutput output = new CustomWMSOrderProgressOutput();

            try
            {
                Utilities.ValidateNullInput(input);

                List<string> errorDetails = new List<string>();

                bool createNotRequestedMaterial = false;

                // Get the tracker for this IOID:
                var replenishmentRequestTrackers = _wmsUtilities.GetCustomWMSMaterialTrackers((long)input.IOID);

                // No tracker found. It means that this IOID was not a request from MES, check if it is necessary to create the material anyway:
                if (replenishmentRequestTrackers.IsNullOrEmpty())
                {
                    createNotRequestedMaterial = _genericUtilities.GetConfigurationValueByPath<bool>(IKEAConstants.WMSCreateNotRequestedMaterials);
                    if (!createNotRequestedMaterial)
                    {
                        errorDetails.Add(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomWMSInvalidInventoryIdReceivedLocalizedMessage, input.IOID));
                    }
                }

                if (errorDetails.IsNullOrEmpty())
                {
                    CustomWMSOrderRequestType ioType = CustomWMSOrderRequestType.None;
                    ICustomWMSMaterialTracker requestTracker = null;

                    if (createNotRequestedMaterial)
                    {
                        // Although the material was not requested, we will consider this as a Feed operation
                        ioType = CustomWMSOrderRequestType.Feed;
                    }
                    else
                    {
                        // Get the tracker for the supplied inventory order Id:
                        requestTracker = replenishmentRequestTrackers.FirstOrDefault();
                        ioType = (CustomWMSOrderRequestType)requestTracker.OrderRequestType.Value;
                    }

                    switch (ioType)
                    {
                        #region Inventory Order Type Feed
                        case CustomWMSOrderRequestType.Feed:

                            // Validate the Status field:
                            if (input.Status > 0)
                            {
                                errorDetails.Add(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomWMSStatusFieldNotValidLocalizedMessage, input.Status.ToString()));
                            }
                            // Validate the DeliveredQuantity field:
                            if (input.DeliveredQuantity <= 0)
                            {
                                errorDetails.Add(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomWMSDeliveredQuantityFieldNotValidLocalizedMessage, input.DeliveredQuantity.ToString()));
                            }
                            // Validate the PalletQuantity field:
                            if (input.PalletQuantity <= 0)
                            {
                                errorDetails.Add(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomWMSPalletQuantityFieldNotValidLocalizedMessage, input.PalletQuantity.ToString()));
                            }
                            // Validate the ItemID field:
                            if (string.IsNullOrWhiteSpace(input.ItemID))
                            {
                                errorDetails.Add(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomWMSItemIdFieldNotValidLocalizedMessage, input.ItemID));
                            }
                            // Validate the BatchID field:
                            if (string.IsNullOrWhiteSpace(input.BatchID))
                            {
                                errorDetails.Add(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomWMSBatchIdFieldNotValidLocalizedMessage, input.BatchID));
                            }

                            if (errorDetails.IsNullOrEmpty())
                            {
                                string resourceName = input.Destination;
                                string productionOrderName = null;

                                if (requestTracker != null)
                                {
                                    decimal? maxOverDelivery = null;

                                    // Check if the quantity to be delivered respects the conditions set up in ST CustomWMSOverDeliveryResolution
                                    IResource feeder = _entityFactory.Create<IResource>();
                                    feeder.Name = requestTracker.DestinationStockingPoint;
                                    feeder.Load();

                                    IResource resourceTopMost = feeder.GetTopMostResource();
                                    resourceTopMost.Load();

                                    IArea area = resourceTopMost.Area;

                                    IFacility facility = area.Facility;

                                    string resourceWorkcenter = resourceTopMost.GetAttributeValueOrDefault<string>(IKEAConstants.CustomResourceAttributeWorkCenter, true);


                                    Tuple<decimal, decimal?, decimal?, decimal?> allowedOverDelivery = null;
                                    IMaterial mo = _entityFactory.Create<IMaterial>();
                                    mo.Name = requestTracker.ManufacturingOrder;
                                    mo.Load();
                                    Dictionary<IMaterial, decimal> childMOsPartPerCycle = null;
                                    if (mo.IsChildOfGroupMO())
                                    {

                                        childMOsPartPerCycle = _iKEAUtilities.GetChildMaterialsAndPartsPerCycleFromGroupMO(mo.GetGroupMOFromChild());
                                        foreach (KeyValuePair<IMaterial, decimal> childMo in childMOsPartPerCycle)
                                        {
                                            IProduct product = _entityFactory.Create<IProduct>();
                                            if (requestTracker != null)
                                            {
                                                childMo.Key.Product.Load();
                                                string productName = childMo.Key.Product.Name;
                                                product.Load(productName);
                                            }

                                            IProductGroup productGroup = _entityFactory.Create<IProductGroup>();
                                            if (product != null)
                                            {
                                                productGroup = product.ProductGroup;
                                            }

                                            allowedOverDelivery = _iKEAUtilities.ResolveCustomWMSOverDeliveryResolutionSmartTable(facility, area, resourceTopMost, resourceWorkcenter, product, productGroup);
                                            if (allowedOverDelivery != null)
                                                break;
                                        }
                                    }
                                    else
                                    {
                                        IProduct product = _entityFactory.Create<IProduct>();
                                        if (requestTracker != null)
                                        {
                                            string productName = requestTracker.ProductName;
                                            product.Load(productName);
                                        }

                                        IProductGroup productGroup = _entityFactory.Create<IProductGroup>();
                                        if (product != null)
                                        {
                                            productGroup = product.ProductGroup;
                                        }

                                        // Item1 = OverDeliveryPercentage
                                        // Item2 = OverDeliveryQuantity
                                        allowedOverDelivery = _iKEAUtilities.ResolveCustomWMSOverDeliveryResolutionSmartTable(facility, area, resourceTopMost, resourceWorkcenter, product, productGroup);
                                    }


                                    // If it was possible to resolve ST CustomWMSOverDeliveryResolution,
                                    // then we are before an over-delivery scenario
                                    if (allowedOverDelivery != null)
                                    {
                                        decimal? overDeliveryBasedOnPercentage = null;
                                        decimal? overDeliveryBasedOnQuantity = null;

                                        if (mo.IsChildOfGroupMO())
                                        {
                                            // Calculate the possible ranges, based on percentage and quantity (if provided)									
                                            overDeliveryBasedOnPercentage = requestTracker.RequestedQuantity * (1 + allowedOverDelivery.Item1 / 100);
                                            // Multiply the pieces by the total of all parts per cycle
                                            overDeliveryBasedOnQuantity = requestTracker.RequestedQuantity + (childMOsPartPerCycle.Where(pair => pair.Key.Name == mo.Name).FirstOrDefault().Value * allowedOverDelivery.Item2);
                                        }
                                        else
                                        {
                                            // Calculate the possible ranges, based on percentage and quantity (if provided)									
                                            overDeliveryBasedOnPercentage = requestTracker.RequestedQuantity * (1 + allowedOverDelivery.Item1 / 100);
                                            overDeliveryBasedOnQuantity = requestTracker.RequestedQuantity + allowedOverDelivery.Item2;
                                        }

                                        if (overDeliveryBasedOnQuantity >= 0)
                                        {
                                            // if both percentage and quantity were provided, consider the lower of the 2 values
                                            maxOverDelivery = Math.Min((decimal)overDeliveryBasedOnPercentage, (decimal)overDeliveryBasedOnQuantity);
                                        }
                                        else
                                        {
                                            maxOverDelivery = overDeliveryBasedOnPercentage;
                                        }
                                    }

                                    // Check if quantity to be delivered, together with the quantity that has already been delivered, will be in range of max over-delivery
                                    bool isDeliveredQuantityInRange = true;
                                    if (maxOverDelivery != null)
                                    {
                                        isDeliveredQuantityInRange = requestTracker.DeliveredQuantity + input.PalletQuantity <= maxOverDelivery;
                                    }

                                    // Get the destination resource name from the request tracker:
                                    resourceName = requestTracker.DestinationStockingPoint;

                                    // Get the productionorder name from the request tracker:
                                    productionOrderName = requestTracker.ManufacturingOrder;

                                    // Update the request tracker delivered quantity:
                                    requestTracker.DeliveredQuantity += input.PalletQuantity;
                                    requestTracker.Save();

                                    if (requestTracker.DeliveredQuantity >= requestTracker.RequestedQuantity)
                                    {
                                        // Terminate the tracker for this inventory order Id:
                                        replenishmentRequestTrackers.Terminate();

                                        // Send message to FA to Complete the Job
                                        string result = _wmsUtilities.SendRequestToFactoryAutomation((long)input.IOID, IKEAConstants.WMSFactoryAutomationRequestTypeComplete, true);
                                        if (!string.IsNullOrWhiteSpace(result))
                                        {
                                            errorDetails.Add(result);
                                        }
                                    }

                                    if (!isDeliveredQuantityInRange)
                                    {
                                        // Notify employees in case of threshold surpassed									
                                        IEmployeeCollection employeesToBeNotified = _entityFactory.CreateCollection<IEmployeeCollection>();
                                        if (!string.IsNullOrWhiteSpace(resourceTopMost.Name))
                                        {
                                            // Get employees chechecked-in at the top most resource, to send them the notification
                                            employeesToBeNotified = _genericUtilities.GetCheckedInEmployees(resourceTopMost.Name);

                                            if (employeesToBeNotified != null && employeesToBeNotified.Any())
                                            {
                                                employeesToBeNotified.Load();
                                            }

                                            // Get details to send in notification
                                            string title = _iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomWMSOverDeliveryExceededTitle);
                                            string details = _iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomWMSOverDeliveryExceeded, input.PalletQuantity, maxOverDelivery.Value.ToString("#.##"));

                                            // Send notification to all employees checked in
                                            _iKEAUtilities.GenerateNotificationToEmployees(title, details, employeesToBeNotified, resource: resourceTopMost, sendEmail: false);
                                        }
                                    }
                                }

                                // Create or Update the material in MES:
                                if (errorDetails.IsNullOrEmpty())
                                {
                                    if (!string.IsNullOrWhiteSpace(resourceName))
                                    {
                                        IMaterial material = _entityFactory.Create<IMaterial>();
                                        material.Name = input.PalletID;

                                        // Check if the material exists
                                        if (material.ObjectExists())
                                        {
                                            // Update the material in MES
                                            material = _wmsUtilities.UpdateMaterialFromWMS(input, out errorDetails, resourceName, productionOrderName);
                                        }
                                        else
                                        {
                                            // Create the material in MES
                                            material = _wmsUtilities.CreateMaterialFromWMS(input, out errorDetails, resourceName, productionOrderName);
                                        }
                                        if (material != null && errorDetails.IsNullOrEmpty())
                                        {
                                            output.Response = CustomWMSOrderResponseType.Accepted;

                                            if (ioType == CustomWMSOrderRequestType.Feed)
                                            {
                                                // In case of Feed, created material must be attached

                                                // Obtain Resource
                                                IServiceProvider serviceProvider = ApplicationContext.CurrentServiceProvider;
                                                IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
                                                IResource feederResource = _entityFactory.Create<IResource>();
                                                feederResource.Load(resourceName);

                                                IResource mainResource = feederResource.GetTopMostResource();
                                                mainResource.Load();

                                                // Resolve Custom Consumable Feeds Direct Delivery SmartTable
                                                // Returns a boolean, and when its valued as true, the material created on WMS should be
                                                // directly attached to the defined feeder
                                                bool isDirectDelivery = _iKEAUtilities.ResolveCustomConsumableFeedsDirectDelivery(
                                                    mainResource,
                                                    feederResource
                                                    );

                                                if (isDirectDelivery)
                                                {
                                                    material.Load();
                                                    IMaterialCollection materialcolllection = _entityFactory.CreateCollection<IMaterialCollection>();
                                                    materialcolllection.Add(material);
                                                    _iKEAUtilities.ApplyOperationActionsInCollection(materialcolllection, feederResource, IKEAConstants.WMSAttach);
                                                }
                                            }
                                        }
                                    }
                                    else
                                    {
                                        errorDetails.Add(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomWMSResourceNotValidLocalizedMessage, resourceName));
                                    }
                                }


                            }
                            break;
                        #endregion

                        #region Inventory Order Types PutAway, Move and Cancel
                        case CustomWMSOrderRequestType.PutAway:
                        case CustomWMSOrderRequestType.Move:
                        case CustomWMSOrderRequestType.Cancel:

                            // Terminate the tracker for this inventory order Id:
                            replenishmentRequestTrackers.Terminate();

                            // Send message to FA to Complete the Job
                            string automationRequestType = input.IOType == CustomWMSOrderRequestType.Cancel ? IKEAConstants.WMSFactoryAutomationRequestTypeCancel :
                                                                                                              IKEAConstants.WMSFactoryAutomationRequestTypeComplete;

                            string errorMessage = _wmsUtilities.SendRequestToFactoryAutomation((long)input.IOID, automationRequestType, true);

                            // No errors set output as accepted:
                            if (string.IsNullOrWhiteSpace(errorMessage))
                            {
                                output.Response = CustomWMSOrderResponseType.Accepted;
                            }
                            else
                            {
                                errorDetails.Add(errorMessage);
                            }

                            break;
                        #endregion

                        case CustomWMSOrderRequestType.None:
                        default:
                            errorDetails.Add(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomWMSInvalidRequestTypeReceivedLocalizedMessage, (int)ioType));
                            break;
                    }
                }

                // Check if there were errors during the message validation, material update or creation:
                if (!errorDetails.IsNullOrEmpty())
                {
                    output.Details = String.Join("; ", errorDetails);
                    output.Response = CustomWMSOrderResponseType.Rejected;
                }


                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomWMSOrderProgressInput", input),
                                            new KeyValuePair<String, Object>("CustomWMSOrderProgressOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            return output;
        }

        /// <summary>
        /// Custom service to get max additional QTY
        /// </summary>
        /// <param name="input">Input Object</param>
        /// <returns>Output Object</returns>
        public CustomWMSGetMaxAdditionalQuantityOutput CustomWMSGetMaxAdditionalQuantity(CustomWMSGetMaxAdditionalQuantityInput input)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomWMSGetMaxAdditionalQuantity",
                 new KeyValuePair<String, Object>("CustomWMSGetMaxAdditionalQuantityInput", input));
            var output = new CustomWMSGetMaxAdditionalQuantityOutput();
            try
            {
                Tuple<decimal, decimal?, decimal?, decimal?> allowedOverRequest = null;
                decimal? overRequestBasedOnPercentage = null;
                output.ProductWithMaxAdditionalQuantity = new Dictionary<long, decimal?>();
                foreach (var warehouseOrder in input.WareHouseOrdersDetails)
                {
                    IResource feeder = warehouseOrder.DestinationFeeder;
                    IMaterial material = _entityFactory.Create<IMaterial>();
                    material.Name = input.ManufacturingOrders;
                    IResource resourceTopMost = _entityFactory.Create<IResource>();
                    //feeder.Load()
                    if (feeder == null)
                    {
                        material.Load();
                        resourceTopMost = material.LastProcessedResource;
                    }
                    else
                    {
                        resourceTopMost = feeder.GetTopMostResource();
                    }

                    //resourceTopMost.Load();

                    IArea area = resourceTopMost.Area;
                    IFacility facility = area.Facility;
                    IProduct product = warehouseOrder.Product;
                    IProductGroup productGroup = product.ProductGroup;
                    string resourceWorkcenter = resourceTopMost.GetAttributeValueOrDefault<string>(IKEAConstants.CustomResourceAttributeWorkCenter, true);
                    allowedOverRequest = _iKEAUtilities.ResolveCustomWMSOverDeliveryResolutionSmartTable(facility, area, resourceTopMost, resourceWorkcenter, product, productGroup);
                    decimal remianingQuantity = warehouseOrder.RemainingQuantity;
                    decimal? overRequestPercentage = 0;
                    decimal? overRequestQuantity = 0;
                    if (allowedOverRequest != null)
                    {
                        overRequestPercentage = allowedOverRequest.Item3;
                        overRequestQuantity = allowedOverRequest.Item4;
                    }

                    overRequestBasedOnPercentage = remianingQuantity * (overRequestPercentage / 100);

                    decimal? maxAdditionalQuantity = 0;

                    if (overRequestBasedOnPercentage.HasValue && overRequestQuantity.HasValue)  // If both percentage and quantity has value then take less value
                    {
                        maxAdditionalQuantity = overRequestBasedOnPercentage >= overRequestQuantity ? overRequestQuantity : overRequestBasedOnPercentage;
                    }
                    else if (overRequestBasedOnPercentage.HasValue) // If percentage has value then take
                    {
                        maxAdditionalQuantity = overRequestBasedOnPercentage;
                    }
                    else if (overRequestQuantity.HasValue)
                    {
                        maxAdditionalQuantity = overRequestQuantity;
                    }

                    maxAdditionalQuantity = maxAdditionalQuantity.HasValue == true ? maxAdditionalQuantity : 0;

                    output.ProductWithMaxAdditionalQuantity.Add(product.Id, maxAdditionalQuantity);

                    //output.ProductWithMaxAdditionalQuantity.Add(product, maxAdditionalQuantity);
                }

                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomWMSGetMaxAdditionalQuantityInput", input),
                                            new KeyValuePair<String, Object>("CustomWMSGetMaxAdditionalQuantityOutput", output));
            }

            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            return output;


        }

        /// <summary>
        /// Service to be invoked by Factory Automation for making requests to the WMS
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public CustomWMSOrderRequestOutput CustomWMSOrderRequest(CustomWMSOrderRequestInput input)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomWMSOrderRequest",
                 new KeyValuePair<String, Object>("CustomWMSOrderRequestInput", input));

            CustomWMSOrderRequestOutput output = new();

            System.IServiceProvider serviceProvider = ApplicationContext.CurrentServiceProvider;
            IEntityFactory entityFactory = serviceProvider.GetRequiredService<IEntityFactory>();

            try
            {
                string factoryAutomationJobId = input.FactoryAutomationJobId;

                ICustomWMSMaterialTracker jobLatestTracker = null;

                decimal feedQuantity = input.MaterialQuantity;

                jobLatestTracker = _wmsUtilities.GetJobLatestCustomWMSMaterialTracker(factoryAutomationJobId, true);

                //Don't do repeated requests
                if (jobLatestTracker == null ||
                    jobLatestTracker.UniversalState == UniversalState.Terminated ||
                    input.InventoryOrderType == CustomWMSOrderRequestType.Cancel)
                {

                    // When a FEED Job is canceled, only ask for delivery of whatever quantity was missing (not yet delivered)
                    if (input.InventoryOrderType == CustomWMSOrderRequestType.Feed)
                    {
                        if (jobLatestTracker != null)
                        {
                            feedQuantity = Math.Max(0, (jobLatestTracker.RequestedQuantity ?? feedQuantity) - (jobLatestTracker.DeliveredQuantity ?? 0));
                        }
                    }


                    // Build an OrderRequest message based on the input (invoked by FA):
                    WMSIntegrationMessage wmsIntegrationMessage = _wmsUtilities.CreateWMSOrderRequestMessage(type: input.InventoryOrderType,
                                                                                         productName: input.ProductName,
                                                                                         materialName: input.PalletName,
                                                                                         productionOrderName: input.ManufacturingOrderName,
                                                                                         feedQuantity: feedQuantity,
                                                                                         sourceResourceName: input.SourceResource,
                                                                                         destinationResourceName: input.DestinationResource,
                                                                                         wmsIOID: input.InventoryOrderId,
                                                                                         batchID: input.BatchID,
                                                                                         palletID: input.PalletName,
                                                                                         status: input.Status);

                    if (wmsIntegrationMessage == null)
                    {
                        throw _iKEAUtilities.LocalizedException(IKEAConstants.CustomWMSDeserializationFailedLocalizedMessage);
                    }

                    // EndPoint
                    string config = input.InventoryOrderType == CustomWMSOrderRequestType.Cancel
                        ? IKEAConstants.WMSEndPoint + IKEAConstants.WMSOrderCancelEndpoint
                        : IKEAConstants.WMSEndPoint + IKEAConstants.WMSOrderRequestEndpoint;
                    string endPoint = _genericUtilities.GetConfigurationValueByPath<string>(config);
                    if (string.IsNullOrWhiteSpace(endPoint))
                    {
                        throw _iKEAUtilities.LocalizedException(IKEAConstants.CustomWMSMissingEndpointConfigLocalizedMessage, config);
                    }

                    // Send message to WMS system:
                    WMSIntegrationMessage wmsResponse = _wmsUtilities.SendWMSMessageWithIntegrationEntry(wmsIntegrationMessage, endPoint, HttpMethod.Post);
                    if (wmsResponse == null)
                    {
                        throw _iKEAUtilities.LocalizedException(IKEAConstants.CustomWMSNoApiMessageFoundLocalizedMessage);
                    }

                    switch (wmsResponse.Response)
                    {
                        case CustomWMSOrderResponseType.Accepted:

                            // If we are cancelling a previous request, clear the trackers for this IOID:
                            if (input.InventoryOrderType == CustomWMSOrderRequestType.Cancel)
                            {
                                var replenishmentRequestTrackers = _wmsUtilities.GetCustomWMSMaterialTrackers(input.InventoryOrderId);

                                if (replenishmentRequestTrackers != null && replenishmentRequestTrackers.Count > 0)
                                {
                                    replenishmentRequestTrackers.Terminate();
                                }
                            }
                            // In case of Feed, Move or PutAway, create a Material request Tracker:
                            else
                            {

                                ICustomWMSMaterialTracker tracker = _entityFactory.Create<ICustomWMSMaterialTracker>();
                                INameGenerator trackerNameGenerator = _entityFactory.Create<INameGenerator>();
                                tracker.Name = string.Format("{0}.{1}.{2}", endPoint, wmsIntegrationMessage.IOType.ToString(), wmsIntegrationMessage.IOID);
                                tracker.FactoryAutomationJobId = factoryAutomationJobId;
                                tracker.InventoryOrderId = wmsResponse.IOID;
                                tracker.ProductName = wmsIntegrationMessage.ItemID;
                                tracker.OrderRequestType = (int)wmsIntegrationMessage.IOType;
                                tracker.RequestedQuantity = wmsIntegrationMessage.Quantity > 0 ? wmsIntegrationMessage.Quantity : wmsIntegrationMessage.PalletQuantity;
                                tracker.SourceStockingPoint = wmsIntegrationMessage.Source;
                                tracker.DestinationStockingPoint = wmsIntegrationMessage.Destination;
                                tracker.DeliveredQuantity = 0;
                                tracker.ManufacturingOrder = input.ManufacturingOrderName;
                                tracker.PalletName = input.PalletName;

                                tracker.Name = trackerNameGenerator.GenerateName(IKEAConstants.CustomWMSMaterialTrackerNameGenerator, tracker);

                                //add BatchID and Status value to attributes
                                tracker.Attributes.Add(IKEAConstants.WMSBatchIDAttributeName, input.BatchID);
                                tracker.Attributes.Add(IKEAConstants.WMSStatusAttributeName, input.Status);

                                tracker.Create();
                                output.IOID = (long)wmsResponse.IOID;
                            }
                            break;

                        case CustomWMSOrderResponseType.Rejected:

                            string configValue = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.WMSContinueCancelWithResponse);
                            if (!string.IsNullOrEmpty(configValue) && wmsResponse.Details.Contains(configValue))
                            {
                                ICustomWMSMaterialTrackerCollection replenishmentRequestTrackers = _wmsUtilities.GetCustomWMSMaterialTrackers(input.InventoryOrderId);
                                if (replenishmentRequestTrackers != null && replenishmentRequestTrackers.Count > 0)
                                {
                                    replenishmentRequestTrackers.Terminate();
                                }
                            }
                            else
                            {
                                throw _iKEAUtilities.LocalizedException(IKEAConstants.CustomWMSExceptionLocalizedMessage, wmsResponse.Details);
                            }
                            break;
                    }
                }
                else
                {
                    // If we are restarting an Automation Job which has an active Tracker,
                    // we still need to include the IOID so that Factory Automation receives it
                    output.IOID = jobLatestTracker.InventoryOrderId ?? 0;
                }

            }
            catch (Exception exception)
            {
                // If this service throws an error the integration entry is not created and thus no feedback to MES about the WMS response.
                // Instead send an output response and consider this as handled exception.
                output = new CustomWMSOrderRequestOutput
                {
                    AutomationJobErrorMessage = exception.Message
                };

            }

            Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomWMSOrderRequestInput", input),
                                        new KeyValuePair<String, Object>("CustomWMSOrderRequestOutput", output));

            return output;
        }

        /// <summary>
        /// Service to send a Cancel Request to IoT
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public CustomWMSCancelOrdersRequestOutput CustomWMSCancelOrdersRequest(CustomWMSCancelOrdersRequestInput input)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomWMSCancelOrdersRequest",
                 new KeyValuePair<String, Object>("CustomWMSCancelOrdersRequestInput", input));

            CustomWMSCancelOrdersRequestOutput output = new CustomWMSCancelOrdersRequestOutput();

            try
            {
                ICustomWMSMaterialTrackerCollection replenishmentRequestTrackers = _wmsUtilities.GetCustomWMSMaterialTrackers(input.FactoryAutomationJobIds, "FactoryAutomationJobId");
                if (!replenishmentRequestTrackers.IsNullOrEmpty())
                {

                    string resourceName = !String.IsNullOrWhiteSpace(_genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.FactoryAutomationWMSHandler)) ?
                                                _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.FactoryAutomationWMSHandler) : "FactoryAutomationWMSHandler";


                    IResource resource = _entityFactory.Create<IResource>();
                    resource.Name = resourceName;

                    resource.Load();

                    IAutomationControllerInstance controllerInstance = resource.GetAutomationControllerInstance();

                    foreach (CustomWMSMaterialTracker requestTracker in replenishmentRequestTrackers)
                    {
                        object data = new { IOID = requestTracker.InventoryOrderId };

                        var eiReply = _genericUtilities.RequestFromIoT<Dictionary<string, object>>(controllerInstance, IKEAConstants.WMSCancelJob, data);

                        object parsedReply = null;
                        eiReply.TryGetValue(IKEAConstants.AutomationRequestReplyField, out parsedReply);
                        if (parsedReply is string)
                        {
                            //Throw error returned by IoT
                            throw _iKEAUtilities.LocalizedException(parsedReply.ToString());
                        }
                        // Canceling multiple Jobs without this delay causes the second cancel to memory override in IoT
                        Thread.Sleep(250);
                    }
                }

                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomWMSCancelOrdersRequestInput", input),
                                            new KeyValuePair<String, Object>("CustomWMSCancelOrdersRequestOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;
        }

        /// <summary>
        /// Custom service to send a request order to WMS
        /// </summary>
        /// <param name="input">Input Object</param>
        /// <returns>Output Object</returns>
        public CustomWMSManualOrderRequestOutput CustomWMSManualOrderRequest(CustomWMSManualOrderRequestInput input)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomWMSManualOrderRequest",
                new KeyValuePair<String, Object>("CustomWMSManualOrderRequestInput", input));

            CustomWMSManualOrderRequestOutput output = new CustomWMSManualOrderRequestOutput();

            try
            {
                #region Validate Input

                Utilities.ValidateNullInput(input);

                if (input.ProductMaterialQuantities.IsNullOrEmpty())
                {
                    throw new ArgumentNullCmfException(nameof(input.ProductMaterialQuantities));
                }

                if (input.Destinations.IsNullOrEmpty())
                {
                    throw new ArgumentNullCmfException(nameof(input.Destinations));
                }

                // Validate if all products have a resource destination set in the input
                foreach (string productName in input.ProductMaterialQuantities.Keys)
                {
                    if (!input.Destinations.ContainsKey(productName) || input.Destinations[productName].IsNullOrEmpty())
                    {
                        throw _iKEAUtilities.LocalizedException(
                            IKEAConstants.CustomWMSFeedProductMissingDestinationLocalizedMessage,
                            productName
                        );
                    }
                }

                #endregion

                CustomWMSOrderRequestType type = CustomWMSOrderRequestType.Feed;

                // Create the list of job inputs to send
                List<Common.WMS.WMSAutomationJobInput> jobInputs = new List<Common.WMS.WMSAutomationJobInput>();

                // Create an EntityCache to easily fetch entities more performantly
                var entityCache = new EntityCache();

                #region Pre-load required entities

                // Pre-Load all the materials
                IEnumerable<string> materialNames = input.ProductMaterialQuantities
                    .SelectMany(products => products.Value)
                    .Select(material => material.Key);
                IMaterialCollection allMaterials = _entityFactory.CreateCollection<IMaterialCollection>();
                allMaterials.AddRange(entityCache.FetchAll<IEntityCollection<IMaterial>, IMaterial>(materialNames).ToList());

                allMaterials.LoadAttributes(new Collection<string> { IKEAConstants.CustomMaterialAttributeIsGroupMO });

                // If there is any material that is a GroupMO, load the child relations
                if (allMaterials.Any(material => material.IsGroupMO(loadAttributes: false)))
                {
                    allMaterials.LoadRelations(IKEAConstants.CustomGroupMaterialManufacturingOrder, 1);
                }

                // Pre-Load all the products
                IEnumerable<string> productNames = input.ProductMaterialQuantities
                    .Select(products => products.Key);
                entityCache.FetchAll<IEntityCollection<IProduct>, IProduct>(productNames);

                // Pre-Load all the Production Orders
                IEnumerable<string> productionOrderNames = allMaterials
                    .Select(mat => !mat.IsGroupMO() ? mat.ProductionOrder.GetNativeValue<string>("Name") : null)
                    .Where(name => !string.IsNullOrEmpty(name));
                entityCache.FetchAll<IEntityCollection<IProductionOrder>, IProductionOrder>(productionOrderNames);

                // Pre-Load all the Resources
                IEnumerable<string> resourceNames = input.Destinations.Values
                    .Where(name => !string.IsNullOrEmpty(name))
                    .Distinct();
                entityCache.FetchAll<IEntityCollection<IResource>, IResource>(resourceNames);

                #endregion
                Dictionary<string, Dictionary<string, decimal>> calculatedQuantities =
                    _wmsUtilities.CalculateTotalRequestedQuantities(allMaterials, entityCache, loadAttributes: true, loadReleation: true);

                // The input becomes a Dictionary<Material, Dictionary<Product, WMSOrderRequestFields>
                Dictionary<string, Dictionary<string, WMSOrderRequestFields>> materialProductQuantities = _iKEAUtilities.FlipDictionaries(input.ProductMaterialQuantities);

                foreach (KeyValuePair<string, Dictionary<string, WMSOrderRequestFields>> materialPair in materialProductQuantities)
                {
                    IMaterial material = entityCache.Fetch<IMaterial>(materialPair.Key);

                    //if calculatedquantities are null or empty then WMS does not contain any data. No orders were created prior.
                    if (!calculatedQuantities.IsNullOrEmpty())
                    {
                        foreach (KeyValuePair<string, WMSOrderRequestFields> productQuantity in materialPair.Value)
                        {
                            string productionOrderName = material.IsGroupMO(loadAttributes: false)
                                ? material.Name
                                : material.ProductionOrder?.Name;

                            if (calculatedQuantities.ContainsKey(productQuantity.Key)
                                && calculatedQuantities[productQuantity.Key].ContainsKey(productionOrderName))
                            {
                                decimal previousRequestsQuantity = calculatedQuantities[productQuantity.Key][productionOrderName];

                                decimal remainingQuantity = material.PrimaryQuantity.Value - previousRequestsQuantity;

                                if (productQuantity.Value.Quantity > remainingQuantity)
                                {
                                    _iKEAUtilities.LocalizedException(IKEAConstants.CustomWMSCalculatedQuantityCanNotBeLargerThenCalculatedLocalizedMessage,
                                                                        productQuantity.Value.ToString(), remainingQuantity.ToString());
                                }
                            }
                        }
                    }

                    if (material.IsGroupMO(loadAttributes: false) == false)
                    {
                        foreach (KeyValuePair<string, WMSOrderRequestFields> productQuantity in materialPair.Value)
                        {
                            IProduct product = entityCache.Fetch<IProduct>(productQuantity.Key);

                            decimal quantity = productQuantity.Value.Quantity;

                            string resourceName = input.Destinations[product.Name];
                            IResource destination = entityCache.Fetch<IResource>(resourceName);

                            if (material.ProductionOrder != null)
                            {
                                IProductionOrder productionOrder = entityCache.Fetch<IProductionOrder>(material.ProductionOrder.Id);
                                jobInputs.Add(new Common.WMS.WMSAutomationJobInput
                                {
                                    IOType = type,
                                    ItemID = product.Name,
                                    ItemName = product.Description,
                                    ManufacturingOrderName = productionOrder.Name,
                                    Quantity = quantity,
                                    Destination = destination.Name,
                                    Status = _wmsUtilities.GetWMSStatus(productQuantity.Value.Status),
                                    PalletID = productQuantity.Value.PalletId == string.Empty ? null : productQuantity.Value.PalletId,
                                    BatchID = productQuantity.Value.BatchId == string.Empty ? null : productQuantity.Value.BatchId
                                });
                            }
                        }
                    }
                    else
                    {
                        var bomQuantities = _iKEAUtilities.GetAggregateChildMaterialBOMs(material, materialPair.Value, loadRelations: false);

                        // Fetch all the production orders
                        IEnumerable<string> poNames = bomQuantities
                            .Select(pair => pair.Item2.ProductionOrder.GetNativeValue<string>("Name"))
                            .Where(name => !string.IsNullOrEmpty(name));
                        entityCache.FetchAll<IEntityCollection<IProductionOrder>, IProductionOrder>(poNames);

                        foreach (var (product, childMaterial, quantity) in bomQuantities)
                        {
                            WMSOrderRequestFields orderRequestFields = materialPair.Value[product.Name];

                            if (childMaterial.ProductionOrder != null)
                            {
                                string resourceName = input.Destinations[product.Name];
                                IResource destination = entityCache.Fetch<IResource>(resourceName);
                                IProductionOrder productionOrder = entityCache.Fetch<IProductionOrder>(childMaterial.ProductionOrder.Id);
                                jobInputs.Add(new Common.WMS.WMSAutomationJobInput
                                {
                                    IOType = type,
                                    ItemID = product.Name,
                                    ItemName = product.Description,
                                    ManufacturingOrderName = productionOrder.Name,
                                    Quantity = quantity,
                                    Destination = destination.Name,
                                    // Converts string to int 
                                    Status = _wmsUtilities.GetWMSStatus(orderRequestFields.Status),
                                    PalletID = orderRequestFields.PalletId == string.Empty ? null : orderRequestFields.PalletId,
                                    BatchID = orderRequestFields.BatchId == string.Empty ? null : orderRequestFields.BatchId
                                });
                            }
                        }
                    }
                }

                output.FeedbackMessages = new Collection<FeedbackMessage>();
                output.FeedbackMessages.Add(new FeedbackMessage
                {
                    Message = _iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomWMSJobsCreatedLocalizedMessage, jobInputs.Count),
                    MessageType = FeedbackMessageType.Success,
                });

                foreach (var singleInput in jobInputs)
                {
                    output.FeedbackMessages.Add(new FeedbackMessage
                    {
                        Message = _iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomWMSJobFeedPropertiesLocalizedMessage, singleInput.PalletID, singleInput.ItemID, singleInput.Quantity, singleInput.Destination),
                        MessageType = FeedbackMessageType.Success,
                    });
                }

                if (jobInputs.Any())
                {
                    _wmsUtilities.SendOrderAutomationJobInputs(jobInputs);
                }

                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomWMSManualOrderRequestInput", input),
                            new KeyValuePair<String, Object>("CustomWMSManualOrderRequestOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;
        }

        /// <summary>
        /// Custom service to force the completion of a Manufacturing order on lines with Automation Mode Online.
        /// 
        /// ## Pre-requisites:
        ///  - material.Form == Order
        ///  - material.SystemState == InProcess
        ///  - material.CurrentState == INPROCESS
        ///  - material.Attributes[InCompletion] == true
        ///  - material.Attributes[ForceOrderCompletionAllowed] == "Complete"
        ///  - resource.AutomationMode == Online
        /// 
        /// ## Assumptions
        ///  - IoT Reply has valid Numeric field
        /// 
        /// </summary>
        /// <param name="input">Input Object</param>
        /// <returns>Output Object</returns>
        public CustomForceOrderCompletionOutput CustomForceOrderCompletion(CustomForceOrderCompletionInput input)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomForceOrderCompletion",
                 new KeyValuePair<String, Object>("CustomForceOrderCompletionInput", input));

            CustomForceOrderCompletionOutput output = new CustomForceOrderCompletionOutput();

            try
            {
                ForceOrderInput utilityInput = new ForceOrderInput();
                utilityInput.Material = input.Material;
                utilityInput.ServiceComments = input.ServiceComments;
                utilityInput.IgnoreLastServiceId = input.IgnoreLastServiceId;
                utilityInput.IsCompletion = true;

                ForceOrderOutput utilityOutput = _iKEAUtilities.ForceOrderCompletionOrAbort(utilityInput);
                output.Success = utilityOutput.Success;

                // Generate the process loss pallet(s)
                var unitCompleteOutput = CustomUnitComplete(new CustomUnitCompleteInput
                {
                    ProcessOrderMaterial = utilityOutput.Material,
                    CompletedPrimaryQuantity = utilityOutput.ProcessLossUnit,
                    ExcludeTrackout = false,
                    IsProcessLoss = true,
                    CompletedSecondaryQuantity = null,
                    IgnoreOrderMaterialState = true,
                    IsAutomationInvoke = true,
                    UnitAttributes = new AttributeCollection
                {
                    { IKEAConstants.CustomMaterialAttributeProcessLossMotive, IKEAConstants.ForceOrderCompletion }
                },
                });

                // Spreads message stating line condition has changed to trigger refresh
                string messageSubject = String.Format("{0}{1}", IKEAConstants.MessageBusResourceAndMaterialEventsPrefix, utilityOutput.Resource.Id);
                List<string> refreshItems = new List<string>
                {
                    "ResourceState",
                    "ActionButtons"
                };
                _iKEAUtilities.PublishCockpitTransactionalMessages(messageSubject, refreshItems: refreshItems);

                if (utilityOutput.ProcessLossUnit > 0)
                {
                    IAutomationControllerInstance controllerInstance = utilityOutput.Resource.GetAutomationControllerInstance();
                    controllerInstance.Publish(IKEAConstants.AutomationPublishForceOrderCompletionProcessLossTrigger, new
                    {
                        MaterialName = input.Material.Name,
                    });
                }

                output.Material = unitCompleteOutput.ProcessOrderMaterial;
                output.ProcessLossUnit = unitCompleteOutput.CompletedUnit;

                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomForceOrderCompletionInput", input),
                                            new KeyValuePair<String, Object>("CustomForceOrderCompletionOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;
        }

        /// <summary>
        /// Custom service to force the Abortion of a Manufacturing order on lines with Automation Mode Online.
        /// 
        /// ## Pre-requisites:
        ///  - material.Form == Order
        ///  - material.SystemState == InProcess
        ///  - material.CurrentState == INPROCESS
        ///  - material.Attributes[InCompletion] == true
        ///  - material.Attributes[ForceOrderCompletionAllowed] == "Complete"
        ///  - resource.AutomationMode == Online
        /// 
        /// ## Assumptions
        ///  - IoT Reply has valid Numeric field
        /// 
        /// </summary>
        /// <param name="input">Input Object</param>
        /// <returns>Output Object</returns>
        public CustomForceOrderAbortOutput CustomForceOrderAbort(CustomForceOrderAbortInput input)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomForceOrderAbort",
                 new KeyValuePair<String, Object>("CustomForceOrderAbortInput", input));

            CustomForceOrderAbortOutput output = new CustomForceOrderAbortOutput();

            try
            {

                ForceOrderInput utilityInput = new ForceOrderInput();
                utilityInput.Material = input.Material;
                utilityInput.ServiceComments = input.ServiceComments;
                utilityInput.IgnoreLastServiceId = input.IgnoreLastServiceId;
                utilityInput.IsCompletion = false;

                ForceOrderOutput utilityOutput = _iKEAUtilities.ForceOrderCompletionOrAbort(utilityInput);
                output.Success = utilityOutput.Success;

                // Generate the process loss pallet(s)
                var unitCompleteOutput = CustomUnitComplete(new CustomUnitCompleteInput
                {
                    ProcessOrderMaterial = utilityOutput.Material,
                    CompletedPrimaryQuantity = utilityOutput.ProcessLossUnit,
                    ExcludeTrackout = false,
                    IsProcessLoss = true,
                    CompletedSecondaryQuantity = null,
                    IgnoreOrderMaterialState = true,
                    IsAutomationInvoke = true,
                    UnitAttributes = new AttributeCollection
                    {
                        { IKEAConstants.CustomMaterialAttributeProcessLossMotive, IKEAConstants.ForceOrderCompletion }
                    },
                });

                // Spreads message stating line condition has changed to trigger refresh
                string messageSubject = String.Format("{0}{1}", IKEAConstants.MessageBusResourceAndMaterialEventsPrefix, utilityOutput.Resource.Id);
                List<string> refreshItems = new List<string>
                {
                    "ResourceState",
                    "ActionButtons"
                };
                _iKEAUtilities.PublishCockpitTransactionalMessages(messageSubject, refreshItems: refreshItems);

                if (utilityOutput.ProcessLossUnit > 0)
                {
                    IAutomationControllerInstance controllerInstance = utilityOutput.Resource.GetAutomationControllerInstance();
                    controllerInstance.Publish(IKEAConstants.AutomationPublishForceOrderAbortProcessLossTrigger, new
                    {
                        MaterialName = input.Material.Name,
                    });
                }
                output.Material = unitCompleteOutput.ProcessOrderMaterial;
                output.ProcessLossUnit = unitCompleteOutput.CompletedUnit;

                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomForceOrderAbortInput", input),
                                            new KeyValuePair<String, Object>("CustomForceOrderAbortOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;
        }

        /// <summary>
        /// Changes the default completion quantity of a order in process
        /// If automation is online, then the new default completion quantity should be greater than or equal to the
        /// quantity counted in pallet by IoT
        /// </summary>
        /// <param name="input">Input Object</param>
        /// <returns>Output Object</returns>
        public CustomChangeDefaultCompletionQuantityOutput CustomChangeDefaultCompletionQuantity(CustomChangeDefaultCompletionQuantityInput input)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomChangeDefaultCompletionQuantity",
                new KeyValuePair<String, Object>("CustomChangeDefaultCompletionQuantityInput", input));

            CustomChangeDefaultCompletionQuantityOutput output = new CustomChangeDefaultCompletionQuantityOutput();

            try
            {
                Utilities.ValidateNullInput(input);

                IMaterial material = input.Material;

                bool isGroupMO = material.IsGroupMO(loadAttributes: true);

                if (input.DefaultCompletionQuantity < 0)
                {
                    throw _iKEAUtilities.LocalizedException(IKEAConstants.CustomInvalidNegativeDefaultCompletionQuantityLocalizedMessage, "0");
                }

                if (isGroupMO && input.DefaultCompletionQuantity <= 0)
                {
                    throw _iKEAUtilities.LocalizedException(IKEAConstants.CustomInvalidNegativeDefaultCompletionQuantityLocalizedMessage, "1");
                }

                if (material.SystemState != MaterialSystemState.InProcess)
                {
                    throw _iKEAUtilities.LocalizedException(
                        IKEAConstants.CustomChangeDefaultCompletionQuantityInvalidSystemStateLocalizedMessage,
                        MaterialSystemState.InProcess.ToString(),
                        material.SystemState.ToString()
                    );
                }

                if (isGroupMO)
                {
                    // Get the child MOs materials and parts per cycle from the Group:
                    var materialChildMOs = _iKEAUtilities.GetChildMaterialsAndPartsPerCycleFromGroupMO(material, loadAttributes: false);

                    foreach (var materialChild in materialChildMOs)
                    {
                        // Calculate the default completion quantity (number parts per cycle x number cycles):
                        decimal moDefaultCompletionQuantity = materialChild.Value * input.DefaultCompletionQuantity;
                        IMaterial child = materialChild.Key;

                        // Save default completion quantity to child MO:
                        child.Load();
                        child.SaveAttributes(new AttributeCollection()
                        {
                            { IKEAConstants.CustomMaterialAttributeDefaultCompletedQuantity, (moDefaultCompletionQuantity)}
                        });
                    }
                }

                material.SaveAttributes(new AttributeCollection
                {
                    { IKEAConstants.CustomMaterialAttributeDefaultCompletedQuantity, input.DefaultCompletionQuantity }
                });

                // Load the resource the material is in currently
                IResource resource = material.LastProcessedResource;
                resource.Load();

                if (resource.AutomationMode == ResourceAutomationMode.Online)
                {
                    IAutomationControllerInstance controllerInstance = resource.GetAutomationControllerInstance();

                    if (controllerInstance != null)
                    {
                        var eiReply = _genericUtilities.RequestFromIoT<Dictionary<string, object>>(controllerInstance, IKEAConstants.AutomationRequestChangeDefaultCompletionQuantity, new
                        {
                            MaterialName = material.Name,
                            DefaultCompletionQuantity = input.DefaultCompletionQuantity,
                        });

                        object parsedReply = null;
                        eiReply.TryGetValue(IKEAConstants.AutomationRequestReplyField, out parsedReply);

                        // A string or false reply means error reported by IoT
                        if (parsedReply is string || parsedReply as bool? == false)
                        {
                            throw _iKEAUtilities.LocalizedException(IKEAConstants.CustomChangeDefaultCompletionQuantityTooSmallLocalizedMessage);
                        }
                    }
                }

                output.Material = material;

                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomChangeDefaultCompletionQuantityInput", input),
                                            new KeyValuePair<String, Object>("CustomChangeDefaultCompletionQuantityOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;
        }

        /// <summary>
        /// Creates a Move or PutAway request in FactoryAutomation (to then be sent to WMS) for a specific Material
        /// </summary>
        /// <param name="input">Input Object</param>
        /// <returns>Output Object</returns>
        public CustomWMSManualMoveRequestOutput CustomWMSManualMoveRequest(CustomWMSManualMoveRequestInput input)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomWMSManualMoveRequest",
                 new KeyValuePair<string, object>("CustomWMSManualMoveRequestInput", input));

            CustomWMSManualMoveRequestOutput output = new CustomWMSManualMoveRequestOutput();

            try
            {
                Utilities.ValidateNullInput(input, new List<string> {
                    nameof(input.Destination)
                });

                IMaterial material = Utilities.ValidateServiceConditions(
                    input.ServiceComments,
                    input.IgnoreLastServiceId,
                    input.Material
                );

                if (input.OrderType != CustomWMSOrderRequestType.Move && input.OrderType != CustomWMSOrderRequestType.PutAway)
                {
                    throw _iKEAUtilities.LocalizedException(IKEAConstants.CustomWMSInvalidOrderTypeLocalizedMessage,
                        string.Format("{0}, {1}", CustomWMSOrderRequestType.Move.ToString(), CustomWMSOrderRequestType.PutAway.ToString()),
                        input.OrderType.ToString()
                    );
                }

                if (input.OrderType == CustomWMSOrderRequestType.Move && input.Destination == null)
                {
                    throw new ArgumentNullCmfException(nameof(input.Destination));
                }

                List<Common.WMS.WMSAutomationJobInput> jobInputs = _wmsUtilities.CreateWMSManufacturingOrderJobInputs(
                    type: input.OrderType,
                    sourceResource: input.Source,
                    targetResource: input.Destination,
                    operationMaterial: input.Material
                );

                if (jobInputs.IsNullOrEmpty() == false)
                {
                    _wmsUtilities.SendOrderAutomationJobInputs(jobInputs);
                }

                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomWMSManualMoveRequestInput", input),
                                            new KeyValuePair<String, Object>("CustomWMSManualMoveRequestOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;
        }

        /// <summary>
        /// Service to resolve Orderless BOMs that can be used for a particular main line 
        /// Resource/Product combination.
        /// </summary>
        /// <param name="input">Input Object</param>
        /// <returns>Output Object</returns>
        public CustomResolveOrderlessBOMsOutput CustomResolveOrderlessBOMs(CustomResolveOrderlessBOMsInput input)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomResolveOrderlessBOMs",
                 new KeyValuePair<string, object>("CustomResolveOrderlessBOMsInput", input));

            CustomResolveOrderlessBOMsOutput output = new CustomResolveOrderlessBOMsOutput();

            try
            {
                // Validate if the inputs are all set (except the optional BOM). When called with the BOM input,
                // the service will only check if that can be used as an orderless BOM for that Resource & Product,
                // instead of listing all the BOMs that can be used
                Utilities.ValidateNullInput(input, new List<string> {
                    nameof(input.BOM)
                });

                input.Resource.Load();

                // Retrieve a list of WorkCenters associated with this resource
                var workCenters = _iKEAUtilities.GetWorkCentersFromCustomWorkCenterResourceMapping(input.Resource.Name);

                if (workCenters.Any())
                {
                    IFilterCollection filters = new FilterCollection()
                    {
                        new Filter()
                        {
                            Name = "WorkCenter",
                            ObjectName = "BOM",
                            ObjectAlias = "BOM_1",
                            Operator = Cmf.Foundation.Common.FieldOperator.In,
                            Value = workCenters,
                            LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND,
                            FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                        }
                    };

                    // If the input includes a specific BOM, then only search for it and no other BOMs. Improves performance
                    // when we already have a specific BOM and only want to check if it can be used as an Orderless BOM for
                    // this Resource/Product combination
                    if (input.BOM != null)
                    {
                        filters.Add(new Filter()
                        {
                            Name = "Name",
                            ObjectName = "BOM",
                            ObjectAlias = "BOMProduct_SourceEntity_2",
                            Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                            Value = input.BOM.Name,
                            LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND,
                            FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                        });
                    }

                    // Get the BOMs applicable to this Main Line (by looking at the process and sub-process segments
                    // of the SubResources and BOMProducts and matching them) that also respect our custom filters
                    output.BomCollection = _iKEAUtilities.GetOrderlessBOMs(filters);
                }
                else
                {
                    output.BomCollection = _entityFactory.CreateCollection<IBOMCollection>();
                }

                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomResolveOrderlessBOMsInput", input),
                                        new KeyValuePair<String, Object>("CustomResolveOrderlessBOMsOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;
        }

        /// <summary>
        /// Service to create Orderless Production Orders (PO)
        /// </summary>
        /// <param name="input">CustomCreateOrderlessProductionInput</param>
        /// <returns>CustomCreateOrderlessProductionOutput</returns>
        public CustomCreateOrderlessProductionOutput CustomCreateOrderlessProduction(CustomCreateOrderlessProductionInput input)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomCreateOrderlessProduction",
                 new KeyValuePair<string, object>("CustomCreateOrderlessProductionInput", input));

            CustomCreateOrderlessProductionOutput output = new CustomCreateOrderlessProductionOutput();

            try
            {
                Utilities.ValidateNullInput(input);

                #region Validate that Resource has no Regular Orders Dispatched when creating an Orderless

                bool canProcessOrderless = true;

                var inProcessOrders = input.Resource.GetProcessingManufacturingOrders();
                inProcessOrders.LoadAttributes(new Collection<string> { IKEAConstants.CustomMaterialIsOrderlessAttribute });
                foreach (IMaterial material in inProcessOrders)
                {
                    if (!material.GetAttributeValueOrDefault(IKEAConstants.CustomMaterialIsOrderlessAttribute, defaultValue: false))
                    {
                        canProcessOrderless = false;
                        break;
                    }
                }

                if (!canProcessOrderless)
                {
                    throw _iKEAUtilities.LocalizedException(IKEAConstants.CustomCanProcessOrderlessLocalizedMessage, input.Resource.Name);
                }

                #endregion


                IMaterialCollection materialCollection = _entityFactory.CreateCollection<IMaterialCollection>(); ;
                Dictionary<IMaterial, decimal> materialsPartsPerCycle = new Dictionary<IMaterial, decimal>();

                foreach (OrderlessCreation orderlessCreation in input.Orders)
                {
                    //Validate if the BOM is valid
                    CustomResolveOrderlessBOMsInput customResolveOrderlessBOMsInput = new CustomResolveOrderlessBOMsInput();

                    customResolveOrderlessBOMsInput.BOM = orderlessCreation.BOM;
                    customResolveOrderlessBOMsInput.Product = orderlessCreation.Product;
                    customResolveOrderlessBOMsInput.Resource = input.Resource;


                    if (!CustomResolveOrderlessBOMs(customResolveOrderlessBOMsInput).BomCollection.IsNullOrEmpty())
                    {
                        //For each Order received, call CreateSingleOrderless
                        IMaterial currentMaterial = _productionOrderHandlingUtilities.CreateSingleOrderless(input.Resource, orderlessCreation);

                        if (!input.IsGroupOrder)
                        {
                            //Dispatch material
                            _iKEAUtilities.DispatchMaterial(currentMaterial, input.Resource);
                        }

                        materialCollection.Add(currentMaterial);

                        //If it's a Group MO, call service CustomHandleGroupManufacturingOrders in the end
                        if (input.IsGroupOrder)
                        {
                            materialsPartsPerCycle.Add(currentMaterial, orderlessCreation.PartsPerCycle);
                        }

                    }
                    else
                    {
                        throw _iKEAUtilities.LocalizedException(IKEAConstants.CustomCouldntResolveOrderlessBOMs,
                            orderlessCreation.BOM.Name,
                            orderlessCreation.Product.Name,
                            input.Resource.Name
                        );
                    }
                }

                if (input.IsGroupOrder)
                {
                    var groupMO = new CustomHandleGroupManufacturingOrdersInput();
                    groupMO.IsToOptimize = input.IsToOptimize;
                    groupMO.IsHPOEnabled = input.IsToOptimize;
                    groupMO.IsToDispatch = true;
                    groupMO.MaterialPartsPerCycle = materialsPartsPerCycle;
                    groupMO.ResourceToDispatch = input.Resource;

                    output.GroupOrder = CustomHandleGroupManufacturingOrders(groupMO).GroupMaterialOrder;
                }

                output.Orders = materialCollection;

                // Create a collection with the objects
                output.FeedbackMessages = new Collection<FeedbackMessage>()
                {
                    new FeedbackMessage
                    {
                        MessageType = FeedbackMessageType.ObjectsToOpen,
                        Objects = output.GroupOrder != null
                            ? new Collection<object>() { output.GroupOrder }
                            : new Collection<object>(materialCollection.OfType<object>().ToList()),
                    }
                };

                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomCreateOrderlessProductionInput", input),
                                            new KeyValuePair<String, Object>("CustomCreateOrderlessProductionOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            return output;
        }

        /// <summary>
        /// Service to update Orderless Production Orders (PO)
        /// Right now is only used to update Group Orders when they are sent to the HPO, and are returned
        /// with new orders that need a BOM to be selected by the operator.
        /// </summary>
        /// <param name="input">CustomUpdateOrderlessProductionInput</param>
        /// <returns>CustomUpdateOrderlessProductionOutput</returns>
        public CustomUpdateOrderlessProductionOutput CustomUpdateOrderlessProduction(CustomUpdateOrderlessProductionInput input)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomUpdateOrderlessProduction",
                 new KeyValuePair<string, object>("CustomUpdateOrderlessProductionInput", input));

            CustomUpdateOrderlessProductionOutput output = new CustomUpdateOrderlessProductionOutput();

            try
            {
                Utilities.ValidateNullInput(input);

                #region Validate the Group Order conditions

                IMaterial groupOrder = Utilities.ValidateServiceConditions(
                    input.ServiceComments,
                    input.IgnoreLastServiceId,
                    input.GroupOrder
                );

                // Load the required attributes to validate the state of the group order
                groupOrder.LoadAttributes(new Collection<string>
                {
                    IKEAConstants.CustomMaterialIsOrderlessAttribute,
                    IKEAConstants.CustomMaterialAttributeIsGroupMO,
                    IKEAConstants.CustomMaterialAttributeGroupOrderState,
                });

                // Check if the material is Orderless
                if (!groupOrder.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomMaterialIsOrderlessAttribute))
                {
                    throw _iKEAUtilities.LocalizedException(IKEAConstants.CustomCannotUpdateNotOrderlessLocalizedMessage, groupOrder.Name);
                }

                // Check if the material is a Group MO
                if (!groupOrder.IsGroupMO())
                {
                    throw _iKEAUtilities.LocalizedException(IKEAConstants.CustomCannotUpdateOrderlessNotGroupOrderLocalizedMessage, groupOrder.Name);
                }

                // Get the group state from the attributes
                var groupOrderState = groupOrder.GetAttributeValueOrDefault<CustomGroupOrderStateEnum>(IKEAConstants.CustomMaterialAttributeGroupOrderState);

                if (groupOrderState != CustomGroupOrderStateEnum.WaitingForOperator)
                {
                    throw _iKEAUtilities.LocalizedException(IKEAConstants.CustomCannotUpdateGroupOrderInvalidStateLocalizedMessage,
                        groupOrder.Name,
                        CustomGroupOrderStateEnum.WaitingForOperator.ToString(),
                        groupOrderState.ToString()
                    );
                }

                #endregion

                // Get the children orders from this group order
                IMaterialCollection groupChildren = _iKEAUtilities.GetChildMaterialsFromGroupMO(groupOrder, loadAttributes: false);

                // And for each of these child orders, retrieve the associated BOMs from the BOMContext smart table
                // This method only returns if the BOM is associated specifically to this order, looking only at the Material and Step columns
                // It doesn't resolve the BOM using the regular MES methods. All material names from the argument are present in the returned dictionary
                // If a material does not have an associated BOM, then the value of that key in the dictionary is null
                Dictionary<string, IBOM> existingMaterialBOMs = _productionOrderHandlingUtilities.GetAssociatedOrderBOMs(groupChildren);

                // Count how many materials do not have any associated BOM
                int missingBOMsCount = existingMaterialBOMs.Values.Where(bom => bom == null).Count();

                #region Associate the BOMs with the Orders

                Dictionary<IMaterial, IBOM> bomsToUpdate = new Dictionary<IMaterial, IBOM>();

                // Validate that no existing material BOMs are changed
                foreach (var keyValue in input.MaterialBOMs)
                {
                    IMaterial order = keyValue.Key;

                    // Ensure that the order is a child of the Group Order we are updating
                    if (!existingMaterialBOMs.ContainsKey(order.Name))
                    {
                        throw _iKEAUtilities.LocalizedException(IKEAConstants.CustomCannotUpdateOrderlessBOMNotChildOfGroupLocalizedMessage,
                            order.Name,
                            groupOrder.Name
                        );
                    }

                    IBOM existingBOM = existingMaterialBOMs[keyValue.Key.Name];
                    IBOM updatedBOM = keyValue.Value;

                    // Skip any partial updates (i.e. allow not setting the BOM of some materials, state will remain WaitingForOperator
                    if (updatedBOM == null)
                    {
                        continue;
                    }

                    if (existingBOM != null)
                    {
                        // Do not allow to change BOMs already associated with the order
                        if (existingBOM.Name != updatedBOM.Name)
                        {
                            throw _iKEAUtilities.LocalizedException(IKEAConstants.CustomCannotUpdateOrderlessBOMAlreadySetLocalizedMessage,
                                order.Name,
                                updatedBOM.Name,
                                existingBOM.Name
                            );
                        }
                        else
                        {
                            continue;
                        }
                    }

                    bool isBOMValid = CustomResolveOrderlessBOMs(new CustomResolveOrderlessBOMsInput
                    {
                        Resource = input.Resource,
                        Product = order.Product,
                        BOM = updatedBOM,
                    }).BomCollection.Any();

                    if (!isBOMValid)
                    {
                        throw _iKEAUtilities.LocalizedException(IKEAConstants.CustomCouldntResolveOrderlessBOMs,
                            updatedBOM.Name,
                            order.Product.Name,
                            input.Resource.Name
                        );
                    }

                    // Set the BOM to be updated
                    bomsToUpdate[order] = updatedBOM;
                }

                if (bomsToUpdate.Any())
                {
                    _productionOrderHandlingUtilities.AssociateMaterialBOMs(bomsToUpdate);

                    // Load all the production orders from the materials at once
                    IProductionOrderCollection productionOrders = _entityFactory.CreateCollection<IProductionOrderCollection>(); ;
                    productionOrders.LoadByIDs<IProductionOrder, ProductionOrder>(bomsToUpdate.Keys.Select(material => material.GetNativeValue<long>(Cmf.Navigo.Common.Constants.ProductionOrder)).Distinct().ToList());

                    // And create a dictionary to avoid quadratic searches by Id
                    Dictionary<long, IProductionOrder> productionOrdersById = productionOrders.ToDictionary(step => step.Id);

                    Dictionary<string, IProductionOrder> productionOrdersByMaterial = bomsToUpdate.Keys.ToDictionary(
                        material => material.Name,
                        material => productionOrdersById[material.GetNativeValue<long>(Cmf.Navigo.Common.Constants.ProductionOrder)]
                    );

                    // Load the BOMs StructureType attributes
                    IBOMCollection bomCollection = _entityFactory.CreateCollection<IBOMCollection>();
                    bomCollection.AddRange(bomsToUpdate.Values);
                    bomCollection.LoadAttributes(new Collection<string>
                    {
                        IKEAConstants.CustomBOMStructureTypeAttribute
                    });

                    foreach (var keyValue in bomsToUpdate)
                    {
                        // Retrieve the loaded production order associated with this material
                        IProductionOrder productionOrder = productionOrdersByMaterial[keyValue.Key.Name];

                        // Retrieve the structure type from the BOM's attributes
                        string structureType = keyValue.Value.GetAttributeValueOrDefault(IKEAConstants.CustomBOMStructureTypeAttribute, defaultValue: string.Empty);

                        productionOrder.SaveAttributes(new AttributeCollection
                        {
                            { IKEAConstants.CustomProductionOrderAttributeStructureType, structureType }
                        });
                    }
                }

                #endregion

                // Update the state of the group order if all the missing BOMs have been set
                if (missingBOMsCount <= bomsToUpdate.Count)
                {
                    groupOrder.SaveAttributes(new AttributeCollection
                    {
                        { IKEAConstants.CustomMaterialAttributeGroupOrderState, CustomGroupOrderStateEnum.Ready }
                    });

                    // No need to notify the operator here, because this service is
                    // triggered by the operator himself
                    // And also the operator has been notified already when the order
                    // was exported by the HPO
                }

                output.GroupOrder = groupOrder;

                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomUpdateOrderlessProductionInput", input),
                                            new KeyValuePair<String, Object>("CustomUpdateOrderlessProductionOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            return output;
        }

        /// <summary>
        /// Service to receive messaged from NiceLabel
        /// </summary>
        /// <param name="input">CustomNiceLabelMessageInput</param>
        /// <returns>CustomNiceLabelMessageOutput</returns>
        public CustomNiceLabelMessageOutput CustomNiceLabelMessage(CustomNiceLabelMessageInput input)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomNiceLabelMessage",
                new KeyValuePair<string, object>("CustomNiceLabelMessageInput", input));
            CustomNiceLabelMessageOutput output = new CustomNiceLabelMessageOutput();
            try
            {
                Boolean isFlag = true;
                string errorMessage = string.Empty;
                //Load line resource
                IResource lineResource = _entityFactory.Create<IResource>();
                lineResource.Name = input.Workcenter;
                lineResource.Load();

                //Get priting resource
                IResource printingQueueResource = _iKEAUtilities.GetAssociatedPrintingQueueResource(lineResource);

                if (printingQueueResource == null)
                {
                    throw _iKEAUtilities.LocalizedException(IKEAConstants.CustomNoPrintingQueueConfiguredForResourceLocalizedMessage, input.Workcenter);
                }

                string printingSystem = printingQueueResource.GetAttributeValueOrDefault<string>(IKEAConstants.CustomResourcePrintingSystemAttribute, true);

                if (String.IsNullOrEmpty(printingSystem))
                {
                    throw _iKEAUtilities.LocalizedException(IKEAConstants.CustomLabelPrintingErrorParsePrintingSystemCodeLocalizedMessage, printingQueueResource.Name);
                }

                // If the printing system of this Queue is not NiceLabel, disallow calling the service
                if (!printingSystem.Equals(IKEAConstants.NiceLabelSystem))
                {
                    throw _iKEAUtilities.LocalizedException(IKEAConstants.CustomNiceLabelInvalidPrintingQueueSystemLocalizedMessage,
                        printingQueueResource.Name, // Printing Queue Resource Name
                        IKEAConstants.CustomResourcePrintingSystemAttribute, // PrintingSystem Attribute Name
                        printingSystem, // PrintingSystem Attribute actual value
                        IKEAConstants.NiceLabelSystem // PrintingSystem Attribute expected value
                    );
                }
                //Load line material
                IMaterial materialToRetrieve = _entityFactory.Create<IMaterial>();
                IEnumerable<IMaterialResource> materialsInQueueOrdered = new List<IMaterialResource>();
                // Get the materials on the printing queue storage
                IMaterialResourceCollection materialsInPrintingQueue = _iKEAUtilities.GetMaterialsInPrintingQueue(printingQueueResource, sort: false);

                if (materialsInPrintingQueue.Any())
                {
                    materialsInQueueOrdered = materialsInPrintingQueue.OrderBy(rel => rel.CreatedOn).ThenBy(rel => rel.Id);
                }
                else
                {
                    throw _iKEAUtilities.LocalizedException(IKEAConstants.CustomLabelPrintingMissingMaterialInQueueLocalizedMessage, printingQueueResource.Name);
                }

                // Get the materials that are already associated with another Integration Entry
                IMaterialCollection materialsAlreadyTaken = _niceLabelUtilities.GetNiceLabelMaterialAlreadyAssociatedForResource(lineResource);
                IMaterialCollection availableMaterials = _entityFactory.CreateCollection<IMaterialCollection>();
                IMaterialCollection availableMaterialsMO = _entityFactory.CreateCollection<IMaterialCollection>();
                // Remove the materials already associated to another Integration Entry from the list
                // of available materials
                if (materialsAlreadyTaken != null)
                {
                    foreach (IMaterialResource materialResource in materialsInQueueOrdered)
                    {
                        if (materialsAlreadyTaken.Where(mat => mat.Name == materialResource.SourceEntity.Name).ToList().Count == 0)
                        {
                            availableMaterials.Add(materialResource.SourceEntity);
                        }
                    }
                }
                else
                {
                    availableMaterials.AddRange(materialsInQueueOrdered.Select(materialResource => materialResource.SourceEntity));
                }

                IProductionOrder productionOrder = _entityFactory.Create<IProductionOrder>();
                productionOrder.Name = input.MOID;
                productionOrder.Load();
                if (String.IsNullOrEmpty(input.PalletID))
                {
                    //Need to select the material match with production Order from queue to remove 

                    if (productionOrder.ObjectExists())
                    {
                        materialToRetrieve = availableMaterials.Where(material => material.GetNativeValue<long>(Navigo.Common.Constants.ProductionOrder) == productionOrder.Id).FirstOrDefault();
                    }
                }
                else
                {
                    //Check PalletID exists in the system.                  
                    if (materialToRetrieve.ObjectExists(input.PalletID) && productionOrder.ObjectExists())
                    {
                        availableMaterialsMO.AddRange(availableMaterials.Where(material => material.GetNativeValue<long>(Navigo.Common.Constants.ProductionOrder) == productionOrder.Id).ToList());
                        materialToRetrieve.Load(input.PalletID);
                        if (!availableMaterialsMO.Contains(materialToRetrieve))
                        {
                            isFlag = false;
                            errorMessage = _iKEAUtilities.LocalizedException(IKEAConstants.CustomLabelPalletIdErrorforResourceLocalizedMessage, input.PalletID, printingQueueResource.Name, input.MOID).Message;
                        }
                    }
                    else
                    {
                        isFlag = false;
                        errorMessage = _iKEAUtilities.LocalizedException(IKEAConstants.CustomLabelPalletIdErrorLocalizedMessage, input.PalletID).Message;
                    }
                }

                if (materialToRetrieve == null)
                {
                    throw _iKEAUtilities.LocalizedException(IKEAConstants.CustomLabelPrintingMissingMaterialInQueueLocalizedMessage, printingQueueResource.Name);
                }

                // Get the list of executing NiceLabel integration entries (this should only have one IntegrationEntry)
                IIntegrationEntryCollection integrationEntryExecuting = _niceLabelUtilities.GetNiceLabelProcessingIntegrationEntries();
                IIntegrationEntry parentIntegration = null;
                if (!integrationEntryExecuting.IsNullOrEmpty())
                {
                    if (integrationEntryExecuting.Count > 1)
                    {
                        // Get the last Integration Entry on the queue
                        IIntegrationEntryCollection lastIntegratioEntriesOnQueue = _niceLabelUtilities.GetNiceLabelLastIntegrationInQueue(integrationEntryExecuting);
                        parentIntegration = lastIntegratioEntriesOnQueue.FirstOrDefault();
                    }
                    else
                    {
                        parentIntegration = integrationEntryExecuting.FirstOrDefault();
                    }
                }

                IIntegrationEntry integrationEntry = _niceLabelUtilities.CreateNiceLabelIncomingIntegrationEntry(input, parentIntegration, isFlag, errorMessage);
                if (isFlag)
                {
                    DataSet ds = new DataSet();
                    DataTable dt = new DataTable();

                    dt.Columns.Add(IKEAConstants.CustomNiceLabelIntegrationEntriesIntegrationEntryColumn);
                    dt.Columns.Add(IKEAConstants.CustomNiceLabelIntegrationEntriesResourceColumn);
                    dt.Columns.Add(IKEAConstants.CustomNiceLabelIntegrationEntriesMaterialColumn);
                    DataRow row = dt.NewRow();
                    row[IKEAConstants.CustomNiceLabelIntegrationEntriesIntegrationEntryColumn] = integrationEntry.Name;
                    row[IKEAConstants.CustomNiceLabelIntegrationEntriesResourceColumn] = lineResource.Name;
                    row[IKEAConstants.CustomNiceLabelIntegrationEntriesMaterialColumn] = materialToRetrieve.Name;
                    dt.Rows.Add(row);

                    ds.Tables.Add(dt);

                    _iKEAUtilities.InsertOrUpdateRows(IKEAConstants.CustomNiceLabelIntegrationEntries, ds);
                }
                output.MaterialName = materialToRetrieve.Name;
                output.IntegrationEntryName = integrationEntry.Name;

                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomNiceLabelMessageInput", input),
                                        new KeyValuePair<String, Object>("CustomNiceLabelMessageOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            return output;
        }

        /// <summary>
        /// Service to resolve the alternative cycle times
        /// </summary>
        /// <param name="input">CustomResolveAlternativeCyclesTimesInput</param>
        /// <returns>CustomResolveAlternativeCyclesTimesOutput</returns>
        public CustomResolveAlternativeCyclesTimesOutput CustomResolveAlternativeCyclesTimes(CustomResolveAlternativeCyclesTimesInput input)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomResolveAlternativeCyclesTimes",
                 new KeyValuePair<string, object>("CustomResolveAlternativeCyclesTimesInput", input));

            CustomResolveAlternativeCyclesTimesOutput output = new CustomResolveAlternativeCyclesTimesOutput();
            output.Material = input.Material;
            output.Resource = input.Resource;

            try
            {
                // Load the data that comes from the input
                input.Resource.Load();
                input.Material.Load(1);

                if (input.Material.Product.ProductGroup != null)
                {
                    input.Material.Product.ProductGroup.Load();
                }

                // Resolve data from the ResourceIdealCycleTime smart table, also getting what columns are required to filter by
                DataSet resourceIdealCycleTimes = _iKEAUtilities.ResolveResourceIdealCycleTime(input.Material, input.Resource, out IFilterCollection smartTableFilters);

                // If there is no original cycle time, then there is no alternative cycle time either
                if (!resourceIdealCycleTimes.HasData())
                {
                    output.OriginalCycleTime = null;
                    output.AlternativeCycleTime = null;
                    output.RequiresAlternativeCycleTime = false;
                    output.CycleTimeInUse = false;
                }
                else
                {
                    // Get the original cycle time
                    DataRow originalRow = resourceIdealCycleTimes.Tables[0].Rows[0];

                    ResourceAlternativeCycleTime originalCycleTime = new ResourceAlternativeCycleTime
                    {
                        Id = originalRow.Field<long>("ResourceIdealCycleTimeId"),
                        TimeScaleValue = originalRow.Field<string>("TimeScale"),
                        TimePerUnitValue = originalRow.Field<decimal>("TimePerUnit"),
                    };

                    // Get information from AlternativeCycleTimes
                    ResourceAlternativeCycleTime alternativeCycleTimes = null;

                    // We need to clone the filters passed to this method, because otherwise it sometimes mutates the filter's properties. For example,
                    // the filter names sometimes are changed by wrapping them in square brackes, such as "ProductGroup" becoming "[ProductGroup]"
                    DataSet result = TableHelper.GetDataFromSmartTable(IKEAConstants.CustomAlternativeIdealCycleTimesSmartTable, smartTableFilters.Clone());

                    // If there are any alternative cycle times, then at least one is required to match this structure type. If not we must fail the track in
                    bool requiresAlternativeCycleTime = result.HasData();

                    var productionOrder = input.Material.ProductionOrder;

                    string defaultStructureTypeConfig = GeneralUtilities.GetConfigValue<string>(IKEAConstants.DefaultCustomAlternativeIdealCycleTimeStructureTypeConfig);



                    // We can only use alternative cycle times when the material has a production order
                    // Because we need the StructureType attribute in the production order to be able to choose which alternative cycle time
                    bool found = false;
                    if (productionOrder != null)
                    {
                        productionOrder.Load();

                        string expectedStructureType = productionOrder.GetAttributeValueOrDefault<string>(IKEAConstants.CustomProductionOrderAttributeStructureType, loadAttribute: true);
                        // If the production order has a structure type, try to find a match in the list of alternative cycle times
                        if (!string.IsNullOrWhiteSpace(expectedStructureType))
                        {
                            if (result.HasData())
                            {
                                foreach (DataRow dataRow in result.Tables[0].Rows)
                                {
                                    string structureType = dataRow.Field<string>("StructureType");

                                    // When a match is found, we can save it and stop the search
                                    if (structureType == expectedStructureType)
                                    {
                                        long id = dataRow.Field<long>("CustomAlternativeIdealCycleTimesId");
                                        string timeScaleValue = dataRow.Field<string>("AlternativeTimeScale");
                                        decimal timePerUnitValue = dataRow.Field<decimal>("AlternativeTimePerUnit");

                                        alternativeCycleTimes = new ResourceAlternativeCycleTime()
                                        {
                                            Id = id,
                                            TimeScaleValue = timeScaleValue,
                                            TimePerUnitValue = timePerUnitValue
                                        };
                                        //if is found we flag it as true
                                        found = true;
                                        break;
                                    }
                                }
                                //if we didnt find it it will check for default one
                                if (found == false)
                                {
                                    foreach (DataRow dataRow in result.Tables[0].Rows)
                                    {
                                        string structureType = dataRow.Field<string>("StructureType");
                                        //we check if the match is found whit the value from config
                                        if (structureType == defaultStructureTypeConfig)
                                        {
                                            long id = dataRow.Field<long>("CustomAlternativeIdealCycleTimesId");
                                            string timeScaleValue = dataRow.Field<string>("AlternativeTimeScale");
                                            decimal timePerUnitValue = dataRow.Field<decimal>("AlternativeTimePerUnit");

                                            alternativeCycleTimes = new ResourceAlternativeCycleTime()
                                            {
                                                Id = id,
                                                TimeScaleValue = timeScaleValue,
                                                TimePerUnitValue = timePerUnitValue
                                            };
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }

                    var cycleTimeInUse = false;
                    var cycleTimeMaterialsInProcess = new List<string>();

                    if (requiresAlternativeCycleTime)
                    {
                        // Detect if this IdealCycleTime is being used by any InProcess MO in this or in other lines.
                        // If it is, it is not possible to change it
                        DataSet dsInProcess = _iKEAUtilities.ResolveInProcessOrderWithCicleTime(smartTableFilters);

                        cycleTimeInUse = dsInProcess.HasData();

                        if (cycleTimeInUse)
                        {
                            cycleTimeMaterialsInProcess = dsInProcess
                                .Tables[0].Rows.Cast<DataRow>()
                                .Select(row => row.Field<string>("MaterialName"))
                                .ToList();
                        }
                    }

                    //Add information to return object
                    output.OriginalCycleTime = originalCycleTime;
                    output.AlternativeCycleTime = alternativeCycleTimes;
                    output.RequiresAlternativeCycleTime = requiresAlternativeCycleTime;
                    output.CycleTimeInUse = cycleTimeInUse;
                    output.CycleTimeMaterialsInProcess = cycleTimeMaterialsInProcess;
                }

                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomResolveAlternativeCyclesTimesInput", input),
                                        new KeyValuePair<String, Object>("CustomResolveAlternativeCyclesTimesOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;
        }

        /// <summary>
        /// Service to reload the pending trackout queues on IoT after some partial trackout fails
        /// </summary>
        /// <param name="input">CustomReloadPendingTrackOutsInput</param>
        /// <returns>CustomReloadPendingTrackOutsOutput</returns>
        public CustomReloadPendingTrackOutsOutput CustomReloadPendingTrackOuts(CustomReloadPendingTrackOutsInput input)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomReloadPendingTrackOuts",
                 new KeyValuePair<string, object>("CustomReloadPendingTrackOutsInput", input));

            CustomReloadPendingTrackOutsOutput output = new CustomReloadPendingTrackOutsOutput();

            try
            {
                var resource = input.LineResource;

                // Load the Resource Entity
                resource.Load();

                if (resource.AutomationMode == ResourceAutomationMode.Online)
                {
                    IAutomationControllerInstance controllerInstance = resource.GetAutomationControllerInstance();

                    IMaterial material = _entityFactory.Create<IMaterial>();

                    if (!input.SelectedMaterial.IsNullOrEmpty())
                    {
                        material.Name = input.SelectedMaterial;
                        material.Load();
                    }
                    // In case input.SelectedMaterial IsNullOrEmpty or it is not but previous material.Load failed, material.Id is 0
                    if (material.Id == 0)
                    {
                        material = _iKEAUtilities.GetMaterialsFromResourceByState(resource.Id, loadMaterials: true, MaterialSystemState.InProcess)
                                .OrderBy(mo => mo.Value)
                                .Select(mo => mo.Key)
                                .FirstOrDefault();

                        if (material == null)
                        {
                            throw _iKEAUtilities.LocalizedException(IKEAConstants.CustomResourceNoMaterialsInProcessLocalizedMessage,
                                resource.Name
                            );
                        }
                    }

                    // Get the Attribute
                    var errorHandleEnabled = resource.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomResourcePalletizeErrorHandleEnabledAttribute, loadAttribute: true);

                    if (!errorHandleEnabled)
                    {
                        throw _iKEAUtilities.LocalizedException(IKEAConstants.CustomResourcePalletizeErrorHandleEnabledAttributeNotFoundLocalizedMessage);
                    }

                    resource.SaveAttributes(new AttributeCollection
                    {
                        { IKEAConstants.CustomResourcePalletizeErrorHandleEnabledAttribute, false }
                    });

                    if (controllerInstance != null)
                    {
                        var eiReply = _genericUtilities.RequestFromIoT<Dictionary<string, object>>(controllerInstance, IKEAConstants.AutomationRequestReloadPendingTrackOuts, new
                        {
                            Resource = resource.Name,
                            Material = material.Name,
                        });

                        eiReply.TryGetValue(IKEAConstants.AutomationRequestReplyField, out object parsedReply);

                        // A string or false reply means error reported by IoT
                        if (parsedReply is string || parsedReply as bool? == false)
                        {
                            throw _iKEAUtilities.LocalizedException(IKEAConstants.CustomReloadPendingTrackOutsIotErrorLocalizedMessage);
                        }
                        else
                        {
                            output.LineResource = resource;
                        }

                    }
                }

                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomReloadPendingTrackOutsInput", input),
                                            new KeyValuePair<String, Object>("CustomReloadPendingTrackOutsOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;
        }

        /// <summary>
        /// Service to get the recipe overwritten values
        /// </summary>
        /// <param name="input">CustomRecipeOverwrittenValuesInput</param>
        /// <returns>CustomRecipeOverwrittenValuesOutput</returns>
        public CustomRecipeOverwrittenValuesOutput CustomRecipeOverwrittenValues(CustomRecipeOverwrittenValuesInput input)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomRecipeOverwrittenValues",
                 new KeyValuePair<string, object>("CustomRecipeOverwrittenValuesInput", input));

            CustomRecipeOverwrittenValuesOutput output = new CustomRecipeOverwrittenValuesOutput();
            try
            {
                output.Recipe = input.Recipe;
                output.RecipeParameters = _iKEAUtilities.GetRecipeParametersCollection(input.Recipe, input.Material);

                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomRecipeOverwrittenValuesInput", input),
                                        new KeyValuePair<String, Object>("CustomRecipeOverwrittenValuesOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;
        }

        /// <summary>
        /// Resolves the BOM for the Material and Resource, and creates a list of which BOM Products accept alternative resources to be used for them.
        /// </summary>
        /// <param name="input">CustomResolveAlternativeSubResourcesInput</param>
        /// <returns>CustomResolveAlternativeSubResourcesOutput</returns>
        public CustomResolveAlternativeSubResourcesOutput CustomResolveAlternativeSubResources(CustomResolveAlternativeSubResourcesInput input)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomResolveAlternativeSubResources",
                 new KeyValuePair<string, object>("CustomResolveAlternativeSubResourcesInput", input));

            CustomResolveAlternativeSubResourcesOutput output = new CustomResolveAlternativeSubResourcesOutput();

            try
            {
                // Create the variables to be returned in the output
                var originalResources = new Dictionary<IBOMProduct, IResource>();
                var alternativeResources = new Dictionary<IResource, IResourceCollection>();
                IBOMCollection bomCollection = _entityFactory.CreateCollection<IBOMCollection>();
                IBOM bom = null;

                // Validate the material passed in from the input
                var material = Utilities.ValidateServiceConditions(input.ServiceComments, input.IgnoreLastServiceId, input.Material);

                // Get Order Form
                string orderForm = _iKEAUtilities.GetOrderMaterialForm();

                if (!material.Form.CompareStrings(orderForm))
                {
                    throw _iKEAUtilities.LocalizedException(IKEAConstants.CustomResolveAlternativeSubResourcesInvalidMaterialFormMessage,
                        material.Name,
                        orderForm,
                        material.Form
                    );
                }

                if (material.SystemState != MaterialSystemState.Dispatched)
                {
                    throw _iKEAUtilities.LocalizedException(IKEAConstants.CustomResolveAlternativeSubResourcesInvalidMaterialFormMessage,
                        material.Name,
                        MaterialSystemState.Dispatched.ToString(),
                        material.SystemState.ToString()
                    );
                }

                // TODO Validate the material is not Orderless (uses shared BOMs)

                // Get materials to process, multiple if it's groupMO
                material.Load();
                List<IMaterial> materialsToIterate = new List<IMaterial>();

                if (material.IsGroupMO())
                {
                    // Get MOs from GroupMO Relation
                    materialsToIterate = _iKEAUtilities.GetChildMaterialsFromGroupMO(material).ToList();
                }
                else
                {
                    materialsToIterate.Add(material);
                }

                // Multiple only in GroupMO case
                foreach (IMaterial materialIteration in materialsToIterate)
                {
                    // Resolve the BOM to be used for this Manufacturing Order and this Resource
                    IResolveBomContextsResult result = materialIteration.Product.ResolveBomContexts(materialIteration);

                    if (result.Bom != null && result.Bom.UniversalState != UniversalState.Terminated)
                    {
                        bom = result.Bom;
                        // Load the relations with LevelsToLoad as 1 so we can show information in the GUI about each BOMProduct,
                        // such as the product name or the consumption's step name, if needed
                        bom.LoadRelations(Navigo.Common.Constants.BOMProduct, levelsToLoad: 1);
                        // Load the attributes required to match these BOMProducts with the Consumable Feeds
                        bom.BomProducts.LoadAttributes(new Collection<string>
                        {
                            IKEAConstants.BomProductProcessSegmentAttribute,
                            IKEAConstants.BomProductSubProcessSegmentAttribute,
                        });

                        // Get the reference to the main line resource
                        var mainLine = materialIteration.GetProcessResource(loadRelations: true);
                        mainLine.Load();

                        // Load all the consumable feed resources from the Main Line
                        var consumableFeeds = _wmsUtilities.GetMainLineFeeders(mainLine);
                        consumableFeeds.LoadAttributes(new Collection<string>
                        {
                            IKEAConstants.ProcessSegmentSequence,
                            IKEAConstants.SubProcessSegmentName,
                        });

                        foreach (IBOMProduct bomProduct in result.Bom.BomProducts)
                        {
                            string productProcessSegment = bomProduct.GetAttributeValueOrDefault<string>(IKEAConstants.BomProductProcessSegmentAttribute);
                            string productSubProcessSegment = bomProduct.GetAttributeValueOrDefault<string>(IKEAConstants.BomProductSubProcessSegmentAttribute);

                            // Find a consumable feeder with the same Process Segments as this BOMProduct
                            var originalFeeder = consumableFeeds.FirstOrDefault(resource =>
                            {
                                return resource.GetAttributeValueOrDefault<string>(IKEAConstants.ProcessSegmentSequence) == productProcessSegment
                                    && resource.GetAttributeValueOrDefault<string>(IKEAConstants.SubProcessSegmentName) == productSubProcessSegment;
                            });

                            // If a match is found, save it in the original's dictionary
                            if (originalFeeder != null)
                            {
                                originalFeeder.LoadAttribute(IKEAConstants.CustomResourceAttributeFeederConsumptionMode);
                                originalResources[bomProduct] = originalFeeder;
                            }
                        }

                        if (originalResources.Any())
                        {
                            alternativeResources = _iKEAUtilities.GetAlternativeSubResources(originalResources.Values, loadResources: true);
                        }

                        foreach (ResourceCollection resources in alternativeResources.Values)
                        {
                            resources.LoadAttributes(new Collection<string>() { IKEAConstants.CustomResourceAttributeFeederConsumptionMode });
                        }

                        // Add bom to collection
                        bomCollection.Add(bom);
                    }

                }

                // Save the output variables
                output.OriginalResources = originalResources;
                output.AlternativeResources = alternativeResources;
                output.BOMCollection = bomCollection;

                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomResolveAlternativeSubResourcesInput", input),
                                        new KeyValuePair<String, Object>("CustomResolveAlternativeSubResourcesOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;
        }


        /// <summary>
        /// Service to get the quantities 
        /// </summary>
        /// <param name="input">CustomResolveWMSQuantityInput</param>
        /// <returns>CustomResolveWMSQuantityOutput</returns>
        public CustomResolveWMSQuantityOutput CustomResolveWMSQuantity(CustomResolveWMSQuantityInput input)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomResolveWMSQuantity",
                 new KeyValuePair<string, object>("CustomResolveWMSQuantityInput", input));

            CustomResolveWMSQuantityOutput output = new CustomResolveWMSQuantityOutput();

            try
            {
                Utilities.ValidateNullInput(input);

                IMaterialCollection allMaterials = _entityFactory.CreateCollection<IMaterialCollection>(); ;

                foreach (string materialName in input.MaterialNames)
                {
                    var material = _entityFactory.Create<IMaterial>();
                    material.Name = materialName;
                    allMaterials.Add(material);
                }

                allMaterials.Load();


                var entityCache = new EntityCache();

                allMaterials.LoadAttributes(new Collection<string> { IKEAConstants.CustomMaterialAttributeIsGroupMO });

                // If there is any material that is a GroupMO, load the child relations

                if (allMaterials.Any(material => material.IsGroupMO(loadAttributes: false)))
                {
                    allMaterials.LoadRelations(IKEAConstants.CustomGroupMaterialManufacturingOrder, 1);
                }

                output.ProductQuantityPerProductionOrderPerProductName = _wmsUtilities.CalculateTotalRequestedQuantities(allMaterials, entityCache, loadAttributes: false, loadReleation: false);

                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomResolveWMSQuantityInput", input),
                                        new KeyValuePair<String, Object>("CustomResolveWMSQuantityOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;
        }

        /// <summary>
        /// Service to request ERP for an Ad-Hoc Production Order (for type Rework or Repair)
        /// </summary>
        /// <param name="input">Input object CustomERPRequestOrderInput</param>
        /// <returns>CustomERPRequestOrderOutput</returns>
        /// <exception cref="CmfBaseException"></exception>
        public CustomERPRequestOrderOutput CustomERPRequestOrder(CustomERPRequestOrderInput input)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomERPRequestOrder",
                 new KeyValuePair<string, object>("CustomERPRequestOrderInput", input));

            CustomERPRequestOrderOutput output = new CustomERPRequestOrderOutput();
            try
            {
                // Get the configurations for the request production order:
                string status = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.ERPRequestOrderStatusConfig);
                string responsible = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.ErpResponsibleConfig);

                // Resolve Order Type by Generic Table
                string orderType = String.Empty;

                IProduct product = _entityFactory.Create<IProduct>();
                product.Name = input.Product.Name;
                product.Load();
                string baseProductName = String.Empty;
                if (product.HasRelatedAttribute(IKEAConstants.CustomProductAttributeBaseProduct, true)
                    && !String.IsNullOrWhiteSpace(product.RelatedAttributes[IKEAConstants.CustomProductAttributeBaseProduct].ToString()))
                {
                    baseProductName = product.RelatedAttributes[IKEAConstants.CustomProductAttributeBaseProduct].ToString();
                }
                else
                {
                    baseProductName = input.Product.Name;
                }

                ISmartTable test = new SmartTable();
                test.Load(IKEAConstants.CustomERPOrderTypeStructureTypeMapping);

                //Create NgpDataRow with the configuration to be tested against the SmartTable
                INgpDataRow values = new NgpDataRow();
                values.Add(IKEAConstants.CustomERPOrderTypeStructureTypeMappingProductColumn, product.Name);
                values.Add(IKEAConstants.CustomERPOrderTypeStructureTypeMappingResourceColumn, input.Resource.Name);
                values.Add(IKEAConstants.CustomERPOrderTypeStructureTypeMappingStructureTypeColumn, input.StructureType);

                //Resolve the smartTable 
                INgpDataSet nds = test.Resolve(values, false);

                if (nds != null)
                {
                    //If the configuration was successfully found on the SmartTable
                    DataSet ds = NgpDataSet.ToDataSet(nds);
                    if (ds.HasData())
                    {
                        DataRow row = ds.Tables[0].Rows[0];
                        if (!row.IsNull(IKEAConstants.CustomERPOrderTypeStructureTypeMappingOrderTypeColumn))
                        {
                            orderType = row[IKEAConstants.CustomERPOrderTypeStructureTypeMappingOrderTypeColumn].ToString();
                        }
                    }
                }
                if (string.IsNullOrEmpty(orderType))
                {
                    throw _iKEAUtilities.LocalizedException(IKEAConstants.CustomNoDataRetrievedSmartTableParametersLocalizedMessage,
                            IKEAConstants.CustomERPOrderTypeStructureTypeMapping, string.Join(", ", new List<string> { product.Name, input.Resource.Name, input.StructureType }));
                }
                input.Resource.Load();
                input.Resource.Area.Load();

                IFacility facility = input.Resource.Area.Facility;
                string facilityERPIdentifier = facility.GetAttributeValueOrDefault<string>(IKEAConstants.CustomFacilityAttributeERPIdentifier, true);

                //The company field is filled by calling the parent constructor
                NewProductionOrderRequest request = new NewProductionOrderRequest()
                {
                    Facility = facilityERPIdentifier,
                    ProductNumber = baseProductName,
                    ProductStructureType = input.StructureType,
                    OrderedQuantityAlt = input.Quantity.ToString(),
                    Status = status,
                    FinishDate = DateTime.Now.Date.ToString("yyyyMMdd"),
                    OrderType = orderType,
                    ProductionLine = input.Resource.Name,
                    Responsible = responsible,
                    ScheduleNumber = input.ScheduleNumber,
                    AlternateUnits = product.DefaultUnits
                };

                string requestEndpoint = IKEAConstants.ERPRequestProductionOrder;

                string jsonMessage = JsonConvert.SerializeObject(request);

                NewProductionOrderRequestCommunication communication = new NewProductionOrderRequestCommunication()
                {
                    API = requestEndpoint,
                    Message = jsonMessage
                };

                XmlDocument xmlDoc = communication.SerializeToXMLDocument();

                output.ServiceOutput = _iKEAUtilities.CreateIntegrationEntry(IKEAConstants.MESSystem, IKEAConstants.ERPSystem, IKEAConstants.ERPRequestProductionOrderMessageType, IKEAConstants.ERPRequestProductionOrderEventName, xmlDoc);

                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomERPRequestOrderInput", input),
                                        new KeyValuePair<String, Object>("CustomERPRequestOrderOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;
        }





        /// <summary>
        /// Returns the CustomWMSMaterialTracker collection to be displayed in the GUI 'Warehouse Order Requests', for each IOType:
        ///   - FEED: material moved from the wharehouse into the production line
        ///   - MOVE: material moved from a production line, any of its feeder(s) or main stocking point, into another production line, any of its feeder(s) or stocking point
        ///   - PUTAWAY: material moved from the production line, any of its feeder(s) or stocking point, into the wharehouse
        /// </summary>
        /// <param name="input">CustomWMSListGroupedMaterialTrackersInput</param>
        /// <returns>CustomWMSListGroupedMaterialTrackersOutput</returns>
        public CustomWMSListGroupedMaterialTrackersOutput CustomWMSListGroupedMaterialTrackers(CustomWMSListGroupedMaterialTrackersInput input)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomWMSListGroupedMaterialTrackers",
                 new KeyValuePair<string, object>("CustomWMSListGroupedMaterialTrackersInput", input));
            CustomWMSListGroupedMaterialTrackersOutput output = new CustomWMSListGroupedMaterialTrackersOutput();
            Utilities.ValidateNullInput(input, new List<string> { "ManufacturingOrderFilter",
                                                                  "DestinationResourceFilter",
                                                                  "ProductFilter",
                                                                  "StartDateFilter",
                                                                  "EndDateFilter" });

            try
            {
                // Create the filter collection:
                //    - OrderRequestType (included for any IO type): to filter the type of IO (Feed, Move or PutAway)
                //    - CreatedOn (included for any IO type): date from which IOs will be filtered; comes from input
                //    - SourceStockingPoint (will vary according to IO type):
                //          + FEED: null (material is being moved from Warehouse to current Resource)
                //          + PUTAWAY and MOVE: it can be selected Main Line, any of its feeders or stocking point
                //    - DestinationStockingPoint: will vary according to type of IO
                //          + FEED: any feeder destination of MainLine
                //          + PUTAWAY: null (material is being moved from current Resource to Warehouse)
                //          + MOVE: no filter is added in this case, as material can be moved to any resource
                IFilterCollection filters = new FilterCollection()
                {
                    // Filters OrderRequestType and CreatedOn
                    new Filter()
                    {
                        Name = "OrderRequestType",
                        ObjectName = "CustomWMSMaterialTracker",
                        ObjectAlias = "CustomWMSMaterialTracker_1",
                        Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                        Value = input.IOType,
                        LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND,
                        FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                    },
                    new Filter()
                    {
                        Name = "CreatedOn",
                        ObjectName = "CustomWMSMaterialTracker",
                        ObjectAlias = "CustomWMSMaterialTracker_1",
                        Operator = Cmf.Foundation.Common.FieldOperator.GreaterThan,
                        Value = input.StartDateFilter,
                        LogicalOperator = Cmf.Foundation.Common.LogicalOperator.Nothing,
                        FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                    }
                };

                // Get all possible feed destinations for resource from input (MainLine):
                //    + MainLine's Main Stocking Point
                //    + MainLine's Feeders
                //    + Feeders associated with MainLine, as defined in the Smart Table "CustomConsumableFeedsDirectDelivery"
                FeedDestinations feedDestinations = new FeedDestinations(input.MainLine);
                feedDestinations.Load();

                // Get MainLine's Main Stocking Point, Feeders, and related feeders from "CustomConsumableFeedsDirectDelivery"
                IResourceCollection feedDestinationResources = _entityFactory.CreateCollection<IResourceCollection>();

                if (feedDestinations.FeederResources != null && feedDestinations.FeederResources.Any())
                {
                    feedDestinationResources.AddRange(feedDestinations.FeederResources);
                }
                if (feedDestinations.DirectStorageResources != null && feedDestinations.DirectStorageResources.Any())
                {
                    feedDestinationResources.AddRange(feedDestinations.DirectStorageResources);
                }
                if (feedDestinations.MainStockingPoint != null)
                {
                    feedDestinationResources.Add(feedDestinations.MainStockingPoint);
                }

                // Filter DestinationStockingPoint (Move will not have this filter)
                IFilter destinationStockingPointFilter = new Filter()
                {
                    Name = "DestinationStockingPoint",
                    ObjectName = "CustomWMSMaterialTracker",
                    ObjectAlias = "CustomWMSMaterialTracker_1",
                    LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND,
                    FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                };

                if (input.DestinationResourceFilter != null)
                {
                    destinationStockingPointFilter.Operator = FieldOperator.In;
                    destinationStockingPointFilter.Value = input.DestinationResourceFilter.Name;

                    filters.Add(destinationStockingPointFilter);
                }
                else if (input.IOType.Equals(CustomWMSOrderRequestType.Feed))
                {
                    destinationStockingPointFilter.Operator = Cmf.Foundation.Common.FieldOperator.In;
                    destinationStockingPointFilter.Value = feedDestinationResources.Select(res => res.Name).ToList();

                    filters.Add(destinationStockingPointFilter);
                }
                else if (input.IOType.Equals(CustomWMSOrderRequestType.PutAway))
                {
                    destinationStockingPointFilter.Operator = Cmf.Foundation.Common.FieldOperator.IsNull;
                    destinationStockingPointFilter.Value = string.Empty;

                    filters.Add(destinationStockingPointFilter);
                }

                // Filter SourceStockingPoint
                IFilter sourceStockingPointFilter = new Filter()
                {
                    Name = "SourceStockingPoint",
                    ObjectName = "CustomWMSMaterialTracker",
                    ObjectAlias = "CustomWMSMaterialTracker_1",
                    LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND,
                    FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                };

                if (input.IOType.Equals(CustomWMSOrderRequestType.Feed))
                {
                    sourceStockingPointFilter.Operator = Cmf.Foundation.Common.FieldOperator.IsNull;
                    sourceStockingPointFilter.Value = string.Empty;

                    filters.Add(sourceStockingPointFilter);
                }
                else
                {
                    // For Move and PutAway
                    // Add MainLine to all its related feed destinations
                    IResourceCollection mainLineAndRelatedFeeders = feedDestinationResources;
                    mainLineAndRelatedFeeders.Add(input.MainLine);

                    sourceStockingPointFilter.Operator = Cmf.Foundation.Common.FieldOperator.In;
                    sourceStockingPointFilter.Value = mainLineAndRelatedFeeders.Select(res => res.Name).ToList();

                    filters.Add(sourceStockingPointFilter);
                }

                if (input.ManufacturingOrderFilter != null)
                {
                    filters.Add(new Filter()
                    {
                        Name = "ManufacturingOrder",
                        ObjectName = "CustomWMSMaterialTracker",
                        ObjectAlias = "CustomWMSMaterialTracker_1",
                        Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                        Value = input.ManufacturingOrderFilter.Name,
                        LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND,
                        FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                    });
                }
                if (input.ProductFilter != null)
                {
                    filters.Add(new Filter()
                    {
                        Name = "ProductName",
                        ObjectName = "CustomWMSMaterialTracker",
                        ObjectAlias = "CustomWMSMaterialTracker_1",
                        Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                        Value = input.ProductFilter.Name,
                        LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND,
                        FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                    });
                }
                if (input.EndDateFilter != null)
                {
                    filters.Add(new Filter()
                    {
                        Name = "CreatedOn",
                        ObjectName = "CustomWMSMaterialTracker",
                        ObjectAlias = "CustomWMSMaterialTracker_1",
                        Operator = Cmf.Foundation.Common.FieldOperator.LessThan,
                        Value = input.EndDateFilter.Value,
                        LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND,
                        FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                    });
                }

                // Filtered CustomWMSMaterialTracker collection
                ICustomWMSMaterialTrackerCollection customWMSMaterialTrackers = _wmsUtilities.GetCustomWMSMaterialTrackers(filters, includeTerminated: true);
                customWMSMaterialTrackers.LoadAttributes(new Collection<string>
                {
                    IKEAConstants.WMSBatchIDAttributeName,
                    IKEAConstants.WMSStatusAttributeName,
                });
                List<GroupedInventoryOrders> groupedOrders = new List<GroupedInventoryOrders>();

                // Group Inventory Orders by (combo box 'Group By'):
                //    - Product: group IOs by product name
                //    - Resource: group IOs by destination resource name
                //    - Manufacturing Orders: group IOs by production order name
                EntityCache entityCache = new EntityCache();
                if (customWMSMaterialTrackers != null)
                {
                    // Pre-fetch all entities (Materials, Products, Resources)
                    entityCache.FetchAll<IEntityCollection<IMaterial>, IMaterial>(customWMSMaterialTrackers.Where(tracker => !tracker.ManufacturingOrder.IsNullOrEmpty()).Select(x => x.ManufacturingOrder));
                    entityCache.FetchAll<IEntityCollection<IResource>, IResource>(customWMSMaterialTrackers.Where(tracker => !tracker.DestinationStockingPoint.IsNullOrEmpty()).Select(tracker => tracker.DestinationStockingPoint));
                    entityCache.FetchAll<IEntityCollection<IProduct>, IProduct>(customWMSMaterialTrackers.Where(tracker => !tracker.ProductName.IsNullOrEmpty()).Select(tracker => tracker.ProductName));

                    groupedOrders = customWMSMaterialTrackers
                        .OrderByDescending(tracker => tracker.CreatedOn)
                        .GroupBy(tracker => (
                            input.ManufacturingOrderGrouping ? tracker.ManufacturingOrder : null,
                            input.DestinationResourceGrouping ? tracker.DestinationStockingPoint : null, // n�o est� muito claro na GUI, q s� diz 'Resources'
                            input.ProductGrouping ? tracker.ProductName : null))
                        .Select(group => new GroupedInventoryOrders(
                            entityCache.TryFetch<IMaterial>(group.Key.Item1),
                            entityCache.TryFetch<IResource>(group.Key.Item2),
                            entityCache.TryFetch<IProduct>(group.Key.Item3),
                            group
                        )).ToList();
                }

                output.GroupedInventoryOrders = groupedOrders;

                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomWMSListGroupedMaterialTrackersInput", input),
                                        new KeyValuePair<String, Object>("CustomWMSListGroupedMaterialTrackersOutput", output));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;
        }

        /// <summary>
        /// Service to get the chart context from material or resource
        /// </summary>
        /// <param name="input">CustomGetChartContextFromChartContextTranslatorInput</param>
        /// <returns>CustomGetChartContextFromChartContextTranslatorOutput</returns>
        public CustomGetChartContextFromChartContextTranslatorOutput CustomGetChartContextFromChartContextTranslator(CustomGetChartContextFromChartContextTranslatorInput input)
        {
            if (input.Resource == null && input.Material == null)
            {
                throw new CmfBaseException("Both resource and material are null");
            }

            CustomGetChartContextFromChartContextTranslatorOutput output = new CustomGetChartContextFromChartContextTranslatorOutput();

            try
            {
                output.ChartContext = new Dictionary<string, object>();
                IChart targetChart = _entityFactory.Create<IChart>();
                targetChart.Name = input.ChartName;
                targetChart.Load();
                targetChart.LoadContextInformation();
                IFilterCollection filterCollection = new FilterCollection();
                if (targetChart.ContextInformation.Count > 0)
                {
                    List<string> contextKeyList
                        = targetChart.ContextInformation.Select(contextInfo => contextInfo.Name).ToList();
                    filterCollection.Add(new Filter
                    {
                        LogicalOperator = LogicalOperator.Nothing,
                        Name = "ChartContextName",
                        Operator = FieldOperator.In,
                        Value = contextKeyList
                    });
                }

                DataSet result = TableHelper.GetDataFromGenericTable(IKEAConstants.CustomChartContextTranslator, filterCollection);

                if (result != null
                    && result.Tables.Count > 0
                    && result.Tables[0].HasData())
                {
                    foreach (DataRow row in result.Tables[0].Rows)
                    {
                        string ruleName = row["ContextRule"].ToString();
                        string contextName = row["ChartContextName"].ToString();

                        IRule rule = _entityFactory.Create<IRule>();
                        rule.Load(ruleName);
                        Cmf.Foundation.Common.Abstractions.IAction deeAction = new Cmf.Foundation.Common.DynamicExecutionEngine.Action
                        {
                            Name = rule.DEERule
                        };

                        deeAction.Load();
                        Dictionary<string, Object> deeInput = new Dictionary<string, object>();
                        deeInput["Resource"] = input.Resource;
                        deeInput["Material"] = input.Material;
                        Dictionary<string, object> actionresult = deeAction.ExecuteAction(deeInput);

                        if (actionresult.ContainsKey("Result") && actionresult["Result"] != null)
                        {
                            output.ChartContext.Add(contextName, actionresult["Result"]);
                        }
                    }
                }
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;
        }


        /// <summary>
        /// Service to get the first scanned material in storage resource defined in the attribute LabelStorageResource on the mainFeeder provided
        /// After that, attach the same material to the mainFeeder
        /// </summary>
        /// <param name="input">MaterialLabelStorageInput</param>
        /// <returns>MaterialLabelStorageOutput</returns>
        public MaterialLabelStorageOutput MaterialLabelStorage(MaterialLabelStorageInput input)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "MaterialLabelStorage", new KeyValuePair<String, Object>("MaterialLabelStorageInput", input));

            MaterialLabelStorageOutput output = new MaterialLabelStorageOutput();

            try
            {
                #region Validate and load resources

                // Validates input and its properties
                Utilities.ValidateNullInput(input);

                // load main resource
                string resourceName = input.MainFeeder;
                IResource mainFedder = _entityFactory.Create<IResource>();
                mainFedder.Name = resourceName;
                mainFedder.Load();

                // Get storage resource from attribute
                string labelStorageResourceName = mainFedder.GetAttributeValueOrDefault<string>(attributeName: IKEAConstants.CustomLabelStorageResourceAttribute,
                                                        loadAttribute: true);

                // Check if string is valid
                if (labelStorageResourceName.IsNullOrEmpty())
                {
                    throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomStorageResourceDoesNotExistLocalizedMessage, labelStorageResourceName));
                }

                // Gets storage resource
                IResource storageResource = _entityFactory.Create<IResource>();
                storageResource.Name = labelStorageResourceName;

                // Check if value in attribute is valid
                if (!storageResource.ObjectExists())
                {
                    throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomStorageResourceDoesNotExistLocalizedMessage, labelStorageResourceName));
                }
                storageResource.Load();
                #endregion

                // Get main resource name
                string mainResourceName = mainFedder.GetTopMostResource().Name;

                // It should have at least one material stored, if not then throw error
                // If it does not have a MaterialResource relation, then no materials are stored
                if (!storageResource.HasRelations(Navigo.Common.Constants.MaterialResource, loadRelation: true) || storageResource.RelationCollection.IsNullOrEmpty())
                {

                    // Get employees checked-in on main resource in order to send them a notification
                    IEmployeeCollection employees = _genericUtilities.GetCheckedInEmployees(mainResourceName);

                    // Get details to send in notification
                    string title = _iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomStorageResourceNoMaterials, labelStorageResourceName);
                    string details = _iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomStorageResourceNoMaterialsNotificationDetails, labelStorageResourceName);

                    // Send notification to all employees checked in
                    _iKEAUtilities.GenerateNotificationToEmployees(title, details, employees, resource: storageResource, sendEmail: true);
                }
                else
                {
                    // Gets MaterialResource relations of storage resource in order to get all materials stored in resource
                    IEntityRelationCollection<IEntityRelation> materialResourceCollection = storageResource.RelationCollection[Navigo.Common.Constants.MaterialResource];

                    // Order MaterialResource collection by the createdOn property, this organizes it by the order the materials where scanned into the storage resource
                    materialResourceCollection.OrderByDescending(x => x.CreatedOn);

                    // Gets the first material scanned
                    IMaterial firstMaterialScanned = materialResourceCollection[0].SourceEntity as IMaterial;

                    // Retrieve the material from the storage resource and attach it to the main feeder resource
                    _iKEAUtilities.ApplyOperationActions(firstMaterialScanned, mainFedder, "Attach");

                }

                Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomERPRequestOrderInput", input),
                                    new KeyValuePair<String, Object>("CustomERPRequestOrderOutput", output));

            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            return output;
        }

        /// <summary>
        /// Service called by IoT to Resolve Resource's OEE State when alarm required and if alarm action set on table CustomAlarmHandlingActions
        /// </summary>
        /// <param name="input">CustomModelStateChangeWithActiveAlarmInput</param>
        /// <returns>CustomModelStateChangeWithActiveAlarmOutput</returns>
        public CustomModelStateChangeWithActiveAlarmOutput CustomModelStateChangeWithActiveAlarm(CustomModelStateChangeWithActiveAlarmInput input)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomModelStateChangeWithActiveAlarm",
                 new KeyValuePair<string, object>("CustomModelStateChangeWithActiveAlarmInput", input));

            CustomModelStateChangeWithActiveAlarmOutput output = new CustomModelStateChangeWithActiveAlarmOutput();

            try
            {
                Utilities.ValidateNullInput(input);

                if (input.Resources.IsNullOrEmpty())
                {
                    output.State = string.Empty;
                    output.Reason = string.Empty;
                    output.IsToPreventOEEConfigurationState = false;
                    output.IsToBlockOEECalculation = false;
                    output.AlarmIDBlockingOEECalculation = string.Empty;
                    Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomModelStateChangeWithActiveAlarmInput", input),
                                            new KeyValuePair<String, Object>("CustomModelStateChangeWithActiveAlarmOutput", output));
                    return output;
                }

                IResourceCollection resources = _entityFactory.CreateCollection<IResourceCollection>();

                foreach (string resourceName in input.Resources)
                {
                    var resource = _entityFactory.Create<IResource>();
                    resource.Name = resourceName;
                    resources.Add(resource);
                }

                resources.Load();

                IResource topmost = resources.First().GetTopMostResource();
                topmost.Load();
                topmost.LoadAttributes(new Collection<string> { IKEAConstants.CustomMAORequired, IKEAConstants.CustomAlarmRequired });
                Tuple<ICustomAlarmOccurrence, string, string> utilityOutput = _iKEAUtilities.ResolveOEEStateAndReasonWhenAlarmRequired(topmost, resources);
                if (utilityOutput != null && utilityOutput.Item1 != null && !String.IsNullOrEmpty(utilityOutput.Item2) && !String.IsNullOrEmpty(utilityOutput.Item3))
                {
                    string reasonName = utilityOutput.Item3;
                    string stateName = utilityOutput.Item2;
                    _iKEAUtilities.SetStateOnResource(topmost, stateName, reasonName, false);
                    output.State = stateName;
                    output.Reason = reasonName;
                    output.IsToPreventOEEConfigurationState = false;
                    output.IsToBlockOEECalculation = true;
                    output.AlarmIDBlockingOEECalculation = utilityOutput.Item1.Id.ToString();
                    Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomModelStateChangeWithActiveAlarmInput", input),
                                            new KeyValuePair<String, Object>("CustomModelStateChangeWithActiveAlarmOutput", output));
                    return output;
                }
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            output.State = string.Empty;
            output.Reason = string.Empty;
            output.IsToPreventOEEConfigurationState = true;
            output.IsToBlockOEECalculation = false;
            output.AlarmIDBlockingOEECalculation = string.Empty;
            Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomModelStateChangeWithActiveAlarmInput", input),
                                    new KeyValuePair<String, Object>("CustomModelStateChangeWithActiveAlarmOutput", output));
            return output;
        }

        /// <summary>
        /// Service to generate an error notification to be used by IoT
        /// </summary>
        /// <param name="input">CustomGenerateErrorNotificationInput</param>
        /// <returns>CustomGenerateErrorNotificationOutput</returns>
        public CustomGenerateErrorNotificationOutput CustomGenerateErrorNotification(CustomGenerateErrorNotificationInput input)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomGenerateErrorNotification", new KeyValuePair<String, Object>("CustomGenerateErrorNotificationInput", input));

            CustomGenerateErrorNotificationOutput output = new CustomGenerateErrorNotificationOutput();

            try
            {
                // Validates input and its properties
                Utilities.ValidateNullInput(input);



                var resource = _entityFactory.Create<IResource>();
                resource.Name = input.ResourceName;
                resource.Load();

                // Get checked-in employees on main resource
                IEmployeeCollection employees = _genericUtilities.GetCheckedInEmployees(input.ResourceName);

                // Send notification to all checked-in employees
                _iKEAUtilities.GenerateNotificationToEmployees(input.Title, input.ErrorMessage, employees, sendEmail: true, resource: resource);
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomGenerateErrorNotificationInput", input),
                                    new KeyValuePair<String, Object>("CustomGenerateErrorNotificationOutput", output));
            return output;
        }



        /// <summary>
        /// Service to validate if counter part (in first line) of order in the second line has been completed or aborted
        /// </summary>
        /// <param name="input">CustomDirectFeedingCounterPartValidationInput</param>
        /// <returns>CustomDirectFeedingCounterPartValidationOutput</returns>
        public CustomDirectFeedingCounterPartValidationOutput CustomDirectFeedingCounterPartValidation(CustomDirectFeedingCounterPartValidationInput input)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomDirectFeedingCounterPartValidation", new KeyValuePair<String, Object>("CustomDirectFeedingCounterPartValidationInput", input));

            CustomDirectFeedingCounterPartValidationOutput output = new CustomDirectFeedingCounterPartValidationOutput();

            try
            {

                #region Validate input

                // Validates input and its properties
                Utilities.ValidateNullInput(input);



                // Check if order is exists and load it
                string orderName = input.OrderName;
                IMaterial order = _entityFactory.Create<IMaterial>();
                order.Name = orderName;

                if (!order.ObjectExists())
                {
                    throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.MaterialDoesNotExist, orderName));
                }
                order.Load();

                // Check if order is in process
                if (order.LastProcessedResource == null)
                {
                    throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomOrderMaterialNotInProcessMessage, orderName));
                }
                IResource resource = order.LastProcessedResource;
                resource.Load();

                #endregion


                // Verify counter part
                _genericUtilities.VerifyOrderCounterPart(order, resource);

            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomDirectFeedingCounterPartValidationInput", input),
                                    new KeyValuePair<String, Object>("CustomDirectFeedingCounterPartValidationOutput", output));
            return output;
        }

        /// <summary>
        /// Service to request IoT to create a virtual pallet. Request will be sent to resource counterpart in direct feeding.
        /// </summary>
        /// <param name="input">CustomCreateVirtualPalletInput</param>
        /// <returns>CustomCreateVirtualPalletOutput</returns>
        public CustomCreateVirtualPalletOutput CustomCreateVirtualPallet(CustomCreateVirtualPalletInput input)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomCreateVirtualPallet", new KeyValuePair<String, Object>("CustomCreateVirtualPalletInput", input));

            CustomCreateVirtualPalletOutput output = new CustomCreateVirtualPalletOutput();



            try
            {
                // Validates input and its properties
                Utilities.ValidateNullInput(input);

                // Get input data:
                long resourceId = long.Parse(input.ResourceId);
                IResource resource = _entityFactory.Create<IResource>();
                resource.Load(resourceId);
                if (!resource.ObjectExists())
                {
                    throw new CmfBaseException(IKEAConstants.CustomErrorMessageResourceNotExists);
                }
                resource.Load();

                IResource counterpartResource = _directFeedingUtilities.GetDirectFeedingCounterpartResource(resource);
                if (counterpartResource == null)
                {
                    throw new CmfBaseException(IKEAConstants.CustomErrorMessageCounterpartResourceNotExists);
                }
                counterpartResource.Load();

                Dictionary<IMaterial, decimal> materialOrders = _iKEAUtilities.GetMaterialsFromResourceByState(resource.Id, true, new MaterialSystemState[] { MaterialSystemState.InProcess });
                IMaterialCollection materials = _entityFactory.CreateCollection<IMaterialCollection>(); ;
                materials.AddRange(materialOrders.OrderBy(mo => mo.Value).Select(mo => mo.Key));
                if (materials.Count <= 0)
                {
                    throw new CmfBaseException(String.Format(IKEAConstants.CustomErrorMessageNoMOInProcess, resource.Name));
                }
                IMaterial mo = materials.FirstOrDefault();
                mo.Load();
                IProduct product = mo.Product;
                product.LoadAttributes(new Collection<string>() { IKEAConstants.CustomProductAttributeBaseProduct,
                                                                  IKEAConstants.CustomProductAttributeRevision });

                string customProductAttributeBaseProduct = product.GetRelatedAttributeValueOrDefault<String>(IKEAConstants.CustomProductAttributeBaseProduct);
                // Verify if there is a custom revision
                if (!String.IsNullOrWhiteSpace(product.GetRelatedAttributeValueOrDefault<String>(IKEAConstants.CustomProductAttributeRevision))
                    && !String.IsNullOrWhiteSpace(customProductAttributeBaseProduct))
                {
                    product = _entityFactory.Create<IProduct>();
                    product.Load(customProductAttributeBaseProduct);
                }

                _directFeedingUtilities.RequestVirtualPalletCreation(
                    product: product,
                    lineResource: counterpartResource,
                    baseUnitConversion: _iKEAUtilities.CalculateConversionFactorFromMaterial(mo),
                    quantity: input.Quantity
                    );
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomCreateVirtualPalletInput", input),
                                    new KeyValuePair<String, Object>("CustomCreateVirtualPalletOutput", output));
            return output;
        }

        /// <summary>
        /// Service that checks if MO in SecondLine is InProcess
        /// </summary>
        /// <param name="input">CustomCreateVirtualPalletInput</param>
        /// <returns>CustomCreateVirtualPalletOutput</returns>
        public CustomIsMOInSecondLineInProcessOutput CustomIsMOInSecondLineInProcess(CustomIsMOInSecondLineInProcessInput input)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomIsMOInSecondLineInProcess", new KeyValuePair<String, Object>("CustomIsMOInSecondLineInProcessInput", input));

            CustomIsMOInSecondLineInProcessOutput output = new CustomIsMOInSecondLineInProcessOutput();



            try
            {
                Utilities.ValidateNullInput(input);

                IResource resource = _entityFactory.Create<IResource>();
                resource.Name = input.ResourceName;
                resource.Load();

                if (!_directFeedingUtilities.IsDirectFeedingResourceMatchValid(resource))
                {
                    throw new CmfBaseException(IKEAConstants.CustomErrorMessageDFValidateSecondLineMO);
                }

                bool isFirstLine = resource.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomResourceDirectFeedingIsFirstLine, loadAttribute: true);
                if (!isFirstLine)
                {
                    throw new CmfBaseException(IKEAConstants.CustomErrorMessageDFNotFirstLine);
                }

                IResource counterpartResource = _directFeedingUtilities.GetDirectFeedingCounterpartResource(resource);
                counterpartResource.Load();

                output.IsMOInProcess = false;
                Dictionary<IMaterial, decimal> materialOrders = _iKEAUtilities.GetMaterialsFromResourceByState(counterpartResource.Id, true, new MaterialSystemState[] { MaterialSystemState.InProcess });
                if (materialOrders.Count > 0)
                {
                    output.IsMOInProcess = true;
                }
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomIsMOInSecondLineInProcessInput", input),
                                        new KeyValuePair<String, Object>("CustomIsMOInSecondLineInProcessOutput", output));
            return output;
        }



        /// <summary>
        /// Service is called by second line to clear interlock on the first line.
        /// </summary>
        /// <param name="input">CustomCreateVirtualPalletInput</param>
        /// <returns>CustomCreateVirtualPalletOutput</returns>
        public CustomRequestClearInterlockOnFirstLineOutput CustomRequestClearInterlockOnFirstLine(CustomRequestClearInterlockOnFirstLineInput input)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomRequestClearInterlockOnFirstLine", new KeyValuePair<String, Object>("CustomRequestClearInterlockOnFirstLineInput", input));

            CustomRequestClearInterlockOnFirstLineOutput output = new CustomRequestClearInterlockOnFirstLineOutput();



            try
            {
                Utilities.ValidateNullInput(input);

                // Validate that request is from second line
                IResource secondLineResource = _entityFactory.Create<IResource>();
                secondLineResource.Name = input.ResourceName;
                secondLineResource.Load();

                if (!_directFeedingUtilities.IsDirectFeedingResourceMatchValid(secondLineResource))
                {
                    throw new CmfBaseException(IKEAConstants.CustomErrorMessageDFClearInterlockNotValid);
                }
                bool isSecondLine = !secondLineResource.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomResourceDirectFeedingIsFirstLine, loadAttribute: true);
                if (isSecondLine)
                {
                    // Send request to first line
                    IResource firstLineResource = _directFeedingUtilities.GetDirectFeedingCounterpartResource(secondLineResource, loadResource: true);
                    firstLineResource.Load();

                    _directFeedingUtilities.RequestFirstLineToClearDirectFeedingInterlock(firstLineResource: firstLineResource);
                }
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomRequestClearInterlockOnFirstLineInput", input),
                                        new KeyValuePair<String, Object>("CustomRequestClearInterlockOnFirstLineOutput", output));
            return output;
        }

        /// <summary>
        /// Service to validate complete button conditions
        /// </summary>
        /// <param name="input">CustomValidateCompleteConditionsInput</param>
        /// <returns>CustomValidateCompleteConditionsOutput</returns>
        public CustomValidateCompleteConditionsOutput CustomValidateCompleteConditions(CustomValidateCompleteConditionsInput input)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomValidateCompleteConditions", new KeyValuePair<String, Object>("CustomValidateCompleteConditionsInput", input));

            CustomValidateCompleteConditionsOutput output = new CustomValidateCompleteConditionsOutput();

            try
            {
                // Validates input and its properties
                Utilities.ValidateNullInput(input);

                IResource resource = input.Resource;
                IMaterial material = input.Material;

                if (material != null)
                {
                    material.Load();
                }
                if (resource != null)
                {
                    resource.Load();
                }

                bool isCompleteAllowed = false;
                decimal iotRemainingQntts = 0;
                output.IsToOpenWizard = false;

                material.LoadMainState();
                material.LoadAttributes(new Collection<string>() {
                            IKEAConstants.CustomMaterialAttributeCompletedQuantity,
                            IKEAConstants.CustomMaterialAttributeOriginalQuantity,
                            IKEAConstants.CustomMaterialAttributeIoTReportedQuantity
                        });

                decimal completedQuantity = material.GetAttributeValueOrDefault<decimal>(IKEAConstants.CustomMaterialAttributeCompletedQuantity);
                decimal originalQuantity = material.GetAttributeValueOrDefault<decimal>(IKEAConstants.CustomMaterialAttributeOriginalQuantity);
                decimal iotReportedQuantity = material.GetAttributeValueOrDefault<decimal>(IKEAConstants.CustomMaterialAttributeIoTReportedQuantity);

                bool inOverproduction = material.PrimaryQuantity + completedQuantity > originalQuantity;

                bool isReadyForCompletion = inOverproduction || iotReportedQuantity >= originalQuantity;

                // Is Complete Allowed if the Primary Quantity is Zero while the MSM state is neither SETUP nor DISPATCHED and automation mode is NOT Online
                // Or if MSM is INPROCESS and the material is: not on hold, and the quantity is enough
                if (material.CurrentMainState?.CurrentState?.Name != IKEAConstants.MaterialStateModelDispatched
                    && material.CurrentMainState?.CurrentState?.Name != IKEAConstants.MaterialStateModelSetup
                    && material.PrimaryQuantity == 0)
                {
                    isCompleteAllowed = true;
                }
                else if (material.CurrentMainState?.CurrentState?.Name == IKEAConstants.MaterialStateModelInProcess
                    && (inOverproduction || isReadyForCompletion) //enough quantity for completion / material is in Overproduction or has the flag IsReadyForProduction
                    && (material.HoldCount == 0))
                {
                    isCompleteAllowed = true;
                }

                if (resource.AutomationMode == ResourceAutomationMode.Online)
                {
                    IAutomationControllerInstance controllerInstance = resource.GetAutomationControllerInstance();
                    if (controllerInstance != null)
                    {
                        // Prepare material details to send order stop
                        Dictionary<string, string> materialDetails = new Dictionary<string, string>
                        {
                            { "MaterialName", material.Name }
                        };

                        object parsedReply = null;

                        //Call Iot new event to know the IoT remaining quantities if it is online
                        // Send Synchronous request to automation remaining quantities
                        var eiReply = _genericUtilities.RequestFromIoT<Dictionary<string, object>>(controllerInstance, IKEAConstants.AutomationRequestTypeGetRemainingQuantities, materialDetails.ToString());

                        if (eiReply != null && eiReply.ContainsKey(IKEAConstants.AutomationRequestReplyField))
                        {
                            eiReply.TryGetValue(IKEAConstants.AutomationRequestReplyField, out parsedReply);

                            string resultString = JsonConvert.DeserializeObject<string>(parsedReply?.ToJsonString());

                            if (!string.IsNullOrEmpty(resultString))
                            {
                                decimal result = 0;

                                if (decimal.TryParse(resultString, out result))
                                {
                                    iotRemainingQntts = result;
                                }
                            }
                        }
                    }
                    else
                    {
                        //Throw connect IOT / Line controller error
                        throw new CmfBaseException(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomValidateCompletionConditionsNoAutomationControllerInstanceFoundMessage, resource.Name));
                    }
                }

                if (!isCompleteAllowed && iotRemainingQntts == 0)
                {
                    // Only call IoT abort when user confirms the abort operation
                    if (input.IsToCommitAbort)
                    {
                        material.LoadRelations(Cmf.Navigo.Common.Constants.MaterialResource);
                        IMaterialResource materialResource = material.MaterialResourceRelations.Where(
                            mr => mr.TargetEntity.ProcessingType == ProcessingType.Process
                            ).FirstOrDefault();
                        _iKEAUtilities.AbortMaterial(resource, material, isReadyForCompletion, "Abort", materialResource);
                    }

                    output.IsToOpenWizard = false;
                }
                else
                {
                    output.IsToOpenWizard = true;

                }
                output.IsCompleteAllowed = isCompleteAllowed;
                output.RemainingQuantity = iotRemainingQntts;

            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomValidateCompleteConditionsInput", input),
                                    new KeyValuePair<String, Object>("CustomValidateCompleteConditionsOutput", output));
            return output;
        }

        /// <summary>
        /// Service that returns MOs not in any groupMO based on input filter
        /// </summary>
        public CustomGetParentlessMOListByFilterOutput CustomGetParentlessMOListByFilter(CustomGetParentlessMOListByFilterInput input)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomGetParentlessMOListByFilter", new KeyValuePair<String, Object>("CustomGetParentlessMOListByFilterInput", input));

            CustomGetParentlessMOListByFilterOutput output = new CustomGetParentlessMOListByFilterOutput();


            const int MAX_RESULTS = 10;

            try
            {
                List<IMaterial> materials = null;

                // Get Dispatched Materials from resource.
                var dispatchedMaterials = input.Resource.GetDispatchList(levelsToLoad: 1);
                if (dispatchedMaterials != null)
                {
                    materials = dispatchedMaterials.ToList();
                }

                // Filter By MO Form
                if (materials != null)
                {
                    string materialForm = _iKEAUtilities.GetOrderMaterialForm();
                    materials = materials.Where(m => m.Form == materialForm).ToList();
                }

                // Filter By ExcludedMaterials
                if (materials != null && input.ExcludedMaterials != null)
                {
                    // Create a HashSet of excluded material names for fast lookup
                    var excludedMaterialNames = new HashSet<long>(input.ExcludedMaterials.Select(em => em.Id));
                    // Filter out materials that are in the excludedMaterialNames set
                    materials = materials.Where(m => !excludedMaterialNames.Contains(m.Id)).ToList();
                }

                // Filter By MaterialNameFilter
                if (materials != null && input.MaterialNameFilter != null)
                {
                    materials = materials.Where(m => m.Name.Contains(input.MaterialNameFilter)).ToList();
                }

                // Filter by product
                if (materials != null && input.ProductFilter != null)
                {
                    materials = materials.Where(m => m.Product.Name == input.ProductFilter.Name).ToList();
                }

                // Filter By Attribute isGroupMO
                if (materials != null)
                {
                    IMaterialCollection materialCollection = _entityFactory.CreateCollection<IMaterialCollection>();
                    foreach (IMaterial material in materials)
                    {
                        materialCollection.Add(material);
                    }
                    materialCollection.LoadAttributes(new Collection<string> { IKEAConstants.CustomMaterialAttributeIsGroupMO });
                    materials = materialCollection.ToList();

                    materials = materials.Where(m =>
                        !m.Attributes.ContainsKey(IKEAConstants.CustomMaterialAttributeIsGroupMO)
                        || (bool)m.Attributes[IKEAConstants.CustomMaterialAttributeIsGroupMO] == false).ToList();

                }

                // Run query to resolve what materials are not children.
                if (materials != null)
                {
                    materials = materials.FilterChildMOsFromList().ToList();
                }

                // Limit results by 10
                if (materials != null)
                {
                    materials = materials.Take(MAX_RESULTS).ToList();
                }

                output.Materials = materials;

            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomGetParentlessMOListByFilterInput", input),
                                    new KeyValuePair<String, Object>("CustomGetParentlessMOListByFilterOutput", output));
            return output;
        }

        public CustomGetDispatchListForResourceOutput CustomGetDispatchListForResource(CustomGetDispatchListForResourceInput input)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomGetDispatchListForResource", new KeyValuePair<String, Object>("CustomGetDispatchListForResourceInput", input));

            CustomGetDispatchListForResourceOutput output = new CustomGetDispatchListForResourceOutput();
            try
            {
                input.Input.ExtensionData = input.ExtensionData;
                input.Input.IgnoreLastServiceId = input.IgnoreLastServiceId;
                input.Input.OperationTarget = input.OperationTarget;
                input.Input.NumberOfRetries = input.NumberOfRetries;
                input.Input.OperationAttributes = input.OperationAttributes;
                input.Input.PageNumber = 0;
                input.Input.PageSize = 0;
                input.Input.ServiceComments = input.ServiceComments;
                input.Input.ExtraParameters = input.ExtraParameters;

                int totalRows = 0;
                int countPlannedMaterials = 0;

                GetDispatchListForResourceOutput serviceOutput = _dispatchOrchestration.GetDispatchListForResource(input.Input);



                IMaterialCollection materials = serviceOutput.Materials;

                if (input.Input.Resource.SortRuleSet == null)
                {
                    ISortRuleSet sortRuleSet = _entityFactory.Create<ISortRuleSet>();
                    sortRuleSet.Load("CustomSortRuleSetMaterialsToDispatch");
                    if (materials.Any())
                    {
                        materials = sortRuleSet.Sort(serviceOutput.Materials);
                    }
                }

                IMaterialCollection materialsLoaded = _deeContextUtilities.GetContextParameter(IKEAConstants.CustomLoadMaterialsForDispatchContext) as IMaterialCollection;

                if (materialsLoaded != null)
                {
                    Dictionary<long, IMaterial> matDictionary = materialsLoaded.ToDictionary(po => po.Id, po => po);

                    for (int i = 0; i < materials.Count; i++)
                    {
                        IMaterial mat = materials[i];
                        if (matDictionary.TryGetValue(mat.Id, out var loadedMaterial))
                        {
                            materials[i] = loadedMaterial;
                        }
                    }
                }

                materials = _iKEAUtilities.GetMaterialsToDispatchForResource(input.Filters, materials);

                #region Pagination
                Cmf.Navigo.BusinessObjects.Abstractions.IServiceCollection enabledServices = _entityFactory.CreateCollection<Navigo.BusinessObjects.Abstractions.IServiceCollection>();
                if (input.Input.Resource.ResourceServices != null && input.Input.Resource.ResourceServices.Count > 0)
                {
                    // Select all the enabled services at the Resource which are also enabled globally 
                    var serv = input.Input.Resource.ResourceServices
                        .Where(e => (e.IsEnabled ?? false) && (e.TargetEntity.IsEnabled ?? false))
                        .Select(e => e.TargetEntity);

                    foreach (Cmf.Navigo.BusinessObjects.Abstractions.IService service in serv)
                    {
                        enabledServices.Add(service);
                    }
                }

                if (enabledServices.Count > 0)
                {
                    /*
                   * For Resources of ProcessingType Process or ConsumableFeed or Line
                   * it will match the RequiredServices of all TopMost Material in the same Facility
                   * as the Resource, with IsDispatchable set to true, and returns the corresponding planned and unplanned count,
                   * also matching with existing schedule scenario jobs associated to the Resource and with a Released Schedule Scenario
                   */

                    IMaterialCollection materialCol = _entityFactory.CreateCollection<IMaterialCollection>();

                    if (input.Input.Resource.ProcessingType == ProcessingType.Process || input.Input.Resource.ProcessingType == ProcessingType.ConsumableFeed || input.Input.Resource.ProcessingType == ProcessingType.Line)
                    {
                        materialCol.GetMaterialCounters(enabledServices, input.Input.Resource, out totalRows, out countPlannedMaterials, input.Input.LevelsToLoad, input.Input.Filters, input.Input.IsToIncludeMaterialsOnHold);
                        serviceOutput.CountPlannedMaterials = countPlannedMaterials;
                        serviceOutput.CountUnplannedMaterials = totalRows - countPlannedMaterials;
                    }
                    else
                    {
                        // LoadPort or Storage
                        throw new RestrictedDispatchTypeCmfException(input.Input.Resource.ProcessingType.GetLocalizedName(), input.Input.Resource.EntityType.GetLocalizedName());
                    }
                }


                serviceOutput.TotalRows = materials.Count;

                // Select the materials according to the PageSize and PageNumber
                // This is not being done at SQL level since to correctly sort the materials we need to have them all
                if (input.PageNumber > 0 && input.PageSize > 0)
                {
                    IMaterialCollection paginatedMaterials = _entityFactory.CreateCollection<IMaterialCollection>();
                    paginatedMaterials.AddRange(materials.Skip((input.PageNumber - 1) * input.PageSize).Take(input.PageSize));
                    materials = paginatedMaterials;
                }
                #endregion

                serviceOutput.Materials = materials;

                output = new CustomGetDispatchListForResourceOutput
                {
                    Output = serviceOutput
                };

            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomGetDispatchListForResourceInput", input),
                                    new KeyValuePair<String, Object>("CustomGetDispatchListForResourceOutput", output));
            return output;
        }

        /// <summary>
        /// Service to request IoT to Reset palletID.
        /// </summary>
        /// <param name="input">CustomResetPalletIDQueueInput</param>
        /// <returns>CustomResetPalletIDQueueOutput</returns>
        public CustomResetPalletIDQueueOutput CustomResetPalletIDQueue(CustomResetPalletIDQueueInput input)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomResetPalletIDQueue", new KeyValuePair<String, Object>("CustomResetPalletIDQueueInput", input));
            CustomResetPalletIDQueueOutput output = new CustomResetPalletIDQueueOutput();
            System.IServiceProvider serviceProvider = ApplicationContext.CurrentServiceProvider;
            IEntityFactory entityFactory = serviceProvider.GetRequiredService<IEntityFactory>();

            //Load Material:
            IMaterial material = _entityFactory.Create<IMaterial>();
            material.Load();
            if (material.LastProcessedResource == null)
            {
                throw new Exception(_iKEAUtilities.GetLocalizedMessage(IKEAConstants.CustomOrderMaterialNotInProcessMessage, material.Name));
            }

            //Get resource from material:
            IResource resource = material.LastProcessedResource;
            resource.Load();
            if (resource.AutomationMode == ResourceAutomationMode.Online)
            {
                IAutomationControllerInstance controllerInstance = resource.GetAutomationControllerInstance();
                if (controllerInstance != null)
                {
                    bool result = _iKEAUtilities.RequestPalletIDReset(
                        controllerInstance: controllerInstance,
                        materialName: input.Material
                    );
                    output.RequestSentToIOT = result;
                }
            }

            Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomResetPalletIDQueueInput", input),
                            new KeyValuePair<String, Object>("CustomResetPalletIDQueueOutput", output));
            return output;
        }

        /// <summary>
        /// Service that returns all possible return steps for teh outsorted material
        /// </summary>
        public CustomGetOutsortedMaterialAllPossibleReturnStepsOutput CustomGetOutsortedMaterialAllPossibleReturnSteps(CustomGetOutsortedMaterialAllPossibleReturnStepsInput input)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomGetOutsortedMaterialAllPossibleReturnSteps", new KeyValuePair<String, Object>("CustomGetOutsortedMaterialAllPossibleReturnStepsInput", input));

            CustomGetOutsortedMaterialAllPossibleReturnStepsOutput output = new CustomGetOutsortedMaterialAllPossibleReturnStepsOutput();
            try
            {
                System.IServiceProvider serviceProvider = ApplicationContext.CurrentServiceProvider;

                IMaterial material = _entityFactory.Create<IMaterial>();
                material.Name = input.MaterialName;
                if (material.ObjectExists())
                {
                    material.Load();
                }
                IGenericTable genericTable = _entityFactory.Create<IGenericTable>();
                genericTable.Load(IKEAConstants.CustomMaterialTypeStepTypeGenericTable);
                // Get all the matching step type from generic table CustomMaterialTypeStepType
                genericTable.LoadData(new FilterCollection { new Filter { Name = IKEAConstants.CustomMaterialTypeStepTypeGenericTableMaterialType, Value = input.NewMaterialType } });

                if (genericTable != null && genericTable.Data != null)
                {
                    System.Data.DataSet dataSet = NgpDataSet.ToDataSet(genericTable.Data);

                    if (dataSet.HasData())
                    {
                        IStepCollection stepTypeCol = _entityFactory.CreateCollection<IStepCollection>();
                        IFlow flow = material.Flow;
                        flow.Load();
                        // Get all the steps of the flow, including alternative flow and sub flows
                        IStepCollection stepCol = flow.GetAllStepsOfFlow();
                        foreach (DataRow row in dataSet.Tables[0].Rows)
                        {
                            // Filter only the matching step types from the generic table with MarksProductCompletion is enabled
                            stepTypeCol.AddRange(stepCol.Where(m => m.Type == row["StepType"].ToString() && m.MarksProductCompletion == true));
                        }

                        if (stepTypeCol != null && stepTypeCol.Count > 0)
                        {
                            IStep returnStep = stepTypeCol.LastOrDefault();
                            string returnFlowPath = flow.GetFlowPath(returnStep.Name);

                            output.MaterialName = material.Name;
                            output.ReturnFlowPath = returnFlowPath;
                            output.ReturnFlow = flow;
                            output.ReturnStep = returnStep;
                            output.Steps = stepTypeCol;
                        }
                    }
                }

            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }
            Utilities.EndMethod(-1, -1, new KeyValuePair<String, Object>("CustomGetOutsortedMaterialAllPossibleReturnStepsInput", input),
                                    new KeyValuePair<String, Object>("CustomGetOutsortedMaterialAllPossibleReturnStepsOutput", output));
            return output;
        }

        /// <summary>
        /// Service to request Detach Materials.
        /// </summary>
        /// <param name="input">CustomDetachMaterialsInput</param>
        /// <returns>CustomDetachMaterialsOutput</returns>
        public CustomDetachMaterialsOutput CustomDetachMaterials(CustomDetachMaterialsInput customDetachMaterialsInput)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomDetachMaterials", new KeyValuePair<String, Object>("CustomDetachMaterialsInput", customDetachMaterialsInput));

            CustomDetachMaterialsOutput customDetachMaterialsOutput = new CustomDetachMaterialsOutput
            {
                Result = false
            };

            try
            {
                // Validate input and log service comments if existing
                Utilities.ValidateNullInput(customDetachMaterialsInput);
                // load resource
                IResource resource = _entityFactory.Create<IResource>();
                resource.Load(customDetachMaterialsInput.Resource);
                //Resolve all the subresources with the type of consumable feed
                var orderedResources = resource.GetResourceSubResources();
                IResourceCollection resourceCollection = _entityFactory.CreateCollection<IResourceCollection>();
                resourceCollection.AddRange(orderedResources.Where(x => x.ProcessingType == ProcessingType.ConsumableFeed));
                resourceCollection.LoadAttributes(new Collection<string>() { IKEAConstants.ProcessSegmentSequence, IKEAConstants.SubProcessSegmentName });

                IResourceCollection resourceWithProcessSegment = _entityFactory.CreateCollection<IResourceCollection>();
                resourceWithProcessSegment.AddRange(resourceCollection.Where(r => !string.IsNullOrWhiteSpace(r.GetAttributeValueOrDefault<string>(IKEAConstants.ProcessSegmentSequence))));
                resourceCollection = resourceWithProcessSegment;
                resourceCollection.LoadRelations();
                IResource sharedFeederResource = null;
                IResourceCollection sharedFeederscollection = _entityFactory.CreateCollection<IResourceCollection>();
                foreach (var feeder in resourceCollection)
                {
                    feeder.LoadRelations();
                    feeder.LoadRelations(IKEAConstants.CustomResourceConsumptionProvider);
                    var resourceConsmuptionProvider = _iKEAUtilities.GetActiveSharedProviderFromFeeder(feeder);
                    if (resourceConsmuptionProvider == null) continue;

                    sharedFeederResource = resourceConsmuptionProvider.TargetEntity;
                    if (sharedFeederResource != null && !resourceCollection.Contains(sharedFeederResource))
                    {
                        sharedFeederscollection.Add(sharedFeederResource);
                    }
                }
                resourceCollection.AddRange(sharedFeederscollection);
                resource.LoadRelations();

                //materialInProcess.GetBOMProductsForSubResource

                // get currently inprocess orders
                IMaterialCollection materialInProcessCollection = resource.GetAllMaterialsInProcess();

                if (materialInProcessCollection.Count != 0)
                {
                    foreach (IMaterial material in materialInProcessCollection)
                    {
                        foreach (IResource feedersubresource in resourceCollection)
                        {
                            feedersubresource.LoadRelations(IKEAConstants.CustomResourceConsumptionProvider);
                            IResource resolvedfeederresource = null;

                            IEnumerable<Cmf.Navigo.BusinessObjects.Resource> consumptionProvider = null;
                            if (feedersubresource.IsSharedConsumableFeed == true)
                            {
                                consumptionProvider = feedersubresource.RelationCollection[IKEAConstants.CustomResourceConsumptionProvider]
                                                         .Select(ER => ER.TargetEntity as Cmf.Navigo.BusinessObjects.Resource);
                            }
                            if (consumptionProvider != null)
                            {
                                resolvedfeederresource = consumptionProvider.Where(res => res.GetAscendentResources(1).FirstOrDefault().ParentResource.Name == resource.Name).FirstOrDefault();
                            }
                            else
                            {
                                resolvedfeederresource = feedersubresource;
                            }

                            var feeederMaterialCollection = feedersubresource.GetAttachedMaterials();

                            IBOMProductCollection bomProductCollection = material.GetBOMProductsForSubResource(resolvedfeederresource);
                            var productList = bomProductCollection.Select(x => x.TargetEntity);
                            var availableMaterials = feeederMaterialCollection.Where(material => productList.Contains(material.Product));
                            IMaterialCollection updatedMaterialCollection = _entityFactory.CreateCollection<IMaterialCollection>();
                            updatedMaterialCollection = feeederMaterialCollection;

                            if (availableMaterials != null)
                            {
                                foreach (var availableMaterial in availableMaterials.ToList())
                                {
                                    updatedMaterialCollection.Remove(availableMaterial);

                                }

                                if (!updatedMaterialCollection.IsNullOrEmpty())
                                {
                                    try
                                    {
                                        feedersubresource.DetachConsumablesFromResource(updatedMaterialCollection);
                                    }
                                    catch (Exception)
                                    {
                                        updatedMaterialCollection.Terminate();
                                    }
                                }
                            }

                        }
                    }

                }
                else
                {
                    foreach (IResource feedersubresource in resourceCollection)
                    {
                        var attachedMaterials = feedersubresource.GetAttachedMaterials();
                        try
                        {
                            feedersubresource.DetachConsumablesFromResource(attachedMaterials);
                        }
                        catch (Exception)
                        {
                            attachedMaterials.Terminate();
                        }
                    }
                }

                customDetachMaterialsOutput.Result = true;
                // log method exit
                long objectInstanceId = -1;
                long objectTypeId = -1;
                Utilities.EndMethod(objectTypeId, objectInstanceId, new KeyValuePair<String, Object>("CustomDetachMaterialsInput", customDetachMaterialsInput),
                                                                    new KeyValuePair<String, Object>("CustomDetachMaterialsOutput", customDetachMaterialsOutput));
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception excep)
            {
                throw new CmfBaseException(excep.Message, excep);
            }

            return customDetachMaterialsOutput;
        }
        #endregion Orchestration Methods
    }
}
