﻿
namespace Cmf.Custom.IKEA.Orchestration
{
    public partial class IKEAOrchestration : IIKEAOrchestration
    {
        private const string OBJECT_TYPE_NAME = "Cmf.Custom.IKEA.Orchestration.IKEAManagementOrchestration";
    }
}
