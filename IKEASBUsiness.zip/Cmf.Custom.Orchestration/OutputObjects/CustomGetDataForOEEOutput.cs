﻿using Cmf.Foundation.BusinessOrchestration;
using System;
using System.Runtime.Serialization;
using Cmf.Foundation.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{
    /// <summary>
    /// CustomGetDataForOEE Output Object
    /// </summary>
    [DataContract(Name = "CustomGetDataForOEEOutput")]
    public class CustomGetDataForOEEOutput : BaseOutput
    {
        #region Properties
        /// <summary>
        /// Data
        /// </summary>
        [DataMember(Name = "Data", Order = 0)]
        public INgpDataSet Data { get; set; }

        /// <summary>
        /// ShowDecimals
        /// </summary>
        [DataMember(Name = "ShowDecimals", Order = 0)]
        public Boolean ShowDecimals { get; set; }
        #endregion
    }
}
