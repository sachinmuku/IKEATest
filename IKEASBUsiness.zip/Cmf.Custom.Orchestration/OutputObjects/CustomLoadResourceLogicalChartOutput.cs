﻿using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{
    /// <summary>
    /// Output Data Contract for the CustomLoadResourceLogicalChart service
    /// </summary>
    [DataContract(Name = "CustomLoadResourceLogicalChartOutput")]
    public class CustomLoadResourceLogicalChartOutput : BaseOutput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties
        /// <summary>
        /// LogicalChartCollection
        /// </summary>
        [DataMember(Name = "LogicalCharts", Order = 10)]
        public ILogicalChartCollection LogicalCharts { get; set; }
        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
