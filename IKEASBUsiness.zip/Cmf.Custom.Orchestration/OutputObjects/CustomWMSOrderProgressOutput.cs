﻿
using Cmf.Custom.IKEA.Common.Enums;
using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{
    [DataContract(Name = "CustomWMSOrderProgressOutput")]
    public class CustomWMSOrderProgressOutput : BaseOutput
    {

        [DataMember(Name = "Response", Order = 10)]
        public CustomWMSOrderResponseType Response { get; set; }

        [DataMember(Name = "Details", Order = 10)]
        public string Details { get; set; }

    }
}
