﻿using Cmf.Foundation.BusinessOrchestration;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{
    [DataContract(Name = "CustomWMSGetMaxAdditionalQuantityOutput")]
    public class CustomWMSGetMaxAdditionalQuantityOutput : BaseOutput
    {        

        [DataMember(Name = "ProductWithMaxAdditionalQuantity", Order = 1)]
        public Dictionary<long, decimal?> ProductWithMaxAdditionalQuantity { get; set; }
    }
}
