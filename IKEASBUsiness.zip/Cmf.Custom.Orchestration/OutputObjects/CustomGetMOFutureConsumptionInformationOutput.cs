﻿using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;
using Cmf.Foundation.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{
    /// <summary>
    /// Output Data Contract for the CustomGetMOFutureConsumptionInformationOutput service
    /// </summary>
    [DataContract(Name = "CustomGetMOFutureConsumptionInformationOutput")]
    public class CustomGetMOFutureConsumptionInformationOutput : BaseOutput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// Possible Feeders
        /// </summary>
        [DataMember(Name = "PossibleFeeders", Order = 10)]
        public INgpDataSet PossibleFeeders { get; set; }

        /// <summary>
        /// Possible Consumers
        /// </summary>
        [DataMember(Name = "PossibleConsumers", Order = 20)]
        public INgpDataSet PossibleConsumers { get; set; }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
