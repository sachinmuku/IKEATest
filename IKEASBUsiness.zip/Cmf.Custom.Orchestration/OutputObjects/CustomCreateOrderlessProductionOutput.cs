using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;
namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{
    /// <summary>
    /// Output Data Contract for the CustomCreateOrderlessProduction service
    /// </summary>
    [DataContract(Name = "CustomCreateOrderlessProductionOutput")]
    public class CustomCreateOrderlessProductionOutput : BaseOutput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties
        /// <summary>
        /// Collection of orderless MOs
        /// </summary>
        [DataMember(Name = "Orders", Order = 0)]
        public IMaterialCollection Orders { get; set; }

        /// <summary>
        /// Material group order
        /// </summary>
        [DataMember(Name = "GroupOrder", Order = 1)]
        public IMaterial GroupOrder { get; set; }
        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
