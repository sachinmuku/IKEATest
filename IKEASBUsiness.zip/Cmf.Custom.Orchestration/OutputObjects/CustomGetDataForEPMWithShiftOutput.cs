﻿using Cmf.Foundation.BusinessOrchestration;
using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Cmf.Foundation.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{
    /// <summary>
    /// CustomGetDataForEPMWithShift Output Object
    /// </summary>
    [DataContract(Name = "CustomGetDataForEPMWithShiftOutput")]
    public class CustomGetDataForEPMWithShiftOutput : BaseOutput
    {
        #region Properties
        /// <summary>
        /// Data
        /// </summary>
        [DataMember(Name = "Data", Order = 0)]
        public INgpDataSet Data { get; set; }

        /// <summary>
        /// StateChanges - State changes grouped by resource name
        /// </summary>
        [DataMember(Name = "StateChanges", Order = 0)]
        public Dictionary<string, INgpDataSet> StateChanges { get; set; }

        /// <summary>
        /// StateSummary - Sum of the full time spent at each state
        /// </summary>
        [DataMember(Name = "StateSummary", Order = 0)]
        public INgpDataSet StateSummary { get; set; }

        /// <summary>
        /// ShowDecimals
        /// </summary>
        [DataMember(Name = "ShowDecimals", Order = 0)]
        public Boolean ShowDecimals { get; set; }
        #endregion
    }
}
