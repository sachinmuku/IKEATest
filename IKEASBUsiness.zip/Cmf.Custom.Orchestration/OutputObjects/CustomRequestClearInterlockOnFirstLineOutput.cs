﻿using System.Runtime.Serialization;
using Cmf.Foundation.BusinessOrchestration;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{
    /// <summary>
    /// Input Data Contract for the CustomRequestClearInterlockOnFirstLine service
    /// </summary>
    [DataContract(Name = "CustomRequestClearInterlockOnFirstLineOutput")]
    public class CustomRequestClearInterlockOnFirstLineOutput : BaseOutput
    {

        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties
        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion

    }
}
