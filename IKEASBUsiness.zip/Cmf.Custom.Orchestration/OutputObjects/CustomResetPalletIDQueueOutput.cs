using Cmf.Foundation.BusinessOrchestration;
using System;
using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{
    /// <summary>
    /// Output Data Contract for the CustomGetDispatchListForResourceOutput service
    /// </summary>
    [DataContract(Name = "CustomResetPalletIDQueueOutput")]
    public class CustomResetPalletIDQueueOutput : BaseOutput
    {
        [DataMember(Name = "RequestSentToIOT", Order = 0)]
        public bool RequestSentToIOT { get; set; }
    }
}
