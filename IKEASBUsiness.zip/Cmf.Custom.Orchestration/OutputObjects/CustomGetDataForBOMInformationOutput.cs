﻿using Cmf.Foundation.BusinessOrchestration;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessOrchestration.ResourceManagement.OutputObjects;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{
    /// <summary>
    /// Output Data Contract for the CustomPrintLabelOrRfidOutput service
    /// </summary>
    [DataContract(Name = "CustomGetDataForBOMInformationOutput")]
    public class CustomGetDataForBOMInformationOutput : BaseOutput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// The material native data, with Topmost and DepthToTopMost properties
        /// </summary>
        [DataMember(Name = "Material", Order = 100)]
        public IMaterial Material
        {
            get;
            set;
        }

        /// <summary>
        /// The Bom resolved for the material.
        /// </summary>
        [DataMember(Name = "Bom", Order = 100)]
        public IBOM Bom
        {
            get;
            set;
        }

        /// <summary>
        /// BOMSetupInformation
        /// </summary>
        [DataMember(Name = "BOMSetupInformation", Order = 100)]
        public BOMSetupInformation BOMSetupInformation
        {
            get;
            set;
        }


        /// <summary>
        /// The BOMAssemblyType resolved for the material.
        /// </summary>
        [DataMember(Name = "BOMAssemblyType", Order = 100)]
        public BOMAssemblyType BOMAssemblyType
        {
            get;
            set;
        }

        /// <summary>
        /// The Resource
        /// </summary>
        [DataMember(Name = "Resource", Order = 100)]
        public IResource Resource
        {
            get;
            set;
        }


        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
