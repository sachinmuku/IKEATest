﻿using Cmf.Foundation.BusinessOrchestration;
using Cmf.Navigo.BusinessObjects;
using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{
    /// <summary>
    /// Output Data Contract for the CustomResolveWMSQuantity service
    /// </summary>
    [DataContract(Name = "CustomResolveWMSQuantityOutput")]
    public class CustomResolveWMSQuantityOutput : BaseOutput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties
        
        /// <summary>
        /// returns the {productnames // productionorders.names // quantities}
        /// </summary>
        [DataMember(Name = "ProductQuantityPerProductionOrderPerProductName", Order = 0)]        
        public Dictionary<string, Dictionary<string, decimal>> ProductQuantityPerProductionOrderPerProductName { get; set; }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
