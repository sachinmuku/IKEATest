﻿using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Foundation.BusinessOrchestration;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{
    /// <summary>
    /// Output Data Contract for the CustomGetMaterialSetupStateOutput service
    /// </summary>
    [DataContract(Name = "CustomGetMaterialSetupStateOutput")]
    public class CustomGetMaterialSetupStateOutput : BaseOutput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// 
        /// </summary>
        [DataMember(Name = "CustomSetupConsumptionDetail", Order = 100)]
        public CustomSetupConsumptionDetailCollection CustomSetupConsumptionDetail
        {
            get;
            set;
        }

        /// <summary>
        /// Loaded material
        /// </summary>
        [DataMember(Name = "Material", Order = 100)]
        public IMaterial Material
        {
            get;
            set;
        }

        /// <summary>
        /// Past Consumptions
        /// </summary>
        [DataMember(Name = "PastConsumptions", Order = 100)]
        public Dictionary<string, List<PalletConsumptionStructure>> PastConsumptions
        {
            get;
            set;
        }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
