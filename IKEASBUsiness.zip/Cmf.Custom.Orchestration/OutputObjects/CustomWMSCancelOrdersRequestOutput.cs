﻿using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{
    [DataContract(Name = "CustomWMSCancelOrdersRequestOutput")]
    public class CustomWMSCancelOrdersRequestOutput : BaseOutput
    {

        [DataMember(Name = "FactoryAutomationJobId", Order = 10)]
        public long FactoryAutomationJobId { get; set; }

    }
}
