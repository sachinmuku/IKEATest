﻿using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{

    /// <summary>
    /// Output Data Contract for the CustomGetDetailsForPalletOutsorting service.
    /// </summary>
    [DataContract(Name = "CustomGetDetailsForPalletOutsorting")]
    public class CustomGetDetailsForPalletOutsortingOutput : BaseOutput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// Outsorted pallet
        /// </summary>
        [DataMember(Name = "OutsortedPallet", Order = 100)]
        public IMaterial OutsortedPallet { get; set; }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
