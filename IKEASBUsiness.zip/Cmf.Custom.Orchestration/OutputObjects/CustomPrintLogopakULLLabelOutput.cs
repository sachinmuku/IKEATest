﻿using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{
    [DataContract(Name = "CustomPrintLogopakULLLabelOutput")]
    public class CustomPrintLogopakULLLabelOutput : BaseOutput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties
        /// <summary>
        /// information collection of all necessary fields to the ULL label
        /// </summary>
        [DataMember(Name = "UllLabelInfo", Order = 100)]
        public UllLabelFields UllLabelInfo
        {
            get;
            set;
        }
        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
