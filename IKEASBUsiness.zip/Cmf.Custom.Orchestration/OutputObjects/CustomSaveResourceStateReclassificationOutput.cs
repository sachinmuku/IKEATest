﻿using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;
using Cmf.Custom.IKEA.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{

    /// <summary>
    /// Output Data Contract for the CustomSaveResourceStateReclassification service
    /// </summary>
    [DataContract(Name = "CustomSaveResourceStateReclassificationOutput")]
    public class CustomSaveResourceStateReclassificationOutput : BaseOutput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// Collection of the _entityFactory.Create<IResource>(); State Reclassification
        /// </summary>
        [DataMember(Name = "CustomResourceStateReclassificationCollection", Order = 100)]
        public ICustomResourceStateReclassificationCollection CustomResourceStateReclassificationCollection
        {
            get;
            set;
        }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
