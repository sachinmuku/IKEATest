﻿using Cmf.Foundation.BusinessOrchestration;
using Cmf.Navigo.BusinessObjects;
using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{
    /// <summary>
    /// Input Data Contract for the CustomPrintLabelUnitLoading service
    /// </summary>
    [DataContract(Name = "CustomPrintLabelUnitLoadingOutput")]
    public class CustomPrintLabelUnitLoadingOutput : BaseOutput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties
        [DataMember(Name = "PalletNumber", Order = 0)]
        public string PalletNumber { get; set; }

        [DataMember(Name = "SsccBarcode", Order = 1)]
        public string SsccBarcode { get; set; }
        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
