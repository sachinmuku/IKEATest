﻿using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{
    /// <summary>
    /// Output Data for the NiceLabel messages
    /// </summary>
    [DataContract(Name = "CustomNiceLabelMessageOutput")]
    public class CustomNiceLabelMessageOutput : BaseOutput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties
        /// <summary>
        /// NiceLabel Message - Name of the printing queue material that was removed
        /// </summary>
        [DataMember(Name = "MaterialName", Order = 100)]
        public string MaterialName
        {
            get;
            set;
        }

        /// <summary>
        /// NiceLabel Message - Name of the Integration Entry created
        /// </summary>
        [DataMember(Name = "IntegrationEntryName", Order = 200)]
        public string IntegrationEntryName
        {
            get;
            set;
        }
        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
