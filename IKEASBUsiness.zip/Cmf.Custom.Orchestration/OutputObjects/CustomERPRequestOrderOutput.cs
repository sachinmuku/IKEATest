﻿using Cmf.Foundation.BusinessOrchestration;
using Cmf.Navigo.BusinessObjects;
using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{
    /// <summary>
    /// Output Data Contract for the CustomERPRequestOrder service
    /// </summary>
    [DataContract(Name = "CustomERPRequestOrderOutput")]
    public class CustomERPRequestOrderOutput : BaseOutput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties
        /// <summary>
        /// Object received by ERP
        /// </summary>
        [DataMember(Name = "ServiceOutput", Order = 10)]
        public Object ServiceOutput { get; set; }
        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
