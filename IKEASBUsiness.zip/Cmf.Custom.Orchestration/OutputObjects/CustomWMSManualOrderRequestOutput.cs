﻿using Cmf.Foundation.BusinessOrchestration;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Cmf.Foundation.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{
    /// <summary>
    /// Output Data Contract for the CustomWMSManualOrderRequest service
    /// </summary>
    [DataContract(Name = "CustomWMSManualOrderRequestOutput")]
    public class CustomWMSManualOrderRequestOutput : BaseOutput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// The Material after being attached to the printing queue
        /// </summary>
        [DataMember(Name = "AutomationJobs", Order = 0)]
        public List<IAutomationJob> AutomationJobs { get; set; }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
