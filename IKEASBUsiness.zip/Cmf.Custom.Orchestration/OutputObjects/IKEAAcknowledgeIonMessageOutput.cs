﻿using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;
using Cmf.Foundation.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{
    /// <summary>
    /// Output Data Contract for the IKEAAcknowledgeIonMessage service
    /// </summary>
    [DataContract(Name = "IKEAAcknowledgeIonMessageOutput")]
    public class IKEAAcknowledgeIonMessageOutput : BaseOutput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// Result of the creation of the IE
        /// </summary>
        [DataMember(Name = "Result", Order = 10)]
        public IIntegrationEntry Result { get; set; }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
