﻿using Cmf.Foundation.BusinessOrchestration;
using System;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{
    /// <summary>
    /// Input Data Contract for the CustomGetResourcesForCheckInInput service
    /// </summary>
    [DataContract(Name = "CustomGetChartCurrentShiftLimitsOutput")]
    public class CustomGetChartCurrentShiftLimitsOutput : BaseOutput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties
        [DataMember(Name = "HasShift", Order = 1)]

        public Boolean HasShift { get; set; }

        [DataMember(Name = "StartShift", Order = 2)]
        public TimeSpan StartShift { get; set; }

        [DataMember(Name = "EndShift", Order = 3)]
        public TimeSpan EndShift { get; set; }

        [DataMember(Name = "Calendar", Order = 4)]
        public ICalendar Calendar { get; set; }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
