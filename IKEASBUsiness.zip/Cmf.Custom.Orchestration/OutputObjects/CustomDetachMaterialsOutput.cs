using Cmf.Foundation.BusinessOrchestration;
using System;
using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{
    /// <summary>
    /// Output Data Contract for the CustomDetachMaterialsOutput service
    /// </summary>
    [DataContract(Name = "CustomDetachMaterialsOutput")]
    public class CustomDetachMaterialsOutput : BaseOutput
    {
        /// <summary>
        /// Result indicating if the material was Detach
        /// </summary>
        [DataMember(Name = "Result", Order = 10)]
        public bool Result { get; set; }
    }
}
