﻿using Cmf.Foundation.BusinessOrchestration;
using Cmf.Navigo.BusinessObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{
    /// <summary>
    /// Output Data Contract for the CustomERPCommunicationTestInput service
    /// </summary>
    [DataContract(Name = "CustomERPCommunicationTestOutput")]
    public class CustomERPCommunicationTestOutput : BaseOutput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// Object received by ERP
        /// </summary>
        [DataMember(Name = "ServiceOutput", Order = 10)]
        public Object ServiceOutput { get; set; }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
