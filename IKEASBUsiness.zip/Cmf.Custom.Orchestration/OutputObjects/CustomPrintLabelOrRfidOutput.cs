﻿using Cmf.Foundation.BusinessOrchestration;
using Cmf.Navigo.BusinessObjects;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{
    /// <summary>
    /// Output Data Contract for the CustomPrintLabelOrRfidOutput service
    /// </summary>
    [DataContract(Name = "CustomPrintLabelOrRfidOutput")]
    public class CustomPrintLabelOrRfidOutput : BaseOutput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// <see cref="PrintableDocumentCollection"/> of objects that were previewed
        /// </summary>
        [DataMember(Name = "PrintableDocuments", Order = 0)]
        public IPrintableDocumentCollection PrintableDocuments { get; set; }

        /// <summary>
        /// <see cref="PrintedRfid"/> 
        /// </summary>
        [DataMember(Name = "PrintedRfid", Order = 1)]
        public bool PrintedRfid { get; set; }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
