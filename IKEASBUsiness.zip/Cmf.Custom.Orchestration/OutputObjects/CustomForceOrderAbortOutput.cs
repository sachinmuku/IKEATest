﻿using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{

    /// <summary>
    /// Output Data Contract for the CustomForceOrderAbort service
    /// </summary>
    [DataContract(Name = "CustomForceOrderAbortOutput")]
    public class CustomForceOrderAbortOutput : BaseOutput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// Indicates if it successfully forced the Abort of the MO
        /// </summary>
        [DataMember(Name = "Success", Order = 1)]
        public bool Success
        {
            get;
            set;
        }

        /// <summary>
        /// The Process Order material after all the transformations
        /// </summary>
        [DataMember(Name = "Material", Order = 2)]
        public IMaterial Material
        {
            get;
            set;
        }

        /// <summary>
        /// The newly generated process loss unit
        /// </summary>
        [DataMember(Name = "ProcessLossUnit", Order = 3)]
        public IMaterial ProcessLossUnit
        {
            get;
            set;
        }
        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
