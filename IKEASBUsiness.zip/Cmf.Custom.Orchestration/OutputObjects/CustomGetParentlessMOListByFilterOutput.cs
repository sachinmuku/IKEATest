﻿using System.Collections.Generic;
using System.Runtime.Serialization;
using Cmf.Foundation.BusinessOrchestration;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{
    /// <summary>
    /// Output Data Contract for the CustomGetParentlessMOListByFilterOutput service
    /// </summary>
    [DataContract(Name = "CustomGetParentlessMOListByFilterOutput")]
    public class CustomGetParentlessMOListByFilterOutput : BaseOutput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// List of 10 materials without parent groupMO
        /// </summary>
        [DataMember(Name = "Materials", Order = 0)]
        public List<IMaterial> Materials { get; set; }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
