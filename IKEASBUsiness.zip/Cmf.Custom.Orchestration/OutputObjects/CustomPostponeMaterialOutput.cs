﻿using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{
    /// <summary>
    /// Output Data Contract for the CustomPostponeMaterialOutput service
    /// </summary>
    [DataContract(Name = "CustomPostponeMaterialOutput")]
    public class CustomPostponeMaterialOutput : BaseOutput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// Result indicating if the material was postpone
        /// </summary>
        [DataMember(Name = "Result", Order = 10)]
        public bool Result { get; set; }

        /// <summary>
        /// Material postponed
        /// </summary>
        [DataMember(Name = "Material", Order = 10)]
        public IMaterial Material { get; set; }

        /// <summary>
        /// Resource where the material is dispatched
        /// </summary>
        [DataMember(Name = "Resource", Order = 10)]
        public IResource Resource { get; set; }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
