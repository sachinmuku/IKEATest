﻿using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{
    /// <summary>
    /// Output Data Contract for the CustomCompleteOutsortedPalletOutput service
    /// </summary>
    [DataContract(Name = "CustomCompleteOutsortedPalletOutput")]
    public class CustomCompleteOutsortedPalletOutput : BaseOutput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// Completed pallet
        /// </summary>
        [DataMember(Name = "Material", Order = 100)]
        public IMaterial Material
        {
            get;
            set;
        }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
