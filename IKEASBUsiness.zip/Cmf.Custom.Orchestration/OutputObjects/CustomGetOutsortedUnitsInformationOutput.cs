﻿using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Foundation.BusinessOrchestration;
using Cmf.Foundation.Security;
using Cmf.Navigo.BusinessObjects;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{

    /// <summary>
    /// Output Data Contract for the CustomGetOutsortedUnitsInformationOutput service
    /// </summary>
    [DataContract(Name = "CustomGetOutsortedUnitsInformationOutput")]
    public class CustomGetOutsortedUnitsInformationOutput : BaseOutput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// Reply from EI regarding Outsorted Quantity of a given resource
        /// </summary>
        [DataMember(Name = "EIReply", Order = 0)]
        public List<ProductionCounterStructure> EIReply
        {
            get;
            set;
        }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
