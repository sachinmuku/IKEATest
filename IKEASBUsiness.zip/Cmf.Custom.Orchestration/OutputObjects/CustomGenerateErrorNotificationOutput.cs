﻿using System.Runtime.Serialization;
using Cmf.Foundation.BusinessOrchestration;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{
    /// <summary>
    /// Output data for the error Notification
    /// </summary>
    [DataContract(Name = "CustomGenerateErrorNotificationOutput")]
    public class CustomGenerateErrorNotificationOutput : BaseOutput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion
    }
}
