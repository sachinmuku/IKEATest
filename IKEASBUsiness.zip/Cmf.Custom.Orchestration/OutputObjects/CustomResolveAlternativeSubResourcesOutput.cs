﻿using Cmf.Foundation.BusinessOrchestration;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{
    /// <summary>
    /// Output Data Contract for the CustomResolveAlternativeSubResources service
    /// </summary>
    [DataContract(Name = "CustomResolveAlternativeSubResourcesOutput")]
    public class CustomResolveAlternativeSubResourcesOutput : BaseOutput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// Relation between BOMProducts and the Original Resource mapped to them (based on the Process Segment and SubProcess Segment attributes)
        /// </summary>
        [DataMember(Name = "OriginalResources", Order = 0)]
        public Dictionary<IBOMProduct, IResource> OriginalResources
        {
            get;
            set;
        }

        /// <summary>
        /// Relation between Resource (that exists in the OriginalResources) and the list of alternative resources 
        /// (based on the GT CustomAlternativeSubResources)
        /// </summary>
        [DataMember(Name = "AlternativeResources", Order = 1)]
        public Dictionary<IResource, IResourceCollection> AlternativeResources
        {
            get;
            set;
        }

        /// <summary>
        /// The BOM collection instance (can be null) resolved by this service
        /// </summary>
        [DataMember(Name = "BOMCollection", Order = 2)]
        public IBOMCollection BOMCollection
        {
            get;
            set;
        }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
