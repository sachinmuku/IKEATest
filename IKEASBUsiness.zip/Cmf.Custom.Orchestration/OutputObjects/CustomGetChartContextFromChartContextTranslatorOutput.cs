﻿using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessOrchestration;
using Cmf.Navigo.BusinessObjects;
using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{
    /// <summary>
    /// The chart contexts automatically resolved using <see cref="IKEAConstants.CustomChartContextTranslator"/>
    /// </summary>
    public class CustomGetChartContextFromChartContextTranslatorOutput : BaseOutput
    {
        [DataMember()]
        public Dictionary<string, object> ChartContext { get; set; }

    }
}
