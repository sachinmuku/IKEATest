﻿using System.Runtime.Serialization;
using Cmf.Foundation.BusinessOrchestration;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{
    /// <summary>
    /// Output Data Contract for CustomDirectFeedingCounterPartValidation service.
    /// </summary>
    [DataContract(Name = "CustomDirectFeedingCounterPartValidationOutput")]
    public class CustomDirectFeedingCounterPartValidationOutput : BaseOutput
    {
    }
}
