﻿using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessOrchestration;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessOrchestration.ResourceManagement.OutputObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{
    /// <summary>
    /// Output Data Contract for the CustomGetEmployeeTasksAndAreaNotificationsOutput service
    /// </summary>
    [DataContract(Name = "CustomGetEmployeeTasksAndAreaNotificationsOutput")]
    public class CustomGetEmployeeTasksAndAreaNotificationsOutput : BaseOutput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// EmployeeTasksAndAreaNotification
        /// </summary>
        [DataMember(Name = "EmployeeTasksAndAreaNotification", Order = 10)]
        public List<MaterialRequest> EmployeeTasksAndAreaNotification
        {
            get;
            set;
        }

        /// <summary>
        /// Areas where employee is Checked In
        /// </summary>
        [DataMember(Name = "EmployeeCheckedInAreaIDs", Order = 10)]
        public List<long> EmployeeCheckedInAreaIDs
        {
            get;
            set;
        }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
