﻿using Cmf.Foundation.BusinessOrchestration;
using Cmf.Navigo.BusinessOrchestration.DispatchManagement.OutputObjects;
using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{
    /// <summary>
    /// Output Data Contract for the CustomGetDispatchListForResourceOutput service
    /// </summary>
    [DataContract(Name = "CustomGetDispatchListForResource")]
    public class CustomGetDispatchListForResourceOutput : BaseOutput
    {
        [DataMember(Name = "Output", Order = 0)]
        public GetDispatchListForResourceOutput Output { get; set; }
    }
}
