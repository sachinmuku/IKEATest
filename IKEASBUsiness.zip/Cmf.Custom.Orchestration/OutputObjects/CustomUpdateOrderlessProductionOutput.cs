using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;
namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{
    /// <summary>
    /// Output Data Contract for the CustomUpdateOrderlessProduction service
    /// </summary>
    [DataContract(Name = "CustomUpdateOrderlessProductionOutput")]
    public class CustomUpdateOrderlessProductionOutput : BaseOutput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// Material group order
        /// </summary>
        [DataMember(Name = "GroupOrder", Order = 0)]
        public IMaterial GroupOrder { get; set; }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion

    }
}
