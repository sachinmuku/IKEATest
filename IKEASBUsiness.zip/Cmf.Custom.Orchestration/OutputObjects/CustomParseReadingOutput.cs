﻿using Cmf.Foundation.BusinessOrchestration;
using Cmf.Navigo.BusinessObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{
    /// <summary>
    /// Output Data Contract for the CustomParseReading service
    /// </summary>
    [DataContract(Name = "CustomParseReadingOutput")]
    public class CustomParseReadingOutput : BaseOutput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// Extracted Data from the barcode
        /// </summary>
        [DataMember(Name = "ExtractedData", Order = 0)]
        public Dictionary<string, string> ExtractedData { get; set; }

        /// <summary>
        /// Extracted Data objects from the barcode
        /// </summary>
        [DataMember(Name = "ExtractedDataObjects", Order = 0)]
        public Dictionary<string, object> ExtractedDataObjects { get; set; }


        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
