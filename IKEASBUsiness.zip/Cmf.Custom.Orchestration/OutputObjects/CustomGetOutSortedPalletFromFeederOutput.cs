﻿using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{
    /// <summary>
    /// Output Data Contract for the CustomGetOutSortedPalletFromFeeder service
    /// </summary>
    [DataContract(Name = "CustomGetOutSortedPalletFromFeederOutput")]
    public class CustomGetOutSortedPalletFromFeederOutput : BaseOutput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// The material associated with the resource
        /// </summary>
        [DataMember(Name = "OutsortedPallet", Order = 0)]
        public IMaterial OutsortedPallet { get; set; }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
