﻿using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{
    [DataContract(Name = "CustomWMSOrderRequestOutput")]
    public class CustomWMSOrderRequestOutput : BaseOutput
    {

        [DataMember(Name = "IOID", Order = 10)]
        public long IOID { get; set; }

        [DataMember(Name = "AutomationJobErrorMessage", Order = 2)]
        public string AutomationJobErrorMessage { get; set; }

    }
}
