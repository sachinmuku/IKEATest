﻿using System.Runtime.Serialization;
using Cmf.Foundation.BusinessOrchestration;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{
    /// <summary>
    /// Input Data Contract for the CustomIsMOInSecondLineInProcess service
    /// </summary>
    [DataContract(Name = "CustomIsMOInSecondLineInProcessOutput")]
    public class CustomIsMOInSecondLineInProcessOutput : BaseOutput
    {

        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// The material native data, with Topmost and DepthToTopMost properties
        /// </summary>
        [DataMember(Name = "IsMOInProcess", Order = 1)]
        public bool IsMOInProcess
        {
            get;
            set;
        }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion

    }
}
