﻿using Cmf.Custom.IKEA.Orchestration.DataStructures;
using Cmf.Foundation.BusinessOrchestration;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{
    /// <summary>
    /// Output Data Contract for the CustomResolveAlternativeCyclesTimes service
    /// </summary>
    [DataContract(Name = "CustomResolveAlternativeCyclesTimesOutput")]
    public class CustomResolveAlternativeCyclesTimesOutput : BaseOutput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// The MO
        /// </summary>
        [DataMember(Name = "Material", Order = 100)]
        public IMaterial Material
        {
            get;
            set;
        }

        /// <summary>
        /// The resource
        /// </summary>
        [DataMember(Name = "Resource", Order = 100)]
        public IResource Resource
        {
            get;
            set;
        }

        /// <summary>
        /// Alternative cycle time for material and resource that matches the PO StructureType
        /// </summary>
        [DataMember(Name = "AlternativeCycleTime", Order = 100)]
        public ResourceAlternativeCycleTime AlternativeCycleTime
        {
            get;
            set;
        }

        /// <summary>
        /// Indicates if this material requires an alternative cycle time to be configured for it
        /// </summary>
        [DataMember(Name = "RequiresAlternativeCycleTime", Order = 100)]
        public bool RequiresAlternativeCycleTime
        {
            get;
            set;
        }

        /// <summary>
        /// Property to hold the cycle time is in use 
        /// </summary>
        [DataMember(Name = "CycleTimeInUse", Order = 100)]
        public bool CycleTimeInUse
        {
            get;
            set;
        }

        /// <summary>
        /// Property to hold the names of the materials in process that use the original cycle time. 
        /// Is empty when CycleTimeInUse == false.
        /// </summary>
        [DataMember(Name = "CycleTimeMaterialsInProcess", Order = 100)]
        public List<string> CycleTimeMaterialsInProcess
        {
            get;
            set;
        }

        /// <summary>
        /// The current effective ideal cycle time set for this for material and resource
        /// </summary>
        [DataMember(Name = "OriginalCycleTime", Order = 100)]
        public ResourceAlternativeCycleTime OriginalCycleTime
        {
            get;
            set;
        }
        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
