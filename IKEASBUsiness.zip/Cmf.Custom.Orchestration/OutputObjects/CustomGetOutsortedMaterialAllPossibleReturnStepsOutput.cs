﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using Cmf.Foundation.BusinessOrchestration;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{
    /// <summary>
    /// Output Data Contract for the CustomGetOutsortedMaterialAllPossibleReturnSteps service
    /// </summary>
    [DataContract(Name = "CustomGetOutsortedMaterialAllPossibleReturnStepsOutput")]
    public class CustomGetOutsortedMaterialAllPossibleReturnStepsOutput : BaseOutput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// Outsorted material name for which all possible return steps requested
        /// </summary>
        [DataMember(Name = "MaterialName", Order = 0)]
        public string MaterialName
        {
            get;
            set;
        }

        /// <summary>
        /// All possible return steps for the outsorted material
        /// </summary>
        [DataMember(Name = "Steps", Order = 1)]
        public IStepCollection Steps
        {
            get;
            set;
        }

        /// <summary>
        /// Default return flow path for the outsorted material
        /// </summary>
        [DataMember(Name = "ReturnFlowPath", Order = 2)]
        public string ReturnFlowPath
        {
            get;
            set;
        }

        /// <summary>
        /// Default return flow for the outsorted material
        /// </summary>
        [DataMember(Name = "ReturnFlow", Order = 3)]
        public IFlow ReturnFlow
        {
            get;
            set;
        }

        /// <summary>
        /// Default return step for the outsorted material
        /// </summary>
        [DataMember(Name = "ReturnStep", Order = 4)]
        public IStep ReturnStep
        {
            get;
            set;
        }
        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion
    }
}
