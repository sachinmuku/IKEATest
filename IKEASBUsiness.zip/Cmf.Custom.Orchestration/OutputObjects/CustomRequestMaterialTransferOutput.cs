﻿using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{
    /// <summary>
    /// Output Data Contract for the CustomUpdateBomProductsAttributesOutput service
    /// </summary>
    [DataContract(Name = "CustomRequestMaterialTransferOutput")]
    public class CustomRequestMaterialTransferOutput : BaseOutput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// RequestMaterialMovement created Notification
        /// </summary>
        [DataMember(Name = "RequestMaterialMovementNotification", Order = 0)]
        public INotification RequestMaterialMovementNotification { get; set; }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
