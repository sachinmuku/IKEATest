﻿using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{
    /// <summary>
    /// Input Data Contract for the CustomHandleGroupManufacturingOrders service
    /// </summary>
    [DataContract(Name = "CustomHandleGroupManufacturingOrdersOutput")]
    public class CustomHandleGroupManufacturingOrdersOutput : BaseOutput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties
        [DataMember(Name = "GroupMaterialOrder", Order = 1)]
        public IMaterial GroupMaterialOrder { get; set; }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
