﻿using Cmf.Foundation.BusinessOrchestration;
using Cmf.Foundation.Security;
using Cmf.Navigo.BusinessObjects;
using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{

    /// <summary>
    /// Output Data Contract for the CustomForceUnitCompletion service
    /// </summary>
    [DataContract(Name = "CustomForceUnitCompletionOutput")]
    public class CustomForceUnitCompletionOutput : BaseOutput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// Indicates if it successfully forced the completion of the MO
        /// </summary>
        [DataMember(Name = "Success", Order = 100)]
        public bool Success
        {
            get;
            set;
        }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
