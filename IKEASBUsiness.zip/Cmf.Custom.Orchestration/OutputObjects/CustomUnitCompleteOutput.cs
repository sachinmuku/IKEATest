﻿using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{
    /// <summary>
    /// Output Data Contract for the CustomUnitCompleteOutput service
    /// </summary>
    [DataContract(Name = "CustomUnitCompleteOutput")]
    public class CustomUnitCompleteOutput : BaseOutput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// Updated material from where the completed tracking unit was generated
        /// </summary>
        [DataMember(Name = "ProcessOrderMaterial", Order = 10)]
        public IMaterial ProcessOrderMaterial { get; set; }

        /// <summary>
        /// Completed Unit Material
        /// </summary>
        [DataMember(Name = "CompletedUnit", Order = 10)]
        public IMaterial CompletedUnit { get; set; }

        /// <summary>
        /// Completed Quantity
        /// </summary>
        [DataMember(Name = "CompletedQuantity", Order = 10)]
        public decimal CompletedQuantity { get; set; }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
