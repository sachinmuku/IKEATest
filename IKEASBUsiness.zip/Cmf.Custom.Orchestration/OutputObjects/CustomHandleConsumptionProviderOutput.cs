﻿using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{
    /// <summary>
    /// Output Data Contract for the CustomHandleConsumptionProvider service
    /// </summary>
    [DataContract(Name = "CustomHandleConsumptionProviderOutput")]
    public class CustomHandleConsumptionProviderOutput : BaseOutput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// Resource that is configured as the Consumption provider
        /// </summary>
        [DataMember(Name = "ConsumptionProvider", Order = 10)]
        public IResource ConsumptionProvider
        {
            get;
            set;
        }

        /// <summary>
        /// Aditional resources that will be used together with the main feeder
        /// </summary>
        [DataMember(Name = "DistributedConsumptionProviders", Order = 10)]
        public IResourceCollection DistributedConsumptionProviders
        {
            get;
            set;
        }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
