﻿using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;
namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{
    /// <summary>
    /// Output Data Contract for the CustomGetAutomationVariables service
    /// </summary>
    [DataContract(Name = "CustomGetAutomationVariablesOutput")]
    public class CustomGetAutomationVariablesOutput : BaseOutput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// Automation Variables Details
        /// </summary>
        [DataMember(Name = "CustomGetAutomationVariableDetailCollection", Order = 100)]
        public CustomGetAutomationVariableDetailCollection CustomGetAutomationVariableDetailCollection { get; set; } = new CustomGetAutomationVariableDetailCollection();

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
