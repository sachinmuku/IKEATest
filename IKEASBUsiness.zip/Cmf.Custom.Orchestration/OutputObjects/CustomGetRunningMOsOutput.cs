﻿using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;
using Cmf.Foundation.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{
    /// <summary>
    /// Output Data Contract for the CustomGetRunningMOs service
    /// </summary>
    [DataContract(Name = "CustomGetRunningMOsOutput")]
    public class CustomGetRunningMOsOutput : BaseOutput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// Running MOs
        /// </summary>
        [DataMember(Name = "Materials", Order = 100)]
        public INgpDataSet Materials { get; set; }

        /// <summary>
        /// Refresh rate for the GUI
        /// </summary>
        [DataMember(Name = "RefreshRate", Order = 100)]
        public int RefreshRate { get; set; }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
