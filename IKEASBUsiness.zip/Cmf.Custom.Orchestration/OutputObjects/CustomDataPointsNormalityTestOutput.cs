﻿using Cmf.Foundation.BusinessOrchestration;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{
    [DataContract(Name = "CustomDataPointsNormalityTestOutput")]
    public class CustomDataPointsNormalityTestOutput : BaseOutput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// The Normal Distribution Mean
        /// </summary>
        [DataMember(Name = "Mean", Order = 100)]
        public double Mean
        {
            get;
            set;
        }

        /// <summary>
        /// The Normal Distribution Median
        /// </summary>
        [DataMember(Name = "Median", Order = 100)]
        public double Median
        {
            get;
            set;
        }

        /// <summary>
        /// The Normal Distribution Standard Deviation
        /// </summary>
        [DataMember(Name = "StdDeviation", Order = 100)]
        public double StdDeviation
        {
            get;
            set;
        }

        /// <summary>
        /// The Normal Distribution Variance
        /// </summary>
        [DataMember(Name = "Variance", Order = 100)]
        public double Variance
        {
            get;
            set;
        }

        /// <summary>
        /// The Normal Distribution Skewness
        /// </summary>
        [DataMember(Name = "Skewness", Order = 100)]
        public double Skewness
        {
            get;
            set;
        }

        /// <summary>
        /// The Normal Distribution Kurtosis
        /// </summary>
        [DataMember(Name = "Kurtosis", Order = 100)]
        public double Kurtosis
        {
            get;
            set;
        }


        /// <summary>
        /// The data points series (for the chart X axis)
        /// </summary>
        [DataMember(Name = "DataPointsX", Order = 100)]
        public IList<double> DataPointsX
        {
            get;
            set;
        }

        /// <summary>
        /// The inverse normal distribution function output values (for the chart Y axis)
        /// </summary>
        [DataMember(Name = "DataPointsY", Order = 100)]
        public IList<double> DataPointsY
        {
            get;
            set;
        }

        /// <summary>
        /// The data points series (for the chart X axis)
        /// </summary>
        [DataMember(Name = "TrendLineX", Order = 100)]
        public IList<double> TrendLineX
        {
            get;
            set;
        }

        /// <summary>
        /// The trend line points series in Y
        /// </summary>
        [DataMember(Name = "TrendLineY", Order = 100)]
        public IList<double> TrendLineY
        {
            get;
            set;
        }


        /// <summary>
        /// The trend line points series in Y
        /// </summary>
        [DataMember(Name = "Histogram", Order = 100)]
        public INormalDistributionIntervalCollection Histogram
        {
            get;
            set;
        }

        /// <summary>
        /// The Gaussian Curve to show together with the histogram
        /// </summary>
        [DataMember(Name = "GaussianCurve", Order = 100)]
        public Dictionary<double, double> GaussianCurve
        {
            get;
            set;
        }

        /// <summary>
        /// The Histogram LowerBound
        /// </summary>
        [DataMember(Name = "HistogramLowerBound", Order = 100)]
        public double HistogramLowerBound
        {
            get;
            set;
        }

        /// <summary>
        /// The Histogram UpperBound
        /// </summary>
        [DataMember(Name = "HistogramUpperBound", Order = 100)]
        public double HistogramUpperBound
        {
            get;
            set;
        }


        /// <summary>
        /// The AndersonDarling result statistic (AD)
        /// </summary>
        [DataMember(Name = "AndersonDarlingStatistic", Order = 100)]
        public double AndersonDarlingAD
        {
            get;
            set;
        }

        /// <summary>
        /// The AndersonDarling P Value
        /// </summary>
        [DataMember(Name = "AndersonDarlingPValue", Order = 100)]
        public double AndersonDarlingPValue
        {
            get;
            set;
        }

        /// <summary>
        /// The AndersonDarling result sucess:
        /// </summary>
        [DataMember(Name = "AndersonDarlingTestSucess", Order = 100)]
        public bool AndersonDarlingTestSucess
        {
            get;
            set;
        }

        /// <summary>
        /// Error message to show in GUI:
        /// </summary>
        [DataMember(Name = "ErrorMessage", Order = 100)]
        public string ErrorMessage
        {
            get;
            set;
        }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
