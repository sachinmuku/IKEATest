﻿using Cmf.Foundation.BusinessOrchestration;
using System.Collections.Generic;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{
    /// <summary>
    /// Output Data Contract for the CustomGetResourcesForCheckInOutput service
    /// </summary>
    [DataContract(Name = "CustomGetResourcesForCheckInOutput")]
    public class CustomGetResourcesForCheckInOutput : BaseOutput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// Areas for check In
        /// </summary>
        [DataMember(Name = "ResourcesForCheckIn", Order = 0)]
        public List<IResource> ResourcesForCheckIn
        {
            get;
            set;
        }
        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
