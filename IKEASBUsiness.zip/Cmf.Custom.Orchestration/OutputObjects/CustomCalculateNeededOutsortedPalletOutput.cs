﻿using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{
    /// <summary>
    /// Output Data Contract for the CustomCalculateNeededOutsortedPalletOutput service
    /// </summary>
    [DataContract(Name = "CustomCalculateNeededOutsortedPalletOutput")]
    public class CustomCalculateNeededOutsortedPalletOutput : BaseOutput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// Pallet default Quantity
        /// </summary>
        [DataMember(Name = "DefaultCompletionQuantity", Order = 100)]
        public decimal DefaultCompletionQuantity
        {
            get;
            set;
        }

        /// <summary>
        /// Necessary quantity for pallet already in line to reach Default Completion Quantity
        /// </summary>
        [DataMember(Name = "ExistingPalletQuantity", Order = 100)]
        public decimal ExistingPalletQuantity
        {
            get;
            set;
        }

        /// <summary>
        /// Boolean value that represents if pallet already in line has reached Default Completion Quantity
        /// </summary>
        [DataMember(Name = "IsExistingPalletCompleted", Order = 100)]
        public bool IsExistingPalletCompleted
        {
            get;
            set;
        }

        /// <summary>
        /// Number of New Pallets that reached Default Completion Quantity
        /// </summary>
        [DataMember(Name = "NumberOfCompletedPallets", Order = 100)]
        public decimal NumberOfCompletedPallets
        {
            get;
            set;
        }

        /// <summary>
        /// Quantity of Pallet that did not reach Default Completion Quantity
        /// </summary>
        [DataMember(Name = "IncompletePalletQuantity", Order = 100)]
        public decimal IncompletePalletQuantity
        {
            get;
            set;
        }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
