﻿using Cmf.Foundation.BusinessOrchestration;
using Cmf.Navigo.BusinessObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{
    /// <summary>
    /// Output Data Contract for the CustomLogAlarmOccurrence service
    /// </summary>
    [DataContract(Name = "CustomLogAlarmOccurrenceOutput")]
    public class CustomLogAlarmOccurrenceOutput : BaseOutput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// AlarmOccurrence Unique ID
        /// </summary>
        [DataMember(Name = "AlarmOccurrenceUID", Order = 1)]
        public long? AlarmOccurrenceUID { get; set; }

        /// <summary>
        /// Flag that indicates if alarm is to interlock line 
        /// </summary>
        [DataMember(Name = "IsToBlockFeeder", Order = 2)]
        public bool IsToBlockFeeder { get; set; }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
