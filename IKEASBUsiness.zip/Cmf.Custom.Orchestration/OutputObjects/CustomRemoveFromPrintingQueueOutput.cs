﻿using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{
    /// <summary>
    /// Input Data Contract for the CustomRemoveFromPrintingQueue service
    /// </summary>
    [DataContract(Name = "CustomRemoveFromPrintingQueueOutput")]
    public class CustomRemoveFromPrintingQueueOutput : BaseOutput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// The Material detached from the printing queue
        /// </summary>
        [DataMember(Name = "Material", Order = 0)]
        public IMaterial Material { get; set; }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
