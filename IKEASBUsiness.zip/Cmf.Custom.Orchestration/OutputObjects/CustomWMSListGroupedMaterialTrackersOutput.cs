﻿using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Foundation.BusinessOrchestration;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{
    /// <summary>
    /// Output Data Contract for the CustomWMSListGroupedMaterialTrackers service
    /// </summary>
    [DataContract(Name = "CustomWMSListGroupedMaterialTrackersOutput")]
    public class CustomWMSListGroupedMaterialTrackersOutput : BaseOutput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// The Material after being attached to the printing queue
        /// </summary>
        [DataMember(Name = "GroupedInventoryOrders", Order = 0)]        
        public List<GroupedInventoryOrders> GroupedInventoryOrders { get; set; }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
