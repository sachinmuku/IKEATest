﻿using Cmf.Foundation.BusinessOrchestration;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessOrchestration.ResourceManagement.OutputObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{
    /// <summary>
    /// Output Data Contract for the CustomUpdateBomProductsAttributesOutput service
    /// </summary>
    [DataContract(Name = "CustomUpdateBomProductsAttributesOutput")]
    public class CustomUpdateBomProductsAttributesOutput : BaseOutput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
