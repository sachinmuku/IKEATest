﻿using Cmf.Foundation.BusinessOrchestration;
using System;
using System.Runtime.Serialization;
using Cmf.Foundation.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{

    /// <summary>
    /// Output Data Contract for the CustomGetDataForPPM service
    /// </summary>
    [DataContract(Name = "CustomGetDataForPPMOutput")]
    public class CustomGetDataForPPMOutput : BaseOutput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// YieldAndCycleTime
        /// </summary>
        [DataMember(Name = "YieldAndCycleTime", Order = 0)]
        public INgpDataSet YieldAndCycleTime { get; set; }

        /// <summary>
        /// ReasonsFrequencyAndPercentage
        /// </summary>
        [DataMember(Name = "ReasonsFrequencyAndPercentage", Order = 0)]
        public INgpDataSet ReasonsFrequencyAndPercentage { get; set; }

        /// <summary>
        /// ShowDecimals
        /// </summary>
        [DataMember(Name = "ShowDecimals", Order = 0)]
        public Boolean ShowDecimals { get; set; }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
