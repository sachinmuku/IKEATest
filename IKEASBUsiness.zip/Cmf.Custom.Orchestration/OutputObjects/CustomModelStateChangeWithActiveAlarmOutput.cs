﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.Text;
using Cmf.Foundation.BusinessOrchestration;
using Cmf.Navigo.BusinessObjects;
using DocumentFormat.OpenXml.Wordprocessing;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{
    /// <summary>
    /// Output Data Contract for the CustomPostDataToCharts service
    /// </summary>
    [DataContract(Name = "CustomModelStateChangeWithActiveAlarmOutput")]
    public class CustomModelStateChangeWithActiveAlarmOutput : BaseOutput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        ///Updated State handled by the Service
        /// </summary>
        [DataMember(Name = "State", Order = 1)]
        public string State { get; set; }

        /// <summary>
        ///Updated Reason handled by the service
        /// </summary>
        [DataMember(Name = "Reason", Order = 1)]
        public string Reason { get; set; }

        /// <summary>
        ///Boolean to prevent OEE configuration State in case there are no alarms active
        /// </summary>
        [DataMember(Name = "IsToPreventOEEConfigurationState", Order = 1)]
        public bool IsToPreventOEEConfigurationState { get; set; }

        /// <summary>
        ///Boolean to block OEE State recalculation in case there is an alarm blocking the state
        /// </summary>
        [DataMember(Name = "IsToBlockOEECalculation", Order = 1)]
        public bool IsToBlockOEECalculation { get; set; }

        /// <summary>
        ///Updated Alarm that is blocking the resource OEE State
        /// </summary>
        [DataMember(Name = "AlarmIDBlockingOEECalculation", Order = 1)]
        public string AlarmIDBlockingOEECalculation { get; set; }


        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
