﻿using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{

    /// <summary>
    /// Output Data Contract for the CustomValidateCompleteConditions service
    /// </summary>
    [DataContract(Name = "CustomValidateCompleteConditionsOutput")]
    public class CustomValidateCompleteConditionsOutput : BaseOutput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// Indicates if it is to open the wizard
        /// </summary>
        [DataMember(Name = "IsToOpenWizard", Order = 0)]
        public bool IsToOpenWizard
        {
            get;
            set;
        }

        /// <summary>
        /// Indicates if the complete is allowed. Only used when the wizard is to open
        /// </summary>
        [DataMember(Name = "IsCompleteAllowed", Order = 0)]
        public bool? IsCompleteAllowed
        {
            get;
            set;
        }

        /// <summary>
        /// Indicates the IoT remaining quantity to consume. Only used when the wizard is to open
        /// </summary>
        [DataMember(Name = "RemainingQuantity", Order = 0)]
        public decimal? RemainingQuantity
        {
            get;
            set;
        }
        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
}
