﻿using Cmf.Custom.IKEA.Orchestration.DataStructures;
using Cmf.Foundation.BusinessObjects.QueryObject;
using Cmf.Foundation.BusinessOrchestration;
using Cmf.Navigo.BusinessObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{
    /// <summary>
    /// Output Data Contract for the CustomGetDataForPalletLocationOutput service
    /// </summary>
    [DataContract(Name = "CustomGetDataForPalletLocationOutput")]
    public class CustomGetDataForPalletLocationOutput : BaseOutput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        // <summary>
        // Gets or sets PalletLocationCollection output
        // </summary>
        [DataMember(Name = "PalletLocationCollection", Order = 0)]
        public PalletLocationCollection PalletLocationCollection
        {
            get;

            set;
        }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion
    }
 }
