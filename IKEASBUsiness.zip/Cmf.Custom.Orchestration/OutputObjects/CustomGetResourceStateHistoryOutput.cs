﻿using Cmf.Foundation.BusinessOrchestration;
using System.Runtime.Serialization;
using Cmf.Foundation.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Orchestration.OutputObjects
{
    /// <summary>
    /// Output Data Contract for the CustomGetResourceStateHistory service
    /// </summary>
    [DataContract(Name = "CustomGetResourceStateHistoryOutput")]
    public class CustomGetResourceStateHistoryOutput : BaseOutput
    {
        #region Private Variables
        #endregion

        #region Public Variables
        #endregion

        #region Properties

        /// <summary>
        /// Resource State History
        /// </summary>
        [DataMember(Name = "ResourceStateHistory", Order = 100)]
        public INgpDataSet ResourceStateHistory { get; set; }

        #endregion

        #region Constructors
        #endregion

        #region Private & Internal Methods
        #endregion

        #region Public Methods
        #endregion

        #region Event handling Methods
        #endregion

    }
}
