using Cmf.Custom.IKEA.Orchestration.Abstractions;
using Cmf.Foundation.Services.HostStartup;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;

namespace Cmf.Custom.IKEA.Orchestration
{

    public class OrchestrationStartupModule : IStartupModule
    {
        public MiddlewarePositioning MiddlewarePositioning => MiddlewarePositioning.None;

        public int ServiceRegistrationOrder => 0;

        public void Configure(IApplicationBuilder app, ConfigureMiddlewareContext context)
        {
        }

        public void ConfigureRootServices(IServiceCollection services)
        {
        }

        public void ConfigureServices(IServiceCollection services, ConfigureServicesContext context)
        {
            services.AddTransient<IIKEABusinessManagementOrchestration, IKEABusinessManagementOrchestration>();
            services.AddTransient<IIKEAOrchestration, IKEAOrchestration>();
        }
    }
}