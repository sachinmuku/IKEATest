﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Custom.IKEA.BusinessObjects;
using Cmf.Custom.IKEA.BusinessObjects.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Extensions;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;

using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace Cmf.Custom.IKEA.Actions.Resources
{
    public class CustomERPOperationTrackingResource : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     On track-in of the materials, if no UsedResource is defined in the CustomERPOperationTracking
            ///     it will set it with the resource where the material is being tracked in
            /// Action Groups:
            ///     BusinessObjects.MaterialCollection.TrackIn.Post
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.MaterialCollection.TrackIn.Post",
            };

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            if (executionVeridict
                && IKEADEEActionUtilities.GetInputItem<IMaterialCollection>(Input, "MaterialCollection") == null
                && IKEADEEActionUtilities.GetInputItem<IResource>(Input, "Resource") == null)
            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            //System
            UseReference("", "Cmf.Custom.IKEA.BusinessObjects.Abstractions");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("", "System");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            //Custom
            UseReference("Cmf.Custom.IKEA.BusinessObjects.CustomERPOperationTracking.dll", "Cmf.Custom.IKEA.BusinessObjects");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Extensions");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();

            IMaterialCollection materials = IKEADEEActionUtilities.GetInputItem<IMaterialCollection>(Input, "MaterialCollection");
            IResource resource = IKEADEEActionUtilities.GetInputItem<IResource>(Input, "Resource");

            ICustomERPOperationTrackingCollection erpOperationTrackings = entityFactory.CreateCollection<ICustomERPOperationTrackingCollection>();

            foreach (IMaterial material in materials)
            {
                // Get the ERPOperationTracking for the material and ERP Operation code
                ICustomERPOperationTracking erpOperationTracking = material.GetCurrentCustomERPOperatingTracking(false);

                // If no Used Resource is defined, set for the one where the material is being tracked in
                if (erpOperationTracking != null && string.IsNullOrWhiteSpace(erpOperationTracking.OrderResource))
                {
                    erpOperationTracking.OrderResource = resource.Name;
                    erpOperationTrackings.Add(erpOperationTracking);
                }
            }

            // Check if there are any CustomERPOperationTracking to update
            if (!erpOperationTrackings.IsNullOrEmpty())
            {
                erpOperationTrackings.Save();
            }

            //---End DEE Code---

            return Input;
        }
    }
}
