﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Extensions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Foundation.Security;
using Cmf.Foundation.Security.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.ResourceManagement.InputObjects;
using Cmf.Navigo.BusinessOrchestration.ResourceManagement.OutputObjects;
using Microsoft.Extensions.DependencyInjection;

using System;
using Cmf.Custom.IKEA.Common.DEE;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;

namespace Cmf.Custom.IKEA.Actions.Resources
{
    public class CustomResourceStateChangesNotification : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Dee rule to notification a distribution list when the resource state changes [e.g.: Engineering --> Standby]
            /// Action Groups:
            ///     BusinessObjects.Resource.LogEvent.Post
            ///     BusinessObjects.ResourceCollection.Save.Pre
            ///     BusinessObjects.ResourceCollection.Save.Post
            ///     ResourceManagement.ResourceManagementOrchestration.FullUpdateResource.Pre (optional)
            ///     ResourceManagement.ResourceManagementOrchestration.FullUpdateResource.Post (optional)
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.Resource.LogEvent.Pre",
                "BusinessObjects.Resource.LogEvent.Post",
                "BusinessObjects.ResourceCollection.Save.Pre",
                "BusinessObjects.ResourceCollection.Save.Post",
                "ResourceManagement.ResourceManagementOrchestration.FullUpdateResource.Pre",
                "ResourceManagement.ResourceManagementOrchestration.FullUpdateResource.Post"
            };

            // only proceed if within expected triggers (action groups)
            return IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            //System
            UseReference("", "System");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("", "System.Linq");
            UseReference("", "System.Text");

            //Foundation
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.Common.dll", "Cmf.Foundation.Common");
            UseReference("Cmf.Foundation.Security.dll", "Cmf.Foundation.Security");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration");
            UseReference("", "Cmf.Foundation.Common");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.ResourceManagement.InputObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.ResourceManagement.OutputObjects");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Extensions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");


            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();

            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            ILocalizedMessage localizedMessage = serviceProvider.GetService<ILocalizedMessage>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();

            //DEE context 
            DeeContext currentDEEContext = deeContextUtilities.SetCurrentServiceContext("CustomResourceStateChangesNotification");

            IResource resource = null;
            string transitionName = null;
            string serviceComments = null;

            string currentContext = IKEAConstants.CustomNotificationResourcesChangeState + "_" + IKEAConstants.CustomNotificationResourcesChangeStateInitialStateTransition;

            Dictionary<long, ResourceStateChangesStructure> resourceStates = new Dictionary<long, ResourceStateChangesStructure>();

            string actionGroupName = IKEADEEActionUtilities.GetActionGroup(Input);

            switch (currentDEEContext.MethodName)
            {
                // BusinessObjects.Resource.LogEvent.Post
                case "LogEvent":
                    {
                        if (currentDEEContext.TriggerPoint == DeeTriggerPoint.Pre)
                        {
                            ResourceStateChangesStructure resourceStateChanges = new ResourceStateChangesStructure();

                            IResource logEventResource = IKEADEEActionUtilities.GetInputItem<IResource>(Input, "Resource");

                            // Check if there is a transition and state model defined
                            if (logEventResource != null)
                            {
                                resource = entityFactory.Create<IResource>();
                                resource.Load(logEventResource.Name);

                                if (resource.CurrentMainState != null && resource.CurrentMainState.CurrentState != null)
                                {
                                    resourceStateChanges.Resource = resource;
                                    resourceStateChanges.ResourceMainStateModel = resource.CurrentMainState != null ? resource.CurrentMainState.StateModel : null;
                                    resourceStateChanges.InitialStateModelState = resource.CurrentMainState.CurrentState;
                                    resourceStateChanges.InitialStateReason = resource.CurrentMainState.Reason;

                                    resourceStates.Add(resource.Id, resourceStateChanges);
                                }

                                deeContextUtilities.SetContextParameter(currentContext, resourceStates);

                            }
                        }
                        else if (currentDEEContext.TriggerPoint == DeeTriggerPoint.Post)
                        {
                            IResource logEventResource = IKEADEEActionUtilities.GetInputItem<IResource>(Input, "Resource");

                            if (logEventResource != null)
                            {
                                resource = entityFactory.Create<IResource>();
                                resource.Load(logEventResource.Name);

                                if (resource.CurrentMainState != null && resource.CurrentMainState.CurrentState != null)
                                {
                                    resourceStates = deeContextUtilities.GetContextParameter(currentContext) as Dictionary<long, ResourceStateChangesStructure>;

                                    if (resourceStates != null)
                                    {
                                        ResourceStateChangesStructure resourceStateChanges;

                                        if (resourceStates.TryGetValue(resource.Id, out resourceStateChanges))
                                        {
                                            resourceStateChanges.Resource = resource;
                                            resourceStateChanges.FinalStateModelState = resource.CurrentMainState.CurrentState;
                                            resourceStateChanges.FinalStateReason = resource.CurrentMainState.Reason;
                                        }
                                    }
                                }
                            }

                            if (!string.IsNullOrWhiteSpace(ApplicationContext.CallContext.HistoryObjectCollection.ServiceComment))
                            {
                                serviceComments = ApplicationContext.CallContext.HistoryObjectCollection.ServiceComment;
                            }
                        }

                        break;
                    }
                // ResourceManagement.ResourceManagementOrchestration.FullUpdateResource
                case "FullUpdateResource":
                    {
                        if (currentDEEContext.TriggerPoint == DeeTriggerPoint.Pre)
                        {
                            ResourceStateChangesStructure resourceStateChanges = new ResourceStateChangesStructure();

                            FullUpdateResourceInput fullUpdateResourceInput = IKEADEEActionUtilities.GetInputItem<FullUpdateResourceInput>(Input, "FullUpdateResourceInput");

                            if (fullUpdateResourceInput != null
                                && fullUpdateResourceInput.Resource != null)
                            {
                                resource = entityFactory.Create<IResource>();
                                resource.Load(fullUpdateResourceInput.Resource.Name);

                                if (resource.CurrentMainState != null && resource.CurrentMainState.CurrentState != null)
                                {
                                    resourceStateChanges.Resource = resource;
                                    resourceStateChanges.ResourceMainStateModel = resource.CurrentMainState != null ? resource.CurrentMainState.StateModel : null;
                                    resourceStateChanges.InitialStateModelState = resource.CurrentMainState.CurrentState;
                                    resourceStateChanges.InitialStateReason = resource.CurrentMainState.Reason;

                                    resourceStates.Add(resource.Id, resourceStateChanges);
                                }

                                deeContextUtilities.SetContextParameter(currentContext, resourceStates);
                            }
                        }
                        else if (currentDEEContext.TriggerPoint == DeeTriggerPoint.Post)
                        {
                            FullUpdateResourceOutput fullUpdateResourceOutput = IKEADEEActionUtilities.GetInputItem<FullUpdateResourceOutput>(Input, "FullUpdateResourceOutput");

                            if (fullUpdateResourceOutput != null
                                && fullUpdateResourceOutput.Resource != null)
                            {
                                resource = entityFactory.Create<IResource>();
                                resource.Load(fullUpdateResourceOutput.Resource.Name);

                                if (resource.CurrentMainState != null && resource.CurrentMainState.CurrentState != null)
                                {
                                    resourceStates = deeContextUtilities.GetContextParameter(currentContext) as Dictionary<long, ResourceStateChangesStructure>;

                                    if (resourceStates != null)
                                    {
                                        ResourceStateChangesStructure resourceStateChanges;

                                        if (resourceStates.TryGetValue(resource.Id, out resourceStateChanges))
                                        {
                                            resourceStateChanges.Resource = resource;
                                            resourceStateChanges.FinalStateModelState = resource.CurrentMainState.CurrentState;
                                            resourceStateChanges.FinalStateReason = resource.CurrentMainState.Reason;
                                        }
                                    }
                                }

                                if (!string.IsNullOrWhiteSpace(ApplicationContext.CallContext.HistoryObjectCollection.ServiceComment))
                                {
                                    serviceComments = ApplicationContext.CallContext.HistoryObjectCollection.ServiceComment;
                                }
                            }
                        }

                        break;
                    }
                // BusinessObjects.ResourceCollection.Save
                case "Save":
                    {
                        IResourceCollection resources = IKEADEEActionUtilities.GetInputItem<IResourceCollection>(Input, "ResourceCollection");
                        if (!resources.IsNullOrEmpty())
                        {
                            if (currentDEEContext.TriggerPoint == DeeTriggerPoint.Pre)
                            {
                                foreach (IResource resourceSaved in resources)
                                {
                                    if (resourceSaved.CurrentMainState != null && resourceSaved.CurrentMainState.CurrentState != null)
                                    {
                                        ResourceStateChangesStructure resourceStateChanges = new ResourceStateChangesStructure();
                                        resourceStateChanges.Resource = resourceSaved;
                                        resourceStateChanges.ResourceMainStateModel = resourceSaved.CurrentMainState != null ? resourceSaved.CurrentMainState.StateModel : null; ;
                                        resourceStateChanges.InitialStateModelState = resourceSaved.CurrentMainState.CurrentState;
                                        resourceStateChanges.InitialStateReason = resourceSaved.CurrentMainState.Reason;

                                        resourceStates.Add(resourceSaved.Id, resourceStateChanges);
                                    }

                                    deeContextUtilities.SetContextParameter(currentContext, resourceStates);
                                }
                            }
                            else if (currentDEEContext.TriggerPoint == DeeTriggerPoint.Post)
                            {
                                resourceStates = deeContextUtilities.GetContextParameter(currentContext) as Dictionary<long, ResourceStateChangesStructure>;

                                foreach (IResource savedResource in resources)
                                {
                                    if (savedResource.CurrentMainState != null && savedResource.CurrentMainState.CurrentState != null)
                                    {
                                        ResourceStateChangesStructure resourceStateChanges;
                                        if (resourceStates.TryGetValue(savedResource.Id, out resourceStateChanges))
                                        {
                                            resourceStateChanges.FinalStateModelState = savedResource.CurrentMainState.CurrentState;
                                            resourceStateChanges.FinalStateReason = savedResource.CurrentMainState.Reason;
                                        }
                                    }
                                }

                                if (!string.IsNullOrWhiteSpace(ApplicationContext.CallContext.HistoryObjectCollection.ServiceComment))
                                {
                                    serviceComments = ApplicationContext.CallContext.HistoryObjectCollection.ServiceComment;
                                }
                            }
                        }
                        break;
                    }
                default:
                    break;
            }

            if (!resourceStates.IsNullOrEmpty())
            {
                foreach (var resourceState in resourceStates)
                {
                    ResourceStateChangesStructure resourceStateChanges = resourceState.Value;

                    if (resourceStateChanges.InitialStateModelState != null
                        && resourceStateChanges.FinalStateModelState != null)
                    {
                        string transitionNameInitial = resourceStateChanges.InitialStateModelState.Name;
                        string transitionNameFinal = resourceStateChanges.FinalStateModelState.Name;

                        if (!transitionNameInitial.CompareStrings(transitionNameFinal))
                        {
                            resource = resourceStateChanges.Resource;

                            // Obtain the role and the distribution list to be notified of the change
                            Dictionary<string, string> roleDistributionList = ikeaUtilities.ResolveResorceChangeStateDistributionList(transitionNameInitial, transitionNameFinal, resource);

                            // Check if any role was found
                            if (!roleDistributionList.IsNullOrEmpty())
                            {
                                transitionName = string.Format("{0} to {1}", transitionNameInitial, transitionNameFinal);

                                // Build Message for notification
                                string subject = ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomResourceStateChangesNotificationHasChangedMessageLocalizedMessage, resource.Name, transitionName);
                                StringBuilder message = new StringBuilder();

                                message.AppendLine(ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomResourceStateChangesNotificationHasChangedOnMessageLocalizedMessage, resource.Name, transitionName, resource.ModifiedBy, resource.ModifiedOn.ToString()));
                                message.Append("<br>");

                                // Only add this part of the message if there is a reason defined
                                if (Input.ContainsKey("Reason") && Input["Reason"] != null && !String.IsNullOrWhiteSpace(Input["Reason"].ToString()))
                                {
                                    message.AppendLine(ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomResourceStateChangesNotificationFollowingReasonMessageLocalizedMessage, Input["Reason"].ToString()));
                                }

                                // Only add this part of the message if there is a service comment defined
                                if (serviceComments != null)
                                {
                                    message.Append("<br>");
                                    message.AppendLine(ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomResourceStateChangesNotificationServiceCommentsMessageLocalizedMessage, serviceComments));
                                }

                                // Go through all the roles and distribution list and create a notification
                                foreach (var distributionList in roleDistributionList)
                                {
                                    IRole role = new Role()
                                    {
                                        Name = distributionList.Key
                                    };

                                    role.Load();

                                    //Validate if Severity exists in config
                                    string severity = ikeaUtilities.GetValueFromConfigurationWithPath(IKEAConstants.DefaultNotificationSeverityConfig);

                                    if (severity.IsNullOrEmpty())
                                    {
                                        throw new CmfBaseException(ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomDefaultNotificationSeverityConfigNotDefined, IKEAConstants.DefaultNotificationSeverityConfig));
                                    }

                                    Cmf.Navigo.BusinessObjects.Abstractions.INotification notification = entityFactory.Create<Cmf.Navigo.BusinessObjects.Abstractions.INotification>();

                                    notification.Type = "System";
                                    notification.Title = subject;
                                    notification.Details = message.ToString();
                                    notification.Severity = ikeaUtilities.GetValueFromLookupTable(IKEAConstants.NotificationSeverityLookupTableName, severity, true);
                                    notification.AssignmentType = (NotificationAssignmentType)AssignmentType.Role;
                                    notification.AssignedToRole = role;
                                    notification.SendEmailToAssignedParty = true;
                                    notification.EmailDistributionList = distributionList.Value;


                                    notification.Create();
                                }
                            }

                            resourceStateChanges.Resource.ReclassifyResourcePreviousStates(resourceStateChanges);
                        }
                    }
                }
            }


            //---End DEE Code---

            return Input;
        }

    }
}
