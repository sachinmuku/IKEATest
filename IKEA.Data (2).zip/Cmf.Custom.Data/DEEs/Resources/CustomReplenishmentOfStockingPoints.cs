﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;

using Cmf.Custom.IKEA.BusinessObjects;
using Cmf.Custom.IKEA.BusinessObjects.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Extensions;
using Cmf.Custom.IKEA.Orchestration;
using Cmf.Custom.IKEA.Orchestration.Abstractions;
using Cmf.Custom.IKEA.Orchestration.InputObjects;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Foundation.Configuration;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;

using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.Resources
{
    public class CustomReplenishmentOfStockingPoints : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Action to be called by the timer CustomReplenishmentOfStockingPoints 
            ///     and will calculate the necessity of requesting more materials to stocking points
            /// Depends On:
            ///     CustomReplenishmentOfStockingPoints Timer and CustomReplenishmentOfStockingPoints Rule
            /// </summary>
            #endregion

            return true;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            //System
            UseReference("", "Cmf.Custom.IKEA.Orchestration.Abstractions");
            UseReference("", "Cmf.Custom.IKEA.BusinessObjects.Abstractions");
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            //Foundation
            UseReference("Cmf.Foundation.Common.dll", "Cmf.Foundation.Common");

            //Custom
            UseReference("Cmf.Custom.IKEA.BusinessObjects.CustomStockingPointResource.dll", "Cmf.Custom.IKEA.BusinessObjects");
            UseReference("Cmf.Custom.IKEA.BusinessObjects.CustomMaterialReplenishmentRequestTracker.dll", "Cmf.Custom.IKEA.BusinessObjects");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Extensions");
            UseReference("Cmf.Custom.IKEA.Orchestration.dll", "Cmf.Custom.IKEA.Orchestration");
            UseReference("Cmf.Custom.IKEA.Orchestration.dll", "Cmf.Custom.IKEA.Orchestration.InputObjects");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");

            // Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");

            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            //IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            var iKEABusinessManagementOrchestration = serviceProvider.GetService<IIKEABusinessManagementOrchestration>();
            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            ILocalizedMessage localizedMessage = serviceProvider.GetService<ILocalizedMessage>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IStockingPointUtilities istUtilities = serviceProvider.GetService<IStockingPointUtilities>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();

            // Get all the Material Replenishment Request Configurations
            List<MaterialReplenishmentRequestConfiguration> configurations = istUtilities.GetMaterialReplenishmentRequestConfiguration();

            Dictionary<string, IProductCollection> stockingPointsProducts = new Dictionary<string, IProductCollection>();

            int frequency = genericUtilities.GetConfigurationValueByPath<int>(IKEAConstants.StockingPointReplenishmentTimerFrequencyConfig);
            if (frequency > 0)
            {
                ICmfTimer timerToLoad = entityFactory.Create<ICmfTimer>();
                timerToLoad.Load(IKEAConstants.CustomReplenishmentOfStockingPoints);
                if (frequency != timerToLoad.RecurrenceDefinedSeconds)
                {
                    timerToLoad.RecurrenceDefinedSeconds = frequency;
                    timerToLoad.Save();
                }
            }

            // Check if any configuration exists
            if (!configurations.IsNullOrEmpty())
            {
                // Collection with all the configured products
                Dictionary<long, IProduct> configuredProducts = new Dictionary<long, IProduct>();

                Dictionary<ICustomMaterialReplenishmentRequestTracker, CustomRequestMaterialTransferInput> materialTransfersTrackers = new Dictionary<ICustomMaterialReplenishmentRequestTracker, CustomRequestMaterialTransferInput>();

                // Get a collection of stocking points
                IResourceCollection stockingPoints = entityFactory.CreateCollection<IResourceCollection>();
                stockingPoints.AddRange(configurations.DistinctBy(c => c.StockingPoint).Select(c => { var r = entityFactory.Create<IResource>(); r.Name = c.StockingPoint;return r; }));
                stockingPoints.Load();
                Dictionary<string, IResource> stockingPointsDictionary = stockingPoints.ToDictionary(s => s.Name, s => s);

                stockingPointsProducts = configurations.Select(c => c.StockingPoint).Distinct().ToDictionary(c => c, c => (IProductCollection)entityFactory.CreateCollection< IProductCollection > ());

                // Load the stocking point relation to be able to obtain the main lines
                stockingPoints.LoadRelations("CustomStockingPointResource");

                // Get a collection of areas of the stocking points
                IAreaCollection areas = entityFactory.CreateCollection<IAreaCollection>();
                areas.LoadByIDs<IArea, Area>(stockingPoints.Select(sp => sp.GetNativeValue<long>("Area")).Distinct().ToList());
                Dictionary<long, IArea> areasDictionary = areas.ToDictionary(a => a.Id, a => a);

                // Get a collection of facilities of the stocking points
                IFacilityCollection facilities = entityFactory.CreateCollection<IFacilityCollection>();
                facilities.LoadByIDs<IFacility, Facility>(areas.Select(a => a.GetNativeValue<long>("Facility")).Distinct().ToList());
                Dictionary<long, IFacility> facilitiesDictionary = facilities.ToDictionary(f => f.Id, f => f);

                // Get dictionary of Stocking Points and their main lines
                Dictionary<string, List<long>> stockingPointsMainLines = stockingPoints.Where(sp => sp.RelationCollection.ContainsKey("CustomStockingPointResource"))
                                                                                              .Select(E => new { StockingPoint = E.Name, MainLine = E.RelationCollection["CustomStockingPointResource"].Select(spr => (spr as ICustomStockingPointResource).GetNativeValue<long>("TargetEntity")) })
                                                                                              .GroupBy(E => E.StockingPoint)
                                                                                              .ToDictionary(E => E.Key, E => E.SelectMany(x => x.MainLine).ToList());

                if (!stockingPointsMainLines.IsNullOrEmpty())
                {
                    List<long> mainLineIds = stockingPointsMainLines.SelectMany(E => E.Value).ToList();

                    // Get a collection of main lines
                    IResourceCollection mainLines = entityFactory.CreateCollection<IResourceCollection>();
                    mainLines.Load(new Collection<long>(mainLineIds.Distinct().ToList()), 0);
                    Dictionary<long, IResource> mainLinesDictionary = mainLines.ToDictionary(r => r.Id, r => r);

                    // Group the configurations by StockingPoint, WorkingMode and HoursToConsider to reduce the number of cycles to do
                    var groupedConfigurations = configurations.GroupBy(msp => new { msp.StockingPoint, msp.WorkingMode, msp.HoursToConsider });

                    if (!groupedConfigurations.IsNullOrEmpty())
                    {
                        Dictionary<long, List<IResource>> mainLinesSubResources = new Dictionary<long, List<IResource>>();

                        foreach (var config in groupedConfigurations)
                        {
                            foreach (long mainLineId in stockingPointsMainLines[config.Key.StockingPoint])
                            {
                                // Get the main line of the stocking point
                                IResource mainLine = mainLinesDictionary[mainLineId];

                                // Get order quantities
                                Dictionary<IMaterial, decimal?> orderQuantitiesToProduce = istUtilities.RetrieveOrderQuantity(mainLine, config.Key.WorkingMode, config.Key.HoursToConsider);

                                // Get the stocking point resource
                                IResource mainStockingPoint = stockingPointsDictionary[config.Key.StockingPoint];

                                // Check if there any orders to produce
                                if (!orderQuantitiesToProduce.IsNullOrEmpty())
                                {
                                    Dictionary<long, decimal> quantitiesByProduct = new Dictionary<long, decimal>();

                                    #region Get Necessities by order

                                    foreach (var orderMaterials in orderQuantitiesToProduce)
                                    {
                                        // Calculate the order product necessities
                                        Dictionary<IProduct, decimal> orderNecessity = istUtilities.CalculateOrderNecessities(orderMaterials.Key, orderMaterials.Value.GetValueOrDefault());

                                        // Only get the products that have a matching configuration, either by name or by type
                                        var orderProducts = orderNecessity.Where(on => config.Any(c => c.Product == on.Key.Name || c.ProductType == on.Key.Type));

                                        // Get a collection with all the configured products
                                        configuredProducts.AddRange(orderProducts.Where(op => !configuredProducts.ContainsKey(op.Key.DefinitionId))
                                                                                            .ToDictionary(op => op.Key.DefinitionId, op => op.Key));

                                        // Only go through the orders that require the configured products
                                        foreach (var necessity in orderProducts)
                                        {
                                            // If the product already exists in the dictionary, adds the quantity to the already existing one
                                            if (quantitiesByProduct.ContainsKey(necessity.Key.DefinitionId))
                                            {
                                                quantitiesByProduct[necessity.Key.DefinitionId] = quantitiesByProduct[necessity.Key.DefinitionId] + necessity.Value;
                                            }
                                            // Otherwise, adds product and quantity to the dictionary
                                            else
                                            {
                                                quantitiesByProduct.Add(necessity.Key.DefinitionId, necessity.Value);
                                            }
                                        }
                                    }

                                    #endregion

                                    #region Reduce the necessities the quantities already in the feeders

                                    // To prevent the unlikely case where the same main line appears several times
                                    // we will load the sub resources only once and save them in a dictionary
                                    if (!mainLinesSubResources.ContainsKey(mainLineId))
                                    {
                                        int order = 0;
                                        mainLine.GetDescendentResources(-1);

                                        Dictionary<int, IResource> mainLineSubResources = mainLine.GetResourceSubResources(ref order);

                                        // Save the main line and the sub resources, if there are no sub resources
                                        // set it at null
                                        mainLinesSubResources.Add(mainLineId, mainLineSubResources != null ? mainLineSubResources.Values.ToList() : null);
                                    }

                                    foreach (var subResource in mainLinesSubResources[mainLineId])
                                    {
                                        // Get all the attached materials
                                        IMaterialCollection materials = subResource.GetAttachedMaterials();

                                        if (!materials.IsNullOrEmpty())
                                        {
                                            // Get the feeders available quantities by product
                                            Dictionary<long, decimal> availableQuantities = quantitiesByProduct.ToDictionary(on => on.Key, on => materials.Where(m => m.GetNativeValue<long>("Product") == on.Key)
                                                                                                                                                            .Sum(m => m.PrimaryQuantity.GetValueOrDefault()));

                                            // Reduce the quantities in the order necessities
                                            foreach (var availableQuantity in availableQuantities)
                                            {
                                                quantitiesByProduct[availableQuantity.Key] = quantitiesByProduct[availableQuantity.Key] - availableQuantity.Value;
                                            }
                                        }
                                    }

                                    #endregion

                                    #region Request stocking point replenishment

                                    if (!quantitiesByProduct.IsNullOrEmpty())
                                    {
                                        // Get all the main line stocking points
                                        ICustomStockingPointResourceCollection stockingPointResources = istUtilities.GetLineStockingPoint(mainLine);

                                        // Check if there are any stocking points for the main line
                                        if (!stockingPointResources.IsNullOrEmpty())
                                        {
                                            // Get a collection of stocking points resources
                                            IResourceCollection lineStockingPoints = entityFactory.CreateCollection<IResourceCollection>();
                                            lineStockingPoints.Load(new Collection<long>(stockingPointResources.Select(sp => sp.GetNativeValue<long>("SourceEntity")).ToList()));

                                            // Get all the stored materials in the stocking point
                                            IMaterialCollection materialsAtStockingPoints = lineStockingPoints.GetAttachedMaterials();

                                            foreach (var quantityByProduct in quantitiesByProduct)
                                            {
                                                // Get the sum of all quantities for the given product
                                                decimal quantityAtStockingPoint = materialsAtStockingPoints.Where(m => m.GetNativeValue<long>("Product") == quantityByProduct.Key).Sum(m => m.PrimaryQuantity.GetValueOrDefault());

                                                // Get the product to be used
                                                IProduct product = configuredProducts[quantityByProduct.Key];

                                                // Try to get the Replenishment Request Configuration for the product name
                                                MaterialReplenishmentRequestConfiguration configuration = config.FirstOrDefault(c => c.Product == product.Name);

                                                // If there are no configurations by product name, try to get it by product type
                                                if (configuration == null)
                                                {
                                                    configuration = config.FirstOrDefault(c => c.ProductType == product.Type);
                                                }

                                                // Check if any configuration exists
                                                if (configuration != null)
                                                {
                                                    // If the quantity in the stocking points for the product is inferior to the required one and is bellow the threshold
                                                    // a new material transfer will be requested
                                                    if (quantityAtStockingPoint < quantityByProduct.Value && quantityAtStockingPoint < configuration.Threshold.GetValueOrDefault())
                                                    {
                                                        stockingPointsProducts[mainStockingPoint.Name].Add(product);

                                                        // Get the stocking point area
                                                        IArea area = areasDictionary[mainStockingPoint.GetNativeValue<long>("Area")];

                                                        // Get the stocking point Facility
                                                        IFacility facility = facilitiesDictionary[area.GetNativeValue<long>("Facility")];

                                                        decimal quantity = configuration.QuantityToRequest.GetValueOrDefault();

                                                        // Check if there is already an active request made for the product in the stocking point
                                                        if (!istUtilities.ReplenishmentRequestExists(product.Name, quantity, mainStockingPoint.Name)
                                                            && !materialTransfersTrackers.Keys.Any(m => m.ProductName == product.Name && m.RequestedQuantity == quantity && m.StockingPoint == mainStockingPoint.Name))
                                                        {
                                                            CustomRequestMaterialTransferInput input = null;

                                                            switch (configuration.RequestMode)
                                                            {
                                                                // When request mode is manual a material transfer needs to be requested
                                                                case CustomMaterialReplenishmentRequestModeEnum.Manual:
                                                                    {
                                                                        input = new CustomRequestMaterialTransferInput()
                                                                        {
                                                                            FromArea = configuration.Area,
                                                                            FromFacility = configuration.Facility,
                                                                            RequiredProduct = product.Name,
                                                                            RequiredQuantity = quantity,
                                                                            ToArea = area.Name,
                                                                            ToFacility = facility.Name,
                                                                            ToLocation = mainStockingPoint.Name
                                                                        };
                                                                        break;
                                                                    }
                                                                // If request mode is ERP a new ERP message will be sent
                                                                case CustomMaterialReplenishmentRequestModeEnum.ERP:
                                                                    {
                                                                        ikeaUtilities.RequestMaterialReplenishment(facility, product, mainStockingPoint, quantity);
                                                                        break;
                                                                    }
                                                                // Not Implemented
                                                                case CustomMaterialReplenishmentRequestModeEnum.Automated:
                                                                default:
                                                                    break;
                                                            }

                                                            // Until we have implemented the request mode Automated, we should not create the material trackings 
                                                            if (configuration.RequestMode != CustomMaterialReplenishmentRequestModeEnum.Automated)
                                                            {
                                                                // Save the new material request
                                                                ICustomMaterialReplenishmentRequestTracker materialReplenishmentRequestTracker = entityFactory.Create<ICustomMaterialReplenishmentRequestTracker>();

                                                                materialReplenishmentRequestTracker.Name = string.Format("{0}.{1}.{2}.{3:yyyyMMddhhmmss}", product.Name, quantity, mainStockingPoint.Name, DateTime.Now);
                                                                materialReplenishmentRequestTracker.ProductName = product.Name;
                                                                materialReplenishmentRequestTracker.DeliveredQuantity = 0;
                                                                materialReplenishmentRequestTracker.RequestedQuantity = quantity;
                                                                materialReplenishmentRequestTracker.StockingPoint = mainStockingPoint.Name;


                                                                materialTransfersTrackers.Add(materialReplenishmentRequestTracker, input);
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    #endregion
                                }
                            }
                        }
                    }
                }

                // Save all the material requests
                if (!materialTransfersTrackers.IsNullOrEmpty())
                {
                    ICustomMaterialReplenishmentRequestTrackerCollection materialReplenishmentRequestTrackers = entityFactory.CreateCollection<ICustomMaterialReplenishmentRequestTrackerCollection>();
                    materialReplenishmentRequestTrackers.AddRange(materialTransfersTrackers.Keys.ToList());

                    materialReplenishmentRequestTrackers.Create();

                    foreach (var materialTransfersTracker in materialTransfersTrackers.Where(mt => mt.Value != null))
                    {
                        materialTransfersTracker.Value.SourceMaterialRequestId = materialTransfersTracker.Key.Id;

                        // Request a material transfer
                        iKEABusinessManagementOrchestration.CustomRequestMaterialTransfer(materialTransfersTracker.Value);
                    }
                }

                if (!stockingPointsProducts.IsNullOrEmpty())
                {
                    foreach (var productsToReplenish in stockingPointsProducts)
                    {
                        // Clean up all the requests that are not necessary anymore
                        istUtilities.CleanUpReplenishmentRequest(productsToReplenish.Key, productsToReplenish.Value);
                    }
                }
            }

            Input.Add("Result", "");

            //---End DEE Code---

            return Input;
        }

    }
}
