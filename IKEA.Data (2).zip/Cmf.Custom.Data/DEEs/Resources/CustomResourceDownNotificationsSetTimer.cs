﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Utilities;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;

using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading;

namespace Cmf.Custom.IKEA.Actions.Resources
{
    public class CustomResourceDownNotificationsSetTimer : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Updates the LastStateChangeTimestamp Attribute when the resource state changes
            ///     and creates a timer when a notification needs to be sent for the new state
            /// Action Groups:
            ///     BusinessObjects.Resource.LogEvent.Post
            ///     BusinessObjects.ResourceCollection.Save.Pre
            ///     BusinessObjects.ResourceCollection.Save.Post
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.Resource.LogEvent.Post",
                "BusinessObjects.ResourceCollection.Save.Pre",
                "BusinessObjects.ResourceCollection.Save.Post"
            };

            // only proceed if within expected triggers (action groups)
            return IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            //System
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("", "System");

            //Foundation
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");

            //Navigo
            UseReference("Cmf.Navigo.Common.dll", "Cmf.Navigo.Common");
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            ILocalizedMessage localizedMessage = serviceProvider.GetService<ILocalizedMessage>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();

            string transitionNameInitial = null;
            string transitionNameFinal = null;
            string transitionName = null;
            IResource resource = null;

            string currentContext = IKEAConstants.CustomResourceDownNotificationsContext + "_" + IKEAConstants.CustomNotificationResourcesChangeStateInitialStateTransition;

            string actionGroupName = IKEADEEActionUtilities.GetInputItem<string>(Input, "ActionGroupName");

            if (!string.IsNullOrEmpty(actionGroupName))
            {
                // BusinessObjects.Resource.LogEvent.Post
                if (string.Equals(actionGroupName, "BusinessObjects.Resource.LogEvent.Post", StringComparison.InvariantCultureIgnoreCase) &&
                    Input.ContainsKey("TransitionName") &&
                    Input.ContainsKey(Cmf.Foundation.Common.Constants.StateModel))
                {
                    transitionName = IKEADEEActionUtilities.GetInputItem<string>(Input, "TransitionName");
                    IStateModel selectedStateModel = IKEADEEActionUtilities.GetInputItem<IStateModel>(Input, Cmf.Foundation.Common.Constants.StateModel);

                    selectedStateModel.Load();
                    IStateModelTransition stateModelTransition = selectedStateModel.StateTransitions.FirstOrDefault(t => t.Name == transitionName);

                    transitionNameInitial = stateModelTransition.FromState.Name.ToString();
                    transitionNameFinal = stateModelTransition.ToState.Name.ToString();

                    resource = IKEADEEActionUtilities.GetInputItem<IResource>(Input, Cmf.Navigo.Common.Constants.Resource);
                }
                // BusinessObjects.ResourceCollection.Save.Pre
                else if (string.Equals(actionGroupName, "BusinessObjects.ResourceCollection.Save.Pre", StringComparison.InvariantCultureIgnoreCase) &&
                         Input.ContainsKey(Cmf.Navigo.Common.Constants.ResourceCollection))
                {
                    IResourceCollection resources = IKEADEEActionUtilities.GetInputItem<IResourceCollection>(Input, Cmf.Navigo.Common.Constants.ResourceCollection);

                    if (resources.Count > 0)
                    {
                        resource = entityFactory.Create<IResource>();
                        if (resources.FirstOrDefault() != null)
                        {
                            resource = resources.FirstOrDefault();
                            if (string.IsNullOrEmpty(resource.Name))
                            {
                                resource.Load();
                            }
                            if (resource.CurrentMainState != null && resource.CurrentMainState.CurrentState != null)
                            {
                                deeContextUtilities.SetContextParameter(currentContext, resource.CurrentMainState.CurrentState.Name.ToString());
                            }
                            else
                            {
                                deeContextUtilities.SetContextParameter(currentContext, string.Empty);
                            }
                        }
                    }
                }
                // BusinessObjects.ResourceCollection.Save.Post
                else if (string.Equals(actionGroupName, "BusinessObjects.ResourceCollection.Save.Post", StringComparison.InvariantCultureIgnoreCase) &&
                         Input.ContainsKey(Cmf.Navigo.Common.Constants.ResourceCollection))
                {
                    IResourceCollection resources = IKEADEEActionUtilities.GetInputItem<IResourceCollection>(Input, Cmf.Navigo.Common.Constants.ResourceCollection);

                    if (resources.Count > 0)
                    {
                        resource = entityFactory.Create<IResource>();
                        if (resources.FirstOrDefault() != null)
                        {
                            resource = resources.FirstOrDefault();
                            resource.Load();
                            if (resource.CurrentMainState != null && resource.CurrentMainState.CurrentState != null)
                            {
                                transitionNameInitial = deeContextUtilities.GetContextParameter(currentContext).ToString();
                                transitionNameFinal = resource.CurrentMainState.CurrentState.Name.ToString();
                            }
                        }
                    }
                }

                // Only change the LastStateChangeTimestamp Attribute and create timer 
                // if the previous state and new one are different
                if (!string.IsNullOrWhiteSpace(transitionNameInitial)
                    && !string.IsNullOrWhiteSpace(transitionNameFinal)
                    && !string.Equals(transitionNameInitial, transitionNameFinal, StringComparison.InvariantCultureIgnoreCase))
                {
                    string timeStamp = DateTime.Now.ToString("yyyyMMddHHmmss");

                    // Change the Last State Change Timestamp Attribute to reflect the last change done to the state
                    IAttributeCollection atrtibutes = new AttributeCollection()
        {
            { IKEAConstants.LastStateChangeTimestampAttribute, timeStamp }
        };
                    resource.SaveAttributes(atrtibutes);

                    // Get the Time Threshold, role and distribution list configured in the smart table
                    Tuple<int, string, string, string> settings = ikeaUtilities.GetTimeThresholdForResourceStateNotifications(resource.Area.Facility.Name,
                                                                                                                        resource.Area.Name,
                                                                                                                        resource.Name,
                                                                                                                        resource.Type,
                                                                                                                        transitionNameFinal);

                    // Check if any configuration exists
                    if (settings != null)
                    {
                        int timeThreshold = settings.Item1;

                        // Get Rule object to set in CmfTimer
                        IRule rule = entityFactory.Create<IRule>();

                        rule.Name = IKEAConstants.CustomResourceDownNotificationTimer;


                        // Check if there is a rule with the given name
                        if (rule.ObjectExists())
                        {
                            rule.Load();

                            // Create Timer
                            ICmfTimer notificationTimer = entityFactory.Create<ICmfTimer>();

                            notificationTimer.Name = string.Format("{0}_{1}_{2}", IKEAConstants.CustomResourceDownNotificationsContext, resource.Name, timeStamp);
                            notificationTimer.Description = ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomResourceDownNotificationTimerDescriptionLocalizedMessage, resource.Name, timeThreshold.ToString());
                            notificationTimer.IsEnabled = true;
                            notificationTimer.Start = DateTime.Now.AddSeconds(10); // The start date needs to be a date after the timer is created
                            notificationTimer.Recurrence = CmfTimerRecurrence.OneTime;
                            notificationTimer.RecurrenceDefinedFrequency = 1;
                            notificationTimer.RecurrenceDefinedSeconds = timeThreshold;
                            notificationTimer.Rule = rule;
                            notificationTimer.Scope = CmfTimerScope.General;
                            notificationTimer.SendEmailOnError = false;

                            notificationTimer.Create();
                        }
                    }

                }

            }

            //---End DEE Code---

            return Input;
        }
    }
}
