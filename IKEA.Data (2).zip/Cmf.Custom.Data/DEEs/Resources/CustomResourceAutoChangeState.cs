﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;


using Cmf.Custom.IKEA;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Extensions;
using Cmf.Custom.IKEA.Orchestration;
using Cmf.Custom.IKEA.Orchestration.InputObjects;
using Cmf.Custom.IKEA.Orchestration.OutputObjects;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects;
using Microsoft.Extensions.DependencyInjection;

using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.Resources
{
    public class CustomResourceAutoChangeState : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Will call Change the resource state based on the type of material
            /// Action Groups:
            ///     MaterialManagement.MaterialManagementOrchestration.ComplexTrackOutMaterials.Post
            ///     MaterialManagement.MaterialManagementOrchestration.AbortMaterialsProcess.Pre
            ///     MaterialManagement.MaterialManagementOrchestration.AbortMaterialsProcess.Post
            ///     MaterialManagement.MaterialManagementOrchestration.TerminateMaterials.Pre
            ///     MaterialManagement.MaterialManagementOrchestration.TerminateMaterials.Post
            ///     MaterialManagement.MaterialManagementOrchestration.ComplexTrackInMaterials.Post
            ///     Orchestration.IKEABusinessOrchestration.CustomStartMaterial.Post
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "MaterialManagement.MaterialManagementOrchestration.ComplexTrackOutMaterials.Post",
                "MaterialManagement.MaterialManagementOrchestration.AbortMaterialsProcess.Pre",
                "MaterialManagement.MaterialManagementOrchestration.AbortMaterialsProcess.Post",
                "MaterialManagement.MaterialManagementOrchestration.TerminateMaterials.Pre",
                "MaterialManagement.MaterialManagementOrchestration.TerminateMaterials.Post",
                "MaterialManagement.MaterialManagementOrchestration.ComplexTrackInMaterials.Post",
                "Orchestration.IKEABusinessOrchestration.CustomStartMaterial.Post",
                "MaterialManagement.MaterialManagementOrchestration.DispatchMaterials.Post",
                "MaterialManagement.MaterialManagementOrchestration.UndispatchMaterials.Post",
                "MaterialManagement.MaterialManagementOrchestration.UndispatchMaterials.Pre"
            };

            // Only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            if (executionVeridict
                && IKEADEEActionUtilities.GetInputItem<ComplexTrackOutMaterialsOutput>(Input, "ComplexTrackOutMaterialsOutput") == null
                && IKEADEEActionUtilities.GetInputItem<AbortMaterialsProcessInput>(Input, "AbortMaterialsProcessInput") == null
                && IKEADEEActionUtilities.GetInputItem<TerminateMaterialsInput>(Input, "TerminateMaterialsInput") == null
                && IKEADEEActionUtilities.GetInputItem<ComplexTrackInMaterialsOutput>(Input, "ComplexTrackInMaterialsOutput") == null
                && IKEADEEActionUtilities.GetInputItem<CustomStartMaterialInput>(Input, "CustomStartMaterialInput") == null 
                && IKEADEEActionUtilities.GetInputItem<CustomStartMaterialInput>(Input, "CustomStartMaterialInput") == null
                && IKEADEEActionUtilities.GetInputItem<DispatchMaterialsInput>(Input, "DispatchMaterialsInput") == null
                && IKEADEEActionUtilities.GetInputItem<UndispatchMaterialsInput>(Input, "UndispatchMaterialsInput") == null)
            {
                executionVeridict = false;
            }

            return executionVeridict;


            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            //System
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("", "System");

            //Foundation
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");

            //Navigo
            UseReference("Cmf.Navigo.Common.dll", "Cmf.Navigo.Common");
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects");
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Extensions");
            UseReference("Cmf.Custom.IKEA.Orchestration.dll", "Cmf.Custom.IKEA.Orchestration.InputObjects");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();

            DeeContext currentContext = deeContextUtilities.SetCurrentServiceContext("CustomResourceAutoChangeState");
            string contextMaterialResource = "CustomResourceAutoChangeState_MaterialResources";

            IMaterialResourceCollection materialResources = null;
            IMaterialCollection materials = null;

            string context = string.Empty;


            switch (currentContext.MethodName)
            {
                case "ComplexTrackInMaterials":

                    ComplexTrackInMaterialsInput complexTrackInMaterialsInput = IKEADEEActionUtilities.GetInputItem<ComplexTrackInMaterialsInput>(Input, "ComplexTrackInMaterialsInput");

                    materialResources = entityFactory.CreateCollection<IMaterialResourceCollection>();

                    complexTrackInMaterialsInput.Materials.LoadRelations(Navigo.Common.Constants.MaterialResource);
                    materialResources.AddRange(complexTrackInMaterialsInput.Materials.Where(m => !m.MaterialResourceRelations.IsNullOrEmpty()).SelectMany(m => m.MaterialResourceRelations).ToList());

                    context = "TrackInMaterial.Post";
                    break;
                case "AbortMaterialsProcess":

                    AbortMaterialsProcessInput abortMaterialsProcessInput = IKEADEEActionUtilities.GetInputItem<AbortMaterialsProcessInput>(Input, "AbortMaterialsProcessInput");

                    if (currentContext.TriggerPoint == DeeTriggerPoint.Pre)
                    {
                        materialResources = entityFactory.CreateCollection<IMaterialResourceCollection>();

                        abortMaterialsProcessInput.Materials.LoadRelations(Navigo.Common.Constants.MaterialResource);
                        materialResources.AddRange(abortMaterialsProcessInput.Materials.Where(m => !m.MaterialResourceRelations.IsNullOrEmpty()).SelectMany(m => m.MaterialResourceRelations).ToList());

                        deeContextUtilities.SetContextParameter(contextMaterialResource, materialResources);
                    }
                    else
                    {
                        context = "AbortMaterial.Post";
                        materialResources = deeContextUtilities.GetContextParameter(contextMaterialResource) as IMaterialResourceCollection;
                    }

                    break;
                case "TerminateMaterials":

                    TerminateMaterialsInput terminateMaterialsInput = IKEADEEActionUtilities.GetInputItem<TerminateMaterialsInput>(Input, "TerminateMaterialsInput");

                    if (currentContext.TriggerPoint == DeeTriggerPoint.Pre)
                    {
                        materialResources = entityFactory.CreateCollection<IMaterialResourceCollection>();

                        terminateMaterialsInput.Materials.LoadRelations(Navigo.Common.Constants.MaterialResource);
                        materialResources.AddRange(terminateMaterialsInput.Materials.Where(m => !m.MaterialResourceRelations.IsNullOrEmpty()).SelectMany(m => m.MaterialResourceRelations).ToList());

                        deeContextUtilities.SetContextParameter(contextMaterialResource, materialResources);
                    }
                    else
                    {
                        context = "TerminateMaterial.Post";
                        materialResources = deeContextUtilities.GetContextParameter(contextMaterialResource) as IMaterialResourceCollection;
                    }

                    break;
                case "ComplexTrackOutMaterials":

                    context = "TrackOutMaterial.Post";
                    ComplexTrackOutMaterialsOutput complexTrackOutMaterialsOutput = IKEADEEActionUtilities.GetInputItem<ComplexTrackOutMaterialsOutput>(Input, "ComplexTrackOutMaterialsOutput");

                    materials = entityFactory.CreateCollection<IMaterialCollection>();
                    materials.AddRange(complexTrackOutMaterialsOutput.Materials.Keys);

                    materialResources = entityFactory.CreateCollection<IMaterialResourceCollection>();

                    materials.LoadRelations(Navigo.Common.Constants.MaterialResource);
                    materialResources.AddRange(materials.Where(m => m.LastProcessedResource != null).Select(m => { var ma = entityFactory.Create<IMaterialResource>();  ma.SourceEntity = m; ma.TargetEntity = m.LastProcessedResource;return ma; }).ToList());

                    break;

                case "CustomStartMaterial":

                    context = "CustomStartMaterial.Post";
                    CustomStartMaterialInput customStartMaterialInput = IKEADEEActionUtilities.GetInputItem<CustomStartMaterialInput>(Input, "CustomStartMaterialInput");

                    materials = entityFactory.CreateCollection<IMaterialCollection>();
                    materials.Add(customStartMaterialInput.Material);

                    materialResources = entityFactory.CreateCollection<IMaterialResourceCollection>();

                    materials.LoadRelations(Navigo.Common.Constants.MaterialResource);
                    materialResources.AddRange(materials.Where(m => m.LastProcessedResource != null).Select(m => { var mr =entityFactory.Create < IMaterialResource > (); mr.SourceEntity = m; mr.TargetEntity = m.LastProcessedResource;return mr; }).ToList());

                    break;

                case "DispatchMaterials":
                    if (currentContext.TriggerPoint == DeeTriggerPoint.Post)
                    {
                        context = "Dispatch.Post";
                        DispatchMaterialsInput dispatchMaterialsInput = IKEADEEActionUtilities.GetInputItem<DispatchMaterialsInput>(Input, "DispatchMaterialsInput");

                        materialResources = entityFactory.CreateCollection<IMaterialResourceCollection>();
                        materialResources.AddRange(dispatchMaterialsInput.Materials.Where(m => m.Value.Resource != null).Select(m => { var mr = entityFactory.Create<IMaterialResource>(); mr.SourceEntity = m.Key; mr.TargetEntity = m.Value.Resource;return mr; }).ToList());
                    }

                    break;

                case "UndispatchMaterials":
                    if (currentContext.TriggerPoint == DeeTriggerPoint.Pre)
                    {
                        UndispatchMaterialsInput undispatchMaterialsInput = IKEADEEActionUtilities.GetInputItem<UndispatchMaterialsInput>(Input, "UndispatchMaterialsInput");

                        materials = entityFactory.CreateCollection<IMaterialCollection>();
                        materials.AddRange(undispatchMaterialsInput.Materials);
                        materials.LoadRelations(Navigo.Common.Constants.MaterialResource);

                        materialResources = entityFactory.CreateCollection<IMaterialResourceCollection>();

                        foreach (IMaterial mat in materials)
                        {
                            IMaterialResourceCollection matResourceCollection = mat.MaterialResourceRelations;
                            materialResources.AddRange(matResourceCollection);
                        }


                        deeContextUtilities.SetContextParameter(contextMaterialResource, materialResources);
                    }
                    else
                    {
                        context = "Undispatch.Post";
                        materialResources = deeContextUtilities.GetContextParameter(contextMaterialResource) as IMaterialResourceCollection;
                    }
                    break;

                default:
                    break;
            }

            if (currentContext.TriggerPoint == DeeTriggerPoint.Post && !materialResources.IsNullOrEmpty())
            {
                var materialByResources = materialResources.GroupBy(mr => mr.GetNativeValue<long>("TargetEntity"));

                IResourceCollection resources = entityFactory.CreateCollection<IResourceCollection>();
                resources.LoadByIDs<IResource, Resource>(materialByResources.Select(mr => mr.Key).ToList());

                foreach (var materialResource in materialByResources)
                {
                    IResource resource = resources.Where(r => r.Id == materialResource.Key).First();

                    IMaterialCollection resourceMaterials = entityFactory.CreateCollection<IMaterialCollection>();
                    resourceMaterials.AddRange(materialResource.Select(mr => mr.SourceEntity).ToList());

                    IResourcePossibleTransitions possibleTransitions = resource.GetPossibleTransitions(
                            context,
                            new Dictionary<String, Object>()
                            {
                    { "Materials", resourceMaterials }
                            }
                        );

                    if (possibleTransitions != null && possibleTransitions.DefaultTransition != null)
                    {
                        string serviceComment = null;
                        bool enforceChangeStateComments = ikeaUtilities.GetResourceChangeStateEnforceComment(resource);
                        if (enforceChangeStateComments)
                        {
                            serviceComment = string.Format(IKEAConstants.CustomResourceEnforceCommentOnChangeStateServiceMessageAuto, "CustomResourceAutoChangeState");
                        }

                        resource.ChangeState(possibleTransitions.DefaultTransition, possibleTransitions.DefaultTransition.ReasonDefaultValue, serviceComment);
                    }
                }
            }

            //---End DEE Code---

            return Input;
        }





    }
}
