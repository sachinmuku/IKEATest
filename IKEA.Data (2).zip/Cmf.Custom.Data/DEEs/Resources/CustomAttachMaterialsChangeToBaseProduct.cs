﻿using Cmf.Custom.IKEA.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.Abstractions;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cmf.Common.CustomActionUtilities;

namespace Cmf.Custom.IKEA.Actions.Resources
{
    /// <summary>
    ///  Validates if materials attached are from products having revision control and associated with a product revision
    ///  If so, changes their product to the base product to ensure material is valid against the BOM, which
    ///  is not product revision specific
    /// </summary>
    public class CustomAttachMaterialsChangeToBaseProduct : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Validates if materials attached are from products having revision control and associated with a product revision
            ///     If so, changes their product to the base product to ensure material is valid against the BOM, which
            ///     is not product revision specific
            /// Action Groups:
            ///     BusinessObjects.Resource.AttachConsumables.Pre
            /// </summary>
            #endregion
            
            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.Resource.AttachConsumables.Pre"
            };

            // Only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            if (executionVeridict
                && IKEADEEActionUtilities.GetInputItem<Dictionary<IMaterial, IAttachConsumableParameters>>(Input, "Materials") == null)
            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            //System
            UseReference("", "Cmf.Navigo.BusinessOrchestration.Abstractions");
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");

            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            //IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            var materialOrchestration = serviceProvider.GetService<IMaterialOrchestration>();

            Dictionary<IMaterial, IAttachConsumableParameters> attachedMaterials = IKEADEEActionUtilities.GetInputItem<Dictionary<IMaterial, IAttachConsumableParameters>>(Input, "Materials");

            // collect materials to process
            IMaterialCollection materialsToProcess = entityFactory.CreateCollection<IMaterialCollection>();
            materialsToProcess.AddRange(attachedMaterials.Keys);
            Dictionary<long, IMaterial> materialsToProcessDictionary = materialsToProcess.ToDictionary(E => E.Id, E => E);

            // Collect all materials linked to a product revision
            Dictionary<long, long> materialOldProduct = attachedMaterials.ToDictionary(E => E.Key.Id, E => E.Key.GetNativeValue<long>("Product"));
            Dictionary<long, IProduct> materialNewProduct = new Dictionary<long, IProduct>();

            // Load all products at once
            List<long> productIds = materialOldProduct.Select(E => E.Value).Distinct().ToList();
            IProductCollection currentProducts = entityFactory.CreateCollection<IProductCollection>();
            currentProducts.LoadByIDs<IProduct, Product>(productIds);
            currentProducts.LoadAttributes(new Collection<string>() { IKEAConstants.CustomProductAttributeBaseProduct
                                                          , IKEAConstants.CustomProductAttributeRevision });

            // collect base products for each product. empty means it has none, otherwise product is a revision
            // assumning existence of product revision attribute means base product also exists
            Dictionary<long, string> productBaseProduct = currentProducts.ToDictionary(E => E.DefinitionId
                , E => E.RelatedAttributes.ContainsKey(IKEAConstants.CustomProductAttributeRevision)
                        && !String.IsNullOrWhiteSpace(Convert.ToString(E.RelatedAttributes[IKEAConstants.CustomProductAttributeRevision]))
                        ? Convert.ToString(E.RelatedAttributes[IKEAConstants.CustomProductAttributeBaseProduct]) : String.Empty
                        );


            // cross materials with existence of a product revision to determine which ones we have to change
            List<long> materialIdsToChangeProduct = materialsToProcess.Where(E => !String.IsNullOrWhiteSpace(productBaseProduct[materialOldProduct[E.Id]])).Select(E => E.Id).ToList();

            // if there are materials with a product to change, do it
            if (materialIdsToChangeProduct.Count > 0)
            {
                IProduct product = entityFactory.Create<IProduct>();
                // load all base products
                IProductCollection newProducts = entityFactory.CreateCollection<IProductCollection>();
                List<string> baseProductsToLoad = productBaseProduct.Where(E => !String.IsNullOrEmpty(E.Value)).Select(E => E.Value).Distinct().ToList();
                foreach (string baseProductName in baseProductsToLoad)
                {
                    product.Name = baseProductName;
                    newProducts.Add(product);
                }
                newProducts.Load();

                // facilitate product access
                Dictionary<string, IProduct> newProductsDictionary = newProducts.ToDictionary(E => E.Name, E => E);

                // create product change dictionary
                Dictionary<IMaterial, IProduct> materialsNewProduct = materialIdsToChangeProduct.ToDictionary(E => materialsToProcessDictionary[E], E => newProductsDictionary[productBaseProduct[materialOldProduct[E]]]);

                // collect material objects in collection
                IMaterialCollection materialsToChange = entityFactory.CreateCollection<IMaterialCollection>();
                materialsToChange.AddRange(materialsNewProduct.Keys);

                foreach (var mat in materialsNewProduct)
                {
                    // Key: Old Product & Value: New Product
                    mat.Value.LoadSubProducts();
                    var subProd = mat.Value.SubProducts ?? entityFactory.CreateCollection<ISubProductCollection>();
                    bool subProductExists = subProd.Any(x => x.TargetEntity.Name == mat.Key.Product.Name);
                    if (!subProductExists)
                    {
                        // Check If new product already available in sub product of old product
                        ISubProductCollection subProducts = entityFactory.CreateCollection<ISubProductCollection>();
                        ISubProduct subProduct = entityFactory.Create<ISubProduct>();
                        subProduct.SourceEntity = mat.Value;
                        subProduct.TargetEntity = mat.Key.Product;

                        //subProduct.SourceEntity = mat.Key.Product.Name;
                        //subProduct.Load();
                        subProducts.Add(subProduct);
                        mat.Value.AddSubProducts(subProducts);
                    }
                }


                materialsToChange.SpecialChangeProduct(materialsNewProduct);

                // ensure input is reloaded
                materialsToProcess.Load();

            }

            // check need for retrieving from storage location
            IMaterialCollection materialsToRetrieve = entityFactory.CreateCollection<IMaterialCollection>();
            materialsToRetrieve.AddRange(attachedMaterials.Keys.Where(E => E.IsInStore.GetValueOrDefault()));
            if(materialsToRetrieve.Any())
            {
                // perform retrieval of materials to allow storing
                materialOrchestration.RetrieveMaterials(new RetrieveMaterialsInput() { Materials = materialsToRetrieve });

                // ensure input is reloaded
                materialsToRetrieve.Load();
            }



            //---End DEE Code---

            return Input;
        }
    }
}
