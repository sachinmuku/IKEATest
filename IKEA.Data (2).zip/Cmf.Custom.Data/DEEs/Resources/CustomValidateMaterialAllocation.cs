﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;

using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace Cmf.Custom.IKEA.Actions.Resources
{
    public class CustomValidateMaterialAllocation : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text:
            ///     Validate the hard allocation of the materials
            /// Action Groups:
            ///     BusinessObjects.Resource.AttachConsumables.Pre
            /// Depends On:
            ///     CustomConsumableAttachmentValidation
            /// Exceptions:
            ///     MaterialAllocatedInAnotherProductionOrderException
            ///     MaterialNotAllocatedException
            /// </summary>
            #endregion

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();
            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.Resource.AttachConsumables.Pre"
            };

            // Only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            if (executionVeridict
                && (
                        deeContextUtilities.GetContextParameter("AllocationsValidMaterials") == null
                        ||
                        IKEADEEActionUtilities.GetInputItem<IResource>(Input, "Resource") == null
                   )
                )
            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            //System
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("", "System.IO");
            UseReference("", "System.Threading");
            UseReference("", "System");

            //Foundation
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IResource consumableFeed = IKEADEEActionUtilities.GetInputItem<IResource>(Input, "Resource");
            IBOMProductCollection validBomProducts = deeContextUtilities.GetContextParameter("AllocationsValidBOMProducts") as IBOMProductCollection;
            IMaterialCollection validMaterials = deeContextUtilities.GetContextParameter("AllocationsValidMaterials") as IMaterialCollection;

            if (!validMaterials.IsNullOrEmpty())
            {
                ikeaUtilities.ValidateMaterialAllocations(validMaterials, consumableFeed, validBomProducts);
            }

            //---End DEE Code---

            return Input;
        }
    }
}
