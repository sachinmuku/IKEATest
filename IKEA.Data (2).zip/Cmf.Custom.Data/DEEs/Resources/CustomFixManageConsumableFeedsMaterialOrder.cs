﻿using Cmf.Custom.IKEA.Common;
using Cmf.Foundation.BusinessObjects.QueryObject;
using Cmf.Foundation.BusinessOrchestration.QueryManagement.InputObjects;
using System.Collections.Generic;
using System.Linq;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Custom.IKEA.Common.DEE;

namespace Cmf.Custom.IKEA.Actions.Resources
{
    public class CustomFixManageConsumableFeedsMaterialOrder : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     DEE to fix the order in which the materials appear in the Manage Consumables Wizard
            /// Action Groups:
            ///     QueryManagement.QueryManagementOrchestration.ExecuteQuery.Pre
            /// </summary>
            #endregion

            ExecuteQueryInput executeQueryInput = IKEADEEActionUtilities.GetInputItem<ExecuteQueryInput>(Input, "ExecuteQueryInput");

            // Check if the query being executed is the one for the Manage Consumable Feeds Wizard
            return executeQueryInput != null 
                    && executeQueryInput.QueryObject != null 
                    && executeQueryInput.QueryObject.Name != null 
                    && executeQueryInput.QueryObject.Name.CompareStrings("GA Get Consumable Feeds Query");

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            //System
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System");

            //Foundation
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.QueryManagement.InputObjects");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects.QueryObject");
            
            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");

            ExecuteQueryInput executeQueryInput = IKEADEEActionUtilities.GetInputItem<ExecuteQueryInput>(Input, "ExecuteQueryInput");

            IQueryObject queryObject = executeQueryInput.QueryObject;

            // Try to obtain the order Field
            IField orderField = executeQueryInput.QueryObject.Query.Fields.FirstOrDefault(f => f.ObjectName.CompareStrings("MaterialResource")
                                                                                            && f.ObjectAlias.CompareStrings("Resource_SubResource_TargetEntity_MaterialResource_4")
                                                                                            && f.Alias.CompareStrings("SubResourceTargetEntityMaterialResourceOrder"));

            // If the field already exists the change the sorting order
            // otherwise add a new field with the order
            if (orderField != null)
            {
                orderField.Sort = Cmf.Foundation.Common.FieldSort.Ascending;
            }
            else
            {
                // Add order field to the query
                executeQueryInput.QueryObject.Query.Fields.Add(new Field()
                {
                    Alias = "SubResourceTargetEntityMaterialResourceOrder",
                    ObjectAlias = "Resource_SubResource_TargetEntity_MaterialResource_4",
                    IsUserAttribute = false,
                    ObjectName = "MaterialResource",
                    Name = "Order",
                    Position = 19,
                    Sort = Cmf.Foundation.Common.FieldSort.Ascending
                });
            }

            //---End DEE Code---

            return Input;
        }
    }
}
