﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Utilities;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;

using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading;
using INotification = Cmf.Navigo.BusinessObjects.Abstractions.INotification;
using INotificationCollection = Cmf.Navigo.BusinessObjects.Abstractions.INotificationCollection;

namespace Cmf.Custom.IKEA.Actions.Resources
{
    /// <summary>
    /// DEE responsible for notifying employees that checked-in Resources have stop states that have not yet been classified.
    /// </summary>
    public class CustomResourceStopReclassificationNotification : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     
            /// Action Groups:
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion

            return true;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            //System
            UseReference("", "System");
            UseReference("", "System.Linq");
            UseReference("%MicrosoftNetPath%\\System.XML.dll", "System.Xml");
            UseReference("%MicrosoftNetPath%\\System.Data.dll", "System.Data");
            UseReference("%MicrosoftNetPath%\\System.Data.DataSetExtensions.dll", "");
            UseReference("", "System.Collections.Generic");
            UseReference("%MicrosoftNetPath%System.Private.CoreLib.dll", "System.Threading");
            //Foundation
            UseReference("Cmf.Foundation.Common.dll", "Cmf.Foundation.Common");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");

            // Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            ILocalizedMessage localizedMessage = serviceProvider.GetService<ILocalizedMessage>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();

            Dictionary<string, object> Output = new Dictionary<string, object>(Input);

            //Check if the timer's frequency has changed
            int timerFrequency = genericUtilities.GetConfigurationValueByPath<int>(IKEAConstants.ResourceStateReclassificationNotificationTimerFrequency);

            ICmfTimer notificationTimer = entityFactory.Create<ICmfTimer>();

            notificationTimer.Name = IKEAConstants.CustomResourceStopReclassificationNotificationTimer;

            notificationTimer.Load();

            //Update the timer's frequency
            if(timerFrequency != notificationTimer.RecurrenceDefinedSeconds)
            {
                notificationTimer.RecurrenceDefinedSeconds = timerFrequency;
                notificationTimer.Save();
            }


            //Get state timeframe from config
            int timeFrame = genericUtilities.GetConfigurationValueByPath<int>(IKEAConstants.ResourceStateReclassificationNotificationTimeframe);
            DateTime startDate = DateTime.Now.AddMinutes(-timeFrame);

            string severity = genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.ResourceStateReclassificationsNotificationSeverity);

            if (severity.IsNullOrEmpty())
            {
                severity = genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.DefaultNotificationSeverityConfig);
            }

            if (severity.IsNullOrEmpty())
            {
                throw new CmfBaseException(ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomDefaultNotificationSeverityConfigNotDefined, IKEAConstants.DefaultNotificationSeverityConfig));
            }

            //Note: full name space is required to avoid clashing with the Cmf.Foundation.Common namespace when compiling DEE
            DataSet resourceStateHistory = ikeaUtilities.GetResourceStateHistoryForStopReclassificationDataSet(startDate, DateTime.Now, microstopFilter: Cmf.Custom.IKEA.Common.Enums.CustomMicrostopThresholdFilterEnum.LongerThanThreshold);

            if (resourceStateHistory.HasData())
            {
                Cmf.Navigo.BusinessObjects.Abstractions.INotificationCollection notifications = entityFactory.CreateCollection<Cmf.Navigo.BusinessObjects.Abstractions.INotificationCollection>();

                //Store data in a dictionary to avoid performing loads multiple times
                Dictionary<long, IResource> loadedResources = new Dictionary<long, IResource>();
                Dictionary<long, IEmployee> loadedEmployees = new Dictionary<long, IEmployee>();

                foreach (DataRow resourceStateDataRow in resourceStateHistory.Tables[0].Rows)
                {
                    long resourceId = resourceStateDataRow.Field<long>("ResourceId");

                    IResource resource = entityFactory.Create<IResource>();

                    //Check if resource has been previously loaded
                    if (!loadedResources.ContainsKey(resourceId))
                    {
                        resource.Load(resourceId);
                        resource.Area.Load();
                        resource.Area.Facility.Load();
                        resource.LoadRelations("ResourceEmployee");

                        if (!resource.RelationCollection.IsNullOrEmpty() && !resource.RelationCollection["ResourceEmployee"].IsNullOrEmpty())
                        {
                            IEmployeeCollection unloadedCheckedInEmployees = entityFactory.CreateCollection<IEmployeeCollection>();

                            //load not previously loaded employees
                            unloadedCheckedInEmployees.AddRange(resource.RelationCollection["ResourceEmployee"].Select(resEmp => resEmp.TargetEntity as IEmployee).Where(emp => !loadedEmployees.ContainsKey(emp.Id)));

                            if (unloadedCheckedInEmployees.Any())
                            {
                                unloadedCheckedInEmployees.Load();

                                //store loaded employees in the 
                                loadedEmployees.AddRange(unloadedCheckedInEmployees.ToDictionary(emp => emp.Id, emp => emp));
                            }
                        }

                        loadedResources.Add(resourceId, resource);
                    }
                    else
                    {
                        //Retrieve from loaded resources collection
                        resource = loadedResources[resourceId];
                    }

                    if (!resource.RelationCollection.IsNullOrEmpty() && !resource.RelationCollection["ResourceEmployee"].IsNullOrEmpty())
                    {
                        IEnumerable<long> checkedInEmployeeIds = resource.RelationCollection["ResourceEmployee"].Select(resEmp => resEmp.TargetEntity.Id);

                        foreach (long empId in checkedInEmployeeIds)
                        {
                            IEmployee employee = loadedEmployees[empId];

                            string resourceState = resourceStateDataRow.Field<string>("MainStateModelStateName");
                            string stateReason = resourceStateDataRow.Field<string>("MainStateModelStateReason");
                            string fromDate = resourceStateDataRow.Field<DateTime>("StartModifiedOn").ToString();
                            string toDate = resourceStateDataRow.Field<DateTime>("EndModifiedOn").ToString();
                            string threshold = resourceStateDataRow.Field<int>("Threshold").ToString();

                            //Add a notification to the collection
                            Cmf.Navigo.BusinessObjects.Abstractions.INotification notification = entityFactory.Create<Cmf.Navigo.BusinessObjects.Abstractions.INotification>();

                            notification.Type = "System";
                            notification.Title = localizedMessage.LoadLocalizedMessage(Thread.CurrentThread.CurrentCulture.Name, IKEAConstants.CustomResourceStopReclassificationNotificationTitleLocalizedMessage).MessageText;
                            notification.Details = ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomResourceStopReclassificationNotificationDetailsLocalizedMessage, resource.Name, resourceState, stateReason, fromDate, toDate, threshold);
                            notification.Severity = ikeaUtilities.GetValueFromLookupTable(IKEAConstants.NotificationSeverityLookupTableName, severity, true);
                            notification.AssignmentType = (NotificationAssignmentType)AssignmentType.Employee;
                            notification.AssignedToUser = employee.User;
                            notification.Resource = resource;
                            notification.Area = resource.Area;
                            notification.Facility = resource.Area.Facility;


                            notifications.Add(notification);
                        }
                    }
                }

                if (notifications.Any())
                {
                    //Create all notifications
                    notifications.Create();
                }
            }

            Output["Result"] = true;

            return Output;

            //---End DEE Code---
        }
    }
}
