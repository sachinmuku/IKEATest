﻿using Cmf.Custom.IKEA.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cmf.Common.CustomActionUtilities;

namespace Cmf.Custom.IKEA.Actions.Resources
{
    /// <summary>
    /// This DEE checks for a given resource where a material is being attached to, to check if disables or not ERP communication regarding movement and
    /// consumption. Also removes any invalidation of communication on detach
    /// </summary>
    public class CustomAttachDetachMaterialCheckERPReporting : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     This DEE checks for a given resource where a material is being attached to, to check if disables or not ERP communication regarding movement and
            ///     consumption. Also removes any invalidation of communication on detach
            /// Action Groups:
            ///     BusinessObjects.Resource.AttachConsumables.Pre
            ///     BusinessObjects.Resource.DetachConsumables.Post
            ///     BusinessObjects.Resource.DetachConsumable.Post
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.Resource.AttachConsumables.Pre"
                , "BusinessObjects.Resource.DetachConsumables.Post"
                , "BusinessObjects.Resource.DetachConsumable.Post"
            };

            // Only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            //System
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System");

            //Foundation
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();

            // handle attach
            if (String.Equals(IKEADEEActionUtilities.GetActionGroup(Input), "BusinessObjects.Resource.AttachConsumables.Pre", StringComparison.InvariantCultureIgnoreCase))
            {
                // if resource is configured to block reporting, convey that limitation to the materials being attached
                Dictionary<IMaterial, IAttachConsumableParameters> attachInput = IKEADEEActionUtilities.GetInputItem<Dictionary<IMaterial, IAttachConsumableParameters>>(Input, "Materials");
                IResource resource = IKEADEEActionUtilities.GetInputItem<IResource>(Input, "Resource");
                if(attachInput != null && resource != null)
                {

                    if(resource.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomResourceAttributeIsReportingBlocked, true))
                    {
                        IMaterialCollection allMaterials = entityFactory.CreateCollection<IMaterialCollection>();
                        allMaterials.AddRange(attachInput.Keys);
                        allMaterials.SaveAttributes(new Foundation.BusinessObjects.AttributeCollection() { { IKEAConstants.CustomMaterialAttributeIsReportingBlocked, true } });
                    }
                }

            }
            // handle detach collection
            else if (String.Equals(IKEADEEActionUtilities.GetActionGroup(Input), "BusinessObjects.Resource.DetachConsumables.Post", StringComparison.InvariantCultureIgnoreCase))
            {
                IMaterialCollection materials = IKEADEEActionUtilities.GetInputItem<IMaterialCollection>(Input, "Materials");

                if(materials != null && materials.Count > 0)
                {
                    materials.RemoveAttributes(new Collection<string>() { IKEAConstants.CustomMaterialAttributeIsReportingBlocked });
                }
            }
            // handle detach singular
            else if (String.Equals(IKEADEEActionUtilities.GetActionGroup(Input), "BusinessObjects.Resource.DetachConsumable.Post", StringComparison.InvariantCultureIgnoreCase))
            {
                IMaterial material = IKEADEEActionUtilities.GetInputItem<IMaterial>(Input, "Material");
                if(material != null)
                {
                    material.RemoveAttributes(new Collection<string>() { IKEAConstants.CustomMaterialAttributeIsReportingBlocked });
                }
            }

            //---End DEE Code---

            return Input;
        }
    }
}