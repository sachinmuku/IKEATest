﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Orchestration.InputObjects;
using Cmf.Custom.IKEA.Orchestration.OutputObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects;
using Cmf.Navigo.BusinessOrchestration.ResourceManagement.OutputObjects;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.Resources
{
    /// <summary>
    /// This DEE captures all resource and events that should trigger an automatic refresh 
    /// of any UI Page connected to a given resource
    /// </summary>
    public class CustomResourceMaterialEventsPublisher : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info

            /// <summary>
            /// Summary text
            ///     This DEE captures all resource and events that should trigger an automatic refresh 
            ///     of any UI Page connected to a given resource
            /// Action Groups:
            ///     BusinessObjects.Resource.LogEvent.Post
            ///     BusinessObjects.Resource.ManageConsumableFeeds.Post
            ///     BusinessObjects.Resource.ManageDurables.Post
            ///     BusinessObjects.Material.LogEvent.Post
            ///     BusinessObjects.Material.SetMainStateModel.Post
            ///     BusinessObjects.Material.Merge.Post
            ///     BusinessObjects.Material.Release.Post            
            ///     BusinessObjects.MaterialCollection.Split.Post
            ///     BusinessObjects.MaterialCollection.AbortProcess.Post
            ///     BusinessObjects.MaterialCollection.ChangeFlowAndStep.Pre
            ///     BusinessObjects.MaterialCollection.ChangeType.Post
            ///     BusinessObjects.MaterialCollection.MoveToNextStep.Pre
            ///     BusinessObjects.MaterialCollection.MoveToStep.Pre
            ///     BusinessObjects.MaterialCollection.TrackOut.Post
            ///     BusinessObjects.MaterialCollection.Hold.Post
            ///     MaterialManagement.MaterialManagementOrchestration.ComplexTrackInMaterials.Post
            ///     MaterialManagement.MaterialManagementOrchestration.DispatchMaterials.Post
            ///     MaterialManagement.MaterialManagementOrchestration.PerformMaterialChecklistItems.Post
            ///     MaterialManagement.MaterialManagementOrchestration.UndispatchMaterials.Pre
            ///     Orchestration.IKEABusinessOrchestration.CustomStartMaterial.Post
            ///     Orchestration.IKEABusinessOrchestration.CustomStopMaterial.Post
            ///     Orchestration.IKEABusinessOrchestration.CustomSetMaterialState.Post
            ///     Orchestration.IKEABusinessOrchestration.CustomPostponeMaterial.Post
            ///     ResourceManagement.ResourceManagementOrchestration.DetachConsumableFromResource.Post
            ///     ResourceManagement.ResourceManagementOrchestration.DetachConsumablesFromResource.Post
            ///     ResourceManagement.ResourceManagementOrchestration.AttachConsumableToResource.Post
            ///     ResourceManagement.ResourceManagementOrchestration.AttachConsumablesToResource.Post
            /// </summary>

            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.Resource.LogEvent.Post"
                , "BusinessObjects.Resource.ManageConsumableFeeds.Post"
                , "BusinessObjects.Resource.ManageDurables.Post"
                , "BusinessObjects.Material.LogEvent.Post"
                , "BusinessObjects.Material.SetMainStateModel.Post"
                , "BusinessObjects.Material.Merge.Post"
                , "BusinessObjects.Material.Release.Post"
                , "BusinessObjects.MaterialCollection.Split.Post"             
                , "BusinessObjects.MaterialCollection.AbortProcess.Post"
                , "BusinessObjects.MaterialCollection.ChangeFlowAndStep.Pre"
                , "BusinessObjects.MaterialCollection.ChangeQuantity.Post"
                , "BusinessObjects.MaterialCollection.ChangeType.Post"
                , "BusinessObjects.MaterialCollection.MoveToNextStep.Pre"
                , "BusinessObjects.MaterialCollection.MoveToStep.Pre"
                , "BusinessObjects.MaterialCollection.TrackOut.Post"
                , "BusinessObjects.MaterialCollection.Hold.Post"                
                , "MaterialManagement.MaterialManagementOrchestration.ComplexTrackInMaterials.Post"
                , "MaterialManagement.MaterialManagementOrchestration.DispatchMaterials.Post"
                , "MaterialManagement.MaterialManagementOrchestration.PerformMaterialChecklistItems.Post"
                , "MaterialManagement.MaterialManagementOrchestration.UndispatchMaterials.Pre"
                , "Orchestration.IKEABusinessOrchestration.CustomStartMaterial.Post"
                , "Orchestration.IKEABusinessOrchestration.CustomStopMaterial.Post"
                , "Orchestration.IKEABusinessOrchestration.CustomSetMaterialState.Post"
                , "Orchestration.IKEABusinessOrchestration.CustomPostponeMaterial.Post"
                , "ResourceManagement.ResourceManagementOrchestration.DetachConsumableFromResource.Post"
                , "ResourceManagement.ResourceManagementOrchestration.DetachConsumablesFromResource.Post"
                , "ResourceManagement.ResourceManagementOrchestration.AttachConsumableToResource.Post"
                , "ResourceManagement.ResourceManagementOrchestration.AttachConsumablesToResource.Post"
            };

            // Only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            //System
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System");

            // Foundation
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "");
            UseReference("", "Cmf.Foundation.Common.Exceptions");
            UseReference("", "Cmf.Foundation.Common");

            //Navigo
            UseReference("Cmf.Navigo.Common.dll", "Cmf.Navigo.Common");
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.ResourceManagement");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.ResourceManagement.InputObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.ResourceManagement.OutputObjects");

            // Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Orchestration.dll", "Cmf.Custom.IKEA.Orchestration.OutputObjects");
            UseReference("Cmf.Custom.IKEA.Orchestration.dll", "Cmf.Custom.IKEA.Orchestration.InputObjects");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();


            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            ILocalizedMessage localizedMessage = serviceProvider.GetService<ILocalizedMessage>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();

            Collection<long> processedResources = deeContextUtilities.GetContextParameter(IKEAConstants.CustomResourceMaterialEventsPublisherProcessedResourceEvents) as Collection<long>;

            // holds list of distinct resources received.
            Collection<long> incomingResourceIds = new Collection<long>();

            // extract resources based on input
            if (Input != null)
            {
                // get triggering action group
                string actionGroup = IKEADEEActionUtilities.GetActionGroup(Input);

                // extract resources based on action group
                switch (actionGroup)
                {
                    case "BusinessObjects.Resource.LogEvent.Post":
                    case "BusinessObjects.Resource.ManageConsumableFeeds.Post":
                    case "BusinessObjects.Resource.ManageDurables.Post":
                        IResource resource = IKEADEEActionUtilities.GetInputItem<IResource>(Input, Cmf.Navigo.Common.Constants.Resource);
                        if (resource != null)
                        {
                            incomingResourceIds.Add(resource.Id);
                        }
                        break;

                    case "BusinessObjects.Material.LogEvent.Post":
                    case "BusinessObjects.Material.SetMainStateModel.Post":
                        IMaterial logEventMaterial = IKEADEEActionUtilities.GetInputItem<IMaterial>(Input, Cmf.Navigo.Common.Constants.Material);
                        if (logEventMaterial != null && logEventMaterial.GetNativeValue<long>("LastProcessedResource") > 0)
                        {
                            incomingResourceIds.Add(logEventMaterial.GetNativeValue<long>("LastProcessedResource"));
                        }
                        break;

                    case "BusinessObjects.MaterialCollection.ChangeFlowAndStep.Pre":
                    case "BusinessObjects.MaterialCollection.MoveToNextStep.Pre":
                    case "BusinessObjects.MaterialCollection.MoveToStep.Pre":
                    case "BusinessObjects.MaterialCollection.TrackOut.Post":
                    case "BusinessObjects.MaterialCollection.AbortProcess.Post":
                    case "BusinessObjects.MaterialCollection.ChangeQuantity.Post":
                    case "BusinessObjects.MaterialCollection.ChangeType.Post":
                        IMaterialCollection trackedOutMaterials = IKEADEEActionUtilities.GetInputItem<IMaterialCollection>(Input, Navigo.Common.Constants.MaterialCollection);
                        incomingResourceIds.AddRange(trackedOutMaterials.Select(m => m.GetNativeValue<long>("LastProcessedResource")).Distinct().Where(E => E > 0));
                        break;

                    case "MaterialManagement.MaterialManagementOrchestration.ComplexTrackInMaterials.Post":
                        IMaterialCollection trackedInMaterials = IKEADEEActionUtilities.GetInputItem<ComplexTrackInMaterialsOutput>(Input, "ComplexTrackInMaterialsOutput").Materials;
                        incomingResourceIds.AddRange(trackedInMaterials.Select(m => m.GetNativeValue<long>("LastProcessedResource")).Distinct().Where(E => E > 0));
                        break;

                    case "MaterialManagement.MaterialManagementOrchestration.DispatchMaterials.Post":
                        DispatchMaterialsOutput dispatchOutput = IKEADEEActionUtilities.GetInputItem<DispatchMaterialsOutput>(Input, "DispatchMaterialsOutput");
                        if (dispatchOutput != null && dispatchOutput.Resources != null)
                        {
                            incomingResourceIds.AddRange(dispatchOutput.Resources.Where(E => E.Id > 0).Select(E => E.Id).Distinct());
                        }
                        break;

                    case "MaterialManagement.MaterialManagementOrchestration.UndispatchMaterials.Pre":
                        UndispatchMaterialsInput undispatchInput = IKEADEEActionUtilities.GetInputItem<UndispatchMaterialsInput>(Input, "UndispatchMaterialsInput");
                        if (undispatchInput != null && undispatchInput.Materials != null && undispatchInput.Materials.Count > 0)
                        {
                            Collection<long> tempResourceIds = new Collection<long>();

                            IMaterialCollection materialsToCheck = entityFactory.CreateCollection<IMaterialCollection>();
                            materialsToCheck.Load(new Collection<long>(undispatchInput.Materials.Where(E => E.Id > 0).Select(E => E.Id).ToList()));
                            materialsToCheck.LoadRelations("MaterialResource");
                            foreach (IMaterial materialToCheck in materialsToCheck)
                            {
                                if (materialToCheck.RelationCollection != null
                                    && materialToCheck.RelationCollection.ContainsKey("MaterialResource")
                                    && materialToCheck.RelationCollection["MaterialResource"] != null)
                                {
                                    tempResourceIds.AddRange(materialToCheck.RelationCollection["MaterialResource"].Select(E => E.GetNativeValue<long>("TargetEntity")));
                                }
                            }

                            incomingResourceIds.AddRange(tempResourceIds.Distinct().Where(E => E > 0));
                        }
                        break;

                    case "MaterialManagement.MaterialManagementOrchestration.PerformMaterialChecklistItems.Post":
                        PerformMaterialChecklistItemsOutput output = IKEADEEActionUtilities.GetInputItem<PerformMaterialChecklistItemsOutput>(Input, "PerformMaterialChecklistItemsOutput");
                        IMaterial material = output.Material;
                        if (material != null && material.GetNativeValue<long>("LastProcessedResource") > 0)
                        {
                            incomingResourceIds.Add(material.GetNativeValue<long>("LastProcessedResource"));
                        }
                        break;

                    case "Orchestration.IKEABusinessOrchestration.CustomPostponeMaterial.Post":
                        CustomPostponeMaterialInput customPostponeMaterialInput = IKEADEEActionUtilities.GetInputItem<CustomPostponeMaterialInput>(Input, "CustomPostponeMaterialInput");
                        if (customPostponeMaterialInput != null && customPostponeMaterialInput.Resource != null)
                        {
                            incomingResourceIds.Add(customPostponeMaterialInput.Resource.Id);
                        }
                        break;

                    case "Orchestration.IKEABusinessOrchestration.CustomStartMaterial.Post":
                        CustomStartMaterialOutput customStartMaterialOutput = IKEADEEActionUtilities.GetInputItem<CustomStartMaterialOutput>(Input, "CustomStartMaterial");
                        if (customStartMaterialOutput != null && customStartMaterialOutput.Material != null && customStartMaterialOutput.Material.GetNativeValue<long>("LastProcessedResource") > 0)
                        {
                            incomingResourceIds.Add(customStartMaterialOutput.Material.GetNativeValue<long>("LastProcessedResource"));
                        }

                        break;

                    case "Orchestration.IKEABusinessOrchestration.CustomStopMaterial.Post":
                        CustomStopMaterialOutput customStopMaterialOutput = IKEADEEActionUtilities.GetInputItem<CustomStopMaterialOutput>(Input, "CustomStopMaterialOutput");
                        if (customStopMaterialOutput != null && customStopMaterialOutput.Material != null && customStopMaterialOutput.Material.GetNativeValue<long>("LastProcessedResource") > 0)
                        {
                            incomingResourceIds.Add(customStopMaterialOutput.Material.GetNativeValue<long>("LastProcessedResource"));
                        }
                        break;

                    case "Orchestration.IKEABusinessOrchestration.CustomSetMaterialState.Post":
                        CustomSetMaterialStateOutput customSetMaterialStateOutput = IKEADEEActionUtilities.GetInputItem<CustomSetMaterialStateOutput>(Input, "CustomSetMaterialStateOutput");
                        if (customSetMaterialStateOutput != null && customSetMaterialStateOutput.Material != null && customSetMaterialStateOutput.Material.GetNativeValue<long>("LastProcessedResource") > 0)
                        {
                            incomingResourceIds.Add(customSetMaterialStateOutput.Material.GetNativeValue<long>("LastProcessedResource"));
                        }
                        break;

                    case "ResourceManagement.ResourceManagementOrchestration.DetachConsumableFromResource.Post":
                        DetachConsumableFromResourceOutput detachConsumableFromResourceOutput = IKEADEEActionUtilities.GetInputItem<DetachConsumableFromResourceOutput>(Input, "DetachConsumableFromResourceOutput");
                        if (detachConsumableFromResourceOutput != null && detachConsumableFromResourceOutput.Resource != null)
                        {
                            incomingResourceIds.Add(detachConsumableFromResourceOutput.Resource.GetTopMostResource().Id);
                        }
                        break;

                    case "ResourceManagement.ResourceManagementOrchestration.DetachConsumablesFromResource.Post":
                        DetachConsumablesFromResourceOutput detachConsumablesFromResourceOutput = IKEADEEActionUtilities.GetInputItem<DetachConsumablesFromResourceOutput>(Input, "DetachConsumablesFromResourceOutput");
                        if (detachConsumablesFromResourceOutput != null && detachConsumablesFromResourceOutput.Resource != null)
                        {
                            incomingResourceIds.Add(detachConsumablesFromResourceOutput.Resource.GetTopMostResource().Id);
                        }
                        break;

                    case "ResourceManagement.ResourceManagementOrchestration.AttachConsumableToResource.Post":
                        AttachConsumableToResourceOutput attachConsumableToResourceOutput = IKEADEEActionUtilities.GetInputItem<AttachConsumableToResourceOutput>(Input, "AttachConsumableToResourceOutput");
                        if (attachConsumableToResourceOutput != null && attachConsumableToResourceOutput.Resource != null)
                        {
                            incomingResourceIds.Add(attachConsumableToResourceOutput.Resource.GetTopMostResource().Id);
                        }
                        break;

                    case "ResourceManagement.ResourceManagementOrchestration.AttachConsumablesToResource.Post":
                        AttachConsumablesToResourceOutput attachConsumablesToResourceOutput = IKEADEEActionUtilities.GetInputItem<AttachConsumablesToResourceOutput>(Input, "AttachConsumablesToResourceOutput");
                        if (attachConsumablesToResourceOutput != null && attachConsumablesToResourceOutput.Resource != null)
                        {
                            incomingResourceIds.Add(attachConsumablesToResourceOutput.Resource.GetTopMostResource().Id);
                        }
                        break;

                    case "BusinessObjects.Material.Release.Post":
                    case "BusinessObjects.Material.Merge.Post":
                        IMaterial parentMaterial = IKEADEEActionUtilities.GetInputItem<IMaterial>(Input, "Material");
                        if (parentMaterial != null && parentMaterial.LastProcessedResource != null && parentMaterial.SystemState == MaterialSystemState.Processed)
                        {
                            incomingResourceIds.Add(parentMaterial.LastProcessedResource.GetTopMostResource().Id);
                        }
                        break;

                    case "BusinessObjects.MaterialCollection.Split.Post":
                        Dictionary<IMaterial, IMaterialCollection> outputChildMaterials = IKEADEEActionUtilities.GetInputItem<Dictionary<IMaterial, IMaterialCollection>>(Input, "OutputChildMaterials");
                        foreach (IMaterial outputChildMaterial in outputChildMaterials.Keys)
                        {
                            if (outputChildMaterial.LastProcessedResource != null && outputChildMaterial.SystemState == MaterialSystemState.Processed)
                            {
                                incomingResourceIds.Add(outputChildMaterial.LastProcessedResource.GetTopMostResource().Id);
                            }
                        }
                        break;

                    case "BusinessObjects.MaterialCollection.Hold.Post":
                        IMaterialCollection materialsOnHold = IKEADEEActionUtilities.GetInputItem<IMaterialCollection>(Input, "MaterialCollection");
                        foreach (IMaterial materialOnHold in materialsOnHold)
                        {
                            if (materialOnHold.LastProcessedResource != null && materialOnHold.SystemState == MaterialSystemState.Processed)
                            {
                                incomingResourceIds.Add(materialOnHold.LastProcessedResource.GetTopMostResource().Id);
                            }
                        }
                        break;

                    default:
                        break;

                }

                if (incomingResourceIds.Count > 0)
                {
                    if (processedResources == null)
                        processedResources = new Collection<long>();

                    // only process resources not yet processed
                    var unprocessedResources = incomingResourceIds.Except(processedResources);
                    foreach (long resourceId in unprocessedResources)
                    {
                        // publish message and add resource id to the list of processed resources

                        string messageSubject = String.Format("{0}{1}", IKEAConstants.MessageBusResourceAndMaterialEventsPrefix, resourceId);
                        ikeaUtilities.PublishCockpitTransactionalMessages(messageSubject, actionGroup);

                        processedResources.Add(resourceId);
                    }

                    // update context parameter
                    deeContextUtilities.SetContextParameter(IKEAConstants.CustomResourceMaterialEventsPublisherProcessedResourceEvents, processedResources);
                }
            }

            //---End DEE Code---

            return Input;
        }
    }
}
