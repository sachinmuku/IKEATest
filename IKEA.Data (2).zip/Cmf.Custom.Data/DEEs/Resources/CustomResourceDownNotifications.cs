﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Foundation.Security;
using Cmf.Foundation.Security.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;

using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using INotification = Cmf.Navigo.BusinessObjects.Abstractions.INotification;

namespace Cmf.Custom.IKEA.Actions.Resources
{
    public class CustomResourceDownNotifications : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Creates notification indicating that the Resource as been in the same state more time that is expected
            /// </summary>
            #endregion

            bool executionVeridict = IKEADEEActionUtilities.GetInputItem<ICmfTimer>(Input, "CmfTimer") != null;

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            //System
            UseReference("", "System");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");

            //Foundation
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.Security.dll", "Cmf.Foundation.Security");
            UseReference("", "Cmf.Foundation.Common");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.BusinessObjects.CustomAlarmOccurrence.dll", "Cmf.Custom.IKEA.BusinessObjects");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();

            ICmfTimer cmfTimer = IKEADEEActionUtilities.GetInputItem<ICmfTimer>(Input, "CmfTimer");

            Dictionary<string, object> output = new Dictionary<string, object>();

            // CustomResourceDownNotifications_{ResourceName}_{Timestamp}
            string[] timerName = cmfTimer.Name.Split('_');

            // Check if the timer name is made up of the expected 3 strings
            if (timerName.Length == 3)
            {
                // Check if the timer name has the right context
                if (timerName[0] == IKEAConstants.CustomResourceDownNotificationsContext)
                {
                    // Get Resource by Name
                    IResource resource = entityFactory.Create<IResource>();

                    resource.Name = timerName[1];


                    resource.Load();

                    // Check if the resource defined in the timer exists
                    if (resource.Id > 0)
                    {
                        // Load the attribute that indicates when was the resource state changed for the last time
                        resource.LoadAttributes(new Collection<string>() { IKEAConstants.LastStateChangeTimestampAttribute });

                        // Get the timestamp from the last time the resource state has changed
                        string timestamp = resource.GetAttributeValueOrDefault<string>(IKEAConstants.LastStateChangeTimestampAttribute);

                        if (!string.IsNullOrEmpty(timestamp))
                        {
                            // Check if the resource state changed since the timer was created
                            if (timerName[2].CompareStrings(timestamp))
                            {
                                // Get the Time Threshold, role and distribution list configured in the smart table
                                Tuple<int, string, string, string> resourceNotificationSettings = ikeaUtilities.GetTimeThresholdForResourceStateNotifications(resource.Area.Facility.Name,
                                                                                                                                                        resource.Area.Name,
                                                                                                                                                        resource.Name,
                                                                                                                                                        resource.Type,
                                                                                                                                                        resource.CurrentMainState.CurrentState.Name);

                                // Check if any configuration exists
                                if (resourceNotificationSettings != null)
                                {
                                    int timeThreshold = resourceNotificationSettings.Item1;
                                    string notificationRole = resourceNotificationSettings.Item2;
                                    string notificationDistributionList = resourceNotificationSettings.Item3;
                                    string maintenanceActivity = resourceNotificationSettings.Item4;

                                    IRole role = new Role();

                                    // Check if any role was defined
                                    if (!string.IsNullOrEmpty(notificationRole))
                                    {
                                        role.Load(notificationRole);
                                    }

                                    // Check if maintenance activity is defined
                                    if (!string.IsNullOrEmpty(maintenanceActivity))
                                    {
                                        ikeaUtilities.ResourceMAOHandling(resource.Name, maintenanceActivity, null);
                                    }


                                    // Check if the given role exists
                                    if (role.Id > 0 || !string.IsNullOrEmpty(notificationDistributionList))
                                    {
                                        //Validate if Severity exists in config
                                        string severity = ikeaUtilities.GetValueFromConfigurationWithPath(IKEAConstants.DefaultNotificationSeverityConfig);

                                        if (severity.IsNullOrEmpty())
                                        {
                                            throw new CmfBaseException(ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomDefaultNotificationSeverityConfigNotDefined, IKEAConstants.DefaultNotificationSeverityConfig));
                                        }

                                        // Create Notification
                                        Cmf.Navigo.BusinessObjects.Abstractions.INotification notification = entityFactory.Create<Cmf.Navigo.BusinessObjects.Abstractions.INotification>();

                                        notification.Type = "System";
                                        notification.Title = ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomResourceDownNotificationTitleLocalizedMessage, resource.Name, resource.CurrentMainState.CurrentState.Name, timeThreshold.ToString());
                                        notification.Details = ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomResourceDownNotificationTitleLocalizedMessage, resource.Name, resource.CurrentMainState.CurrentState.Name, timeThreshold.ToString());
                                        notification.Severity = ikeaUtilities.GetValueFromLookupTable(IKEAConstants.NotificationSeverityLookupTableName, ikeaUtilities.GetValueFromConfigurationWithPath(IKEAConstants.DefaultNotificationSeverityConfig), true);
                                        notification.AssignmentType = (NotificationAssignmentType)AssignmentType.Role;
                                        notification.AssignedToRole = role;
                                        notification.SendEmailToAssignedParty = (role.Id > 0); // If role not defined then only sends notification to Distribution 
                                        notification.EmailDistributionList = notificationDistributionList;


                                        notification.Create();

                                        output.Add("Result", string.Format(IKEAConstants.CustomResourceDownNotificationResultNotificationCreated, resource.Name));
                                    }
                                    else
                                    {
                                        output.Add("Result", IKEAConstants.CustomResourceDownNotificationResultNoRoleDistributionList);
                                    }
                                }
                            }
                            else
                            {
                                output.Add("Result", string.Format(IKEAConstants.CustomResourceDownNotificationResultStateOfResourceChanged, resource.Name));
                            }
                        }
                        else
                        {
                            output.Add("Result", string.Format(IKEAConstants.CustomResourceDownNotificationResultResourceDoesNotHaveAttribute, resource.Name));
                        }
                    }
                    else
                    {
                        output.Add("Result", string.Format(IKEAConstants.CustomResourceDownNotificationResultResourceDoesNotExist, timerName[1]));
                    }
                }
                else
                {
                    output.Add("Result", IKEAConstants.CustomResourceDownNotificationResultWrongTimerName);
                }
            }
            else
            {
                output.Add("Result", IKEAConstants.CustomResourceDownNotificationResultWrongTimerName);
            }

            return output;

            //---End DEE Code---

        }

    }
}
