﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common;
using Cmf.Navigo.BusinessOrchestration.ResourceManagement.InputObjects;
using Microsoft.Extensions.DependencyInjection;

using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Threading;

namespace Cmf.Custom.IKEA.Actions.Resources
{
    class CustomResourceEnforceCommentOnChangeState : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {

        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Dee rule to validate if a resource requires a comment by the operator when changing its state
            /// Action Groups:
            ///     ResourceManagement.ResourceManagementOrchestration.ComplexLogResourceEvent.Pre
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "ResourceManagement.ResourceManagementOrchestration.ComplexLogResourceEvent.Pre"
            };

            // Only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            if (executionVeridict && IKEADEEActionUtilities.GetInputItem<ComplexLogResourceEventInput>(Input, "ComplexLogResourceEventInput") == null)
            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            //System
            UseReference("", "System");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.ResourceManagement.InputObjects");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetRequiredService<IIKEAUtilities>();
            ILocalizedMessage localizedMessage = serviceProvider.GetService<ILocalizedMessage>();

            //DEE context 
            DeeContext currentDEEContext = deeContextUtilities.SetCurrentServiceContext("CustomResourceEnforceCommentOnChangeState");

            switch (currentDEEContext.MethodName)
            {
                // BusinessObjects.Resource.LogEvent.Post
                case "ComplexLogResourceEvent":
                    {
                        if (currentDEEContext.TriggerPoint == DeeTriggerPoint.Pre)
                        {

                            ComplexLogResourceEventInput complexLogResourceEventInput = IKEADEEActionUtilities.GetInputItem<ComplexLogResourceEventInput>(Input, "ComplexLogResourceEventInput");

                            // Only if there is a valid transition (different statemodel state or different reason):
                            if (!complexLogResourceEventInput.StateModelTransition.FromState.Name.CompareStrings(complexLogResourceEventInput.StateModelTransition.ToState.Name) ||
                                !complexLogResourceEventInput.Resource.CurrentMainState.Reason.CompareStrings(complexLogResourceEventInput.Reason))
                            {

                                // If there is no ServiceComment specified, check if it must be enforced:
                                if (complexLogResourceEventInput.ServiceComments.IsNullOrEmpty())
                                {                                                                        
                                    if (complexLogResourceEventInput.Resource != null)
                                    {
                                        bool enforceMessage = ikeaUtilities.GetResourceChangeStateEnforceComment(
                                            complexLogResourceEventInput.Resource,
                                            complexLogResourceEventInput.StateModel,
                                            complexLogResourceEventInput.StateModelTransition.FromState,
                                            complexLogResourceEventInput.Resource.CurrentMainState.Reason
                                            );

                                        if (enforceMessage)
                                        {
                                            throw new CmfBaseException(localizedMessage.LoadLocalizedMessage(Thread.CurrentThread.CurrentCulture.Name, IKEAConstants.CustomResourceEnforceCommentOnChangeStateCommentNecessaryLocalizedMessage).MessageText);
                                        }
                                    }
                                }
                            }
                        }
                        break;
                    }
            }

            //---End DEE Code---

            return Input;
        }



    }
}
