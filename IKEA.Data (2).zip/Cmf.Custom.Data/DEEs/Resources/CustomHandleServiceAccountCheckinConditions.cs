﻿using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Orchestration.InputObjects;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Foundation.Security;
using Cmf.Foundation.Security.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.Abstractions;
using Cmf.Navigo.BusinessOrchestration.LaborManagement;
using Cmf.Navigo.BusinessOrchestration.LaborManagement.InputObjects;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Actions.Resources
{
    /// <summary>
    /// This DEE checks for the need to auto checkin system account on a Resource
    /// </summary>
    public class CustomHandleServiceAccountCheckinConditions : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     This DEE checks for the need to auto checkin system account on a Resource
            /// </summary>
            #endregion

            // By default, action is not to be executed
            bool executionVeridict = false;

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "Orchestration.IKEABusinessOrchestration.CustomUnitComplete.Pre"
                , "Orchestration.IKEABusinessOrchestration.CustomStopMaterial.Pre"
                , "Orchestration.IKEABusinessOrchestration.CustomScanInMaterial.Pre"
                , "Orchestration.IKEABusinessOrchestration.CustomStartMaterial.Pre"
                , "Orchestration.IKEABusinessOrchestration.CustomSetMaterialState.Pre"
                , "Orchestration.IKEABusinessOrchestration.CustomClearMaterialAdmissionInterlock.Pre"
                , "Orchestration.IKEABusinessOrchestration.CustomUpdateInterlockStatus.Pre"
            };

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();

            // extract execution account
            string automationExecutionAccount = genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.AutomationExecutionAccount);

            // get user invoking service...
            IUser currentUser = ikeaUtilities.GetInvokingUser();

            // only proceed if within expected triggers (action groups), execution account is configured and user is current....
            executionVeridict = !String.IsNullOrWhiteSpace(automationExecutionAccount)
                                && String.Equals(automationExecutionAccount, currentUser.UserAccount, StringComparison.InvariantCultureIgnoreCase)
                                && IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);
            
            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            // CORE
            UseReference("", "Cmf.Navigo.BusinessOrchestration.Abstractions");
UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "");
            UseReference("", "Cmf.Foundation.Common.Exceptions");
            UseReference("", "Cmf.Foundation.Common");
            UseReference("Cmf.Foundation.Security.dll", "Cmf.Foundation.Security");

            // MES
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.LaborManagement.InputObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.LaborManagement");
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            // CUSTOM 
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Orchestration.dll", "");
            UseReference("Cmf.Custom.IKEA.Orchestration.dll", "Cmf.Custom.IKEA.Orchestration.InputObjects");
var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            //IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            var laborOrchestration = serviceProvider.GetService<ILaborOrchestration>();
          
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();


            if (Input != null)
            {
                IResource resourceToCheck = null;

                #region Collect Resource

                // extract relevant resource information from input
                if (Input.ContainsKey("CustomUnitCompleteInput"))
                {
                    CustomUnitCompleteInput customUnitCompleteInput = Input["CustomUnitCompleteInput"] as CustomUnitCompleteInput;
                    if(customUnitCompleteInput != null && customUnitCompleteInput.ProcessOrderMaterial != null )
                    {
                        resourceToCheck = customUnitCompleteInput.ProcessOrderMaterial.LastProcessedResource;
                    }
                }
                else if (Input.ContainsKey("CustomStopMaterialInput"))
                {
                    CustomStopMaterialInput customStopMaterialInput = Input["CustomStopMaterialInput"] as CustomStopMaterialInput;
                    if (!String.IsNullOrWhiteSpace(customStopMaterialInput.MaterialName))
                    {
                        IMaterial materialToCheck = entityFactory.Create<IMaterial>();
                        materialToCheck.Name = customStopMaterialInput.MaterialName;
                        materialToCheck.Load();
                        resourceToCheck = materialToCheck.LastProcessedResource;
                    }
                }
                else if (Input.ContainsKey("CustomScanInMaterialInput"))
                {
                    CustomScanInMaterialInput customScanInMaterialInput = Input["CustomScanInMaterialInput"] as CustomScanInMaterialInput;
                    if(customScanInMaterialInput != null && !String.IsNullOrWhiteSpace(customScanInMaterialInput.Resource))
                    {
                        IResource incomingResource = entityFactory.Create<IResource>();
                        incomingResource.Load(customScanInMaterialInput.Resource);
                        resourceToCheck = incomingResource.GetTopMostResource();
                    }
                }
                else if (Input.ContainsKey("CustomStartMaterialInput"))
                {
                    CustomStartMaterialInput customStartMaterialInput = Input["CustomStartMaterialInput"] as CustomStartMaterialInput;
                    if (customStartMaterialInput.Material != null)
                    {
                        resourceToCheck = customStartMaterialInput.Material.LastProcessedResource;
                    }
                }
                else if (Input.ContainsKey("CustomSetMaterialStateInput"))
                {
                    CustomSetMaterialStateInput customSetMaterialStateInput = Input["CustomSetMaterialStateInput"] as CustomSetMaterialStateInput;
                    if (customSetMaterialStateInput != null && (!String.IsNullOrWhiteSpace(customSetMaterialStateInput.MaterialName) || customSetMaterialStateInput.Material != null))
                    {
                        if(customSetMaterialStateInput.Material != null)
                        {
                            resourceToCheck = customSetMaterialStateInput.Material.LastProcessedResource;
                        }
                        else
                        {
                            IMaterial materialToCheck = entityFactory.Create<IMaterial>();
                            materialToCheck.Name = customSetMaterialStateInput.MaterialName;
                            materialToCheck.Load();
                            resourceToCheck = materialToCheck.LastProcessedResource;
                        }
                    }

                }
                else if (Input.ContainsKey("CustomClearMaterialAdmissionInterlockInput"))
                {
                    CustomClearMaterialAdmissionInterlockInput customClearMaterialAdmissionInterlockInput = Input["CustomClearMaterialAdmissionInterlockInput"] as CustomClearMaterialAdmissionInterlockInput;
                    if(customClearMaterialAdmissionInterlockInput != null)
                    {
                        resourceToCheck = customClearMaterialAdmissionInterlockInput.Resource;
                    }
                }
                else if (Input.ContainsKey("CustomUpdateInterlockStatusInput"))
                {
                    CustomUpdateInterlockStatusInput customUpdateInterlockStatusInput = Input["CustomUpdateInterlockStatusInput"] as CustomUpdateInterlockStatusInput;
                    if (customUpdateInterlockStatusInput != null)
                    {
                        IResource incomingResource = entityFactory.Create<IResource>();
                        incomingResource.Load(Convert.ToInt64(customUpdateInterlockStatusInput.ResourceId));
                        resourceToCheck = incomingResource;
                    }
                }

                #endregion Collect Resource

                if(resourceToCheck != null && resourceToCheck.EnableCheckIn && resourceToCheck.RequireCheckInForMaterialOperations)
                {
                    IEmployee employee = ikeaUtilities.GetCurrentEmployee();

                    // check if employee is already checked in
                    resourceToCheck.LoadRelations("ResourceEmployee");

                    // check for the need to check in
                    if (resourceToCheck.ResourceEmployees == null || !resourceToCheck.ResourceEmployees.Any(E => E.GetNativeValue<long>("TargetEntity") == employee.Id))
                    {
                        laborOrchestration.CheckInEmployees(new CheckInEmployeesInput()
                        {
                            Employees = new Dictionary<IEmployee, ICheckInEmployeeParameters>()
                                {
                                    {
                                        employee,
                                        new CheckInEmployeeParameters()
                                        {
                                            ResourcesCertification = new Dictionary<IResource, ICertification>()
                                            {
                                                { resourceToCheck, null }
                                            }
                                        }
                                    }
                                }
                        });

                        resourceToCheck.Load();
                    }
                }
            }

            //---End DEE Code---

            return null;
        }
    }
}