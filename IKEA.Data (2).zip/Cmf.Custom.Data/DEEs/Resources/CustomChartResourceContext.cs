using Cmf.Foundation.Common;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessOrchestration.ResourceManagement;
using Cmf.Navigo.BusinessOrchestration.ResourceManagement.InputObjects;
using Cmf.Navigo.BusinessOrchestration.ResourceManagement.OutputObjects;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Actions.Resources
{
    public class CustomChartResourceContext : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---
            /**Using Assembles**/
            UseReference("Cmf.Navigo.BusinessObjects.dll", "");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "");
            /**Using NameSpace**/
            UseReference("", "Cmf.Navigo.BusinessObjects");
            UseReference("", "Cmf.Navigo.BusinessOrchestration.ResourceManagement");
            UseReference("", "Cmf.Navigo.BusinessOrchestration.ResourceManagement.InputObjects");
            UseReference("", "Cmf.Navigo.BusinessOrchestration.ResourceManagement.OutputObjects");
            UseReference("", "System");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Linq");
            //Please start code here
            IMaterial material = Input[nameof(Material)] as IMaterial;
            IResource resource = Input[nameof(Resource)] as IResource;

            //If resource is null, get resource from material.
            if (resource == null && material != null)
            {
                material.LoadRelations(Cmf.Navigo.Common.Constants.MaterialResource);
                if (material.RelationCollection != null && material.RelationCollection.Count() > 0 && material.RelationCollection.ContainsKey(Constants.MaterialResource))
                {
                    resource = material.RelationCollection[Constants.MaterialResource].FirstOrDefault()?.TargetEntity as IResource;
                }
            }

            //Use topmost resource if available (user does not want to see sub-resources)
            if (resource != null)
            {
                IResource topResource = resource.GetTopMostResource();
                resource = topResource ?? resource;
                resource.Load();

                Input.Add("Result", resource);
            }

            //---End DEE Code---
            return Input;
        }

        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---
            return (Input["Resource"] is IResource) || (Input["Material"] is IMaterial);
            //---End DEE Condition Code---
        }
    }
}
