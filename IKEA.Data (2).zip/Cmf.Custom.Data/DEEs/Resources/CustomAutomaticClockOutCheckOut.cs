﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Custom.IKEA.Common;
using Cmf.Navigo.BusinessObjects;
using System.Collections.Generic;
using System.Linq;
using Cmf.Navigo.BusinessObjects.Abstractions;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;


namespace Cmf.Custom.IKEA.Actions.Resources
{
    public class CustomAutomaticClockOutCheckOut : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text:
            ///     Workaround for the Automatic Clock Out.
            ///     The base functionality does not work in version 7.0.2 when we have more than one
            ///     employee check-in in one resource
            /// Action Groups:
            ///     BusinessObjects.EmployeeCollection.SpecialCheckOut.Pre
            /// </summary>
            #endregion

            return true;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            //System
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.IO");
            UseReference("", "System.Threading");
            UseReference("", "System");

            //Foundation
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");

            // Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            Dictionary<IResource, IEmployeeCollection> resourceEmployees = IKEADEEActionUtilities.GetInputItem<Dictionary<IResource, IEmployeeCollection>>(Input, "ResourceEmployees");

            Dictionary<IResource, IEmployeeCollection> newResourceEmployees = new Dictionary<IResource, IEmployeeCollection>();

            // Create a new dictionary without repeated keys
            foreach (var resourceEmployee in resourceEmployees)
            {
                var existingresourceEmployee = newResourceEmployees.FirstOrDefault(re => re.Key.Id == resourceEmployee.Key.Id);

                if (!existingresourceEmployee.Equals(new KeyValuePair<IResource, IEmployeeCollection>()))
                {
                    existingresourceEmployee.Value.AddRange(resourceEmployee.Value);
                }
                else
                {
                    newResourceEmployees.Add(resourceEmployee.Key, resourceEmployee.Value);
                }
            }

            // Clear the all the records and replace them with the right ones
            resourceEmployees.Clear();
            resourceEmployees.AddRange(newResourceEmployees);

            //---End DEE Code---

            return null;
        }

    }
}
