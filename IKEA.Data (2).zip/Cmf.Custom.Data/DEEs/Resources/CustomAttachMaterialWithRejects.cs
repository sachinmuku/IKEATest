﻿using Cmf.Common.CustomActionUtilities;

using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Utilities;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;

using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.Resources
{
    public class CustomAttachMaterialWithRejects : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Sum the secondary quantity to the primary quantity for all the materials with the rejects defined
            /// Action Groups:
            ///     BusinessObjects.Resource.AttachConsumables.Pre
            /// </summary>
            #endregion

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            

            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            // Get the default reject unit
            string rejectUnit = genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.ScrapManagementRejectUnit);

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.Resource.AttachConsumables.Pre"
            };

            // Only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups) && !string.IsNullOrWhiteSpace(rejectUnit);

            if (executionVeridict
                && IKEADEEActionUtilities.GetInputItem<Dictionary<IMaterial, IAttachConsumableParameters>>(Input, "Materials") == null)
            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            //System
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Utilities");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();

            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();

            Dictionary<IMaterial, IAttachConsumableParameters> attachMaterials = IKEADEEActionUtilities.GetInputItem<Dictionary<IMaterial, IAttachConsumableParameters>>(Input, "Materials");

            IMaterialCollection materials = entityFactory.CreateCollection<IMaterialCollection>();

            // Get the default reject unit
            string rejectUnit = genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.ScrapManagementRejectUnit);

            // Get all the materials that have rejected quantity
            materials.AddRange(attachMaterials.Where(m => m.Key.SecondaryUnits.CompareStrings(rejectUnit) && m.Key.SecondaryQuantity > 0).Select(m => m.Key));

            // Check if any of the materials have rejected quantity
            if (!materials.IsNullOrEmpty())
            {
                IMaterialQuantityChangeCollection materialQuantities = new MaterialQuantityChangeCollection();

                // Go throw all the materials with rejected quantity 
                // and pass the secondary quantity to the primary quantity
                foreach (IMaterial material in materials)
                {
                    IMaterialQuantityChange materialQuantity = new MaterialQuantityChange()
                    {
                        Material = material,
                        NewPrimaryQuantity = material.PrimaryQuantity + material.SecondaryQuantity.Value,
                        NewSecondaryQuantity = 0
                    };

                    materialQuantities.Add(materialQuantity);
                }

                if (!materialQuantities.IsNullOrEmpty())
                {
                    materials.ChangeQuantity(materialQuantities, null);
                }
            }

            //---End DEE Code---

            return Input;
        }
    }
}
