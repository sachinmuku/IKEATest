﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;


using Cmf.Custom.IKEA.Common;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessObjects.QueryObject;
using Cmf.Foundation.BusinessOrchestration.QueryManagement.InputObjects;
using Cmf.Foundation.BusinessOrchestration.QueryManagement.OutputObjects;
using Cmf.Navigo.BusinessObjects;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace Cmf.Custom.IKEA.Actions.Resources
{
    public class CustomFabLiveOfflineResources : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   
            
            #region Info
            /// <summary>
            /// Summary text
            ///     DEE to fill in runtime any queries that ask for the attribute "FabLiveMainStateModel" in the "Resource" entity.
            ///     Used to compute the value for FabLive, taking into account not only the MainStateModelStateId of the resource,
            ///     but the Automation Mode as well (when it is offline or none).
            /// Action Groups:
            ///     QueryManagement.QueryManagementOrchestration.ExecuteQuery.Pre
            ///     QueryManagement.QueryManagementOrchestration.ExecuteQuery.Post
            /// </summary>
            #endregion

            ExecuteQueryInput executeQueryInput = IKEADEEActionUtilities.GetInputItem<ExecuteQueryInput>(Input, "ExecuteQueryInput");

            // Check if the query being executed is the one for the Manage Consumable Feeds Wizard
            bool isQueryResource =
                       executeQueryInput != null
                    && executeQueryInput.QueryObject != null
                    && executeQueryInput.QueryObject.EntityTypeName != null
                    && executeQueryInput.QueryObject.EntityTypeName.CompareStrings("Resource");

            if (isQueryResource)
            {
                IQuery query = executeQueryInput.QueryObject.Query;

                IEntityFilter entityFilter = query?.Entities?.FirstOrDefault(filter => filter.EntityType == "Resource");

                IField fabLiveAttribute = entityFilter?.Fields?.FirstOrDefault(field => field.Name == IKEAConstants.CustomFabLiveMainStateModel);

                return fabLiveAttribute != null;
                // MainStateModelStateId
            }

            return false;
            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---

            //System
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System");
            UseReference("", "System.Data");

            //Foundation
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.QueryManagement.InputObjects");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.QueryManagement.OutputObjects");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects.QueryObject");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();

            ExecuteQueryInput executeQueryInput = IKEADEEActionUtilities.GetInputItem<ExecuteQueryInput>(Input, "ExecuteQueryInput");

            bool isQueryResource =
                       executeQueryInput != null
                    && executeQueryInput.QueryObject != null
                    && executeQueryInput.QueryObject.EntityTypeName != null
                    && executeQueryInput.QueryObject.EntityTypeName.CompareStrings("Resource");

            if (isQueryResource)
            {
                IQuery query = executeQueryInput.QueryObject.Query;

                IEntityFilter entityFilter = query?.Entities?.FirstOrDefault(filter => filter.EntityType == "Resource");

                IField fabLiveAttribute = entityFilter?.Fields?.FirstOrDefault(field => field.Name == IKEAConstants.CustomFabLiveMainStateModel);

                // If the attribute "FabLiveMainStateModel" is included in the fields, we need to make sure that:
                //   - Pre: The fields MainStateModelStateId and AutomationMode are included in the query as well (or include them now if they're not)
                //   - Post: We calculate and replace the value of the attribute during runtime, looking at the Automation Mode and Main State Model State Id
                if (fabLiveAttribute != null)
                {
                    DeeContext context = deeContextUtilities.SetCurrentServiceContext("CustomFabLiveOfflineResources");

                    if (context.TriggerPoint == DeeTriggerPoint.Pre)
                    {
                        #region Add Necessary Additional Fields before the Query executes

                        IField mainStateModelStateIdField = entityFilter.Fields.FirstOrDefault(field => field.Name == "MainStateModelStateId");

                        if (mainStateModelStateIdField == null)
                        {
                            entityFilter.Fields.Add(new Field
                            {
                                IsUserAttribute = false,
                                Name = "MainStateModelStateId",
                                Alias = "MainStateModelStateId",
                                Position = 0,
                                Sort = 0,
                            });
                        }

                        IField automationModeField = entityFilter.Fields.FirstOrDefault(field => field.Name == "AutomationMode");

                        if (automationModeField == null)
                        {
                            entityFilter.Fields.Add(new Field
                            {
                                IsUserAttribute = false,
                                Name = "AutomationMode",
                                Alias = "AutomationMode",
                                Position = 0,
                                Sort = 0,
                            });
                        }

                        #endregion
                    }
                    else if (context.TriggerPoint == DeeTriggerPoint.Post)
                    {
                        #region Calculate Attribute Value for each Row after Query executes

                        ExecuteQueryOutput executeQueryOutput = IKEADEEActionUtilities.GetInputItem<ExecuteQueryOutput>(Input, "ExecuteQueryOutput");

                        DataSet ds = NgpDataSet.ToDataSet(executeQueryOutput.NgpDataSet);

                        if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
                        {
                            HashSet<long> stateModelStateIds = new HashSet<long>();

                            #region Collect all StateModel state's Ids

                            foreach (DataRow row in ds.Tables[0].Rows)
                            {
                                var automationMode = (ResourceAutomationMode)row.GetValue<int>("AutomationMode");

                                if (automationMode == ResourceAutomationMode.Online)
                                {
                                    var mainStateModelStateId = row.GetValue<long>("MainStateModelStateId");

                                    if (!stateModelStateIds.Contains(mainStateModelStateId))
                                    {
                                        stateModelStateIds.Add(mainStateModelStateId);
                                    }
                                }
                            }

                            #endregion

                            Dictionary<long, IStateModelState> statesById;
                            Dictionary<long, IStateModel> stateModelsById;

                            #region Get the StateModel state's Names from the database

                            IStateModelStateCollection statesCollection = new StateModelStateCollection();
                            statesCollection.LoadByIDs<IStateModelState, StateModelState>(stateModelStateIds.ToList());

                            statesById = statesCollection.ToDictionary(state => state.Id);

                            // Load the State Models that these states belong to
                            IStateModelCollection stateModelsCollection = new StateModelCollection();
                            stateModelsCollection.LoadByIDs<IStateModel, StateModel>(statesCollection.Select(state => state.StateModelId).Distinct().ToList());

                            stateModelsById = stateModelsCollection.ToDictionary(stateModel => stateModel.Id);

                            #endregion

                            #region Replace the DataSet in the output with the correct attribute values

                            foreach (DataRow row in ds.Tables[0].Rows)
                            {
                                var automationMode = (ResourceAutomationMode)row.GetValue<int>("AutomationMode");

                                if (automationMode == ResourceAutomationMode.Online)
                                {
                                    var mainStateModelStateId = row.GetValue<long>("MainStateModelStateId");

                                    IStateModelState state = null;
                                    IStateModel stateModel = null;

                                    if (statesById.TryGetValue(mainStateModelStateId, out state) && stateModelsById.TryGetValue(state.StateModelId, out stateModel))
                                    {
                                        row.SetField(IKEAConstants.CustomFabLiveMainStateModel, string.Format("{0} : {1}", stateModel.Name, state.Name));
                                    }
                                }
                                else
                                {
                                    row.SetField(IKEAConstants.CustomFabLiveMainStateModel, string.Format("Automation Mode : {0}", automationMode.ToString()));
                                }
                            }

                            #endregion

                            executeQueryOutput.NgpDataSet = NgpDataSet.FromDataSet(ds);
                        }

                        #endregion
                    }
                }
            }

            //---End DEE Code---

            return Input;
        }
    }
}
