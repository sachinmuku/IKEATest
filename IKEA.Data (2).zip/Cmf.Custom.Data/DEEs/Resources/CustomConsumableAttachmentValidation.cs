﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;


using Cmf.Custom.IKEA.BusinessObjects;
using Cmf.Custom.IKEA.BusinessObjects.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Extensions;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;

using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading;

namespace Cmf.Custom.IKEA.Actions.Resources
{
    public class CustomConsumableAttachmentValidation : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Validates if an attached consumable can be added to a consumable feed
            /// Action Groups:
            ///     BusinessObjects.Resource.AttachConsumables.Pre
            /// Is Dependency For:
            ///     CustomValidateMaterialAllocation
            /// </summary>
            #endregion


            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            bool attachmentValidationEnable = genericUtilities.GetConfigurationValueByPath<bool>(IKEAConstants.ConsumableAttachmentValidationEnable);
            bool validateAllowedMaterialTypes = genericUtilities.GetConfigurationValueByPath<bool>(IKEAConstants.ValidateAllowedMaterialTypesInMO);

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.Resource.AttachConsumables.Pre"
            };

            // Only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups) && (attachmentValidationEnable || validateAllowedMaterialTypes);

            if (executionVeridict
                && IKEADEEActionUtilities.GetInputItem<Dictionary<IMaterial, IAttachConsumableParameters>>(Input, "Materials") == null
                && IKEADEEActionUtilities.GetInputItem<IResource>(Input, "Resource") == null)
            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            //System
            UseReference("", "Cmf.Custom.IKEA.BusinessObjects.Abstractions");
            UseReference("", "System.Linq");
            UseReference("", "System.Text");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.IO");
            UseReference("", "System.Threading");
            UseReference("", "System");

            //Foundation
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");

            //Navigo
            UseReference("Cmf.Navigo.Common.dll", "Cmf.Navigo.Common");
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Extensions");
            UseReference("Cmf.Custom.IKEA.BusinessObjects.CustomResourceConsumptionProvider.dll", "Cmf.Custom.IKEA.BusinessObjects");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");


            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            ILocalizedMessage localizedMessage = serviceProvider.GetService<ILocalizedMessage>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();

            IResource consumableFeed = null;
            Dictionary<IMaterial, IAttachConsumableParameters> consumables = null;
            IMaterialCollection materials = entityFactory.CreateCollection<IMaterialCollection>();

            IBOMProductCollection validBomProducts = entityFactory.CreateCollection<IBOMProductCollection>();
            IMaterialCollection validMaterials = entityFactory.CreateCollection<IMaterialCollection>();

            bool attachmentValidationEnable = genericUtilities.GetConfigurationValueByPath<bool>(IKEAConstants.ConsumableAttachmentValidationEnable);
            bool validateAllowedMaterialTypes = genericUtilities.GetConfigurationValueByPath<bool>(IKEAConstants.ValidateAllowedMaterialTypesInMO);

            consumableFeed = IKEADEEActionUtilities.GetInputItem<IResource>(Input, "Resource");
            consumables = IKEADEEActionUtilities.GetInputItem<Dictionary<IMaterial, IAttachConsumableParameters>>(Input, "Materials");

            if (consumables != null)
            {
                materials.AddRange(consumables.Select(c => c.Key));
                materials.Load();

                // In parallel execution, multiple consumables with different products should be allowed
                IResource topMostResource = consumableFeed.GetTopMostResource();
                int materialsInProcessCount = topMostResource.GetAllMaterialsInProcess().Count;
                bool parallelExecutionActive = materialsInProcessCount > 1;

                // In the case of distributed consumption, validate if the materials being attached are of the same product than the already existing ones.
                if (!parallelExecutionActive && !ikeaUtilities.ValidateProductInDistributedFeedersOnAttach(consumableFeed, materials))
                {
                    throw new CmfBaseException(localizedMessage.LoadLocalizedMessage(Thread.CurrentThread.CurrentCulture.Name, IKEAConstants.CustomDistributedConsumptionIncompatibleProductLocalizedMessage).MessageText);
                }


                // Check if validation of allowed material types is enabled. (Only for Semi-Finished Goods and Finished Goods)
                if (validateAllowedMaterialTypes)
                {

                    // Collect all allowed product types:
                    Collection<string> allowedProductTypes = new Collection<string>
        {
            genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.CustomFinishGoodProductType),
            genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.CustomSemiFinishGoodProductType)
        };

                    // Load Products:
                    IProductCollection products = entityFactory.CreateCollection<IProductCollection>();
                    List<long> productIds = materials.Select(m => m.GetNativeValue<long>("Product")).Distinct().ToList();
                    products.LoadByIDs<IProduct, Product>(productIds);
                    Dictionary<long, string> productTypes = products.ToDictionary(p => p.DefinitionId, p => p.Type);

                    IMaterialCollection eligibleMaterials = entityFactory.CreateCollection<IMaterialCollection>();
                    eligibleMaterials.AddRange(materials.Where(mat => allowedProductTypes.Contains(productTypes[mat.GetNativeValue<long>("Product")])));

                    if (!eligibleMaterials.IsNullOrEmpty())
                    {
                        // Get all the materials in process in the consumable feed parents:
                        IMaterialCollection materialsInProcess = ikeaUtilities.GetMaterialsInProgresFromConsumableFeed(consumableFeed.Id, true);

                        // Throws error if validation fails:
                        ikeaUtilities.ValidateAllowedMaterialTypes(materialsInProcess, eligibleMaterials);
                    }
                }

                // Check if the validation of attachments is enabled
                if (attachmentValidationEnable)
                {
                    // Load Feeder attributes:
                    consumableFeed.LoadAttributes(new Collection<string>()
        {
            IKEAConstants.ProcessSegmentSequence,
            IKEAConstants.SubProcessSegmentName,
            IKEAConstants.CustomResourceAttributeFeederConsumptionMode
        });

                    CustomFeederConsumptionModeEnum feederConsumptionMode = consumableFeed.GetAttributeValueOrDefault<CustomFeederConsumptionModeEnum>(IKEAConstants.CustomResourceAttributeFeederConsumptionMode);
                    string feederProcessSegment = consumableFeed.GetAttributeValueOrDefault<string>(IKEAConstants.ProcessSegmentSequence);
                    string feederSubProcessSegment = consumableFeed.GetAttributeValueOrDefault<string>(IKEAConstants.SubProcessSegmentName);


                    // Check if this consumable feeder belongs to a distributed consumption group:                    
                    ICustomResourceConsumptionProviderCollection consumptionProviders = consumableFeed.GetRelationFromDistributedFeederTarget();
                    if (!consumptionProviders.IsNullOrEmpty())
                    {
                        IResource mainFeeder = consumptionProviders.FirstOrDefault().SourceEntity;

                        // Load the main feeder attributes:
                        mainFeeder.LoadAttributes(new Collection<string>()
            {
                IKEAConstants.ProcessSegmentSequence,
                IKEAConstants.SubProcessSegmentName,
                IKEAConstants.CustomResourceAttributeFeederConsumptionMode
            });

                        feederConsumptionMode = mainFeeder.GetAttributeValueOrDefault<CustomFeederConsumptionModeEnum>(IKEAConstants.CustomResourceAttributeFeederConsumptionMode);
                        feederProcessSegment = mainFeeder.GetAttributeValueOrDefault<string>(IKEAConstants.ProcessSegmentSequence);
                        feederSubProcessSegment = mainFeeder.GetAttributeValueOrDefault<string>(IKEAConstants.SubProcessSegmentName);
                    }

                    // Currently no difference between ProductSequenceBased and SequenceBased Feeders - Both validate Materials before attaching
                    // Load all material Products:
                    IProductCollection materialProducts = entityFactory.CreateCollection<IProductCollection>();
                    materialProducts.AddRange(materials.Select(m => m.Product));
                    materialProducts.Load();

                    // Load all BOMs:
                    IBOMCollection boms = ikeaUtilities.GetBOMOfMaterialsInProgressInResource(consumableFeed.Id);

                    // If BOMs are available:
                    if (!boms.IsNullOrEmpty())
                    {
                        boms.Load();
                        boms.LoadRelations(Navigo.Common.Constants.BOMProduct);

                        // Load all BOMProducts:
                        IBOMProductCollection bOMProducts = entityFactory.CreateCollection<IBOMProductCollection>();
                        bOMProducts.AddRange(boms.SelectMany(b => b.RelationCollection[Navigo.Common.Constants.BOMProduct]).Cast<IBOMProduct>());

                        // Load attributes fro Process segments:
                        bOMProducts.LoadAttributes(new Collection<string>()
                        {
                            IKEAConstants.BomProductProcessSegmentAttribute,
                            IKEAConstants.BomProductSubProcessSegmentAttribute
                        });

                        List<string> excludedMaterials = new List<string>();

                        // Check if the products being attached match with the BOM and Feeder:
                        foreach (IProduct product in materialProducts)
                        {
                            // Get the BOM Product that matches the feeder and product to attach:
                            var inFeederBOMProducts = bOMProducts.Where(BP => BP.TargetEntity.Name.CompareStrings(product.Name)
                                                                           && BP.GetAttributeValueOrDefault<string>(IKEAConstants.BomProductProcessSegmentAttribute).CompareStrings(feederProcessSegment)
                                                                           && BP.GetAttributeValueOrDefault<string>(IKEAConstants.BomProductSubProcessSegmentAttribute).CompareStrings(feederSubProcessSegment));

                            if (inFeederBOMProducts.IsNullOrEmpty())
                            {
                                excludedMaterials.AddRange(materials.Where(M => M.Product.Id == product.Id).Select(M => M.Name));
                            }
                            else
                            {
                                validBomProducts.AddRange(inFeederBOMProducts);
                                validMaterials.AddRange(materials.Where(M => M.Product.Id == product.Id));
                            }
                        }

                        if (validMaterials.IsNullOrEmpty())
                        {
                            throw new CmfBaseException(ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomConsumableAttachmentValidationsInvalidMaterialLocalizedMessage, string.Join(",", excludedMaterials)));
                        }
                    }
                    else
                    {
                        validMaterials.AddRange(materials);
                    }
                }
            }

            if (!validBomProducts.IsNullOrEmpty())
            {
                deeContextUtilities.SetContextParameter("AllocationsValidBOMProducts", validBomProducts);
            }

            if (!validMaterials.IsNullOrEmpty())
            {
                deeContextUtilities.SetContextParameter("AllocationsValidMaterials", validMaterials);
            }

            return Input;

            //---End DEE Code---
        }
    }
}
