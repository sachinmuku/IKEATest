﻿using Accord;
using Cmf.Common.CustomActionUtilities;

using Cmf.Custom.IKEA.Actions.Automation;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Extensions;
using Cmf.Custom.IKEA.Orchestration;
using Cmf.Custom.IKEA.Orchestration.InputObjects;
using Cmf.Custom.IKEA.Orchestration.OutputObjects;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessObjects.QueryObject;
using Cmf.Foundation.BusinessObjects.SmartTables;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Foundation.Common.Base;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.MaintenanceManagement.InputObjects;
using Microsoft.CodeAnalysis;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.Resources
{
    public class ResourceAutoStateChange : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     
            /// Action Groups:
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion

            return true;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            UseReference("", "System.Data");
            UseReference("%MicrosoftNetPath%\\System.Xml.dll", "System.Xml");
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.Common.dll", "Cmf.Navigo.Common");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("", "Cmf.Foundation.Common");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects.QueryObject");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Extensions");
            UseReference("", "Cmf.Foundation.BusinessObjects.SmartTables");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaintenanceManagement.InputObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.ResourceManagement");
            UseReference("Cmf.Custom.IKEA.Orchestration.dll", "Cmf.Custom.IKEA.Orchestration");
            UseReference("", "Cmf.Custom.IKEA.Orchestration.InputObjects");
            UseReference("", "Cmf.Custom.IKEA.Orchestration.OutputObjects");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            /**
             * Rule Description:
             * 
             * This rule was based on SEMI-10 State Model for Navigo MES Resources.
             * 
             * =======================================================================================================================
             * =                                                Input Parameters                                                     =
             * =======================================================================================================================
             * 
             * 1 - Resource (Resource): the resource where this rule is being evaluated;
             * 2 - CurrentContext (String): current call context (eg: BeginMao, TrackInMaterial, ...) 
             * 3 - DefaultTransition (StateModelTransition): the default transition to be given by this function;
             * 4 - Possible Transitions (StateModelTransitionCollection): all possible transitions to be returned by this function.
             * 5 - IsToLogEvent (Boolean): should the DEE rule log an event?
             * 6 - UserData (Dictionary<String, Object>): Context information (eg: Material being tracked-in, MAO requested, ...)
             * 
             * Notes:
             * Inside the Inputs dictionary, we can also specify:
             *  - PossibleTransitions (StateModelTransitionCollection): all possible transitions to be returned by this function;
             *  - DefaultTransition (StateModelTransition): the default transition to be given by this function;
             *  - ForceStateChange (Boolean): If true, indicates that a transition to the same state is not possible.
             *  - ReasonsToIgnore (Dictionary<StateModelTransition, List<String>>): List of Reasons (string) per Transition to remove from the available reasons.
             **/

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();

            const string attributeModelName = "SEMI-E10";
            const string attributeModelProduction = "Productive";
            const string attributeModelStandBy = "Standby";
            const string attributeModelEngineering = "Engineering";
            const string attributeModelScheduledDown = "Scheduled Down";
            const string attributeModelUnscheduledDown = "Unscheduled Down";
            const string attributeModelNonscheduled = "Nonscheduled";

            #region Validate Input Parameters

            if (!Input.ContainsKey("Resource"))
            {
                throw new ArgumentNullCmfException("Resource");
            }

            if (!Input.ContainsKey("CurrentContext"))
            {
                throw new ArgumentNullCmfException("CurrentContext");
            }

            if (!Input.ContainsKey("DefaultTransition"))
            {
                Input["DefaultTransition"] = null;
            }

            if (!Input.ContainsKey("PossibleTransitions"))
            {
                Input["PossibleTransitions"] = new StateModelTransitionCollection();
            }

            if (!Input.ContainsKey("IsToLogEvent"))
            {
                Input["IsToLogEvent"] = false;
            }

            if (!Input.ContainsKey("ReasonsToIgnore"))
            {
                Input["ReasonsToIgnore"] = new Dictionary<IStateModelTransition, List<string>>();
            }

            if (!Input.ContainsKey("ForceStateChange"))
            {
                Input["ForceStateChange"] = new bool();
            }

            #endregion

            #region Initialize Objects

            // get user data
            Dictionary<string, object> userData = null;
            if (Input.ContainsKey("UserData") && Input["UserData"] is Dictionary<string, object>)
            {
                userData = Input["UserData"] as Dictionary<string, object>;
            }
            if (userData == null) { userData = new Dictionary<string, object>(); }

            // current context
            String currentContext = (String)Input["CurrentContext"];

            // is log event
            Boolean isToLogEvent = (Boolean)Input["IsToLogEvent"];

            // default / possible transitions
            IStateModelTransitionCollection possibleTransitions = Input["PossibleTransitions"] as IStateModelTransitionCollection;
            IStateModelTransition defaultTransition = Input["DefaultTransition"] as IStateModelTransition;

            // target resource
            IResource resource = (IResource)Input["Resource"];
            resource.LoadMainState();

            // target materials
            IMaterialCollection materials = null;
            if (userData.ContainsKey("Materials") && userData["Materials"] is IMaterialCollection)
            {
                materials = (IMaterialCollection)userData["Materials"];
            }
            if (materials == null) { materials = entityFactory.CreateCollection<IMaterialCollection>(); }
            // else { materials.Load(); }

            #endregion

            if (resource.CurrentMainState != null)
            {
                // Get all available transitions
                IStateModelTransitionCollection availableTransitions = resource.CurrentMainState.StateModel.GetPossibleTransitionsForState(resource.CurrentMainState.CurrentState);

                #region Hold
                if (currentContext.Equals("Hold"))
                {
                    if (resource.CurrentMainState.StateModel.Name.CompareStrings(IKEAConstants.StateModelOEE))
                    {
                        // In the case of OEE if the current state is different than WAITING TIME or the current reason is different from 430-Quality Stops
                        // Then the suggested state is WAITING TIME with the reason 430-Quality Stops
                        if (!resource.CurrentMainState.CurrentState.Name.CompareStrings(IKEAConstants.StateModelStateWaitingTime)
                            || !resource.CurrentMainState.Reason.CompareStrings(IKEAConstants.StateModelStateWaitingTimeQualityStops))
                        {
                            IStateModelTransition smt = availableTransitions.FirstOrDefault(at => at.ToState.Name == IKEAConstants.StateModelStateWaitingTime);
                            smt.ReasonDefaultValue = IKEAConstants.StateModelStateWaitingTimeQualityStops;
                            possibleTransitions.Add(smt);
                        }
                    }
                    else
                    {
                        foreach (IStateModelState state in resource.CurrentMainState.StateModel.States)
                        {

                            if (state.Attributes.Count(a => a.Name.Equals("SEMI-E10", StringComparison.InvariantCultureIgnoreCase)
                                && a.Value.ToString().Equals("Scheduled Down", StringComparison.InvariantCultureIgnoreCase)) > 0
                                && resource.CurrentMainState.CurrentState.Name != state.Name)
                            {
                                IStateModelTransition smt = null;

                                //if in the available transitions a transition exists that has down state as a ToState, its a possible transition
                                if ((smt = availableTransitions.FirstOrDefault(at => at.ToState.Id == state.Id)) != null)
                                {
                                    if (availableTransitions == null)
                                    {
                                        availableTransitions = new StateModelTransitionCollection();
                                    }
                                    else
                                    {
                                        availableTransitions.Clear();
                                    }

                                    if (possibleTransitions == null)
                                    {
                                        possibleTransitions = new StateModelTransitionCollection();
                                    }

                                    possibleTransitions.Add(smt);
                                }
                                else
                                {
                                    possibleTransitions = null;
                                    if (Input.ContainsKey("DownState"))
                                    {
                                        Input["DownState"] = state;
                                    }
                                    else
                                    {
                                        Input.Add("DownState", state);
                                    }
                                }
                            }
                        }
                    }
                }
                #endregion

                #region Release
                else if (currentContext.Equals("Release"))
                {

                    /*
                     Se StateModel = OEE e Current state != WAITING TIME || current state == WAITING TIME e Current Reason != 400-Waiting time
                        então como possible transitions adicionamos StateModelTransition para WAITING TIME e setamos default reason = 400-Waiting time
                    */

                    if (resource.CurrentMainState.StateModel.Name.CompareStrings(IKEAConstants.StateModelOEE))
                    {
                        if (!resource.CurrentMainState.CurrentState.Name.CompareStrings(IKEAConstants.StateModelStateWaitingTime)
                            || !resource.CurrentMainState.Reason.CompareStrings(IKEAConstants.StateModelStateWaitingTimeWaitingTime))
                        {
                            IStateModelTransition smt = availableTransitions.FirstOrDefault(at => at.ToState.Name == IKEAConstants.StateModelStateWaitingTime);
                            smt.ReasonDefaultValue = IKEAConstants.StateModelStateWaitingTimeWaitingTime;
                            possibleTransitions.Add(smt);
                        }
                    }
                    else
                    {
                        foreach (IStateModelState state in resource.CurrentMainState.StateModel.States)
                        {
                            if (state.Attributes.Count(a => a.Name.Equals("SEMI-E10", StringComparison.InvariantCultureIgnoreCase)
                                && a.Value.ToString().Equals("Standby", StringComparison.InvariantCultureIgnoreCase)) > 0
                                && resource.CurrentMainState.CurrentState.Name != state.Name)
                            {
                                IStateModelTransition smt = null;

                                //if in the available transitions a transition exists that has down state as a ToState, its a possible transition
                                if ((smt = availableTransitions.FirstOrDefault(at => at.ToState.Id == state.Id)) != null)
                                {
                                    if (availableTransitions == null)
                                    {
                                        availableTransitions = new StateModelTransitionCollection();
                                    }
                                    else
                                    {
                                        availableTransitions.Clear();
                                    }

                                    if (possibleTransitions == null)
                                    {
                                        possibleTransitions = new StateModelTransitionCollection();
                                    }

                                    possibleTransitions.Add(smt);
                                }
                                else
                                {
                                    possibleTransitions = null;
                                    if (Input.ContainsKey("StandbyState"))
                                    {
                                        Input["StandbyState"] = state;
                                    }
                                    else
                                    {
                                        Input.Add("StandbyState", state);
                                    }
                                }
                            }
                        }
                    }
                }
                #endregion

                else if (resource.CurrentMainState.StateModel.Name.Equals(IKEAConstants.StateModelOEE))
                {
                    string sampleTesting = genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.MaterialTypeSampleTestingConfig);

                    #region Pre Conditions

                    #region OEE State Getters

                    IStateModelState stateWaitingTime = resource.CurrentMainState.StateModel.States.Single(state =>
                    {
                        IStateModelStateAttribute oeeAttribute = state.Attributes.FirstOrDefault(attr => attr.Name.Equals(attributeModelName));
                        IStateModelStateAttribute timeClassCodeAttribute = state.Attributes.FirstOrDefault(attr => attr.Name.Equals(IKEAConstants.StateModelStateTimeClassCode));
                        return oeeAttribute != null && timeClassCodeAttribute != null ? ((String)timeClassCodeAttribute.Value).CompareStrings(IKEAConstants.StateModelStateTimeClassCodeWaitingTime) : false;
                    });

                    IStateModelState stateRunningTimeNormal = resource.CurrentMainState.StateModel.States.Single(state =>
                    {
                        IStateModelStateAttribute oeeAttribute = state.Attributes.FirstOrDefault(attr => attr.Name.Equals(attributeModelName));
                        IStateModelStateAttribute timeClassCodeAttribute = state.Attributes.FirstOrDefault(attr => attr.Name.Equals(IKEAConstants.StateModelStateTimeClassCode));
                        return oeeAttribute != null && timeClassCodeAttribute != null ? ((String)timeClassCodeAttribute.Value).CompareStrings(IKEAConstants.StateModelStateTimeClassCodeRunningTimeNormal) : false;
                    });

                    IStateModelState stateRunningTimeReduced = resource.CurrentMainState.StateModel.States.Single(state =>
                    {
                        IStateModelStateAttribute oeeAttribute = state.Attributes.FirstOrDefault(attr => attr.Name.Equals(attributeModelName));
                        IStateModelStateAttribute timeClassCodeAttribute = state.Attributes.FirstOrDefault(attr => attr.Name.Equals(IKEAConstants.StateModelStateTimeClassCode));
                        return oeeAttribute != null && timeClassCodeAttribute != null ? ((String)timeClassCodeAttribute.Value).CompareStrings(IKEAConstants.StateModelStateTimeClassCodeRunningTimeReduced) : false;
                    });

                    IStateModelState stateUnplanned = resource.CurrentMainState.StateModel.States.Single(state =>
                    {
                        IStateModelStateAttribute oeeAttribute = state.Attributes.FirstOrDefault(attr => attr.Name.Equals(attributeModelName));
                        IStateModelStateAttribute timeClassCodeAttribute = state.Attributes.FirstOrDefault(attr => attr.Name.Equals(IKEAConstants.StateModelStateTimeClassCode));
                        return oeeAttribute != null && timeClassCodeAttribute != null ? ((String)timeClassCodeAttribute.Value).CompareStrings(IKEAConstants.StateModelStateTimeClassCodeUnplanned) : false;
                    });

                    #endregion

                    #region Maintenance Activity Order Scheduling 

                    // if IgnoreInSheduling is true, dont recomend any new state
                    bool ignoreInScheduling = false;
                    try
                    {
                        if (userData.ContainsKey("MaintenanceActivityOrderCollection"))
                        {
                            Cmf.Navigo.BusinessObjects.Abstractions.IMaintenanceActivityOrderCollection maintenanceActivityOrderCollection =
                                userData["MaintenanceActivityOrderCollection"] as Cmf.Navigo.BusinessObjects.Abstractions.IMaintenanceActivityOrderCollection;
                            ignoreInScheduling = maintenanceActivityOrderCollection.ElementAt(0).IgnoreInScheduling;
                        }
                    }
                    catch (Exception)
                    {
                        // do nothing
                    }

                    #endregion

                    #region Resource Hierarchy 

                    //
                    IResourceHierarchy resourceHierarchy = resource.GetAscendentResources(1);
                    bool isTopMostResource = resourceHierarchy == null || (resourceHierarchy != null && resourceHierarchy.Count <= 0);

                    #endregion

                    #endregion

                    #region Execution

                    #region Maintenance Activity Order: Request

                    if (currentContext.StartsWith("RequestMai", StringComparison.InvariantCultureIgnoreCase))
                    {
                        resource.LoadAttribute(IKEAConstants.CustomMAORequired);

                        #region Resource with MAORequired
                        if (resource != null && isTopMostResource && resource.AutomationMode == ResourceAutomationMode.Online)
                        {
                            Input["ForceStateChange"] = false;
                        }
                        #endregion
                        else
                        {
                            possibleTransitions.AddRange(availableTransitions);
                        }
                    }

                    #endregion

                    #region Maintenance Activity Order: Begin

                    else if (currentContext.StartsWith("BeginMao", StringComparison.InvariantCultureIgnoreCase))
                    {
                        // Get the first valid transaction to waiting time and then use the reason 450-Maintenance Stop
                        defaultTransition = availableTransitions.Single(q => q.FromState.Equals(resource.CurrentMainState.CurrentState)
                                                                                && q.ToState.Equals(stateWaitingTime));

                        defaultTransition.ReasonDefaultValue = IKEAConstants.StateModelStateWaitingTimeMaintenanceStop;

                        possibleTransitions.AddRange(availableTransitions);

                        #region Resource with MAORequired

                        if (resource != null && isTopMostResource && resource.AutomationMode == ResourceAutomationMode.Online && userData.ContainsKey("MaintenanceActivityOrderCollection"))
                        {
                            IMaintenanceActivityOrderCollection maintenanceActivityOrders = userData["MaintenanceActivityOrderCollection"] as MaintenanceActivityOrderCollection;
                            if (!maintenanceActivityOrders.IsNullOrEmpty())
                            {
                                maintenanceActivityOrders.Load();
                                foreach(IMaintenanceActivityOrder mao in maintenanceActivityOrders.Where(e => !e.Type.IsNullOrEmpty()))
                                {
                                    IMaintenanceActivityOrderCollection maoCollection = ikeaUtilities.GetOtherMAOsActiveForResource(mao, resource);
                                    List<(string, string)> tupleList = new List<(string, string)>();
                                    if (!maoCollection.IsNullOrEmpty())
                                    {
                                        maoCollection.Load();
                                        foreach(string type in maoCollection.Select(e => e.Type).Where(e => !e.IsNullOrEmpty()))
                                        {
                                            tupleList = ikeaUtilities.ResolveOEEStateAndReasonWhenMAORequired(resource, type);
                                            if (tupleList != null && !tupleList.FirstOrDefault().Item1.IsNullOrEmpty() && !tupleList.FirstOrDefault().Item2.IsNullOrEmpty())
                                            {
                                                break;
                                            }
                                        }
                                    }

                                    if (tupleList == null || tupleList.FirstOrDefault().Item1.IsNullOrEmpty() || tupleList.FirstOrDefault().Item2.IsNullOrEmpty())
                                    {
                                        tupleList = ikeaUtilities.ResolveOEEStateAndReasonWhenMAORequired(resource, mao.Type);
                                    }

                                    if (tupleList != null && !tupleList.FirstOrDefault().Item1.IsNullOrEmpty() && !tupleList.FirstOrDefault().Item2.IsNullOrEmpty())
                                    {
                                        List<string> reasonList = tupleList.Select(item => item.Item2).ToList();
                                        List<string> stateList = tupleList.Select(item => item.Item1).ToList();
                                        Collection<string> reasonCollection = new Collection<string>(reasonList);
                                        Collection<string> stateCollection = new Collection<string>(stateList);

                                        Collection<string> tupleListCollection = new Collection<string>(tupleList.Select(tl => tl.Item1).ToList());
                                        availableTransitions.Clear();

                                        Dictionary<IStateModelTransition, List<string>> reasonsToIgnore = new Dictionary<IStateModelTransition, List<string>>();

                                        foreach (IStateModelTransition transition in possibleTransitions.Where(pt => pt.ToState.Name.IsContained(tupleListCollection)))
                                        {
                                            // Consier only the selected subreasons
                                            reasonsToIgnore.Add(
                                                transition,
                                                ikeaUtilities.GetOEEModelStateReasonsFromTableName(transition.ReasonLookupTable)
                                                    .Where(reason => !reason.IsContained(reasonCollection)).ToList()
                                                );

                                            // Pre select reason, if there is only one to be selected
                                            IEnumerable<string> reasonsToAdd = ikeaUtilities.GetOEEModelStateReasonsFromTableName(transition.ReasonLookupTable)
                                                .Where(reason => reason.IsContained(reasonCollection)).ToList();

                                            if (reasonsToAdd.Count() == 1)
                                            {
                                                transition.ReasonDefaultValue = reasonsToAdd.FirstOrDefault();
                                            }
                                            else
                                            {
                                                transition.ReasonDefaultValue = null;
                                            }

                                            availableTransitions.Add(transition);
                                        }

                                        Input["ReasonsToIgnore"] = reasonsToIgnore;
                                        Input["ForceStateChange"] = true;

                                        possibleTransitions.Clear();
                                        possibleTransitions.AddRange(availableTransitions);

                                        // Set default transition, if only one exists
                                        if (availableTransitions.Count == 1)
                                        {
                                            defaultTransition = availableTransitions.FirstOrDefault();
                                        }
                                    }
                                }
                            }
                        }
                        #endregion
                    }

                    #endregion

                    #region Maintenance Activity Order: Complete

                    else if (currentContext.StartsWith("CompleteMao", StringComparison.InvariantCultureIgnoreCase))
                    {
                        #region Resource State(s): ScheduledDown or UnscheduledDown

                        IResource topmost = resource.GetTopMostResource();
                        topmost.Load();
                        topmost.LoadAttributes(new Collection<string>() { IKEAConstants.CustomMAORequired, IKEAConstants.CustomAlarmRequired });

                        // Check if the Current state is WAITING TIME and the reason is 450-Maintenance Stop
                        if ((resource.CurrentMainState.CurrentState.Equals(stateWaitingTime) && resource.CurrentMainState.Reason.CompareStrings(IKEAConstants.StateModelStateWaitingTimeMaintenanceStop) && !ignoreInScheduling))
                        {
                            IEnumerable<long> maintenanceActivityOrderIds = null;

                            //
                            try
                            {
                                if (userData.ContainsKey("MaintenanceActivityOrderCollection"))
                                {
                                    Cmf.Navigo.BusinessObjects.Abstractions.IMaintenanceActivityOrderCollection maintenanceActivityOrderCollection =
                                        userData["MaintenanceActivityOrderCollection"] as Cmf.Navigo.BusinessObjects.Abstractions.IMaintenanceActivityOrderCollection;
                                    maintenanceActivityOrderIds = maintenanceActivityOrderCollection != null ?
                                        maintenanceActivityOrderCollection.Select(q => q.Id) :
                                        null;
                                }

                            }
                            catch (Exception)
                            {
                                // do nothing
                            }

                            #region filter collection: maintenance activity order

                            IFilterCollection filterCollectionForMaintenanceActivityOrder = new FilterCollection();
                            filterCollectionForMaintenanceActivityOrder.Add(
                                new Cmf.Foundation.BusinessObjects.QueryObject.Filter()
                                {
                                    Name = "ExecutionState",
                                    Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                                    Value = (Int32)MaintenanceExecutionStates.InProgress,
                                    LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND
                                });
                            filterCollectionForMaintenanceActivityOrder.Add(
                                new Cmf.Foundation.BusinessObjects.QueryObject.Filter()
                                {
                                    Name = "Id",
                                    Operator = maintenanceActivityOrderIds != null ?
                                        Cmf.Foundation.Common.FieldOperator.NotIn :
                                        Cmf.Foundation.Common.FieldOperator.In,
                                    Value = maintenanceActivityOrderIds != null ?
                                        maintenanceActivityOrderIds.ToList() :
                                        new List<long>() { -1 }, // no results
                                    LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND
                                });

                            #endregion

                            #region filter collection: maintenance plan instance

                            IFilterCollection filterCollectionForMaintenancePlanInstance = new FilterCollection();
                            filterCollectionForMaintenancePlanInstance.Add(
                                new Cmf.Foundation.BusinessObjects.QueryObject.Filter()
                                {
                                    Name = "ResourceId",
                                    Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                                    Value = resource.Id,
                                    LogicalOperator = Cmf.Foundation.Common.LogicalOperator.Nothing
                                });

                            #endregion

                            // build query
                            IQueryObject outputQuery = new QueryObject();
                            outputQuery.Description = "";
                            outputQuery.EntityTypeName = "MaintenanceActivityOrder";
                            outputQuery.Name = "MaintenanceActivityOrderQuery";
                            outputQuery.Query = new Query();
                            outputQuery.Query.Distinct = false;
                            outputQuery.Query.Entities = new EntityFilterCollection(){
                    new EntityFilter()
                    {
                        Alias = "MaintenanceActivityOrder_1",
                        EntityType = "MaintenanceActivityOrder",
                        Filter = filterCollectionForMaintenanceActivityOrder,
                        Fields = new FieldCollection()
                        {
                            new Field()
                            {
                                Alias = "Id",
                                IsUserAttribute = false,
                                Name = "Id",
                                Position = 0,
                                Sort = Cmf.Foundation.Common.FieldSort.NoSort
                            },
                            new Field()
                            {
                                Alias = "Name",
                                IsUserAttribute = false,
                                Name = "Name",
                                Position = 1,
                                Sort = Cmf.Foundation.Common.FieldSort.NoSort
                            }
                        }
                    },
                    new EntityFilter()
                    {
                        Alias = "MaintenanceActivityOrder_MaintenancePlanInstance_2",
                        EntityType = "MaintenancePlanInstance",
                        Filter = filterCollectionForMaintenancePlanInstance,
                        Fields = new FieldCollection()
                    }
                };
                            outputQuery.Query.Relations = new RelationCollection() {
                    new Relation()
                    {
                        Alias = "MaintenanceActivityOrderToMaintenancePlanInstance",
                        Filter = new FilterCollection(),
                        Fields = new FieldCollection(),
                        IsRelation = false,
                        Name = "",
                        SourceEntity = "MaintenanceActivityOrder",
                        SourceEntityAlias = "MaintenanceActivityOrder_1",
                        SourceJoinType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.JoinType.InnerJoin,
                        SourceProperty = "MaintenancePlanInstanceId",
                        TargetEntity = "MaintenancePlanInstance",
                        TargetEntityAlias = "MaintenanceActivityOrder_MaintenancePlanInstance_2",
                        TargetJoinType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.JoinType.InnerJoin,
                        TargetProperty = "Id"
                    }
                };

                            DataSet queryResults = outputQuery.Execute(false, null);

                            if (queryResults.Tables.Count <= 0 || queryResults.Tables[0].Rows.Count <= 0)
                            {
                                defaultTransition = availableTransitions.Single(q =>
                                q.FromState.Equals(resource.CurrentMainState.CurrentState) &&
                                q.ToState.Equals(stateWaitingTime));

                                defaultTransition.ReasonDefaultValue = IKEAConstants.StateModelStateWaitingTimeWaitingTime;
                            }

                            possibleTransitions.AddRange(availableTransitions);
                        }

                        #endregion

                        #region Resource with MAORequired

                        else if (resource != null && isTopMostResource && resource.AutomationMode == ResourceAutomationMode.Online
                            && topmost.Attributes.ContainsKey(IKEAConstants.CustomMAORequired) && topmost.Attributes[IKEAConstants.CustomMAORequired] != null
                            && Convert.ToBoolean(topmost.Attributes[IKEAConstants.CustomMAORequired]))
                        {
                            bool isToCallIoT = true;
                            bool isToBlockOEE = true;
                            if (userData.ContainsKey("MaintenanceActivityOrderCollection"))
                            {
                                IMaintenanceActivityOrderCollection maintenanceActivityOrders = userData["MaintenanceActivityOrderCollection"] as MaintenanceActivityOrderCollection;
                                if (!maintenanceActivityOrders.IsNullOrEmpty())
                                {
                                    maintenanceActivityOrders.Load();
                                    foreach (IMaintenanceActivityOrder order in maintenanceActivityOrders.Where(e => !e.Type.IsNullOrEmpty()))
                                    {
                                        IMaintenanceActivityOrderCollection maoCollection = ikeaUtilities.GetOtherMAOsActiveForResource(order, resource);
                                        if (!maoCollection.IsNullOrEmpty())
                                        {
                                            foreach (string type in maoCollection.Select(e => e.Type).Where(e => !e.IsNullOrEmpty()))
                                            {
                                                List<(string,string)> tupleList = ikeaUtilities.ResolveOEEStateAndReasonWhenMAORequired(resource, type);
                                                if (tupleList != null && !tupleList.FirstOrDefault().Item1.IsNullOrEmpty() && !tupleList.FirstOrDefault().Item2.IsNullOrEmpty())
                                                {
                                                    string reason = tupleList.FirstOrDefault().Item2;
                                                    string state = tupleList.FirstOrDefault().Item1;
                                                    defaultTransition = availableTransitions.Single(q => q.FromState.Equals(resource.CurrentMainState.CurrentState)
                                                                                                && q.ToState.Equals(resource.CurrentMainState.StateModel.States.First(p => p.Name.Equals(state))));

                                                    defaultTransition.ReasonDefaultValue = reason;
                                                    availableTransitions = new StateModelTransitionCollection() { defaultTransition };
                                                    Input["ReasonsToIgnore"] = new Dictionary<IStateModelTransition, List<string>>()
                                        {
                                            {
                                                defaultTransition,
                                                ikeaUtilities.GetOEEModelStateReasonsFromTableName(defaultTransition.ReasonLookupTable)
                                                                .Where(E => !string.IsNullOrEmpty(E) && !E.Equals(reason, StringComparison.InvariantCultureIgnoreCase)).ToList()
                                            }
                                        };
                                                    Input["ForceStateChange"] = true;
                                                    possibleTransitions.Clear();
                                                    possibleTransitions.AddRange(availableTransitions);

                                                    isToCallIoT = false;
                                                    break;
                                                }
                                            }
                                        }

                                        // If mao is completed by operator, BUT started by ERP, is not to block OEE
                                        if (isToCallIoT)
                                        {
                                            // Obtain StartedByOperator MAO's attribute
                                            order.LoadAttribute(IKEAConstants.CustomMaoStartedByOperatorAttribute);
                                            if (order.Attributes.TryGetValue(IKEAConstants.CustomMaoStartedByOperatorAttribute, out object isStartedByOperator))
                                            {
                                                isToBlockOEE = (bool)isStartedByOperator;
                                            }
                                            else
                                            {
                                                isToBlockOEE = false;
                                            }
                                        }
                                    }
                                }
                            }

                            if (isToCallIoT && isToBlockOEE)
                            {
                                IAutomationControllerInstance controllerInstance = resource.GetAutomationControllerInstance();
                                Dictionary<string, object> resourceDetails = new Dictionary<string, object>
                    {
                        { IKEAConstants.AutomationRequestBlockOEEStateField, false }
                    };

                                try
                                {
                                    _ = genericUtilities.RequestFromIoT<Dictionary<string, string>>(controllerInstance, IKEAConstants.AutomationRequestTypeBlockOEEStateCalculation, resourceDetails.ToJsonString());
                                }
                                catch (Exception)
                                {
                                    throw;
                                }
                                resourceDetails = new Dictionary<string, object>
                    {
                        { IKEAConstants.AutomationRequestResourceName, resource.Name }
                    };
                                Dictionary<string, string> outputIoT = new Dictionary<string, string>();

                                try
                                {
                                    outputIoT = genericUtilities.RequestFromIoT<Dictionary<string, string>>(controllerInstance, IKEAConstants.AutomationRequestTypeCalculateOEEStateAndReason, resourceDetails.ToJsonString());
                                }
                                catch (Exception)
                                {
                                    throw;
                                }

                                if (!outputIoT.IsNullOrEmpty())
                                {
                                    defaultTransition = availableTransitions.Single(q => q.FromState.Equals(resource.CurrentMainState.CurrentState)
                                        && q.ToState.Equals(resource.CurrentMainState.StateModel.States.First(p => p.Name.Equals(outputIoT["State"]))));

                                    defaultTransition.ReasonDefaultValue = outputIoT["Reason"];
                                    Input["ReasonsToIgnore"] = new Dictionary<IStateModelTransition, List<string>>()
                        {
                            {
                                defaultTransition,
                                ikeaUtilities.GetOEEModelStateReasonsFromTableName(defaultTransition.ReasonLookupTable)
                                    .Where(E => !string.IsNullOrEmpty(E) && !E.Equals(outputIoT["Reason"], StringComparison.InvariantCultureIgnoreCase)).ToList()
                            }
                        };
                                    Input["ForceStateChange"] = true;
                                    availableTransitions = new StateModelTransitionCollection() { defaultTransition };
                                    possibleTransitions.Clear();
                                    possibleTransitions.AddRange(availableTransitions);
                                    resourceDetails = new Dictionary<string, object>
                        {
                            { IKEAConstants.AutomationRequestBlockOEEStateField, isToBlockOEE }
                        };
                                    defaultTransition.ReasonDefaultValue = outputIoT["Reason"];
                                    try
                                    {
                                        _ = genericUtilities.RequestFromIoT<Dictionary<string, string>>(controllerInstance, IKEAConstants.AutomationRequestTypeBlockOEEStateCalculation, resourceDetails.ToJsonString());
                                    }
                                    catch (Exception)
                                    {
                                        throw;
                                    }
                                }
                                else
                                {
                                    defaultTransition = availableTransitions.Single(q => q.FromState.Equals(resource.CurrentMainState.CurrentState)
                                        && q.ToState.Equals(resource.CurrentMainState.StateModel.States.First(p => p.Equals(stateWaitingTime))));
                                    possibleTransitions.AddRange(availableTransitions);
                                }
                            }
                        }
                        #endregion

                        #region Resource State(s): {all other}

                        else
                        {
                            possibleTransitions.AddRange(availableTransitions);
                        }

                        #endregion
                    }
                    #endregion

                    #region  Material Action: Track In Material

                    else if (currentContext.StartsWith("TrackInMaterial", StringComparison.InvariantCultureIgnoreCase)
                            && currentContext.EndsWith("Post", StringComparison.InvariantCultureIgnoreCase))
                    {
                        // if resource is on WaitingTime
                        if (!resource.CurrentMainState.CurrentState.Equals(stateRunningTimeNormal)
                            && !resource.CurrentMainState.CurrentState.Equals(stateRunningTimeReduced))
                        {
                            IStateModelTransition possibleTransition = null;
                            string reason;

                            // The validation will be done on the Post of the Track in so it will be at least one material
                            if (resource.MaterialsInProcessCount == 1)
                            {
                                // Check if any of the materials are sample testing
                                if (materials.Any(m => m.Type.CompareStrings(sampleTesting)))
                                {
                                    // Set the reason to 220-R&D
                                    reason = IKEAConstants.StateModelStateUnplannedRD;

                                    possibleTransition = availableTransitions.FirstOrDefault(x => x.FromState.Equals(resource.CurrentMainState.CurrentState)
                                                                                                    && x.ToState.Equals(stateUnplanned));
                                }
                                else
                                {
                                    // Set the reason to 410-Setup
                                    reason = IKEAConstants.StateModelStateWaitingTimeSetup;

                                    possibleTransition = availableTransitions.FirstOrDefault(x => x.FromState.Equals(resource.CurrentMainState.CurrentState)
                                                                                                    && x.ToState.Equals(stateWaitingTime));
                                }

                                if (possibleTransition != null)
                                {
                                    defaultTransition = possibleTransition;
                                    defaultTransition.ReasonDefaultValue = reason;
                                    possibleTransitions.Add(possibleTransition);
                                }
                            }
                        }
                        else
                        {
                            possibleTransitions.AddRange(availableTransitions);
                        }
                    }

                    #endregion

                    #region Material Action: Track Out Material, Abort Material and Terminate Material

                    else if (currentContext.StartsWith("TrackOutMaterial", StringComparison.InvariantCultureIgnoreCase)
                                || currentContext.StartsWith("AbortMaterial", StringComparison.InvariantCultureIgnoreCase)
                                || currentContext.StartsWith("TerminateMaterial", StringComparison.InvariantCultureIgnoreCase))
                    {
                        IStateModelTransition possibleTransition = null;
                        string reason = string.Empty;

                        // Only execute the validation on Post
                        if (currentContext.EndsWith("Post", StringComparison.InvariantCultureIgnoreCase))
                        {
                            // Check if there aren't materials in process
                            if (resource.MaterialsInProcessCount == 0)
                            {
                                // Set the reason to 400-WaitingTime
                                reason = reason = IKEAConstants.StateModelStateWaitingTimeWaitingTime;

                                possibleTransition = availableTransitions.FirstOrDefault(x => x.FromState.Equals(resource.CurrentMainState.CurrentState)
                                                                                                && x.ToState.Equals(stateWaitingTime));


                            }
                            else
                            {
                                // Get all material tracked-in in the resource
                                Dictionary<IMaterial, decimal> trackedInMaterials = ikeaUtilities.GetMaterialsFromResourceByState(resource.Id, true, MaterialSystemState.InProcess);

                                // Get the Oldest material going to the first in the list
                                IMaterial oldestMaterialTrackedIn = trackedInMaterials.First().Key;

                                // Check if the oldest material is Sample Testing
                                if (oldestMaterialTrackedIn.Type.CompareStrings(sampleTesting))
                                {
                                    // Set the reason to 220-R&D
                                    reason = IKEAConstants.StateModelStateUnplannedRD;

                                    possibleTransition = availableTransitions.FirstOrDefault(x => x.FromState.Equals(resource.CurrentMainState.CurrentState)
                                                                                                    && x.ToState.Equals(stateUnplanned));
                                }
                                else
                                {
                                    // Check if the Material is the state MSM -> SETUP
                                    if (oldestMaterialTrackedIn.CurrentMainState.StateModel.Name.CompareStrings(IKEAConstants.MaterialStateModel)
                                        && oldestMaterialTrackedIn.CurrentMainState.CurrentState.Name.CompareStrings(IKEAConstants.MaterialStateModelSetup))
                                    {
                                        // Set the reason to 410-Setup
                                        reason = IKEAConstants.StateModelStateWaitingTimeSetup;

                                        possibleTransition = availableTransitions.FirstOrDefault(x => x.FromState.Equals(resource.CurrentMainState.CurrentState)
                                                                                                        && x.ToState.Equals(stateWaitingTime));
                                    }
                                    else
                                    {
                                        if (resource.AutomationMode != ResourceAutomationMode.Online)
                                        {
                                            // Set the reason to 300-Normal speed
                                            reason = IKEAConstants.StateModelStateRunningTimeNormalSpeed;

                                            possibleTransition = availableTransitions.FirstOrDefault(x => x.FromState.Equals(resource.CurrentMainState.CurrentState)
                                                                                                        && x.ToState.Equals(stateRunningTimeNormal));
                                        }
                                    }
                                }
                            }
                        }

                        if (possibleTransition != null)
                        {
                            defaultTransition = possibleTransition;
                            defaultTransition.ReasonDefaultValue = reason;
                            possibleTransitions.Add(possibleTransition);
                        }

                    }

                    #endregion

                    #region Material Action: Dispatch, undispatch

                    else if (currentContext.StartsWith("Dispatch", StringComparison.InvariantCultureIgnoreCase)
                        || currentContext.StartsWith("Undispatch", StringComparison.InvariantCultureIgnoreCase))
                    {
                        IStateModelTransition possibleTransition = null;
                        string reason = string.Empty;

                        // Only execute the validation on Post
                        if (currentContext.EndsWith("Post", StringComparison.InvariantCultureIgnoreCase))
                        {
                            // Check if there aren't materials in process
                            if (resource.MaterialsInProcessCount == 0)
                            {

                                // Set the reason to 400-WaitingTime
                                reason = IKEAConstants.StateModelStateWaitingTimeWaitingTime;

                                possibleTransition = availableTransitions.FirstOrDefault(x => x.FromState.Equals(resource.CurrentMainState.CurrentState)
                                                                                                && x.ToState.Equals(stateWaitingTime));

                            }

                            if (possibleTransition != null)
                            {
                                defaultTransition = possibleTransition;
                                defaultTransition.ReasonDefaultValue = reason;
                                possibleTransitions.Add(possibleTransition);
                            }

                        }
                    }
                    #endregion

                    #region Service CustomStartMaterial

                    else if (currentContext.StartsWith("CustomStartMaterial", StringComparison.InvariantCultureIgnoreCase))
                    {
                        if (resource.AutomationMode != ResourceAutomationMode.Online)
                        {
                            // Set the default transition to OEE Running Time Normal
                            defaultTransition = availableTransitions.FirstOrDefault(x => x.FromState.Equals(resource.CurrentMainState.CurrentState)
                                                                                    && x.ToState.Equals(stateRunningTimeNormal));
                            // Set the reason to 300-NormalSpeed
                            defaultTransition.ReasonDefaultValue = IKEAConstants.StateModelStateRunningTimeNormalSpeed;

                            possibleTransitions.AddRange(availableTransitions);
                        }
                    }

                    #endregion

                    else
                    {
                        possibleTransitions.AddRange(availableTransitions);
                    }

                    #endregion

                    #region Post Conditions

                    #endregion
                }
                else if (resource.CurrentMainState.StateModel.Name.Equals("SEMI E10"))
                {
                    #region Pre Conditions

                    #region SEMI - 10 State Getters

                    IStateModelState stateProductive = resource.CurrentMainState.StateModel.States.Single(state =>
                    {
                        IStateModelStateAttribute semiE10Attribute = state.Attributes.FirstOrDefault(attr => attr.Name.Equals(attributeModelName));
                        return semiE10Attribute != null ? ((String)semiE10Attribute.Value).Equals(attributeModelProduction, StringComparison.InvariantCultureIgnoreCase) : false;
                    });

                    IStateModelState stateStandby = resource.CurrentMainState.StateModel.States.Single(state =>
                    {
                        IStateModelStateAttribute semiE10Attribute = state.Attributes.FirstOrDefault(attr => attr.Name.Equals(attributeModelName));
                        return semiE10Attribute != null ? ((String)semiE10Attribute.Value).Equals(attributeModelStandBy, StringComparison.InvariantCultureIgnoreCase) : false;
                    });

                    IStateModelState stateEngineering = resource.CurrentMainState.StateModel.States.Single(state =>
                    {
                        IStateModelStateAttribute semiE10Attribute = state.Attributes.FirstOrDefault(attr => attr.Name.Equals(attributeModelName));
                        return semiE10Attribute != null ? ((String)semiE10Attribute.Value).Equals(attributeModelEngineering, StringComparison.InvariantCultureIgnoreCase) : false;
                    });

                    IStateModelState stateScheduledDown = resource.CurrentMainState.StateModel.States.Single(state =>
                    {
                        IStateModelStateAttribute semiE10Attribute = state.Attributes.FirstOrDefault(attr => attr.Name.Equals(attributeModelName));
                        return semiE10Attribute != null ? ((String)semiE10Attribute.Value).Equals(attributeModelScheduledDown, StringComparison.InvariantCultureIgnoreCase) : false;
                    });

                    IStateModelState stateUnscheduledDown = resource.CurrentMainState.StateModel.States.Single(state =>
                    {
                        IStateModelStateAttribute semiE10Attribute = state.Attributes.FirstOrDefault(attr => attr.Name.Equals(attributeModelName));
                        return semiE10Attribute != null ? ((String)semiE10Attribute.Value).Equals(attributeModelUnscheduledDown, StringComparison.InvariantCultureIgnoreCase) : false;
                    });

                    IStateModelState stateNonscheduled = resource.CurrentMainState.StateModel.States.Single(state =>
                    {
                        IStateModelStateAttribute semiE10Attribute = state.Attributes.FirstOrDefault(attr => attr.Name.Equals(attributeModelName));
                        return semiE10Attribute != null ? ((String)semiE10Attribute.Value).Equals(attributeModelNonscheduled, StringComparison.InvariantCultureIgnoreCase) : false;
                    });

                    #endregion

                    #region Maintenance Activity Order Scheduling 

                    // if IgnoreInSheduling is true, dont recomend any new state
                    bool ignoreInScheduling = false;
                    try
                    {
                        if (userData.ContainsKey("MaintenanceActivityOrderCollection"))
                        {
                            Cmf.Navigo.BusinessObjects.Abstractions.IMaintenanceActivityOrderCollection maintenanceActivityOrderCollection =
                                userData["MaintenanceActivityOrderCollection"] as Cmf.Navigo.BusinessObjects.Abstractions.IMaintenanceActivityOrderCollection;
                            ignoreInScheduling = maintenanceActivityOrderCollection.ElementAt(0).IgnoreInScheduling;
                        }
                    }
                    catch (Exception)
                    {
                        // do nothing
                    }

                    #endregion

                    #region Resource Hierarchy 

                    //
                    IResourceHierarchy resourceHierarchy = resource.GetAscendentResources(1);
                    bool isTopMostResource = resourceHierarchy == null || (resourceHierarchy != null && resourceHierarchy.Count <= 0);

                    #endregion

                    #endregion

                    #region Execution

                    #region Maintenance Activity Order: Begin

                    if (currentContext.StartsWith("BeginMao", StringComparison.InvariantCultureIgnoreCase))
                    {
                        #region Resource State(s): StandBy

                        // StandBy > Scheduled Down
                        if (resource.CurrentMainState.CurrentState.Equals(stateStandby) && !ignoreInScheduling)
                        {
                            //
                            defaultTransition = availableTransitions.Single(q =>
                            q.FromState.Equals(stateStandby) &&
                            q.ToState.Equals(stateScheduledDown));
                            //
                            possibleTransitions.AddRange(availableTransitions);
                        }

                        #endregion

                        #region Resource State(s): Engineering

                        // Engineering > Unscheduled Down
                        else if (resource.CurrentMainState.CurrentState.Equals(stateEngineering) && !ignoreInScheduling)
                        {
                            defaultTransition = availableTransitions.Single(q =>
                            q.FromState.Equals(stateEngineering) &&
                            q.ToState.Equals(stateUnscheduledDown));
                            //
                            possibleTransitions.AddRange(availableTransitions);
                        }

                        #endregion

                        #region Resource State(s): Productive

                        // Productive > Unscheduled Down
                        else if (resource.CurrentMainState.CurrentState.Equals(stateProductive) && !ignoreInScheduling)
                        {
                            //
                            defaultTransition = availableTransitions.Single(q =>
                            q.FromState.Equals(stateProductive) &&
                            q.ToState.Equals(stateUnscheduledDown));
                            //
                            possibleTransitions.AddRange(availableTransitions);
                        }

                        #endregion

                        #region Resource State(s): {all other}

                        else
                        {
                            possibleTransitions.AddRange(availableTransitions);
                        }

                        #endregion
                    }

                    #endregion

                    #region Maintenance Activity Order: Complete

                    else if (currentContext.StartsWith("CompleteMao", StringComparison.InvariantCultureIgnoreCase))
                    {
                        #region Resource State(s): ScheduledDown or UnscheduledDown

                        if ((resource.CurrentMainState.CurrentState.Equals(stateScheduledDown) && !ignoreInScheduling) || (resource.CurrentMainState.CurrentState.Equals(stateUnscheduledDown) && !ignoreInScheduling))
                        {
                            //  - If no other MAOs InProgress exist for Resource:
                            //      1) Default: Scheduled Down to Stand By
                            //      2) Possible: All transitions from current state PLUS None
                            //  - Else
                            //      1) Default: None
                            //      1) Possible: All transitions from current state PLUS None

                            //  - try to obtain enclosed maintenance activity order instance ids 
                            //  - not likely to be more than one maintenance activity order however, take that possibility into account
                            //  - in the future, try to collect the following information earlier
                            //                   
                            IEnumerable<long> maintenanceActivityOrderIds = null;

                            //
                            try
                            {
                                if (userData.ContainsKey("MaintenanceActivityOrderCollection"))
                                {
                                    Cmf.Navigo.BusinessObjects.Abstractions.IMaintenanceActivityOrderCollection maintenanceActivityOrderCollection =
                                        userData["MaintenanceActivityOrderCollection"] as Cmf.Navigo.BusinessObjects.Abstractions.IMaintenanceActivityOrderCollection;
                                    maintenanceActivityOrderIds = maintenanceActivityOrderCollection != null ?
                                        maintenanceActivityOrderCollection.Select(q => q.Id) :
                                        null;
                                }

                            }
                            catch (Exception)
                            {
                                // do nothing
                            }

                            #region filter collection: maintenance activity order

                            IFilterCollection filterCollectionForMaintenanceActivityOrder = new FilterCollection();
                            filterCollectionForMaintenanceActivityOrder.Add(
                                new Cmf.Foundation.BusinessObjects.QueryObject.Filter()
                                {
                                    Name = "ExecutionState",
                                    Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                                    Value = (Int32)MaintenanceExecutionStates.InProgress,
                                    LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND
                                });
                            filterCollectionForMaintenanceActivityOrder.Add(
                                new Cmf.Foundation.BusinessObjects.QueryObject.Filter()
                                {
                                    Name = "Id",
                                    Operator = maintenanceActivityOrderIds != null ?
                                        Cmf.Foundation.Common.FieldOperator.NotIn :
                                        Cmf.Foundation.Common.FieldOperator.In,
                                    Value = maintenanceActivityOrderIds != null ?
                                        maintenanceActivityOrderIds.ToList() :
                                        new List<long>() { -1 }, // no results
                                    LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND
                                });

                            #endregion

                            #region filter collection: maintenance plan instance

                            IFilterCollection filterCollectionForMaintenancePlanInstance = new FilterCollection();
                            filterCollectionForMaintenancePlanInstance.Add(
                                new Cmf.Foundation.BusinessObjects.QueryObject.Filter()
                                {
                                    Name = "ResourceId",
                                    Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                                    Value = resource.Id,
                                    LogicalOperator = Cmf.Foundation.Common.LogicalOperator.Nothing
                                });

                            #endregion

                            // build query
                            IQueryObject outputQuery = new QueryObject();
                            outputQuery.Description = "";
                            outputQuery.EntityTypeName = "MaintenanceActivityOrder";
                            outputQuery.Name = "MaintenanceActivityOrderQuery";
                            outputQuery.Query = new Query();
                            outputQuery.Query.Distinct = false;
                            outputQuery.Query.Entities = new EntityFilterCollection(){
                new EntityFilter()
                {
                    Alias = "MaintenanceActivityOrder_1",
                    EntityType = "MaintenanceActivityOrder",
                    Filter = filterCollectionForMaintenanceActivityOrder,
                    Fields = new FieldCollection()
                    {
                        new Field()
                        {
                            Alias = "Id",
                            IsUserAttribute = false,
                            Name = "Id",
                            Position = 0,
                            Sort = Cmf.Foundation.Common.FieldSort.NoSort
                        },
                        new Field()
                        {
                            Alias = "Name",
                            IsUserAttribute = false,
                            Name = "Name",
                            Position = 1,
                            Sort = Cmf.Foundation.Common.FieldSort.NoSort
                        }
                    }
                },
                new EntityFilter()
                {
                    Alias = "MaintenanceActivityOrder_MaintenancePlanInstance_2",
                    EntityType = "MaintenancePlanInstance",
                    Filter = filterCollectionForMaintenancePlanInstance,
                    Fields = new FieldCollection()
                }
            };
                            outputQuery.Query.Relations = new RelationCollection() {
                new Relation()
                {
                    Alias = "MaintenanceActivityOrderToMaintenancePlanInstance",
                    Filter = new FilterCollection(),
                    Fields = new FieldCollection(),
                    IsRelation = false,
                    Name = "",
                    SourceEntity = "MaintenanceActivityOrder",
                    SourceEntityAlias = "MaintenanceActivityOrder_1",
                    SourceJoinType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.JoinType.InnerJoin,
                    SourceProperty = "MaintenancePlanInstanceId",
                    TargetEntity = "MaintenancePlanInstance",
                    TargetEntityAlias = "MaintenanceActivityOrder_MaintenancePlanInstance_2",
                    TargetJoinType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.JoinType.InnerJoin,
                    TargetProperty = "Id"
                }
            };

                            DataSet queryResults = outputQuery.Execute(false, null);

                            if (queryResults.Tables.Count <= 0 || queryResults.Tables[0].Rows.Count <= 0)
                            {
                                defaultTransition = availableTransitions.Single(q =>
                                q.FromState.Equals(resource.CurrentMainState.CurrentState) &&
                                q.ToState.Equals(stateStandby));
                            }

                            possibleTransitions.AddRange(availableTransitions);
                        }

                        #endregion

                        #region Resource State(s): Nonscheduled

                        // NonScheduled > Standby
                        else if (resource.CurrentMainState.CurrentState.Equals(stateNonscheduled) && !ignoreInScheduling)
                        {
                            //
                            defaultTransition = availableTransitions.Single(q =>
                            q.FromState.Equals(resource.CurrentMainState.CurrentState) &&
                            q.ToState.Equals(stateStandby));
                            //
                            possibleTransitions.AddRange(availableTransitions);
                        }

                        #endregion

                        #region Resource State(s): {all other}

                        else
                        {
                            possibleTransitions.AddRange(availableTransitions);
                        }

                        #endregion
                    }
                    #endregion

                    #region  Material Action: Track In Material

                    else if (currentContext.StartsWith("TrackInMaterial", StringComparison.InvariantCultureIgnoreCase))
                    {
                        // if resource is on Standby
                        if (resource.CurrentMainState.CurrentState.Equals(stateStandby))
                        {
                            IStateModelTransition standByToProductive = availableTransitions.FirstOrDefault(x => x.FromState.Equals(stateStandby) && x.ToState.Equals(stateProductive));
                            if (standByToProductive != null)
                            {
                                defaultTransition = standByToProductive;
                                possibleTransitions.Add(standByToProductive);
                            }

                            IStateModelTransition standByToEngineering = availableTransitions.FirstOrDefault(x => x.FromState.Equals(stateStandby) && x.ToState.Equals(stateEngineering));
                            if (standByToEngineering != null)
                            {
                                possibleTransitions.Add(standByToEngineering);
                            }
                        }
                        else
                        {
                            possibleTransitions.AddRange(availableTransitions);
                        }
                    }

                    #endregion

                    #region Material Action: Track Out Material

                    else if (currentContext.StartsWith("TrackOutMaterial", StringComparison.InvariantCultureIgnoreCase))
                    {
                        // if resource is on Standby
                        if (resource.CurrentMainState.CurrentState.Equals(stateStandby))
                        {
                            possibleTransitions.AddRange(availableTransitions);
                        }

                        //
                        if (resource.CurrentMainState.CurrentState.Equals(stateProductive) ||
                            resource.CurrentMainState.CurrentState.Equals(stateEngineering))
                        {
                            #region establish materials in process count

                            // establish the number of materials in process (from datastore)
                            int? dbMaterialsInProcessCount = isTopMostResource == true ?
                                resource.MaterialsInProcessCount :
                                resource.GetMaterialsInProcessCount();
                            if (dbMaterialsInProcessCount.HasValue == false) { dbMaterialsInProcessCount = 0; }

                            // reload session materials and establish the number of materials in process (from session)
                            if (materials != null && materials.Any()) { materials.Load(); }
                            int ssMaterialsInProcessCount = materials.Where(q =>
                                q.LastProcessedResource != null && q.LastProcessedResource.Id == resource.Id &&
                                q.SystemState == MaterialSystemState.InProcess &&
                                q.UniversalState == UniversalState.Active).Count();

                            #endregion

                            // evaluate if we are going to transit to StandBy
                            bool isToTransitToStandBy =
                                (currentContext.EndsWith("Post", StringComparison.InvariantCultureIgnoreCase) && dbMaterialsInProcessCount == 0) ||
                                (currentContext.EndsWith("Pre", StringComparison.InvariantCultureIgnoreCase) && dbMaterialsInProcessCount <= ssMaterialsInProcessCount);

                            //
                            if (isToTransitToStandBy)
                            {
                                IStateModelTransition toStandBy = availableTransitions.FirstOrDefault(x => x.FromState.Equals(resource.CurrentMainState.CurrentState) && x.ToState.Equals(stateStandby));
                                if (toStandBy != null)
                                {
                                    defaultTransition = toStandBy;
                                    possibleTransitions.Add(toStandBy);
                                }
                            }
                            else
                            {
                                defaultTransition = null;
                                possibleTransitions.AddRange(availableTransitions);
                            }
                        }
                    }

                    #endregion

                    #region Material Action: Abort Material

                    else if (currentContext.StartsWith("AbortMaterial", StringComparison.InvariantCultureIgnoreCase))
                    {
                        // if resource is on Standby
                        if (resource.CurrentMainState.CurrentState.Equals(stateStandby))
                        {
                            defaultTransition = null;
                            possibleTransitions.AddRange(availableTransitions);
                        }

                        // if resource is on Productive or Engineering (applicable on topmost resources)
                        if (resource.CurrentMainState.CurrentState.Equals(stateProductive) ||
                            resource.CurrentMainState.CurrentState.Equals(stateEngineering))
                        {
                            #region establish materials in process count

                            // establish the number of materials in process (from datastore)
                            int? dbMaterialsInProcessCount = isTopMostResource == true ?
                                resource.MaterialsInProcessCount :
                                resource.GetMaterialsInProcessCount();
                            if (dbMaterialsInProcessCount.HasValue == false) { dbMaterialsInProcessCount = 0; }

                            // reload session materials and establish the number of materials in process (from session)
                            if (materials != null && materials.Any()) { materials.Load(); }
                            int ssMaterialsInProcessCount = materials.Where(q =>
                                q.LastProcessedResource != null && q.LastProcessedResource.Id == resource.Id &&
                                q.SystemState == MaterialSystemState.InProcess &&
                                q.UniversalState == UniversalState.Active).Count();

                            #endregion

                            // evaluate if we are going to transit to StandBy
                            bool isToTransitToStandBy =
                                (currentContext.EndsWith("Post", StringComparison.InvariantCultureIgnoreCase) && dbMaterialsInProcessCount == 0) ||
                                (currentContext.EndsWith("Pre", StringComparison.InvariantCultureIgnoreCase) && dbMaterialsInProcessCount <= ssMaterialsInProcessCount);

                            if (isToTransitToStandBy)
                            {
                                IStateModelTransition toStandBy = availableTransitions.FirstOrDefault(x => x.FromState.Equals(resource.CurrentMainState.CurrentState) && x.ToState.Equals(stateStandby));
                                if (toStandBy != null)
                                {
                                    defaultTransition = toStandBy;
                                    possibleTransitions.Add(toStandBy);
                                }
                            }
                            else
                            {
                                defaultTransition = null;
                                possibleTransitions.AddRange(availableTransitions);
                            }
                        }
                    }

                    #endregion

                    else
                    {
                        possibleTransitions.AddRange(availableTransitions);
                    }

                    #endregion

                    #region Post Conditions
                    #endregion
                }
                // Add all available transitions for non SEMI-10 State Models
                else
                {
                    possibleTransitions.AddRange(availableTransitions);
                }

                Input["DefaultTransition"] = defaultTransition;

                if (isToLogEvent && defaultTransition != null)
                {
                    resource.LogEvent(defaultTransition.Name, resource.CurrentMainState.StateModel, defaultTransition.ReasonDefaultValue);
                }

                Input["PossibleTransitions"] = possibleTransitions;
            }
            //---End DEE Code---

            return Input;
        }


    }
}
