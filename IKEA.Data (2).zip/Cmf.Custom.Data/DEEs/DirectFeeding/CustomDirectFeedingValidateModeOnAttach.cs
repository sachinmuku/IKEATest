﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.Exceptions;
using Cmf.Foundation.Common;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.ResourceManagement.InputObjects;
using Microsoft.Extensions.DependencyInjection;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Threading;

namespace Cmf.Custom.IKEA.Actions.DirectFeeding
{
    public class CustomDirectFeedingValidateModeOnAttach : Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text:
            ///     Action to validate if, in Direct Feeding mode, the attach process is valid (should only be from first line).
            /// Action Groups:
            ///     ResourceManagement.ResourceManagementOrchestration.AttachConsumableToResource.Pre
            ///     ResourceManagement.ResourceManagementOrchestration.AttachConsumablesToResource.pre
            /// </summary>
            #endregion

            System.IServiceProvider serviceProvider = ApplicationContext.CurrentServiceProvider;
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "ResourceManagement.ResourceManagementOrchestration.AttachConsumableToResource.pre",
                "ResourceManagement.ResourceManagementOrchestration.AttachConsumablesToResource.pre"
            };

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            if (executionVeridict && IKEADEEActionUtilities.GetInputItem<AttachConsumableToResourceInput>(Input, "AttachConsumableToResourceInput") == null
                                  && IKEADEEActionUtilities.GetInputItem<AttachConsumablesToResourceInput>(Input, "AttachConsumablesToResourceInput") == null)
            {
                executionVeridict = false;
            }

            bool isDirectFeedingEnabled = genericUtilities.GetConfigurationValueByPath<bool>(IKEAConstants.EnableDirectFeedingConfig);
            if (!isDirectFeedingEnabled)
            {
                return false;
            }

            AttachConsumableToResourceInput attachConsumableInput = IKEADEEActionUtilities.GetInputItem<AttachConsumableToResourceInput>(Input, "AttachConsumableToResourceInput");
            AttachConsumablesToResourceInput attachConsumablesInput = IKEADEEActionUtilities.GetInputItem<AttachConsumablesToResourceInput>(Input, "AttachConsumablesToResourceInput");

            // Get resource that the material is being attached to
            IResource resource;
            if (attachConsumablesInput != null)
            {
                resource = attachConsumablesInput.Resource;
            }
            else
            {
                resource = attachConsumableInput.Resource;
            }

            if (resource == null)
            {
                return false;
            }
            deeContextUtilities.SetContextParameter(IKEAConstants.CustomDirectFeedingValidateModeOnAttachResourceContextKey, resource);


            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
            //Navigo
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.ResourceManagement.InputObjects");

            //Foundation
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects.Cultures");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Exceptions");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            System.IServiceProvider serviceProvider = ApplicationContext.CurrentServiceProvider;
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();

            IResource resource = deeContextUtilities.GetContextParameter(IKEAConstants.CustomDirectFeedingValidateModeOnAttachResourceContextKey) as IResource;

            resource.Load();
            IResource topMostResource = resource.GetTopMostResource();

            bool resourceDirectFeedingEnabled = topMostResource.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomResourceDirectFeedingEnabled, true);
            bool resourceIsFirstLine = topMostResource.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomResourceDirectFeedingIsFirstLine, true);
            bool? isValidToAttach = deeContextUtilities.GetContextParameter(IKEAConstants.CustomDirectFeedingAutomaticAttach) as bool?;

            // If resource is of DirectFeeding and is second line, then attach is only valid if is coming from first line (we know this is context parameter is set to true)
            if (resourceDirectFeedingEnabled && !resourceIsFirstLine && (!isValidToAttach.HasValue || !isValidToAttach.Value))
            {
                throw new IKEAException(IKEAConstants.CustomAttachConsumableNotValidInDirectFeedingMode, topMostResource.Name);
            }

            // Reset parameter
            deeContextUtilities.SetContextParameter(IKEAConstants.CustomDirectFeedingAutomaticAttach, false);
            //---End DEE Code---
            return Input;
        }

    }
}
