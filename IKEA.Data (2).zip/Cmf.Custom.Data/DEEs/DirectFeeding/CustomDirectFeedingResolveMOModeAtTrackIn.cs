﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;

using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Exceptions;
using Cmf.Custom.IKEA.Common.Extensions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects;
using Microsoft.Extensions.DependencyInjection;

using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading;

namespace Cmf.Custom.IKEA.Actions.DirectFeeding
{
    public class CustomDirectFeedingResolveMOModeAtTrackIn : Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   


            /// <summary>
            /// Summary text:
            ///     Action to update the MO mode when tracked-in in the first line or second line. The action will resolve the smart table CustomDirectFeedingRecipeMode and save the mode in the MO.
            /// Action Groups:
            ///     MaterialManagement.MaterialManagementOrchestration.ComplexTrackInMaterials.Post
            /// </summary>

            System.IServiceProvider serviceProvider = ApplicationContext.CurrentServiceProvider;

            IDirectFeedingUtilities idrUtilities = serviceProvider.GetService<IDirectFeedingUtilities>();

            ILocalizedMessage _localizedMessage = serviceProvider.GetService<ILocalizedMessage>();
            IGenericUtilities _genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "MaterialManagement.MaterialManagementOrchestration.ComplexTrackInMaterials.Post"
            };

            if (!IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups) ||
                IKEADEEActionUtilities.GetInputItem<ComplexTrackInMaterialsInput>(Input, "ComplexTrackInMaterialsInput") == null)
            {
                return false;
            }

            bool isConfigDirectFeedingEnabled = _genericUtilities.GetConfigurationValueByPath<bool>(IKEAConstants.EnableDirectFeedingConfig);
            if (!isConfigDirectFeedingEnabled)
            {
                return false;
            }

            ComplexTrackInMaterialsInput trackInMaterialsInput = IKEADEEActionUtilities.GetInputItem<ComplexTrackInMaterialsInput>(Input, "ComplexTrackInMaterialsInput");

            IMaterialCollection materialCollection = trackInMaterialsInput.Materials;
            if (materialCollection.IsNullOrEmpty())
            {
                return false;
            }

            IMaterial material = materialCollection.FirstOrDefault();
            if (material == null)
            {
                return false;
            }
            material.Load();

            IResource resource = trackInMaterialsInput.Resource;
            if (resource == null)
            {
                return false;
            }

            resource.Load();
            Collection<string> attributesToLoad = new Collection<string>() {
                    IKEAConstants.CustomResourceDirectFeedingEnabled,
                    IKEAConstants.CustomResourceDirectFeedingIsFirstLine,
                    IKEAConstants.CustomResourceDirectFeedingSendRequestTo,
                    IKEAConstants.MESAutomationInFeederSubResourceController,
                };
            resource.LoadAttributes(attributesToLoad);
            bool isResourceSetupForDirectFeeding = resource.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomResourceDirectFeedingEnabled);

            CustomDirectFeedingModeEnum? feedingMode = idrUtilities.ResolveCustomDirectFeedingRecipeModeSmartTable(material, resource);

            // DirectFeeding disabled on resource and disabled on MO
            if (!isResourceSetupForDirectFeeding && feedingMode == null)
            {
                return false;
            }
            // DirectFeeding enabled on resource and disabled on MO
            if (isResourceSetupForDirectFeeding && feedingMode == null)
            {
                throw new IKEAException(IKEAConstants.CustomDirectFeedingDownloadFailNoOrderModeMessage);
            }
            // DirectFeeding disabled on resource and enabled on MO
            if (!isResourceSetupForDirectFeeding && feedingMode != null)
            {
                throw new IKEAException(IKEAConstants.CustomDirectFeedingDownloadFailDirectFeedingDisabledMessage);
            }

            deeContextUtilities.SetContextParameter(IKEAConstants.CustomDirectFeedingResolveMOModeAtTrackInMaterialsContextKey, material);
            deeContextUtilities.SetContextParameter(IKEAConstants.CustomDirectFeedingResolveMOModeAtTrackInResourceContextKey, resource);
            deeContextUtilities.SetContextParameter(IKEAConstants.CustomDirectFeedingResolveMOModeAtTrackInFeedingModeContextKey, feedingMode);

            return true;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            // Navigo
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects");

            // Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Extensions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Exceptions");
            // Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");

            System.IServiceProvider serviceProvider = ApplicationContext.CurrentServiceProvider;
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            INiceLabelUtilities nbUtilities = serviceProvider.GetService<INiceLabelUtilities>();
            ILocalizedMessage _localizedMessage = serviceProvider.GetService<ILocalizedMessage>();
            IGenericUtilities _genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();
            IEntityFactory entityFactory = serviceProvider.GetRequiredService<IEntityFactory>();

            IResource resource = deeContextUtilities.GetContextParameter(IKEAConstants.CustomDirectFeedingResolveMOModeAtTrackInResourceContextKey) as IResource;
            IMaterial material = deeContextUtilities.GetContextParameter(IKEAConstants.CustomDirectFeedingResolveMOModeAtTrackInMaterialsContextKey) as IMaterial;
            CustomDirectFeedingModeEnum? feedingMode = deeContextUtilities.GetContextParameter(IKEAConstants.CustomDirectFeedingResolveMOModeAtTrackInFeedingModeContextKey) as CustomDirectFeedingModeEnum?;

            // Resolve the CustomDirectFeedingRecipeMode to get the Direct Feeding mode for MO

            #region Validate if there is another order in process in resource - If it can be started

            // Get valid materials in process
            IMaterialCollection materialsInProcess = resource.GetAllMaterialsInProcess();

            Collection<string> attributesToLoadMaterialsInProcess = new Collection<string>()
            {
                IKEAConstants.CustomMaterialAttributeDirectFeedingMode,
            };
            materialsInProcess.LoadAttributes(attributesToLoadMaterialsInProcess);

            int countOfMaterialsWithDF = materialsInProcess.Where(m => m.GetAttributeValueOrDefault<CustomDirectFeedingModeEnum>(IKEAConstants.CustomMaterialAttributeDirectFeedingMode) == CustomDirectFeedingModeEnum.DirectFeeding).Count();
            int countOfMaterials = materialsInProcess.Count();

            // If there is an order defined as DF or current order being tracked in is defined for DF, then there there cannot be any other orders
            if ((countOfMaterialsWithDF > 0 || feedingMode == CustomDirectFeedingModeEnum.DirectFeeding) && countOfMaterials > 1)
            {
                throw new IKEAException(IKEAConstants.CustomDirectFeedingOrderStillInProcess, material.Name, resource.Name);
            }

            #endregion

            // True if first line - false if second line
            bool isFirstLineResource = resource.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomResourceDirectFeedingIsFirstLine);

            // If the resource is second line then perform validations
            if (!isFirstLineResource)
            {
                #region validate first line is already setup

                // Get the first line resource in the DirectFeedingSendRequestTo attribute
                string firstLineResourceName = resource.GetAttributeValueOrDefault<string>(IKEAConstants.CustomResourceDirectFeedingSendRequestTo);

                if (string.IsNullOrEmpty(firstLineResourceName))
                {
                    throw new IKEAException(IKEAConstants.CustomTrackInMODirectFeedingSendRequestToNotDefined, material.Name);
                }

                IResource firstLineResource = entityFactory.Create<IResource>();
                firstLineResource.Name = firstLineResourceName;
                firstLineResource.Load();

                Collection<string> attributesToLoad = new Collection<string>() {
                        IKEAConstants.CustomResourceDirectFeedingEnabled,
                    };
                firstLineResource.LoadAttributes(attributesToLoad);

                // Check if first line is setup for direct feeding
                bool isFirstLineSetupForDirectFeeding = firstLineResource.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomResourceDirectFeedingEnabled);
                if (!isFirstLineSetupForDirectFeeding)
                {
                    throw new IKEAException(IKEAConstants.CustomTrackInResourceAttributesNotSetupCorrectlyMessage, firstLineResourceName);
                }

                // Validate if resource has MO tracked in
                IMaterialCollection firstLineTrackedInMaterials = firstLineResource.GetAllMaterialsInProcess();

                // If order being tracked-in on the second line is direct feeding and the first line is not setup, then throw error
                if (feedingMode == CustomDirectFeedingModeEnum.DirectFeeding && (firstLineResource.MaterialsInProcessCount == 0 || firstLineTrackedInMaterials == null || firstLineTrackedInMaterials.Count == 0))
                {
                    throw new IKEAException(IKEAConstants.CustomTrackInMOFirstLineNotSetUp, material.Name, firstLineResourceName);
                }

                #endregion

                // Get the counter part MO
                IMaterial materialCounterpart = firstLineTrackedInMaterials.FirstOrDefault();

                if (materialCounterpart != null && feedingMode == CustomDirectFeedingModeEnum.DirectFeeding)
                {
                    materialCounterpart.Load();
                    attributesToLoad = new Collection<string>() {
                        IKEAConstants.CustomMaterialAttributeDirectFeedingMode,
                        IKEAConstants.CustomMaterialAttributeDefaultCompletedQuantity
                    };
                    materialCounterpart.LoadAttributes(attributesToLoad);

                    #region Validate DirectFeedingMode of both MOs

                    // Get DirectFeedingMode of CounterPart
                    CustomDirectFeedingModeEnum counterPartDirectFeedingMode = materialCounterpart.GetAttributeValueOrDefault<CustomDirectFeedingModeEnum>(IKEAConstants.CustomMaterialAttributeDirectFeedingMode);

                    // Validate if the current feeding mode is equal to the counterpart's feeding mode - if they aren't equal throw an error
                    if (counterPartDirectFeedingMode != feedingMode)
                    {
                        throw new IKEAException(IKEAConstants.CustomTrackInMOAndCounterPartDirectFeedingModesAreNotEqualMessage, material.Name, materialCounterpart.Name);
                    }

                    #endregion

                    #region Validate if the DefaultCompletedQuantity is equal and if quantity of second line is equal or higher than the one in first line

                    // Get DefaultCompletedQuantity of both MOs
                    material.LoadAttribute(IKEAConstants.CustomMaterialAttributeDefaultCompletedQuantity);
                    decimal currentMODefaultCompletedQuantity = material.GetAttributeValueOrDefault<decimal>(IKEAConstants.CustomMaterialAttributeDefaultCompletedQuantity);

                    // Get BOM quantity for second line
                    IResource mainFeeder = entityFactory.Create<IResource>();
                    mainFeeder.Name = resource.GetAttributeValueOrDefault<string>(IKEAConstants.MESAutomationInFeederSubResourceController);
                    if (mainFeeder.Name == string.Empty || !mainFeeder.ObjectExists())
                    {
                        throw new CmfBaseException(IKEAConstants.CustomAutomationNullOrMissingMainFeeder);

                    }
                    IBOMProductCollection currentBOMProducts = material.GetBOMProductsForSubResource(mainFeeder);
                    decimal quantityBomProduct = currentBOMProducts.FirstOrDefault().Quantity.Value;

                    // Second Line
                    decimal counterPartMODefaultCompletedQuantity = materialCounterpart.GetAttributeValueOrDefault<decimal>(IKEAConstants.CustomMaterialAttributeDefaultCompletedQuantity);

                    // Compare the quantities - if the default completed quantity is equal, second line quantity is multiplied by the Bom quantity in case the 
                    // ratio for consumption between lines isn't 1:1, for example, if it needs to consume 3 pallets of the second Line to produce 1 pallet on the first line
                    if (counterPartMODefaultCompletedQuantity != currentMODefaultCompletedQuantity * quantityBomProduct)
                    {
                        throw new IKEAException(IKEAConstants.CustomTrackInMOFirstLineDefaultCompletedQuantityIsNotEqualOrHigherMessage, material.Name, materialCounterpart.Name);
                    }

                    // Make sure first line quantity is higher or equal to the second line, to ensure there is enough quantity for the whole process
                    if (materialCounterpart.PrimaryQuantity < material.PrimaryQuantity * quantityBomProduct)
                    {
                        throw new IKEAException(IKEAConstants.CustomTrackInMOSecondLineQuantityIsNotEqualOrHigherMessage, material.Name, materialCounterpart.Name);
                    }

                    #endregion

                    // Link both MOs through the counterpart attribute - update the attribute with the MO name
                    material.SaveAttributes(new AttributeCollection() { { IKEAConstants.CustomMaterialAttributeDirectFeedingCounterPart, materialCounterpart.Name } });
                    materialCounterpart.SaveAttributes(new AttributeCollection() { { IKEAConstants.CustomMaterialAttributeDirectFeedingCounterPart, material.Name } });
                }
            }

            // Update material attribute
            material.SaveAttributes(new AttributeCollection() { { IKEAConstants.CustomMaterialAttributeDirectFeedingMode, feedingMode } });

            //---End DEE Code---
            return Input;
        }

    }
}
