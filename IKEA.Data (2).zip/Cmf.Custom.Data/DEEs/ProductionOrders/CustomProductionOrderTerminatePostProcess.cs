﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.BusinessObjects;
using Cmf.Custom.IKEA.BusinessObjects.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Extensions;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;

using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading;

namespace Cmf.Custom.IKEA.Actions.ProductionOrders
{
    public class CustomProductionOrderTerminatePostProcess : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     On the Terminate of the PO terminates all the related CustomERPOperationTracking and CustomERPOperationTrackingConsumptionLogs
            /// Action Groups:
            ///     BusinessObjects.ProductionOrderCollection.Terminate.Pre
            ///     BusinessObjects.ProductionOrderCollection.Terminate.Post
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.ProductionOrderCollection.Terminate.Pre",
                "BusinessObjects.ProductionOrderCollection.Terminate.Post",
            };

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];

            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();

            bool? cancelingPO = deeContextUtilities.GetContextParameter(IKEAConstants.ValidatePOStatusCancelingPO) as bool?;

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups) && !cancelingPO.GetValueOrDefault();

            if(executionVeridict
                && IKEADEEActionUtilities.GetInputItem<IProductionOrderCollection>(Input, "ProductionOrderCollection") == null)
            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            //System
            UseReference("", "Cmf.Custom.IKEA.BusinessObjects.Abstractions");
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("", "System");
            UseReference("%MicrosoftNetPath%System.Private.CoreLib.dll", "System.Threading");

            //Foundation
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.Common.dll", "Cmf.Foundation.Common");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            //Custom
            UseReference("Cmf.Custom.IKEA.BusinessObjects.CustomERPOperationTracking.dll", "Cmf.Custom.IKEA.BusinessObjects");
            UseReference("Cmf.Custom.IKEA.BusinessObjects.CustomPOERPOperationTracking.dll", "Cmf.Custom.IKEA.BusinessObjects");
            UseReference("Cmf.Custom.IKEA.BusinessObjects.CustomPOOperationResource.dll", "Cmf.Custom.IKEA.BusinessObjects");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Extensions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IERPUtilities erpUtilities = serviceProvider.GetService<IERPUtilities>();
            ILocalizedMessage localizedMessage = serviceProvider.GetService<ILocalizedMessage>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();

            DeeContext currentContext = deeContextUtilities.SetCurrentServiceContext("CustomProductionOrderTerminatePostProcess");

            string contextERPOperationTrackingIds = "CustomProductionOrderTerminatePostProcess_ERPOperationTrackingIds";
            string contextPOOperationResources = "CustomProductionOrderTerminatePostProcess_POOperationResources";
            IProductionOrderCollection inputProductionOrders = IKEADEEActionUtilities.GetInputItem<IProductionOrderCollection>(Input, "ProductionOrderCollection");

            Dictionary<IProductionOrder, List<long>> poERPOperationTrackingIds = null;
            Dictionary<long, List<ICustomPOOperationResource>> poOperationResources = null;

            // On PRE it should get all CustomERPOperationTracking that need to be terminate
            if (currentContext.TriggerPoint == DeeTriggerPoint.Pre)
            {
                inputProductionOrders.LoadMaterials(0, null);
                if (inputProductionOrders.Any(po => po.HasMaterials))
                {
                    throw new CmfBaseException(localizedMessage.LoadLocalizedMessage(Thread.CurrentThread.CurrentCulture.Name, IKEAConstants.CustomProductionOrderMaterialsAssociatedErrorMessage).MessageText);
                }
                inputProductionOrders.LoadRelations("CustomPOERPOperationTracking");

                // Get all the CustomPOOperationResource of the PO because they are needed to report the consumption
                inputProductionOrders.LoadRelations(IKEAConstants.CustomPOOperationResource);
                poOperationResources = inputProductionOrders.Where(po => po.HasRelations(IKEAConstants.CustomPOOperationResource)).ToDictionary(po => po.Id, po => po.RelationCollection[IKEAConstants.CustomPOOperationResource].Select(r => r as ICustomPOOperationResource).ToList());

                if (!poOperationResources.IsNullOrEmpty())
                {
                    deeContextUtilities.SetContextParameter(contextPOOperationResources, poOperationResources);
                }
                var grouped = inputProductionOrders.Where(po => po.HasRelations("CustomPOERPOperationTracking"))
                                                 .SelectMany(po => po.RelationCollection["CustomPOERPOperationTracking"].Select(ot => ot as ICustomPOERPOperationTracking))
                                                 .GroupBy(po => po.SourceEntity.Id);

                if (!grouped.IsNullOrEmpty())
                {
                    // Get all the CustomERPOperationTracking ids related with the PO
                    poERPOperationTrackingIds = grouped.ToDictionary(g => inputProductionOrders.Where(p => p.Id == g.Key).First(),
                                                                     g => g.ToList().Select(r => r.GetNativeValue<long>("TargetEntity")).ToList());

                    deeContextUtilities.SetContextParameter(contextERPOperationTrackingIds, poERPOperationTrackingIds);
                }
            }
            else
            {
                poERPOperationTrackingIds = deeContextUtilities.GetContextParameter(contextERPOperationTrackingIds) as Dictionary<IProductionOrder, List<long>>;
                poOperationResources = deeContextUtilities.GetContextParameter(contextPOOperationResources) as Dictionary<long, List<ICustomPOOperationResource>>;

                // Check if there are any CustomERPOperationTracking ids related with the PO defined
                if (!poERPOperationTrackingIds.IsNullOrEmpty())
                {
                    string orderForm = ikeaUtilities.GetOrderMaterialForm();
                    string batchForm = ikeaUtilities.GetOrderMaterialBatch();
                    ICustomERPOperationTrackingCollection erpOperationTrackings = entityFactory.CreateCollection<ICustomERPOperationTrackingCollection>();
                    erpOperationTrackings.LoadByIDs<ICustomERPOperationTracking, CustomERPOperationTracking>(poERPOperationTrackingIds.Values.SelectMany(x => x).ToList());

                    Dictionary<long, ICustomERPOperationTracking> trackings = erpOperationTrackings.ToDictionary(t => t.Id, t => t);

                    // Report closing of each operation
                    foreach (var poERPOPTracking in poERPOperationTrackingIds)
                    {
                        IProductionOrder po = poERPOPTracking.Key;
                        po.Load();
                        foreach (var item in erpOperationTrackings.GroupBy(a => a.OrderOperation))
                        {
                            ICustomERPOperationTracking opTracker = item.First();
                            //Report operation
                            opTracker.ReportOperation(0, productionOrder: po, isOperationClosure: true);
                        }
                        //Report PO Close
                        erpUtilities.ReportProductionOrderComplete(po);
                    }

                    // Terminate all CustomERPOperationTracking
                    erpOperationTrackings.TerminateAllCustomERPOperationTracking(poERPOperationTrackingIds, poOperationResources);
                }
            }

            //---End DEE Code---

            return Input;
        }
    }
}
