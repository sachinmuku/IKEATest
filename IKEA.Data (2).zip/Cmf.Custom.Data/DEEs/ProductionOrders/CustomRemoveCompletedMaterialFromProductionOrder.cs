﻿using Cmf.Custom.IKEA.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.Abstractions;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Actions.ProductionOrders
{
    /// <summary>
    /// This DEE removes a material associated with a production order that reaches a completion step from the Production order
    /// so it can proceed and be consumed in other processes without affecting completed quantities of the production order
    /// </summary>
    public class CustomRemoveCompletedMaterialFromProductionOrder : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---

            //System
            UseReference("", "Cmf.Navigo.BusinessOrchestration.Abstractions");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System");
            UseReference("", "System.Collections.ObjectModel");

            //Foundation
            UseReference("Cmf.Foundation.Configuration.dll", "Cmf.Foundation.Configuration");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            var materialOrchestration = serviceProvider.GetService<IMaterialOrchestration>();

            //IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();

            IMaterialCollection materials = Input["MaterialCollection"] as IMaterialCollection;
            if(materials != null && materials.Count > 0)
            {
                // Material Collection that holds all eligible materials for removing from PO
                // check for each material if it is marked as completed, belonging to a Production Order in a step that marks for completion
                IMaterialCollection materialsToRemoveFromPO = entityFactory.CreateCollection<IMaterialCollection>();
                materialsToRemoveFromPO.AddRange(materials.Where(E => E.IsProductionComplete && E.GetNativeValue<long>("ProductionOrder") > 0 && E.Step.MarksProductCompletion));

                if(materialsToRemoveFromPO.Count > 0)
                {
                    // remove material from Production order keeping its quantities
                    materialOrchestration.ChangeMaterialsProductionOrder(
                        new ChangeMaterialsProductionOrderInput()
                        {
                            MaterialProductionOrders = materialsToRemoveFromPO.ToDictionary(E=> E, E=> (IProductionOrder) null)
                            , IsToCopyOrderPriority = false
                            , IsToCopyOrderPlannedEndDate = false
                            , AssignChilds = true
                            , IsToAccountToOldProductionOrderQuantity = true
                            , IsToAccountToNewProductionOrderQuantity = false
                            , IsToRemoveFromOldProductionOrder = false
                        }
                    );

                    // Refresh materials for the remaining code
                    materialsToRemoveFromPO.Load();
                }
            }

            //---End DEE Code---
            return null;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="Input"></param>
        /// <returns></returns>
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---

            #region Info
            /// <summary>
            /// Summary text
            ///     Removes material from PO if it entered a step that marks material as completed

            /// Action Groups:
            ///     BusinessObjects.MaterialCollection.ChangeFlowAndStep.Post
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.MaterialCollection.ChangeFlowAndStep.Post"
                , "BusinessObjects.MaterialCollection.MoveToNextStep.Post"
                , "BusinessObjects.MaterialCollection.MoveToStep.Post"
            };

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups) && IKEADEEActionUtilities.GetInputItem<IMaterialCollection>(Input, "MaterialCollection") != null;

            return executionVeridict;

            //---End DEE Condition Code---
        }
    }
}
