﻿using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.Abstractions;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Cmf.Common.CustomActionUtilities;

namespace Cmf.Custom.IKEA.Actions.ProductionOrders
{
    /// <summary>
    /// This DEE triggers at the creation of Production Orders and automatically creates a material for it
    /// </summary>
    public class CustomProductionOrderAutoCreateMOMaterial : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---

            // MES
            UseReference("", "Cmf.Navigo.BusinessOrchestration.Abstractions");
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement");
            UseReference("", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects");

            // Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            var materialOrchestration = serviceProvider.GetService<IMaterialOrchestration>();

            //IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            ILocalizedMessage localizedMessage = serviceProvider.GetService<ILocalizedMessage>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();

            IProductionOrderCollection posToOperate = IKEADEEActionUtilities.GetInputItem<IProductionOrderCollection>(Input, "ProductionOrderCollection", entityFactory.CreateCollection<IProductionOrderCollection>());
            if (posToOperate != null && posToOperate.Count > 0)
            {
                // collect all POs and related Products
                Dictionary<long, long> poProductIDs = posToOperate.ToDictionary(E => E.Id, E => E.GetNativeValue<long>("Product"));

                // collect all distinct product IDs and load them 
                #region Product Gathering

                Collection<long> productIDs = new Collection<long>(poProductIDs.Values.Distinct().ToList());
                IProductCollection allProducts = entityFactory.CreateCollection<IProductCollection>();
                if (productIDs.Count > 1)
                {
                    allProducts.LoadByIDs<IProduct, Product>(productIDs);
                }
                else
                {
                    allProducts.Add(posToOperate.First().Product);
                }

                Dictionary<long, IProduct> productDictionary = allProducts.ToDictionary(E => E.DefinitionId, E => E);

                #endregion

                // get order material form to use
                String orderMaterialForm = ikeaUtilities.GetOrderMaterialForm();

                // for each PO, set up a material with the required settings
                IMaterialCollection materialsToCreate = entityFactory.CreateCollection<IMaterialCollection>();
                foreach (IProductionOrder poToHandle in posToOperate)
                {
                    if (poToHandle.FlowPath == null)
                        throw new Exception(ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomProductionOrderAutoCreateMOMaterial, poToHandle.Name));

                    IMaterial materialToAdd = entityFactory.Create<IMaterial>();
                    materialToAdd.Name = poToHandle.Name;
                    materialToAdd.Description = poToHandle.Description;
                    materialToAdd.PrimaryQuantity = poToHandle.Quantity;
                    materialToAdd.PrimaryUnits = poToHandle.Units;
                    materialToAdd.FlowPath = poToHandle.FlowPath;
                    materialToAdd.Flow = poToHandle.Flow;
                    materialToAdd.Step = poToHandle.Step;
                    materialToAdd.Product = productDictionary[poProductIDs[poToHandle.Id]];
                    materialToAdd.Type = poToHandle.Type;
                    materialToAdd.Form = orderMaterialForm;
                    materialToAdd.ProductionOrder = poToHandle;
                    materialToAdd.Facility = poToHandle.Facility;

                    materialToAdd.Attributes[IKEAConstants.CustomMaterialIsOrderlessAttribute] = poToHandle.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomProductionOrderIsOrderlessAttribute, defaultValue: false, true);
                    materialsToCreate.Add(materialToAdd);
                }

                // create materials
                if (materialsToCreate.Count > 0)
                {
                    materialOrchestration.CreateMaterials(new CreateMaterialsInput() { Materials = materialsToCreate });
                }
            }


            //---End DEE Code---
            return null;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="Input"></param>
        /// <returns></returns>
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---

            #region Info

            /* Description: 
             *   This DEE triggers at the creation of Production Orders and automatically creates a material for it
             *      
             * Action groups:
             *   - BusinessObjects.ProductionOrderCollection.Create.Post
            */

            #endregion

            // By default, action is not to be executed
            bool executionVeridict = false;

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.ProductionOrderCollection.Create.Post"
            };

            // only proceed if within expected triggers (action groups)
            executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            return executionVeridict;

            //---End DEE Condition Code---
        }
    }
}
