﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;

namespace Cmf.Custom.IKEA.Actions.NameGenerators
{
    /// <summary>
    /// Custom action to send information to the NameGenerator depending on the Material Type and existence of BaseMaterial Attribute
    /// </summary>
    public class CustomGetMaterialBaseName : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---

            
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");

            // MES
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            //Foundation
            UseReference("Cmf.Foundation.Common.dll", "Cmf.Foundation.Common");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();

            IGenericUtilities _genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();


            // try to extract entity object from EntitySource input item if existing
            object oEntitySource = Input["EntitySource"];
            if (oEntitySource != null && oEntitySource is IMaterial)
            {
                // entity source defined and of type material. check if name is set or not...
                IMaterial mEntitySource = oEntitySource as IMaterial;

                bool? completeUnit = ApplicationContext.CallContext.GetInformationContext("CustomMaterialAssembleRework_CompleteUnit") as bool?;

                string baseMaterial = ikeaUtilities.GetPossibleBaseMaterial(mEntitySource, completeUnit.HasValue ? !completeUnit.Value : true);

                // Get use prefixes configuration
                bool usePrefixes = _genericUtilities.GetConfigurationValueByPath<bool>(IKEAConstants.UseNameGeneratorPrefixes);

                // Check if it should use prefixes
                if (usePrefixes)
                {
                    //Get ReRun and DirectRepair Material types
                    string reRunMaterialType = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.CustomReRunMaterialDefaultTypePath);
                    string directRepairMaterialType = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.CustomDirectRepairMaterialDefaultTypePath);

                    if(mEntitySource.Name!=null)
                    {
                        string[] splitedName = mEntitySource.Name.Split('.');
                    if (splitedName.Length > 0)
                    {
                        if (!splitedName[0].CompareStrings(reRunMaterialType)
                            && !splitedName[0].CompareStrings(directRepairMaterialType))
                        {
                            //Validate if NameGenerator is being used from CustomUnitComplete
                            string generatedPalletType = deeContextUtilities.GetContextParameter(IKEAConstants.CustomUnitCompletePalletTypeContextKey) as string;
                            if (!string.IsNullOrEmpty(generatedPalletType))
                            {
                                //Set prefix according to material type ReRun and DirectRepair
                                if (generatedPalletType == reRunMaterialType)
                                {
                                    baseMaterial = reRunMaterialType + "." + baseMaterial;
                                }
                                if (generatedPalletType == directRepairMaterialType)
                                {
                                    baseMaterial = directRepairMaterialType + "." + baseMaterial;
                                }
                            }
                        }
                        else
                        {
                            baseMaterial = string.Format("{0}.{1}", splitedName[0], baseMaterial);
                        }
                    }
                    }
                }

                //Use name generator based on BaseMaterial if it is defined
                if (!string.IsNullOrWhiteSpace(baseMaterial))
                {
                    Input["Result"] = baseMaterial;
                }
                else
                {
                    Input["Result"] = mEntitySource.Name;
                }
            }



            //---End DEE Code---
            return null;
        }

        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---
            return true;
            //---End DEE Condition Code---
        }
    }
}
