﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessOrchestration.NameGeneratorManagement;
using Cmf.Foundation.BusinessOrchestration.NameGeneratorManagement.InputObjects;
using Cmf.Foundation.BusinessOrchestration.NameGeneratorManagement.OutputObjects;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Actions.NameGenerators
{
    /// <summary>
    /// This class is responsible for determining which material name generator to use
    /// </summary>
    public class CustomMaterialNameGeneratorHandler : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---

            // Core
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");


            // Core
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.NameGeneratorManagement");
            UseReference("", "Cmf.Foundation.BusinessOrchestration.NameGeneratorManagement.InputObjects");
            UseReference("", "Cmf.Foundation.BusinessOrchestration.NameGeneratorManagement.OutputObjects");

            // MES
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            // Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            INiceLabelUtilities nbUtilities = serviceProvider.GetService<INiceLabelUtilities>();
            ILocalizedMessage _localizedMessage = serviceProvider.GetService<ILocalizedMessage>();
            IGenericUtilities _genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            IEntityFactory entityFactory = serviceProvider.GetRequiredService<IEntityFactory>();
            // try to extract entity object from EntitySource input item if existing
            object oEntitySource = IKEADEEActionUtilities.GetInputItem<object>(Input, "EntitySource", null);
            switch (oEntitySource)
            {
                case null:
                    Input["Result"] = "OS";
                    break;
                case IMaterial:
                    IMaterial mEntitySource = oEntitySource as IMaterial;

                    String nameGeneratorToUse = null;
                    if (mEntitySource.GetNativeValue<long>("ProductionOrder") > 0)
                    {
                        // name generator to be used for generating the name
                        nameGeneratorToUse = ikeaUtilities.GetMaterialNameGenerator(mEntitySource.Form);
                    }

                    // Fall back to standard material name generator
                    if (String.IsNullOrWhiteSpace(nameGeneratorToUse))
                    {
                        nameGeneratorToUse = "MaterialNameGenerator";
                    }

                    // generate name
                    string generatorName = null;
                    if (!String.IsNullOrWhiteSpace(nameGeneratorToUse))
                    {
                        var ng = entityFactory.Create<INameGenerator>();
                        ng.Name = nameGeneratorToUse;
                        generatorName = ng.GenerateName(nameGeneratorToUse, mEntitySource);
                    }

                    if (!String.IsNullOrEmpty(generatorName))
                        Input["Result"] = generatorName;
                    break;
                case IProductionOrder:
                    IProductionOrder poEntitySource = oEntitySource as IProductionOrder;
                    poEntitySource.Load();
                    Input["Result"] = poEntitySource.Name;
                    break;
            }

            //---End DEE Code---
            return null;
        }

        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---
            return true;
            //---End DEE Condition Code---
        }
    }
}
