﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.Tasks
{
    public class CustomCancelTasksOverdueDueDate : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Cancel Tasks that have surpass the Due Date
            /// Action Groups:
            ///     BusinessObjects.TaskCollection.RemindTasks.Pre
            /// </summary>
            #endregion
            
            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.TaskCollection.RemindTasks.Pre"
            };

            // only proceed if within expected triggers (action groups)
            return IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            //System
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");

            //Foundation
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IIKEAUtilities _ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();

            // Get Tasks With Overdue Due Date
            ITaskCollection taskCollection = _ikeaUtilities.GetTaskWithOverdueDueDate();

            // Check if there are any tasks to be canceled
            if (!taskCollection.IsNullOrEmpty())
            {
                // load attributes to generate GUI Refresh messages
                taskCollection.LoadAttributes();

                // collect all task attributes
                var notificationsToSend = taskCollection.Select(E => new
                {
                    Facility = E.GetAttributeValueOrDefault<string>(IKEAConstants.MaterialTransferFromFacility) ?? String.Empty
                    , Area = E.GetAttributeValueOrDefault<string>(IKEAConstants.MaterialTransferFromArea) ?? String.Empty
                    , Resource = E.GetAttributeValueOrDefault<string>(IKEAConstants.MaterialTransferFromLocation) ?? String.Empty
                }).Distinct();

                foreach(var entry in notificationsToSend)
                {
                    _ikeaUtilities.PublishMaterialMovementEvent(entry.Facility, entry.Area, entry.Resource);
                }

                // Cancel all the tasks
                taskCollection.Cancel(new OperationAttributeCollection(), true);



            }

            //---End DEE Code---

            return Input;
        }

    }
}
