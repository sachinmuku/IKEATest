﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common;
using Cmf.Foundation.Configuration;
using Cmf.Foundation.Configuration.Abstractions;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;

using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

namespace Cmf.Custom.IKEA.Actions
{
    public class CustomSetRevisionOfProduct : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Set the revision value of a Product on Clone
            /// Action Groups:
            ///     BusinessObjects.ProductCollection.Clone.Post
            ///     BusinessObjects.ProductCollection.CreateVersion.Post
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            ILocalizedMessage localizedMessage = serviceProvider.GetService<ILocalizedMessage>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();

            string contextParameter = "CustomSetRevisionOfProduct_SplitProductName";
            string contextParameterNameSeparator = "CustomSetRevisionOfProduct_NameSeparator";
            bool proccessProduct = false;
            string separator = null;

            IConfig config = null;
            if (Config.TryGetConfig(IKEAConstants.CustomProductRevisionSeparator, out config) && config != null)
            {
                separator = Convert.ToString(config.Value);
                deeContextUtilities.SetContextParameter(contextParameterNameSeparator, separator);
            }

            if (separator == string.Empty)
            {
                throw new CmfBaseException(localizedMessage.LoadLocalizedMessage(Thread.CurrentThread.CurrentCulture.Name, IKEAConstants.CustomProductRevsionSeparatorNotSetLocalizedMessage).MessageText);
            }

            bool isCloneProduct = Input.ContainsKey("Cmf.Navigo.BusinessObjects.ProductCollection");
            bool isCreateProduct = Input.ContainsKey("ProductCollection");

            if (isCloneProduct || isCreateProduct)
            {
                IProductCollection products = Input[isCloneProduct ? "Cmf.Navigo.BusinessObjects.ProductCollection" : "ProductCollection"] as IProductCollection;

                if (!products.IsNullOrEmpty())
                {
                    Dictionary<IProduct, string[]> splitProductName = new Dictionary<IProduct, string[]>();

                    products.Load();

                    foreach (IProduct product in products)
                    {
                        if (product.Name.Contains(separator))
                        {
                            string[] splitName = product.Name.Split(separator.ToCharArray());

                            if (splitName.Length >= 2)
                            {
                                splitProductName.Add(product, splitName); 
                            }
                            else
                            {
                                throw new CmfBaseException(ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomProductNameDoesNotContainRevisionLocalizedMessage, product.Name));
                            }
                        }
                    }

                    deeContextUtilities.SetContextParameter(contextParameter, splitProductName);
                    proccessProduct = true;
                }
            }
            return proccessProduct;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            //System
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.IO");
            UseReference("", "System.Threading");
            UseReference("", "System");

            //Foundation
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects.Cultures");
            UseReference("Cmf.Foundation.Configuration.dll", "Cmf.Foundation.Configuration");
            UseReference("Cmf.Foundation.Common.dll", "Cmf.Foundation.Common");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            ILocalizedMessage localizedMessage = serviceProvider.GetService<ILocalizedMessage>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();

            string contextParameter = "CustomSetRevisionOfProduct_SplitProductName";
            string contextParameterNameSeparator = "CustomSetRevisionOfProduct_NameSeparator";

            Dictionary<IProduct, string[]> splitProductName = deeContextUtilities.GetContextParameter(contextParameter) as Dictionary<IProduct, string[]>;
            string nameSeparator = deeContextUtilities.GetContextParameter(contextParameterNameSeparator) as string;

            if (!splitProductName.IsNullOrEmpty())
            {
                foreach (KeyValuePair<IProduct, string[]> splitProduct in splitProductName)
                {
                    IProduct product = splitProduct.Key;

                    product.Load();

                    IAttributeCollection attributes = new AttributeCollection();

                    // Set the revision of the product using the last part of the product name
                    attributes.Add(IKEAConstants.CustomProductAttributeRevision, splitProduct.Value[splitProduct.Value.Length - 1]);

                    // Only change the Base Product if it's not yet defined
                    if (string.IsNullOrEmpty(product.GetAttributeValueOrDefault<string>(IKEAConstants.CustomProductAttributeBaseProduct, true)))
                    {
                        // Remove the revision part of the name
                        string[] productNameArray = splitProduct.Value.Take(splitProduct.Value.Count() - 1).ToArray();

                        // Set the Base Product as the product name without the revision
                        attributes.Add(IKEAConstants.CustomProductAttributeBaseProduct, string.Join(nameSeparator, productNameArray));
                    }

                    splitProduct.Key.SaveRelatedAttributes(attributes);
                }
            }


            //---End DEE Code---

            return Input;
        }

    }
}
