﻿using Cmf.Custom.IKEA.Common;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.SmartTables;
using Cmf.Foundation.BusinessOrchestration.TableManagement.InputObjects;
using System.Collections.Generic;
using System.Data;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessOrchestration.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;

using Cmf.Common.CustomActionUtilities;

namespace Cmf.Custom.IKEA.Actions
{
    public class CustomCloneProductBOMContext : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Action To Replicate the BOM Context of Source Product to the Clone Products
            /// Action Groups:
            ///     BusinessObjects.ProductCollection.Clone.Post
            /// </summary>
            #endregion

            return true;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            //System
            UseReference("", "Cmf.Foundation.BusinessOrchestration.Abstractions");
            UseReference("", "System");
            UseReference("", "System.Collections.Generic");
            UseReference("%MicrosoftNetPath%\\System.Data.dll", "System.Data");
            UseReference("%MicrosoftNetPath%\\System.XML.dll", "System.Xml");

            //Foundation
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects.SmartTables");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.TableManagement");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.TableManagement.InputObjects");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            var tableOrchestration = serviceProvider.GetService<ITableOrchestration>();

            if (Input.ContainsKey("Cmf.Navigo.BusinessObjects.ProductCollection"))
            {
                IProductCollection products = Input["Cmf.Navigo.BusinessObjects.ProductCollection"] as IProductCollection;
                IProduct productSource = Input["Source"] as IProduct;

                if (!products.IsNullOrEmpty())
                {
                    ISmartTable smartTable = new SmartTable() { Name = IKEAConstants.CustomSmartTableBOMContext };
                    smartTable.Load();

                    productSource.LoadBomContexts();

                    // Get BOM Context from Source Product
                    DataSet bomContexts = NgpDataSet.ToDataSet(productSource.ProductBomContexts);
                    if (bomContexts.HasData())
                    {
                        // Clone the DataSet Structure
                        DataSet newBOMContexts = bomContexts.Clone();

                        // Replicate the BOM Context through all the Clone Products
                        foreach (IProduct productTarget in products)
                        {
                            foreach (DataRow row in bomContexts.Tables[0].Rows)
                            {
                                DataRow newRow = newBOMContexts.Tables[0].NewRow();
                                newRow.CopyFrom(row);

                                newRow[IKEAConstants.CustomSmartTableBOMContextProduct] = productTarget.Name;
                                newRow[IKEAConstants.CustomSmartTableBOMContextId] = 0;
                                newRow[IKEAConstants.CustomSmartTableLastServiceHistoryId] = 0;
                                newRow[IKEAConstants.CustomSmartTableLastOperationHistorySeq] = 0;

                                newBOMContexts.Tables[0].Rows.Add(newRow);
                            }

                            newBOMContexts.AcceptChanges();
                        }

                        if (newBOMContexts.HasData())
                        {
                            // Update the Smart Table
                            FullUpdateSmartTableDataInput fullUpdateSmartTableDataInput = new FullUpdateSmartTableDataInput()
                            {
                                SmartTable = smartTable,
                                RowsToAddOrUpdate = NgpDataSet.FromDataSet(newBOMContexts)
                            };
                            tableOrchestration.FullUpdateSmartTableData(fullUpdateSmartTableDataInput);
                        }
                    }

                }
            }

            //---End DEE Code---

            return Input;
        }

        
    }
}
