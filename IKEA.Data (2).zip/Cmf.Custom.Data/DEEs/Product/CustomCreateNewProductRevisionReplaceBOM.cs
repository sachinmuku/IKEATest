﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessOrchestration.Abstractions;
using Cmf.Foundation.BusinessOrchestration.ChangeSetManagement.InputObjects;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.Abstractions;
using Cmf.Navigo.BusinessOrchestration.FacilityManagement.ProductManagement.InputObjects;
using Microsoft.Extensions.DependencyInjection;

using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions
{
    public class CustomCreateNewProductRevisionReplaceBOM : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Create Substitutes Product in BOMs when Product is effective
            /// Action Groups:
            ///     BusinessObjects.ProductCollection.MakeEffective.Post
            /// </summary>
            #endregion

            return true;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            //System
            UseReference("", "Cmf.Foundation.BusinessOrchestration.Abstractions");
            UseReference("", "Cmf.Navigo.BusinessOrchestration.Abstractions");
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("", "System.IO");
            UseReference("", "System.Threading");
            UseReference("", "System");

            //Foundation
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.ChangeSetManagement");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.ChangeSetManagement.InputObjects");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.FacilityManagement.ProductManagement");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.FacilityManagement.ProductManagement.InputObjects");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");

            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            //IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            ILocalizedMessage localizedMessage = serviceProvider.GetService<ILocalizedMessage>();

            var changeSetOrchestration = serviceProvider.GetService<IChangeSetOrchestration>();
            var productOrchestration = serviceProvider.GetService<IProductOrchestration>();

            IProductCollection products = Input["ProductCollection"] as IProductCollection;
            if (!products.IsNullOrEmpty())
            {
                products.LoadAttributes(new Collection<string>() { IKEAConstants.CustomProductAttributeBaseProduct,
                                                                    IKEAConstants.CustomProductAttributeIsBreakingChanges,
                                                                    IKEAConstants.CustomProductAttributeRevision,
                                                                    IKEAConstants.CustomProductAttributeRevisionProcessed });

                IProductCollection productsToProcess = entityFactory.CreateCollection<IProductCollection>();

                productsToProcess.AddRange(products.Where(p => p.GetRelatedAttributeValueOrDefault<string>(IKEAConstants.CustomProductAttributeBaseProduct) != string.Empty
                                                                && p.GetRelatedAttributeValueOrDefault<bool>(IKEAConstants.CustomProductAttributeIsBreakingChanges) == false
                                                                && p.GetRelatedAttributeValueOrDefault<bool>(IKEAConstants.CustomProductAttributeRevisionProcessed) == false));

                foreach (IProduct product in productsToProcess)
                {
                    // Get the revision of the product being processed
                    string actualRevision = product.GetRelatedAttributeValueOrDefault<string>(IKEAConstants.CustomProductAttributeRevision);

                    // Get Base Product
                    string baseProduct = product.GetRelatedAttributeValueOrDefault<string>(IKEAConstants.CustomProductAttributeBaseProduct);

                    IProduct revisionProduct = ikeaUtilities.GetLatestRevisionForBaseProduct(baseProduct, actualRevision, true);

                    if (revisionProduct != null)
                    {
                        // Get the revision of the previous revision of the product
                        string previousRevision = revisionProduct.GetRelatedAttributeValueOrDefault<string>(IKEAConstants.CustomProductAttributeRevision, true);

                        // Check if the actual revision is superior to the previous one
                        if (string.Compare(actualRevision, previousRevision) > 0)
                        {
                            IBOMCollection productBOMs = ikeaUtilities.GetBOMsByBaseProductNameAndRevision(baseProduct,
                                                                                                         previousRevision);

                            productBOMs.Load();
                            productBOMs.LoadRelations();

                            IChangeSet changeSet = null;

                            foreach (IBOM bOM in productBOMs)
                            {
                                ICmfEntityRelationCollection bomProuctToAdd = serviceProvider.GetService<ICmfEntityRelationCollection>();
                                ICmfEntityRelationCollection bomProuctToUpdate = serviceProvider.GetService<ICmfEntityRelationCollection>();

                                if (changeSet == null)
                                {
                                    changeSet = ikeaUtilities.CreateChangeSet();
                                }

                                bOM.ChangeSet = changeSet;

                                bOM.CreateVersion();

                                IBOMProductCollection bOMProducts = entityFactory.CreateCollection<IBOMProductCollection>();
                                bOMProducts.AddRange(bOM.RelationCollection["BOMProduct"].Select(bp => bp as IBOMProduct).Where(pb => pb.TargetEntity.GetRelatedAttributeValueOrDefault<string>(IKEAConstants.CustomProductAttributeBaseProduct, true) == baseProduct
                                                                                                                                    && pb.TargetEntity.GetRelatedAttributeValueOrDefault<string>(IKEAConstants.CustomProductAttributeRevision, true) == previousRevision));

                                foreach (IBOMProduct bomProductToProccess in bOMProducts)
                                {
                                    IBOMProduct parentBOMProduct = bomProductToProccess.Parent != null ? bomProductToProccess.Parent : bomProductToProccess;

                                    IBOMProductCollection bOMProductsChildren = entityFactory.CreateCollection<IBOMProductCollection>();
                                    bOMProductsChildren.LoadChildren(parentBOMProduct.UniqueId);

                                    int? maxOrder = bOMProductsChildren.Max(b => b.Order);

                                    IBOMProduct substituteBOMProduct = entityFactory.Create<IBOMProduct>();

                                    substituteBOMProduct.Parent = parentBOMProduct;
                                    substituteBOMProduct.Order = (maxOrder ?? 0) + 1;
                                    substituteBOMProduct.IsOptional = bomProductToProccess.IsOptional;
                                    substituteBOMProduct.IsProductMixAllowed = true;
                                    substituteBOMProduct.IsReference = bomProductToProccess.IsReference;
                                    substituteBOMProduct.Units = bomProductToProccess.Units;
                                    substituteBOMProduct.Quantity = bomProductToProccess.Quantity;
                                    substituteBOMProduct.TargetEntity = product;
                                    substituteBOMProduct.SourceEntity = bOM;
                                    substituteBOMProduct.Step = bomProductToProccess.Step;

                                    bomProuctToAdd.Add(substituteBOMProduct);

                                    parentBOMProduct.IsProductMixAllowed = true;

                                    bomProuctToUpdate.Add(parentBOMProduct);
                                }

                                FullUpdateBOMInput updateBOMInput = new FullUpdateBOMInput()
                                {
                                    BOM = bOM,
                                    FullUpdateBOMParameters = new FullUpdateBOMParameters()
                                    {
                                        RelationsToAdd = (IEntityRelationCollection<IEntityRelation>)bomProuctToAdd,
                                        RelatedRelationsToUpdate = (IEntityRelationCollection<IEntityRelation>)bomProuctToUpdate
                                    }
                                };

                                productOrchestration.FullUpdateBOM(updateBOMInput);

                            }

                            if (changeSet != null)
                            {
                                // Request approval of the ChangeSet
                                changeSetOrchestration.RequestChangeSetApproval(new RequestChangeSetApprovalInput
                                {
                                    ChangeSet = changeSet
                                });
                            }

                            // Set the revision as processed
                            IAttributeCollection attributes = new AttributeCollection();
                            attributes.Add(IKEAConstants.CustomProductAttributeRevisionProcessed, true);

                            product.SaveRelatedAttributes(attributes);
                        }

                    }

                }

            }

            //---End DEE Code---

            return Input;
        }

    }
}
