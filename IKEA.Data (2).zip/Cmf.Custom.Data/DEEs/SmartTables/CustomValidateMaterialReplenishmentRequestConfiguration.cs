﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessObjects.SmartTables;
using Cmf.Foundation.Common;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;


namespace Cmf.Custom.IKEA.Actions.SmartTables
{
    class CustomValidateMaterialReplenishmentRequestConfiguration : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Validates if facility and/or Area are filled. Ate least one of them must exist.
            /// Action Groups:
            ///     SmartTables.SmartTables.InsertOrUpdateRows.Pre
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "SmartTables.SmartTables.InsertOrUpdateRows.Pre"
            };

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            if (executionVeridict && IKEADEEActionUtilities.GetInputItem<ISmartTable>(Input, "SmartTable") == null)
            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            //System
            UseReference("", "System");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("%MicrosoftNetPath%\\System.Data.dll", "System.Data");
            UseReference("%MicrosoftNetPath%\\System.XML.dll", "System.Xml");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");

            //Foundation
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects.SmartTables");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            ISmartTable smartTable = Input["SmartTable"] as ISmartTable;
            if (smartTable.Name.CompareStrings(IKEAConstants.CustomValidateMaterialReplenishmentRequestConfiguration))
            {
                INgpDataSet ngpDataSet = Input["TableData"] as INgpDataSet;
                DataSet dataSet = NgpDataSet.ToDataSet(ngpDataSet);

                if (dataSet.HasData())
                {
                    foreach (DataRow row in dataSet.Tables[0].Rows)
                    {
                        string facility = row.GetValue<String>("Facility");
                        string area = row.GetValue<String>("Area");

                        if (String.IsNullOrEmpty(facility) && String.IsNullOrEmpty(area))
                        {
                            throw new CmfBaseException(ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomValidateMaterialReplenishmentRequestMissingFieldsLocalizedMessage, IKEAConstants.Facility, IKEAConstants.Area));
                        }
                    }
                }
            }

            //---End DEE Code---

            return Input;
        }

    }
}
