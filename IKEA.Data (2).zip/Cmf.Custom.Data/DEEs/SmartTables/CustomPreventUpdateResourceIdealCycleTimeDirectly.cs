﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessObjects.Cultures;
using Cmf.Foundation.BusinessObjects.QueryObject;
using Cmf.Foundation.BusinessObjects.SmartTables;
using Cmf.Foundation.BusinessOrchestration.TableManagement.InputObjects;
using Cmf.Foundation.BusinessOrchestration.TableManagement.OutputObjects;
using Cmf.Foundation.Common;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Threading;

namespace Cmf.Custom.IKEA.Actions.SmartTables
{
    public class CustomPreventUpdateResourceIdealCycleTimeDirectly : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---

            #region Info
            /// <summary>
            /// Summary text
            ///     Validate that the user can't update the values directy in the ResourceIdealCycleTime smart table when there is a matching row in the CustomAlternativeIdealCycleTimes
            /// Action Groups:
            ///     TableManagement.TableManagementOrchestration.FullUpdateSmartTableData.Pre
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion

            bool executionVeridict = false;
            if (Input != null)
            {
                // List of eligible action groups (configuration sanity check)
                Collection<string> EligibleActionGroups = new Collection<string>()
                {
                    "TableManagement.TableManagementOrchestration.FullUpdateSmartTableData.Pre"
                };

                // only proceed if within expected triggers (action groups)
                bool isEligibleActionGroups = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

                FullUpdateSmartTableDataInput fullUpdateSmartTableDataInput = IKEADEEActionUtilities.GetInputItem<FullUpdateSmartTableDataInput>(Input, "FullUpdateSmartTableDataInput");

                if (fullUpdateSmartTableDataInput != null)
                {
                    bool isAddOrEditAction = fullUpdateSmartTableDataInput.RowsToAddOrUpdate != null;
                    bool isEligibleTable = fullUpdateSmartTableDataInput.SmartTable.Name.Equals(IKEAConstants.ResourceIdealCycleTimeSmartTable);

                    executionVeridict = isEligibleActionGroups && isAddOrEditAction && isEligibleTable;
                }
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---

            UseReference("", "System");
            UseReference("", "System.Data");
            UseReference("%MicrosoftNetPath%System.Private.CoreLib.dll", "System.Threading");
            //Foundation
            UseReference("Cmf.Foundation.BusinessObjects.dll", "");
            UseReference("", "Cmf.Foundation.BusinessObjects");
            UseReference("", "Cmf.Foundation.BusinessObjects.SmartTables");
            UseReference("", "Cmf.Foundation.BusinessObjects.QueryObject");
            UseReference("", "Cmf.Foundation.BusinessOrchestration.TableManagement.InputObjects");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            ILocalizedMessage localizedMessage = serviceProvider.GetService<ILocalizedMessage>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();
            // Set context to skip the valition when user update the values directy in the ResourceIdealCycleTime smart table when there is a matching row in the CustomAlternativeIdealCycleTimes
            bool? skipValidation = deeContextUtilities.GetContextParameter(IKEAConstants.CustomPreventUpdateResourceIdealCycleTimeDirectlyContextKey) as bool?;

            if (skipValidation == null || skipValidation == false)
            {
                FullUpdateSmartTableDataInput input = IKEADEEActionUtilities.GetInputItem<FullUpdateSmartTableDataInput>(Input, "FullUpdateSmartTableDataInput");
                INgpDataSet rowsToAddOrUpdate = input.RowsToAddOrUpdate;

                DataSet dataSet = NgpDataSet.ToDataSet(rowsToAddOrUpdate);
                if (dataSet.HasData())
                {
                    ISmartTable smartTable = new SmartTable();
                    IFilterCollection filters = new FilterCollection();

                    List<string> smartTableKeyColumns = new List<string>()
        {
            IKEAConstants.CustomAlternativeIdealCycleTimesResourceColumn,
            IKEAConstants.CustomAlternativeIdealCycleTimesResourceTypeColumn,
            IKEAConstants.CustomAlternativeIdealCycleTimesModelColumn,
            IKEAConstants.CustomAlternativeIdealCycleTimesStepColumn,
            IKEAConstants.CustomAlternativeIdealCycleTimesProductColumn,
            IKEAConstants.CustomAlternativeIdealCycleTimesProductGroupColumn
        };

                    smartTable.Load(IKEAConstants.CustomAlternativeIdealCycleTimesSmartTable);

                    foreach (DataRow dataRow in dataSet.Tables[0].Rows)
                    {
                        long.TryParse(dataRow.Field<object>(IKEAConstants.ResourceIdealCycleTimeIdColumn).ToString(), out long resourceIdealCycleTimeIdValue);
                        if (resourceIdealCycleTimeIdValue > 0)
                        {
                            filters.Clear();

                            foreach (string column in smartTableKeyColumns)
                            {
                                bool isColumnNull = !dataRow.Table.Columns.Contains(column) || string.IsNullOrEmpty(dataRow[column] as string);
                                filters.Add(new Cmf.Foundation.BusinessObjects.QueryObject.Filter
                                {
                                    Name = column,
                                    Operator = isColumnNull ? FieldOperator.IsNull : FieldOperator.IsEqualTo,
                                    Value = isColumnNull ? null : dataRow[column]
                                });
                            }

                            smartTable.GetDataCount(filters, out int totalRows);

                            if (totalRows > 0)
                            {
                                throw new CmfBaseException(localizedMessage.LoadLocalizedMessage(Thread.CurrentThread.CurrentCulture.Name, IKEAConstants.CustomPreventUpdateResourceIdealCycleTimeDirectlyErrorLocalizedMessage).MessageText);
                            }
                        }
                    }

                }
            }

            //---End DEE Code---
            return Input;
        }
    }
}
