﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;

using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Utilities;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Text;

namespace Cmf.Custom.IKEA.Actions.SmartTables
{
    public class CustomValidateFlowPathInMaterialFlowResolution : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
			//---Start DEE Condition Code---   

			#region Info
			/// <summary>
			/// Summary text
			///     Validates columns that reference a Flowpath when instering or updating smart tables CustomMaterialFlowResolution and CustomFeederOutsortingFlowResolution
			/// Action Groups:
			///     SmartTables.SmartTables.InsertOrUpdateRows.Pre
			/// Depends On:
			/// Is Dependency For:
			/// Exceptions:
			/// </summary>
			#endregion

			// List of eligible action groups (configuration sanity check)
			Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "SmartTables.SmartTables.InsertOrUpdateRows.Pre"
            };

			// only proceed if within expected triggers (action groups)
			System.IServiceProvider serviceProvider = ApplicationContext.CurrentServiceProvider;
            
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();

			if (IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups) && IKEADEEActionUtilities.GetInputItem<ISmartTable>(Input, "SmartTable") != null)
            {
				ISmartTable smartTable = Input["SmartTable"] as ISmartTable;

                if (smartTable.Name.CompareStrings(IKEAConstants.CustomMaterialFlowResolution) 
                    || smartTable.Name.CompareStrings(IKEAConstants.CustomFeederOutsortingFlowResolutionSmartTable))
                {
					deeContextUtilities.SetContextParameter("CustomValidateFlowPathInMaterialFlowResolution_DataSet", Input["TableData"] as INgpDataSet);
                    return true;

				}
			}

            return false;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            UseReference("", "System");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("%MicrosoftNetPath%\\System.Data.dll", "System.Data");
            UseReference("%MicrosoftNetPath%\\System.XML.dll", "System.Xml");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects.SmartTables");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            UseReference("", "System.Text");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");

            System.IServiceProvider serviceProvider = ApplicationContext.CurrentServiceProvider;
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();

            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            ILocalizedMessage localizedMessage = serviceProvider.GetService<ILocalizedMessage>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            INgpDataSet ngpDataSet = deeContextUtilities.GetContextParameter("CustomValidateFlowPathInMaterialFlowResolution_DataSet") as INgpDataSet;

            DataSet dataSet = NgpDataSet.ToDataSet(ngpDataSet);
            if (dataSet != null && dataSet.Tables != null && dataSet.Tables.Count > 0 && dataSet.Tables[0].Rows != null)
            {
                StringBuilder errors = new StringBuilder();
                foreach (DataRow row in dataSet.Tables[0].Rows)
                {
                    string flowPath = row.GetValue<string>("FlowPath");
                    string consumptionFlowPath = row.GetValue<String>("ConsumptionFlowPath");

                    if (!String.IsNullOrEmpty(flowPath))
                    {
                        string correctFlowPath = genericUtilities.GetCorrectFlowPath(flowPath);

                        if (!flowPath.Equals(correctFlowPath))
                        {
                            string message = ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomDisplayCorrectFlowPathLocalizedMessage, "Flow Path", flowPath, correctFlowPath);
                            errors.AppendLine(message);
                        }
                    }

                    if (!String.IsNullOrEmpty(consumptionFlowPath))
                    {
                        string correctConsumptionFlowPath = genericUtilities.GetCorrectFlowPath(consumptionFlowPath);

                        if (!consumptionFlowPath.Equals(correctConsumptionFlowPath))
                        {
                            string message = ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomDisplayCorrectFlowPathLocalizedMessage, "Consumption Flow Path",flowPath, correctConsumptionFlowPath);
                            errors.AppendLine(message);
                        }
                    }
                }

                if (errors.Length > 0)
                {
                    throw new Exception(errors.ToString());
                }
            }

            //---End DEE Code---

            return Input;
        }

    }
}
