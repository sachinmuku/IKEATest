﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Exceptions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Foundation.Security;
using Cmf.Foundation.Security.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;

using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Data;
using System.Threading;
using INotification = Cmf.Navigo.BusinessObjects.Abstractions.INotification;

namespace Cmf.Custom.IKEA.Actions.NiceLabel
{
    public class CustomNiceLabelErrorHandler : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text: 
            /// Action used by the integration handler when there is an error performing messages from MES to NiceLabel.
            /// Check smart table IntegrationHandlerResolution for the configuration
            /// Action Groups: N/A
            /// Depends On: N/A
            /// Is Dependency For: N/A
            /// Exceptions: N/A
            /// </summary>
            #endregion

            if (Input != null && Input.ContainsKey("EdiEvent") && Input["EdiEvent"] is IIntegrationEntry)
            {
                return true;
            }

            return false;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
            // MES
            UseReference("%MicrosoftNetPath%System.Private.CoreLib.dll", "System.Threading");
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement");
            UseReference("", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects");
            // Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Exceptions");


            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            UseReference("", "Cmf.Foundation.Common");

            //System
            UseReference("", "System.Data");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            INiceLabelUtilities nbUtilities = serviceProvider.GetService<INiceLabelUtilities>();
            ILocalizedMessage localizedMessage = serviceProvider.GetService<ILocalizedMessage>();
            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            IAlarmHandlingUtilities alarmHandlingUtilities = serviceProvider.GetService<IAlarmHandlingUtilities>();
            // IAlarmHandlingUtilities ahUtilities = serviceProvider.GetService<IAlarmHandlingUtilities>();

            string administrationRole = ikeaUtilities.GetValueFromConfigurationWithPath(IKEAConstants.AdministrationRole);
            IRole role = new Role();
            role.Load(administrationRole);

            string distributionList = String.IsNullOrEmpty(role.DistributionList) ?
                ikeaUtilities.GetValueFromConfigurationWithPath(IKEAConstants.LocalSupport) : role.DistributionList;
            string maxRetries = ikeaUtilities.GetValueFromConfigurationWithPath(IKEAConstants.MaxNumberOfRetriesPath);
            int maxRetriesValue = int.Parse(string.IsNullOrEmpty(maxRetries) ? "0" : maxRetries);

            IIntegrationEntry integrationEntry = Input["EdiEvent"] as IIntegrationEntry;
            Exception exError = Input["Error"] as Exception;
            integrationEntry.LoadAttribute(IKEAConstants.IntegrationEntryAttributeNiceLabelCurrentNumberOfRetries);

            if (!integrationEntry.Attributes.ContainsKey(IKEAConstants.IntegrationEntryAttributeNiceLabelCurrentNumberOfRetries))
            {
                IAttributeCollection attributeToSave = new AttributeCollection();
                attributeToSave.Add(new KeyValuePair<string, object>(IKEAConstants.IntegrationEntryAttributeNiceLabelCurrentNumberOfRetries, -1));
                integrationEntry.SaveAttributes(attributeToSave);
            }

            if (integrationEntry.MessageType.CompareStrings(IKEAConstants.CustomNiceLabelMessageTypeSSCC) && ((int.Parse(integrationEntry.Attributes[IKEAConstants.IntegrationEntryAttributeNiceLabelCurrentNumberOfRetries].ToString(), System.Globalization.CultureInfo.InvariantCulture) + 1) < maxRetriesValue))
            {
                if (integrationEntry.NumberOfRetries == null || integrationEntry.NumberOfRetries == 2)
                {
                    integrationEntry.NumberOfRetries = -1;
                    integrationEntry.Save();
                }
                IAttributeCollection attributeToSave = new AttributeCollection();
                attributeToSave.Add(new KeyValuePair<string, object>(IKEAConstants.IntegrationEntryAttributeNiceLabelCurrentNumberOfRetries, (int.Parse(integrationEntry.Attributes[IKEAConstants.IntegrationEntryAttributeNiceLabelCurrentNumberOfRetries].ToString(), System.Globalization.CultureInfo.InvariantCulture) + 1)));
                integrationEntry.SaveAttributes(attributeToSave);
                Input["IsRetriable"] = true;
            }
            else
            {
                DataSet storedDataSet = nbUtilities.GetNiceLabelMaterialForIntegrationEntry(integrationEntry);
                if (!storedDataSet.HasData())
                {
                    throw new IKEAException(IKEAConstants.CustomNiceLabelIntegrationEntryIntegrationEntryNotOnGenericTable, integrationEntry.Name);
                }

                //Validate if Severity exists in config
                string severity = ikeaUtilities.GetValueFromConfigurationWithPath(IKEAConstants.DefaultNotificationSeverityConfig);
                if (severity.IsNullOrEmpty())
                {
                    throw new CmfBaseException(ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomDefaultNotificationSeverityConfigNotDefined, IKEAConstants.DefaultNotificationSeverityConfig));
                }

                string resourceName = null;
                string materialName = null;
                foreach (DataRow row in storedDataSet.Tables[0].Rows)
                {
                    resourceName = row.GetValue<String>(IKEAConstants.CustomNiceLabelIntegrationEntriesResourceColumn);
                    materialName = row.GetValue<String>(IKEAConstants.CustomNiceLabelIntegrationEntriesMaterialColumn);
                }

                IEmployeeCollection employeesCheckedIn = genericUtilities.GetCheckedInEmployees(resourceName);
                foreach (IEmployee employee in employeesCheckedIn)
                {
                    employee.User.Load();
                    Cmf.Navigo.BusinessObjects.Abstractions.INotification notificationEmployees = entityFactory.Create<Cmf.Navigo.BusinessObjects.Abstractions.INotification>();

                    notificationEmployees.Type = "System";
                    notificationEmployees.Title = localizedMessage.LoadLocalizedMessage(Thread.CurrentThread.CurrentCulture.Name, IKEAConstants.CustomNotificationTitleForNiceLabelErrorHandler).MessageText;
                    notificationEmployees.Details = ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomNotificationDetailsForNiceLabelErrorHandler
                                , integrationEntry.Name + " (Material Name : " + materialName + " , Resource Name: " + resourceName + " )"
                                , integrationEntry.MessageType
                                , exError.Message);
                    notificationEmployees.Severity = ikeaUtilities.GetValueFromLookupTable(IKEAConstants.NotificationSeverityLookupTableName, severity, true);
                    notificationEmployees.AssignmentType = (NotificationAssignmentType)AssignmentType.Employee;
                    notificationEmployees.AssignedToUser = employee.User;
                    notificationEmployees.SendEmailToAssignedParty = false;
                    notificationEmployees.Create();
                }

                Cmf.Navigo.BusinessObjects.Abstractions.INotification notification = entityFactory.Create<Cmf.Navigo.BusinessObjects.Abstractions.INotification>();
                notification.Type = "System";
                notification.Title = localizedMessage.LoadLocalizedMessage(Thread.CurrentThread.CurrentCulture.Name, IKEAConstants.CustomNotificationTitleForNiceLabelErrorHandler).MessageText;
                notification.Details = ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomNotificationDetailsForNiceLabelErrorHandler
                                , integrationEntry.Name + " (Material Name : " + materialName + " , Resource Name: " + resourceName + " )"
                                , integrationEntry.MessageType
                                , exError.Message);
                notification.Severity = ikeaUtilities.GetValueFromLookupTable(IKEAConstants.NotificationSeverityLookupTableName, severity, true);
                notification.AssignmentType = (NotificationAssignmentType)AssignmentType.Role;
                notification.AssignedToRole = role;
                notification.SendEmailToAssignedParty = string.IsNullOrEmpty(distributionList);
                notification.EmailDistributionList = distributionList;
                notification.Create();

                Input["IsRetriable"] = false;
            }

            //---End DEE Code---

            return Input;
        }
    }
}
