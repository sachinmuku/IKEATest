﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Extensions;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Threading;

namespace Cmf.Custom.IKEA.Actions.NiceLabel
{
    public class CustomNiceLabelNotifyOnTrackIn : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   



            #region Info
            /// <summary>
            /// Summary text:  Creates an integration entry to send notification of trackin to NiceLabel
            ///     
            /// Action Groups:   MaterialManagement.MaterialManagementOrchestration.ComplexTrackInMaterialsInput.Pre
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "MaterialManagement.MaterialManagementOrchestration.ComplexTrackInMaterials.Pre"
            };

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            if (executionVeridict && IKEADEEActionUtilities.GetInputItem<ComplexTrackInMaterialsInput>(Input, "ComplexTrackInMaterialsInput") == null)
            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            //System
            UseReference("", "System");
            UseReference("", "System.Data");
            UseReference("", "System.Collections.Generic");
            UseReference("%MicrosoftNetPath%\\System.XML.XDocument.dll", "");
            UseReference("%MicrosoftNetPath%\\System.XML.ReaderWriter.dll", "");
            UseReference("%MicrosoftNetPath%\\System.Private.XML.dll", "");
            UseReference("%MicrosoftNetPath%\\System.XML.dll", "System.Xml");

            //Foundation
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.NiceLabel");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Extensions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");

            // Newtonsoft
            UseReference("Newtonsoft.Json.dll", "Newtonsoft.Json");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            INiceLabelUtilities nbUtilities = serviceProvider.GetService<INiceLabelUtilities>();
            ILocalizedMessage localizedMessage = serviceProvider.GetService<ILocalizedMessage>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();

            ComplexTrackInMaterialsInput input = (ComplexTrackInMaterialsInput)Input["ComplexTrackInMaterialsInput"];

            IResource mainResource = input.Resource;
            IResource printingQueueResource = ikeaUtilities.GetAssociatedPrintingQueueResource(input.Resource);

            string printingSystem = string.Empty;

            if (printingQueueResource != null)
            {
                printingSystem = printingQueueResource.GetAttributeValueOrDefault<string>(IKEAConstants.CustomResourcePrintingSystemAttribute, true);
            }

            if (printingSystem != null && printingSystem.Equals(IKEAConstants.NiceLabelSystem))
            {
                string requestEndpoint = IKEAConstants.NiceLabelNotifyTrackInMessageType;

                foreach (IMaterial material in input.Materials)
                {
                    material.Load();

                    // resolve the recipeID from CustomNiceLabelContext Smart Table
                    int recipeID;

                    DataSet recipeDataSet = nbUtilities.ResolveNiceLabelContextSmartTable(mainResource, material.Product);
                    if (recipeDataSet != null && recipeDataSet.HasData())
                    {
                        recipeID = recipeDataSet.Tables[0].Rows[0].Field<int>(IKEAConstants.CustomNiceLabelContextRecipeIDColumn);
                    }
                    else
                    {
                        throw new CmfBaseException(ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomNiceLabelRecipeIDNotConfiguredLocalizedMessage, mainResource.Name, material.Product.Name));
                    }

                    if (material.ProductionOrder != null)
                    {
                        NiceLabelIntegrationMessage niceLabelIntegrationMessage = new NiceLabelIntegrationMessage()
                        {
                            _Id = Guid.NewGuid().ToString(),
                            MOID = material.ProductionOrder.Name,
                            ItemNo = material.Product.GetBaseProduct().Name,
                            Workcenter = mainResource.Name,
                            Recipe = recipeID
                        };

                        IIntegrationEntry integrationEntry = nbUtilities.CreateNiceLabelOutgoingIntegrationEntry(niceLabelIntegrationMessage,
                                                                                                    requestEndpoint,
                                                                                                    requestType: IKEAConstants.NiceLabelNotifyTrackInMessageType,
                                                                                                    eventName: IKEAConstants.NiceLabelNotifyTrackInEventName);
                    }
                }
            }

            //---End DEE Code---

            return Input;
        }
    }
}
