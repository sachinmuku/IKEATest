﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;

using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Exceptions;
using Cmf.Custom.IKEA.Common.NiceLabel;
using Cmf.Custom.IKEA.Orchestration.InputObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Xml;
using DocumentFormat.OpenXml.Spreadsheet;
using Microsoft.CodeAnalysis.VisualBasic.Syntax;
using Cmf.Custom.IKEA.Common.Utilities;

namespace Cmf.Custom.IKEA.Actions.NiceLabel
{
    public class CustomNiceLabelHandler : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text: 
            /// Action used by the integration handler when performing messages from MES to NiceLabel.
            /// Check smart table IntegrationHandlerResolution for the configuration
            /// Action Groups: N/A
            /// Depends On: N/A
            /// Is Dependency For: N/A
            /// Exceptions: N/A
            /// </summary>
            #endregion

            return true;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            //System
            UseReference("", "System");
            UseReference("", "System.Text");
            UseReference("", "System.Linq");
            UseReference("", "System.Data");
            UseReference("", "System.Collections.Generic");
            UseReference("%MicrosoftNetPath%\\System.XML.XDocument.dll", "");
            UseReference("%MicrosoftNetPath%\\System.XML.ReaderWriter.dll", "");
            UseReference("%MicrosoftNetPath%\\System.Private.XML.dll", "");
            UseReference("%MicrosoftNetPath%\\System.XML.dll", "System.Xml");

            //Foundation
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.NiceLabel");

            UseReference("Cmf.Custom.IKEA.BusinessObjects.CustomWMSMaterialTracker.dll", "Cmf.Custom.IKEA.BusinessObjects");
            UseReference("Cmf.Custom.IKEA.Orchestration.dll", "Cmf.Custom.IKEA.Orchestration.InputObjects");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Exceptions");

            // Newtonsoft
            UseReference("Newtonsoft.Json.dll", "Newtonsoft.Json");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            INiceLabelUtilities nbUtilities = serviceProvider.GetService<INiceLabelUtilities>();
            ILocalizedMessage localizedMessage = serviceProvider.GetService<ILocalizedMessage>();
            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();

            string errorStep = String.Empty;
            try
            {
                if (Input.ContainsKey("IntegrationEntry"))
                {
                    var entityFactory = serviceProvider.GetService<IEntityFactory>();

                    // Get input item
                    IIntegrationEntry integrationEntry = IKEADEEActionUtilities.GetInputItem<IIntegrationEntry>(Input, "IntegrationEntry");

                    XmlDocument xmlMessage = new XmlDocument();
                    xmlMessage.LoadXml(Encoding.UTF8.GetString(integrationEntry.IntegrationMessage.Message));

                    MESNiceLabelCommunication mesNiceLabelCommunication;
                    try
                    {
                        // Deserialize the Xml from the integration entry message
                        mesNiceLabelCommunication = genericUtilities.DeserializeXmlToObject<MESNiceLabelCommunication>(xmlMessage);
                    }
                    catch (Exception exception)
                    {
                        throw ikeaUtilities.LocalizedException(IKEAConstants.CustomNiceLabelInvalidResponseLocalizedMessage, exception.Message);
                    }

                    // Validate if MESWMSCommunication key is present:
                    if (mesNiceLabelCommunication != null)
                    {
                        #region Send message to NiceLabel and validate response
                        if (integrationEntry.MessageType.Equals(IKEAConstants.NiceLabelNotifyTrackInMessageType) || integrationEntry.MessageType.Equals(IKEAConstants.NiceLabelNotifyStopMessageType))
                        {

                            // Extract API and Message from IntegrationEntry message
                            string rawEndpointConfigName = mesNiceLabelCommunication.API;
                            string rawMessage = mesNiceLabelCommunication.Message;

                            // Validate API and rawMessage
                            if (!string.IsNullOrWhiteSpace(rawEndpointConfigName) && !string.IsNullOrWhiteSpace(rawMessage))
                            {
                                string config = IKEAConstants.NiceLabelEndpoint + rawEndpointConfigName;
                                string endPoint = genericUtilities.GetConfigurationValueByPath<string>(config);

                                // Validate if config was successfully extracted
                                if (!string.IsNullOrWhiteSpace(endPoint))
                                {
                                    // Send message to NiceLabel system:
                                    string result = nbUtilities.SendNiceLabelMessage(rawMessage, endPoint);

                                    // Deserialize the response:
                                    NiceLabelIntegrationMessage niceLabelResponse;
                                    try
                                    {
                                        // Get the response object. should be in json format.
                                        niceLabelResponse = JsonConvert.DeserializeObject<NiceLabelIntegrationMessage>(result);
                                    }
                                    catch (Exception exception)
                                    {
                                        throw new IKEAException(IKEAConstants.CustomNiceLabelInvalidResponseLocalizedMessage, exception.Message);
                                    }

                                    if (niceLabelResponse == null)
                                    {
                                        throw new IKEAException(IKEAConstants.CustomWMSDeserializationFailedLocalizedMessage);
                                    }

                                    if (niceLabelResponse.Response == CustomNiceLabelResponseType.Rejected)
                                    {
                                        throw new IKEAException(IKEAConstants.CustomNiceLabelExceptionLocalizedMessage, niceLabelResponse.Response.ToString());
                                    }

                                    // Add the message result to the integration entry:
                                    if (!result.IsNullOrEmpty())
                                    {
                                        Input.Add("Result", result);
                                    }
                                }
                                #endregion
                                else
                                {
                                    throw new IKEAException(IKEAConstants.CustomNiceLabelMissingEndpointConfigLocalizedMessage, config);
                                }
                            }
                            else
                            {
                                throw new IKEAException(IKEAConstants.CustomNiceLabelNoApiMessageFoundLocalizedMessage);
                            }
                        }
                        else if (integrationEntry.MessageType.Equals(IKEAConstants.NiceLabelSSCCInfoMessageType))
                        {
                            CustomNiceLabelMessageInput serviceInput = new CustomNiceLabelMessageInput();
                            try
                            {
                                serviceInput = JsonConvert.DeserializeObject<CustomNiceLabelMessageInput>(mesNiceLabelCommunication.Message);
                            }
                            catch (Exception)
                            {
                                throw new IKEAException(IKEAConstants.CustomNiceLabelDeserializationFailedLocalizedMessage, mesNiceLabelCommunication.Message);
                            }

                            DataSet storedDataSet = nbUtilities.GetNiceLabelMaterialForIntegrationEntry(integrationEntry);
                            if (!storedDataSet.HasData())
                            {
                                throw new IKEAException(IKEAConstants.CustomNiceLabelIntegrationEntryIntegrationEntryNotOnGenericTable, integrationEntry.Name);
                            }

                            IMaterial material = entityFactory.Create<IMaterial>();
                            IResource resource = entityFactory.Create<IResource>();

                            foreach (DataRow row in storedDataSet.Tables[0].Rows)
                            {
                                string materialName = row.GetValue<String>(IKEAConstants.CustomNiceLabelIntegrationEntriesMaterialColumn);
                                material.Name = materialName;
                                string resourceName = row.GetValue<String>(IKEAConstants.CustomNiceLabelIntegrationEntriesResourceColumn);
                                resource.Name = resourceName;
                            }

                            material = ikeaUtilities.RemoveMaterialFromPrintingQueue(resource, out errorStep, sscc: serviceInput.SSCC, materialToBeRetrieved: material);
                            Input.Add("Result", "SSCC " + serviceInput.SSCC + " stored in material " + material.Name);
                        }
                    }
                    else
                    {
                        throw new IKEAException(IKEAConstants.CustomNiceLabelDeserializationFailedLocalizedMessage);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ikeaUtilities.LocalizedException(IKEAConstants.CustomLabelDeadlockLocalizedMessage, errorStep, ex.Message);
            }

            //---End DEE Code---

            return Input;
        }
    }
}
