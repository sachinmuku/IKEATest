﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Extensions;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Threading;

namespace Cmf.Custom.IKEA.Actions.NiceLabel
{
    public class CustomNiceLabelNotifyStop : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text:  Creates an integration entry to send notification of stopped/aborted/completed material
            ///     
            /// Action Groups:   BusinessObjects.Material.SetMainStateModel.Post
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.Material.SetMainStateModel.Post"
            };

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);
            
            if (executionVeridict && Input["StateModel"] == null)
            {
                return false;
            }

            // check state of material - only proceed if the material is aborted or completed
            ICurrentEntityState inputState = IKEADEEActionUtilities.GetInputItem<ICurrentEntityState>(Input, "StateModel");
            
            if (inputState.CurrentState == null || (!inputState.CurrentState.Name.Equals(IKEAConstants.MaterialStateModelAborted) && !inputState.CurrentState.Name.Equals(IKEAConstants.MaterialStateModelCompleted)))
            {
                return false;
            }

            return true;
            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            //System
            UseReference("", "System");
            UseReference("", "System.Data");
            UseReference("", "System.Collections.Generic");
            UseReference("%MicrosoftNetPath%\\System.XML.XDocument.dll", "");
            UseReference("%MicrosoftNetPath%\\System.XML.ReaderWriter.dll", "");
            UseReference("%MicrosoftNetPath%\\System.Private.XML.dll", "");
            UseReference("%MicrosoftNetPath%\\System.XML.dll", "System.Xml");

            //Foundation
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("", "Cmf.Foundation.BusinessObjects.Abstractions");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects");
            UseReference("", "Cmf.Navigo.BusinessObjects.Abstractions");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.NiceLabel");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Extensions");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");


            // Newtonsoft
            UseReference("Newtonsoft.Json.dll", "Newtonsoft.Json");


            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            INiceLabelUtilities nbUtilities = serviceProvider.GetService<INiceLabelUtilities>();
            ILocalizedMessage localizedMessage = serviceProvider.GetService<ILocalizedMessage>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();

            // get input material
            IMaterial inputMaterial = IKEADEEActionUtilities.GetInputItem<IMaterial>(Input, "Material");

            IResource mainResource = inputMaterial.LastProcessedResource;

            if (mainResource == null)
            {
                throw new CmfBaseException(ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomNiceLabelNoResourceAssociatedToMaterial, inputMaterial.Name));
            }

            IResource printingQueueResource = ikeaUtilities.GetAssociatedPrintingQueueResource(mainResource);

            string printingSystem = String.Empty;

            if (printingQueueResource != null)
            {
                printingSystem = printingQueueResource.GetAttributeValueOrDefault<string>(IKEAConstants.CustomResourcePrintingSystemAttribute, true);
            }

            if (!String.IsNullOrEmpty(printingSystem) && printingSystem.Equals(IKEAConstants.NiceLabelSystem))
            {
                string requestStopEndpoint = IKEAConstants.NiceLabelNotifyStopEndpoint;

                inputMaterial.Load();

                // resolve the recipeID from CustomNiceLabelContext Smart Table
                int recipeID;

                DataSet recipeDataSet = nbUtilities.ResolveNiceLabelContextSmartTable(mainResource, inputMaterial.Product);
                if (recipeDataSet.HasData())
                {
                    recipeID = recipeDataSet.Tables[0].Rows[0].Field<int>(IKEAConstants.CustomNiceLabelContextRecipeIDColumn);
                }
                else
                {
                    throw new CmfBaseException(ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomNiceLabelRecipeIDNotConfiguredLocalizedMessage, mainResource.Name, inputMaterial.Product.Name));
                }

                if (inputMaterial.ProductionOrder != null)
                {
                    INiceLabelIntegrationMessage niceLabelIntegrationMessage = new NiceLabelIntegrationMessage()
                    {
                        _Id = Guid.NewGuid().ToString(),
                        MOID = inputMaterial.ProductionOrder.Name,
                        ItemNo = inputMaterial.Product.GetBaseProduct().Name,
                        Workcenter = mainResource.Name,
                        Recipe = recipeID
                    };

                    IIntegrationEntry integrationEntry = nbUtilities.CreateNiceLabelOutgoingIntegrationEntry(niceLabelIntegrationMessage,
                                                                                                requestStopEndpoint,
                                                                                                requestType: IKEAConstants.NiceLabelNotifyStopMessageType,
                                                                                                eventName: IKEAConstants.NiceLabelNotifyStopEventName);
                }
            }

            //---End DEE Code---

            return Input;
        }
    }
}
