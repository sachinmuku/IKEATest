﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Exceptions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessObjects.Cultures;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;

using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using INotification = Cmf.Navigo.BusinessObjects.Abstractions.INotification;

namespace Cmf.Custom.IKEA.Actions.MaintenanceActivityOrders
{
    public class CustomSendMaintenanceManagementNotificationMail : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Creates notifications for the MAOs, when creating AdHocs or when reaching one of the due dates
            /// </summary>
            #endregion

            return IKEADEEActionUtilities.GetInputItem<IMaintenanceActivityOrderCollection>(Input, "MaintenanceActivityOrderCollection") != null
                    || IKEADEEActionUtilities.GetInputItem<IMaintenanceActivityOrder>(Input, Navigo.Common.Constants.MaintenanceActivityOrder) != null;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
     

            //System
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Globalization");
            UseReference("", "System.Text");
            UseReference("", "System");

            //Foundation
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("", "Cmf.Foundation.Common");

            //Navigo
            UseReference("Cmf.Navigo.Common.dll", "Cmf.Navigo.Common");
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Exceptions");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            INiceLabelUtilities nbUtilities = serviceProvider.GetService<INiceLabelUtilities>();
            ILocalizedMessage _localizedMessage = serviceProvider.GetService<ILocalizedMessage>();
            IGenericUtilities _genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();

            string emailDistributionList = null;

            IMaintenanceActivityOrderCollection maos = IKEADEEActionUtilities.GetInputItem<IMaintenanceActivityOrderCollection>(Input, "MaintenanceActivityOrderCollection");
            bool createdAdHockMAOs = !maos.IsNullOrEmpty();

            // If the action isn't coming form the creation of AdHock MAOs
            // then add the MAO in the Input to the collection
            if (!createdAdHockMAOs)
            {
                IMaintenanceActivityOrder mao = IKEADEEActionUtilities.GetInputItem<IMaintenanceActivityOrder>(Input, Navigo.Common.Constants.MaintenanceActivityOrder);

                if (mao != null)
                {
                    maos = entityFactory.CreateCollection<IMaintenanceActivityOrderCollection>();
                    // new MaintenanceActivityOrderCollection();
                    maos.Add(mao);
                }
            }

            if (!maos.IsNullOrEmpty())
            {
                // Create notifications for all the MAOs in the collection
                foreach (var mao in maos)
                {
                    if (mao != null && mao.MaintenancePlanInstance != null)
                    {
                        if (!string.IsNullOrWhiteSpace(mao.MaintenancePlanInstance.DistributionList))
                        {
                            emailDistributionList = mao.MaintenancePlanInstance.DistributionList;
                        }
                        else if (mao.MaintenancePlanInstance.OwnerRole != null)
                        {
                            emailDistributionList = mao.MaintenancePlanInstance.OwnerRole.GetEmailAddressesAsDistributionList(null, true, true);
                        }
                    }

                    // {0} {1} maintenance plan alert
                    string maoStatusMailSubject = ikeaUtilities.GetLocalizedMessage(IKEAConstants.MaoStatusMailSubjectLocalizedMessage, mao.MaintenancePlanInstance.ReferredEntity.EntityType.Name, mao.MaintenancePlanInstance.ReferredEntity.Name);

                    StringBuilder maoMessage = new StringBuilder();

                    string dateChange = string.Empty;
                    string stateNext = string.Empty;
                    string dateNext = string.Empty;
                    string counterNext = string.Empty;

                    if (!createdAdHockMAOs)
                    {
                        if (mao.ScheduleState == MaintenanceScheduleStates.EarlyDue)
                        {
                            stateNext = MaintenanceScheduleStates.Due.ToString();
                            if ((mao.IsUsageBased ?? false) && !(mao.IsTimeBased ?? false))
                            {
                                dateChange = mao.UsageBasedEarlyDueDate.ToString();
                                counterNext = mao.UsageBasedDue.ToString();
                            }
                            else
                            {
                                dateNext = mao.TimeBasedDue.ToString();
                                if (mao.TimeBasedEarlyDueDate == null)
                                {
                                    dateChange = mao.UsageBasedEarlyDueDate.ToString();
                                }
                                else
                                {
                                    dateChange = mao.TimeBasedEarlyDueDate.ToString();
                                }
                            }
                        }
                        else if (mao.ScheduleState == MaintenanceScheduleStates.Due)
                        {

                            stateNext = MaintenanceScheduleStates.LateDue.ToString();
                            if ((mao.IsUsageBased ?? false) && !(mao.IsTimeBased ?? false))
                            {
                                dateChange = mao.UsageBasedDueDate.ToString();
                                counterNext = mao.UsageBasedLateDue.ToString();
                            }
                            else
                            {
                                dateNext = mao.TimeBasedLateDue.ToString();
                                if (mao.TimeBasedDueDate == null)
                                {
                                    dateChange = mao.UsageBasedDueDate.ToString();
                                }
                                else
                                {
                                    dateChange = mao.TimeBasedDueDate.ToString();
                                }
                            }

                        }
                        else if (mao.ScheduleState == MaintenanceScheduleStates.LateDue)
                        {
                            if (mao.TimeBasedLateDueDate == null)
                            {
                                dateChange = mao.UsageBasedLateDueDate.ToString();
                            }
                            else
                            {
                                dateChange = mao.TimeBasedLateDueDate.ToString();
                            }
                        }

                        if (!string.IsNullOrWhiteSpace(dateChange))
                        {
                            dateChange = string.Format("{0} [{1}]", dateChange, TimeZoneInfo.Local.StandardName);
                        }

                        // At {0} the maintenance activity {1} for the {2} {3} has reached the {4} state.
                        maoMessage.Append(ikeaUtilities.GetLocalizedMessage(IKEAConstants.MaoStatusMailTextLocalizedMessage, dateChange,
                                                                                                                            mao.Name,
                                                                                                                            mao.MaintenancePlanInstance.ReferredEntity.EntityType.Name,
                                                                                                                            mao.MaintenancePlanInstance.ReferredEntity.Name,
                                                                                                                            mao.ScheduleState.ToString()));

                        // MaoStatusMailExtraText = "Next state {0} will be reached at {1}"
                        if (mao.ScheduleState != MaintenanceScheduleStates.LateDue)
                        {
                            if (!string.IsNullOrWhiteSpace(dateNext))
                            {
                               // dateNext = string.Format("{0} [{1}]", dateNext, TimeZone.CurrentTimeZone.StandardName);
                                dateNext = string.Format("{0} [{1}]", dateNext, TimeZoneInfo.Local.StandardName);

                                // Next state {0} will be reached at {1}
                                maoMessage.AppendLine(ikeaUtilities.GetLocalizedMessage(IKEAConstants.MaoStatusMailExtraTextTimeBasedLocalizedMessage, stateNext, dateNext));
                            }
                            else
                            {
                                // Next state {0} will be reached when counter reaches {1}.
                                maoMessage.AppendLine(ikeaUtilities.GetLocalizedMessage(IKEAConstants.MaoStatusMailExtraTextUsageBasedLocalizedMessage, stateNext, counterNext));
                            }
                        }
                    }
                    else
                    {
                        //string dueDate = string.Format("{0} [{1}]", mao.ScheduledDate, TimeZone.CurrentTimeZone.StandardName);
                          string dueDate = string.Format("{0} [{1}]", mao.ScheduledDate, TimeZoneInfo.Local.StandardName);
                        maoMessage.Append(ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomAdHocMaoCreatedLocalizedMessage, mao.Type, mao.MaintenancePlanInstance.ReferredEntity.Name, dueDate));
                    }
                    //Validate if Severity exists in config
                    string severity = ikeaUtilities.GetValueFromConfigurationWithPath(IKEAConstants.DefaultNotificationSeverityConfig);

                    if (severity.IsNullOrEmpty())
                    {
                        throw new IKEAException(IKEAConstants.CustomDefaultNotificationSeverityConfigNotDefined, IKEAConstants.DefaultNotificationSeverityConfig);
                    }

                    Cmf.Navigo.BusinessObjects.Abstractions.INotification notification = entityFactory.Create<Cmf.Navigo.BusinessObjects.Abstractions.INotification>();


                    notification.Type = "System";
                    notification.Title = maoStatusMailSubject;
                    notification.Details = maoMessage.ToString();
                    notification.Severity = ikeaUtilities.GetValueFromLookupTable(IKEAConstants.NotificationSeverityLookupTableName, severity, true);
                    notification.AssignmentType = (NotificationAssignmentType)AssignmentType.Role;
                    notification.AssignedToRole = mao.MaintenancePlanInstance.OwnerRole;
                    notification.SendEmailToAssignedParty = false;
                    notification.EmailDistributionList = emailDistributionList;


                    notification.Create();
                }
            }

            Input.Add("Result", "Success");

            
            //---End DEE Code---

            return Input;
        }
    }
}
