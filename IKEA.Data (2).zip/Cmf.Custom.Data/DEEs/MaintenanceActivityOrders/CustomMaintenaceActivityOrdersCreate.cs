﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Custom.IKEA.Common;
using Cmf.Foundation.BusinessOrchestration.Abstractions;
using Cmf.Foundation.BusinessOrchestration.DynamicExecutionEngineManagement.InputObjects;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;

using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.MaintenanceActivityOrders
{
    public class CustomMaintenanceActivityOrdersCreate : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     It will create notifications to all the AdHoc MAOs being created
            /// Action Groups:
            ///     BusinessObjects.MaintenanceActivityCollection.Request.Post
            /// Depends On:
            ///     CustomSendMaintenanceManagementNotificationMail
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.MaintenanceActivityCollection.Request.Post"
            };

            // Only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            if (executionVeridict
                && IKEADEEActionUtilities.GetInputItem<IMaintenanceActivityOrderCollection>(Input, "CreatedMaintenanceActivityOrders") == null)
            {
                executionVeridict = false;
            }

            return executionVeridict;


            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
     

            //System
            UseReference("", "Cmf.Foundation.BusinessOrchestration.Abstractions");
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("", "System");

            //Foundation
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.DynamicExecutionEngineManagement.InputObjects");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.DynamicExecutionEngineManagement");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            var dynamicExecutionEngineOrchestration = serviceProvider.GetService<IDynamicExecutionEngineOrchestration>();

            IMaintenanceActivityOrderCollection maintenanceActivityOrders = IKEADEEActionUtilities.GetInputItem<IMaintenanceActivityOrderCollection>(Input, "CreatedMaintenanceActivityOrders");

            IMaintenanceActivityOrderCollection maoAdhocs = entityFactory.CreateCollection<IMaintenanceActivityOrderCollection>();
                
            maoAdhocs.AddRange(maintenanceActivityOrders.Where(m => m.IsAdhoc.Value).ToList());

            if (!maoAdhocs.IsNullOrEmpty())
            {
                Dictionary<string, object> newInput = new Dictionary<string, object>();

                newInput.Add("MaintenanceActivityOrderCollection", maoAdhocs);

                GetActionByNameInput deeInput = new GetActionByNameInput
                {
                    Name = IKEAConstants.CustomSendMaintenanceManagementNotificationMail
                };

                Cmf.Foundation.Common.Abstractions.IAction action = dynamicExecutionEngineOrchestration.GetActionByName(deeInput).Action;

                ExecuteActionInput execute = new ExecuteActionInput()
                {
                    Action = action,
                    Input = newInput
                };

                dynamicExecutionEngineOrchestration.ExecuteAction(execute);
            }

            
            //---End DEE Code---

            return Input;
        }
    }
}
