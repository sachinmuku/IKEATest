﻿using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.MaintenanceManagement.InputObjects;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Threading;

namespace Cmf.Custom.IKEA.Actions.MaintenanceActivityOrders
{
    public class CustomSetMAOServiceComments : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary Action to prepend to service comments the source of the request
            ///         If there are no service comments defined, fallback to Manual request mode
            ///         
            /// Action Groups: MaintenanceManagement.MaintenanceManagementOrchestration.RequestMaintenanceActivityOrders.Pre
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion


            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "MaintenanceManagement.MaintenanceManagementOrchestration.RequestMaintenanceActivityOrders.Pre"
            };

            // Only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
     

            //System
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("", "System");
            //Navigo
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaintenanceManagement.InputObjects");
            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            INiceLabelUtilities nbUtilities = serviceProvider.GetService<INiceLabelUtilities>();
            ILocalizedMessage _localizedMessage = serviceProvider.GetService<ILocalizedMessage>();
            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            //IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();
            //Get input object
            RequestMaintenanceActivityOrdersInput maoInput = Input["RequestMaintenanceActivityOrdersInput"] as RequestMaintenanceActivityOrdersInput;

            if (string.IsNullOrWhiteSpace(maoInput.ServiceComments))
            {
                // Get Manual MAO request mode from configs
                string manualModeConfig = genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.ManualMaintenanceSource);
                //If there are no service commentd defined, fallback to manual
                //Add Request comment indicating request is manual 
                maoInput.RequestComment = ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomRequestMAORequestComment, manualModeConfig);
            }
            else
            {
                 // Add Request comment setting the Mode to the mode defined on the service comments
                 maoInput.RequestComment = ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomRequestMAORequestComment, maoInput.ServiceComments);
            }

            
            //---End DEE Code---
            return Input;
        }
    }
}
