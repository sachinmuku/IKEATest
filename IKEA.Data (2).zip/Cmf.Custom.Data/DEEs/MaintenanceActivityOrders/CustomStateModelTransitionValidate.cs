﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Exceptions;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.MaintenanceManagement.InputObjects;
using Microsoft.Extensions.DependencyInjection;

using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Threading;

namespace Cmf.Custom.IKEA.Actions.MaintenanceActivityOrders
{
	public class CustomStateModelTransitionValidate : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
		public override bool ValidateAction(Dictionary<string, object> Input)
		{
			//---Start DEE Condition Code---   

			#region Info
			/// <summary>
			/// Summary text
			///     It will create notifications to all the AdHoc MAOs being created
			/// Action Groups:
			///     BusinessObjects.MaintenanceActivityCollection.Request.Post
			/// Depends On:
			///     CustomSendMaintenanceManagementNotificationMail
			/// </summary>
			#endregion

			// List of eligible action groups (configuration sanity check)
			Collection<string> EligibleActionGroups = new Collection<string>()
						{
								"MaintenanceManagement.MaintenanceManagementOrchestration.BeginMaintenanceActivityOrders.Pre",
								"MaintenanceManagement.MaintenanceManagementOrchestration.CompleteMaintenanceActivityOrders.Pre"
						};

			// Only proceed if within expected triggers (action groups)
			bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

			if (executionVeridict
					&& IKEADEEActionUtilities.GetInputItem<BeginMaintenanceActivityOrdersInput>(Input, "BeginMaintenanceActivityOrdersInput") == null
					&& IKEADEEActionUtilities.GetInputItem<CompleteMaintenanceActivityOrdersInput>(Input, "CompleteMaintenanceActivityOrdersInput") == null
					)
			{
				executionVeridict = false;
			}

			return executionVeridict;


			//---End DEE Condition Code---
		}

		public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
		{
			//---Start DEE Code---
UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");

			//System
			UseReference("", "System.Linq");
			UseReference("", "System.Collections.Generic");
			UseReference("", "System.Collections.ObjectModel");
			UseReference("", "System");
			UseReference("", "System.Data");
			UseReference("", "System.Text");

			//Foundation
			UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.GenericServiceManagement.InputObjects");
			UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration");
			UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
			UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects.QueryObject");
            UseReference("", "Cmf.Foundation.BusinessObjects.Abstractions");

            //Navigo
            UseReference("", "Cmf.Foundation.BusinessObjects.SmartTables");
			UseReference("", "Cmf.Foundation.BusinessObjects.SmartTables");
			UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
			UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaintenanceManagement.InputObjects");
            UseReference("", "Cmf.Navigo.BusinessObjects.Abstractions");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

			//Custom
			UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Exceptions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
			UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.ERP.Maintenance");
			UseReference("", "Cmf.Custom.IKEA.Orchestration.InputObjects");
			UseReference("", "Cmf.Custom.IKEA.Orchestration.OutputObjects");
			UseReference("Cmf.Custom.IKEA.Orchestration.dll", "Cmf.Custom.IKEA.Orchestration");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            INiceLabelUtilities nbUtilities = serviceProvider.GetService<INiceLabelUtilities>();
            ILocalizedMessage _localizedMessage = serviceProvider.GetService<ILocalizedMessage>();
            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();

            DeeContext currentContext = deeContextUtilities.SetCurrentServiceContext("CustomMaintenanceHandleActivityProgress");

			bool blockOEEStateFlag = false;

            if (currentContext != null)
            {
                switch (currentContext.MethodName)
                {
                    case "BeginMaintenanceActivityOrders":
                        {
                            blockOEEStateFlag = true;
                            BeginMaintenanceActivityOrdersInput beginMAOsInput = IKEADEEActionUtilities.GetInputItem<BeginMaintenanceActivityOrdersInput>(Input, "BeginMaintenanceActivityOrdersInput");

                            if (beginMAOsInput != null && !beginMAOsInput.MaintenanceActivityOrders.IsNullOrEmpty())
                            {
                                IStateModelTransition stateModelTransition = beginMAOsInput.StateModelTransition ?? null;

                                try
                                {
                                    //Input MAOS
                                    IMaintenanceActivityOrderCollection beginMAOs = beginMAOsInput.MaintenanceActivityOrders;

                                    //Necessary objects
                                    IMaintenancePlanInstanceCollection mpiCollection = entityFactory.CreateCollection<IMaintenancePlanInstanceCollection>();
                                    IResourceCollection resourceCollection = entityFactory.CreateCollection<IResourceCollection>();
                                    IResource resource = entityFactory.Create<IResource>();
                                    IMaintenanceActivityOrder mao = entityFactory.Create<IMaintenanceActivityOrder>();

                                    //Load MAOs and fill MPIs
                                    if (!beginMAOs.IsNullOrEmpty())
                                    {
                                        beginMAOs.Load();
                                        beginMAOs.LoadRelations();
                                        mpiCollection.AddRange(beginMAOs.Where(e => e.MaintenancePlanInstance != null).Select(x => x.MaintenancePlanInstance).ToList());
                                    }

                                    //Load MPIs and fill Resources
                                    if (mpiCollection.Any())
                                    {
                                        mpiCollection.Load();
                                        mpiCollection.LoadRelations();
                                        resourceCollection.AddRange(mpiCollection.Where(e => e.Resource != null).Select(x => x.Resource).ToList());
                                    }

                                    //Load Resources and fill single objects (resource and mao)
                                    if (resourceCollection.Any())
                                    {
                                        resourceCollection.Load();

                                        //Logic for 1 MAO - assumption given by IKEA
                                        resource = resourceCollection.FirstOrDefault();
                                        mao = beginMAOs.Where(e =>
                                                e.MaintenancePlanInstance.Equals(
                                                    mpiCollection.Where(
                                                        p => p.Resource.Equals(resource)
                                                    ).FirstOrDefault()
                                                )
                                            ).FirstOrDefault();
                                    }

                                    if (!string.IsNullOrEmpty(resource.Name) && !string.IsNullOrEmpty(mao.Name))
                                    {
                                        //Verify if any other MAO active
                                        IMaintenanceActivityOrderCollection maoCollection = ikeaUtilities.GetOtherMAOsActiveForResource(mao, resource);
                                        List<(string, string)> tupleList = new List<(string, string)>();

                                        if (!maoCollection.IsNullOrEmpty())
                                        {
                                            foreach (IMaintenanceActivityOrder maoInternal in maoCollection.Where(e => e != null && !e.Type.IsNullOrEmpty()))
                                            {
                                                //Verify if any other MAO active are blocking or to block the state
                                                tupleList = ikeaUtilities.ResolveOEEStateAndReasonWhenMAORequired(resource, maoInternal.Type);
                                                if (tupleList != null && !tupleList.FirstOrDefault().Item1.IsNullOrEmpty() && !tupleList.FirstOrDefault().Item2.IsNullOrEmpty())
                                                {
                                                    break;
                                                }
                                            }
                                        }
                                        
                                        if (tupleList == null || tupleList.FirstOrDefault().Item1.IsNullOrEmpty() || tupleList.FirstOrDefault().Item2.IsNullOrEmpty())
                                        {
                                            //If not, resolve for this one
                                            tupleList = ikeaUtilities.ResolveOEEStateAndReasonWhenMAORequired(resource, mao.Type);
                                        }

                                        //Get topmost
                                        IResource topmost = resource.GetTopMostResource();

                                        //If MAO is configured to block state
                                        if (tupleList != null && !tupleList.FirstOrDefault().Item1.IsNullOrEmpty() && !tupleList.FirstOrDefault().Item2.IsNullOrEmpty())
                                        {
                                            //and transition is null + is line resource - throw exception
                                            if (stateModelTransition == null && resource.Equals(topmost))
                                            {
                                                throw new IKEAException(IKEAConstants.CustomBlockOEEStateChangeOnBeginLocalizedMessage, resource.Name);
                                            }

                                            if (!resource.Equals(topmost))
                                            {
                                                ikeaUtilities.SetStateOnResource(topmost, tupleList.FirstOrDefault().Item1, tupleList.FirstOrDefault().Item2, false);
                                            }
                                            IAutomationControllerInstance controllerInstance = topmost.GetAutomationControllerInstance();
                                            Dictionary<string, object> resourceDetails = new Dictionary<string, object>
                                            {
                                                    { IKEAConstants.AutomationRequestBlockOEEStateField, blockOEEStateFlag }
                                            };
                                            try
                                            {
                                                _ = genericUtilities.RequestFromIoT<Dictionary<string,string>>(controllerInstance, IKEAConstants.AutomationRequestTypeBlockOEEStateCalculation, resourceDetails.ToJsonString());
                                            }
                                            catch (Exception)
                                            {
                                                throw;
                                            }
                                        }

                                    }
                                }
                                catch (Exception exception)
                                {
                                    throw new Exception(exception.Message);
                                }
                            }
                            break;
                        }
                    case "CompleteMaintenanceActivityOrders":
                        {
                            blockOEEStateFlag = false;
                            CompleteMaintenanceActivityOrdersInput completeMAOsInput = IKEADEEActionUtilities.GetInputItem<CompleteMaintenanceActivityOrdersInput>(Input, "CompleteMaintenanceActivityOrdersInput");

                            if (completeMAOsInput != null && !completeMAOsInput.MaintenanceActivityOrders.IsNullOrEmpty())
                            {
                                IStateModelTransition stateModelTransition = completeMAOsInput.StateModelTransition;

                                try
                                {
                                    //Input MAOS
                                    IMaintenanceActivityOrderCollection completeMAOs = completeMAOsInput.MaintenanceActivityOrders;

                                    //Necessary objects
                                    IMaintenancePlanInstanceCollection mpiCollection = entityFactory.CreateCollection<IMaintenancePlanInstanceCollection>();
                                    IResourceCollection resourceCollection = entityFactory.CreateCollection<IResourceCollection>();
                                    IResource resource = entityFactory.Create<IResource>();
                                    IMaintenanceActivityOrder mao = entityFactory.Create<IMaintenanceActivityOrder>();
                                    Dictionary<string, string> outputIoT = new Dictionary<string, string>();

                                    //Load MAOs and fill MPIs
                                    if (!completeMAOs.IsNullOrEmpty())
                                    {
                                        completeMAOs.Load();
                                        completeMAOs.LoadRelations();
                                        mpiCollection.AddRange(completeMAOs.Where(e => e.MaintenancePlanInstance != null).Select(x => x.MaintenancePlanInstance).ToList());
                                    }

                                    //Load MPIs and fill Resources
                                    if (mpiCollection.Any())
                                    {
                                        mpiCollection.Load();
                                        mpiCollection.LoadRelations();
                                        resourceCollection.AddRange(mpiCollection.Where(e => e.Resource != null).Select(x => x.Resource).ToList());
                                    }

                                    //Load Resources and fill single objects (resource and mao)
                                    if (resourceCollection.Any())
                                    {
                                        resourceCollection.Load();

                                        //Logic for 1 MAO - assumption given by IKEA
                                        resource = resourceCollection.FirstOrDefault();
                                        mao = completeMAOs.Where(e =>
                                                e.MaintenancePlanInstance.Equals(
                                                    mpiCollection.Where(
                                                        p => p.Resource.Equals(resource)
                                                    ).FirstOrDefault()
                                                )
                                            ).FirstOrDefault();
                                    }

                                    //Get topmost
                                    IResource topmost = resource.GetTopMostResource();
                                    topmost.LoadAttribute(IKEAConstants.CustomMAORequired);

                                    if (!string.IsNullOrEmpty(resource.Name) && !string.IsNullOrEmpty(mao.Name))
                                    {
                                        //Verify if any other MAO active
                                        IMaintenanceActivityOrderCollection maoCollection = ikeaUtilities.GetOtherMAOsActiveForResource(mao, resource);
                                        List<(string, string)> tupleList = new List<(string, string)>();

                                        if (!maoCollection.IsNullOrEmpty())
                                        {
                                            foreach (MaintenanceActivityOrder maoInternal in maoCollection.Where(e => e!= null && !e.Type.IsNullOrEmpty()))
                                            {
                                                //Verify if any other MAO active are blocking or to block the state
                                                tupleList = ikeaUtilities.ResolveOEEStateAndReasonWhenMAORequired(resource, maoInternal.Type);
                                                if (tupleList != null && !tupleList.FirstOrDefault().Item1.IsNullOrEmpty() && !tupleList.FirstOrDefault().Item2.IsNullOrEmpty())
                                                {
                                                    outputIoT = genericUtilities.DeserializeObject("{ \"State\": \"" + tupleList.FirstOrDefault().Item1 + "\"," +
                                                                                                        " \"Reason\": \"" + tupleList.FirstOrDefault().Item2 + "\"" +
                                                                                                        "}");
                                                    break;
                                                }
                                            }
                                        }

                                        if (topmost.Attributes.ContainsKey(IKEAConstants.CustomMAORequired) && topmost.Attributes[IKEAConstants.CustomMAORequired] != null && Convert.ToBoolean(topmost.Attributes[IKEAConstants.CustomMAORequired]))
                                        {

                                            if (resource.Equals(topmost) && stateModelTransition == null)
                                            {
                                                throw new IKEAException(IKEAConstants.CustomBlockOEEStateChangeOnCompleteLocalizedMessage, resource.Name);
                                            }

                                            //If Nothing from other MAOs ask IoT to recalculate
                                            if (!outputIoT.Any())
                                            {
                                                mao.Load();
                                                mao.LoadAttribute(IKEAConstants.CustomMaoStartedByOperatorAttribute);
                                                if (mao.Attributes.TryGetValue(IKEAConstants.CustomMaoStartedByOperatorAttribute, out object isStartedByOperator))
                                                {
                                                    blockOEEStateFlag = (bool)isStartedByOperator;
                                                }
                                                else
                                                {
                                                    blockOEEStateFlag = false;
                                                }

                                                // request only if OEE state flag is set to true on controller
                                                if (blockOEEStateFlag)
                                                {
                                                    IAutomationControllerInstance controllerInstance = topmost.GetAutomationControllerInstance();
                                                    Dictionary<string, object> resourceDetails = new Dictionary<string, object>
                                                    {
                                                            { IKEAConstants.AutomationRequestBlockOEEStateField, false }
                                                    };
                                                    try
                                                    {
                                                        _ = genericUtilities.RequestFromIoT<Dictionary<string, string>>(controllerInstance, IKEAConstants.AutomationRequestTypeBlockOEEStateCalculation, resourceDetails.ToJsonString());
                                                    }
                                                    catch (Exception)
                                                    {
                                                        throw;
                                                    }
                                                    try
                                                    {
                                                        resourceDetails = new Dictionary<string, object>
                                                    {
                                                            { IKEAConstants.AutomationRequestResourceName, topmost.Name },
                                                    };
                                                        outputIoT = genericUtilities.RequestFromIoT<Dictionary<string, string>>(controllerInstance, IKEAConstants.AutomationRequestTypeCalculateOEEStateAndReason, resourceDetails.ToJsonString());
                                                    }
                                                    catch (Exception)
                                                    {
                                                        throw;
                                                    }
                                                }
                                                
                                            }

                                            //If is not line resource and any output from IoT or Previous MAOs, set state on line resource
                                            if (!resource.Equals(topmost) && outputIoT.Any())
                                            {
                                                ikeaUtilities.SetStateOnResource(topmost, outputIoT[IKEAConstants.OEEStateToChangeOnResource], outputIoT[IKEAConstants.OEEStateReasonToChangeOnResource], false);
                                            }
                                        }
                                    }
                                }
                                catch (Exception)
                                {
                                    throw;
                                }
                            }
                            break;
                        }
                    default:
                        {
                            break;
                        }
                }
            }

            

            //---End DEE Code---
            return Input;
		}
	}
}
