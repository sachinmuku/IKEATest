﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Exceptions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessObjects.Cultures;
using Cmf.Foundation.BusinessOrchestration.TableManagement.InputObjects;
using Cmf.Foundation.Common;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Threading;

namespace Cmf.Custom.IKEA.Actions.GenericTables
{
    public class CustomPreventMixingUnitsConfiguration : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override Boolean ValidateAction(Dictionary<string, Object> Input)
        {
            //---Start DEE Condition Code---  

            #region Info
            /// <summary>
            /// Summary text
            ///     Validates if the user does not try to mix length units and Weight
            /// Action Groups:
            ///     TableManagement.TableManagementOrchestration.FullUpdateGenericTableData.Pre
            ///     TableManagement.TableManagementOrchestration.InsertOrUpdateGenericTableRows.Pre
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "TableManagement.TableManagementOrchestration.FullUpdateGenericTableData.Pre",
                "TableManagement.TableManagementOrchestration.InsertOrUpdateGenericTableRows.Pre"
            };

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);
            INgpDataSet rowsToAddOrUpdate = null;
            IGenericTable genericTable = null;

            if (executionVeridict)
            {
                if (Input.ContainsKey("FullUpdateGenericTableDataInput"))
                {
                    FullUpdateGenericTableDataInput input = IKEADEEActionUtilities.GetInputItem<FullUpdateGenericTableDataInput>(Input, "FullUpdateGenericTableDataInput");
                    if (input != null)
                    {
                        rowsToAddOrUpdate = input.RowsToAddOrUpdate;
                        genericTable = input.GenericTable;
                    }
                }
                else if (Input.ContainsKey("InsertOrUpdateGenericTableRowsInput"))
                {
                    InsertOrUpdateGenericTableRowsInput input = IKEADEEActionUtilities.GetInputItem<InsertOrUpdateGenericTableRowsInput>(Input, "InsertOrUpdateGenericTableRowsInput");
                    if (input != null)
                    {
                        rowsToAddOrUpdate = input.Table;
                        genericTable = input.GenericTable;
                    }
                }
            }

            if (executionVeridict && (rowsToAddOrUpdate == null || genericTable == null || !genericTable.Name.CompareStrings(IKEAConstants.CustomUnitDimensions)))
            {
                // execute only for Add or Update rows in CustomManualDataPostingNotifications generic table
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, Object> EvaluateRule(Dictionary<string, Object> Input)
        {
            //---Start DEE Code---



            UseReference("", "System");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("%MicrosoftNetPath%\\System.Data.dll", "System.Data");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
             UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Exceptions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects.GenericTables");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.TableManagement.InputObjects");
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];

            ILocalizedMessage _localizedMessage = serviceProvider.GetService<ILocalizedMessage>();


            INgpDataSet ngpDataSet = null;
            INgpDataSet ngpDataSetRemove = null;

            if (Input.ContainsKey("FullUpdateGenericTableDataInput"))
            {
                FullUpdateGenericTableDataInput input = IKEADEEActionUtilities.GetInputItem<FullUpdateGenericTableDataInput>(Input, "FullUpdateGenericTableDataInput");
                ngpDataSet = input.RowsToAddOrUpdate;
                ngpDataSetRemove = input.RowsToRemove;
            }
            else if (Input.ContainsKey("InsertOrUpdateGenericTableRowsInput"))
            {
                InsertOrUpdateGenericTableRowsInput input = IKEADEEActionUtilities.GetInputItem<InsertOrUpdateGenericTableRowsInput>(Input, "InsertOrUpdateGenericTableRowsInput");
                ngpDataSet = input.Table;
            }

            //throw new CmfBaseException(ngpDataSet.ToString());

            DataSet dataSet = NgpDataSet.ToDataSet(ngpDataSet);
            if (dataSet.HasData())
            {

                foreach (DataRow row in dataSet.Tables[0].Rows)
                {
                    if ((Boolean.Parse(row[IKEAConstants.CustomMaterialLengthAttribute].ToString())
                        || Boolean.Parse(row[IKEAConstants.CustomMaterialWidthAttribute].ToString())
                        || Boolean.Parse(row[IKEAConstants.CustomMaterialThicknessAttribute].ToString())
                        ) && Boolean.Parse(row[IKEAConstants.CustomMaterialWeightAttribute].ToString()))
                        throw new IKEAException(IKEAConstants.CustomGenericTableMixingUnitsNotAllowedLocalizedMessage);
                }
            }

            

            //---End DEE Code---
            return Input;
        }


    }
}