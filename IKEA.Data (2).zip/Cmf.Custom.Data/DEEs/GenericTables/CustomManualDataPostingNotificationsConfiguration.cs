﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Exceptions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessOrchestration.TableManagement.InputObjects;
using Cmf.Foundation.Common;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;

using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Threading;

namespace Cmf.Custom.IKEA.Actions.GenericTables
{
    public class CustomManualDataPostingNotificationsConfiguration : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override Boolean ValidateAction(Dictionary<string, Object> Input)
        {
            //---Start DEE Condition Code---  

            #region Info
            /// <summary>
            /// Summary text
            ///     Validates if Chart, LogicalChart or Parameter are filled. Ate least one of them must exist.
            ///     Also fills in the Key column 'ConfigurationUID' of the table (not used by the user or MES with a unique ID.)
            /// Action Groups:
            ///     TableManagement.TableManagementOrchestration.FullUpdateGenericTableData.Pre
            ///     TableManagement.TableManagementOrchestration.InsertOrUpdateGenericTableRows.Pre
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "TableManagement.TableManagementOrchestration.FullUpdateGenericTableData.Pre",
                "TableManagement.TableManagementOrchestration.InsertOrUpdateGenericTableRows.Pre"
            };

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);
            INgpDataSet rowsToAddOrUpdate = null;
            IGenericTable genericTable = null;

            if (executionVeridict)
            {
                if (Input.ContainsKey("FullUpdateGenericTableDataInput"))
                {
                    FullUpdateGenericTableDataInput input = IKEADEEActionUtilities.GetInputItem<FullUpdateGenericTableDataInput>(Input, "FullUpdateGenericTableDataInput");
                    if (input != null)
                    {
                        rowsToAddOrUpdate = input.RowsToAddOrUpdate;
                        genericTable = input.GenericTable;
                    }
                }
                else if (Input.ContainsKey("InsertOrUpdateGenericTableRowsInput"))
                {
                    InsertOrUpdateGenericTableRowsInput input = IKEADEEActionUtilities.GetInputItem<InsertOrUpdateGenericTableRowsInput>(Input, "InsertOrUpdateGenericTableRowsInput");
                    if (input != null)
                    {
                        rowsToAddOrUpdate = input.Table;
                        genericTable = input.GenericTable;
                    }
                }
            }

            if (executionVeridict && (rowsToAddOrUpdate == null || genericTable == null || !genericTable.Name.CompareStrings(IKEAConstants.CustomManualDataPostingNotifications)))
            {
                // execute only for Add or Update rows in CustomManualDataPostingNotifications generic table
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, Object> EvaluateRule(Dictionary<string, Object> Input)
        {
            //---Start DEE Code---


            //System
            UseReference("", "System");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("%MicrosoftNetPath%\\System.Data.dll", "System.Data");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Exceptions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");

            //Foundation
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects.GenericTables");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.TableManagement.InputObjects");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
              UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            INiceLabelUtilities nbUtilities = serviceProvider.GetService<INiceLabelUtilities>();
            ILocalizedMessage _localizedMessage = serviceProvider.GetService<ILocalizedMessage>();
            IGenericUtilities _genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();

            INgpDataSet ngpDataSet = null;
            INgpDataSet ngpDataSetRemove = null;

            if (Input.ContainsKey("FullUpdateGenericTableDataInput"))
            {
                FullUpdateGenericTableDataInput input = IKEADEEActionUtilities.GetInputItem<FullUpdateGenericTableDataInput>(Input, "FullUpdateGenericTableDataInput");
                ngpDataSet = input.RowsToAddOrUpdate;
                ngpDataSetRemove = input.RowsToRemove;
            }
            else if (Input.ContainsKey("InsertOrUpdateGenericTableRowsInput"))
            {
                InsertOrUpdateGenericTableRowsInput input = IKEADEEActionUtilities.GetInputItem<InsertOrUpdateGenericTableRowsInput>(Input, "InsertOrUpdateGenericTableRowsInput");
                ngpDataSet = input.Table;
            }

            DataSet dataSet = NgpDataSet.ToDataSet(ngpDataSet);
            if (dataSet.HasData())
            {

                // Because the key column of the generic table is not used, it is being hidden by the DEE CustomManualDataPostingNotificationsConfHideColumn.
                // It must be added to the dataset to be filled with a dummy unique value:
                string dummyKeyColumnName = "ConfigurationUID";
                if (dataSet.Tables[0].Columns.IndexOf(dummyKeyColumnName) < 0)
                {
                    dataSet.Tables[0].Columns.Add(dummyKeyColumnName, typeof(string));
                }

                int rowCounter = 0;

                #region Collect all data table rows from the Generic Table not being updated right now
                HashSet<long> excludeRowIds = new HashSet<long>();

                string idColumnName = IKEAConstants.CustomManualDataPostingNotifications + "Id";

                foreach (DataRow row in dataSet.Tables[0].Rows)
                {
                    long rowId;
                    if (row.Table.Columns.Contains(idColumnName) && long.TryParse(row[idColumnName].ToString(), out rowId) && rowId > 0)
                    {
                        excludeRowIds.Add(rowId);
                    }
                }

                // If when calling this service, we are removing any rows, then we also want to exclude them from our validation
                if (ngpDataSetRemove != null)
                {
                    DataSet dataSetRemove = NgpDataSet.ToDataSet(ngpDataSet);

                    if (dataSetRemove.HasData())
                    {
                        foreach (DataRow row in dataSet.Tables[0].Rows)
                        {
                            long rowId;

                            if (row.Table.Columns.Contains(idColumnName) && long.TryParse(row[idColumnName].ToString(), out rowId) && rowId > 0)
                            {
                                excludeRowIds.Add(rowId);
                            }
                        }
                    }
                }

                List<CustomDataPostingNotifications> manualDataPostingNotifications = ikeaUtilities.GetManualDataPostingNotifications(excludeRows: excludeRowIds);

                Dictionary<string, CustomDataPostingNotifications> existingRelatedChartNames = new Dictionary<string, CustomDataPostingNotifications>();

                foreach (CustomDataPostingNotifications manualDataPostingNotification in manualDataPostingNotifications)
                {
                    ILogicalChartCollection existingLogicalCharts = ikeaUtilities.GetAllRelatedLogicalCharts(new List<CustomDataPostingNotifications>() { manualDataPostingNotification }, true);

                    foreach (ILogicalChart logicalChart in existingLogicalCharts)
                    {
                        if (!existingRelatedChartNames.ContainsKey(logicalChart.Name))
                        {
                            existingRelatedChartNames.Add(logicalChart.Name, manualDataPostingNotification);
                        }
                    }
                }

                #endregion

                foreach (DataRow row in dataSet.Tables[0].Rows)
                {

                    // Update the key column with a unique id (DateTime and row counter):
                    row[dummyKeyColumnName] = DateTime.Now.ToString($"yyyyMMddHHmmssFFF.{rowCounter++}");

                    // Check if at least one of the required settings are specified:
                    string logicalChartName = row.GetValue<string>("LogicalChart");
                    string chartName = row.GetValue<string>("Chart");
                    string parameterName = row.GetValue<string>("Parameter");
                    if (string.IsNullOrEmpty(logicalChartName) && string.IsNullOrEmpty(chartName) && string.IsNullOrEmpty(parameterName))
                    {
                        throw new IKEAException(IKEAConstants.CustomGenericTableMissingValueLocalizedMessage);
                    }


                    // Gets all the LogicalCharts that are present in the new or updated rows:
                    ILogicalChartCollection newOrUpdatedRowsLogicalCharts = ikeaUtilities.GetAllRelatedLogicalCharts(logicalChartName.IsNullOrEmpty() ? null : new List<string>() { logicalChartName },
                                                                                                                    chartName.IsNullOrEmpty() ? null : new List<string>() { chartName },
                                                                                                                    parameterName.IsNullOrEmpty() ? null : new List<string>() { parameterName }, true);

                    // Finds the first logical chart associated with this row we are editing/inserting, that was already associated with any other row
                    ILogicalChart insersectingLogicalChart = newOrUpdatedRowsLogicalCharts.FirstOrDefault(newLogicalChart => existingRelatedChartNames.ContainsKey(newLogicalChart.Name));

                    if (insersectingLogicalChart != null)
                    {
                        CustomDataPostingNotifications manualDataPostingNotification = existingRelatedChartNames[insersectingLogicalChart.Name];

                        // Formatting the entry of user
                        string[] entries = new string[]{
                                                        !String.IsNullOrWhiteSpace(logicalChartName)? "LogicalChart : " + logicalChartName : String.Empty,
                                                        !String.IsNullOrWhiteSpace(chartName)? "Chart : " + chartName:String.Empty,
                                                        !String.IsNullOrWhiteSpace(parameterName)? "Parameter : " + parameterName : String.Empty };

                        string result = String.Join(", ", entries.Where(s => !string.IsNullOrEmpty(s)));

                        // Formatting the existing record
                        string existingLogicalChartName = manualDataPostingNotification.LogicalChartName;
                        string existingChartName = manualDataPostingNotification.ChartName;
                        string existingParameterName = manualDataPostingNotification.ParameterName;

                        string[] existingEntries = new string[]{
                                                            !String.IsNullOrWhiteSpace(existingLogicalChartName)? "LogicalChart : " + existingLogicalChartName : String.Empty,
                                                            !String.IsNullOrWhiteSpace(existingChartName)? "Chart : " + existingChartName : String.Empty,
                                                            !String.IsNullOrWhiteSpace(existingParameterName)? "Parameter : " + existingParameterName : String.Empty};

                        string existing = String.Join(", ", existingEntries.Where(s => !string.IsNullOrEmpty(s)));

                        throw new IKEAException(IKEAConstants.CustomGenericTableAlreadyExistingConfigurationLocalizedMessage, result, existing);
                    }
                    else
                    {
                        // Create a dummy representation of this row to associated with all of it's logical chart names
                        // So that any subsequent validations of rows can construct their error messages in case any of them conflict with this row
                        CustomDataPostingNotifications manualDataPostingNotification = new CustomDataPostingNotifications {
                            LogicalChartName = logicalChartName,
                            ChartName = chartName,
                            ParameterName = parameterName,
                        };

                        // If the row we are inserting/updating is valid, then add all of its related logical charts to our
                        // internal set, so that any subsequent rows we try to validate also check against them
                        foreach (ILogicalChart newLogicalChart in newOrUpdatedRowsLogicalCharts)
                        {
                            existingRelatedChartNames.Add(newLogicalChart.Name, manualDataPostingNotification);
                        }
                    }
                }

                // Update the rows collection with the key dummy column:
                if (Input.ContainsKey("FullUpdateGenericTableDataInput"))
                {
                    FullUpdateGenericTableDataInput input = IKEADEEActionUtilities.GetInputItem<FullUpdateGenericTableDataInput>(Input, "FullUpdateGenericTableDataInput");
                    input.RowsToAddOrUpdate = NgpDataSet.FromDataSet(dataSet);
                }
                else if (Input.ContainsKey("InsertOrUpdateGenericTableRowsInput"))
                {
                    InsertOrUpdateGenericTableRowsInput input = IKEADEEActionUtilities.GetInputItem<InsertOrUpdateGenericTableRowsInput>(Input, "InsertOrUpdateGenericTableRowsInput");
                    input.Table = NgpDataSet.FromDataSet(dataSet);
                }
            }

            

            //---End DEE Code---
            return Input;
        }


    }
}