﻿using Cmf.Custom.IKEA.Common;
using Cmf.Foundation.BusinessObjects.GenericTables;
using Cmf.Foundation.BusinessOrchestration.TableManagement.InputObjects;
using Cmf.Foundation.BusinessOrchestration.TableManagement.OutputObjects;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using Cmf.Foundation.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Actions.GenericTables
{
    public class CustomManualDataPostingNotificationConfHideColumn : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override Boolean ValidateAction(Dictionary<string, Object> Input)
        {
            //---Start DEE Condition Code---  

            #region Info
            /// <summary>
            /// Summary text
            ///     No keys could be created on the user columns because they can not be unique and/or mandatory.
            ///     So a Dummy key column was created but it is not used.
            ///     This DEE hides the dummy key column 'ConfigurationUID' so it will not be seen in the GUI.
            /// Action Groups:
            ///     TableManagement.TableManagementOrchestration.GetGenericTableWithFilter.Post
            ///     TableManagement.TableManagementOrchestration.GetGenericTable.Post
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "TableManagement.TableManagementOrchestration.GetGenericTableWithFilter.Post",
                "TableManagement.TableManagementOrchestration.GetGenericTable.Post"
            };

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            var getGenericTableWithFilterInput = IKEADEEActionUtilities.GetInputItem<GetGenericTableWithFilterInput>(Input, "GetGenericTableWithFilterInput");
            var getGenericTableWithFilterOutput = IKEADEEActionUtilities.GetInputItem<GetGenericTableWithFilterOutput>(Input, "GetGenericTableWithFilterOutput");
            var getGenericTableByIdOutput = IKEADEEActionUtilities.GetInputItem<GetGenericTableByIdOutput>(Input, "GetGenericTableByIdOutput");

            if (executionVeridict && getGenericTableWithFilterInput == null &&
                                     getGenericTableWithFilterOutput == null &&
                                     getGenericTableByIdOutput == null)
            {
                executionVeridict = false;
            }

            if (executionVeridict)
            {
                string tableName = "";
                if (getGenericTableWithFilterInput != null)
                {
                    tableName = getGenericTableWithFilterInput.GenericTable.Name;
                }
                else if (getGenericTableWithFilterOutput != null)
                {
                    tableName = getGenericTableWithFilterOutput.GenericTable.Name;
                }
                else if (getGenericTableByIdOutput != null)
                {
                    tableName = getGenericTableByIdOutput.GenericTable.Name;
                }

                // Check if this is the generic table 'CustomManualDataPostingNotifications'
                if (!tableName.CompareStrings(IKEAConstants.CustomManualDataPostingNotifications))
                {
                    executionVeridict = false;
                }
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, Object> EvaluateRule(Dictionary<string, Object> Input)
        {
            //---Start DEE Code---
UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.TableManagement.InputObjects");
UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.TableManagement.OutputObjects");
UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects.GenericTables");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");

            List<string> columnsToHide = new List<string>
            {
                "ConfigurationUID"
            };

            var inputfil = IKEADEEActionUtilities.GetInputItem<GetGenericTableWithFilterInput>(Input, "GetGenericTableWithFilterInput");
            if (inputfil != null)
            {
                IGenericTablePropertiesCollection props = new GenericTablePropertiesCollection();
                props.AddRange(inputfil.GenericTable.GenericTableProperties.Where(x => !columnsToHide.Contains(x.Name)));

                inputfil.GenericTable.GenericTableProperties = new GenericTablePropertiesCollection();
                inputfil.GenericTable.GenericTableProperties.AddRange(props);
            }


            var outputfil = IKEADEEActionUtilities.GetInputItem<GetGenericTableWithFilterOutput>(Input, "GetGenericTableWithFilterOutput");
            if (outputfil != null)
            {
                IGenericTablePropertiesCollection props = new GenericTablePropertiesCollection();
                props.AddRange(outputfil.GenericTable.GenericTableProperties.Where(x => !columnsToHide.Contains(x.Name)));

                outputfil.GenericTable.GenericTableProperties = new GenericTablePropertiesCollection();
                outputfil.GenericTable.GenericTableProperties.AddRange(props);
            }


            var output = IKEADEEActionUtilities.GetInputItem<GetGenericTableByIdOutput>(Input, "GetGenericTableByIdOutput");
            if (output != null)
            {
                IGenericTablePropertiesCollection props = new GenericTablePropertiesCollection();
                props.AddRange(output.GenericTable.GenericTableProperties.Where(x => !columnsToHide.Contains(x.Name)));

                output.GenericTable.GenericTableProperties = new GenericTablePropertiesCollection();
                output.GenericTable.GenericTableProperties.AddRange(props);
            }

         
            //---End DEE Code---
            return Input;
        }


    }
}