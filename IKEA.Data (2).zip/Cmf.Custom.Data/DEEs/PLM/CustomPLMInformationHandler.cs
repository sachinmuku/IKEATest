﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Exceptions;
using Cmf.Custom.IKEA.Common.PLM;
using Cmf.Custom.IKEA.Common.PLM.Communication;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Foundation.Configuration;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;

using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;

namespace Cmf.Custom.IKEA.Actions.PLM
{
    public class CustomPLMInformationHandler : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Action To Handle PLM Message of type ProcessItemMaster
            /// </summary>
            #endregion
            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();

            bool executeAction = false;

            if (Input.ContainsKey("IntegrationEntry"))
            {
                IIntegrationEntry integrationEntry = IKEADEEActionUtilities.GetInputItem<IIntegrationEntry>(Input, "IntegrationEntry");

                if (integrationEntry.IntegrationMessage?.Message != null)
                {
                    XmlDocument xmlMessage = new XmlDocument();
                    xmlMessage.LoadXml(Encoding.UTF8.GetString(integrationEntry.IntegrationMessage.Message));

                    if (xmlMessage.SelectNodes(IKEAConstants.ProcessItemMaster).Count > 0)
                    {
                        deeContextUtilities.SetContextParameter(IKEAConstants.CustomPLMSyncProductXmlDocumentContextKey, xmlMessage);

                        executeAction = true;
                    }
                }
            }

            return executeAction;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            //System
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Text");
            UseReference("", "System.IO");
            UseReference("", "System.Threading");
            UseReference("", "System");
            UseReference("%MicrosoftNetPath%\\System.XML.XDocument.dll", "");
            UseReference("%MicrosoftNetPath%\\System.XML.ReaderWriter.dll", "");
            UseReference("%MicrosoftNetPath%\\System.Private.XML.dll", "");
            UseReference("%MicrosoftNetPath%\\System.XML.dll", "System.Xml");

            //Foundation
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.Common.dll", "Cmf.Foundation.Common");
            UseReference("Cmf.Foundation.Security.dll", "Cmf.Foundation.Security");

            //Navigo
            UseReference("Cmf.Navigo.Common.dll", "Cmf.Navigo.Common");
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaintenanceManagement");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaintenanceManagement.InputObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaintenanceManagement.OutputObjects");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");


            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.PLM");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.PLM.Communication");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Exceptions");
            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IPLMUtilities plmUtilities = serviceProvider.GetService<IPLMUtilities>();
            ILocalizedMessage localizedMessage = serviceProvider.GetService<ILocalizedMessage>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();

            #region Retrieve and Parse the XML Message
            // Since we already parsed the XML string in the test condition code, we saved it
            // already parsed as a context parameter to avoid parsing it twice
            XmlDocument xmlMessage = deeContextUtilities.GetContextParameter(IKEAConstants.CustomPLMSyncProductXmlDocumentContextKey) as XmlDocument;

            // If no context parameter was saved, it means we are executing the action without executing the test condition first
            // Which means we need to load and parse the XML string now for the first time
            if (xmlMessage == null)
            {
                IIntegrationEntry integrationEntry = IKEADEEActionUtilities.GetInputItem<IIntegrationEntry>(Input, "IntegrationEntry");

                xmlMessage = new XmlDocument();
                xmlMessage.LoadXml(Encoding.UTF8.GetString(integrationEntry.IntegrationMessage.Message));
            }

            // Deserialize the parsed XmlDocument into the message type ProcessItemMaster
            var productCreationMessage = new ProductCreation(xmlMessage);
            #endregion

            IFacility facility = null;

            #region Validate the facility ERP code from the message
            // This is the ERP facility code that should come with the message
            string facilityErpCode = productCreationMessage.GetProperty("FACI");

            if (facilityErpCode.IsNullOrEmpty())
            {
                throw new IKEAException(IKEAConstants.CustomPLMInvalidFacilityCodeProvidedLocalizedMessage);
            }

            facility = ikeaUtilities.GetFacilityByERPIdentifier(facilityErpCode);

            if (facility == null)
            {
                throw new IKEAException(IKEAConstants.CustomPLMInvalidFacilityCodeProvidedLocalizedMessage, facilityErpCode);
            }
            #endregion

            var productSyncInput = new ProductSyncInput();

            #region Populate intermediate ProductSyncInput object
            var revisionSeparator = Config.GetConfig(IKEAConstants.CustomProductRevisionSeparator).GetConfigValue<string>();

            var itemID = productCreationMessage.GetItem<ItemIDType>(ItemsChoiceType.ItemID);

            productSyncInput.BaseName = itemID.ID.Value;
            productSyncInput.Revision = Convert.ToInt32(itemID.RevisionID);
            productSyncInput.Name = String.Format("{0}{1}{2:D3}", productSyncInput.BaseName, revisionSeparator, productSyncInput.Revision);

            productSyncInput.Description = productCreationMessage.GetDescription();
            productSyncInput.AttributeItemGroup = productCreationMessage.GetClassificationCode("Item Groups");
            productSyncInput.AttributeProductGroup = productCreationMessage.GetClassificationCode("Product Groups");
            productSyncInput.AttributeItemType = productCreationMessage.GetClassificationCode("Item Types");
            productSyncInput.AttributeItemDescription = productCreationMessage.GetProperty("FUDS");
            productSyncInput.DefaultUnits = productCreationMessage.GetItemMasterHeader().BaseUOMCode.Value;

            productSyncInput.FacilityName = facility.Name;

            // Alternative Units
            productSyncInput.AlternateUnitConversions = productCreationMessage.GetProperty("ALUN", "")
                .Split(',')
                .Select(unit => unit.Trim())
                .Where(unit => unit.IsNullOrEmpty() == false)
                .ToDictionary(unit => unit, unit => Convert.ToDecimal(productCreationMessage.GetProperty("Calc" + unit)));

            var dimensions = productCreationMessage.GetDimensions();
            productSyncInput.WidthMeasure = Convert.ToDecimal(dimensions.WidthMeasure.Value);
            productSyncInput.HeightMeasure = Convert.ToDecimal(dimensions.HeightMeasure.Value);
            productSyncInput.LengthMeasure = Convert.ToDecimal(dimensions.LengthMeasure.Value);

            // Sometimes the unit names from the message do not match the ones in MES exactly (pcs instead of Pcs, for example)
            // This function tries to match existing units regardless of casing with the ones in MES
            // and replaces them in-place in the object
            plmUtilities.NormalizeProductUnitsFromPLM(productSyncInput);
            #endregion

            #region Create/Update Base Product
            IProduct baseProduct = entityFactory.Create<IProduct>();
            baseProduct.Name = productSyncInput.BaseName;
            if (baseProduct.ObjectExists() == false)
            {
                baseProduct = plmUtilities.CreateProductFromPLM(productSyncInput, false);
            }
            else
            {
                baseProduct = plmUtilities.CreateProductVersionFromPLM(productSyncInput, false);
            }
            #endregion

            #region Create/Update Product Revision
            IProduct productRevision = entityFactory.Create<IProduct>();
            productRevision.Name = productSyncInput.Name;
            if (productRevision.ObjectExists() == false)
            {
                productRevision = plmUtilities.CreateProductFromPLM(productSyncInput, true);
            }
            else
            {
                productRevision = plmUtilities.CreateProductVersionFromPLM(productSyncInput, true);
            }
            #endregion

            //---End DEE Code---

            return Input;
        }

    }
}
