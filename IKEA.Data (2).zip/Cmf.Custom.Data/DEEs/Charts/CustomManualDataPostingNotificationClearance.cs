﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;

using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using INotification = Cmf.Navigo.BusinessObjects.Abstractions.INotification;
using INotificationCollection = Cmf.Navigo.BusinessObjects.Abstractions.INotificationCollection;

namespace Cmf.Custom.IKEA.Actions.Charts
{
    class CustomManualDataPostingNotificationClearance : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {

        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---

            #region Info
            /// <summary>
            /// DEE to handle the creation of a Task after a clearance of a notification of the type ChartDataPosting 
            /// Action Groups: BusinessObjects.NotificationCollection.Terminate.Post
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion


            // By default, action is not to be executed
            bool executionVeridict = false;

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.NotificationCollection.Terminate.Post"
            };
            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IGenericUtilities _genericUtilities = serviceProvider.GetService<IGenericUtilities>();

            // Check if tasks are enabled for this functionality:
            bool createTasksEnabled = _genericUtilities.GetConfigurationValueByPath<bool>(IKEAConstants.CustomManualDataPostingNotificationCreateTasks);

            // only proceed if within expected triggers (action groups)
            executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups) && createTasksEnabled;

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---
UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            //System
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("", "System");
            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            
            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            INiceLabelUtilities nbUtilities = serviceProvider.GetService<INiceLabelUtilities>();
            ILocalizedMessage _localizedMessage = serviceProvider.GetService<ILocalizedMessage>();
            IGenericUtilities _genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();

            // Get all notifications in the collection post:
            Cmf.Navigo.BusinessObjects.Abstractions.INotificationCollection notificationsToClear = IKEADEEActionUtilities.GetInputItem<Cmf.Navigo.BusinessObjects.Abstractions.INotificationCollection>(Input, "NotificationCollection");

            // Get notification type:
            string notificationType = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.CustomManualDataPostingNotificationType);

            if (!notificationType.IsNullOrEmpty() && notificationsToClear.Any(n => n.Type.Equals(notificationType, StringComparison.InvariantCultureIgnoreCase)))
            {
                // Get current logged Employee:
                IEmployee currentEmployee = ikeaUtilities.GetCurrentEmployee();

                // Check if tasks are enabled for this fucntionality:
                bool stackTasksAllowed = _genericUtilities.GetConfigurationValueByPath<bool>(IKEAConstants.CustomManualDataPostingNotificationStackTasks);

                // Get notification type:
                int taskCompletionTime = _genericUtilities.GetConfigurationValueByPath<int>(IKEAConstants.CustomManualDataPostingNotificationTaskCompletionTime);

                // Gather all necessary attributes from notification:                
                notificationsToClear.LoadAttributes(new Collection<string> { IKEAConstants.CustomNotificationLogicalChartName });


                ITaskCollection tasksToCreate = entityFactory.CreateCollection<ITaskCollection>();

                foreach (Cmf.Navigo.BusinessObjects.Abstractions.INotification notification in notificationsToClear.Where(n => n.Type.Equals(notificationType, StringComparison.InvariantCultureIgnoreCase)))
                {
                    // get the logical chart name from the notification attribute:
                    string logicalChartName = notification.GetAttributeValueOrDefault<string>(IKEAConstants.CustomNotificationLogicalChartName);

                    // Check if it is allowed to create tasks while there are still tasks open for the same logical chart and employee:
                    if (!stackTasksAllowed)
                    {
                        var activeTasks = ikeaUtilities.GetActiveDataPostingTasks(logicalChartName, notificationType, currentEmployee.Name);
                        if (!activeTasks.IsNullOrEmpty())
                        {
                            continue;
                        }
                    }

                    // For the case that it is clearing multiple notifications of the same logical chart, add only one task:
                    if (!tasksToCreate.Any(T => T.Owner.Id == currentEmployee.Id 
                        && T.Attributes.ContainsKey(IKEAConstants.CustomTaskLogicalChartName) 
                        && T.Attributes[IKEAConstants.CustomTaskLogicalChartName].ToString() == logicalChartName))
                    {
                        // Configure a new Task:
                        ITask task = entityFactory.Create<ITask>();
                        task.Title = notification.Title;
                        task.Details = notification.Details;
                        task.DocumentationURL = notification.DocumentationURL;
                        task.OriginalOwner = currentEmployee;
                        task.Owner = currentEmployee;
                        task.OriginalDueDate = DateTime.UtcNow.AddMinutes(taskCompletionTime);
                        task.DueDate = DateTime.UtcNow.AddMinutes(taskCompletionTime);
                       

                        // Add the TaskType attribute to be the same as the notification type: 
                        task.Attributes.Add(IKEAConstants.CustomTaskAttributeTaskType, notificationType);
                        task.Attributes.Add(IKEAConstants.CustomTaskLogicalChartName, logicalChartName);

                        tasksToCreate.Add(task);
                    }
                }

                if (tasksToCreate.Any())
                {
                    tasksToCreate.Create();
                }

            }
            //---End DEE Code---
            return null;
        }


    }
}
