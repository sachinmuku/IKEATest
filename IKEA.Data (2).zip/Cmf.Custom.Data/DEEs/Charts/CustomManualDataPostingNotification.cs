﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Foundation.Security;
using Cmf.Foundation.Security.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;

using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Threading;
using INotification = Cmf.Navigo.BusinessObjects.Abstractions.INotification;
using INotificationCollection = Cmf.Navigo.BusinessObjects.Abstractions.INotificationCollection;

namespace Cmf.Custom.IKEA.Actions.Charts
{
    /// <summary>
    /// Invoked by a Timer, this DEE is responsible for sending notifications for logical charts manual data posting
    /// according the generic table CustomManualDataPostingNotifications
    /// </summary>
    public class CustomManualDataPostingNotification : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {

        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            /// DEE invoked by Timer  
            /// Action Groups:
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion

            return true;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
UseReference("%MicrosoftNetPath%System.Private.CoreLib.dll", "System.Threading");
           //System
            UseReference("", "System");
            UseReference("", "System.Linq");
            UseReference("", "System.Globalization");
            UseReference("", "System.Collections.Generic");
            //Foundation
            UseReference("Cmf.Foundation.Common.dll", "Cmf.Foundation.Common");
            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
             UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            ILocalizedMessage _localizedMessage = serviceProvider.GetService<ILocalizedMessage>();
            IGenericUtilities _genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();

            Dictionary<string, object> Output = new Dictionary<string, object>(Input);

            //Check if the timer's frequency has changed
            int? timerFrequency = _genericUtilities.GetConfigurationValueByPath<int>(IKEAConstants.CustomManualDataPostingNotificationTimerFrequency);
            timerFrequency = timerFrequency.HasValue ? timerFrequency * 60 : 300;

            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();

            ICmfTimer notificationTimer = entityFactory.Create<ICmfTimer>();
            notificationTimer.Name = IKEAConstants.CustomManualDataPostingNotificationTimerName;

            notificationTimer.Load();

            //Update the timer's frequency
            if (timerFrequency != notificationTimer.RecurrenceDefinedSeconds)
            {
                notificationTimer.RecurrenceDefinedSeconds = timerFrequency;
                notificationTimer.Save();
            }

            // Get the data from the Generic table CustomManualDataPostingNotifications:
            List<CustomDataPostingNotifications> manualDataPostingLogicalCharts = ikeaUtilities.GetManualDataPostingNotifications();
            if (!manualDataPostingLogicalCharts.IsNullOrEmpty())
            {

                // Set the date format for the logical chart attribute:
                string dateTimeFormat = "yyyyMMddHHmmss";

                // Create a collection with all logical charts:
                ILogicalChartCollection logicalCharts = ikeaUtilities.GetAllRelatedLogicalCharts(manualDataPostingLogicalCharts, true);

                foreach (var logicalChart in logicalCharts)
                {
                    var notificationSettings = manualDataPostingLogicalCharts.FirstOrDefault(DP =>
                        DP.LogicalChartName.CompareStrings(logicalChart.Name) ||
                        DP.ChartName.CompareStrings(logicalChart.Chart.Name) ||
                        DP.ParameterName.CompareStrings(logicalChart.Chart.Parameter.Name));

                    if (!notificationSettings.NotifyCheckedInEmployees && !notificationSettings.MESNotifications && !notificationSettings.EmailNotifications)
                    {
                        continue;
                    }

                    // Get last notification of this logicalchart:
                    string lastNotificationAttribute = logicalChart.GetAttributeValueOrDefault<string>(IKEAConstants.LogicalChartLastNotificationDateAttribute);

                    // If the date was not set, it means that is a logical chart configured in the table for the first time:
                    DateTime lastNotificationDate;
                    if (!DateTime.TryParseExact(lastNotificationAttribute, dateTimeFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out lastNotificationDate))
                    {
                        logicalChart.SaveAttributes(new AttributeCollection() { { IKEAConstants.LogicalChartLastNotificationDateAttribute, DateTime.Now.ToString(dateTimeFormat) } });
                        continue;
                    }

                    // If the dates interval exceeds the notification frequency, create notifications:
                    if ((DateTime.Now - lastNotificationDate).TotalMinutes >= notificationSettings.NotificationFrequency)
                    {

                        // Buid a link to the logical chart
                        string html5GuiAddress = _genericUtilities.GetConfigurationValueByPath<string>(Cmf.Foundation.Common.Constants.HTML5GuiPath);
                        string logicalChartLink = string.Format("{0}/Entity/LogicalChart/{1}/View/Chart", html5GuiAddress, logicalChart.Id);

                        IResource resource = null;

                        IEmployeeCollection employeesToBeNotified = null;

                        // Set role:
                        IRole role = null;
                        if (!string.IsNullOrWhiteSpace(notificationSettings.NotificationRoleName))
                        {
                            role = new Role() { Name = notificationSettings.NotificationRoleName };
                            role.Load();
                        }

                        #region Extract Resource

                        // Get resource from field. If it is null, try to get it from the logical chart contextexist
                        if (!string.IsNullOrWhiteSpace(notificationSettings.ResourceName))
                        {
                            resource = entityFactory.Create<IResource>();
                            resource.Name = notificationSettings.ResourceName;
                        }
                        else
                        {
                            // Load context from logicalchart                            
                            string[] logicalChartKeys = logicalChart.ContextKeys.Split(new string[] { Cmf.Navigo.Common.Constants.LogicalChartContextSpliter }, StringSplitOptions.None);


                            // Check if a valid resource exist in the context keys:
                            string resourceKey = logicalChartKeys.FirstOrDefault(K =>
                            {
                                var logicalResource = entityFactory.Create<IResource>();
                                logicalResource.Name = K;
                                return logicalResource.ObjectExists();
                            });

                            var filteredLogicalResource = entityFactory.Create<IResource>();
                            filteredLogicalResource.Name = resourceKey;
                            resource = string.IsNullOrWhiteSpace(resourceKey) ? null : filteredLogicalResource;
                        }

                        if (resource != null)
                        {
                            resource.Load();

                            // Only process the notifications if the resource is at the specified StateModel
                            if (!notificationSettings.StateModelName.IsNullOrEmpty() && !resource.CurrentMainState.StateModel.Name.CompareStrings(notificationSettings.StateModelName))
                            {
                                continue;
                            }

                            // Only process the notifications if the resource is at the specified StateModelState
                            if (!notificationSettings.StateModelStateName.IsNullOrEmpty() && !resource.CurrentMainState.CurrentState.Name.CompareStrings(notificationSettings.StateModelStateName))
                            {
                                continue;
                            }
                        }

                        #endregion

                        #region Handle MES Notifications

                        if (notificationSettings.NotifyCheckedInEmployees || notificationSettings.MESNotifications)
                        {
                            Cmf.Navigo.BusinessObjects.Abstractions.INotificationCollection notificationsToSend = null;

                            // get default severity:
                            string severity = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.CustomManualDataPostingNotificationSeverity);
                            if (severity.IsNullOrEmpty())
                            {
                                severity = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.DefaultNotificationSeverityConfig);
                            }
                            if (severity.IsNullOrEmpty())
                            {
                                throw new CmfBaseException(ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomManualDataPostingNotificationSeverityMissingLocalizedMessage, IKEAConstants.CustomManualDataPostingNotificationSeverity));
                            }

                            // If the NotifyCheckedInEmployees is set:
                            if (notificationSettings.NotifyCheckedInEmployees && resource != null)
                            {
                                employeesToBeNotified = _genericUtilities.GetCheckedInEmployees(resource.Name);
                            }

                            // Get settings
                            string type = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.CustomManualDataPostingNotificationType);
                            string title = _localizedMessage.LoadLocalizedMessage(Thread.CurrentThread.CurrentCulture.Name, IKEAConstants.CustomManualDataPostingNotificationTitleLocalizedMessage).MessageText;
                            string details = string.Empty;
                            string lookUpSeverity = ikeaUtilities.GetValueFromLookupTable(IKEAConstants.NotificationSeverityLookupTableName, severity, true);

                            // Add additional information to details
                            if (!notificationSettings.LogicalChartName.IsNullOrEmpty())
                            {
                                details = string.Format("{0} Logical Chart: '{1}'.", details, notificationSettings.LogicalChartName);
                            }

                            if (!notificationSettings.ResourceName.IsNullOrEmpty())
                            {
                                details = string.Format("{0} Resource: '{1}'.", details, notificationSettings.ResourceName);
                            }

                            if (!notificationSettings.ChartName.IsNullOrEmpty())
                            {
                                details = string.Format("{0} Chart: '{1}'.", details, notificationSettings.ChartName);
                            }

                            if (!notificationSettings.ParameterName.IsNullOrEmpty())
                            {
                                details = string.Format("{0} Parameter: '{1}'.", details, notificationSettings.ParameterName);
                            }

                            details = string.Format("{0} {1}.", details, ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomManualDataPostingNotificationEmailDetailsLocalizedMessage, notificationSettings.NotificationFrequency.ToString()));

                            // Handle notifications to a Role:
                            if (notificationSettings.MESNotifications && role != null)
                            {

                                //Add a role notification to the collection
                                notificationsToSend = entityFactory.CreateCollection<Cmf.Navigo.BusinessObjects.Abstractions.INotificationCollection>();
                                Cmf.Navigo.BusinessObjects.Abstractions.INotification notification = entityFactory.Create<Cmf.Navigo.BusinessObjects.Abstractions.INotification>();

                                notification.Type = type;
                                notification.Title = title;
                                notification.Details = details;
                                notification.Severity = lookUpSeverity;
                                notification.AssignmentType = (NotificationAssignmentType)AssignmentType.Role;
                                notification.AssignedToRole = role;
                                notification.Resource = resource;
                                notification.Area = resource?.Area;
                                notification.Facility = resource?.Area.Facility;
                                notification.DocumentationURL = logicalChartLink;

                                notification.Attributes.Add(IKEAConstants.CustomNotificationLogicalChartName, logicalChart.Name);
                                notificationsToSend.Add(notification);

                                // Exclude the employees that belong to the selected role
                                if (!employeesToBeNotified.IsNullOrEmpty())
                                {
                                    IEmployeeCollection employeesNotInRole = entityFactory.CreateCollection<IEmployeeCollection>();

                                    employeesNotInRole.AddRange(
                                        employeesToBeNotified.Except(employeesToBeNotified.Where(E => E.User.Roles.Any(R => R.Name.CompareStrings(role.Name))))
                                    );

                                    employeesToBeNotified = employeesNotInRole;
                                }
                            }

                            // Handle notifications to specific Employees:
                            if (!employeesToBeNotified.IsNullOrEmpty())
                            {
                                if (notificationsToSend == null)
                                {
                                    notificationsToSend = entityFactory.CreateCollection<Cmf.Navigo.BusinessObjects.Abstractions.INotificationCollection>();
                                }

                                foreach (var employee in employeesToBeNotified)
                                {

                                    //Add a notification to the collection
                                    Cmf.Navigo.BusinessObjects.Abstractions.INotification notification = entityFactory.Create<Cmf.Navigo.BusinessObjects.Abstractions.INotification>();

                                    notification.Type = type;
                                    notification.Title = title;
                                    notification.Details = details;
                                    notification.Severity = lookUpSeverity;
                                    notification.AssignmentType = (NotificationAssignmentType)AssignmentType.Employee;
                                    notification.AssignedToUser = employee.User;
                                    notification.Resource = resource;
                                    notification.Area = resource?.Area;
                                    notification.Facility = resource?.Area.Facility;
                                    notification.DocumentationURL = logicalChartLink;

                                    notification.Attributes.Add(IKEAConstants.CustomNotificationLogicalChartName, logicalChart.Name);
                                    notificationsToSend.Add(notification);
                                }
                            }

                            // Create the notifications:
                            if (!notificationsToSend.IsNullOrEmpty())
                            {
                                notificationsToSend.Create();
                            }

                        }

                        #endregion

                        #region Handle Email Notifications
                        if (notificationSettings.EmailNotifications)
                        {
                            List<string> emailAddresses = new List<string>();

                            // Gather addresses from the role:
                            if (role != null)
                            {
                                string roleEmails = role.GetEmailAddressesAsDistributionList(null, true, true);
                                emailAddresses.AddRange(roleEmails.Split(';'));
                            }

                            // Gather addresses from the employes:
                            if (!employeesToBeNotified.IsNullOrEmpty())
                            {
                                emailAddresses.AddRange(employeesToBeNotified.Where(E => !E.User.MailAddress.IsNullOrEmpty())
                                                                             .Select(A => A.User.MailAddress));
                            }

                            // Gather addresses from the distribution list:
                            if (!notificationSettings.EmailDistributionList.IsNullOrEmpty())
                            {
                                emailAddresses.AddRange(notificationSettings.EmailDistributionList.Where(E => !emailAddresses.Contains(E, StringComparer.OrdinalIgnoreCase)));
                            }

                            ikeaUtilities.SendManualDataPostingEmail(emailAddresses, logicalChart, resource, logicalChartLink, notificationSettings.NotificationFrequency.ToString());
                        }

                        #endregion

                        // Update the logical chart last notification date attribute:
                        logicalChart.SaveAttributes(new AttributeCollection() { { IKEAConstants.LogicalChartLastNotificationDateAttribute, DateTime.Now.ToString(dateTimeFormat) } });

                    }
                }
            }

            //Output["Result"] = true;

            //return Output;

            Input["Result"] = true;
            //---End DEE Code---
            return Input;
        }
    }
}
