﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.ERP;
using Cmf.Custom.IKEA.Common.Extensions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Xml;

namespace Cmf.Custom.IKEA.Actions.ERP
{
    public class CustomERPDispatchReport : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text:   Action to create an integration entry to notify ERP when Materials are Dispatched if LineAssignmentCommunication is enabled
            /// 
            /// Action Groups:  MaterialManagement.MaterialManagementOrchestration.DispatchMaterials.Post
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
        
            IGenericUtilities _genericUtilities = serviceProvider.GetService<IGenericUtilities>();

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "MaterialManagement.MaterialManagementOrchestration.DispatchMaterials.Post"
            };

            // only proceed if within expected triggers (action groups) and has LineAssignmentCommunication
            bool hasLineAssignmentCommunication = _genericUtilities.GetConfigurationValueByPath<bool>(IKEAConstants.LineAssignmentCommunication);
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups) && hasLineAssignmentCommunication;

            if (executionVeridict && IKEADEEActionUtilities.GetInputItem<DispatchMaterialsOutput>(Input, "DispatchMaterialsOutput") == null)
            {
                executionVeridict = false;
            }
 
            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            //System
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.IO");
            UseReference("", "System.Threading");
            UseReference("", "System");
            UseReference("%MicrosoftNetPath%\\System.Xml.dll", "System.Xml");
            UseReference("%MicrosoftNetPath%\\System.Private.Xml.dll", "");
            UseReference("%MicrosoftNetPath%\\System.Xml.ReaderWriter.dll", "");

            //Foundation
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");

            //Navigo
            UseReference("Cmf.Navigo.Common.dll", "Cmf.Navigo.Common");
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Extensions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.ERP");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            INiceLabelUtilities nbUtilities = serviceProvider.GetService<INiceLabelUtilities>();
            ILocalizedMessage _localizedMessage = serviceProvider.GetService<ILocalizedMessage>();
            IGenericUtilities _genericUtilities = serviceProvider.GetService<IGenericUtilities>();

            IMaterialCollection inputMaterials = (Input["DispatchMaterialsOutput"] as DispatchMaterialsOutput).Materials;
            inputMaterials.LoadRelations(Cmf.Navigo.Common.Constants.MaterialResource);

            inputMaterials.LoadAttributes(new Collection<string>() { IKEAConstants.CustomMaterialAttributeERPOriginalName });

            foreach (IMaterial material in inputMaterials)
            {
                //If Material does not have a ProductionOrder, no IntegrationEntry is created
                if (material.GetNativeValue<long>(Cmf.Navigo.Common.Constants.ProductionOrder) > 0)
                {
                    // Get Material ERP Original Name
                    string erpOriginalName = material.GetAttributeValueOrDefault<string>(IKEAConstants.CustomMaterialAttributeERPOriginalName);

                    string materialName = string.IsNullOrWhiteSpace(erpOriginalName) ? material.Name : erpOriginalName;

                    WorkCenterDispatchCommunication integrationEntryData = new WorkCenterDispatchCommunication();

                    integrationEntryData.Resource = material.MaterialResourceRelations[0].TargetEntity.Name;
                    integrationEntryData.Material = materialName;
                    integrationEntryData.DateAndTime = DateTime.Now.ToString("u");

                    material.ProductionOrder.Load();
                    integrationEntryData.ProductionOrder = material.ProductionOrder.Name;
                    integrationEntryData.Quantity = material.ProductionOrder.Quantity.ToString();

                    //Generate Integration Entry   
                    IIntegrationEntry integrationEntry = entityFactory.Create<IIntegrationEntry>();
                    integrationEntry = ikeaUtilities.CreateIntegrationEntry(sourceSystem: IKEAConstants.MESSystem,
                                                                           targetSystem: IKEAConstants.ERPSystem,
                                                                           messageType: IKEAConstants.ERPWorkCenterDispatchMessage,
                                                                           eventName: IKEAConstants.ERPWorkCenterDispatchEvent,
                                                                           xmlMessage: new XmlDocument() { InnerXml = integrationEntryData.SerializeToXML() });
                }
            }
            //---End DEE Code---
            return Input;
        }
    }
}
