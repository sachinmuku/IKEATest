﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.BusinessObjects.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Extensions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.ERP
{
    public class CustomERPOperationTrackingProcess : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            /// DEE for reporting consumption to the ERP   
            /// Action Groups:
            ///     BusinessObjects.MaterialCollection.TrackOut.Post
            ///     BusinessObjects.MaterialCollection.ChangeType.Pre
            ///     BusinessObjects.MaterialCollection.ChangeType.Post
            ///     BusinessObjects.MaterialCollection.Terminate.Pre
            ///     BusinessObjects.MaterialCollection.Terminate.Post
            /// </summary>
            #endregion
            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
 
            IGenericUtilities _genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.MaterialCollection.TrackOut.Post",
                "BusinessObjects.MaterialCollection.ChangeType.Pre",
                "BusinessObjects.MaterialCollection.ChangeType.Post",
                "BusinessObjects.MaterialCollection.Terminate.Pre",
                "BusinessObjects.MaterialCollection.Terminate.Post",
                "BusinessObjects.MaterialCollection.MoveToNextStep.Post"
            };

            bool executionVeridict = _genericUtilities.GetConfigurationValueByPath<bool>(IKEAConstants.CustomReportUnitComplete) && IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
     

            //System
            UseReference("", "Cmf.Custom.IKEA.BusinessObjects.Abstractions");
            UseReference("", "System");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("", "System.IO");
            UseReference("", "System.Linq");
            UseReference("", "System.Threading");
            //Foundation
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.Common.dll", "Cmf.Foundation.Common");
            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects");
            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Extensions");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
            UseReference("Cmf.Custom.IKEA.BusinessObjects.CustomERPOperationTracking.dll", "Cmf.Custom.IKEA.BusinessObjects");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            INiceLabelUtilities nbUtilities = serviceProvider.GetService<INiceLabelUtilities>();
            ILocalizedMessage _localizedMessage = serviceProvider.GetService<ILocalizedMessage>();
            IGenericUtilities _genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();

            DateTime internalTrackInDate;
            string lastKnownERPOperation = null;
            decimal operationDurationDelta = 0;

            DeeContext currentContext = deeContextUtilities.SetCurrentServiceContext("CustomERPOperationTrackingProcess");

            string orderForm = ikeaUtilities.GetOrderMaterialForm();

            // TrackOut Post
            if (currentContext.MethodName.StartsWith("TrackOut", System.StringComparison.InvariantCultureIgnoreCase))
            {
                //Get ReRun and DirectRepair Material types
                string reRunMaterialType = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.CustomReRunMaterialDefaultTypePath);
                string directRepairMaterialType = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.CustomDirectRepairMaterialDefaultTypePath);

                IMaterialCollection trackedOutMaterials = entityFactory.CreateCollection<IMaterialCollection>();
                trackedOutMaterials.AddRange(
                    IKEADEEActionUtilities.GetInputItem<IMaterialCollection>(Input, "MaterialCollection")
                        .Where(E => !E.Type.CompareStrings(reRunMaterialType) && !E.Type.CompareStrings(directRepairMaterialType))
                );

                // Gets 'LastKnowOperation' and 'InternalTrackInDate' attributes:
                trackedOutMaterials.LoadAttributes(
                    new Collection<string>
                    {
                        IKEAConstants.CustomMaterialAttributeLastKnownERPOperation,
                        IKEAConstants.CustomMaterialAttributeInternalTrackInDate,
                        IKEAConstants.CustomMaterialAttributeBaseMaterial
                    });

                foreach (IMaterial trackedOutMaterial in trackedOutMaterials)
                {
                    if (trackedOutMaterial.HasAttributes(new Collection<string> { IKEAConstants.CustomMaterialAttributeLastKnownERPOperation, IKEAConstants.CustomMaterialAttributeInternalTrackInDate, IKEAConstants.CustomMaterialAttributeBaseMaterial }))
                    {
                        lastKnownERPOperation = trackedOutMaterial.GetAttributeValueOrDefault<string>(IKEAConstants.CustomMaterialAttributeLastKnownERPOperation);
                        internalTrackInDate = trackedOutMaterial.GetAttributeValueOrDefault<DateTime>(IKEAConstants.CustomMaterialAttributeInternalTrackInDate);

                        if (!String.IsNullOrEmpty(lastKnownERPOperation) && internalTrackInDate != null)
                        {
                            // Gets current tracking Operation:
                            ICustomERPOperationTracking customERPOperationTracking = trackedOutMaterial.GetCurrentCustomERPOperatingTracking(false);
                            if (customERPOperationTracking != null)
                            {
                                //Determines TimeSpan from 'internalTrackInDate' and now:
                                operationDurationDelta = (decimal)(DateTime.Now - internalTrackInDate).TotalMinutes;

                                // Check if the current step is the last Process step of the the flow with the LastKnownERPOperationCode:
                                bool? isLastProcessStep = ikeaUtilities.GetIsLastProcessStepOfSubFlowWithERPOperation(trackedOutMaterial, lastKnownERPOperation);
                                if (isLastProcessStep.HasValue)
                                {
                                    // If it is the last process step reposts the quantity else reports '0':
                                    customERPOperationTracking.UpdateProgress(isLastProcessStep.Value ? trackedOutMaterial.PrimaryQuantity.Value : 0, operationDurationDelta, false, trackedOutMaterial, CustomUpdateProgressMethodEnum.TrackOut);
                                }
                            }
                        }
                    }
                }
            }

            // Terminate Post
            else if (currentContext.MethodName.Equals("Terminate", StringComparison.InvariantCultureIgnoreCase))
            {
                IMaterialCollection terminatedMaterials = Input["MaterialCollection"] as IMaterialCollection;

                Dictionary<long, MaterialSystemState> materialStates;

                if (currentContext.TriggerPoint == DeeTriggerPoint.Pre)
                {
                    materialStates = terminatedMaterials.ToDictionary(m => m.Id, m => m.SystemState);

                    deeContextUtilities.SetContextParameter("CustomERPOperationTrackingProcess_MaterialStates", materialStates);
                }
                else if (currentContext.TriggerPoint == DeeTriggerPoint.Post)
                {
                    materialStates = deeContextUtilities.GetContextParameter("CustomERPOperationTrackingProcess_MaterialStates") as Dictionary<long, MaterialSystemState>;

                    // Gets 'LastKnowOperation' and 'InternalTrackInDate' attributes:
                    terminatedMaterials.LoadAttributes(
                        new Collection<string>
                        {
                            IKEAConstants.CustomMaterialAttributeLastKnownERPOperation
                        });

                    foreach (IMaterial terminatedMaterial in terminatedMaterials)
                    {
                        // Gets all tracking Operations
                        ICustomERPOperationTrackingCollection customERPOperationTrackingCollection = terminatedMaterial.GetAllCustomERPOperationTrackingFromMOByRun(true);
                        if (customERPOperationTrackingCollection != null)
                        {
                            if (terminatedMaterial.HasAttribute(IKEAConstants.CustomMaterialAttributeLastKnownERPOperation))
                            {
                                lastKnownERPOperation = terminatedMaterial.GetAttributeValueOrDefault<string>(IKEAConstants.CustomMaterialAttributeLastKnownERPOperation);

                                if (!String.IsNullOrEmpty(lastKnownERPOperation)/* && internalTrackInDate != null*/)
                                {
                                    var erpOperationTracking = customERPOperationTrackingCollection.Where(ot => ot.OrderOperation.Equals(lastKnownERPOperation, StringComparison.InvariantCultureIgnoreCase)).FirstOrDefault();

                                    if (erpOperationTracking != null)
                                    {
                                        // Gets all elegible tracking Operations (operations with the same or higher sequence number)
                                        var actualSequence = erpOperationTracking.OrderOperationSequence;
                                        var elegibleERPOperationTrackingCollection = customERPOperationTrackingCollection.Where(v => v.OrderOperationSequence.Value >= actualSequence.Value);

                                        //Checks if this occurs before or during last known subflow with ERP Operation defined (lastKnownERPOperation)
                                        bool materialEventOccursUntilDefinedOperation = ikeaUtilities.GetIsEventOccurringUntilDefinedOperation(terminatedMaterial, lastKnownERPOperation);
                                        if (materialEventOccursUntilDefinedOperation)
                                        {
                                            // Updates [Order Finished Quantity] at corresponding CustomERPOperationTracking reporting to the Material.LastKnownERPOperation attribute
                                            // Updates all CustomERPOperationTracking entries related to the MO Name and Run with sequence greater than the one it is in, to increase/decrease the amount of  [Order Scheduled Quantity] that will be expected in following operations
                                            // For Terminate [Order Scheduled Quantity] should be decreased and no time update.
                                            foreach (var customERPOperationTracking in elegibleERPOperationTrackingCollection)
                                            {
                                                if (customERPOperationTracking.OrderOperation.CompareStrings(lastKnownERPOperation))
                                                {
                                                    // Check if the current step is before the last Process step of the flow with the LastKnownERPOperationCode:
                                                    bool isBeforeLastProcessStep = ikeaUtilities.ValidateIfStepBeforeLastProcessingStep(terminatedMaterial.Flow, terminatedMaterial.Step);

                                                    // Only Update Progress if we are not in the last process step or when the material isn't in process
                                                    if (isBeforeLastProcessStep)
                                                    {
                                                        // For current operation progress should be updated with quantity terminated... 
                                                        customERPOperationTracking.UpdateProgress(terminatedMaterial.PrimaryQuantity.Value, 0, true, terminatedMaterial, CustomUpdateProgressMethodEnum.Terminate);
                                                    }
                                                    else if (materialStates[terminatedMaterial.Id] != MaterialSystemState.Processed)
                                                    {
                                                        // Check if the current step is the last Process step of the the flow with the LastKnownERPOperationCode:
                                                        bool isLastProcessStep = ikeaUtilities.GetIsLastProcessStepOfSubFlowWithERPOperation(terminatedMaterial, lastKnownERPOperation).GetValueOrDefault();

                                                        if (isLastProcessStep)
                                                        {
                                                            // For current operation progress should be updated with quantity terminated... 
                                                            customERPOperationTracking.UpdateProgress(terminatedMaterial.PrimaryQuantity.Value, 0, true, terminatedMaterial, CustomUpdateProgressMethodEnum.Terminate);
                                                        }
                                                    }
                                                }
                                                else
                                                {
                                                    // for future operations quantity should be deducted from the scheduled quantity.
                                                    customERPOperationTracking.UpdateScheduledQuantity(terminatedMaterial.PrimaryQuantity.Value * -1, terminatedMaterial.Form.CompareStrings(orderForm));
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // ChangeType Pre + post
            else if (currentContext.MethodName.Equals("ChangeType", StringComparison.InvariantCultureIgnoreCase))
            {
                bool? completeUnit = ApplicationContext.CallContext.GetInformationContext("CustomMaterialAssembleRework_CompleteUnit") as bool?;

                // Do no run when it is the complete unit
                if (!completeUnit.HasValue || !completeUnit.Value)
                {
                    // PRE - Check change type transition from Good to Bad or Bad to Good and save it on context:
                    if (currentContext.TriggerPoint == DeeTriggerPoint.Pre)
                    {
                        // Gets the Previous and future material types and saves it into the local context:
                        if (Input.ContainsKey("MaterialTypes"))
                        {
                            // Get the material types from the input
                            Dictionary<IMaterial, string> materialTypes = Input["MaterialTypes"] as Dictionary<IMaterial, string>;
                            Dictionary<IMaterial, bool> materialTypeTransitions = new Dictionary<IMaterial, bool>();

                            foreach (var materialType in materialTypes)
                            {
                                // Gets the 'CustomMaterialGoodQualityTypes' lookup table to retrieve the good types list:
                                ILookupTable ltGoodQualityTypes = new LookupTable();
                                ltGoodQualityTypes.Load(IKEAConstants.CustomMaterialGoodQualityTypes);
                                Dictionary<string, string> goodQualityTypes = ltGoodQualityTypes.Values.ToDictionary(E => E.Value.ToLower(), E => E.Value);

                                // Check the old and new types of the material:
                                bool isNewTypeGood = goodQualityTypes.Any(gt => gt.Value.Equals(materialType.Value, StringComparison.InvariantCultureIgnoreCase));
                                bool IsOldTypeGood = goodQualityTypes.Any(gt => gt.Value.Equals(materialType.Key.Type, StringComparison.InvariantCultureIgnoreCase));

                                // No change should occur when changing to the same quality type status:
                                if (isNewTypeGood != IsOldTypeGood)
                                {
                                    if (isNewTypeGood)
                                    {
                                        materialTypeTransitions.Add(materialType.Key, true);
                                    }
                                    else
                                    {
                                        materialTypeTransitions.Add(materialType.Key, false);
                                    }
                                }
                            }
                            deeContextUtilities.SetContextParameter("materialTypeTransitions", materialTypeTransitions);
                        }
                    }

                    // POST - Report quantities according to context parameters:
                    else if (currentContext.TriggerPoint == DeeTriggerPoint.Post)
                    {
                        IMaterialCollection changedTypeMaterials = Input["MaterialCollection"] as IMaterialCollection;

                        // Gets 'LastKnowOperation' and 'InternalTrackInDate' attributes:
                        changedTypeMaterials.LoadAttributes(
                            new Collection<string>
                            {
                        IKEAConstants.CustomMaterialAttributeLastKnownERPOperation
                            });

                        // Gets the context parameters saved in Pre condition:
                        Dictionary<IMaterial, bool> materialTypeTransitions = deeContextUtilities.GetContextParameter("materialTypeTransitions") as Dictionary<IMaterial, bool>;
                        if (materialTypeTransitions != null)
                        {
                            foreach (IMaterial changedTypeMaterial in changedTypeMaterials)
                            {
                                // Gets all tracking Operations
                                ICustomERPOperationTrackingCollection customERPOperationTrackingCollection = changedTypeMaterial.GetAllCustomERPOperationTrackingFromMOByRun();
                                if (customERPOperationTrackingCollection != null)
                                {
                                    customERPOperationTrackingCollection.Load();

                                    if (changedTypeMaterial.HasAttribute(IKEAConstants.CustomMaterialAttributeLastKnownERPOperation))
                                    {
                                        lastKnownERPOperation = changedTypeMaterial.GetAttributeValueOrDefault<string>(IKEAConstants.CustomMaterialAttributeLastKnownERPOperation);

                                        if (!String.IsNullOrEmpty(lastKnownERPOperation))
                                        {

                                            // Gets all elegible tracking Operations (operations with the same or bigger sequence number)
                                            var actualSequence = customERPOperationTrackingCollection.Where(ot => ot.OrderOperation.Equals(lastKnownERPOperation, StringComparison.InvariantCultureIgnoreCase)).FirstOrDefault().OrderOperationSequence;
                                            var elegibleERPOperationTrackingCollection = customERPOperationTrackingCollection.Where(v => v.OrderOperationSequence.Value >= actualSequence.Value);

                                            // Checks if this occurs before or during last known subflow with ERP Operation defined (lastKnownERPOperation)
                                            bool materialEventOccursUntilDefinedOperation = ikeaUtilities.GetIsEventOccurringUntilDefinedOperation(changedTypeMaterial, lastKnownERPOperation);
                                            if (materialEventOccursUntilDefinedOperation)
                                            {
                                                // Material must be associated to a PO:
                                                if (changedTypeMaterial.ProductionOrder != null)
                                                {
                                                    // Material must not be marked as Completed:
                                                    if (!changedTypeMaterial.IsProductionComplete)
                                                    {
                                                        // Updates [Order Finished Quantity] at corresponding CustomERPOperationTracking reporting to the Material.LastKnownERPOperation attribute
                                                        // Updates all CustomERPOperationTracking entries related to the MO Name and Run with sequence greater than the one it is in, to increase/decrease the amount of  [Order Scheduled Quantity] that will be expected in following operations
                                                        // For Change Type from good to bad, [Order Scheduled Quantity] should be decreased.
                                                        // For change type of bad to good, [Order Scheduled Quantity] should be increased
                                                        // No change should occur when changing to the same quality type status
                                                        // Use Lookup table CustomMaterialGoodQualityTypes to determine meaning of each Material type, to understand if there is a change of quality status(good > bad or bad > good). 

                                                        // Get context parameter for the material:
                                                        var materialTypeTransition = materialTypeTransitions.Where(mt => mt.Key.Name.Equals(changedTypeMaterial.Name)).FirstOrDefault();
                                                        if (!materialTypeTransition.Equals(default(KeyValuePair<IMaterial, bool>)))
                                                        {
                                                            // Determine if it is to increment or Decrement the Material:
                                                            bool isToIncrement = materialTypeTransition.Value;

                                                            // update progress to all Operations:
                                                            foreach (var customERPOperationTracking in elegibleERPOperationTrackingCollection)
                                                            {
                                                                if (customERPOperationTracking.OrderOperation.Equals(lastKnownERPOperation, StringComparison.InvariantCultureIgnoreCase))
                                                                {
                                                                    // Check that the material it is NOT at the last process step:
                                                                    bool? isLastProcessStep = ikeaUtilities.GetIsLastProcessStepOfSubFlowWithERPOperation(changedTypeMaterial, lastKnownERPOperation);
                                                                    if (isLastProcessStep.HasValue && !isLastProcessStep.Value)
                                                                    {
                                                                        // For current operation progress should be updated with quantity terminated... 
                                                                        customERPOperationTracking.UpdateProgress(changedTypeMaterial.PrimaryQuantity.Value, 0, false, changedTypeMaterial, CustomUpdateProgressMethodEnum.ChangeType);
                                                                    }
                                                                }
                                                                else
                                                                {
                                                                    // for future operations quantity should be deducted from the scheduled quantity.
                                                                    customERPOperationTracking.UpdateScheduledQuantity(changedTypeMaterial.PrimaryQuantity.Value * (isToIncrement ? 1 : -1), changedTypeMaterial.Form.CompareStrings(orderForm));
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // MoveToNext Post
            else if(currentContext.MethodName.StartsWith("MoveToNext", System.StringComparison.InvariantCultureIgnoreCase) || currentContext.MethodName.StartsWith("MoveMaterialsToNextStep", System.StringComparison.InvariantCultureIgnoreCase))
            {
                //Get ReRun and DirectRepair Material types
                string reRunMaterialType = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.CustomReRunMaterialDefaultTypePath);
                string directRepairMaterialType = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.CustomDirectRepairMaterialDefaultTypePath);

                IMaterialCollection MoveNextMaterials = entityFactory.CreateCollection<IMaterialCollection>();
                MoveNextMaterials.AddRange(
                    IKEADEEActionUtilities.GetInputItem<IMaterialCollection>(Input, "MaterialCollection")
                        .Where(E => !E.Type.CompareStrings(reRunMaterialType) && !E.Type.CompareStrings(directRepairMaterialType))
                );

                // Gets 'LastKnowOperation' and 'InternalTrackInDate' attributes:
                MoveNextMaterials.LoadAttributes(
                    new Collection<string>
                    {
                        IKEAConstants.CustomMaterialAttributeLastKnownERPOperation,
                        IKEAConstants.CustomMaterialAttributeInternalTrackInDate,
                        IKEAConstants.CustomMaterialAttributeBaseMaterial
                    });

                foreach (IMaterial moveNextMaterial in MoveNextMaterials)
                {
                    if (moveNextMaterial.HasAttributes(new Collection<string> { IKEAConstants.CustomMaterialAttributeLastKnownERPOperation, IKEAConstants.CustomMaterialAttributeInternalTrackInDate, IKEAConstants.CustomMaterialAttributeBaseMaterial }))
                    {
                        lastKnownERPOperation = moveNextMaterial.GetAttributeValueOrDefault<string>(IKEAConstants.CustomMaterialAttributeLastKnownERPOperation);
                        internalTrackInDate = moveNextMaterial.GetAttributeValueOrDefault<DateTime>(IKEAConstants.CustomMaterialAttributeInternalTrackInDate);

                        if (!String.IsNullOrEmpty(lastKnownERPOperation) && internalTrackInDate != null)
                        {
                            // Gets current tracking Operation:
                            ICustomERPOperationTracking customERPOperationTracking = moveNextMaterial.GetCurrentCustomERPOperatingTracking(false);
                            if (customERPOperationTracking != null)
                            {
                                //Determines TimeSpan from 'internalTrackInDate' and now:
                                operationDurationDelta = (decimal)(DateTime.Now - internalTrackInDate).TotalMinutes;

                                // Check if the current step is the last Process step of the the flow with the LastKnownERPOperationCode:
                                bool? isLastProcessStep = ikeaUtilities.GetIsLastProcessStepOfSubFlowWithERPOperation(moveNextMaterial, lastKnownERPOperation);
                                if (isLastProcessStep.HasValue)
                                {
                                    // If it is the last process step reposts the quantity else reports '0':
                                    customERPOperationTracking.UpdateProgress(isLastProcessStep.Value ? moveNextMaterial.PrimaryQuantity.Value : 0, operationDurationDelta, false, moveNextMaterial, CustomUpdateProgressMethodEnum.MoveToNext);
                                }
                            }
                        }
                    }
                }
            }

            //---End DEE Code---

            return Input;
        }


    }
}