﻿using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Exceptions;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Threading;
using System.Xml;

namespace Cmf.Custom.IKEA.Actions.ERP
{
    /// <summary>
    /// This DEE triggers 
    /// </summary>
    public class CustomERPUnknownMessageType : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---


            // MES
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement");
            UseReference("", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects");

            // Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Exceptions");
            UseReference("%MicrosoftNetPath%\\System.Data.dll", "System.Data");
            UseReference("%MicrosoftNetPath%\\System.Private.XML.dll", "");
            UseReference("%MicrosoftNetPath%\\System.XML.dll", "System.Xml");


            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
             
            ILocalizedMessage _localizedMessage = serviceProvider.GetService<ILocalizedMessage>();

            if (Input.ContainsKey(IKEAConstants.IntegrationInput))
            {
                XmlDocument xmlMessage = new XmlDocument();
                xmlMessage.LoadXml(Input[IKEAConstants.IntegrationInput] as string);

                string verbObj = "Undefined";
                if (xmlMessage.ChildNodes[1] != null)
                    verbObj = xmlMessage.ChildNodes[1].Name;

                throw new IKEAException(IKEAConstants.CustomERPUnknownMessageType, verbObj);
            }

            

            //---End DEE Code---
            return null;
        }


        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---

            return true;

            //---End DEE Condition Code---
        }
    }
}
