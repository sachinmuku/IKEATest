﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.MaintenanceManagement.InputObjects;
using Cmf.Navigo.BusinessOrchestration.MaintenanceManagement.OutputObjects;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.ERP.Maintenance
{
    public class CustomERPRequestMaintenance : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text: Creates an IntegrationEntry, if the MaintenanceActivityOrder should by synced with ERP and if it's associated with a Resource.
            ///     
            /// Action Groups: N/A
            /// Depends On: N/A
            /// Is Dependency For: CustomERPRequestMaintenance Rule
            /// Exceptions: N/A
            /// </summary>
            #endregion
            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();


            Collection<string> elligibleActionGroups = new Collection<string>()
            {
                "MaintenanceManagement.MaintenanceManagementOrchestration.RequestMaintenanceActivityOrders.Post"
            };

            bool actionGroupIsValid = IKEADEEActionUtilities.IsActionGroupValid(Input, elligibleActionGroups);

            var executionVerdict = actionGroupIsValid || Input.ContainsKey(Navigo.Common.Constants.MaintenanceActivityOrder);

            if (executionVerdict)
            {
                bool? skipRequestToERP = deeContextUtilities.GetContextParameter(IKEAConstants.CustomERPRequestMaintenanceSkipRequestsToERPContextKey) as bool?;

                if (skipRequestToERP == true)
                {
                    executionVerdict = false;
                }
            }

            return executionVerdict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     



            //System
            UseReference("", "System.Collections.Generic");

            //Foundation
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");

            //Navigo
            UseReference("Cmf.Navigo.Common.dll", "Cmf.Navigo.Common");
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaintenanceManagement.InputObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaintenanceManagement.OutputObjects");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IMaintenanceUtilities erUtilities = serviceProvider.GetService<IMaintenanceUtilities>();

            if (!Input.ContainsKey(Navigo.Common.Constants.MaintenanceActivityOrder))
            {
                RequestMaintenanceActivityOrdersInput input =
                    IKEADEEActionUtilities.GetInputItem<RequestMaintenanceActivityOrdersInput>(Input, "RequestMaintenanceActivityOrdersInput");

                RequestMaintenanceActivityOrdersOutput output =
                    IKEADEEActionUtilities.GetInputItem<RequestMaintenanceActivityOrdersOutput>(Input, "RequestMaintenanceActivityOrdersOutput");

                // Get values for TXT1 , TXT2 and TXT3
                string txt1 = string.Empty;
                string txt2 = string.Empty;
                string txt3 = string.Empty;

                if (input.OperationAttributes != null)
                {
                    IOperationAttribute attributeTXT1 = input.OperationAttributes.Where(o => o.OperationName.Equals("TXT1")).FirstOrDefault();
                    IOperationAttribute attributeTXT2 = input.OperationAttributes.Where(o => o.OperationName.Equals("TXT2")).FirstOrDefault();
                    IOperationAttribute attributeTXT3 = input.OperationAttributes.Where(o => o.OperationName.Equals("TXT3")).FirstOrDefault();

                    if (attributeTXT1 != null && attributeTXT1.Value != null)
                    {
                        txt1 = attributeTXT1.Value.ToString();
                    }

                    if (attributeTXT2 != null && attributeTXT1.Value != null)
                    {
                        txt2 = attributeTXT2.Value.ToString();
                    }
                    if (attributeTXT3 != null)
                    {
                        txt3 = attributeTXT3.Value.ToString();
                    }
                }

                foreach (var maoRequestOutput in output.RequestMaintenanceActivityOrdersOutputs)
                {
                    // Load MaintenanceActivityOrder and add to Comment txt1, txt3 and txt2 values
                    if (!string.IsNullOrEmpty(txt1) || !string.IsNullOrEmpty(txt2) || string.IsNullOrEmpty(txt3))
                    {
                        IMaintenanceActivityOrder mao = maoRequestOutput.MaintenanceActivityOrder;
                        mao.Load();
                        mao.Comment = txt1 + "\n" + txt3 + "\n" + txt2;
                        mao.Save();
                    }

                    erUtilities.CreateERPMaintenanceRequest(maoRequestOutput.MaintenanceActivityOrder, txt1, txt2, txt3);
                }
            }
            else
            {
                IMaintenanceActivityOrder mao = IKEADEEActionUtilities.GetInputItem<IMaintenanceActivityOrder>(Input, Navigo.Common.Constants.MaintenanceActivityOrder);
                mao.Load();
                erUtilities.CreateERPMaintenanceRequest(mao);
            }


            Input.Add("Result", "Success");


            //---End DEE Code---

            return Input;
        }
    }
}

