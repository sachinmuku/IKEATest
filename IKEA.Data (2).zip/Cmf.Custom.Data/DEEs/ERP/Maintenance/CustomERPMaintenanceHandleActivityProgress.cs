﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.ERP.Maintenance;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessOrchestration.GenericServiceManagement.InputObjects;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.MaintenanceManagement.InputObjects;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.ERP.Maintenance
{
    public class CustomERPMaintenanceHandleActivityProgress : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text: This DEE will handle the progress of a MAO (Mainteneance Activity Order), namely:
            /// Start of Activity, Effort Update, added comments, and Acivity completion.   
            /// Action Groups:             
            /// MaintenanceManagement.MaintenanceManagementOrchestration.BeginMaintenanceActivityOrders.Post
            /// MaintenanceManagement.MaintenanceManagementOrchestration.PerformMaintenanceActivityOrder.Post
            /// MaintenanceManagement.MaintenanceManagementOrchestration.CompleteMaintenanceActivityOrders.Post
            /// GenericServiceManagement.GenericServiceManagementOrchestration.WriteComment.Post
            /// BusinessObjects.MaintenanceActivityOrderCollection.Save.Pre
            /// BusinessObjects.MaintenanceActivityOrderCollection.Terminate.Pre
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion
            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();
            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "MaintenanceManagement.MaintenanceManagementOrchestration.BeginMaintenanceActivityOrders.Post",
				"MaintenanceManagement.MaintenanceManagementOrchestration.PerformMaintenanceActivityOrder.Post",
				"MaintenanceManagement.MaintenanceManagementOrchestration.CompleteMaintenanceActivityOrders.Post",
                "GenericServiceManagement.GenericServiceManagementOrchestration.WriteComment.Post",
				"BusinessObjects.MaintenanceActivityOrderCollection.Save.Pre",
				"BusinessObjects.MaintenanceActivityOrderCollection.Terminate.Pre"
			};

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);
			string actionGroup = IKEADEEActionUtilities.GetActionGroup(Input);

			if (executionVeridict && IKEADEEActionUtilities.GetInputItem<BeginMaintenanceActivityOrdersInput>(Input, "BeginMaintenanceActivityOrdersInput") == null
                                  && IKEADEEActionUtilities.GetInputItem<PerformMaintenanceActivityOrderInput>(Input, "PerformMaintenanceActivityOrderInput") == null
                                  && IKEADEEActionUtilities.GetInputItem<CompleteMaintenanceActivityOrdersInput>(Input, "CompleteMaintenanceActivityOrdersInput") == null
                                  && IKEADEEActionUtilities.GetInputItem<IMaintenanceActivityOrderCollection>(Input, "MaintenanceActivityOrderCollection") == null
                                  && IKEADEEActionUtilities.GetInputItem<WriteCommentInput>(Input, "WriteCommentInput") == null)
            {
                executionVeridict = false;
            }


			// If the MAO is being saved from an ERP incoming message (DEE CustomERPCreateMaintenanceActivity), do not report this event back to the ERP.
			bool? preventReporting = deeContextUtilities.GetContextParameter(IKEAConstants.CustomPreventReportingMaoChangesToERPOnFullUpdateObject) as bool?;
            if (preventReporting.GetValueOrDefault())
            {
				executionVeridict = false;
			}


			// Validate only Comments from MaintenanceActivityOrders:
			if (executionVeridict && actionGroup.CompareStrings("GenericServiceManagement.GenericServiceManagementOrchestration.WriteComment.Post"))
			{
				var input = IKEADEEActionUtilities.GetInputItem<WriteCommentInput>(Input, "WriteCommentInput");
				if (input == null || !(input.Object is IMaintenanceActivityOrder))
				{
					executionVeridict = false;
				}
			}

			return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
		{
			//---Start DEE Code---     
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
     

			//System
			UseReference("", "System.Linq");

			//Foundation
			UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration");
			UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects.Abstractions");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.GenericServiceManagement.InputObjects");
            
            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
			UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaintenanceManagement.InputObjects");

			//Common
			UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

			//Custom
			UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
			UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.ERP.Maintenance");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            DeeContext currentContext = deeContextUtilities.SetCurrentServiceContext("CustomMaintenanceHandleActivityProgress");

			switch (currentContext.MethodName)
			{
				case "BeginMaintenanceActivityOrders":
					{
						// The Maintenance Activity Begin in MES. For the ERP it should send an Update with a minimum possible progress.
						BeginMaintenanceActivityOrdersInput beginMAOsInput = IKEADEEActionUtilities.GetInputItem<BeginMaintenanceActivityOrdersInput>(Input, "BeginMaintenanceActivityOrdersInput");

						if (beginMAOsInput != null && !beginMAOsInput.MaintenanceActivityOrders.IsNullOrEmpty())
						{
							// This is DEE is called when MAO is started by the operator
							// It is necessary to set an attribute to identify who started the MAO
							// Complete MAO will use this attribute to define the 'IsToBlockOEE' IoT flag value
							IMaintenanceActivityOrderCollection beginMAOs = beginMAOsInput.MaintenanceActivityOrders;
							IAttributeCollection maosAttributes = new AttributeCollection();
							beginMAOs.Load();
							beginMAOs.LoadAttributes(new Collection<string> { { IKEAConstants.CustomMaoStartedByOperatorAttribute } });
                            beginMAOs.SaveAttributes(new AttributeCollection
							{
								{ 
									IKEAConstants.CustomMaoStartedByOperatorAttribute, 
									true 
								}
							});

							foreach (var beginMAO in beginMAOs)
							{
								if (ikeaUtilities.IsToReportMAOToERP(beginMAO))
								{
									WorkOrderUpdateCommunication workOrderUpdateCommunication = new WorkOrderUpdateCommunication(beginMAO);
									workOrderUpdateCommunication.SendStartWorkOrderToERP();
								}
							}
						}
						break;
					}

				case "PerformMaintenanceActivityOrder":
					{
						PerformMaintenanceActivityOrderInput performMAOInput = IKEADEEActionUtilities.GetInputItem<PerformMaintenanceActivityOrderInput>(Input, "PerformMaintenanceActivityOrderInput");

						if (performMAOInput != null && performMAOInput.MaintenanceActivityOrder != null)
						{
							IMaintenanceActivityOrder performMAO = performMAOInput.MaintenanceActivityOrder;

							if (ikeaUtilities.IsToReportMAOToERP(performMAO))
							{
								WorkOrderUpdateCommunication workOrderUpdateCommunication = new WorkOrderUpdateCommunication(performMAO);
								workOrderUpdateCommunication.SendUpdateWorkOrderToERP(notes: performMAO.Comment, comments: performMAOInput.ServiceComments);
							}
						}
						break;
					}

				case "CompleteMaintenanceActivityOrders":
					{
						CompleteMaintenanceActivityOrdersInput completeMAOsInput = IKEADEEActionUtilities.GetInputItem<CompleteMaintenanceActivityOrdersInput>(Input, "CompleteMaintenanceActivityOrdersInput");

						if (completeMAOsInput != null && !completeMAOsInput.MaintenanceActivityOrders.IsNullOrEmpty())
						{
							IMaintenanceActivityOrderCollection completedMAOs = completeMAOsInput.MaintenanceActivityOrders;

							//In 9 version when there is a MAO complete the terminate is always triggered and this is to prevent two equal reports 
                            string maosNames = deeContextUtilities.GetContextParameter(IKEAConstants.CustomPreventReportingMaoCloseToERPOnCompleteMAO) as string;
							List<string> maosNamesListToNotReport = new List<string>();

                            if (!string.IsNullOrEmpty(maosNames))
							{
                                maosNamesListToNotReport.AddRange(maosNames.Split(';'));
                            }

                            foreach (var completedMAO in completedMAOs)
							{
								if (!maosNamesListToNotReport.Contains(completedMAO.Name) && ikeaUtilities.IsToReportMAOToERP(completedMAO))
								{
									WorkOrderCloseCommunication workOrderCloseCommunication = new WorkOrderCloseCommunication(completedMAO);
									workOrderCloseCommunication.SendCloseWorkOrderToERP();
								}
							}
						}
						break;
					}

				case "Save":
					{
						if (currentContext.TriggerPoint == DeeTriggerPoint.Pre)
						{
							IMaintenanceActivityOrderCollection maoToSaveCollection = IKEADEEActionUtilities.GetInputItem<IMaintenanceActivityOrderCollection>(Input, "MaintenanceActivityOrderCollection");
							if (maoToSaveCollection != null)
							{
								IMaintenanceActivityOrderCollection maoCollection = entityFactory.CreateCollection<IMaintenanceActivityOrderCollection>();
								maoCollection.AddRange(maoToSaveCollection.Select(MS => {var m =entityFactory.Create< IMaintenanceActivityOrder > (); m.Name = MS.Name;return m; }));
								maoCollection.Load();

								foreach (var mao in maoToSaveCollection)
								{
									string notesBefore = maoCollection.Where(M => M.Name.Equals(mao.Name)).FirstOrDefault().Comment;

									if (!mao.Comment.CompareStrings(notesBefore))
									{
										if (ikeaUtilities.IsToReportMAOToERP(mao))
										{
											WorkOrderUpdateCommunication workOrderUpdateCommunication = new WorkOrderUpdateCommunication(mao);
											workOrderUpdateCommunication.SendUpdateWorkOrderToERP(notes: mao.Comment);
										}
									}
								}
							}
						}
						break;
					}

				case "WriteComment":
					{
						WriteCommentInput writeCommentInput = IKEADEEActionUtilities.GetInputItem<WriteCommentInput>(Input, "WriteCommentInput");
						IMaintenanceActivityOrder writeMAO = writeCommentInput.Object as IMaintenanceActivityOrder;
						if (writeMAO != null)
						{
							if (ikeaUtilities.IsToReportMAOToERP(writeMAO))
							{
								WorkOrderUpdateCommunication workOrderUpdateCommunication = new WorkOrderUpdateCommunication(writeMAO);
								workOrderUpdateCommunication.SendUpdateWorkOrderToERP(notes: writeMAO.Comment, comments: writeCommentInput.ServiceComments);
							}
						}
						break;
					}

				case "InternalTerminate":
					{
						IMaintenanceActivityOrderCollection maoToTerminateCollection = IKEADEEActionUtilities.GetInputItem<IMaintenanceActivityOrderCollection>(Input, "MaintenanceActivityOrderCollection");
						if (maoToTerminateCollection != null && maoToTerminateCollection.Count() > 0)
						{
                            List<string> maosNames = maoToTerminateCollection.Select(x => x.Name).ToList();

                            deeContextUtilities.SetContextParameter(IKEAConstants.CustomPreventReportingMaoCloseToERPOnCompleteMAO, string.Join(';', maosNames));

                            foreach (var maoToTerminate in maoToTerminateCollection)
							{
								if (maoToTerminate.UniversalState == Foundation.Common.Base.UniversalState.Active)
								{
									if (ikeaUtilities.IsToReportMAOToERP(maoToTerminate))
									{
										WorkOrderCloseCommunication workOrderCloseCommunication = new WorkOrderCloseCommunication(maoToTerminate);
										workOrderCloseCommunication.SendCloseWorkOrderToERP();
                                    }
								}
							}
						}
						break;
					}
			}

			

			//---End DEE Code---

			return Input;
		}


	}
}
