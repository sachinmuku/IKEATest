﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using Cmf.Custom.IKEA.Common.ERP.Maintenance;
using Cmf.Custom.IKEA.Common.Exceptions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Foundation.Security;
using Cmf.Foundation.Security.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.Abstractions;
using Cmf.Navigo.BusinessOrchestration.MaintenanceManagement.InputObjects;
using Cmf.Navigo.BusinessOrchestration.MaintenanceManagement.OutputObjects;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading;
using System.Xml;

namespace Cmf.Custom.IKEA.Actions.ERP.Maintenance
{
    public class CustomERPCreateMaintenanceActivity : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Action To Handle ERP Message of type SyncServiceOrder
            /// </summary>
            #endregion

            bool executeAction = false;

            if (Input.ContainsKey(IKEAConstants.IntegrationInput) && Input.ContainsKey(IKEAConstants.IntegrationInputName))
            {
                XmlDocument xmlMessage = new XmlDocument();
                xmlMessage.LoadXml(IKEADEEActionUtilities.GetInputItem<string>(Input, IKEAConstants.IntegrationInput));

                executeAction = xmlMessage.SelectNodes(IKEAConstants.SyncServiceOrder).Count > 0;
            }

            return executeAction;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");


            //System
            UseReference("", "Cmf.Navigo.BusinessOrchestration.Abstractions");
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.IO");
            UseReference("", "System.Threading");
            UseReference("", "System");
            UseReference("", "System.Text");
            UseReference("", "System.Globalization");
            UseReference("%MicrosoftNetPath%\\System.XML.XDocument.dll", "");
            UseReference("%MicrosoftNetPath%\\System.XML.ReaderWriter.dll", "");
            UseReference("%MicrosoftNetPath%\\System.Private.XML.dll", "");
            UseReference("%MicrosoftNetPath%\\System.XML.dll", "System.Xml");

            //Foundation
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.Common.dll", "Cmf.Foundation.Common");
            UseReference("Cmf.Foundation.Security.dll", "Cmf.Foundation.Security");

            //Navigo
            UseReference("Cmf.Navigo.Common.dll", "Cmf.Navigo.Common");
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaintenanceManagement");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaintenanceManagement.InputObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaintenanceManagement.OutputObjects");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Exceptions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.ERP.Maintenance");
            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            //IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IMaintenanceUtilities maUtilities = serviceProvider.GetService<IMaintenanceUtilities>();
            ILocalizedMessage _localizedMessage = serviceProvider.GetService<ILocalizedMessage>();
            IGenericUtilities _genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();

            var maintenanceOrchestration = serviceProvider.GetService<IMaintenanceOrchestration>();

            string integrationEntryName = IKEADEEActionUtilities.GetInputItem<string>(Input, IKEAConstants.IntegrationInputName);

            string xmlMessage = IKEADEEActionUtilities.GetInputItem<string>(Input, IKEAConstants.IntegrationInput);

            WorkOrderCreation workOrderCreation = new WorkOrderCreation(xmlMessage);

            // Check if there is a WorkOrderID defined
            if (!string.IsNullOrWhiteSpace(workOrderCreation.WorkOrderID))
            {
                // Get all the MAOs with the WorkOrderID
                IMaintenanceActivityOrderCollection maintenanceActivityOrders = maUtilities.GetMaintenanceActivityOrdersByWorkOrderId(workOrderCreation.WorkOrderID, loadEntities: true, includeTerminated: true);

                List<string> equipmentIds = workOrderCreation.WorkOrderLines.Select(E => E.EquipmentUID).ToList();

                if (!maintenanceActivityOrders.IsNullOrEmpty())
                {
                    // Load MAO attributes
                    maintenanceActivityOrders.LoadAttributes(new Collection<string>() { IKEAConstants.CustomERPEquipmentIdAttribute });

                    // Obtain all the existing MAOs with the given WorkOrderID that contain an Equipment Id that isn't in the ERP Message
                    IMaintenanceActivityOrderCollection maosToBeRemoved = entityFactory.CreateCollection<IMaintenanceActivityOrderCollection>();
                    maosToBeRemoved.AddRange(maintenanceActivityOrders.Where(m => m.UniversalState != Foundation.Common.Base.UniversalState.Terminated
                                                                                && m.HasAttribute(IKEAConstants.CustomERPEquipmentIdAttribute)
                                                                                && m.ExecutionState.In(MaintenanceExecutionStates.Approved, MaintenanceExecutionStates.Requested, MaintenanceExecutionStates.WaitingForAcceptance)
                                                                                && !equipmentIds.Contains(m.GetAttributeValueOrDefault<string>(IKEAConstants.CustomERPEquipmentIdAttribute))));

                    // Reject the MAOs that already exist but are not coming in the Update message
                    if (!maosToBeRemoved.IsNullOrEmpty())
                    {
                        maosToBeRemoved.Cancel();
                    }
                }

                // If we have more than one line it is considered a merged work order
                bool merged = workOrderCreation.WorkOrderLines.Count > 1;

                // Get configured MES MAO type for the given ERP Type and Sub Type
                string mesType = maUtilities.GetMESMaintenanceTypeByERPMainTypeAndSubType(workOrderCreation.WorkOrderType, workOrderCreation.WorkOrderSubType);

                if (!string.IsNullOrWhiteSpace(mesType))
                {

                    IResourceCollection resources = ikeaUtilities.GetResourcesByEquipmentsIds(equipmentIds);

                    if (!resources.IsNullOrEmpty())
                    {
                        resources.LoadAttributes(new Collection<string>() { IKEAConstants.CustomResourceAttributeERPEquipmentIdentifiers });

                        List<long> areaIds = resources.Select(R => R.GetNativeValue<long>(Navigo.Common.Constants.Area)).ToList();
                        IAreaCollection areas = entityFactory.CreateCollection<IAreaCollection>();
                        areas.LoadByIDs<IArea, Area>(areaIds);

                        Dictionary<long, IArea> resourceAreas = areas.ToDictionary(A => A.Id, A => A);

                        List<long> facilityIds = areas.Select(A => A.GetNativeValue<long>(Navigo.Common.Constants.Facility)).ToList();
                        IFacilityCollection facilities = entityFactory.CreateCollection<IFacilityCollection>();
                        facilities.LoadByIDs<IFacility, Facility>(facilityIds);

                        Dictionary<long, IFacility> resourceFacilities = facilities.ToDictionary(F => F.Id, F => F);

                        List<Tuple<IMaintenancePlanInstance, IMaintenanceActivity, WorkOrderCreationDetail>> requestMAOs = new List<Tuple<IMaintenancePlanInstance, IMaintenanceActivity, WorkOrderCreationDetail>>();

                        Dictionary<IMaintenancePlanInstance, IMaintenanceActivityCollection> maintenancePlanInstancesToCreate = new Dictionary<IMaintenancePlanInstance, IMaintenanceActivityCollection>();

                        // Get Approval Role
                        string roleName = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.ERPMaintenanceRoleConfig);

                        if (!string.IsNullOrWhiteSpace(roleName))
                        {
                            Dictionary<MaintenanceExecutionStates, IMaintenanceActivityOrderCollection> actionsToPreformInMAOs = new Dictionary<MaintenanceExecutionStates, IMaintenanceActivityOrderCollection>();

                            Dictionary<IMaintenanceActivityOrder, IAttributeCollection> maintenanceActivityOrdersToUpdate = new Dictionary<IMaintenanceActivityOrder, IAttributeCollection>();

                            // Get all values from the mapping between the ERP and MES Maintenance Status
                            Dictionary<string, MaintenanceExecutionStates> maoStatus = maUtilities.GetMaintenanceActivityOrderStatusByERPStatus();

                            // Get the number of dates that are different
                            int countStartDates = workOrderCreation.WorkOrderLines.GroupBy(l => l.OriginalScheduledStartDateString).Count();

                            double duration = 0;

                            DateTime nextStartDate = workOrderCreation.WorkOrderLines[0].ScheduledStartDate;
                            DateTime nextEndDate = workOrderCreation.WorkOrderLines[0].ScheduledEndDate;

                            // If there are not different dates, we will need to divide the dates per resource
                            if (countStartDates == 1)
                            {
                                duration = Convert.ToDouble((nextEndDate - nextStartDate).TotalHours / resources.Count);

                                nextEndDate = nextStartDate.AddHours(Math.Round(duration, 1));
                            }

                            foreach (WorkOrderCreationDetail detail in workOrderCreation.WorkOrderLines)
                            {
                                string workOrderEquipmentId = detail.EquipmentUID;

                                // Update the schedule start date to the new one
                                if (duration > 0)
                                {
                                    detail.ScheduledStartDate = nextStartDate;
                                    detail.ScheduledEndDate = nextEndDate;
                                }

                                IMaintenanceActivityOrder maintenanceActivityOrder = null;

                                if (!maintenanceActivityOrders.IsNullOrEmpty())
                                {
                                    maintenanceActivityOrder = maintenanceActivityOrders.FirstOrDefault(E => E.GetAttributeValueOrDefault<string>(IKEAConstants.CustomERPEquipmentIdAttribute).CompareStrings(workOrderEquipmentId));
                                }

                                // If no MAO exists for the resource we will need to request a new one
                                if (maintenanceActivityOrder == null)
                                {
                                    IResource resource = resources.FirstOrDefault(E => E.GetAttributeValueOrDefault<List<string>>(IKEAConstants.CustomResourceAttributeERPEquipmentIdentifiers) != null
                                                                                        && E.GetAttributeValueOrDefault<List<string>>(IKEAConstants.CustomResourceAttributeERPEquipmentIdentifiers).Contains(workOrderEquipmentId));

                                    if (resource != null)
                                    {
                                        IArea area = resourceAreas[resource.GetNativeValue<long>(Navigo.Common.Constants.Area)];
                                        string areaName = area.Name;

                                        // Get the configured Maintenance Plan for the resource
                                        IMaintenancePlan maintenancePlan = ikeaUtilities.ResolveCustomERPMaintenancePlansConfiguration(resourceFacilities[area.GetNativeValue<long>(Navigo.Common.Constants.Facility)].Name,
                                                                                                                                        area.Name,
                                                                                                                                        resource.ResourceType,
                                                                                                                                        resource.Name);
                                        // Check if there is a Maintenance Plan configured for the resource
                                        if (maintenancePlan != null)
                                        {
                                            // Load Maintenance Activities from the Maintenance Plan
                                            maintenancePlan.LoadActivities();

                                            IMaintenanceActivity maintenaceActivity = maintenancePlan.MaintenanceActivities.FirstOrDefault(ma => ma.Type == mesType);

                                            if (maintenaceActivity != null)
                                            {
                                                IMaintenancePlanInstanceCollection maintenancePlanInstances = maUtilities.GetMaintenancePlanInstancesForResource(resource.Name, true);

                                                IMaintenancePlanInstance maintenancePlanInstance = null;

                                                if (maintenancePlanInstances != null)
                                                {
                                                    maintenancePlanInstance = maintenancePlanInstances.FirstOrDefault(mpi => mpi.MaintenancePlan.Name.CompareStrings(maintenancePlan.Name));
                                                }

                                                if (maintenancePlanInstance == null)
                                                {
                                                    IRole role = new Role()
                                                    {
                                                        Name = roleName
                                                    };
                                                    role.Load();

                                                    var maintenanceActivityCollection = entityFactory.CreateCollection<IMaintenanceActivityCollection>();
                                                    maintenanceActivityCollection.Add(maintenaceActivity);

                                                    maintenancePlanInstance = entityFactory.Create<IMaintenancePlanInstance>();
                                                    {
                                                        maintenancePlanInstance.MaintenancePlan = maintenancePlan;
                                                        maintenancePlanInstance.OwnerRole = role;
                                                        maintenancePlanInstance.ReferredEntity = resource;


                                                        maintenancePlanInstancesToCreate.Add(maintenancePlanInstance, maintenanceActivityCollection);
                                                    }

                                                  
                                                }
                                                requestMAOs.Add(new Tuple<IMaintenancePlanInstance, IMaintenanceActivity, WorkOrderCreationDetail>(maintenancePlanInstance,
                                                                                                                                                      maintenaceActivity,
                                                                                                                                                      detail));



                                            }
                                            else
                                            {
                                                // Throw error
                                                throw new IKEAException(IKEAConstants.CustomERPMaintenanceIntegrationMATypeDoesNotExistLocalizedMessage, maintenancePlan.Name, mesType);
                                            }

                                        }
                                        else
                                        {
                                            // Throw error
                                            throw new IKEAException(IKEAConstants.CustomERPMaintenanceIntegrationMaintenancePlanNotConfiguredLocalizedMessage, resource.Name);
                                        }

                                    }
                                    else
                                    {
                                        // Throw error
                                        throw new IKEAException(IKEAConstants.CustomERPMaintenanceIntegrationNoResourceFoundLocalizedMessage, workOrderEquipmentId);
                                    }
                                }

                                // If a MAO already exists we will update it
                                else if (maintenanceActivityOrder.UniversalState != Foundation.Common.Base.UniversalState.Terminated)
                                {
                                    // ***********************************************************************************************************
                                    // If activity found, MES will update any predicted fields from ERP: additional comments or new scheduled date
                                    // ***********************************************************************************************************

                                    bool updateMAO = false;
                                    IAttributeCollection attributes = null;

                                    string operationNumber = maintenanceActivityOrder.GetAttributeValueOrDefault<string>(IKEAConstants.CustomWorkOrderOperationNumberAttribute, true);
                                    if (!operationNumber.CompareStrings(detail.OrderLineNumber))
                                    {
                                        updateMAO = true;
                                        attributes = new AttributeCollection()
                                        {
                                            { IKEAConstants.CustomWorkOrderOperationNumberAttribute, detail.OrderLineNumber }
                                        };
                                    }

                                    bool isAdhoc = maintenanceActivityOrder.IsAdhoc ?? false;

                                    Dictionary<string, string> commentsAndNotes = workOrderCreation.GetOrderLineComment(detail.OrderLineNumber, isAdhoc);

                                    string notes = commentsAndNotes[IKEAConstants.CustomMaoNotes];

                                    if (!maintenanceActivityOrder.Comment.CompareStrings(notes))
                                    {
                                        updateMAO = true;

                                        StringBuilder notesToUpdate = new StringBuilder();

                                        maintenanceActivityOrder.Comment = notesToUpdate.AppendLine(maintenanceActivityOrder.Comment ?? string.Empty).AppendLine().AppendLine(notes).ToString();
                                    }

                                    // Comparison is done by string due to a weird comparison error in DateTime that give different Ticks for the same date and time
                                    if (maintenanceActivityOrder.ScheduledDate.GetValueOrDefault().ToString() != detail.ScheduledStartDate.ToString() && detail.ScheduledStartDate.ToUniversalTime() >= DateTime.UtcNow.ToUniversalTime())
                                    {
                                        updateMAO = true;
                                        maintenanceActivityOrder.ScheduledDate = detail.ScheduledStartDate;
                                    }


                                    if (!workOrderCreation.WorkOrderHeaders.IsNullOrEmpty())
                                    {
                                        foreach (var firstWorkOrderHeader in workOrderCreation.WorkOrderHeaders)
                                        {
                                            DateTime customerTimePeriodStartDateTime;
                                            if (DateTime.TryParseExact(firstWorkOrderHeader.CustomerTimePeriodStartDateTime, "yyyy-MM-ddTHH:mm:ss.fffZ", CultureInfo.InvariantCulture, DateTimeStyles.None, out customerTimePeriodStartDateTime))
                                            {
                                                if (customerTimePeriodStartDateTime.CompareTo(maintenanceActivityOrder.ScheduledDate.GetValueOrDefault()) > 0 && customerTimePeriodStartDateTime.CompareTo(DateTime.UtcNow) > 0)
                                                {
                                                    // Value sent by ERP is greater than the one on MES
                                                    updateMAO = true;
                                                    maintenanceActivityOrder.ScheduledDate = customerTimePeriodStartDateTime;
                                                    break;
                                                }
                                            }
                                        }
                                    }

                                    decimal lineDuration = Convert.ToDecimal((detail.ScheduledEndDate - detail.ScheduledStartDate).TotalHours);

                                    if (lineDuration > 0 && maintenanceActivityOrder.ExpectedDuration.GetValueOrDefault() != lineDuration)
                                    {
                                        updateMAO = true;
                                        maintenanceActivityOrder.ExpectedDuration = Math.Round(lineDuration, 1);
                                    }

                                    if (updateMAO)
                                    {
                                        maintenanceActivityOrdersToUpdate.Add(maintenanceActivityOrder, attributes.IsNullOrEmpty() ? null : attributes);
                                    }

                                    // Only proceed if the status has a mapping to the MES status
                                    if (maoStatus.ContainsKey(detail.Status))
                                    {
                                        MaintenanceExecutionStates newStatus = maoStatus[detail.Status];

                                        // Only proceed if the we are dealing with a different state
                                        if (newStatus != maintenanceActivityOrder.ExecutionState)
                                        {
                                            if (actionsToPreformInMAOs.ContainsKey(newStatus))
                                            {
                                                if (actionsToPreformInMAOs[newStatus].IsNullOrEmpty())
                                                {
                                                    actionsToPreformInMAOs[newStatus] = entityFactory.CreateCollection<IMaintenanceActivityOrderCollection>();
                                                }

                                                actionsToPreformInMAOs[newStatus].Add(maintenanceActivityOrder);
                                            }
                                            else
                                            {
                                                var maintenanceActivityOrderCollection = entityFactory.CreateCollection<IMaintenanceActivityOrderCollection>();
                                                maintenanceActivityOrderCollection.Add(maintenanceActivityOrder);
                                                actionsToPreformInMAOs[newStatus] = maintenanceActivityOrderCollection;
                                            }
                                        }
                                    }

                                }

                                if (duration > 0)
                                {
                                    nextStartDate = nextEndDate;
                                    nextEndDate = nextEndDate.AddMinutes(duration);
                                }
                            }

                            #region Create MPIs

                            IMaintenancePlanInstanceCollection maintenancePlanInstancesCreated = null;

                            // If the MPI doesn't exist we need to create it
                            if (!maintenancePlanInstancesToCreate.IsNullOrEmpty())
                            {

                                CreateMaintenancePlanInstancesInput createMaintenancePlanInstancesInput = new CreateMaintenancePlanInstancesInput()
                                {
                                    MaintenancePlanInstances = maintenancePlanInstancesToCreate
                                };

                                maintenancePlanInstancesCreated = maintenanceOrchestration.CreateMaintenancePlanInstances(createMaintenancePlanInstancesInput).MaintenancePlanInstances;
                            }


                            #endregion

                            #region Request MAOs

                            // In case that the MAOs do not exist we need to request them
                            if (!requestMAOs.IsNullOrEmpty())
                            {
                                foreach (var requestMAO in requestMAOs)
                                {
                                    IMaintenancePlanInstance maintenancePlanInstance = requestMAO.Item1;
                                    WorkOrderCreationDetail requestMAODetail = requestMAO.Item3;

                                    // If the Id is 0 it means that the MPI was generated in the step above
                                    if (requestMAO.Item1.Id == 0)
                                    {
                                        IResource resource = resources.FirstOrDefault(E => E.GetAttributeValueOrDefault<List<string>>(IKEAConstants.CustomResourceAttributeERPEquipmentIdentifiers) != null
                                                                                            && E.GetAttributeValueOrDefault<List<string>>(IKEAConstants.CustomResourceAttributeERPEquipmentIdentifiers).Contains(requestMAODetail.EquipmentUID));

                                        if (resource != null)
                                        {
                                            // Obtain the right MPI for the resource
                                            maintenancePlanInstance = maintenancePlanInstancesCreated.FirstOrDefault(mpi => mpi.GetNativeValue<long>(Navigo.Common.Constants.MaintenancePlan) == requestMAO.Item1.GetNativeValue<long>(Navigo.Common.Constants.MaintenancePlan)
                                                                                                                        && mpi.GetNativeValue<long>("ReferredEntity") == resource.Id);
                                        }
                                        else
                                        {
                                            // Throw error
                                            throw new IKEAException(IKEAConstants.CustomERPMaintenanceIntegrationNoResourceFoundLocalizedMessage, requestMAODetail.EquipmentUID);
                                        }
                                    }

                                    // We need to reload the Instance just for the cases where 
                                    // the instance was already used to request another MAO
                                    maintenancePlanInstance.Load();

                                    if (!maoStatus.ContainsKey(requestMAO.Item3.Status))
                                    {
                                        throw new IKEAException(IKEAConstants.CustomERPMaintenanceMissingERPStatusMappingLocalizedMessage, requestMAO.Item3.Status);
                                    }

                                    MaintenanceExecutionStates executionState = maoStatus[requestMAO.Item3.Status];

                                    bool isAdhoc = requestMAO.Item2.ScheduleType == ScheduleType.Adhoc;

                                    Dictionary<string, string> maoComments = workOrderCreation.GetOrderLineComment(requestMAODetail.OrderLineNumber, isAdhoc);

                                    string adhocComment = maoComments[IKEAConstants.CustomMaoAdhocComment];

                                    // Set flag to skip passing the order to the ERP
                                    deeContextUtilities.SetContextParameter(IKEAConstants.CustomERPRequestMaintenanceSkipRequestsToERPContextKey, true);

                                    // Requests are only made for MAOs of type Adhoc
                                    RequestMaintenanceActivityOrdersInput requestMaintenanceActivityOrdersInput = new RequestMaintenanceActivityOrdersInput
                                    {
                                        RequestMaintenanceActivityOrderInput = new Collection<RequestMaintenanceActivityOrderInput>() {
                                            new RequestMaintenanceActivityOrderInput() {
                                                MaintenancePlanInstance = maintenancePlanInstance,
                                                MaintenanceActivity = requestMAO.Item2
                                            }
                                        },
                                        ScheduleDate = requestMAODetail.ScheduledStartDate,
                                        OwnerRole = roleName,
                                        OrderReleaseMode = executionState == MaintenanceExecutionStates.Released ? ReleaseMode.AutoRelease : ReleaseMode.ManualRelease,
                                        RequestApprovalMode = executionState == MaintenanceExecutionStates.Approved || executionState == MaintenanceExecutionStates.Released ? ApprovalMode.AutoApproval : ApprovalMode.ManualApproval,
                                        ServiceComments = adhocComment
                                    };

                                    RequestMaintenanceActivityOrdersOutput requestMaintenanceActivityOrdersOutput = maintenanceOrchestration.RequestMaintenanceActivityOrders(requestMaintenanceActivityOrdersInput);

                                    // Revert the flag
                                    deeContextUtilities.SetContextParameter(IKEAConstants.CustomERPRequestMaintenanceSkipRequestsToERPContextKey, false);

                                    // If it was able to request the MAOs then update the Attributes and the duration
                                    if (!requestMaintenanceActivityOrdersOutput.RequestMaintenanceActivityOrdersOutputs.IsNullOrEmpty())
                                    {
                                        // We can grab only the first MAO because our RequestMaintenanceActivityOrderInput also only has Count = 1
                                        IMaintenanceActivityOrder _maintenanceActivityOrder = requestMaintenanceActivityOrdersOutput.RequestMaintenanceActivityOrdersOutputs[0].MaintenanceActivityOrder;

                                        IAttributeCollection attributes = new AttributeCollection()
                                        {
                                            { IKEAConstants.CustomWorkOrderIdAttribute, workOrderCreation.WorkOrderID },
                                            { IKEAConstants.CustomERPEquipmentIdAttribute, requestMAODetail.EquipmentUID },
                                            { IKEAConstants.CustomWorkOrderOperationNumberAttribute, requestMAODetail.OrderLineNumber }
                                        };

                                        decimal maoDuration = Convert.ToDecimal((requestMAODetail.ScheduledEndDate - requestMAODetail.ScheduledStartDate).TotalHours);

                                        // If the total duration is '0', set a default of 1 hour:
                                        if (maoDuration == 0)
                                        {
                                            _maintenanceActivityOrder.ExpectedDuration = 1;
                                        }
                                        else if (maoDuration > 0 && maoDuration != _maintenanceActivityOrder.ExpectedDuration.GetValueOrDefault())
                                        {
                                            _maintenanceActivityOrder.ExpectedDuration = maoDuration;
                                        }

                                        // For MAO of type Adhoc, update notes
                                        string notes = maoComments[IKEAConstants.CustomMaoNotes];
                                        _maintenanceActivityOrder.Comment = notes;

                                        maintenanceActivityOrdersToUpdate.Add(_maintenanceActivityOrder, attributes);
                                    }
                                }
                            }

                            #endregion

                            #region Update MAOs

                            if (!maintenanceActivityOrdersToUpdate.IsNullOrEmpty())
                            {
                                deeContextUtilities.SetContextParameter(IKEAConstants.CustomPreventReportingMaoChangesToERPOnFullUpdateObject, true);
                                maintenanceActivityOrdersToUpdate.ToDictionary(E => E.Key, E => new Foundation.BusinessOrchestration.FullUpdateParameters() { AttributesToAddOrUpdate = E.Value }).FullUpdateObjects();
                                deeContextUtilities.SetContextParameter(IKEAConstants.CustomPreventReportingMaoChangesToERPOnFullUpdateObject, null);
                            }

                            #endregion

                            #region Apply Update Actions

                            if (!actionsToPreformInMAOs.IsNullOrEmpty())
                            {
                                foreach (KeyValuePair<MaintenanceExecutionStates, IMaintenanceActivityOrderCollection> action in actionsToPreformInMAOs)
                                {
                                    IMaintenanceActivityOrderCollection maintenanceActivityOrdersToPreformAction = action.Value;

                                    if (!maintenanceActivityOrdersToPreformAction.IsNullOrEmpty())
                                    {
                                        switch (action.Key)
                                        {
                                            case MaintenanceExecutionStates.Approved:
                                                maintenanceActivityOrdersToPreformAction.Approve(string.Empty);
                                                break;
                                            case MaintenanceExecutionStates.Released:
                                                maintenanceActivityOrdersToPreformAction.Release(string.Empty);
                                                break;
                                            case MaintenanceExecutionStates.Rejected:
                                                maintenanceActivityOrdersToPreformAction.Reject(string.Empty);
                                                break;
                                            case MaintenanceExecutionStates.InProgress:
                                                maintenanceActivityOrdersToPreformAction.Begin(string.Empty);
                                                break;
                                            case MaintenanceExecutionStates.Closed:

                                                IMaintenanceActivityOrderCollection maosWithoutClosedChecklists = null;
                                                IMaintenanceActivityOrderCollection maosWithoutFilledDataCollection = null;

                                                // Get list of checklist instances Ids
                                                List<long> checklistIds = maintenanceActivityOrdersToPreformAction.Where(m => m.GetNativeValue<long>("CheckListInstance") > 0)
                                                                                                                    .Select(m => m.GetNativeValue<long>("CheckListInstance")).ToList();

                                                if (!checklistIds.IsNullOrEmpty())
                                                {
                                                    // Load checklist instance by Id
                                                    IChecklistInstanceCollection checklistInstancesCollection = entityFactory.CreateCollection<IChecklistInstanceCollection>();
                                                    checklistInstancesCollection.LoadByIDs<IChecklistInstance, ChecklistInstance>(checklistIds);

                                                    // Create a dictionary for the checklist instance
                                                    Dictionary<long, IChecklistInstance> checklistInstances = checklistInstancesCollection.ToDictionary(cl => cl.Id, cl => cl);

                                                    // Get a list of MAOs with checklists not closed
                                                    maosWithoutClosedChecklists = entityFactory.CreateCollection<IMaintenanceActivityOrderCollection>();
                                                    maosWithoutClosedChecklists.AddRange(maintenanceActivityOrdersToPreformAction.Where(mao =>
                                                {
                                                    long checklistInstanceId = mao.GetNativeValue<long>("CheckListInstance");
                                                    return checklistInstances.ContainsKey(checklistInstanceId) && checklistInstances[checklistInstanceId].SystemState != ChecklistInstanceSystemState.Closed;
                                                }).ToList());
                                                }

                                                // Get list of data collection instances Ids
                                                List<long> dataCollectionInstanceIds = maintenanceActivityOrdersToPreformAction.Where(m => m.GetNativeValue<long>(Navigo.Common.Constants.DataCollectionInstance) > 0)
                                                                                                                                .Select(m => m.GetNativeValue<long>(Navigo.Common.Constants.DataCollectionInstance)).ToList();

                                                if (!dataCollectionInstanceIds.IsNullOrEmpty())
                                                {
                                                    // Load data collection instance by Id
                                                    IDataCollectionInstanceCollection dataCollectionInstancesCollection = entityFactory.CreateCollection<IDataCollectionInstanceCollection>();
                                                    dataCollectionInstancesCollection.LoadByIDs<IDataCollectionInstance, DataCollectionInstance>(dataCollectionInstanceIds);

                                                    // Load the Data Collection Points for all data collection instances
                                                    dataCollectionInstancesCollection.LoadRelations(Navigo.Common.Constants.DataCollectionPoint);

                                                    // Create a dictionary for the data collection instance
                                                    Dictionary<long, IDataCollectionInstance> dataCollectionInstances = dataCollectionInstancesCollection.ToDictionary(cl => cl.Id, cl => cl);

                                                    List<long> dataCollectionIds = dataCollectionInstancesCollection.Select(dc => dc.GetNativeValue<long>(Navigo.Common.Constants.DataCollection)).ToList();

                                                    IDataCollectionCollection dataCollectionsCollection = entityFactory.CreateCollection<IDataCollectionCollection>();
                                                    dataCollectionsCollection.LoadByIDs<IDataCollection, DataCollection>(dataCollectionIds);

                                                    // Create a dictionary for the data collection
                                                    Dictionary<long, IDataCollection> dataCollections = dataCollectionsCollection.ToDictionary(cl => cl.Id, cl => cl);

                                                    // Get a list of MAOs with checklists not closed
                                                    maosWithoutFilledDataCollection = entityFactory.CreateCollection<IMaintenanceActivityOrderCollection>();
                                                    maosWithoutFilledDataCollection.AddRange(maintenanceActivityOrdersToPreformAction.Where(mao =>
                                                    {
                                                        long dataCollectionInstanceId = mao.GetNativeValue<long>(Navigo.Common.Constants.DataCollectionInstance);
                                                        return dataCollectionInstances.ContainsKey(dataCollectionInstanceId)
                                                                &&
                                                                (
                                                                    dataCollectionInstances[dataCollectionInstanceId].DataCollectionPoints == null
                                                                    || dataCollectionInstances[dataCollectionInstanceId].DataCollectionPoints.Count != dataCollections[dataCollectionInstances[dataCollectionInstanceId].GetNativeValue<long>(Navigo.Common.Constants.DataCollection)].DataCollectionParameters.Count
                                                                );
                                                    }).ToList());
                                                }

                                                if (!maUtilities.GenerateNotificationsForMAOsWithOpenDCAndCheckLists(maosWithoutClosedChecklists, maosWithoutFilledDataCollection))
                                                {
                                                    IMaintenanceActivityOrderCollection maosToComplete = entityFactory.CreateCollection<IMaintenanceActivityOrderCollection>();

                                                    // Remove the MAOs that cannot be completed
                                                    if (maosWithoutClosedChecklists.IsNullOrEmpty())
                                                    {
                                                        maosWithoutClosedChecklists = entityFactory.CreateCollection<IMaintenanceActivityOrderCollection>();
                                                    }
                                                    if (maosWithoutFilledDataCollection.IsNullOrEmpty())
                                                    {
                                                        maosWithoutFilledDataCollection = entityFactory.CreateCollection<IMaintenanceActivityOrderCollection>();
                                                    }

                                                    maosToComplete.AddRange(maintenanceActivityOrdersToPreformAction.ToList().Except(maosWithoutClosedChecklists).Except(maosWithoutFilledDataCollection));

                                                    // Orders that are in the state Released must be Skipped:
                                                    IMaintenanceActivityOrderCollection maosToCompleteReleased = entityFactory.CreateCollection<IMaintenanceActivityOrderCollection>();
                                                    maosToCompleteReleased.AddRange(maosToComplete.Where(M => M.ExecutionState == MaintenanceExecutionStates.Released));
                                                    if (!maosToCompleteReleased.IsNullOrEmpty())
                                                    {
                                                        maosToCompleteReleased.Skip(string.Empty);
                                                    }

                                                    // Orders that are in the state InProgress must be Completed:
                                                    IMaintenanceActivityOrderCollection maosToCompleteInProgress = entityFactory.CreateCollection<IMaintenanceActivityOrderCollection>();
                                                    maosToCompleteInProgress.AddRange(maosToComplete.Where(M => M.ExecutionState == MaintenanceExecutionStates.InProgress));
                                                    if (!maosToCompleteInProgress.IsNullOrEmpty())
                                                    {
                                                        maosToCompleteInProgress.Complete(string.Empty);
                                                    }
                                                }

                                                break;
                                            case MaintenanceExecutionStates.Skipped:
                                                maintenanceActivityOrdersToPreformAction.Skip(string.Empty);
                                                break;
                                            case MaintenanceExecutionStates.Reworked:
                                            case MaintenanceExecutionStates.ClosedAsJoined:
                                            case MaintenanceExecutionStates.Requested:
                                            case MaintenanceExecutionStates.WaitingForAcceptance:
                                            default:
                                                throw new IKEAException(IKEAConstants.CustomERPMaintenanceIntegrationNotAllowedActionsLocalizedMessage, maintenanceActivityOrdersToPreformAction.ToString());
                                        }
                                    }
                                }
                            }

                            #endregion
                        }
                        else
                        {
                            // Throw error
                            throw new IKEAException(IKEAConstants.CustomERPMaintenanceIntegrationMaintenanceRoleNotConfiguredLocalizedMessage);
                        }
                    }
                    else
                    {
                        // Throw error
                        throw new IKEAException(IKEAConstants.CustomERPMaintenanceIntegrationNoResourceFoundLocalizedMessage, string.Join(",", equipmentIds));
                    }
                }
                else
                {
                    // Throw error
                    throw new IKEAException(IKEAConstants.CustomERPMaintenanceIntegrationNoConfigurationForERPTypeLocalizedMessage, workOrderCreation.WorkOrderType, workOrderCreation.WorkOrderSubType);
                }
            }




            //---End DEE Code---

            return Input;
        }

    }
}
