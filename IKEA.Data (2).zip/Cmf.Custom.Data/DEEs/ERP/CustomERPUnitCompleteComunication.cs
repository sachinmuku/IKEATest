﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.ERP
{
    /// <summary>
    /// This DEE triggers
    /// </summary>
    public class CustomERPUnitCompleteComunication : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---

            #region Info

            /// <summary>
            /// Summary text:
            ///     Report to the ERP the completion of an unit
            /// Action Groups: 
            ///     BusinessObjects.MaterialCollection.TrackOut.Post
            /// </summary>

            #endregion

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];

            IGenericUtilities _genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.MaterialCollection.TrackOut.Post",
                "BusinessObjects.MaterialCollection.MoveToNextStep.Post",
                "MaterialManagement.MaterialManagementOrchestration.ComplexMoveMaterialsToNextStep.Post"
            };

            bool executionVeridict = _genericUtilities.GetConfigurationValueByPath<bool>(IKEAConstants.CustomReportUnitComplete)
                                        && IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---


            //System
            UseReference("", "System");
            UseReference("", "System.Data");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("", "System.Linq");

            // MES
            UseReference("Cmf.Navigo.Common.dll", "Cmf.Navigo.Common");
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            UseReference("Cmf.Foundation.Configuration.dll", "Cmf.Foundation.Configuration");

            // Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");

            System.IServiceProvider serviceProvider = ApplicationContext.CurrentServiceProvider;
            IEntityFactory entityFactory = serviceProvider.GetRequiredService<IEntityFactory>();

            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IERPUtilities erpUtilities = serviceProvider.GetService<IERPUtilities>();
            ILocalizedMessage _localizedMessage = serviceProvider.GetService<ILocalizedMessage>();
            IGenericUtilities _genericUtilities = serviceProvider.GetService<IGenericUtilities>();

            string actionGroup = IKEADEEActionUtilities.GetActionGroup(Input);
            IMaterialCollection trackOutMaterials = IKEADEEActionUtilities.GetInputItem<IMaterialCollection>(Input, Navigo.Common.Constants.MaterialCollection);


            // Check if there are any materials being tracked out
            if (!trackOutMaterials.IsNullOrEmpty())
            {
                ISmartTable smartTable = entityFactory.Create<ISmartTable>();
                smartTable.Load(IKEAConstants.CustomERPReportablePalletTypesSmartTable);
                string reportPalletizationAt = "";
                IMaterialCollection materials = entityFactory.CreateCollection<IMaterialCollection>();
                foreach (IMaterial material in trackOutMaterials)
                {
                    if (material.GetNativeValue<long>(Navigo.Common.Constants.ProductionOrder) <= 0)
                    {
                        continue;
                    }
                    bool? result = ikeaUtilities.ResolveCustomERPReportableTypes(smartTable, material.Facility, ikeaUtilities.GetAreaFromMaterial(material),
                        material.LastProcessedResource, material.Type != null ? material.Type : null, IKEAConstants.CustomERPReportablePalletTypesCollumnUnitComplete);
                    if (result.HasValue && result.Value)
                    {
                        materials.Add(material);
                    }
                    IArea area = ikeaUtilities.GetAreaFromMaterial(material);
                    Dictionary<string, string> reportAt = ikeaUtilities.ResolveCustomERPReportingReportAt(step: material.Step, facility: material.Facility, area: area, resourceName: material.LastProcessedResource != null ? material.LastProcessedResource.Name : null);

                    reportAt.TryGetValue(IKEAConstants.CustomERPReportingResolutionReportPalletizationAtColumn, out reportPalletizationAt);

                }

                string leftOverMaterialType = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.CustomLeftOverMaterialDefaultTypePath);
                IMaterialCollection leftovers = entityFactory.CreateCollection<IMaterialCollection>();
                leftovers.AddRange(trackOutMaterials.Where(m => m.Type == leftOverMaterialType));

                if (!materials.IsNullOrEmpty())
                {
                    bool isNiceLabelEnabled = _genericUtilities.GetConfigurationValueByPath<bool>(IKEAConstants.NiceLabelIsEnabled);

                    // Get all the materials that have product of type semi finished goods
                    string semiFinishedGoodType = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.CustomSemiFinishGoodProductType);
                    bool isSemiFinishedGood = materials.All(m => m.Product.Type == semiFinishedGoodType);


                    if ((!isNiceLabelEnabled || isSemiFinishedGood) && ((actionGroup == "BusinessObjects.MaterialCollection.TrackOut.Post" && reportPalletizationAt == IKEAConstants.CustomERPReportPalletizationAtTrackOut) ||
                                                                        (actionGroup == "BusinessObjects.MaterialCollection.MoveToNextStep.Post" && reportPalletizationAt == IKEAConstants.CustomERPReportPalletizationAtMoveNext) ||
                                                                        (actionGroup == "MaterialManagement.MaterialManagementOrchestration.ComplexMoveMaterialsToNextStep.Post" && reportPalletizationAt == IKEAConstants.CustomERPReportPalletizationAtMoveNext)))


                    {
                        bool force = IKEAConstants.ForceOrderCompletion.Equals(materials.First().GetAttributeValueOrDefault<string>(IKEAConstants.CustomMaterialAttributeProcessLossMotive, true));
                        erpUtilities.ReportUnitComplete(materials, false, force);
                    }
                }
                if (!leftovers.IsNullOrEmpty())
                {
                    erpUtilities.ReportLeftOvers(leftovers);
                }

            }

            //---End DEE Code---
            return null;
        }

    }
}