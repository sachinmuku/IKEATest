﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Exceptions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Foundation.Security;
using Cmf.Foundation.Security.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Threading;
using INotification = Cmf.Foundation.BusinessObjects.Abstractions.INotification;

namespace Cmf.Custom.IKEA.Actions.ERP
{
    /// <summary>
    /// This DEE triggers
    /// </summary>
    public class CustomERPErrorHandler : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---

  

            // MES
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement");
            UseReference("", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects");
            UseReference("", "Cmf.Foundation.Common");
            // Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Exceptions");
            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            INiceLabelUtilities nbUtilities = serviceProvider.GetService<INiceLabelUtilities>();
            IGenericUtilities _genericUtilities = serviceProvider.GetService<IGenericUtilities>();

            string administrationRole = ikeaUtilities.GetValueFromConfigurationWithPath(IKEAConstants.AdministrationRole);
            IRole role = new Role();
            role.Load(administrationRole);
            string distributionList = String.IsNullOrEmpty(role.DistributionList) ?
                ikeaUtilities.GetValueFromConfigurationWithPath(IKEAConstants.LocalSupport) : role.DistributionList;

            string maxRetries = ikeaUtilities.GetValueFromConfigurationWithPath(IKEAConstants.MaxNumberOfRetriesPath);
            int maxRetriesValue = int.Parse(string.IsNullOrEmpty(maxRetries) ? "0" : maxRetries);

            IIntegrationEntry integrationEntry = Input["EdiEvent"] as IIntegrationEntry;
            Exception exError = Input["Error"] as Exception;

            if (!integrationEntry.MessageType.CompareStrings(IKEAConstants.Unknown) && ((integrationEntry.NumberOfRetries ?? -1) + 1) < maxRetriesValue)
            {
                if (integrationEntry.NumberOfRetries == null)
                {
                    integrationEntry.NumberOfRetries = -1;
                    integrationEntry.Save();
                }

                Input["IsRetriable"] = true;
            }
            else
            {
                //Validate if Severity exists in config
                string severity = ikeaUtilities.GetValueFromConfigurationWithPath(IKEAConstants.DefaultNotificationSeverityConfig);

                if (severity.IsNullOrEmpty())
                {
                    throw new IKEAException(IKEAConstants.CustomDefaultNotificationSeverityConfigNotDefined, IKEAConstants.DefaultNotificationSeverityConfig);
                }

                Cmf.Navigo.BusinessObjects.Abstractions.INotification notification = entityFactory.Create<Cmf.Navigo.BusinessObjects.Abstractions.INotification>();
               
                notification.Type = "System";
                notification.Title = ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomNotificationTitleForERPErrorHandler);
                notification.Details = ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomNotificationDetailsForERPErrorHandler
                                , integrationEntry.Name
                                , integrationEntry.MessageType
                                , exError.Message);
                notification.Severity = ikeaUtilities.GetValueFromLookupTable(IKEAConstants.NotificationSeverityLookupTableName, severity, true);
                notification.AssignmentType = (NotificationAssignmentType)AssignmentType.Role;
                notification.AssignedToRole = role;
                notification.SendEmailToAssignedParty = string.IsNullOrEmpty(distributionList);
                notification.EmailDistributionList = distributionList;
                

                notification.Create();

                Input["IsRetriable"] = false;
            }

            

            //---End DEE Code---
            return null;
        }


        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---

            #region Info

            /// <summary>
            /// Summary text
            ///
            /// Action Groups:
            ///
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>

            #endregion

            if (Input != null && Input.ContainsKey("EdiEvent") && Input["EdiEvent"] is IIntegrationEntry)
            {
                return true;
            }

            return false;

            //---End DEE Condition Code---
        }
    }
}