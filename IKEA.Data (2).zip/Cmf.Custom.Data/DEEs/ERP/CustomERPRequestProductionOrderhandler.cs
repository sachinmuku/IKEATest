﻿using Cmf.Common.CustomActionUtilities;

using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.ERP;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.ERP
{
	public class CustomERPRequestProductionOrderHandler : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
	{
		public override bool ValidateAction(Dictionary<string, object> Input)
		{
			//---Start DEE Condition Code---   

			#region Info
			/// <summary>
			/// Summary text: 
			/// Action used by the integration handler when performing a new Production Order request from MES to ERP.
			/// Check smart table IntegrationHandlerResolution    
			/// Action Groups: N/A
			/// Depends On: N/A
			/// Is Dependency For: N/A
			/// Exceptions: N/A
			/// </summary>
			#endregion

			return true;

			//---End DEE Condition Code---
		}

		public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
		{
			//---Start DEE Code---     
     

			//System
			UseReference("", "System");
			UseReference("", "System.Linq");
			UseReference("", "System.Collections.Generic");
			UseReference("%MicrosoftNetPath%\\System.XML.XDocument.dll", "");
			UseReference("%MicrosoftNetPath%\\System.XML.ReaderWriter.dll", "");
			UseReference("%MicrosoftNetPath%\\System.Private.XML.dll", "");
			UseReference("%MicrosoftNetPath%\\System.XML.dll", "System.Xml");

			// Foundation
			UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");

			// Navigo
			UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

			// Custom
			UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
			UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
			UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.ERP");
			UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Extensions");
			

			// Common
			UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
			IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IERPUtilities erbUtilities = serviceProvider.GetService<IERPUtilities>();
            ILocalizedMessage _localizedMessage = serviceProvider.GetService<ILocalizedMessage>();

            IGenericUtilities _genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            //Validate if integration message contains keys: ERP Info and ERPName
            if (Input.ContainsKey(IKEAConstants.IntegrationInput) && Input.ContainsKey(IKEAConstants.IntegrationInputName))
			{
				// Get integration message from input
				string integrationMessage = Input[IKEAConstants.IntegrationInput] as string;

				// Validate if ERPInfo message is set
				if (!string.IsNullOrWhiteSpace(integrationMessage))
				{
					NewProductionOrderRequestCommunication newProductionOrderRequestCommunication;
					try
					{
						// Deserialize the Xml from the integration entry message
						newProductionOrderRequestCommunication = _genericUtilities.DeserializeXmlToObject<NewProductionOrderRequestCommunication>(integrationMessage);
					}
					catch
					{
						throw new Exception("Message is not in the correct format");
					}

					// Validate if MESERPCommunication key is present in ERPInfo
					if (newProductionOrderRequestCommunication != null)
					{
						// Extract API and Message from IntegrationEntry message
						string rawEndpointConfigName = newProductionOrderRequestCommunication.API;
						string rawMessage = newProductionOrderRequestCommunication.Message;

						// Validate API and rawMessage
						if (!string.IsNullOrWhiteSpace(rawEndpointConfigName) && !string.IsNullOrWhiteSpace(rawMessage))
						{
							Dictionary<string, string> message = _genericUtilities.DeserializeObject(rawMessage);

							string config = IKEAConstants.ERPM3Endpoint + rawEndpointConfigName;
							string endpoint = _genericUtilities.GetConfigurationValueByPath<string>(config);

							// Validate if config was successfully extracted
							if (!string.IsNullOrWhiteSpace(endpoint))
							{
								// Call SendERPMessage Utility 
								string result = erbUtilities.SendERPMessage(message, endpoint);

								// Deserialize the response:
								NewProductionOrderResponse response;
								try
								{
									// Get attribute values from the response object
									response = _genericUtilities.DeserializeXmlToObject<NewProductionOrderResponse>(result);
								}
								catch
								{
									throw new Exception("Response is not in the correct format");
								}

								if (response == null)
								{
									throw new Exception("Deserialization failed");
								}

								// Check if response has MFNO field, that holds the order name
								NewProductionOrderResponseNameValue requestOrderResponse = response?.MIRecord?.NameValues?.SingleOrDefault(nv => nv.Name.Equals("MFNO"));

								// Get the value from the response:
								var manufacturingOrderResponse = response.MIRecord.NameValues.SingleOrDefault(nv => nv.Name.Equals("MFNO"));

								//Get the attribute value from the XML object:
								string manufacturingOrderName = manufacturingOrderResponse != null ? manufacturingOrderResponse.Value : null;

								// These Ad-hoc requests can be originated from:
								//    - An optimized GroupMO that is short of some MO
								//    - An Ad-Hoc request made from the Operator Cockpit of a Resource (for rework or repair types)
								// In both cases, the order name in the response is saved to be later available,
								// after ERP releasing the order (SyncProductionOrder).

								// If request is for an optimized GroupMO,
								// load the GroupMO name from the integration entry
								if (!String.IsNullOrWhiteSpace(newProductionOrderRequestCommunication.GroupMoName))
								{
									IMaterial groupMO = entityFactory.Create<IMaterial>();
									groupMO.Load(newProductionOrderRequestCommunication.GroupMoName);

									// Load the attribute ERPRequestedOrders (array) that will hold the name of ht eorder until it is generated by the ERP
									List<string> eRPRequestedOrders = groupMO.GetAttributeValueOrDefault<List<string>>(IKEAConstants.CustomGroupMOERPRequestedOrders, true);

									if (eRPRequestedOrders == null)
									{
										eRPRequestedOrders = new List<string>();
									}

									if (!eRPRequestedOrders.Contains(manufacturingOrderName))
									{
										eRPRequestedOrders.Add(manufacturingOrderName);
									}

									//Save attributes on the optimized GroupMO with the values from ERP
									CustomGroupOrderStateEnum state = eRPRequestedOrders.IsNullOrEmpty() ? CustomGroupOrderStateEnum.Ready : CustomGroupOrderStateEnum.WaitingForERP;
									IAttributeCollection attributes = new AttributeCollection()
										{
											{ IKEAConstants.CustomGroupMOERPRequestedOrders, eRPRequestedOrders },
											{ IKEAConstants.CustomMaterialAttributeGroupOrderState, state }
										};

									groupMO.SaveAttributes(attributes);
								}
								else
								{									
									if (!(string.IsNullOrEmpty(manufacturingOrderName) || !message.ContainsKey(IKEAConstants.WCLN) || string.IsNullOrEmpty(message[IKEAConstants.WCLN])))
									{
										// If the request is an Ad-Hoc order, made from the Operator Cockpit,
										// save the names of resource and order as attributes of the integration entry

										// Get the resource requesting the order
										string resourceName = message[IKEAConstants.WCLN];

										// Save attributes to the integration entry 
										string ieName = Input[IKEAConstants.IntegrationInputName] as string;

										IIntegrationEntry integrationEntry = entityFactory.Create<IIntegrationEntry>();
										integrationEntry.Load(ieName);

										IAttributeCollection attributes = new AttributeCollection()
										{
											{ IKEAConstants.IntegrationEntryAttributeERPRequestPOName, manufacturingOrderName},
											{ IKEAConstants.IntegrationEntryAttributeERPRequestResourceName, resourceName}
										};

										integrationEntry.SaveAttributes(attributes);									
									}
								}

								// Add the message result to the integration entry:
								if (!result.IsNullOrEmpty())
								{
									Input.Add("Result", result);
								}
							}
							else
							{
								throw new Exception("No endpoint found on Configuration: " + config);
							}
						}
						else
						{
							throw new Exception("No API/Message was found");
						}
					}
					else
					{
						throw new Exception("Deserialization failed");
					}
				}
				else
				{
					throw new Exception("Integration Entry ERPInfo is empty");
				}
			}

			
			//---End DEE Code---

			return Input;
		}

	}
}
