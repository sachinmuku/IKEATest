﻿using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.ERP;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Xml;
using Cmf.Common.CustomActionUtilities;

namespace Cmf.Custom.IKEA.Actions.ERP
{
    public class CustomAttachMaterialChangeERPStatus : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text:  If Material to attach type is not listed in LookUp Table
            ///     
            /// Action Groups: BusinessObjects.Resource.AttachConsumables.Post
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.Resource.AttachConsumables.Post"
            };

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            if (executionVeridict && IKEADEEActionUtilities.GetInputItem<Dictionary<IMaterial, IAttachConsumableParameters>>(Input, "Materials") == null)
            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
     

            //System
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("", "System.IO");
            UseReference("", "System.Threading");
            UseReference("", "System");
            UseReference("%MicrosoftNetPath%\\System.XML.dll", "System.Xml");
            UseReference("%MicrosoftNetPath%\\System.XML.Linq.dll", "System.Xml.Linq");
            UseReference("%MicrosoftNetPath%\\System.XML.Linq.dll", "System.Xml.Linq");

            //Foundation
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");

            //Navigo
            UseReference("Cmf.Navigo.Common.dll", "Cmf.Navigo.Common");
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.ERP");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            IMaterialCollection inputMaterials = entityFactory.CreateCollection<IMaterialCollection>();

            inputMaterials.AddRange((Input["Materials"] as Dictionary<IMaterial, IAttachConsumableParameters>).Select(x => x.Key as IMaterial));

            inputMaterials.LoadRelations(Navigo.Common.Constants.MaterialResource);

            inputMaterials.LoadAttributes();

            foreach (IMaterial material in inputMaterials)
            {
                string internalQualityCode = material.GetAttributeValueOrDefault<string>(IKEAConstants.CustomInternalQualityCode);

                // Get Material ERP Original Name
                string erpOriginalName = material.GetAttributeValueOrDefault<string>(IKEAConstants.CustomMaterialAttributeERPOriginalName);

                string materialName = string.IsNullOrWhiteSpace(erpOriginalName) ? material.Name : erpOriginalName;

                ILookupTable ltGoodQualityTypes = new LookupTable();
                ltGoodQualityTypes.Load(IKEAConstants.CustomMaterialGoodQualityTypes);

                if (String.IsNullOrWhiteSpace(internalQualityCode) && !ltGoodQualityTypes.Values.Any(lt => lt.Value.CompareStrings(material.Type)))
                {
                    string reportQualityChangeEndpointConfig = genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.ErpReportQualityChangeEndpointConfig);
                    string internalType = ikeaUtilities.GetTypeFromErpMappingTable(IKEAConstants.MESSystem, 
                                                                                    IKEAConstants.CustomERPColumnsMappingMaterial, 
                                                                                    IKEAConstants.CustomERPColumnsMappingType, 
                                                                                    genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.DefaultGoodTypeConfig), 
                                                                                    IKEAConstants.ERPSystem, 
                                                                                    reportQualityChangeEndpointConfig);

                    // Instantiate the object to be serialized
                    ChangeQualityTypeCommunication changeErpQuality = new ChangeQualityTypeCommunication()
                    {
                        Partner = genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.SupplierCodeConfig),
                        MessageType = genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.MessageTypeCodeConfig),
                        Warehouse = material.Facility.GetAttributeValueOrDefault<string>(IKEAConstants.CustomFaciltyAttributeERPWarehouseLocation, true),
                        Location = material.GetAttributeValueOrDefault<string>(IKEAConstants.CustomMaterialAttributeERPInventoryLocation),
                        ItemNumber = material.Product.GetRelatedAttributeValueOrDefault<string>(IKEAConstants.CustomProductAttributeBaseProduct, true) ?? material.Product.Name,
                        Container = materialName,
                        StatusBalanceID = String.IsNullOrWhiteSpace(internalType) ? "NA" : internalType,
                        Responsible = genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.ErpResponsibleConfig),
                        ProcessFlag = genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.ChangeQualityTypeCommunicationProcessFlag) ?? "*EXE"
                    };

                    // Create the Integration Entry
                    IIntegrationEntry ie = ikeaUtilities.CreateJsonIntegrationEntry(changeErpQuality,
                                                                                    IKEAConstants.ERPReportQualityChange,
                                                                                    IKEAConstants.ERPChangeTypeReportMessageType,
                                                                                    IKEAConstants.ERPChangeTypeReportEventName);

                    if (ie != null && !String.IsNullOrWhiteSpace(internalType))
                    {
                        IAttributeCollection materialAttribute = new AttributeCollection
                            {
                                {IKEAConstants.CustomInternalQualityCode, internalType }
                            };
                        material.SaveAttributes(materialAttribute);
                    }

                }
            }



            



            //---End DEE Code---

            return Input;
        }

       

    }
}
