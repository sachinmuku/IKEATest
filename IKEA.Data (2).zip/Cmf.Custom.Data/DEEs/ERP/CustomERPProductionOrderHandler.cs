﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.BusinessObjects;
using Cmf.Custom.IKEA.BusinessObjects.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Exceptions;
using Cmf.Custom.IKEA.Common.Extensions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessOrchestration.Abstractions;
using Cmf.Foundation.BusinessOrchestration.GenericServiceManagement.InputObjects;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Threading;
using System.Xml;
using System.Xml.Linq;

namespace Cmf.Custom.IKEA.Actions.Generic
{
    public class CustomERPProductionOrderHandler : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Action To Handle ERP Message of type SyncProductionOrder
            /// </summary>
            #endregion

            return true;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---


            //System
            UseReference("", "Cmf.Foundation.BusinessOrchestration.Abstractions");
            UseReference("", "Cmf.Custom.IKEA.BusinessObjects.Abstractions");
            UseReference("", "System");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Linq");
            UseReference("%MicrosoftNetPath%\\System.Data.dll", "System.Data");
            UseReference("%MicrosoftNetPath%\\System.Private.XML.Linq.dll", "");
            UseReference("%MicrosoftNetPath%\\System.XML.XDocument.dll", "");
            UseReference("%MicrosoftNetPath%\\System.XML.ReaderWriter.dll", "");
            UseReference("%MicrosoftNetPath%\\System.Private.XML.dll", "");
            UseReference("%MicrosoftNetPath%\\System.XML.dll", "System.Xml");
            UseReference("%MicrosoftNetPath%\\System.XML.Linq.dll", "System.Xml.Linq");
            UseReference("", "System.Globalization");

            //Foundation
            UseReference("Cmf.Foundation.Common.dll", "Cmf.Foundation.Common");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects.SmartTables");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects.QueryObject");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.TableManagement");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.TableManagement.InputObjects");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.GenericServiceManagement.InputObjects");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.GenericServiceManagement");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Exceptions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            UseReference("Cmf.Custom.IKEA.BusinessObjects.CustomPOOperationResource.dll", "Cmf.Custom.IKEA.BusinessObjects");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Extensions");
            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            IProductionOrderHandlingUtilities phUtilities = serviceProvider.GetService<IProductionOrderHandlingUtilities>();
            ILocalizedMessage _localizedMessage = serviceProvider.GetService<ILocalizedMessage>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();
          

            //  IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();

            var genericServiceOrchestration = serviceProvider.GetService<IGenericServiceOrchestration>();

            if (Input.ContainsKey(IKEAConstants.IntegrationInput) && Input.ContainsKey(IKEAConstants.IntegrationInputName))
            {
                string integrationEntryName = Input[IKEAConstants.IntegrationInputName] as string;
                XmlDocument xmlMessage = new XmlDocument();
                xmlMessage.LoadXml(Input[IKEAConstants.IntegrationInput] as string);
                IProductionOrder po = null;

                if (xmlMessage.SelectNodes(IKEAConstants.SyncProductionOrder).Count > 0)
                {
                    #region Storage variables for xml parsed data

                    string poName = null;
                    string poType = null;
                    string description = null;
                    string plannedStart = null;
                    string plannedEnd = null;
                    string poFacility = null;
                    string poPriority = null;
                    string poDueDate = null;
                    string poStatus = null;
                    string type = null;
                    string priority = null;
                    string plannedQuantity = null;
                    string yieldlessPlannedQuantity = null;
                    string unitCode = null;
                    string resourceName = null;
                    string productName = null;
                    string workCenterName = "";
                    //Attributes
                    string reportingWarehouse = null;
                    string scheduleNumber = null;
                    string textLine1 = null;
                    string textLine2 = null;
                    string structureType = null;
                    string alternateUnits = null;
                    #endregion

                    #region Parse PO Header values

                    poName = xmlMessage.GetValueByXPath(IKEAConstants.DisplayID);

                    po = entityFactory.Create<IProductionOrder>();
                    
                    po.Name = poName;
                    

                    decimal? originalPoQuantity = null;

                    if (po.ObjectExists())
                    {
                        po.Load();
                        originalPoQuantity = po.Quantity;
                    }
                    XmlNodeList xmlN = xmlMessage.SelectNodes(IKEAConstants.UserArea);

                    XElement usrArea = XElement.Parse(xmlN[0].OuterXml);
                    foreach (var element in usrArea.Elements())
                    {
                        switch (((XElement)element.FirstNode).FirstAttribute.Value)
                        {
                            case IKEAConstants.ORTYCode:
                                poType = element.Value;
                                break;
                            case IKEAConstants.FacilityCode:
                                poFacility = element.Value;
                                break;
                            case IKEAConstants.PRIOCode:
                                poPriority = element.Value;
                                break;
                            case IKEAConstants.DUEDCode:
                                poDueDate = element.Value;
                                break;
                            case IKEAConstants.WHSTCode:
                                poStatus = element.Value;
                                break;
                            case IKEAConstants.SCHNCode:
                                scheduleNumber = element.Value;
                                break;
                            case IKEAConstants.TXT1Code:
                                textLine1 = element.Value;
                                break;
                            case IKEAConstants.TXT2Code:
                                textLine2 = element.Value;
                                break;
                            case IKEAConstants.STRTCode:
                                structureType = element.Value;
                                break;
                            case IKEAConstants.MAUNCode:
                                alternateUnits = element.Value;
                                break;

                            default: break;
                        }
                    }

                    //Check if PO Status is eligible for modifications
                    if (phUtilities.ValidatePOStatus(poName, poStatus, integrationEntryName))
                    {
                        reportingWarehouse = xmlMessage.GetValueByXPath(IKEAConstants.ReportingWarehouse);
                        description = xmlMessage.GetValueByXPath(IKEAConstants.PODescription);
                        plannedStart = xmlMessage.GetValueByXPath(IKEAConstants.StartDateTime);
                        plannedEnd = xmlMessage.GetValueByXPath(IKEAConstants.EndDateTime);
                        productName = xmlMessage.GetValueByXPath(IKEAConstants.Product);
                        plannedQuantity = xmlMessage.GetValueByXPath(IKEAConstants.PlannedQuantity);
                        yieldlessPlannedQuantity = xmlMessage.GetValueByXPath(IKEAConstants.OrderBaseUOMQuantity);
                        unitCode = xmlMessage.GetValueByXPath(IKEAConstants.OrderBaseUOMQuantity, "unitCode");

                        // get WorkCenter in XML file if config is true
                        bool validateWorkCenterAtDispatch = genericUtilities.GetConfigurationValueByPath<bool>(IKEAConstants.ValidateWorkCenterAtDispatch);
                        if (validateWorkCenterAtDispatch)
                        {
                            workCenterName = xmlMessage.GetValueByXPath(IKEAConstants.WorkCenterPath);
                        }


                        resourceName = xmlMessage.GetValueByXPath(IKEAConstants.Resource);
                        if (resourceName.IsNullOrEmpty())
                        {
                            resourceName = xmlMessage.GetValueByXPath(IKEAConstants.AdhocResource);
                        }

                        IFacility facility = ikeaUtilities.GetFacilityByERPIdentifier(poFacility);
                        if (facility != null)
                        {
                            facility.Load();
                        }
                        else
                        {
                            throw new IKEAException(IKEAConstants.CustomERPProductionOrderFacilityError, poFacility);
                        }

                        IProduct product = ikeaUtilities.GetLatestRevisionForBaseProduct(productName, loadProducts: true);
                        if (product == null)
                        {
                            throw new IKEAException(IKEAConstants.CustomERPProductionOrderProductError, productName);
                        }

                        IResource resource = ikeaUtilities.GetResurceByName(resourceName);
                        if (resource == null)
                        {
                            throw new IKEAException(IKEAConstants.CustomERPProductionOrderResourceError, resourceName);
                        }

                        string workcenterMainLine = null;
                        if (validateWorkCenterAtDispatch)
                        {
                            workcenterMainLine = workCenterName;
                        }
                        else
                        {
                            // Get the Resource WorkCenter
                            workcenterMainLine = resource.GetAttributeValueOrDefault<string>(IKEAConstants.CustomResourceAttributeWorkCenter, true);
                        }

                        // Resolve the resource to re-route the order
                        string targetResourceMainLine = ikeaUtilities.ResolveReRouteOrder(facility.Name, resource.Area.Name, resource.Name, workcenterMainLine, product.ProductGroup != null ? product.ProductGroup.Name : null, product.Name);

                        if (!string.IsNullOrWhiteSpace(targetResourceMainLine))
                        {
                            resource = ikeaUtilities.GetResurceByName(targetResourceMainLine);
                        }

                        type = ikeaUtilities.GetTypeFromErpMappingTable(IKEAConstants.ERPSystem, IKEAConstants.CustomERPColumnsMappingProductionOrder, IKEAConstants.ORTYCode, poType, IKEAConstants.MESSystem);
                        if (String.IsNullOrEmpty(type))
                        {
                            throw new IKEAException(IKEAConstants.CustomERPProductionOrderErrorType, poType);
                        }

                        priority = ikeaUtilities.GetTypeFromErpMappingTable(IKEAConstants.ERPSystem, IKEAConstants.CustomERPColumnsMappingProductionOrder, IKEAConstants.PRIOCode, poPriority, IKEAConstants.MESSystem);
                        if (String.IsNullOrEmpty(poPriority))
                        {
                            throw new IKEAException(IKEAConstants.CustomERPProductionOrderErrorType, poPriority);
                        }
                        string flowpath = ikeaUtilities.ResolveMaterialFlow(facility, product, resource, type, workcenterMainLine);
                        List<string> lookupUnits = TableHelper.GetLookupTableValues("Units");
                        unitCode = lookupUnits.First(x => String.Equals(x, unitCode, StringComparison.InvariantCultureIgnoreCase));
                        #endregion

                        #region Initialize PO

                        IFlow flow = genericUtilities.GetFlowsInFlowPath(flowpath).FirstOrDefault();
                        IStep step = genericUtilities.GetStepByFlowPath(flowpath);
                        flow.Load();

                        po.Name = poName;
                        po.OrderNumber = poName;
                        po.Description = description;
                        po.Type = type;
                        po.SystemState = ProductionOrderSystemState.Released;
                        po.Facility = facility;
                        po.Product = product;
                        po.RestrictOnComplete = false;
                        po.FlowPath = flowpath;
                        po.Flow = flow;
                        po.Step = step;
                        po.Quantity = Decimal.Parse(plannedQuantity, NumberStyles.Any, CultureInfo.InvariantCulture);
                        po.Units = product.DefaultUnits;
                        po.UnderDeliveryTolerance = 1;
                        po.OverDeliveryTolerance = 1;

                        DateTime dueDateParsed;
                        if (DateTime.TryParseExact(poDueDate, IKEAConstants.DueDateFormat, CultureInfo.InvariantCulture, DateTimeStyles.None, out dueDateParsed))
                        {
                            po.DueDate = dueDateParsed;
                        }
                        int prio;
                        if (int.TryParse(priority, out prio))
                        {
                            po.Priority = prio;
                        }

                        DateTime plannedStartDateDateTime;
                        if (DateTime.TryParse(plannedStart, CultureInfo.InvariantCulture, DateTimeStyles.None, out plannedStartDateDateTime))
                        {
                            po.PlannedStartDate = plannedStartDateDateTime.ToLocalTime();
                        }
                        DateTime plannedEndDateTime;
                        if (DateTime.TryParse(plannedEnd, CultureInfo.InvariantCulture, DateTimeStyles.None, out plannedEndDateTime))
                        {
                            po.PlannedEndDate = plannedEndDateTime.ToLocalTime();
                        }

                        #endregion

                        #region Create PO with CustomPOOperationResource relations

                        XmlNodeList xmlNodes = xmlMessage.SelectNodes(IKEAConstants.Operations);

                        //Create new collection to store relations to add
                        ICustomPOOperationResourceCollection relationsToAdd = entityFactory.CreateCollection<ICustomPOOperationResourceCollection>();

                        #region Iterate through all nodes in UserArea to get the Planned operation qty and planned good qty by operation code
                        // Dictionary to store <Operation Code, <PlannedOperationQuantity,PlannedGoodQuantity> >
                        Dictionary<string, Tuple<string, string>> opCodeORQADictionary = new Dictionary<string, Tuple<string, string>>();

                        // Keep track of the last operation code                        
                        string lastOperationCode = "";

                        // Save the ERP operation Code from the ERP into the PO attribute:
                        string erpOperationCodeOverride = "";

                        // Default value for the ERP Operation code:
                        string erpOperationCodeDefaultValue = "100";

                        foreach (XmlNode node in xmlNodes)
                        {
                            string operationCode = erpOperationCodeDefaultValue;
                            erpOperationCodeOverride = node[IKEAConstants.OperationCode].InnerText;

                            XmlElement outputItem = node["OutputItem"];
                            var userAreaElement = outputItem["UserArea"];
                            XElement userArea = XElement.Parse(userAreaElement.OuterXml);
                            string oRQA = null;
                            foreach (var element in userArea.Elements())
                            {
                                switch (((XElement)element.FirstNode).FirstAttribute.Value)
                                {
                                    case IKEAConstants.ORQA:
                                        oRQA = ((XElement)element.FirstNode).FirstAttribute.Parent.Value;
                                        //Generate entry for (Code, OperationQty, "")
                                        opCodeORQADictionary[operationCode] = Tuple.Create(oRQA, "");
                                        //Second iteration will:
                                        // >populate data for current operation code with  (Code, OperationQty, "")
                                        // >populate data for the last operation code with (Code, OperationQty , LastOperationQty)                  
                                        if (!string.IsNullOrWhiteSpace(lastOperationCode))
                                        {
                                            string plannedOperationQty = opCodeORQADictionary[lastOperationCode].Item1;
                                            opCodeORQADictionary[lastOperationCode] = Tuple.Create(plannedOperationQty, oRQA);
                                        }
                                        break;
                                    default: break;
                                }
                            }
                            lastOperationCode = operationCode;
                        }
                        // This is used to store the good quantity of the last operation code
                        // It will be like (Code, OperationQty, yieldlessPlannedQuantity)
                        if (!string.IsNullOrWhiteSpace(lastOperationCode) && opCodeORQADictionary.ContainsKey(lastOperationCode))
                        {
                            string plannedOperationQty = opCodeORQADictionary[lastOperationCode].Item1;
                            opCodeORQADictionary[lastOperationCode] = Tuple.Create(plannedOperationQty, yieldlessPlannedQuantity);
                        }

                        #endregion

                        Dictionary<string, IResource> operationResources = new Dictionary<string, IResource>();

                        foreach (XmlNode node in xmlNodes)
                        {
                            string operationResourceName;
                            string originalResource = String.Empty;

                            string operationCode = erpOperationCodeDefaultValue;

                            XmlElement outputItem = node["OutputItem"];
                            var userAreaElement = outputItem["UserArea"];
                            XElement userArea = XElement.Parse(userAreaElement.OuterXml);
                            string cTCD = null;
                            string iPTUN = null;
                            string pITI = null;
                            string mSTI = null;
                            string sTDT = null;
                            string mFTI = null;
                            string fIDT = null;
                            string productionLine = null;

                            foreach (var element in userArea.Elements())
                            {
                                switch (((XElement)element.FirstNode).FirstAttribute.Value)
                                {
                                    case IKEAConstants.CTCD:
                                        cTCD = ((XElement)element.FirstNode).FirstAttribute.Parent.Value;
                                        break;
                                    case IKEAConstants.iPTUN:
                                        iPTUN = ((XElement)element.FirstNode).FirstAttribute.Parent.Value;
                                        break;
                                    case IKEAConstants.PITI:
                                        pITI = ((XElement)element.FirstNode).FirstAttribute.Parent.Value;
                                        break;
                                    case IKEAConstants.MSTI:
                                        mSTI = ((XElement)element.FirstNode).FirstAttribute.Parent.Value;
                                        break;
                                    case IKEAConstants.STDT:
                                        sTDT = ((XElement)element.FirstNode).FirstAttribute.Parent.Value;
                                        break;
                                    case IKEAConstants.MFTI:
                                        mFTI = ((XElement)element.FirstNode).FirstAttribute.Parent.Value;
                                        break;
                                    case IKEAConstants.FIDT:
                                        fIDT = ((XElement)element.FirstNode).FirstAttribute.Parent.Value;
                                        break;
                                    case IKEAConstants.PLGR:
                                        originalResource = ((XElement)element.FirstNode).FirstAttribute.Parent.Value;
                                        break;
                                    case IKEAConstants.WCLN:
                                        productionLine = ((XElement)element.FirstNode).FirstAttribute.Parent.Value;
                                        break;

                                    default: break;
                                }
                            }

                            DateTime? stDate = phUtilities.ConvertStringToDateTime(sTDT.TrimStart("00"), mSTI.PadLeft(4, '0'), "yyyyMMddHHmm");
                            DateTime? endDate = phUtilities.ConvertStringToDateTime(fIDT.TrimStart("00"), mFTI.PadLeft(4, '0'), "yyyyMMddHHmm");

                            int iPTUNInt;
                            if (!Int32.TryParse(iPTUN, out iPTUNInt))
                            {
                                iPTUNInt = Int32.Parse(iPTUN, System.Globalization.CultureInfo.InvariantCulture);
                            }

                            decimal pITIDecimal;
                            if (!decimal.TryParse(pITI, out pITIDecimal))
                            {
                                pITIDecimal = Convert.ToDecimal(pITI, System.Globalization.CultureInfo.InvariantCulture);
                            }

                            decimal cTCDDecimal;
                            if (!decimal.TryParse(cTCD, out cTCDDecimal))
                            {
                                cTCDDecimal = Convert.ToDecimal(cTCD, System.Globalization.CultureInfo.InvariantCulture);
                            }

                            switch (iPTUNInt)
                            {
                                case 1:
                                    pITIDecimal *= 3600;
                                    break;
                                case 2:
                                    pITIDecimal *= 60;
                                    break;
                                case 3:
                                    break;
                            }
                            IResource operationResource = entityFactory.Create<IResource>();
                            decimal projectedCycleTime = pITIDecimal != 0 ? (cTCDDecimal / pITIDecimal) : 0;

                            //if WCLN is not empty we have custom Production Line
                            if (!string.IsNullOrEmpty(productionLine))
                            {
                                operationResource = ikeaUtilities.GetResurceByName(productionLine);
                                originalResource = productionLine;
                            }
                            else
                            {
                                operationResource = ikeaUtilities.GetResurceByName(originalResource);
                            }

                            string workcenter = null;
                            if (validateWorkCenterAtDispatch)
                            {
                                workcenter = workCenterName;
                            }
                            else
                            {
                                // Get the Resource WorkCenter
                                workcenter = operationResource.GetAttributeValueOrDefault<string>(IKEAConstants.CustomResourceAttributeWorkCenter, true);
                            }

                            // Resolve the resource to re-route the order
                            string targetResource = ikeaUtilities.ResolveReRouteOrder(facility.Name,
                                                                                      operationResource.Area.Name
                                                                                      , operationResource.Name,
                                                                                      workcenter,
                                                                                      product.ProductGroup != null ? product.ProductGroup.Name : null,
                                                                                      product.Name);


                            if (!string.IsNullOrWhiteSpace(targetResource))
                            {
                                // If there is any resource to re-route the order, use that resource as the operation resource otherwise use the original
                                operationResourceName = !string.IsNullOrWhiteSpace(targetResource) ? targetResource : originalResource;

                                operationResource = ikeaUtilities.GetResurceByName(operationResourceName);
                            }

                            // Check if the resource exists
                            if (operationResource == null)
                            {
                                throw new IKEAException(IKEAConstants.CustomERPProductionOrderResourceError, resourceName);
                            }

                            operationResources.Add(operationCode, operationResource);

                            // Create Relation
                            ICustomPOOperationResource productionOrderOperationResource =entityFactory.Create<ICustomPOOperationResource>();

                            productionOrderOperationResource.SourceEntity = po;
                            productionOrderOperationResource.TargetEntity = operationResource;
                            productionOrderOperationResource.OperationCode = operationCode;
                            productionOrderOperationResource.ProjectedCycleTime = projectedCycleTime;
                            productionOrderOperationResource.StartTime = stDate.Value;
                            productionOrderOperationResource.EndTime = endDate.Value;
                            productionOrderOperationResource.OriginalResourceToReport = originalResource;

                            #region Setup planned operation and good quantity

                            if (opCodeORQADictionary.ContainsKey(operationCode))
                            {
                                decimal PlannedOperationQuantity;
                                if (!decimal.TryParse(opCodeORQADictionary[operationCode].Item1, out PlannedOperationQuantity))
                                {
                                    PlannedOperationQuantity = Convert.ToDecimal(opCodeORQADictionary[operationCode].Item1, System.Globalization.CultureInfo.InvariantCulture);
                                }
                                productionOrderOperationResource.PlannedOperationQuantity = PlannedOperationQuantity;
                                decimal PlannedGoodQuantity;

                                if (!decimal.TryParse(opCodeORQADictionary[operationCode].Item2, out PlannedGoodQuantity))
                                {
                                    PlannedGoodQuantity = Convert.ToDecimal(opCodeORQADictionary[operationCode].Item2, System.Globalization.CultureInfo.InvariantCulture);
                                }
                                productionOrderOperationResource.PlannedGoodQuantity = PlannedGoodQuantity;
                            }

                            #endregion

                            relationsToAdd.Add(productionOrderOperationResource);

                            lastOperationCode = operationCode;
                        }
                        #endregion

                        IAttributeCollection attribtesToAdd = new AttributeCollection
                        {
                            { IKEAConstants.CustomProductionOrderAttributeDefaultWorkCenter, workCenterName },
                            { IKEAConstants.CustomProductionOrderAttributeReportingWarehouse, reportingWarehouse },
                            { "YieldlessPlannedQuantity", Decimal.Parse(yieldlessPlannedQuantity, NumberStyles.Any, CultureInfo.InvariantCulture) },
                            { "ScheduleNumber", scheduleNumber },
                            { IKEAConstants.CustomERPOperationCodeOverride, erpOperationCodeOverride }
                        };
                        if (!string.IsNullOrWhiteSpace(textLine1))
                        {
                            attribtesToAdd.Add("TextLine1", textLine1);
                        }

                        if (!string.IsNullOrWhiteSpace(textLine2))
                        {
                            attribtesToAdd.Add("TextLine2", textLine2);
                        }

                        attribtesToAdd.Add(IKEAConstants.CustomProductionOrderAttributeStructureType, structureType);

                        //If we are dealing with an Existing PO and want need to Update the quantities
                        if (po.ObjectExists())
                        {
                            po.LoadMaterials();

                            if (!po.Materials.IsNullOrEmpty())
                            {
                                // Update Material Flowpath
                                Dictionary<IMaterial, string> materialFlowPaths = po.Materials.Where(material => material.FlowPath != flowpath).ToDictionary(material => material, material => flowpath);
                                if (!materialFlowPaths.IsNullOrEmpty())
                                {
                                    po.Materials.ChangeFlowAndStep(materialFlowPaths, "ChangeFlowAndStep", null);
                                }

                                // Check if there is any relation to be added
                                if (!relationsToAdd.IsNullOrEmpty())
                                {
                                    po.LoadRelations(IKEAConstants.CustomPOOperationResource);

                                    // Check if already exists relations between the production order and the resource
                                    if (po.RelationCollection != null && po.RelationCollection.ContainsKey(IKEAConstants.CustomPOOperationResource))
                                    {
                                        // Get the relations of the PO
                                        ICustomPOOperationResourceCollection customPOOperationResources = entityFactory.CreateCollection<ICustomPOOperationResourceCollection>();
                                        customPOOperationResources.AddRange(po.RelationCollection[IKEAConstants.CustomPOOperationResource].Select(r => r as ICustomPOOperationResource));

                                        // Get relations to be removed
                                        ICustomPOOperationResourceCollection customPOOperationResourcesRemove = entityFactory.CreateCollection<ICustomPOOperationResourceCollection>();
                                        customPOOperationResourcesRemove.AddRange(customPOOperationResources.Where(p => !relationsToAdd.Any(p2 => p2.GetNativeValue<long>("TargetEntity") == p.GetNativeValue<long>("TargetEntity"))));

                                        // Get relations to be add
                                        ICustomPOOperationResourceCollection customPOOperationResourcesAdd = entityFactory.CreateCollection<ICustomPOOperationResourceCollection>();
                                        customPOOperationResourcesAdd.AddRange(relationsToAdd.Where(p => !customPOOperationResources.Any(p2 => p2.GetNativeValue<long>("TargetEntity") == p.GetNativeValue<long>("TargetEntity"))));

                                        ICustomPOOperationResourceCollection customPOOperationResourcesUpdate = entityFactory.CreateCollection<ICustomPOOperationResourceCollection>();

                                        foreach (ICustomPOOperationResource pOOperationResource in relationsToAdd)
                                        {
                                            ICustomPOOperationResource customPOOperationResourceUpdate = customPOOperationResources.FirstOrDefault(p => pOOperationResource.GetNativeValue<long>("TargetEntity") == p.GetNativeValue<long>("TargetEntity"));

                                            // Get relations to Update
                                            if
                                            (
                                                customPOOperationResourceUpdate != null
                                                &&
                                                (
                                                    customPOOperationResourceUpdate.ProjectedCycleTime != pOOperationResource.ProjectedCycleTime
                                                    || customPOOperationResourceUpdate.PlannedOperationQuantity != pOOperationResource.PlannedOperationQuantity
                                                    || customPOOperationResourceUpdate.PlannedGoodQuantity != pOOperationResource.PlannedGoodQuantity
                                                    || customPOOperationResourceUpdate.OriginalResourceToReport != pOOperationResource.OriginalResourceToReport
                                                    || customPOOperationResourceUpdate.OperationCode != pOOperationResource.OperationCode
                                                    || customPOOperationResourceUpdate.EndTime != pOOperationResource.EndTime
                                                    || customPOOperationResourceUpdate.StartTime != pOOperationResource.StartTime
                                                )
                                            )
                                            {
                                                customPOOperationResourceUpdate.ProjectedCycleTime = pOOperationResource.ProjectedCycleTime;
                                                customPOOperationResourceUpdate.PlannedOperationQuantity = pOOperationResource.PlannedOperationQuantity;
                                                customPOOperationResourceUpdate.PlannedGoodQuantity = pOOperationResource.PlannedGoodQuantity;
                                                customPOOperationResourceUpdate.OriginalResourceToReport = pOOperationResource.OriginalResourceToReport;
                                                customPOOperationResourceUpdate.OperationCode = pOOperationResource.OperationCode;
                                                customPOOperationResourceUpdate.EndTime = pOOperationResource.EndTime;
                                                customPOOperationResourceUpdate.StartTime = pOOperationResource.StartTime;

                                                customPOOperationResourcesUpdate.Add(customPOOperationResourceUpdate);
                                            }
                                        }
                                       
                                        // Add, Remove and Update relations
                                        FullUpdateObjectInput fullUpdateObjectInput = new FullUpdateObjectInput()
                                        {
                                            Object = po,
                                            //FullUpdateParameters = new Foundation.BusinessOrchestration.FullUpdateParameters()
                                            //{
                                            //    RelationsToRemove = serviceProvider.GetService<IEntityRelationCollection<IEntityRelation>>().AddRange(customPOOperationResourcesRemove),
                                            //    RelationsToAdd = (IEntityRelationCollection<IEntityRelation>)customPOOperationResourcesAdd,
                                            //    RelationsToUpdate = (IEntityRelationCollection<IEntityRelation>)customPOOperationResourcesUpdate
                                            //}
                                        };
                                        fullUpdateObjectInput.FullUpdateParameters = new Foundation.BusinessOrchestration.FullUpdateParameters();
                                        fullUpdateObjectInput.FullUpdateParameters.RelationsToRemove = serviceProvider.GetService<IEntityRelationCollection<IEntityRelation>>();
                                        fullUpdateObjectInput.FullUpdateParameters.RelationsToRemove.AddRange(customPOOperationResourcesRemove);
                                        fullUpdateObjectInput.FullUpdateParameters.RelationsToAdd = serviceProvider.GetService<IEntityRelationCollection<IEntityRelation>>();
                                        fullUpdateObjectInput.FullUpdateParameters.RelationsToAdd.AddRange(customPOOperationResourcesAdd);
                                        fullUpdateObjectInput.FullUpdateParameters.RelationsToUpdate = serviceProvider.GetService<IEntityRelationCollection<IEntityRelation>>();
                                        fullUpdateObjectInput.FullUpdateParameters.RelationsToUpdate.AddRange(customPOOperationResourcesUpdate);

                                        genericServiceOrchestration.FullUpdateObject(fullUpdateObjectInput);

                                        if (!customPOOperationResourcesRemove.IsNullOrEmpty()
                                            && customPOOperationResourcesRemove.Count == customPOOperationResourcesAdd.Count
                                            && po.Materials.Any(m => m.SystemState == MaterialSystemState.Dispatched))
                                        {
                                            IMaterialCollection materials = entityFactory.CreateCollection<IMaterialCollection>();
                                            materials.AddRange(po.Materials.Where(m => m.SystemState == MaterialSystemState.Dispatched));
                                            if (!materials.IsNullOrEmpty())
                                            {
                                                    materials.LoadRelations("MaterialResource");

                                                    foreach (var removedRelation in customPOOperationResourcesRemove.Select(r => r as ICustomPOOperationResource))
                                                    {
                                                        int removedFromPosition = customPOOperationResources.IndexOf(removedRelation);

                                                        IResource addedResource = customPOOperationResourcesAdd[removedFromPosition].TargetEntity as IResource;

                                                        // Validate if resource has AutoDispatch flag enabled
                                                        bool resourceHasAutoDispatch = addedResource.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomAutomaticDispatch, true);
                                                        if (resourceHasAutoDispatch)
                                                        {
                                                            IMaterialCollection materialsToUndispatch = entityFactory.CreateCollection<IMaterialCollection>();
                                                            materialsToUndispatch.AddRange(materials.Where(m => m.RelationCollection.ContainsKey("MaterialResource")
                                                                                                                && m.RelationCollection["MaterialResource"].Select(r => r as IMaterialResource)
                                                                                                                                                            .Any(r => r.GetNativeValue<long>("TargetEntity") == removedRelation.GetNativeValue<long>("TargetEntity"))));

                                                            materialsToUndispatch.Undispatch();

                                                            foreach (IMaterial material in materialsToUndispatch)
                                                            {
                                                                ikeaUtilities.CustomAutoDispatchUtility(material, addedResource);
                                                            }
                                                        }
                                                    }
                                                }
                                        }
                                    }
                                    else
                                    {
                                        po.AddRelations(relationsToAdd);
                                    }
                                }
                            }

                            decimal multiplicator = po.Quantity.Value / originalPoQuantity.Value;

                            po.LoadMaterials();
                            string orderForm = ikeaUtilities.GetOrderMaterialForm();
                            po.Materials.LoadAttributes();
                            IMaterialCollection moMaterials = entityFactory.CreateCollection<IMaterialCollection>();

                            moMaterials.AddRange(po.Materials.Where(E => String.Equals(E.Form, orderForm, StringComparison.InvariantCultureIgnoreCase)));

                            IProduct prod = po.Product;
                            prod.Load();
                            moMaterials.Load();
                            IMaterialQuantityChangeCollection materialQuantities = new MaterialQuantityChangeCollection();
                            if (moMaterials.Count > 0)
                            {
                                int i = 0;
                                int allMaterialsQty = 0;
                                foreach (IMaterial moMaterial in moMaterials)
                                {

                                    //Step Allow decimal qty, Values have decimals
                                    if (!prod.IsDiscrete.HasValue || !prod.IsDiscrete.Value)
                                    {
                                        IMaterialQuantityChange materialQuantity = new MaterialQuantityChange()
                                        {
                                            Material = moMaterial,
                                            NewPrimaryQuantity = moMaterial.PrimaryQuantity * multiplicator,
                                            NewSecondaryQuantity = 0
                                        };

                                        materialQuantities.Add(materialQuantity);
                                    }
                                    else
                                    {
                                        //Values are int, and the last Material have the remaining missing quantity to reach the PO quantity

                                        IMaterialQuantityChange materialQuantity = new MaterialQuantityChange()
                                        {
                                            Material = moMaterial,
                                            NewPrimaryQuantity = Decimal.ToInt32(Math.Abs(moMaterial.PrimaryQuantity.Value * multiplicator)),
                                            NewSecondaryQuantity = 0
                                        };
                                        allMaterialsQty += Decimal.ToInt32(materialQuantity.NewPrimaryQuantity.Value);

                                        if (i >= moMaterials.Count() - 1 && moMaterials.Count() > 1)
                                        {
                                            materialQuantity.NewPrimaryQuantity += po.Quantity.Value - allMaterialsQty;
                                        }
                                        materialQuantities.Add(materialQuantity);
                                        i++;
                                    }
                                }
                            }

                            po.SaveAttributes(attribtesToAdd);
                            po.Save();
                            po.Load();
                            //Change Material Quantities
                            if (!materialQuantities.IsNullOrEmpty())
                            {
                                moMaterials.ChangeQuantity(materialQuantities, null);
                            }
                        }
                        else
                        {
                            po.Attributes[IKEAConstants.CustomProductionOrderAttributeReportingWarehouse] = reportingWarehouse;
                            po.Attributes["YieldlessPlannedQuantity"] = Decimal.Parse(yieldlessPlannedQuantity, NumberStyles.Any, CultureInfo.InvariantCulture);
                            po.Attributes["ScheduleNumber"] = scheduleNumber;
                            po.Attributes["TextLine2"] = textLine2;
                            po.Attributes["TextLine1"] = textLine1;
                            po.Attributes[IKEAConstants.CustomProductionOrderAttributeStructureType] = structureType;
                            po.Attributes[IKEAConstants.CustomERPOperationCodeOverride] = erpOperationCodeOverride;

                            if (po.RelationCollection.IsNullOrEmpty())
                            {
                                var relationsToAddCollection = serviceProvider.GetService<ICmfEntityRelationCollection>();
                                relationsToAddCollection.Add(relationsToAdd);
                                po.RelationCollection = relationsToAddCollection;
                            }
                            else
                            {
                                po.RelationCollection.Add(relationsToAdd);
                            }


                            // For preventing the order to be dispatched automatically if it is an MO for a GroupMO:
                            DataSet groupMOToAdd = ikeaUtilities.GetGroupMOToAdd(po.Name);
                            bool hasData = (groupMOToAdd != null && groupMOToAdd.Tables.Count > 0 && groupMOToAdd.Tables[0].Rows.Count > 0);
                            if (hasData)
                            {
                                deeContextUtilities.SetContextParameter("CustomERPProductionOrderHandler_PreventToAutoDispatch", true);
                            }

                            po.Create();

                            if (hasData)
                            {
                                var material = entityFactory.Create<IMaterial>();
                                material.Name = po.Name;
                                // Check if this mo/po is related to a group MO and Add it to the group if expected
                                ikeaUtilities.AddMOToGroup(groupMOToAdd, material);

                                // Clear context:
                                deeContextUtilities.SetContextParameter("CustomERPProductionOrderHandler_PreventToAutoDispatch", null);
                            }

                        }

                        foreach (XmlNode node in xmlNodes)
                        {
                            string operationCode = erpOperationCodeDefaultValue;

                            IResource operationResource = operationResources[operationCode];

                            var mainFlow = genericUtilities.GetFlowsInFlowPath(flowpath).FirstOrDefault();
                            IFlow newFlow = ikeaUtilities.GetFlowWithERPOperationCode(mainFlow, operationCode);

                            IFlowStep flowStep = genericUtilities.GetFirstOrLastFlowStepFromFlow(newFlow, true);

                            // BOM resolution
                            ikeaUtilities.BOMResolution(po, node, operationResource, facility, flowStep, workCenterName);

                        }

                    }
                }
            }

            
            //---End DEE Code---

            return Input;
        }

    }
}
