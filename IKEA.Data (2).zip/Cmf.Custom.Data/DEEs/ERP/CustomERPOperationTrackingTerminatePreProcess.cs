﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.BusinessObjects;
using Cmf.Custom.IKEA.BusinessObjects.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Extensions;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.ERP
{
    public class CustomERPOperationTrackingTerminatePreProcess : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

           UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
  

            #region Info
            /// <summary>
            /// Summary text
            /// This DEE reports to ERP all remaining materials when the CustomERPOperationTracking entities are terminated
            /// Action Groups:
            ///             BusinessObjects.CustomERPOperationTrackingCollection.Terminate.Pre
            ///             BusinessObjects.CustomERPOperationTracking.Terminate.Pre
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion
            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            
            IGenericUtilities _genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();
            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.CustomERPOperationTrackingCollection.Terminate.Pre",
                "BusinessObjects.CustomERPOperationTracking.Terminate.Pre"
            };

            bool executionVeridict = _genericUtilities.GetConfigurationValueByPath<bool>(IKEAConstants.CustomReportUnitComplete) && IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            return executionVeridict;
            
            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
     

            //System
            UseReference("", "Cmf.Custom.IKEA.BusinessObjects.Abstractions");
UseReference("", "System");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("", "System.IO");
            UseReference("", "System.Linq");
            UseReference("", "System.Threading");
            //Foundation
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects");
            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Extensions");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            UseReference("Cmf.Custom.IKEA.BusinessObjects.CustomERPOperationTrackingConsumptionLog.dll", "Cmf.Custom.IKEA.BusinessObjects");
            UseReference("Cmf.Custom.IKEA.BusinessObjects.CustomERPOperationTracking.dll", "Cmf.Custom.IKEA.BusinessObjects");
            UseReference("Cmf.Custom.IKEA.BusinessObjects.CustomPOERPOperationTracking.dll", "Cmf.Custom.IKEA.BusinessObjects");
            UseReference("Cmf.Custom.IKEA.BusinessObjects.CustomPOOperationResource.dll", "Cmf.Custom.IKEA.BusinessObjects");
            UseReference("Cmf.Custom.IKEA.BusinessObjects.CustomERPOperationTrackingConsumptionLog.dll", "Cmf.Custom.IKEA.BusinessObjects");
            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();

            // Get all operation tracking entities:
            ICustomERPOperationTrackingCollection operationTrackingCollection =entityFactory.CreateCollection< ICustomERPOperationTrackingCollection>();

            // Get all operation tracking entities from Collection:
            if (Input.ContainsKey("CustomERPOperationTrackingCollection"))
            {
                operationTrackingCollection = Input["CustomERPOperationTrackingCollection"] as ICustomERPOperationTrackingCollection;
            }

            // Get all operation tracking entities from Singular:
            if (Input.ContainsKey("CustomERPOperationTracking"))
            {
                operationTrackingCollection.Add(Input["CustomERPOperationTracking"] as ICustomERPOperationTracking);
            }

            foreach (ICustomERPOperationTracking operationTracking in operationTrackingCollection)
            {
                if (operationTracking.UniversalState != Cmf.Foundation.Common.Base.UniversalState.Terminated)
                {
                    // Load all relations for getting the PO (relation source):
                    operationTracking.LoadRelations("CustomPOERPOperationTracking");
                    if (!operationTracking.RelationCollection.IsNullOrEmpty())
                    {

                        // Checks if the PO exists:
                        IProductionOrder productionOrder = operationTracking.RelationCollection["CustomPOERPOperationTracking"].Select(ot => (ot as ICustomPOERPOperationTracking).SourceEntity).FirstOrDefault();
                        if (productionOrder != null)
                        {
                            operationTracking.ReportConsumption();

                            // Get all ConsumptionLogs and terminate them > Necessary because they prevent CustomPOERPOperationTracking from being terminated
                            ICustomERPOperationTrackingConsumptionLogCollection consumptionLogs = CustomERPOperationTrackingEngine.GetAllConsumptionLogsForMO(operationTracking.OrderMaterial, operationTracking.OrderRunNumber.Value, operationTracking.OrderOperation, true);
                            consumptionLogs.Terminate();

                            // Terminate the CustomPOERPOperationTracking relations > Necessary because they prevent CustomPOERPOperationTracking from being terminated
                            operationTracking.LoadRelations("CustomPOERPOperationTracking");

                        if (operationTracking.HasRelations("CustomPOERPOperationTracking"))
                        {
                            ICustomPOERPOperationTrackingCollection operationTrackings = entityFactory.CreateCollection<ICustomPOERPOperationTrackingCollection>();
                                operationTrackings.AddRange(operationTracking.RelationCollection["CustomPOERPOperationTracking"]
                                .Select(ot => ot as ICustomPOERPOperationTracking)
                                .Where(ot => ot.UniversalState != Foundation.Common.Base.UniversalState.Terminated));

                                operationTrackings.Terminate();
                            }
                        }
                    }
                }
            }
            
            //---End DEE Code---
            return Input;
        }



    }
}
