﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.ERP;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace Cmf.Custom.IKEA.Actions.ERP
{
    public class CustomERPChangeTypeReport : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Sends a report message to ERP indicating that the new type of the material
            /// Action Groups:
            ///     MaterialManagement.MaterialManagementOrchestration.ChangeMaterialType.Post
            ///     MaterialManagement.MaterialManagementOrchestration.ChangeMaterialsType.Post
            /// </summary>
            #endregion
            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            INiceLabelUtilities nbUtilities = serviceProvider.GetService<INiceLabelUtilities>();
            ILocalizedMessage _localizedMessage = serviceProvider.GetService<ILocalizedMessage>();
            IGenericUtilities _genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();
            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "MaterialManagement.MaterialManagementOrchestration.ChangeMaterialType.Post",
                "MaterialManagement.MaterialManagementOrchestration.ChangeMaterialsType.Post"
            };

            // Get the context for the CustomERPChangeTypeReport indicating if the change type is being done by the unit completion
            bool? unitCompletion = deeContextUtilities.GetContextParameter(IKEAConstants.ERPChangeTypeReportUnitCompletion) as bool?;

            // Check if the functionality is enabled and if is being executed by the right action group
            bool executionVeridict = _genericUtilities.GetConfigurationValueByPath<bool>(IKEAConstants.ChangeTypeCommunication) && IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups) && unitCompletion != true;

            if (executionVeridict && IKEADEEActionUtilities.GetInputItem<ChangeMaterialTypeOutput>(Input, "ChangeMaterialTypeOutput") == null
                                    && IKEADEEActionUtilities.GetInputItem<ChangeMaterialsTypeOutput>(Input, "ChangeMaterialsTypeOutput") == null)
            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
     

            //System
            UseReference("", "System");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("%MicrosoftNetPath%\\System.XML.dll", "System.Xml");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects");

            // Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
             UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.ERP");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            INiceLabelUtilities nbUtilities = serviceProvider.GetService<INiceLabelUtilities>();
            ILocalizedMessage _localizedMessage = serviceProvider.GetService<ILocalizedMessage>();
            IGenericUtilities _genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();

            IMaterialCollection materials = entityFactory.CreateCollection<IMaterialCollection>();

            ChangeMaterialTypeOutput changeMaterialTypeOutput = IKEADEEActionUtilities.GetInputItem<ChangeMaterialTypeOutput>(Input, "ChangeMaterialTypeOutput");
            ChangeMaterialsTypeOutput changeMaterialsTypeOutput = IKEADEEActionUtilities.GetInputItem<ChangeMaterialsTypeOutput>(Input, "ChangeMaterialsTypeOutput");

            if (changeMaterialTypeOutput != null)
            {
                materials.Add(changeMaterialTypeOutput.Material);
            }
            else if (changeMaterialsTypeOutput != null)
            {
                materials.AddRange(changeMaterialsTypeOutput.Materials);
            }

            // Check if there are any materials to report
            if (materials.Count > 0)
            {
                materials.LoadAttributes();

                foreach (IMaterial material in materials)
                {
                    // Get the complete form for the material
                    string completedForm = ikeaUtilities.GetCompletedMaterialForm(material);

                    // Check if the material is in the Complete form
                    if (material.Form == completedForm)
                    {
                        string reportQualityChangeEndpointConfig = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.ErpReportQualityChangeEndpointConfig);
                        string erpMaterialType = ikeaUtilities.GetTypeFromErpMappingTable(IKEAConstants.MESSystem, IKEAConstants.CustomERPColumnsMappingMaterial,
                            IKEAConstants.CustomERPColumnsMappingType, material.Type, IKEAConstants.ERPSystem, reportQualityChangeEndpointConfig);
                        string internalQualityCode = material.GetAttributeValueOrDefault<string>(IKEAConstants.CustomInternalQualityCode);

                        // Get the current ERP Material Type
                        if (!String.IsNullOrWhiteSpace(internalQualityCode) && internalQualityCode.CompareStrings(erpMaterialType))
                        {
                            IAttributeCollection materialAttribute = new AttributeCollection
                            {
                                {IKEAConstants.CustomInternalQualityCode, "" }
                            };
                            material.SaveAttributes(materialAttribute);

                        }
                        else
                        {
                            string warehouse = material.Facility.GetAttributeValueOrDefault<string>(IKEAConstants.CustomFaciltyAttributeERPWarehouseLocation, true);

                            // Get Material ERP Original Name
                            string erpOriginalName = material.GetAttributeValueOrDefault<string>(IKEAConstants.CustomMaterialAttributeERPOriginalName);

                            string materialName = string.IsNullOrWhiteSpace(erpOriginalName) ? material.Name : erpOriginalName;

                            // Instantiate the object to be serialized
                            ChangeQualityTypeCommunication changeErpQuality = new ChangeQualityTypeCommunication
                            {
                                Partner = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.SupplierCodeConfig),
                                MessageType = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.MessageTypeCodeConfig),
                                Warehouse = string.IsNullOrWhiteSpace(warehouse) ? string.Empty : warehouse,
                                Location = material.GetAttributeValueOrDefault<string>(IKEAConstants.CustomMaterialAttributeERPInventoryLocation),
                                ItemNumber = material.Product.GetRelatedAttributeValueOrDefault<string>(IKEAConstants.CustomProductAttributeBaseProduct, true) ?? material.Product.Name,
                                Container = materialName,
                                StatusBalanceID = String.IsNullOrWhiteSpace(erpMaterialType) ? "NA" : erpMaterialType,
                                Responsible = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.ErpResponsibleConfig),
                                ProcessFlag = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.ChangeQualityTypeCommunicationProcessFlag) ?? "*EXE"
                            };                            

                            bool materialAttributeERPIsCreationReported = material.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomMaterialAttributeERPIsCreationReported);
                            // Create the Integration Entry
                            if (materialAttributeERPIsCreationReported)    
                            {
                                IIntegrationEntry ie = ikeaUtilities.CreateJsonIntegrationEntry(changeErpQuality,
                                                                                                IKEAConstants.ERPReportQualityChange,
                                                                                                IKEAConstants.ERPChangeTypeReportMessageType,
                                                                                                IKEAConstants.ERPChangeTypeReportEventName);

                                if (ie != null)
                                {
                                    IAttributeCollection materialAttribute = new AttributeCollection
                                {
                                    {IKEAConstants.CustomInternalQualityCode, "" }
                                };
                                    material.SaveAttributes(materialAttribute);
                                }
                            }

                        }

                    }
                }
            }

            
            //---End DEE Code---

            return Input;
        }


    }
}
