﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.ERP;
using Cmf.Custom.IKEA.Common.Utilities;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;

namespace Cmf.Custom.IKEA.Actions.ERP
{
    public class CustomERPBaseCommunicationHandler : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text: Base communication action to communicate from MES to ERP 
            ///               Validates integration entry message content format and call SendERPMessage with the extracted endpoint from config
            ///     
            /// Action Groups: N/A
            /// Depends On: N/A
            /// Is Dependency For: N/A
            /// Exceptions: N/A
            /// </summary>
            #endregion

            return true;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
     

            //System
            UseReference("", "System");
            UseReference("", "System.Collections.Generic");
            UseReference("%MicrosoftNetPath%\\System.XML.XDocument.dll", "");
            UseReference("%MicrosoftNetPath%\\System.XML.ReaderWriter.dll", "");
            UseReference("%MicrosoftNetPath%\\System.Private.XML.dll", "");
            UseReference("%MicrosoftNetPath%\\System.XML.dll", "System.Xml");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.ERP");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Extensions");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IERPUtilities erpUtilities = serviceProvider.GetService<IERPUtilities>();
            ILocalizedMessage _localizedMessage = serviceProvider.GetService<ILocalizedMessage>();
            IGenericUtilities _genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();

            //Validate if integration message contains key ERP Info
            if (Input.ContainsKey(IKEAConstants.IntegrationInput))
            {
                //Get input item
                string integrationMessage = Input[IKEAConstants.IntegrationInput] as string;
                //Validate if ERPInfo message is set
                if (!string.IsNullOrWhiteSpace(integrationMessage))
                {
                    MESERPCommunication mESERPCommunication = null;
                    try
                    {
                        //Deserialize the Xml from the integration entry message
                        mESERPCommunication = _genericUtilities.DeserializeXmlToObject<MESERPCommunication>(integrationMessage);
                    }
                    catch
                    {
                        throw new Exception("Message is not in the correct format");
                    }

                    //Validate if MESERPCommunication key is present in ERPInfo
                    if (mESERPCommunication != null)
                    {
                        //Extract API and Message from IntegrationEntry message
                        string rawEndpointConfigName = mESERPCommunication.API;
                        string rawMessage = mESERPCommunication.Message;

                        //Validate API and rawMessage
                        if (!string.IsNullOrWhiteSpace(rawEndpointConfigName) && !string.IsNullOrWhiteSpace(rawMessage))
                        {
                            Dictionary<string, string> message = _genericUtilities.DeserializeObject(rawMessage);

                            string config = IKEAConstants.ERPM3Endpoint + rawEndpointConfigName;
                            string endpoint = _genericUtilities.GetConfigurationValueByPath<string>(config);
                            
                            //Validate if config was successfully extracted
                            if (!string.IsNullOrWhiteSpace(endpoint))
                            {
                                //Call SendERPMessage Utility 
                                string result = erpUtilities.SendERPMessage(message, endpoint);

                                // Check type of message sent, OrderlessUnitComplete needs to handle the response to grab the Order Name generated by the ERP
                                if (rawEndpointConfigName == IKEAConstants.ERPM3EndpointOrderlessUnitComplete)
                                {
                                    erpUtilities.HandleERPOrderlessUnitCompleteResponse(mESERPCommunication, result);
                                }

                                // Add the message result to the integration entry:
                                if (!result.IsNullOrEmpty())
                                {
                                    Input.Add("Result", result);
                                }
                            }
                            else
                            {
                                throw new Exception("No endpoint found on Configuration: " + config);
                            }
                        }
                        else
                        {
                            throw new Exception("No API/Message was found");
                        }
                    }
                    else
                    {
                        throw new Exception("Deserialization failed");
                    }
                }
                else
                {
                    throw new Exception("Integration Entry ERPInfo is empty");
                }
            }
            else
            {
                throw new Exception("Integration Entry does not contain ERPInfo key");
            }

            

            //---End DEE Code---

            return Input;
        }

       
    }
}
