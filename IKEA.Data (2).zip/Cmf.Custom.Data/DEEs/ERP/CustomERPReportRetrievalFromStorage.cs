﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.BusinessObjects;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Extensions;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Foundation.Configuration;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.ERP
{
    public class CustomERPReportRetrievalFromStorage : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   
            #region Info
            /// <summary>
            /// Summary text
            /// This DEE reports to ERP that the material has been completed
            /// Action Groups:
            ///             BusinessObjects.Material.Retrieve.Post
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion
            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IGenericUtilities _genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();
            bool isNiceLabelEnabled = _genericUtilities.GetConfigurationValueByPath<bool>(IKEAConstants.NiceLabelIsEnabled);

            if (!isNiceLabelEnabled)
            {
                return false;
            }

            MaterialCollection materialCollection = IKEADEEActionUtilities.GetInputItem<MaterialCollection>(Input, "MaterialCollection");
            if(materialCollection == null)
            {
                return false;
            }
            IMaterial material = materialCollection[0];
            if(material == null)
            {
                return false;
            }
            material.Load();
            material.LoadAttribute(IKEAConstants.CustomMaterialSSCCAttribute);

            if(material.GetAttributeValue(IKEAConstants.CustomMaterialSSCCAttribute) == null)
            {
                return false;
            }
            deeContextUtilities.SetContextParameter("CustomERPReportRetrievalFromStorage_Material", material);

            return true;
            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
     

            //System
            UseReference("", "System");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("", "System.IO");
            UseReference("", "System.Linq");
            UseReference("", "System.Threading");
            //Foundation
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects");
            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Extensions");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
            UseReference("Cmf.Custom.IKEA.BusinessObjects.CustomERPOperationTrackingConsumptionLog.dll", "Cmf.Custom.IKEA.BusinessObjects");
            UseReference("Cmf.Custom.IKEA.BusinessObjects.CustomERPOperationTracking.dll", "Cmf.Custom.IKEA.BusinessObjects");
            UseReference("Cmf.Custom.IKEA.BusinessObjects.CustomPOERPOperationTracking.dll", "Cmf.Custom.IKEA.BusinessObjects");
            UseReference("Cmf.Custom.IKEA.BusinessObjects.CustomPOOperationResource.dll", "Cmf.Custom.IKEA.BusinessObjects");
            UseReference("Cmf.Custom.IKEA.BusinessObjects.CustomERPOperationTrackingConsumptionLog.dll", "Cmf.Custom.IKEA.BusinessObjects");
            UseReference("", "Cmf.Navigo.BusinessObjects.Abstractions");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IERPUtilities eRPUtilities = serviceProvider.GetService<IERPUtilities>();
            IGenericUtilities _genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            Material material = deeContextUtilities.GetContextParameter("CustomERPReportRetrievalFromStorage_Material") as Material;

            bool force = IKEAConstants.ForceOrderCompletion.Equals(material.GetAttributeValueOrDefault<string>(IKEAConstants.CustomMaterialAttributeProcessLossMotive, true));
            IMaterialCollection materials = entityFactory.CreateCollection<IMaterialCollection>();
           
                materials.Add(material);

            eRPUtilities.ReportUnitComplete(materials, true,  force);

            

            //---End DEE Code---
            return Input;
        }



    }
}
