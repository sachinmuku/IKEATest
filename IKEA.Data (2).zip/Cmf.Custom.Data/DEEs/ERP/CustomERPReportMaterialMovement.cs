﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.ERP
{
    public class CustomERPReportMaterialMovement : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Action to report material movement of a Material to ERP
            /// Action Groups:  ResourceManagement.ResourceManagementOrchestration.ManageResourceConsumableFeeds.Post
            ///                 ResourceManagement.ResourceManagementOrchestration.ManageResourceConsumableFeeds.Pre
            ///                 ResourceManagement.ResourceManagementOrchestration.AttachConsumableToResource.Post
            ///                 MaterialManagement.MaterialManagementOrchestration.StoreMaterial.Post
            ///                 MaterialManagement.MaterialManagementOrchestration.StoreMaterials.Post
            ///                 MaterialManagement.MaterialManagementOrchestration.ComplexTrackInMaterials.Post
            ///                 MaterialManagement.MaterialManagementOrchestration.ComplexTrackOutMaterials.Post
            /// </summary>
            #endregion

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IGenericUtilities _genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.Resource.AttachConsumables.Post"
                , "MaterialManagement.MaterialManagementOrchestration.StoreMaterial.Post"
                , "MaterialManagement.MaterialManagementOrchestration.ComplexTrackInMaterials.Post"
                , "MaterialManagement.MaterialManagementOrchestration.ComplexTrackOutMaterials.Post"
                , "MaterialManagement.MaterialManagementOrchestration.StoreMaterials.Post"
            };
            // Check if the functionality is enabled and if is being executed by the right action group
            bool executionVeridict = _genericUtilities.GetConfigurationValueByPath<bool>(IKEAConstants.MaterialConsumptionCommunication) && IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);
            
            return executionVeridict;


            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
     

            //System
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.IO");
            UseReference("", "System.Threading");
            UseReference("", "System");

            //Foundation
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.ResourceManagement.OutputObjects");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.ResourceManagement.InputObjects");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
             UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Extensions");
            UseReference("Cmf.Custom.IKEA.Orchestration.dll", "Cmf.Custom.IKEA.Orchestration.InputObjects");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IERPUtilities erpUtilities = serviceProvider.GetService<IERPUtilities>();
            ILocalizedMessage _localizedMessage = serviceProvider.GetService<ILocalizedMessage>();
            IGenericUtilities _genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();


            //DEE context 
            DeeContext currentContext = deeContextUtilities.SetCurrentServiceContext("CustomERPReportMaterialMovement");

            string orderForm = ikeaUtilities.GetOrderMaterialForm();

            //At post, create Integration entry and update material with new ERPInventoryLocation
            if (currentContext.TriggerPoint == DeeTriggerPoint.Post)
            {
                switch (currentContext.MethodName)
                {
                    #region Attach

                    case "AttachConsumables":

                        // if resource is configured to block reporting, convey that limitation to the materials being attached
                        Dictionary<IMaterial, IAttachConsumableParameters> attachInput = IKEADEEActionUtilities.GetInputItem<Dictionary<IMaterial, IAttachConsumableParameters>>(Input, "Materials");
                        IResource resource = IKEADEEActionUtilities.GetInputItem<IResource>(Input, "Resource");
                        if (attachInput != null && attachInput.Any() && resource != null)
                        {
                            string inventoryLocationManageConsumables = resource.GetAttributeValueOrDefault<string>(IKEAConstants.CustomResourceAttributeInventoryLocation, true);

                            //Try to get InventoryLocation of the TopMost Resource if none found at consumable feed level
                            if (string.IsNullOrEmpty(inventoryLocationManageConsumables))
                            {
                                inventoryLocationManageConsumables = resource.GetTopMostResource().GetAttributeValueOrDefault<string>(IKEAConstants.CustomResourceAttributeInventoryLocation, true);
                            }

                            if (!string.IsNullOrEmpty(inventoryLocationManageConsumables))
                            {
                                Dictionary<long, string> newLocation_ManageConsumables = new Dictionary<long, string>();
                                IMaterialCollection consumablesAttached = entityFactory.CreateCollection<IMaterialCollection>();
                                consumablesAttached.AddRange(attachInput.Keys);

                                foreach (IMaterial consumable in consumablesAttached)
                                {
                                    //new Inventory location for Material <ID,new Location from Resource>
                                    newLocation_ManageConsumables.Add(consumable.Id, inventoryLocationManageConsumables);
                                }

                                erpUtilities.HandleMaterialMovementCommunication(true, consumablesAttached, newLocation_ManageConsumables);
                            }
                        }

                        break;


                    #endregion

                    #region Store

                    case "StoreMaterial":
                    
                        StoreMaterialOutput storeMaterialOutput = IKEADEEActionUtilities.GetInputItem<StoreMaterialOutput>(Input, "StoreMaterialOutput");                 
                        //Try to get InventoryLocation of the Resource
                        string resourceInventoryLocation_Store = storeMaterialOutput.Resource.GetAttributeValueOrDefault<string>(IKEAConstants.CustomResourceAttributeInventoryLocation, true);
                        //Try to get InventoryLocation of the TopMost Resource
                        if (string.IsNullOrEmpty(resourceInventoryLocation_Store))
                        {
                            resourceInventoryLocation_Store = storeMaterialOutput.Resource.GetTopMostResource().GetAttributeValueOrDefault<string>(IKEAConstants.CustomResourceAttributeInventoryLocation, true);
                        }
                        if (!string.IsNullOrEmpty(resourceInventoryLocation_Store))
                        {
                            Dictionary<long, string> newLocation_Store = new Dictionary<long, string>();

                            IMaterial materialStored = storeMaterialOutput.Material;
                            IMaterialCollection storedMaterials = entityFactory.CreateCollection<IMaterialCollection>();
                            storedMaterials.Add(materialStored);
                            newLocation_Store.Add(materialStored.Id, resourceInventoryLocation_Store);
                            erpUtilities.HandleMaterialMovementCommunication(true, storedMaterials, newLocation_Store);
                        }
                        break;

                    case "StoreMaterials":
                     
                        StoreMaterialsOutput storeMaterialsOutput = IKEADEEActionUtilities.GetInputItem<StoreMaterialsOutput>(Input, "StoreMaterialsOutput");
                        //Try to get InventoryLocation of the Resource
                        string resourceInventoryLocation = storeMaterialsOutput.Resource.GetAttributeValueOrDefault<string>(IKEAConstants.CustomResourceAttributeInventoryLocation, true);
                        if (string.IsNullOrEmpty(resourceInventoryLocation))
                        {
                            resourceInventoryLocation = storeMaterialsOutput.Resource.GetTopMostResource().GetAttributeValueOrDefault<string>(IKEAConstants.CustomResourceAttributeInventoryLocation, true);
                        }
                        if (!string.IsNullOrEmpty(resourceInventoryLocation))
                        {
                            Dictionary<long, string> newLocation_Store = new Dictionary<long, string>();

                            IMaterialCollection materialsStored = storeMaterialsOutput.Materials;
                            materialsStored.ToList().ForEach(material => newLocation_Store.Add(material.Id, resourceInventoryLocation));
                            erpUtilities.HandleMaterialMovementCommunication(true, materialsStored, newLocation_Store);
                        }

                        break;
                        
                    #endregion

                    #region TrackIn

                    case "ComplexTrackInMaterials":
                        ComplexTrackInMaterialsOutput complexTrackInMaterialsOutput = IKEADEEActionUtilities.GetInputItem<ComplexTrackInMaterialsOutput>(Input, "ComplexTrackInMaterialsOutput");
                        //Try to get InventoryLocation of the Resource
                        string resourceInventoryLocation_TrackIn = complexTrackInMaterialsOutput.Resource.GetAttributeValueOrDefault<string>(IKEAConstants.CustomResourceAttributeInventoryLocation, true);
                        //Try to get InventoryLocation of the TopMost Resource
                        if (string.IsNullOrEmpty(resourceInventoryLocation_TrackIn))
                        {
                            resourceInventoryLocation_TrackIn = complexTrackInMaterialsOutput.Resource.GetTopMostResource().GetAttributeValueOrDefault<string>(IKEAConstants.CustomResourceAttributeInventoryLocation, true);
                        }
                        if (!string.IsNullOrEmpty(resourceInventoryLocation_TrackIn))
                        {
                            Dictionary<long, string> newLocation_TrackIn = new Dictionary<long, string>();
                            foreach (IMaterial materialTrackedIn in complexTrackInMaterialsOutput.Materials)
                            {
                                //new Inventory location for Material <ID,new Location from Resource>
                                newLocation_TrackIn.Add(materialTrackedIn.Id, resourceInventoryLocation_TrackIn);
                            }
                            erpUtilities.HandleMaterialMovementCommunication(true, complexTrackInMaterialsOutput.Materials, newLocation_TrackIn);
                        }
                        break;

                    #endregion

                    #region Trackout

                    //Update Material with new ERPInventoryLocation on Trackout
                    case "ComplexTrackOutMaterials":

                        //Get Resource and update Material with resource ERPInventoryLocation
                        ComplexTrackOutMaterialsOutput complexTrackOutMaterialsOutput = IKEADEEActionUtilities.GetInputItem<ComplexTrackOutMaterialsOutput>(Input, "ComplexTrackOutMaterialsOutput");

                        string resourceInventoryLocation_TrackOut = "";
                        Dictionary<long, string> newLocation_TrackOut = new Dictionary<long, string>();
                        IMaterialCollection materialsTrackedOut = entityFactory.CreateCollection<IMaterialCollection>();
                        foreach (IMaterial materialTrackedOut in complexTrackOutMaterialsOutput.Materials.Keys)
                        {
                            //Try to get InventoryLocation of the Resource
                            resourceInventoryLocation_TrackOut = materialTrackedOut.LastProcessedResource.GetAttributeValueOrDefault<string>(IKEAConstants.CustomResourceAttributeInventoryLocation, true);
                            //Try to get InventoryLocation of the TopMost Resource
                            if (string.IsNullOrEmpty(resourceInventoryLocation_TrackOut))
                            {
                                resourceInventoryLocation_TrackOut = materialTrackedOut.LastProcessedResource.GetTopMostResource().GetAttributeValueOrDefault<string>(IKEAConstants.CustomResourceAttributeInventoryLocation, true);
                            }
                            if (!string.IsNullOrEmpty(resourceInventoryLocation_TrackOut))
                            {
                                //new Inventory location for Material <ID,new Location from Resource>
                                newLocation_TrackOut.Add(materialTrackedOut.Id, resourceInventoryLocation_TrackOut);
                                //Collect MaterialCollection to be used on the handler
                                materialsTrackedOut.Add(materialTrackedOut);
                            }
                        }
                        erpUtilities.HandleMaterialMovementCommunication(true, materialsTrackedOut, newLocation_TrackOut);

                        break;

                        #endregion
                }
            }

            
            //---End DEE Code---
            return Input;
        }


    }
}
