﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Extensions;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.ResourceManagement.InputObjects;
using Cmf.Navigo.BusinessOrchestration.ResourceManagement.OutputObjects;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.ERP
{
    public class CustomERPDetachReport : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Action to report the detach of a material from a feeder to ERP
            /// Action Groups:
            ///     ResourceManagement.ResourceManagementOrchestration.ManageResourceConsumableFeeds.Post
            ///     ResourceManagement.ResourceManagementOrchestration.DetachConsumableFromResource.Post
            ///     ResourceManagement.ResourceManagementOrchestration.DetachConsumablesFromResource.Post
            /// </summary>
            #endregion
            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IGenericUtilities _genericUtilities = serviceProvider.GetService<IGenericUtilities>();

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "ResourceManagement.ResourceManagementOrchestration.ManageResourceConsumableFeeds.Pre",
                "ResourceManagement.ResourceManagementOrchestration.DetachConsumableFromResource.Pre",
                "ResourceManagement.ResourceManagementOrchestration.DetachConsumablesFromResource.Pre",
                "ResourceManagement.ResourceManagementOrchestration.ManageResourceConsumableFeeds.Post",
                "ResourceManagement.ResourceManagementOrchestration.DetachConsumableFromResource.Post",
                "ResourceManagement.ResourceManagementOrchestration.DetachConsumablesFromResource.Post"
            };
            // Check if the functionality is enabled and if is being executed by the right action group
            bool executionVeridict = _genericUtilities.GetConfigurationValueByPath<bool>(IKEAConstants.MaterialConsumptionCommunication) && IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);
            if (executionVeridict && IKEADEEActionUtilities.GetInputItem<ManageResourceConsumableFeedsOutput>(Input, "ManageResourceConsumableFeedsOutput") == null
                                  && IKEADEEActionUtilities.GetInputItem<DetachConsumableFromResourceOutput>(Input, "DetachConsumableFromResourceOutput") == null
                                  && IKEADEEActionUtilities.GetInputItem<DetachConsumablesFromResourceOutput>(Input, "DetachConsumablesFromResourceOutput") == null
                                  && IKEADEEActionUtilities.GetInputItem<ManageResourceConsumableFeedsInput>(Input, "ManageResourceConsumableFeedsInput") == null
                                  && IKEADEEActionUtilities.GetInputItem<DetachConsumableFromResourceInput>(Input, "DetachConsumableFromResourceInput") == null
                                  && IKEADEEActionUtilities.GetInputItem<DetachConsumablesFromResourceInput>(Input, "DetachConsumablesFromResourceInput") == null)
            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
     

            //System
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("", "System");

            //Foundation
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.ResourceManagement.OutputObjects");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.ResourceManagement.InputObjects");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Extensions");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
             UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            INiceLabelUtilities nbUtilities = serviceProvider.GetService<INiceLabelUtilities>();
            ILocalizedMessage _localizedMessage = serviceProvider.GetService<ILocalizedMessage>();
            IGenericUtilities _genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();

            ManageResourceConsumableFeedsInput manageResourceConsumableFeedsInput = IKEADEEActionUtilities.GetInputItem<ManageResourceConsumableFeedsInput>(Input, "ManageResourceConsumableFeedsInput");
            DetachConsumableFromResourceOutput detachConsumableFromResourceOutput = IKEADEEActionUtilities.GetInputItem<DetachConsumableFromResourceOutput>(Input, "DetachConsumableFromResourceOutput");
            DetachConsumablesFromResourceOutput detachConsumablesFromResourceOutput = IKEADEEActionUtilities.GetInputItem<DetachConsumablesFromResourceOutput>(Input, "DetachConsumablesFromResourceOutput");

            Dictionary<IResource, IMaterialCollection> resourceConsumables = new Dictionary<IResource, IMaterialCollection>();

            if (manageResourceConsumableFeedsInput != null && !manageResourceConsumableFeedsInput.ConsumablesToDetach.IsNullOrEmpty())
            {
                resourceConsumables = manageResourceConsumableFeedsInput.ConsumablesToDetach;
            }
            else if (detachConsumableFromResourceOutput != null)
            {
                var detachConsumableFromResourcematerialCollection = entityFactory.CreateCollection<IMaterialCollection>();
                detachConsumableFromResourcematerialCollection.Add(detachConsumableFromResourceOutput.Material);
                resourceConsumables.Add(detachConsumableFromResourceOutput.Resource, detachConsumableFromResourcematerialCollection);
            }
            else if (detachConsumablesFromResourceOutput != null)
            {
                resourceConsumables.Add(detachConsumablesFromResourceOutput.Resource, detachConsumablesFromResourceOutput.Materials);
            }

            DeeContext currentContext = deeContextUtilities.SetCurrentServiceContext("CustomERPDetachReport");

            // Needs to validate the materials to be detached per MO because of Parallel Execution
            if (currentContext.TriggerPoint == DeeTriggerPoint.Pre)
            {
                Dictionary<IMaterial, Dictionary<IResource, IMaterialCollection>> resourceAndMaterialsPerMO = new Dictionary<IMaterial, Dictionary<IResource, IMaterialCollection>>();
                foreach (KeyValuePair<IResource, IMaterialCollection> resourceMaterial in resourceConsumables.Where(rc => !rc.Value.IsNullOrEmpty()))
                {
                    IMaterialCollection materialsInProcess = ikeaUtilities.GetMaterialsInProgresFromConsumableFeed(resourceMaterial.Key.Id, true);
                    if (!materialsInProcess.IsNullOrEmpty())
                    {
                        //Check the MO of each material being detached
                        foreach (IMaterial material in resourceMaterial.Value)
                        {
                            IMaterial consumableMO = ikeaUtilities.GetMaterialInProcessFromConsumable(resourceMaterial.Key, material);
                            if(consumableMO == null)
                            {
                                consumableMO = materialsInProcess.Where(m => !m.IsChildOfGroupMO()).OrderByDescending(m => m.TrackInDate).First();
                            }

                            //Store the Material on a Dictionary stored per MO
                            if (!resourceAndMaterialsPerMO.ContainsKey(consumableMO))
                            {
                                resourceAndMaterialsPerMO[consumableMO] = new Dictionary<IResource, IMaterialCollection>();
                                resourceAndMaterialsPerMO[consumableMO][resourceMaterial.Key] = entityFactory.CreateCollection<IMaterialCollection>();
                            }
                            else if (!resourceAndMaterialsPerMO[consumableMO].ContainsKey(resourceMaterial.Key))
                            {
                                resourceAndMaterialsPerMO[consumableMO][resourceMaterial.Key] = entityFactory.CreateCollection<IMaterialCollection>();
                            }

                            resourceAndMaterialsPerMO[consumableMO][resourceMaterial.Key].Add(material);
                        }
                    }
                }
                deeContextUtilities.SetContextParameter("CustomERPDetachReport", resourceAndMaterialsPerMO);
            }
            else if (currentContext.TriggerPoint == DeeTriggerPoint.Post)
            {
                //Report the materials per MO and resource, previously stored on the DEE context
                Dictionary<IMaterial, Dictionary<IResource, IMaterialCollection>> resourceConsumablesPerMO = deeContextUtilities.GetContextParameter("CustomERPDetachReport") as Dictionary<IMaterial, Dictionary<IResource, IMaterialCollection>>;
                if (!resourceConsumablesPerMO.IsNullOrEmpty())
                {
                    foreach (KeyValuePair<IMaterial, Dictionary<IResource, IMaterialCollection>> entryPerMO in resourceConsumablesPerMO)
                    {
                        foreach (KeyValuePair<IResource, IMaterialCollection> resourceMaterial in entryPerMO.Value)
                        {
                            IMaterialCollection materialsInProcess = ikeaUtilities.GetMaterialsInProgresFromConsumableFeed(resourceMaterial.Key.Id, true);
                            ikeaUtilities.ReportMaterialConsumption(false, resourceMaterial.Key, resourceMaterial.Value, isAttach: false, materialMO: entryPerMO.Key);
                        }
                    }
                }
            }

            

            //---End DEE Code---

            return Input;
        }
    }
}
