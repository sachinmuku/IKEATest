﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;

using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Extensions;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.Automation
{
    public class CustomAutomationGetCurrentBOMExpectedFeederProducts : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code--- 
            #region Info
            /// <summary>
            /// Summary text
            ///     Receives a list of Feeders and MOIDs and gets the expected products on the BOMs for the corresponding MOID of each feeder, and the FeederConsumptionMode. 
            /// </summary>
            #endregion
            var executionVerdict = true;
            if (IKEADEEActionUtilities.GetInputItem<Object>(Input, "FeederNameList") == null
                || IKEADEEActionUtilities.GetInputItem<Object>(Input, "MOIDList") == null)
            {
                executionVerdict = false;
            }

            return executionVerdict;
            //---End DEE Condition Code--- 
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code--- 
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "");
            UseReference("", "Cmf.Foundation.Common.Exceptions");
            UseReference("", "Cmf.Foundation.Common");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Extensions");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");

            // Newtonsoft
            UseReference("Newtonsoft.Json.dll", "Newtonsoft.Json");

            // Object that will be used as output, contains: MOID, ConsumptionMode, ExpectedProducts and Feeder Name
            List<CustomExpectedProductsAndConsumptionMode> expectedProductsAndConsumptionModeList = new List<CustomExpectedProductsAndConsumptionMode>();

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();


            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            //  INiceLabelUtilities nbUtilities = serviceProvider.GetService<INiceLabelUtilities>();
            ILocalizedMessage _localizedMessage = serviceProvider.GetService<ILocalizedMessage>();
            IGenericUtilities _genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();

            // Get FeederName and MOID Lists from the Input
            List<string> feederNameList = new List<string>();
            List<string> mOIDList = new List<string>();
            feederNameList = Newtonsoft.Json.JsonConvert.DeserializeObject<List<string>>(IKEADEEActionUtilities.GetInputItem<Object>(Input, "FeederNameList")?.ToString());
            mOIDList = Newtonsoft.Json.JsonConvert.DeserializeObject<List<string>>(IKEADEEActionUtilities.GetInputItem<Object>(Input, "MOIDList")?.ToString());

            if (feederNameList != null && mOIDList != null)
            {
                // Iterate through the list of feeders received as Input
                for (int i = 0; i < feederNameList.Count; i++)
                {
                    // create one element of the output list
                    CustomExpectedProductsAndConsumptionMode expectedProductsAndConsumptionMode = new CustomExpectedProductsAndConsumptionMode();
                    expectedProductsAndConsumptionMode.ProductsToConsider = new List<string>();

                    // Set MOID on the output object
                    expectedProductsAndConsumptionMode.MOID = mOIDList[i];

                    // Set FeederName on the output object
                    expectedProductsAndConsumptionMode.FeederName = feederNameList[i];

                    string manufacturingOrderID = mOIDList[i];
                    IMaterial mOToUse = entityFactory.Create<IMaterial>();
                    mOToUse.Load(manufacturingOrderID);

                    IResource feederResource = entityFactory.Create<IResource>();
                    feederResource.Load(feederNameList[i]);
                    feederResource.LoadAttributes(new Collection<string>() { IKEAConstants.CustomResourceAttributeFeederConsumptionMode
                                                                     , IKEAConstants.ProcessSegmentSequence
                                                                     , IKEAConstants.SubProcessSegmentName });

                    // Get feeder consumption mode from feeder attribute
                    int feederConsumptionMode = 0;
                    switch (feederResource.GetAttributeValueOrDefault<CustomFeederConsumptionModeEnum>(IKEAConstants.CustomResourceAttributeFeederConsumptionMode))
                    {
                        case CustomFeederConsumptionModeEnum.ProductSequenceBased:
                            {
                                feederConsumptionMode = (int)CustomFeederConsumptionModeEnum.ProductSequenceBased;
                                break;
                            }
                        case CustomFeederConsumptionModeEnum.SequenceBased:
                        default:
                            {
                                feederConsumptionMode = (int)CustomFeederConsumptionModeEnum.SequenceBased;
                                break;
                            }
                    }

                    // Set ConsumptionMode on the output object
                    expectedProductsAndConsumptionMode.FeederConsumptionMode = feederConsumptionMode;

                    if (feederResource.Attributes != null && feederResource.Attributes.Count > 0 && feederResource.Attributes.ContainsKey(IKEAConstants.ProcessSegmentSequence)
                        && feederResource.Attributes[IKEAConstants.ProcessSegmentSequence] != null)
                    {
                        string feederProcessSegment = feederResource.GetAttributeValueOrDefault<string>(IKEAConstants.ProcessSegmentSequence, false);
                        string feederSubProcessSegment = feederResource.GetAttributeValueOrDefault<string>(IKEAConstants.SubProcessSegmentName, false);

                        // if it is a GroupMO, iterate through every child MO and get all BomProduct Expected products where process segment == feederProcessSegment
                        if (mOToUse.IsGroupMO())
                        {
                            IMaterialCollection childMOsFromGMO = ikeaUtilities.GetChildMaterialsFromGroupMO(mOToUse);
                            foreach (IMaterial childMO in childMOsFromGMO)
                            {
                                // Get Expected Products with matching process segment
                                expectedProductsAndConsumptionMode.ProductsToConsider.AddRange(
                                    ikeaUtilities.GetBOMExpectedProductsFromProcessSegment(childMO, feederProcessSegment, feederSubProcessSegment)
                                    .Except(expectedProductsAndConsumptionMode.ProductsToConsider));
                            }
                        }
                        else
                        {
                            // Get Expected Products with matching process segment
                            expectedProductsAndConsumptionMode.ProductsToConsider = ikeaUtilities.GetBOMExpectedProductsFromProcessSegment(mOToUse, feederProcessSegment, feederSubProcessSegment);
                        }

                        // add the created element to the List
                        expectedProductsAndConsumptionModeList.Add(expectedProductsAndConsumptionMode);
                    }

                }

                Dictionary<string, object> output = new Dictionary<string, object>();
                output.Add("FeederInformation", expectedProductsAndConsumptionModeList);
                return output;
            }
            //---End DEE Code--- 
            return null;
        }
    }
}
