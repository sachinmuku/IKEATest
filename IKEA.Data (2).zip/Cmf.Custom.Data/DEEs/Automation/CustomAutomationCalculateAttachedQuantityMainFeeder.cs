﻿using System;
using System.Collections.Generic;
using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;

namespace Cmf.Custom.IKEA.Actions.Automation
{
	public class CustomAutomationCalculateAttachedQuantityMainFeeder : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
	{
		public override bool ValidateAction(Dictionary<string, object> Input)
		{
			//---Start DEE Condition Code--- 
			#region Info
			/// <summary>
			/// Summary text
			///     Calculates the main feeder total attached quantity
			/// </summary>
			#endregion
			if (IKEADEEActionUtilities.GetInputItem<string>(Input, "MainResourceName") != null)
			{
				string mainResourceName = IKEADEEActionUtilities.GetInputItem<string>(Input, "MainResourceName");
                IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
                IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
                IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();
                IResource mainResource = entityFactory.Create<IResource>();
				mainResource.Load(mainResourceName);
                deeContextUtilities.SetContextParameter("CustomAutomationCalculateAttachedQuantityMainFeeder_MainResource", mainResource);
				return true;

			}

			return false;
			//---End DEE Condition Code--- 
		}

		public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
		{
            //---Start DEE Code--- 
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "");
            UseReference("", "Cmf.Foundation.Common.Exceptions");
            UseReference("", "Cmf.Foundation.Common");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();

            decimal totalAttachedQuantity = 0;
            IResource mainResource = deeContextUtilities.GetContextParameter("CustomAutomationCalculateAttachedQuantityMainFeeder_MainResource") as IResource;
            mainResource.LoadAttribute("MESAutomationInFeederSubResourceController");
            if (mainResource.Attributes != null && mainResource.Attributes.Count > 0 && mainResource.Attributes.ContainsKey("MESAutomationInFeederSubResourceController")
            && mainResource.Attributes["MESAutomationInFeederSubResourceController"] != null)
            {
                string mainFeederName = mainResource.Attributes["MESAutomationInFeederSubResourceController"] as string;

                IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
                IResource mainFeeder = entityFactory.Create<IResource>();
                mainFeeder.Load(mainFeederName);
                mainFeeder.LoadRelations();
                IMaterialResourceCollection attachedConsumables = mainFeeder.ResourceMaterials;

                foreach (IMaterialResource attachedConsumable in attachedConsumables)
                {
                    IMaterial consumable = attachedConsumable.SourceEntity;
                    consumable.Load();
                    totalAttachedQuantity += consumable.PrimaryQuantity ?? 0;
                }
            }
            else
            {
                totalAttachedQuantity = -1;
            }

            Dictionary<string, object> output = new Dictionary<string, object>();
            output.Add("TotalAttachedQuantity", totalAttachedQuantity);
            return output;
            //---End DEE Code--- 
        }
	}
}
