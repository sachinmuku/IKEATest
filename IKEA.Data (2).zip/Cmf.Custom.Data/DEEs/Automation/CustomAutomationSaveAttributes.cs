﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Orchestration;
using Cmf.Custom.IKEA.Orchestration.Abstractions;
using Cmf.Custom.IKEA.Orchestration.InputObjects;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects;
using Cmf.Navigo.BusinessOrchestration.ResourceManagement;
using Cmf.Navigo.BusinessOrchestration.ResourceManagement.InputObjects;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Runtime.Intrinsics.X86;

namespace Cmf.Custom.IKEA.Actions.Automation
{
    public class CustomAutomationSaveAttributes : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     DEE responsible for receiving from IoT a dictionary of attributes to save for a specific resource.
            ///     The DEE then updates these attributes.
            /// </summary>
            #endregion

            bool executionVerdict = true;
            if (IKEADEEActionUtilities.GetInputItem<Object>(Input, "AttributesToSave") == null
                || (IKEADEEActionUtilities.GetInputItem<string>(Input, "Resource") == null && IKEADEEActionUtilities.GetInputItem<string>(Input, "Material") == null)
                )
            {
                executionVerdict = false;
            }

            return executionVerdict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            // CORE
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            // CORE
            UseReference("", "Cmf.Custom.IKEA.Orchestration.Abstractions");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.GenericServiceManagement.OutputObjects");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.GenericServiceManagement.InputObjects");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "");
            UseReference("", "Cmf.Foundation.Common.Exceptions");
            UseReference("", "Cmf.Foundation.Common");

            // MES
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");


            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            // CUSTOM
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Orchestration.dll", "Cmf.Custom.IKEA.Orchestration");
            UseReference("Cmf.Custom.IKEA.Orchestration.dll", "Cmf.Custom.IKEA.Orchestration.InputObjects");

            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetRequiredService<IEntityFactory>();

            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            INiceLabelUtilities nbUtilities = serviceProvider.GetService<INiceLabelUtilities>();
            ILocalizedMessage _localizedMessage = serviceProvider.GetService<ILocalizedMessage>();
            IGenericUtilities _genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();

            string entityType = string.Empty;
            if (IKEADEEActionUtilities.GetInputItem<string>(Input, "Resource") != null)
            {
                entityType = Constants.Resource;
            }
            else if (IKEADEEActionUtilities.GetInputItem<string>(Input, "Material") != null)
            {
                entityType = Constants.Material;
            }

            Dictionary<string, object> attributesToSaveFromIoT = new Dictionary<string, object>();
            object aux;

            string entityName = IKEADEEActionUtilities.GetInputItem<string>(Input, entityType);

            if (Input.TryGetValue("AttributesToSave", out aux))
            {
                attributesToSaveFromIoT = aux as Dictionary<string, object>;
            }

            long resourceId;
            IResource resource = entityFactory.Create<IResource>();
            IMaterial material = entityFactory.Create<IMaterial>();
            switch (entityType)
            {
                case Constants.Resource:
                    resource.Load(entityName);
                    IResource topResource = resource.GetTopMostResource();
                    resource = topResource ?? resource;
                    resource.Load();
                    resourceId = resource.Id;
                    break;

                case Constants.Material:
                    material.Load(entityName);
                    material.LoadRelations("MaterialResource");
                    resourceId = material.RelationCollection["MaterialResource"].FirstOrDefault().TargetEntity.Id;
                    break;

                default:
                    throw new Exception("Invalid Key");
                    // return null;
            }

            AttributeCollection attributesToSave = new AttributeCollection();

            foreach (var pair in attributesToSaveFromIoT)
            {
                attributesToSave.Add(pair.Key, pair.Value);
            }

            switch (entityType)
            {
                case Constants.Resource:
                    resource.SaveAttributes(attributesToSave);
                    break;
                case Constants.Material:
                    material.SaveAttributes(attributesToSave);
                    break;
            }

            // Spreads message stating line condition has changed to trigger refresh                                    
            string messageSubject = String.Format("{0}{1}", IKEAConstants.MessageBusResourceAndMaterialEventsPrefix, resourceId);
            List<string> refreshItems = new List<string>
            {
                "ActionButtons"
            };
            if (entityType == Constants.Material)
            {
                refreshItems.Add("MaterialsDispatchedAndTrackIn");
            }
            ikeaUtilities.PublishCockpitTransactionalMessages(messageSubject, refreshItems: refreshItems);

            //---End DEE Code---

            return Input;
        }
    }
}
