﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;


using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.ResourceManagement.InputObjects;
using Cmf.Navigo.BusinessOrchestration.ResourceManagement.OutputObjects;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.ERP
{
    public class CustomAutomationSendAttachInformation : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text:  Sends information of an Attach on a subresource to IOT
            ///     
            /// Action Groups:   ResourceManagement.ResourceManagementOrchestration.ManageResourceConsumableFeeds.Post
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "ResourceManagement.ResourceManagementOrchestration.ManageResourceConsumableFeeds.Post",
                "ResourceManagement.ResourceManagementOrchestration.AttachConsumableToResource.Post",
                "ResourceManagement.ResourceManagementOrchestration.AttachConsumablesToResource.Post"
            };

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            if (executionVeridict && IKEADEEActionUtilities.GetInputItem<ManageResourceConsumableFeedsInput>(Input, "ManageResourceConsumableFeedsInput") == null
                                  && IKEADEEActionUtilities.GetInputItem<AttachConsumablesToResourceOutput>(Input, "AttachConsumablesToResourceOutput") == null
                                  && IKEADEEActionUtilities.GetInputItem<AttachConsumableToResourceOutput>(Input, "AttachConsumableToResourceOutput") == null)
            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }


        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            //System

            //Foundation

            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            //Navigo
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.ResourceManagement.InputObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.ResourceManagement.OutputObjects");

            // Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");

            //Custom
            
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IDirectFeedingUtilities drUtilities = serviceProvider.GetService<IDirectFeedingUtilities>();
            ILocalizedMessage _localizedMessage = serviceProvider.GetService<ILocalizedMessage>();
            IGenericUtilities _genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();

            ManageResourceConsumableFeedsInput manageResourceConsumableFeedsInput = IKEADEEActionUtilities.GetInputItem<ManageResourceConsumableFeedsInput>(Input, "ManageResourceConsumableFeedsInput");
            AttachConsumablesToResourceOutput attachConsumablesToResourceOutput = IKEADEEActionUtilities.GetInputItem<AttachConsumablesToResourceOutput>(Input, "AttachConsumablesToResourceOutput");
            AttachConsumableToResourceOutput attachConsumableToResourceOutput = IKEADEEActionUtilities.GetInputItem<AttachConsumableToResourceOutput>(Input, "AttachConsumableToResourceOutput");

            Dictionary<IResource, IMaterialCollection> resourceConsumables = new Dictionary<IResource, IMaterialCollection>();

            //System.IServiceProvider serviceProvider = ApplicationContext.CurrentServiceProvider;
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();


            if (manageResourceConsumableFeedsInput != null)
            {
                resourceConsumables = manageResourceConsumableFeedsInput.ConsumablesToAttach;
            }
            else if (attachConsumablesToResourceOutput != null)
            {
                resourceConsumables.Add(attachConsumablesToResourceOutput.Resource, attachConsumablesToResourceOutput.Materials);
            }
            else if (attachConsumableToResourceOutput != null)
            {
                var attachConsumableToResourceCollection = entityFactory.CreateCollection<IMaterialCollection>();
                attachConsumableToResourceCollection.Add(attachConsumableToResourceOutput.Material);
                resourceConsumables.Add(attachConsumableToResourceOutput.Resource, attachConsumableToResourceCollection);
            }

            //Validate input
            if (!resourceConsumables.IsNullOrEmpty() && resourceConsumables.Values.Any())
            {
                IResource resource = resourceConsumables.First().Key;
                resource.Load();
                IResource topMostResource = resource.GetTopMostResource();
                IAutomationControllerInstance controllerInstance = topMostResource.GetAutomationControllerInstance();


                IMaterialCollection materialsToLoadAttributess = entityFactory.CreateCollection<IMaterialCollection>();
                foreach (IMaterialCollection materialColectionInResource in resourceConsumables.Values)
                {
                    materialsToLoadAttributess.AddRange(materialColectionInResource);
                }
                materialsToLoadAttributess.LoadAttributes(new Collection<string> {IKEAConstants.CustomMaterialAttributeReworkCounter,
                                                                                        IKEAConstants.CustomMaterialAttributeCurrentIteration,
                                                                                        IKEAConstants.CustomMaterialAttributeCreationArea,
                                                                                        IKEAConstants.CustomMaterialAttributeBaseMaterial,
                                                                                        IKEAConstants.CustomMaterialAttributeOrderRunNumber
                                                                                        });



                // Check If a parameter context was set in the CustomLogMaterialMovement service. (Pallet was attached manually):
                // The information was already sent to IOT. It is not necessary to send it again.
                bool isToSendConsumableListToAutomation = true;
                string manualPalletName = deeContextUtilities.GetContextParameter(IKEAConstants.CustomLogMaterialMovementManuallyAttachedPalletContextKey) as string;
                if (manualPalletName != null)
                {
                    IMaterialCollection col = resourceConsumables.First().Value;
                    if (col.Count == 1 && col.First().Name.CompareStrings(manualPalletName))
                    {
                        isToSendConsumableListToAutomation = false;
                    }
                }


                IMaterialCollection attachedMaterials = entityFactory.CreateCollection<IMaterialCollection>();

                attachedMaterials.AddRange(resourceConsumables.SelectMany(x => x.Value));


                // Collect and send the consumables list to IoT:
                // Verify if MO in second line is in direct feeding mode
                IMaterial materialInProcess = topMostResource.GetAllMaterialsInProcess().FirstOrDefault();
                CustomDirectFeedingModeEnum materialDirectFeedingMode = materialInProcess.GetAttributeValueOrDefault<CustomDirectFeedingModeEnum>(IKEAConstants.CustomMaterialAttributeDirectFeedingMode, loadAttribute: true);
                bool directFeedingIsFirstLine = topMostResource.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomResourceDirectFeedingIsFirstLine, loadAttribute: true);

                // Send request to IoT - Special Attach
                bool? isToSpecialAttach = deeContextUtilities.GetContextParameter(IKEAConstants.CustomDirectFeedingIsToSpecialAttach) as bool?;
                if (isToSpecialAttach.HasValue && isToSpecialAttach.Value)
                {
                    drUtilities.RequestSpecialAttach(attachedMaterials[0], topMostResource);
                    deeContextUtilities.SetContextParameter(IKEAConstants.CustomDirectFeedingIsToSpecialAttach, false);
                }
                else if (!directFeedingIsFirstLine && materialDirectFeedingMode == CustomDirectFeedingModeEnum.DirectFeeding)
                {
                    // Send request to IoT - VirtualToRealPallet
                    drUtilities.RequestVirtualToRealPallet(attachedMaterials, topMostResource, controllerInstance);
                }
                else if (isToSendConsumableListToAutomation)
                {
                    ikeaUtilities.SendConsumableListToAutomation(resourceConsumables, topMostResource, controllerInstance, IKEAConstants.AutomationRequestTypeConsumableAttach);
                }

                // Checks if the material needs to increment the MO quantity, if 'IncreasesMOQuantity' id set to True:
                ikeaUtilities.IncrementMOQuantityByMaterialAttribute(attachedMaterials);



            }

            //---End DEE Code---
            return Input;
        }


    }
}
