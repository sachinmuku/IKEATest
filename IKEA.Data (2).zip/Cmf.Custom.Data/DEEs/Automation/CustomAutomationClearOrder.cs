﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Extensions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.Automation
{
    public class CustomAutomationClearOrder : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Sends request to IOT indicating that it must remove order from queue
            /// Action Groups:
            ///     MaterialManagement.MaterialManagementOrchestration.AbortMaterialsProcess.Pre
            ///     MaterialManagement.MaterialManagementOrchestration.AbortMaterialsProcess.Post
            ///     MaterialManagement.MaterialManagementOrchestration.TerminateMaterials.Pre
            ///     MaterialManagement.MaterialManagementOrchestration.TerminateMaterials.Post
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "MaterialManagement.MaterialManagementOrchestration.AbortMaterialsProcess.Pre",
                "MaterialManagement.MaterialManagementOrchestration.AbortMaterialsProcess.Post",
                "MaterialManagement.MaterialManagementOrchestration.TerminateMaterials.Pre",
                "MaterialManagement.MaterialManagementOrchestration.TerminateMaterials.Post",
            };

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            if (executionVeridict && IKEADEEActionUtilities.GetInputItem<AbortMaterialsProcessInput>(Input, "AbortMaterialsProcessInput") == null
                && IKEADEEActionUtilities.GetInputItem<TerminateMaterialsInput>(Input, "TerminateMaterialsInput") == null)
            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            //System
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("", "System");

            //Foundation
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Extensions");
            UseReference("Cmf.Custom.IKEA.Orchestration.dll", "Cmf.Custom.IKEA.Orchestration.InputObjects");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");

            AbortMaterialsProcessInput abortMaterialsProcessInput = IKEADEEActionUtilities.GetInputItem<AbortMaterialsProcessInput>(Input, "AbortMaterialsProcessInput");
            TerminateMaterialsInput terminateMaterialsInput = IKEADEEActionUtilities.GetInputItem<TerminateMaterialsInput>(Input, "TerminateMaterialsInput");

            System.IServiceProvider serviceProvider = ApplicationContext.CurrentServiceProvider;
            var entityFactory = serviceProvider.GetService<IEntityFactory>();


            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            INiceLabelUtilities nbUtilities = serviceProvider.GetService<INiceLabelUtilities>();
            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();

            IMaterialCollection materialCollection = entityFactory.CreateCollection<IMaterialCollection>();
            if (abortMaterialsProcessInput != null && abortMaterialsProcessInput.Materials.Count > 0)
            {
                materialCollection.AddRange(abortMaterialsProcessInput.Materials);
            }
            if (terminateMaterialsInput != null && terminateMaterialsInput.Materials.Count > 0)
            {
                materialCollection.AddRange(terminateMaterialsInput.Materials);
            }

            DeeContext currentContext = deeContextUtilities.SetCurrentServiceContext("CustomAutomationClearOrder");

            if (currentContext.TriggerPoint == DeeTriggerPoint.Pre)
            {
                // Load all the resources that the materials were aborted from
                IResourceCollection resources = entityFactory.CreateCollection<IResourceCollection>();
                resources.LoadByIDs<IResource, Resource>(
                    materialCollection
                        .Where(material => material.LastProcessedResource != null)
                        .Select(material => material.LastProcessedResource.Id)
                        .Distinct()
                        .ToList()
                );
                resources.LoadAttributes(new Collection<string>
                {
                    IKEAConstants.CustomResourcePalletizeErrorHandleEnabledAttribute
                });

                // Collection of resources where we will need to disable the Handle Palletization Error Attribute
                // Only resources where the material aborted is the top material
                IResourceCollection resourcesToDisableFlag = entityFactory.CreateCollection<IResourceCollection>();

                foreach (IResource resource in resources)
                {
                    bool errorHandleEnabled = resource.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomResourcePalletizeErrorHandleEnabledAttribute);

                    // If the error handle attribute is not even enabled on this resource, then there is no need to "disable" it anyway
                    if (!errorHandleEnabled)
                    {
                        continue;
                    }

                    // Get the material at the top of the InProcess list for this resource
                    IMaterial topMaterialInProcess =
                        ikeaUtilities.GetMaterialsFromResourceByState(resource.Id, loadMaterials: false, MaterialSystemState.InProcess)
                        .OrderBy(mo => mo.Value)
                        .Select(mo => mo.Key)
                        .FirstOrDefault();

                    // If this top material is included in the list of materials being aborted, then the resource needs its flag removed
                    if (topMaterialInProcess != null && materialCollection.Any(material => material.Name == topMaterialInProcess.Name))
                    {
                        resourcesToDisableFlag.Add(resource);
                    }
                }

                deeContextUtilities.SetContextParameter(IKEAConstants.CustomAutomationClearOrderResourcesDisableErrorHandleContextKey, resourcesToDisableFlag);
            }
            else
            {
                var resources = deeContextUtilities.GetContextParameter(IKEAConstants.CustomAutomationClearOrderResourcesDisableErrorHandleContextKey) as IResourceCollection;

                if (!resources.IsNullOrEmpty())
                {
                    // And remove the palletize error handler attribute
                    resources.Load();
                    resources.RemoveAttributes(new Collection<string>
                    {
                        IKEAConstants.CustomResourcePalletizeErrorHandleEnabledAttribute
                    });
                }

                foreach (IMaterial material in materialCollection)
                {
                    string orderForm = ikeaUtilities.GetOrderMaterialForm();
                    //Only applicable to Order forms
                    if (material.Form == orderForm && material.LastProcessedResource != null)
                    {
                        IResource resource = material.LastProcessedResource;
                        resource.Load();

                        //Only proceed if automation mode is Online and a AutomationControllerInstance was found
                        if (resource.AutomationMode == ResourceAutomationMode.Online)
                        {
                            IAutomationControllerInstance controllerInstance = resource.GetAutomationControllerInstance();
                            if (controllerInstance != null)
                            {
                                // Get EI default timeout
                                int requestTimeout = genericUtilities.GetConfigurationValueByPath<int>(IKEAConstants.DownloadOrderToAutomationSendRequestDefaultTimeout);

                                // Prepare material details to request outsorted qty from EI
                                Dictionary<string, object> materialDetails = new Dictionary<string, object>();

                                materialDetails.Add(IKEAConstants.AutomationRequestMaterialName, material.Name);

                                // Send Asynchronous request to automation to request for Outsorted quantity
                                controllerInstance.Publish(IKEAConstants.AutomationRequestClearMaterial, materialDetails.ToJsonString());
                            }
                        }

                        IResource topMostResource = material.LastProcessedResource.GetTopMostResource();
                        topMostResource.LoadAttribute(IKEAConstants.CustomRoundOverProductionAndLossQuantity);

                        if (topMostResource.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomRoundOverProductionAndLossQuantity)
                               && genericUtilities.GetConfigurationValueByPath<bool>(IKEAConstants.CustomAssembleEnabled))
                        {
                            IMaterialCollection childMaterials = ikeaUtilities.GetBatchRelatedMaterials(material.Id, true);
                            if (!childMaterials.IsNullOrEmpty())
                            {
                                IMaterial lastPallet = childMaterials.OrderByDescending(material => material.CreatedOn).FirstOrDefault();

                                lastPallet.Load();

                                IMaterialGenealogyCollection materialGeneology = lastPallet.GetGenealogy(GenealogyDirection.Ascendant, null, new OperationAttributeCollection());
                                if (materialGeneology != null)
                                {
                                    List<IMaterialGenealogy> assembledMaterials = materialGeneology.Where(materialGeneology => materialGeneology.OperationName == "Assemble").ToList();

                                    if (!assembledMaterials.IsNullOrEmpty())
                                    {
                                        IMaterialCollection consumables = entityFactory.CreateCollection<IMaterialCollection>();
                                        IMaterialQuantityChangeCollection materialQuantityChanges = new MaterialQuantityChangeCollection();
                                        foreach (IMaterialGenealogy materialGenealogy in assembledMaterials)
                                        {
                                            if (!materialGenealogy.AffectedMaterials.IsNullOrEmpty())
                                            {
                                                foreach (IAffectedMaterial affectedMaterial in materialGenealogy.AffectedMaterials)
                                                {
                                                    IMaterial consumable = entityFactory.Create<IMaterial>();
                                                    consumable.Name = affectedMaterial.MaterialName;
                                                    consumable.Load();
                                                    // Get the integer part of the original value
                                                    decimal integerPart = Math.Truncate(consumable.PrimaryQuantity.Value);

                                                    // Subtract the integer part from the original value to get only the fractional part
                                                    decimal fractionalPart = consumable.PrimaryQuantity.Value - integerPart;

                                                    if (fractionalPart != 0 && fractionalPart < IKEAConstants.CustomAssembleMinimumAssumedQuantity)
                                                    {
                                                        materialQuantityChanges.Add(new MaterialQuantityChange() { Material = consumable, NewPrimaryQuantity = integerPart, });
                                                        consumables.Add(consumable);
                                                    }
                                                }
                                            }
                                        }
                                        if (!materialQuantityChanges.IsNullOrEmpty())
                                        {
                                            consumables.ChangeQuantity(materialQuantityChanges, new OperationAttributeCollection());
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            //---End DEE Code---
            return Input;
        }
    }
}
