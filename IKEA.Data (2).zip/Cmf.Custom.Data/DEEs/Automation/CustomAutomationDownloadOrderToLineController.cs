﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;

using Cmf.Custom.IKEA.BusinessObjects.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Exceptions;
using Cmf.Custom.IKEA.Common.Extensions;
using Cmf.Custom.IKEA.Common.Utilities;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects;
using Microsoft.Extensions.DependencyInjection;

using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading;

namespace Cmf.Custom.IKEA.Actions.Automation
{
    public class CustomAutomationDownloadOrderToLineController : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Downloads Orders To Automation
            /// Action Groups:
            ///     MaterialManagement.MaterialManagementOrchestration.ComplexTrackInMaterials.Post
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "MaterialManagement.MaterialManagementOrchestration.ComplexTrackInMaterials.Post"
            };

            // Only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            if (executionVeridict
                && IKEADEEActionUtilities.GetInputItem<ComplexTrackInMaterialsOutput>(Input, "ComplexTrackInMaterialsOutput") == null)
            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
            UseReference("", "Cmf.Custom.IKEA.BusinessObjects.Abstractions");
            
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.IO");
            UseReference("", "System.Threading");
            UseReference("", "System");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Navigo.Common.dll", "Cmf.Navigo.Common");
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Exceptions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            UseReference("Cmf.Custom.IKEA.BusinessObjects.CustomResourceConsumptionProvider.dll", "Cmf.Custom.IKEA.BusinessObjects");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Extensions");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IGenericUtilities _genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            ILocalizedMessage _localizedMessage = serviceProvider.GetService<ILocalizedMessage>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();

            ComplexTrackInMaterialsOutput output = IKEADEEActionUtilities.GetInputItem<ComplexTrackInMaterialsOutput>(Input, "ComplexTrackInMaterialsOutput");

            IResource resource = output.Resource;
            resource.Load();

            //Precondition: Check if Resource is in Automation Mode = ONLINE:
            if (resource.AutomationMode == ResourceAutomationMode.Online)
            {
                resource.LoadAttributes(new Collection<string>() {
                    IKEAConstants.ParentResourceLineName,
                    IKEAConstants.AutomationLineSpeedSubResourceController,
                    IKEAConstants.AutomationPalletOutMode,
                    IKEAConstants.MESAutomationInFeederSubResourceController,
                    IKEAConstants.CustomResourceDirectFeedingEnabled
                });

                IAutomationControllerInstance controllerInstance = resource.GetAutomationControllerInstance();

                // only proceed if automation is enabled
                if (controllerInstance != null)
                {

                    // Checks if it is necessary to refresh the consumable list in automation:
                    bool restoreConsumableQueue = _genericUtilities.GetConfigurationValueByPath<bool>(IKEAConstants.RestoreConsumableQueue);

                    // Get all the materials in process in main resource
                    List<int> systemStatesInProgress = new List<int>();
                    systemStatesInProgress.Add((int)MaterialSystemState.InProcess);
                    //Query for all materials in progress on the Resource
                    IMaterialCollection materialsInProcess = ikeaUtilities.GetMaterialsInProgressOnMainLine(resource.Id, systemStatesInProgress, false);
                    if (restoreConsumableQueue && materialsInProcess.Count == 1)
                    {
                        // Get all the online feeders with the respective materials from the resource:
                        Dictionary<IResource, IMaterialCollection> onlineConsumableFeedMaterials = ikeaUtilities.GetOnlineConsumableFeedsMaterials(resource);

                        // Send the consumable list to automation:
                        ikeaUtilities.SendConsumableListToAutomation(onlineConsumableFeedMaterials, resource, controllerInstance, IKEAConstants.AutomationRequestTypeRestoreConsumableQueue, true);
                    }

                    bool sync = _genericUtilities.GetConfigurationValueByPath<bool>(IKEAConstants.DownloadOrderToAutomationSendRequestSynchronously);
                    string requestType = IKEAConstants.TrackIn;

                    if (!string.IsNullOrWhiteSpace(requestType))
                    {

                        CustomPalletOutModeEnum palletOutMode = resource.GetAttributeValueOrDefault<CustomPalletOutModeEnum>(IKEAConstants.AutomationPalletOutMode);

                        int requestTimeout = _genericUtilities.GetConfigurationValueByPath<int>(IKEAConstants.DownloadOrderToAutomationSendRequestDefaultTimeout);

                        string orderForm = ikeaUtilities.GetOrderMaterialForm();

                        // for each tracked in topmost material, prepare the order download
                        foreach (IMaterial material in output.Materials)
                        {
                            if (material.IsChildOfGroupMO())
                            {
                                continue;
                            }

                            // only pick topmost
                            if (material.GetNativeValue<long>("ParentMaterial") == 0 && material.Form.CompareStrings(orderForm))
                            {
                                material.LoadAttributes(new Collection<string>() {
                                    IKEAConstants.ReadyToStartIsReadyForProduction,
                                    IKEAConstants.CustomMaterialAttributeOrderRunNumber,
                                    IKEAConstants.CustomMaterialAttributeDefaultCompletedQuantity,
                                    IKEAConstants.CustomMaterialAttributeIsGroupMO,
                                    IKEAConstants.CustomMaterialAttributeMaxIterations,
                                    IKEAConstants.CustomMaterialAttributeDirectFeedingMode
                                });

                                // Get subresources with automation online
                                List<FeederStructure> quantityInfeeder = new List<FeederStructure>();
                                List<ProductionCounterStructure> quantityOutsorted = new List<ProductionCounterStructure>();
                                List<ProductionCounterStructure> quantityOutfeeder = new List<ProductionCounterStructure>();

                                IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();

                                if (resource.HasRelations("SubResource", true))
                                {
                                    var resourceCollection = resource.RelationCollection["SubResource"];
                                    string mainFeederName = resource.GetAttributeValueOrDefault<string>(IKEAConstants.MESAutomationInFeederSubResourceController, true);

                                    // Dictionary between the TargetEntity.Id (the key) and the SourceEntity.Id (the value) of each distributed consumption provided
                                    // Both Ids represent a resource that should be a consumable feed
                                    Dictionary<long, long> distributedResources = new Dictionary<long, long>();
                                    if (!String.IsNullOrEmpty(mainFeederName))
                                    {
                                        IResource mainFeeder = entityFactory.Create<IResource>();
                                        mainFeeder.Name = mainFeederName;
                                        mainFeeder.Load();
                                        ICustomResourceConsumptionProviderCollection customDistributedConsumptionProviders = ikeaUtilities.GetDistributedProvidersFromFeeder(mainFeeder);

                                        if (customDistributedConsumptionProviders != null)
                                        {
                                            foreach (var relation in customDistributedConsumptionProviders)
                                            {
                                                distributedResources[relation.TargetEntity.Id] = relation.SourceEntity.Id;
                                            }
                                        }
                                    }

                                    #region Gather All BOM Products for this Manufacturing Order

                                    IBOMProductCollection materialBOMProducts = entityFactory.CreateCollection<IBOMProductCollection>();

                                    // If this material is a GroupMO, then what we really want is their children's BOM Products (since the GroupMO does not have a BOM itself)
                                    if (material.IsGroupMO(loadAttributes: false))
                                    {
                                        // We can avoid loading the material collection since we only really need is their names
                                        List<string> childrenNames = ikeaUtilities.GetChildMaterialsFromGroupMO(material, loadAttributes: false, loadCollection: false)
                                            .Select(child => child.Name)
                                            .ToList();

                                        materialBOMProducts = ikeaUtilities.GetCurrentBOMProductsFromMaterials(childrenNames);
                                    }
                                    else
                                    {
                                        materialBOMProducts = ikeaUtilities.GetCurrentBOMProductsFromMaterials(new List<string> { material.Name });
                                    }

                                    // If there are BOM Products, load their process and sub-process segments for later to be able to compare
                                    if (materialBOMProducts.Any())
                                    {
                                        materialBOMProducts.LoadAttributes(new Collection<string>
                                        {
                                            IKEAConstants.BomProductProcessSegmentAttribute,
                                            IKEAConstants.BomProductSubProcessSegmentAttribute,
                                        });
                                    }

                                    #endregion

                                    foreach (ISubResource subRes in resourceCollection)
                                    {
                                        IResource subResource = subRes.TargetEntity;
                                        subResource.LoadAttributes();
                                        if (subResource.AutomationMode == ResourceAutomationMode.Online)
                                        {

                                            if (subResource.ProcessingType == ProcessingType.ConsumableFeed && subResource.Type == IKEAConstants.ResourceTypeConsumable)
                                            {
                                                string feederProcessSegment = string.Empty;
                                                string feederSubProcessSegment = string.Empty;
                                                bool linked = distributedResources.ContainsKey(subResource.Id);

                                                bool isFeederInBOM = true;

                                                #region Validate if Feeder is included by the BOM

                                                // Only make these checks if there is any BOM Product. When there isn't,
                                                // keep the default true value and send all feeders
                                                if (materialBOMProducts.Any())
                                                {
                                                    IResource feederToVerifyInBOM = subResource;

                                                    // If this is a distributed feeder, then we don't search for it directly in the BOM,
                                                    // but rather we search for the other Feeder that this DistributedFeeder is related to
                                                    if (linked)
                                                    {
                                                        long distributedFeederRelatedId = distributedResources[subResource.Id];

                                                        // Grabs the related feeder by comparing Ids (should never be null, but just in case it is, we handle that below)
                                                        feederToVerifyInBOM = resourceCollection
                                                            .OfType<ISubResource>()
                                                            .Select(relation => relation.TargetEntity)
                                                            .FirstOrDefault(res => res.Id == distributedFeederRelatedId);
                                                    }

                                                    if (feederToVerifyInBOM != null)
                                                    {
                                                        // Grab the attributes from the feeder once (to avoid grabbing them inside the loop)
                                                        feederProcessSegment = feederToVerifyInBOM.GetAttributeValueOrDefault<string>(IKEAConstants.ProcessSegmentSequence);
                                                        feederSubProcessSegment = feederToVerifyInBOM.GetAttributeValueOrDefault<string>(IKEAConstants.SubProcessSegmentName);

                                                        // Check if any of the BOmProducts has a mtaching process segment and sub process segment
                                                        isFeederInBOM = materialBOMProducts.Any(bomProduct =>
                                                        {
                                                            return bomProduct.GetAttributeValueOrDefault<string>(IKEAConstants.BomProductProcessSegmentAttribute) == feederProcessSegment
                                                                && bomProduct.GetAttributeValueOrDefault<string>(IKEAConstants.BomProductSubProcessSegmentAttribute) == feederSubProcessSegment;
                                                        });
                                                    }
                                                    else
                                                    {
                                                        isFeederInBOM = false;
                                                    }
                                                }

                                                #endregion

                                                // Only add the feeder if it is referenced by the BOM (aka by any of the BOM Products)
                                                // This check was added to allow the clear of interlock when not all feeders are being used in an order
                                                if (isFeederInBOM)
                                                {
                                                    List<string> productsToConsider = new List<string>();

                                                    foreach (IBOMProduct bomProduct in materialBOMProducts)
                                                    {
                                                        string bOMProductProcessSegment = bomProduct.GetAttributeValueOrDefault<string>(IKEAConstants.BomProductProcessSegmentAttribute, true);
                                                        string bOMProductSubProcessSegment = bomProduct.GetAttributeValueOrDefault<string>(IKEAConstants.BomProductSubProcessSegmentAttribute, true);

                                                        if (bOMProductProcessSegment == feederProcessSegment && bOMProductSubProcessSegment == feederSubProcessSegment)
                                                        {
                                                            string targetEntity = bomProduct.TargetEntity.GetNativeValue<string>("Name");
                                                            if (!productsToConsider.Contains(targetEntity))
                                                            {
                                                                productsToConsider.Add(targetEntity);
                                                            }
                                                        }
                                                    }


                                                    FeederStructure feeder = new FeederStructure
                                                    {
                                                        Name = subResource.Name,
                                                        Value = 0,
                                                        DistributedMode = linked == false ? (bool?)null : linked,
                                                        ExpectedProducts = productsToConsider
                                                    };
                                                    quantityInfeeder.Add(feeder);
                                                }
                                            }
                                            if (subResource.Type == IKEAConstants.ResourceTypeOutsorter)
                                            {
                                                ProductionCounterStructure outsorter = new ProductionCounterStructure
                                                {
                                                    Name = subResource.Name,
                                                    TotalQuantity = 0,
                                                    PalletQuantity = 0
                                                };
                                                quantityOutsorted.Add(outsorter);
                                            }
                                            if (subResource.Type == IKEAConstants.ResourceTypeOutfeeder)
                                            {
                                                List<MultipleOrdersOutInfo> ordersQuantities = null;

                                                if (palletOutMode == CustomPalletOutModeEnum.MultipleOrdersOutSignal)
                                                {
                                                    if (material.IsGroupMO())
                                                    {
                                                        IMaterialCollection childMaterials = ikeaUtilities.GetChildMaterialsFromGroupMO(material);

                                                        if (childMaterials.Count > 0)
                                                        {

                                                            ordersQuantities = new List<MultipleOrdersOutInfo>();

                                                            foreach (IMaterial mat in childMaterials)
                                                            {
                                                                ordersQuantities.Add(new MultipleOrdersOutInfo()
                                                                {
                                                                    OrderName = mat.Name,
                                                                    Quantity = 0
                                                                });

                                                            }
                                                        }
                                                        else
                                                        {
                                                            throw new IKEAException(IKEAConstants.CustomMultiplePalletOutGroupMOHasNoSubOrdersMessage);
                                                        }

                                                    }
                                                    else
                                                    {
                                                        throw new IKEAException(IKEAConstants.CustomMultiplePalletOutOrderNotGroupMOMessage);
                                                    }

                                                }


                                                ProductionCounterStructure outfeeder = new ProductionCounterStructure
                                                {
                                                    Name = subResource.Name,
                                                    TotalQuantity = 0,
                                                    PalletQuantity = 0,
                                                    OrdersQuantities = ordersQuantities,
                                                };
                                                quantityOutfeeder.Add(outfeeder);
                                            }
                                        }


                                    }
                                }

                                Tuple<decimal, decimal?> resultOverProduction = ikeaUtilities.ResolveCustomOverProductionResolution(resource.Area.Facility, resource.Area, resource, null, material.Product, material.Product.ProductGroup);
                                decimal? overProduction = material.PrimaryQuantity;
                                if (resultOverProduction != null)
                                {
                                    decimal? overProductionPercentage = material.PrimaryQuantity * (1 + resultOverProduction.Item1 / 100);
                                    overProduction = resultOverProduction.Item2 < overProductionPercentage ? resultOverProduction.Item2 : overProductionPercentage;

                                }

                                string productName = material.Product.Name;
                                string productDescription = material.Product.Description;
                                if (material.Product.HasRelatedAttribute(IKEAConstants.CustomProductAttributeBaseProduct, true)
                                && !String.IsNullOrWhiteSpace(material.Product.RelatedAttributes[IKEAConstants.CustomProductAttributeBaseProduct].ToString()))
                                {
                                    productName = material.Product.RelatedAttributes[IKEAConstants.CustomProductAttributeBaseProduct].ToString();
                                }

                                OrderStructure orderStructure = new OrderStructure() { };

                                orderStructure.MaterialId = material.Id.ToString();
                                orderStructure.MaterialName = material.Name;

                                orderStructure.Quantity = Convert.ToDecimal(material.PrimaryQuantity, System.Globalization.CultureInfo.InvariantCulture);
                                orderStructure.QuantityProduced = 0;
                                orderStructure.QuantityConsumed = 0;
                                orderStructure.QuantityConsumedFinalIteration = 0;
                                orderStructure.QuantityOutsorted = quantityOutsorted;
                                orderStructure.QuantityOutfeeder = quantityOutfeeder;
                                orderStructure.OrderState = material.CurrentMainState.CurrentState.Name;
                                orderStructure.ProductName = productName;
                                orderStructure.ProductDescription = productDescription;
                                orderStructure.LineName = resource.Attributes[IKEAConstants.ParentResourceLineName].ToString();
                                //orderStructure.LineSpeed = 2.0;
                                orderStructure.PalletQuantity = material.HasAttribute(IKEAConstants.CustomMaterialAttributeDefaultCompletedQuantity) ?
                                    decimal.Parse(material.Attributes[IKEAConstants.CustomMaterialAttributeDefaultCompletedQuantity].ToString(), System.Globalization.CultureInfo.InvariantCulture) : 0;
                                orderStructure.IsReadyForProduction =
                                    material.HasAttribute(IKEAConstants.ReadyToStartIsReadyForProduction) ?
                                    bool.Parse(material.Attributes[IKEAConstants.ReadyToStartIsReadyForProduction].ToString()) : false;
                                orderStructure.QuantityInfeeder = quantityInfeeder.Count > 0 ? quantityInfeeder : null;
                                orderStructure.MaximumOverproductionQuantity = overProduction;
                                orderStructure.Run = material.HasAttribute(IKEAConstants.CustomMaterialAttributeOrderRunNumber) ? Int32.Parse(material.Attributes[IKEAConstants.CustomMaterialAttributeOrderRunNumber].ToString()) : 0;
                                orderStructure.MESQuantityProduced = 0;
                                // Get the quantity consumption per unit produced for the MO
                                orderStructure.ConsumptionPerUnitProduced = material.GetAttributeValueOrDefault<decimal>(IKEAConstants.CustomMaterialAttributeConsumptionPerUnitProduced, true);
                                orderStructure.MainFeederName = resource.GetAttributeValueOrDefault<string>(IKEAConstants.MESAutomationInFeederSubResourceController);
                                orderStructure.BaseUnitConversion = ikeaUtilities.CalculateConversionFactorFromMaterial(material);
                                orderStructure.Unit = material.PrimaryUnits;
                                orderStructure.MaxIterations = material.HasAttribute(IKEAConstants.CustomMaterialAttributeMaxIterations) ? Int32.Parse(material.Attributes[IKEAConstants.CustomMaterialAttributeMaxIterations].ToString()) : 0;

                                bool isResourceSetupDirectFeedingEnabled = resource.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomResourceDirectFeedingEnabled);
                                if (isResourceSetupDirectFeedingEnabled)
                                {
                                    orderStructure.DirectFeedingMode = material.GetAttributeValueOrDefault<CustomDirectFeedingModeEnum>(IKEAConstants.CustomMaterialAttributeDirectFeedingMode);
                                }
                                // Validate unit complete mode of resource
                                CustomUnitCompletionModeEnum unitCompletionMode = resource.GetAttributeValueOrDefault<CustomUnitCompletionModeEnum>(IKEAConstants.CustomResourceAttributeUnitCompletionMode, true);

                                // If it is groupMO and Manual Outsorting then add the sum of the partspercycle of all children to the order structure, else give default value of 1
                                if (material.IsGroupMO() && unitCompletionMode == CustomUnitCompletionModeEnum.ManualOutsorting)
                                {
                                    Dictionary<IMaterial, decimal> partsPerCycle = ikeaUtilities.GetChildMaterialsAndPartsPerCycleFromGroupMO(material);
                                    orderStructure.QuantityPerCycle = partsPerCycle.Values.Sum();
                                }
                                else
                                {
                                    orderStructure.QuantityPerCycle = 1;
                                }

                                if (material.GetNativeValue<long>("CurrentRecipeInstance") > 0)
                                {
                                    orderStructure.RecipeStructure = new List<RecipeStructure>();
                                    IRecipeInstanceCollection allRecipes = entityFactory.CreateCollection<IRecipeInstanceCollection>();
                                    material.CurrentRecipeInstance.LoadSubRecipeInstances();
                                    allRecipes.Add(material.CurrentRecipeInstance);

                                    // set up recipe name aggregator
                                    Dictionary<long, string> recipeNameAsset = new Dictionary<long, string>();
                                    if (material.CurrentRecipeInstance.SubRecipeInstances != null)
                                    {
                                        allRecipes.AddRange(material.CurrentRecipeInstance.SubRecipeInstances);
                                        material.CurrentRecipeInstance.SubRecipeInstances.ToList().ForEach(E => recipeNameAsset.Add(E.Id, E.ParentEntity.ResourceRecipeName));
                                        //material.CurrentRecipeInstance.SubRecipeInstances.ToList().ForEach(E => recipeNameAsset.Add(E.Id, E.SubRecipeDisplayName));
                                    }

                                    recipeNameAsset.Add(material.CurrentRecipeInstance.Id, IKEAConstants.DownloadOrderToAutomationDetailsTag); // main recipe is set as __, sub recipes get sub recipe instance display name

                                    IRecipeInstanceParameterCollection recipeInstanceParameters = entityFactory.CreateCollection<IRecipeInstanceParameterCollection>();

                                    allRecipes.LoadRelations(Cmf.Navigo.Common.Constants.RecipeInstanceParameter);

                                    recipeInstanceParameters.AddRange(allRecipes.Where(E => !E.RelationCollection.IsNullOrEmpty()
                                                                                            && E.RelationCollection.ContainsKey(Cmf.Navigo.Common.Constants.RecipeInstanceParameter)
                                                                                            && !E.RelationCollection[Cmf.Navigo.Common.Constants.RecipeInstanceParameter].IsNullOrEmpty())
                                                                                .SelectMany(E => E.RelationCollection[Cmf.Navigo.Common.Constants.RecipeInstanceParameter]).Select(E => E as IRecipeInstanceParameter));

                                    IParameterCollection parameters = entityFactory.CreateCollection<IParameterCollection>();

                                    Collection<long> parameterIds = new Collection<long>(recipeInstanceParameters.Select(rp => rp.GetNativeValue<long>("TargetEntity")).Distinct().ToList());
                                    parameters.LoadByIDs<IParameter, Parameter>(parameterIds);

                                    Dictionary<long, IParameter> recipeParameters = parameters.ToDictionary(p => p.Id, p => p);

                                    var RecipeParamValues = recipeInstanceParameters.Select(E =>
                                    {

                                        IParameter parameter = recipeParameters[E.GetNativeValue<long>("TargetEntity")];
                                        int? opcDataTypeAttribute = parameter.GetAttributeValueOrDefault<int?>(IKEAConstants.CustomOPCDataType, null, true);
                                        // If the attribute has a valid value, will assume it as the parameter data type. Otherwise uses the MES parameter data type.
                                        string dataType = opcDataTypeAttribute == null ? Convert.ToInt32(parameter.DataType).ToString() : opcDataTypeAttribute.ToJsonString();
                                        return new
                                        {
                                            ParamResource = recipeNameAsset[E.GetNativeValue<long>("SourceEntity")],
                                            ParamId = parameter.Id,
                                            ParamName = parameter.Name,
                                            ParamValue = E.Value.ToString(),
                                            ParamValueType = dataType,
                                            ParamUnits = parameter.DataUnit != null ? parameter.DataUnit.ToString() : ""
                                        };
                                    });

                                    var xGroupedValyues = RecipeParamValues.GroupBy(E => E.ParamResource);
                                    foreach (var entry in xGroupedValyues)
                                    {
                                        Dictionary<string, object> orderRecipeDetails = new Dictionary<string, object>();
                                        foreach (var detail in entry)
                                        {
                                            RecipeStructure order = new RecipeStructure()
                                            {
                                                ProcessSegment = detail.ParamResource != "__" ? detail.ParamResource : "Workcenter",
                                                ParameterId = detail.ParamId,
                                                ParameterName = detail.ParamName,
                                                ParameterValue = detail.ParamValue.ToString(),
                                                ParameterValueType = detail.ParamValueType,
                                                ParameterUnits = detail.ParamUnits
                                            };
                                            orderStructure.RecipeStructure.Add(order);
                                        }
                                    }

                                    if (RecipeParamValues.Contains(RecipeParamValues.FirstOrDefault(p => p.ParamName == "LineSpeed")))
                                    {
                                        orderStructure.LineSpeed = Convert.ToDouble(RecipeParamValues.FirstOrDefault(p => p.ParamName == "LineSpeed").ParamValue ?? "0");
                                    }
                                    else
                                    {
                                        orderStructure.LineSpeed = 0;
                                    }


                                    // For Parallel Execution we will need to check Parallel Mode for MO as well as retrieve and send linked products through new parameter
                                    if (orderStructure.RecipeStructure.Any(p => p.ParameterName == IKEAConstants.ParallelModeRecipeParameter))
                                    {
                                        // Retrieve information from smart table
                                        bool isInParallelMode;
                                        List<string> linkedParallelProducts;
                                        (isInParallelMode, linkedParallelProducts) = ikeaUtilities.ResolveCustomParallelExecutionRecipeModeSmartTable(material, resource);

                                        // Set Parallel Mode
                                        orderStructure.RecipeStructure.FirstOrDefault(p => p.ParameterName == IKEAConstants.ParallelModeRecipeParameter).ParameterValue = isInParallelMode ? "1" : "0";

                                        // Check if it is defined as Parallel Mode
                                        // If so, then the list of parallel products should be sent, if defined
                                        if (isInParallelMode)
                                        {

                                            // Get all the Parallel Products and define them on a single string separated by a specified config
                                            string separatorParallelProduct = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.ParallelExecutionParallelProductSeparator);

                                            // Join all names in list
                                            string parallelProductNames = String.Join(separatorParallelProduct, linkedParallelProducts.ToArray());

                                            // Check if Parallel Product Parameter already exists
                                            if (orderStructure.RecipeStructure.Any(p => p.ParameterName == IKEAConstants.ParallelProductRecipeParameter))
                                            {
                                                orderStructure.RecipeStructure.FirstOrDefault(p => p.ParameterName == IKEAConstants.ParallelProductRecipeParameter).ParameterValue = parallelProductNames;
                                            }
                                        }
                                    }


                                }

                                if (!sync)
                                {

                                    Dictionary<string, string> orderDownloadObject = _genericUtilities.RequestFromIoT<Dictionary<string, string>>(controllerInstance, requestType, orderStructure);

                                    bool downloadSucceeded;
                                    bool parseSuccessfull = bool.TryParse(orderDownloadObject[IKEAConstants.AutomationRequestReplyField], out downloadSucceeded);

                                    // Check if it was able to parse to bool
                                    if (!parseSuccessfull)
                                    {
                                        // Get localized message by response code
                                        string localizedMessage = ikeaUtilities.GetIoTLocalizedMessageFromResponseCode(orderDownloadObject[IKEAConstants.AutomationRequestReplyField]);
                                        string trackinErrorMessage = _localizedMessage.LoadLocalizedMessage(Thread.CurrentThread.CurrentCulture.Name, IKEAConstants.CustomTrackInFailedMessage).MessageText;

                                        throw new CmfBaseException(String.Concat(trackinErrorMessage, localizedMessage));
                                    }


                                }
                                else
                                {

                                    try
                                    {
                                        var obj = controllerInstance.SendRequest(requestType, orderStructure, requestTimeout);
                                        if (obj != null && obj.ToJsonString().Contains("Error"))
                                        {
                                            throw new IKEAException(IKEAConstants.CustomDownloadOrderToAutomationRequestFailedLocalizedMessage, requestType);
                                        }
                                        else if (obj == null)
                                        {
                                            throw new IKEAException(IKEAConstants.CustomIOTConnectionTimeoutLocalizedMessage, requestType);
                                        }

                                    }
                                    catch (Exception ex)
                                    {
                                        throw new Exception("Communication failed (sync)" + ex.ToString());
                                    }

                                }

                                //reset order download attributes:
                                IAttributeCollection OrderDownloadAttributes = new AttributeCollection
                                {
                                    {IKEAConstants.CustomMaterialAttributeOrderDownloadMessage, "" },
                                    {IKEAConstants.CustomMaterialAttributeOrderDownloadStatus, true }
                                };
                                material.SaveAttributes(OrderDownloadAttributes);

                            }

                        }
                    }
                    else
                    {
                        throw new IKEAException(IKEAConstants.CustomDownloadOrderToAutomationRequestOrderTokenNotDefinedLocalizedMessage);
                    }
                }
            }

            //---End DEE Code---

            return Input;
        }
    }
}
