﻿using Cmf.Custom.IKEA.Common;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;

namespace Cmf.Custom.IKEA.Actions.Automation
{
	public class CustomRestartMissingAutomationJobs : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
	{
		public override bool ValidateAction(Dictionary<string, object> Input)
		{
			//---Start DEE Condition Code---
			#region Info
			/// <summary>
			/// Summary text
			///     Restarts the missing IoT Jobs.
			/// </summary>
			#endregion
			return true;
			//---End DEE Condition Code--- 
		}

		public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
		{
			//---Start DEE Code--- 
			UseReference("", "Cmf.Foundation.Common.Exceptions");
			UseReference("Newtonsoft.Json.dll", "Newtonsoft.Json");
			UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");

			var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
			var entityFactory = serviceProvider.GetService<IEntityFactory>();

			List<long> missingAutomationJobIds = Newtonsoft.Json.JsonConvert.DeserializeObject<List<long>>(IKEADEEActionUtilities.GetInputItem<Object>(Input, "MissingAutomationJobIds")?.ToString());

			IAutomationJobCollection missingAutomationJobs = entityFactory.CreateCollection<IAutomationJobCollection>();
			missingAutomationJobs.LoadByIDs<IAutomationJob, AutomationJob>(missingAutomationJobIds);

			foreach (IAutomationJob missingAutomationJob in missingAutomationJobs)
			{
				if (missingAutomationJob.SystemState != Cmf.Foundation.BusinessObjects.ConnectIoT.AutomationJobSystemState.Error)
				{
					missingAutomationJob.SetError(IKEAConstants.AutomationJobUnknownStateAfterRestart, "Setting Error to Restart Job in the controller", true);
				}
				missingAutomationJob.Restart();
			}

			//---End DEE Code---

			return Input;

		}


	}
}
