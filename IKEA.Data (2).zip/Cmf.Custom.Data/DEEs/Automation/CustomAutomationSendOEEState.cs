﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;


namespace Cmf.Custom.IKEA.Actions.Automation
{
    public class CustomAutomationSendOEEState : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Sends information to IoT to update the tag with the OEE State and Reason information.
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.Resource.LogEvent.Post",
            };

            // only proceed if within expected triggers (action groups)
            bool isActionGroupValid = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            IStateModel stateModel = IKEADEEActionUtilities.GetInputItem<IStateModel>(Input, "StateModel");

            bool isReasonDefined = IKEADEEActionUtilities.GetInputItem<string>(Input, "Reason") != null;
            bool hasStateChanged = IKEADEEActionUtilities.GetInputItem<bool>(Input, "HasStateChanged");


            bool isOEEStateModel = stateModel.Name == IKEAConstants.StateModelOEE;

            return isActionGroupValid && isOEEStateModel && (isReasonDefined || hasStateChanged);

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            // System
            UseReference("", "System.Linq");
            UseReference("", "System");

            // Foundation
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");

            // MES
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");

            // Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Extensions");
            

            IResource logEventResource = IKEADEEActionUtilities.GetInputItem<IResource>(Input, "Resource");
            logEventResource.Load();

            if (logEventResource.AutomationMode != ResourceAutomationMode.Online)
            {
                return Input;
            }

            IAutomationControllerInstance controllerInstance = logEventResource.GetAutomationControllerInstance();
            if (controllerInstance == null)
            {
                return Input;
            }


            if (logEventResource.CurrentMainState != null && logEventResource.CurrentMainState.CurrentState != null)
            {
                string state = logEventResource.CurrentMainState.CurrentState.Name;
                string reason = logEventResource.CurrentMainState.Reason;

                string stateAndReason = $"{state} - {reason}";

                // Prepare details to publish IoT to set State and Reason on LC
                Dictionary<string, object> details = new Dictionary<string, object>();
                details.Add("StateAndReason", stateAndReason);

                controllerInstance.Publish(IKEAConstants.AutomationRequestSendOEEStateToLC, details.ToJsonString());
            }

            //---End DEE Code---

            return Input;
        }

    }
}
