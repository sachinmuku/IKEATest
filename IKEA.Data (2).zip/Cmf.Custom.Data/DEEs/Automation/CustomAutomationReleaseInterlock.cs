﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.ResourceManagement.InputObjects;
using Cmf.Navigo.BusinessOrchestration.ResourceManagement.OutputObjects;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.Automation
{
    public class CustomAutomationReleaseInterlock : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Sends request to IOT indicating that it must release interlock
            /// Action Groups:
            ///     "ResourceManagement.ResourceManagementOrchestration.FullUpdateResource.Pre",
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "ResourceManagement.ResourceManagementOrchestration.FullUpdateResource.Pre",
                "ResourceManagement.ResourceManagementOrchestration.FullUpdateResource.Post",
                "BusinessObjects.ResourceCollection.ChangeAutomationMode.Post",
                "BusinessObjects.ResourceCollection.ChangeAutomationMode.Pre"
            };

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            if (executionVeridict && (IKEADEEActionUtilities.GetInputItem<FullUpdateResourceInput>(Input, "FullUpdateResourceInput") == null && IKEADEEActionUtilities.GetInputItem<IResourceCollection>(Input, "ResourceCollection") == null))
            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("", "System");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.ResourceManagement.InputObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.ResourceManagement.OutputObjects");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Extensions");
            UseReference("Cmf.Custom.IKEA.Orchestration.dll", "Cmf.Custom.IKEA.Orchestration.InputObjects");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            INiceLabelUtilities nbUtilities = serviceProvider.GetService<INiceLabelUtilities>();
            ILocalizedMessage _localizedMessage = serviceProvider.GetService<ILocalizedMessage>();
            IGenericUtilities _genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();

            //DEE context 
            DeeContext currentDEEContext = deeContextUtilities.SetCurrentServiceContext("CustomAutomationReleaseInterlock");
            string currentContext = "InitialAutomationModeContext";


            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();

            if (currentDEEContext.TriggerPoint == DeeTriggerPoint.Pre)
            {
                IResource resource = entityFactory.Create<IResource>();

                if (currentDEEContext.MethodName == "FullUpdateResource")
                {
                    FullUpdateResourceInput fullUpdateResourceInput = IKEADEEActionUtilities.GetInputItem<FullUpdateResourceInput>(Input, "FullUpdateResourceInput");

                    resource.Name = fullUpdateResourceInput.Resource.Name;
                }
                else if (currentDEEContext.MethodName == "ChangeAutomationMode")
                {

                    IResourceCollection resourceCollection = IKEADEEActionUtilities.GetInputItem<IResourceCollection>(Input, "ResourceCollection");

                    resource.Name = resourceCollection.FirstOrDefault()?.Name;
                }

                if (resource.Name != null)
                {
                    resource.Load();
                    deeContextUtilities.SetContextParameter(currentContext, resource.AutomationMode);
                }

            }

            if (currentDEEContext.TriggerPoint == DeeTriggerPoint.Post)
            {
                ResourceAutomationMode? initialAutomationMode = (ResourceAutomationMode?)(deeContextUtilities.GetContextParameter(currentContext));
                IResource resource = null;
                if (currentDEEContext.MethodName == "FullUpdateResource")
                {
                    FullUpdateResourceOutput fullUpdateResourceOutput = IKEADEEActionUtilities.GetInputItem<FullUpdateResourceOutput>(Input, "FullUpdateResourceOutput");
                    resource = fullUpdateResourceOutput.Resource;
                }
                else if (currentDEEContext.MethodName == "ChangeAutomationMode")
                {
                    IResourceCollection resourceCollection = IKEADEEActionUtilities.GetInputItem<IResourceCollection>(Input, "ResourceCollection");
                    resource = resourceCollection.FirstOrDefault();

                }

                if (resource != null && initialAutomationMode != null)
                {

                    if (initialAutomationMode != resource.AutomationMode)
                    {
                        bool interlockValue = false;

                        if (initialAutomationMode != ResourceAutomationMode.Online && resource.AutomationMode == ResourceAutomationMode.Online)
                        {
                            interlockValue = true;
                        }

                        IAutomationControllerInstance controllerInstance = resource.GetAutomationControllerInstance();
                        if (controllerInstance != null)
                        {
                            Dictionary<string, string> releaseInterlockObject = _genericUtilities.RequestFromIoT<Dictionary<string, string>>(controllerInstance, IKEAConstants.AutomationRequestReleaseInterlockOnAutomationModeChange, interlockValue);
                        }

                    }

                }


            }

            //---End DEE Code---
            return Input;
        }
    }
}
