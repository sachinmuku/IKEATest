﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;

using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Exceptions;
using Cmf.Custom.IKEA.Common.Extensions;
using Cmf.Custom.IKEA.Common.Utilities;
using Cmf.Custom.IKEA.Orchestration.Abstractions;
using Cmf.Custom.IKEA.Orchestration.InputObjects;
using Cmf.Custom.IKEA.Orchestration.OutputObjects;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
//
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading;

namespace Cmf.Custom.IKEA.Actions.Automation
{
    public class CustomAutomationPartialTrackOut : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Downloads Orders To Automation
            /// </summary>
            #endregion
            var executionVeridict = true;
            if (IKEADEEActionUtilities.GetInputItem<string>(Input, "MaterialName") == null
                && IKEADEEActionUtilities.GetInputItem<string>(Input, "PalletQuantity") == null)
            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            // System
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.IO");
            UseReference("", "System.Threading");
            UseReference("", "System");
            UseReference("Newtonsoft.Json.dll", "Newtonsoft.Json");

            // Foundation
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");

            // MES
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");

            // Custom
            UseReference("Cmf.Custom.IKEA.Orchestration.dll", "Cmf.Custom.IKEA.Orchestration.InputObjects");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Orchestration.OutputObjects");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Orchestration.Abstractions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Extensions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Exceptions");
            

            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            var iKEABusinessManagementOrchestration = serviceProvider.GetService<IIKEABusinessManagementOrchestration>();
            IEntityFactory entityFactory = serviceProvider.GetRequiredService<IEntityFactory>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();

            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IDirectFeedingUtilities drUtilities = serviceProvider.GetService<IDirectFeedingUtilities>();
            ILocalizedMessage _localizedMessage = serviceProvider.GetService<ILocalizedMessage>();
            IGenericUtilities _genericUtilities = serviceProvider.GetService<IGenericUtilities>();


            // Store InitialShiftQuantity in a Context Parameter to be used on CustomUnitComplete service
            // This will be needed to update the tracked out Material Attribute "CustomInitialShiftQuantity" when is Loss Trackout
            decimal? initialShiftQuantity = Input.ContainsKey("InitialShiftQuantity")
                ? Convert.ToDecimal(Input["InitialShiftQuantity"])
                : null;

            if (initialShiftQuantity != null)
            {
                deeContextUtilities.SetContextParameter("InitialShiftQuantity", initialShiftQuantity);
            }

            Dictionary<string, object> output = new Dictionary<string, object>();

            string materialName = IKEADEEActionUtilities.GetInputItem<string>(Input, "MaterialName");
            bool isToSpecialAttach = IKEADEEActionUtilities.GetInputItem<bool>(Input, "IsToSpecialAttach");

            decimal palletQuantity = Convert.ToDecimal(Input["PalletQuantity"].ToString(), System.Globalization.CultureInfo.InvariantCulture);
            string type = Input["Type"].ToString();
            object aux;
            decimal totalConsumed = 0;
            Dictionary<string, decimal> materialsToConsume = new Dictionary<string, decimal>();
            if (Input.TryGetValue("MaterialsToConsume", out aux))
            {
                materialsToConsume = (aux as Dictionary<string, object>).ToDictionary(E => E.Key, E => Convert.ToDecimal(E.Value));
            }
            bool explicitMode = IKEADEEActionUtilities.GetInputItem<bool>(Input, "Mode");


            // Get the default Outsorted Type
            string outsortedMaterialType = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.CustomOutsortedMaterialDefaultTypePath);

            IMaterial moMaterial = entityFactory.Create<IMaterial>();
            moMaterial.Load(materialName);

            // Get Order Form
            string orderForm = ikeaUtilities.GetOrderMaterialForm();

            // Load MO attributes
            moMaterial.LoadAttributes(new Collection<string>
            {
                IKEAConstants.MaterialAttributeIsInLineDirectRepair,
                IKEAConstants.CustomMaterialAttributeIsGroupMO
            });

            // Validate InLine attribute
            bool isInline = moMaterial.GetAttributeValueOrDefault<bool>(IKEAConstants.MaterialAttributeIsInLineDirectRepair, false);

            // Check if is a group MO:
            bool isGroupMo = moMaterial.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomMaterialAttributeIsGroupMO, false);


            // Needs load to fill automation mode
            IResource mainLine = moMaterial.LastProcessedResource;
            mainLine.Load();
            CustomPalletOutModeEnum automationPalletOutMode = mainLine.GetAttributeValueOrDefault<CustomPalletOutModeEnum>(IKEAConstants.AutomationPalletOutMode, true);

            // Create a collection to gather all materials to perform trackout:
            IMaterialCollection moMaterials = entityFactory.CreateCollection<IMaterialCollection>();

            // In case of group Mos scenario set the quantity to deduct on the groupmo primary quantity:
            decimal quantityToRemoveFromGroupMO = 0;

            bool isLeftOver = false;

            // In the case that we have a group MO, get info from the child MOs:
            Dictionary<IMaterial, decimal> groupMoMaterialInformation = new Dictionary<IMaterial, decimal>();
            if (isGroupMo)
            {
                //moMaterial is Group Mo
                groupMoMaterialInformation = ikeaUtilities.GetChildMaterialsAndPartsPerCycleFromGroupMO(moMaterial, false);

                if (automationPalletOutMode == CustomPalletOutModeEnum.MultipleOrdersOutSignal)
                {

                    List<string> childrenNames = groupMoMaterialInformation.Keys.Select(child => child.Name).ToList();

                    Dictionary<string, IBOMProductCollection> materialBOMProducts = ikeaUtilities.GetCurrentBOMProductsWithMOsFromMaterials(childrenNames);

                    if (materialBOMProducts.Any())
                    {
                        IBOMProduct bOMProduct = null;
                        IMaterial moToSaveLeftOver = null;

                        #region Get the Bom Product with ByProduct as true and the respective material
                        foreach (string moName in materialBOMProducts.Keys)
                        {
                            materialBOMProducts[moName].LoadAttributes(new Collection<string>
                                {
                                    IKEAConstants.BomProductIsByProductSegmentAttribute
                                });

                            //If there is a by-product is to calculate the left-over in MES
                            if (materialBOMProducts[moName].Any(d => d.GetAttributeValueOrDefault<bool>(IKEAConstants.BomProductIsByProductSegmentAttribute)))
                            {
                                bOMProduct = materialBOMProducts[moName].Where(d => d.GetAttributeValueOrDefault<bool>(IKEAConstants.BomProductIsByProductSegmentAttribute)).FirstOrDefault(); ;
                                moToSaveLeftOver = groupMoMaterialInformation.Keys.Where(m => m.Name == moName).FirstOrDefault();
                            }
                        }
                        #endregion

                        //Get the Bom Product with by-product as true
                        if (moToSaveLeftOver != null && bOMProduct != null)
                        {
                            IProduct productLeftOver = bOMProduct.TargetEntity;
                            productLeftOver.Load();
                            ikeaUtilities.CreateLeftOvers(moToSaveLeftOver, productLeftOver, palletQuantity, true, true);
                            isLeftOver = true;
                        }
                    }
                }
                moMaterials.AddRange(groupMoMaterialInformation.Keys);
            }
            else
            {
                // If MultipleOrdersOutSignal, (Scheling line) we are receiving a child of a group MO:
                // Necessary to reduce the total quantity in the associated GroupMo
                if (automationPalletOutMode == CustomPalletOutModeEnum.MultipleOrdersOutSignal)
                {
                    quantityToRemoveFromGroupMO = palletQuantity;
                }

                moMaterials.Add(moMaterial);
            }

            if (!isLeftOver)
            {
                // If the MO is configured to have a Inline Direct Repair and the received type is outsorted
                // change it to Direct Repair
                if (isInline && type.CompareStrings(outsortedMaterialType))
                {
                    // Get Direct Repair Type
                    type = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.CustomDirectRepairMaterialDefaultTypePath);
                }

                Dictionary<IResource, List<IMaterial>> materialsToConsumeMap = new Dictionary<IResource, List<IMaterial>>();
                if (explicitMode)
                {
                    // if there are undefined pieces, it means that they were not consumed on IoT. 
                    // It will throw an exception to activate the interlock and wait for those pieces to be consumed through manual loading
                    if (materialsToConsume.Any((mat) => mat.Key.IsNullOrEmpty()))
                    {
                        throw new Exception(_localizedMessage.LoadLocalizedMessage(Thread.CurrentThread.CurrentCulture.Name, IKEAConstants.CustomAutomationFailedTrackoutUndefinedPieces).MessageText);
                    }
                    if (moMaterial.Form.Equals(orderForm))
                    {

                        foreach (var material in materialsToConsume)
                        {
                            IMaterial mat = entityFactory.Create<IMaterial>();
                            mat.Load(Int64.Parse(material.Key));
                            mat.PrimaryQuantity = material.Value;
                            totalConsumed += material.Value;


                            IResource feeder = null;
                            if (mat.HasRelations("MaterialResource", true))
                            {
                                feeder = mat.RelationCollection["MaterialResource"][0].TargetEntity as IResource;
                            }

                            // The material is not attached to the feeder anymore. Try to get it from the SourceConsumptionMaterial attribute:
                            if (feeder == null)
                            {
                                // Get only the online feeders of the main line:
                                var onlineConsumableFeedsMaterials = ikeaUtilities.GetOnlineConsumableFeedsMaterials(mainLine);
                                foreach (var consumableFeedMaterials in onlineConsumableFeedsMaterials)
                                {
                                    // Load attribute CustomSourceConsumptionMaterial in all materials:
                                    consumableFeedMaterials.Value.LoadAttributes(new Collection<string> { IKEAConstants.CustomSourceConsumptionMaterial });

                                    // Check if any material contains the name of the source material in the attribute (the material from where it was splitted):
                                    if (consumableFeedMaterials.Value.Where(CFM => CFM.GetAttributeValueOrDefault<string>(IKEAConstants.CustomSourceConsumptionMaterial).CompareStrings(mat.Name)).Any())
                                    {
                                        feeder = consumableFeedMaterials.Key;
                                        break;
                                    }
                                }
                            }

                            // If the feeder was not found, throw an error:
                            if (feeder == null)
                            {
                                string sourceConsumptionMaterial = mat.GetAttributeValueOrDefault<string>(IKEAConstants.CustomSourceConsumptionMaterial, true);
                                throw new IKEAException(IKEAConstants.CustomFeederNotFoundForTheSpecifiedAttachedMaterialLocalizedMessage,
                                                                                             mat.Name,
                                                                                             sourceConsumptionMaterial ?? "");
                            }


                            if (materialsToConsumeMap.Any(f => f.Key.Id == feeder.Id))
                            {
                                materialsToConsumeMap.Where(f => f.Key.Id == feeder.Id).FirstOrDefault().Value.Add(mat);
                            }
                            else
                            {
                                materialsToConsumeMap.Add(feeder, new List<IMaterial>() { mat });
                            }

                        }

                        decimal completedQuantity = 0;

                        foreach (var material in moMaterials)
                        {
                            // Set the adjusted quantity to default:
                            decimal adjustedQuantity = totalConsumed;

                            // If we are dealing with MOs that belong to a GroupMO, we must check the parts per cycle:
                            if (!groupMoMaterialInformation.IsNullOrEmpty())
                            {
                                // Get the parts per cyle value:
                                decimal partsPerCycle = groupMoMaterialInformation.Where(GMI => GMI.Key.Id == material.Id).First().Value;

                                // Update the quantity to trackout according to the number of parts per cycle:
                                adjustedQuantity = palletQuantity * partsPerCycle;

                                quantityToRemoveFromGroupMO += adjustedQuantity;
                            }

                            // Store OutFeeder name in a Context Parameter to be used on CustomUnitComplete service
                            // This will be needed to update the tracked out Material Attribute "CustomInitialShiftQuantity"
                            string outfeederName = IKEADEEActionUtilities.GetInputItem<string>(Input, IKEAConstants.OutfeederName);
                            if (outfeederName != null && outfeederName != string.Empty)
                            {
                                deeContextUtilities.SetContextParameter(IKEAConstants.OutfeederName, outfeederName);
                            }


                            Cmf.Custom.IKEA.Orchestration.OutputObjects.CustomUnitCompleteOutput customUnitCompleteOutput = iKEABusinessManagementOrchestration.CustomUnitComplete(new CustomUnitCompleteInput()
                            {
                                ProcessOrderMaterial = material,
                                CompletedPrimaryQuantity = adjustedQuantity,
                                CompletedSecondaryQuantity = null,
                                ExcludeTrackout = false,
                                IgnoreOrderMaterialState = true,
                                CompletedUnitType = type,
                                IsProcessLoss = false,
                                IsAutomationInvoke = true,
                                MaterialsToConsume = materialsToConsumeMap
                            });

                            completedQuantity += customUnitCompleteOutput.CompletedQuantity;
                        }

                        output.Add(("CompletedQuantity"), completedQuantity);
                        output.Add("OrderName", moMaterial.Name);
                        return output;
                    }
                }
                else if (palletQuantity > 0 || type == "Loss")
                {
                    if (moMaterial.Form.Equals(orderForm))
                    {

                        bool processLoss = false;
                        if (type == "Loss")
                        {
                            processLoss = true;
                            type = outsortedMaterialType;
                        }

                        foreach (var material in moMaterials)
                        {
                            // Set the adjusted quantity to default:
                            decimal adjustedQuantity = palletQuantity;

                            // If we are dealing with MOs that belong to a GroupMO, we must check the parts per cycle:
                            if (!groupMoMaterialInformation.IsNullOrEmpty())
                            {
                                // Get the parts per cyle value:
                                decimal partsPerCycle = groupMoMaterialInformation.Where(GMI => GMI.Key.Id == material.Id).First().Value;

                                // Update the quantity to trackout according to the number of parts per cycle:
                                adjustedQuantity = palletQuantity * partsPerCycle;

                                quantityToRemoveFromGroupMO += adjustedQuantity;
                            }



                            // If it's direct feeding
                            bool isDirectFeedingEnabled = _genericUtilities.GetConfigurationValueByPath<bool>(IKEAConstants.EnableDirectFeedingConfig);
                            if (isDirectFeedingEnabled && isToSpecialAttach)
                            {
                                IResource line = material.LastProcessedResource;
                                line.Load();

                                CustomDirectFeedingModeEnum materialDirectFeedingMode = material.GetAttributeValueOrDefault<CustomDirectFeedingModeEnum>(IKEAConstants.CustomMaterialAttributeDirectFeedingMode, loadAttribute: true);
                                bool isLineUsingDirectFeeding = line.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomResourceDirectFeedingEnabled, loadAttribute: true);
                                bool directFeedingIsFirstLine = line.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomResourceDirectFeedingIsFirstLine, loadAttribute: true);

                                // Only if the request comes from the second line
                                if (materialDirectFeedingMode == CustomDirectFeedingModeEnum.DirectFeeding
                                    && isLineUsingDirectFeeding
                                    && !directFeedingIsFirstLine)
                                {

                                    // Calculate quantity to palletize
                                    decimal fullQuantity = drUtilities.CalculateDirectFeedingQuantityAccordingWithBomRatio(line, material, adjustedQuantity);

                                    // Get resource counterpart
                                    IResource firstLine = drUtilities.GetDirectFeedingCounterpartResource(mainLine);

                                    if (firstLine == null)
                                    {
                                        throw new IKEAException(IKEAConstants.CustomDirectFeedingResourceCounterPartNoValid, line.Name);
                                    }

                                    // Get counterpart material
                                    string counterpartMaterialName = material.GetAttributeValueOrDefault<string>(IKEAConstants.CustomMaterialAttributeDirectFeedingCounterPart, loadAttribute: true);
                                    IMaterial counterpartMaterial = entityFactory.Create<IMaterial>();
                                    counterpartMaterial.Name = counterpartMaterialName;

                                    // Flag to determine if counterpart material is valid
                                    bool isCounterpartMaterialValid = drUtilities.ValidateCounterpartMaterialForPalletization(counterpartMaterial, fullQuantity);

                                    // If the counterpart material is valid then continue with process
                                    if (isCounterpartMaterialValid)
                                    {

                                        // Perform trackout, move-next and attach, with necessary quantity to pallet created on counter part line, the service will validate quantity
                                        try
                                        {
                                            string completedUnitType = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.DefaultGoodTypeConfig);

                                            // Store OutFeeder name in a Context Parameter to be used on CustomUnitComplete service
                                            // This will be needed to update the tracked out Material Attribute "CustomInitialShiftQuantity"
                                            firstLine.Load();
                                            firstLine.LoadAttribute(IKEAConstants.CustomDirectFeedingOutfeederResource);

                                            if (firstLine.Attributes.TryGetValue(IKEAConstants.CustomDirectFeedingOutfeederResource, out object outfeederNameDF))
                                            {
                                                deeContextUtilities.SetContextParameter(IKEAConstants.OutfeederName, outfeederNameDF.ToString());
                                            }

                                            // DIRECT FEEDING
                                            // Invoke palletization service
                                            IMaterial palletProduced = iKEABusinessManagementOrchestration.CustomUnitComplete(
                                                    new CustomUnitCompleteInput()
                                                    {
                                                        ProcessOrderMaterial = counterpartMaterial,
                                                        CompletedPrimaryQuantity = fullQuantity,
                                                        CompletedSecondaryQuantity = null,
                                                        ExcludeTrackout = false,
                                                        IgnoreOrderMaterialState = true,
                                                        CompletedUnitType = completedUnitType,
                                                        IsProcessLoss = false,
                                                        IsAutomationInvoke = true
                                                    }).CompletedUnit;

                                            // Get counterpart resource and main feeder
                                            string counterpartMainFeederName = mainLine.GetAttributeValueOrDefault<string>(IKEAConstants.MESAutomationInFeederSubResourceController, true);
                                            IResource counterpartMainFeeder = entityFactory.Create<IResource>();
                                            counterpartMainFeeder.Name = counterpartMainFeederName;
                                            counterpartMainFeeder.Load();

                                            // Get consumption flow path
                                            string consumptionFlowPath = ikeaUtilities.ResolveConsumptionMaterialFlowByResource(resource: counterpartMainFeeder);

                                            // Perform move-next and attach operations
                                            deeContextUtilities.SetContextParameter(IKEAConstants.CustomDirectFeedingIsToSpecialAttach, true);
                                            deeContextUtilities.SetContextParameter(IKEAConstants.CustomDirectFeedingAutomaticAttach, true);

                                            IStep consumptionStep = _genericUtilities.GetStepByFlowPath(consumptionFlowPath);
                                            IFlow consumptionFlow = _genericUtilities.GetFlowsInFlowPath(consumptionFlowPath).FirstOrDefault();
                                            palletProduced.ChangeFlowAndStep(consumptionFlow, consumptionFlowPath, consumptionStep, new OperationAttributeCollection { });
                                            ikeaUtilities.ApplyOperationActions(palletProduced, counterpartMainFeeder, "Attach");

                                            // Send request to IoT
                                            drUtilities.SendRequestReducePalletQuantityOnOutfeeder(firstLine, counterpartMaterial, fullQuantity);

                                        }
                                        catch (Exception ex)
                                        {
                                            throw new IKEAException(IKEAConstants.CustomPalletizeNotSuccessfulOnFirstLine, ex.Message);
                                        }
                                    }
                                }
                            }

                            // Store OutFeeder name in a Context Parameter to be used on CustomUnitComplete service
                            // This will be needed to update the tracked out Material Attribute "CustomInitialShiftQuantity"
                            string outfeederName = IKEADEEActionUtilities.GetInputItem<string>(Input, IKEAConstants.OutfeederName);
                            if (outfeederName != null && outfeederName != string.Empty)
                            {
                                deeContextUtilities.SetContextParameter(IKEAConstants.OutfeederName, outfeederName);
                            }

                            CustomUnitCompleteOutput customUnitCompleteOutput = iKEABusinessManagementOrchestration.CustomUnitComplete(new CustomUnitCompleteInput()
                            {
                                ProcessOrderMaterial = material,
                                CompletedPrimaryQuantity = adjustedQuantity,
                                CompletedSecondaryQuantity = null,
                                ExcludeTrackout = false,
                                IgnoreOrderMaterialState = true,
                                CompletedUnitType = type,
                                IsProcessLoss = processLoss,
                                IsAutomationInvoke = true
                            });

                            if (!string.IsNullOrEmpty(outfeederName) && !processLoss)
                            {
                                //SendPallettoLC Task
                                IResource outfeeder = entityFactory.Create<IResource>();
                                outfeeder.Load(outfeederName);
                                IResource lineResource = moMaterial.LastProcessedResource;
                                lineResource.Load();
                                ikeaUtilities.CustomAutomationSendPalletIDtoLC(lineResource, outfeeder, customUnitCompleteOutput.CompletedUnit);
                            }

                            string defaultGoodMaterialType = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.DefaultGoodTypeConfig);
                            if (type == defaultGoodMaterialType)
                            {
                                // On direct feeding, the pallet created, if setup properly, should attach to the counterpart of the current resource
                                drUtilities.DirectFeedingMovePalletToCounterPartResource(customUnitCompleteOutput.CompletedUnit);
                            }

                        }

                    }
                }
                else if (palletQuantity == 0)
                {
                    // if pallet quantity is 0, and the trackout was activated by the Force Unit Completion, 
                    // it is necessary to reset the ManualCompletionInProgress attribute so the button becomes available again
                    IAttributeCollection attributesToRemove = new AttributeCollection()
                    {
                        { IKEAConstants.CustomMaterialAttributeManualCompletionInProgress, false }
                    };

                    // Remove the attributes from the materials
                    moMaterials.RemoveAttributes(attributesToRemove);
                }


                if (isGroupMo)
                {
                    IAttributeCollection attributesToRemove = new AttributeCollection()
                    {
                        { IKEAConstants.CustomMaterialAttributeManualCompletionInProgress, false }
                    };
                    moMaterial.Load();
                    // Remove the attributes from the Group MO (it is not being handled on the Custom Unit Complete)
                    moMaterial.RemoveAttributes(attributesToRemove);
                }

                // Update the Group MO primary quantity by subtracting the accumulated value of the child Mos: 
                if (quantityToRemoveFromGroupMO > 0)
                {
                    deeContextUtilities.SetContextParameter(IKEAConstants.CustomUnitCompleteHandlerUpdateGroupMOQuantityContextKey, true);

                    decimal newGroupMOQuantity = 0;
                    if (isGroupMo)
                    {
                        newGroupMOQuantity = moMaterial.PrimaryQuantity.Value - quantityToRemoveFromGroupMO;
                        moMaterial.ChangeQuantity(newGroupMOQuantity, 0, null, null, null);
                    }
                    else
                    {
                        IMaterial groupMo = moMaterial.GetGroupMOFromChild();
                        if (groupMo != null)
                        {
                            newGroupMOQuantity = groupMo.PrimaryQuantity.Value - quantityToRemoveFromGroupMO;
                            groupMo.ChangeQuantity(newGroupMOQuantity, 0, null, null, null);
                        }
                    }

                    deeContextUtilities.SetContextParameter(IKEAConstants.CustomUnitCompleteHandlerUpdateGroupMOQuantityContextKey, false);
                }
            }

            //---End DEE Code---

            return Input;
        }

    }
}
