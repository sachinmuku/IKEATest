﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Custom.IKEA.Common;
using Cmf.Navigo.BusinessObjects;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Linq;
using System.Collections.Generic;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Custom.IKEA.Orchestration.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Foundation.BusinessObjects;

using Cmf.Custom.IKEA.Orchestration.InputObjects;
using Cmf.Custom.IKEA.Orchestration.OutputObjects;

namespace Cmf.Custom.IKEA.Actions.Automation
{
    public class CustomAutomationForceOrderCompletionFromIoT : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code--- 
            #region Info
            /// <summary>
            /// Summary text
            ///     Receives a MO name and verifies if the conditions to advance with the complete process are met
            /// </summary>
            #endregion
            var executionVerdict = true;
            if (IKEADEEActionUtilities.GetInputItem<string>(Input, "MaterialName") == null)
            {
                executionVerdict = false;
            }

            return executionVerdict;
            //---End DEE Condition Code--- 
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code--- 
            // CORE
            UseReference("", "Cmf.Custom.IKEA.Orchestration.Abstractions");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.GenericServiceManagement.OutputObjects");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.GenericServiceManagement.InputObjects");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "");
            UseReference("", "Cmf.Foundation.Common.Exceptions");
            UseReference("", "Cmf.Foundation.Common");

            // MES
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            // CUSTOM
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Orchestration.dll", "Cmf.Custom.IKEA.Orchestration");
            UseReference("Cmf.Custom.IKEA.Orchestration.dll", "Cmf.Custom.IKEA.Orchestration.InputObjects");

            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            var iKEABusinessManagementOrchestration = serviceProvider.GetService<IIKEABusinessManagementOrchestration>();

            string materialName = IKEADEEActionUtilities.GetInputItem<string>(Input, "MaterialName");

            var entityFactory = serviceProvider.GetService<IEntityFactory>();

            IMaterial materialMO = entityFactory.Create<IMaterial>();
            materialMO.Name = materialName;
            materialMO.Load();

            // Call service to Force Order Completion
            Cmf.Custom.IKEA.Orchestration.OutputObjects.CustomForceOrderCompletionOutput customForceOrderCompletionOutput = iKEABusinessManagementOrchestration.CustomForceOrderCompletion(new CustomForceOrderCompletionInput()
            {
                IgnoreLastServiceId = true,
                Material = materialMO
            });

            return Input;
            //---End DEE Code--- 

        }
    }
}
