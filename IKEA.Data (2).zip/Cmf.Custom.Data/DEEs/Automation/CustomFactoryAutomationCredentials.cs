﻿using Cmf.Custom.IKEA.Common;
using Cmf.Foundation.Common;
using Cmf.Foundation.Configuration;
using System.Collections.Generic;
using System.Data.Common;

namespace Cmf.Custom.IKEA.Actions.Automation
{
    /// <summary>
    /// Returns database information to Factory Automation
    /// </summary>
    public class CustomFactoryAutomationCredentials : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            return true;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
            UseReference("%MicrosoftNetPath%\\System.Data.Common.dll", "System.Data.Common");
            UseReference("Cmf.Foundation.Configuration.dll", "Cmf.Foundation.Configuration");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");

            DbConnectionStringBuilder builder;
            using (var dbContext = ApplicationContext.CallContext.DbContexts.CmfEntities)
            {
                builder = new DbConnectionStringBuilder()
                {
                    ConnectionString = dbContext.GetConnectionString()
                };

                return new Dictionary<string, object>
                {
                    { "Server" , builder["Data Source"]},
                    { "DatabaseName" , builder["initial catalog"]},
                    { "Password", builder["Password"]},
                    { "UserId", builder["User Id"]},
                    { "InitialCatalog", builder["Initial catalog"]},
                    { "MaxConcurrentJobs", Config.GetConfig(IKEAConstants.FactoryAutomationMaxConcurrentJobs).GetConfigValue<int>() }
                };
            }

            //---End DEE Code---
        }
    }
}
