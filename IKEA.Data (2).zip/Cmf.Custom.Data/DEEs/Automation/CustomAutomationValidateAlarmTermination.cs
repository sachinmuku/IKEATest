﻿using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.BusinessObjects.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Exceptions;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Threading;

namespace Cmf.Custom.IKEA.Actions.Automation
{
    public class CustomAutomationValidateAlarmTermination : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   
            // Set context parameter

            System.IServiceProvider serviceProvider = ApplicationContext.CurrentServiceProvider;

            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();
            bool? isFromAutomation = deeContextUtilities.GetContextParameter(IKEAConstants.CustomTerminateAlarmFromAutomation) as bool?;

            // Skip validation if terminate is from Automation
            if (isFromAutomation.HasValue && isFromAutomation.Value == true)
            {
                return false;
            }
            return true;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Exceptions");
            UseReference("Cmf.Custom.IKEA.BusinessObjects.CustomAlarmOccurrence.dll", "Cmf.Custom.IKEA.BusinessObjects.Abstractions");


            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            INiceLabelUtilities nbUtilities = serviceProvider.GetService<INiceLabelUtilities>();
            ILocalizedMessage _localizedMessage = serviceProvider.GetService<ILocalizedMessage>();
            IGenericUtilities _genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();

            if (!Input.ContainsKey("CustomAlarmOccurrence"))
            {
                return Input;
            }

            ICustomAlarmOccurrence alarm = Input["CustomAlarmOccurrence"] as ICustomAlarmOccurrence;
            if (alarm == null)
            {
                return Input;
            }
            alarm.Load();

            // Cannot request an instance to a null resource
            if (alarm.TopMostResource == null)
            {
                return Input;
            }

            IAutomationControllerInstance instance = alarm.TopMostResource.GetAutomationControllerInstance();
            if (instance != null)
            {
                instance.Load();
                bool allowAlarmTermination = false;
                try
                {
                    Dictionary<string, string> reply = _genericUtilities.RequestFromIoT<Dictionary<string, string>>(instance, IKEAConstants.AutomationRequestCustomAlarmOccurrenceExistsById, new
                    {
                        CustomAlarmOccurrenceId = alarm.Id.ToString(),
                    });

                    if (reply != null && reply.ContainsKey(IKEAConstants.AutomationRequestReplyField))
                    {
                        bool.TryParse(reply[IKEAConstants.AutomationRequestReplyField], out allowAlarmTermination);
                    }
                }
                catch
                {
                    throw new IKEAException(IKEAConstants.CustomAlarmTerminateFailToValidate, alarm.TopMostResource);
                }
                if (!allowAlarmTermination)
                {
                    throw new IKEAException(IKEAConstants.CustomAlarmTerminateNotAllowed);
                }
            }

            //---End DEE Code---

            return Input;
        }
    }
}
