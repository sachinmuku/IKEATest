﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Exceptions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.Abstractions;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects;
using Cmf.Navigo.BusinessOrchestration.ResourceManagement.InputObjects;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading;

namespace Cmf.Custom.IKEA.Actions.Automation
{
    public class CustomAutomationOnConsumableDetached : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text:  Sends information of an Detach on a sub-resource to IOT
            ///     
            /// Action Groups:
            ///     ResourceManagement.ResourceManagementOrchestration.ManageResourceConsumableFeeds.Pre
            ///     ResourceManagement.ResourceManagementOrchestration.DetachConsumableFromResource.Pre
            ///     ResourceManagement.ResourceManagementOrchestration.DetachConsumablesFromResource.Pre
            ///     ResourceManagement.ResourceManagementOrchestration.ManageResourceConsumableFeeds.Post
            ///     ResourceManagement.ResourceManagementOrchestration.DetachConsumableFromResource.Post
            ///     ResourceManagement.ResourceManagementOrchestration.DetachConsumablesFromResource.Post
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion
            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();
            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "ResourceManagement.ResourceManagementOrchestration.ManageResourceConsumableFeeds.Pre",
                "ResourceManagement.ResourceManagementOrchestration.DetachConsumableFromResource.Pre",
                "ResourceManagement.ResourceManagementOrchestration.DetachConsumablesFromResource.Pre",
                "ResourceManagement.ResourceManagementOrchestration.ManageResourceConsumableFeeds.Post",
                "ResourceManagement.ResourceManagementOrchestration.DetachConsumableFromResource.Post",
                "ResourceManagement.ResourceManagementOrchestration.DetachConsumablesFromResource.Post"
            };
            // Check if the functionality is enabled and if is being executed by the right action group
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);
            if (executionVeridict && IKEADEEActionUtilities.GetInputItem<ManageResourceConsumableFeedsInput>(Input, "ManageResourceConsumableFeedsInput") == null
                                  && IKEADEEActionUtilities.GetInputItem<DetachConsumableFromResourceInput>(Input, "DetachConsumableFromResourceInput") == null
                                  && IKEADEEActionUtilities.GetInputItem<DetachConsumablesFromResourceInput>(Input, "DetachConsumablesFromResourceInput") == null)
            {
                executionVeridict = false;
            }

            // Check if in case of detach, this is to be ignored:
            if (executionVeridict == true)
            {
                bool? ignoreDetachForIoT = deeContextUtilities.GetContextParameter("AttachConsumableByManualLoading_IgnoreDetachForIoT") as bool?;
                if (ignoreDetachForIoT.HasValue && ignoreDetachForIoT.Value == true)
                {
                    executionVeridict = false;
                }
            }

            return executionVeridict;
            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code--- 
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");

            UseReference("", "Cmf.Navigo.BusinessOrchestration.Abstractions");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "");
            UseReference("", "Cmf.Foundation.Common.Exceptions");
            UseReference("", "Cmf.Foundation.Common");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.ResourceManagement");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.ResourceManagement.InputObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.ResourceManagement.OutputObjects");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Exceptions");
            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            // Newtonsoft
            UseReference("Newtonsoft.Json.dll", "Newtonsoft.Json");
            //var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            INiceLabelUtilities nbUtilities = serviceProvider.GetService<INiceLabelUtilities>();
            ILocalizedMessage _localizedMessage = serviceProvider.GetService<ILocalizedMessage>();
            IGenericUtilities _genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();

            var materialOrchestration = serviceProvider.GetService<IMaterialOrchestration>();

            DeeContext currentContext = deeContextUtilities.SetCurrentServiceContext("CustomAutomationOnConsumableDetached");

            ManageResourceConsumableFeedsInput manageResourceConsumableFeedsInput = IKEADEEActionUtilities.GetInputItem<ManageResourceConsumableFeedsInput>(Input, "ManageResourceConsumableFeedsInput");
            DetachConsumableFromResourceInput detachConsumableFromResourceInput = IKEADEEActionUtilities.GetInputItem<DetachConsumableFromResourceInput>(Input, "DetachConsumableFromResourceInput");
            DetachConsumablesFromResourceInput detachConsumablesFromResourceInput = IKEADEEActionUtilities.GetInputItem<DetachConsumablesFromResourceInput>(Input, "DetachConsumablesFromResourceInput");

            Dictionary<IResource, IMaterialCollection> resourceConsumables = new Dictionary<IResource, IMaterialCollection>();
            Dictionary<IAutomationControllerInstance, List<string>> detachedConsumablesMainFeeder = new Dictionary<IAutomationControllerInstance, List<string>>();

            // PRE - Validate detached quantity with IOT and save materials detached:
            if (currentContext.TriggerPoint == DeeTriggerPoint.Pre)
            {
                Dictionary<IAutomationControllerInstance, List<string>> controllerMaterialsToBeDetached = new Dictionary<IAutomationControllerInstance, List<string>>();

                if (manageResourceConsumableFeedsInput != null && !manageResourceConsumableFeedsInput.ConsumablesToDetach.IsNullOrEmpty())
                {
                    resourceConsumables = manageResourceConsumableFeedsInput.ConsumablesToDetach;
                }
                else if (detachConsumableFromResourceInput != null)
                {
                    var detachConsumableFromResourceMaterialCollection = entityFactory.CreateCollection<IMaterialCollection>();
                    detachConsumableFromResourceMaterialCollection.Add(detachConsumableFromResourceInput.Material);
                    resourceConsumables.Add(detachConsumableFromResourceInput.Resource, detachConsumableFromResourceMaterialCollection);
                }
                else if (detachConsumablesFromResourceInput != null)
                {
                    resourceConsumables.Add(detachConsumablesFromResourceInput.Resource, detachConsumablesFromResourceInput.Materials);
                }

                List<string> resourcesDettachedList = new List<string>();
                if (resourceConsumables.Count > 0 && resourceConsumables.Any(E => E.Value != null && E.Value.Count > 0))
                {
                    Dictionary<long, IAutomationControllerInstance> controllerInstanceDictionary = new Dictionary<long, IAutomationControllerInstance>();

                    foreach (IResource resource in resourceConsumables.Keys)
                    {
                        IResource topMost = resource.GetTopMostResource();
                        IMaterialCollection materialsAtResource = resourceConsumables[resource] ?? entityFactory.CreateCollection<IMaterialCollection>();
                        materialsAtResource.Load();
                        topMost.Load();
                        resource.Load();
                        topMost.LoadAttribute("MESAutomationInFeederSubResourceController");
                        string mainFeederName = string.Empty;
                        if (topMost.Attributes != null && topMost.Attributes.Count > 0 && topMost.Attributes.ContainsKey("MESAutomationInFeederSubResourceController")
                            && topMost.Attributes["MESAutomationInFeederSubResourceController"] != null)
                        {
                            mainFeederName = topMost.Attributes["MESAutomationInFeederSubResourceController"] as string;
                        }

                        bool isMainFeeder = !string.IsNullOrEmpty(mainFeederName) && mainFeederName.Equals(resource.Name, System.StringComparison.InvariantCultureIgnoreCase);

                        //Validate if parent resource and feeder resource are online
                        if (topMost.AutomationMode == ResourceAutomationMode.Online && resource.AutomationMode == ResourceAutomationMode.Online)
                        {
                            if(!controllerInstanceDictionary.ContainsKey(topMost.Id))
                            {
                                controllerInstanceDictionary[topMost.Id] = topMost.GetAutomationControllerInstance();
                            }
                            IAutomationControllerInstance controllerInstance = controllerInstanceDictionary[topMost.Id];

                            if (isMainFeeder)
                            {
                                detachedConsumablesMainFeeder.Add(controllerInstance, new List<string>());
                            }

                            if (controllerInstance != null)
                            {
                                if(materialsAtResource.Count > 0)
                                {
                                    // Converts all materials from the first resource (feed) to an array of Ids
                                    List<string> materialsToBeDetached = new List<string>();
                                    foreach (var material in materialsAtResource)
                                    {
                                        string sourceConsumption = material.GetAttributeValueOrDefault<string>(IKEAConstants.CustomSourceConsumptionMaterial, true);
                                        if (!string.IsNullOrEmpty(sourceConsumption))
                                        {
                                            IMaterial sourceMaterial = entityFactory.Create<IMaterial>();
                                            sourceMaterial.Name = sourceConsumption;
                                            sourceMaterial.Load();
                                            materialsToBeDetached.Add(sourceMaterial.Id.ToString());
                                            if (isMainFeeder)
                                            {
                                                detachedConsumablesMainFeeder[controllerInstance].Add(sourceMaterial.Id.ToString());
                                            }
                                        }
                                        else
                                        {
                                            materialsToBeDetached.Add(material.Id.ToString());
                                            if (isMainFeeder)
                                            {
                                                detachedConsumablesMainFeeder[controllerInstance].Add(material.Id.ToString());
                                            }
                                        }
                                        if (!resourcesDettachedList.Contains(resource.Name))
                                        {
                                            resourcesDettachedList.Add(resource.Name);
                                        }
                                    }

                                    // Material list being detached
                                    IMaterialCollection materialsAtResourceBeingDetatched = entityFactory.CreateCollection<IMaterialCollection>();
                                    materialsAtResourceBeingDetatched.Load(new Collection<long>(materialsAtResource.Select(E => E.Id).ToList()));

                                    // Get EI default timeout
                                    int requestTimeout = _genericUtilities.GetConfigurationValueByPath<int>(IKEAConstants.DownloadOrderToAutomationSendRequestDefaultTimeout);

                                    string requestType = "ConsumableDetached";
                                    var obj = controllerInstance.SendRequest(requestType, materialsToBeDetached.ToJsonString(), requestTimeout);
                                    if (obj == null)
                                    {
                                        throw new IKEAException(IKEAConstants.CustomIOTConnectionTimeoutLocalizedMessage, requestType);
                                    }

                                    string consumablesDetachedAndQuantity = obj.ToString();

                                    // Parse reply from EI
                                    List<Dictionary<string, string>> eiReply = Newtonsoft.Json.JsonConvert.DeserializeObject<List<Dictionary<string, string>>>(consumablesDetachedAndQuantity);

                                    // Iterate through EI Response
                                    foreach (var materialQuantity in eiReply)
                                    {
                                        IMaterial materialAttached = entityFactory.Create<IMaterial>();
                                        IMaterial materialDetachedFromEI = entityFactory.Create<IMaterial>();
                                        materialDetachedFromEI.Load(long.Parse(materialQuantity["MaterialId"]));
                                        materialsAtResourceBeingDetatched.Load();
                                        //Verify if the material received from EI is 
                                        foreach (var materialAtResource in materialsAtResourceBeingDetatched)
                                        {
                                            string sourceConsumption = materialAtResource.GetAttributeValueOrDefault<string>(IKEAConstants.CustomSourceConsumptionMaterial, true);
                                            if (!string.IsNullOrEmpty(sourceConsumption))
                                            {

                                                IMaterial sourceMaterial = entityFactory.Create<IMaterial>();
                                                sourceMaterial.Name = sourceConsumption;
                                                sourceMaterial.Load();
                                                if (sourceMaterial.Id == long.Parse(materialQuantity["MaterialId"]))
                                                {

                                                    materialAttached = materialAtResource;

                                                }
                                            }
                                            else
                                            {
                                                materialAttached = materialsAtResourceBeingDetatched.Where(mat => mat.Id == long.Parse(materialQuantity["MaterialId"])).First();
                                            }

                                        }

                                        decimal eiConsumableDetachedQuantity;
                                        bool parseSuccessfull = decimal.TryParse(materialQuantity["RemainingQuantity"], out eiConsumableDetachedQuantity);
                                        decimal quantityConsumed = decimal.Parse(materialQuantity["QuantityConsumed"]);
                                        if (parseSuccessfull)
                                        {

                                            decimal quantityNotReported = materialAttached.PrimaryQuantity.Value - eiConsumableDetachedQuantity;

                                            if (quantityNotReported > 0 && quantityConsumed != 0)
                                            {
                                                if (eiConsumableDetachedQuantity == 0)
                                                {
                                                    throw new IKEAException(IKEAConstants.CustomAutomationDetachConsumableConsumedLocalizedMessage, materialAttached.Name);
                                                }
                                                //Check if Material needs to be splitted
                                                else
                                                {
                                                    IResourceMaterialInformationCollection resourceMaterialInformation = resource.GetResourceMaterialInformation(false);
                                                    int order = resourceMaterialInformation.Where(x => x.Material.Id == materialAttached.Id).Select(x => x.Order).First();

                                                    // Prepare split settings
                                                    ISplitInputParametersCollection splitSettings = new SplitInputParametersCollection();
                                                    ISplitInputParameters sipCompletedSettingParameters = new SplitInputParameters()
                                                    {
                                                        PrimaryQuantity = quantityNotReported
                                                    ,
                                                        SecondaryQuantity = 0

                                                    };
                                                    splitSettings.Add(sipCompletedSettingParameters);

                                                    // This context variable is to allow the split on materials atached to automatic feeders.
                                                    deeContextUtilities.SetContextParameter(IKEAConstants.CustomAllowAutomaticFeederMaterialSplit, true);

                                                    // Perform split and update source material
                                                    SplitMaterialOutput splitMaterialOutput = materialOrchestration.SplitMaterial(new SplitMaterialInput()
                                                    {
                                                        ChildMaterials = splitSettings,
                                                        Material = materialAttached,
                                                        TerminateOnZeroQuantity = true,
                                                        //ToCopyFutureGeneralActions = true,
                                                        SplitMode = MaterialSplitMode.SplitNotAssembled
                                                    });

                                                    deeContextUtilities.SetContextParameter(IKEAConstants.CustomAllowAutomaticFeederMaterialSplit, null);

                                                    IMaterial splittedMaterial = splitMaterialOutput.ChildMaterials.First();

                                                    IResourceMaterialManageCollection resourceMaterialManages = new ResourceMaterialManageCollection();
                                                    resourceMaterialManages.Add(
                                                    new ResourceMaterialManage
                                                    {
                                                        Material = splittedMaterial,
                                                        Order = order
                                                    }
                                                    );
                                                    resource.Load();
                                                    resource.ManageMaterialOrder(resourceMaterialManages);

                                                    string sourceConsumption = splittedMaterial.GetAttributeValueOrDefault<string>(IKEAConstants.CustomSourceConsumptionMaterial, true);
                                                    if (string.IsNullOrEmpty(sourceConsumption))
                                                    {
                                                        IAttributeCollection materialAttribute = new AttributeCollection
                                                         {
                                                            { IKEAConstants.CustomSourceConsumptionMaterial, materialAttached.Name }
                                                         };

                                                        splittedMaterial.SaveAttributes(materialAttribute);
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    if (controllerMaterialsToBeDetached.ContainsKey(controllerInstance))
                                    {
                                        controllerMaterialsToBeDetached[controllerInstance].AddRange(materialsToBeDetached);
                                    }
                                    else
                                    {
                                        controllerMaterialsToBeDetached.Add(controllerInstance, materialsToBeDetached);
                                    }
                                }
                            }
                        }
                    }
                }

                deeContextUtilities.SetContextParameter("CustomAutomationOnConsumableDetached_ControllerInstanceAndMaterials", controllerMaterialsToBeDetached);
                deeContextUtilities.SetContextParameter("CustomAutomationOnConsumableDetached_DetachedMaterialsFromMainFeeder", detachedConsumablesMainFeeder);
                deeContextUtilities.SetContextParameter("CustomAutomationOnConsumableDetached_DetachedResourcesList", resourcesDettachedList);
            }
            if (currentContext.TriggerPoint == DeeTriggerPoint.Post)
            {
                Dictionary<IAutomationControllerInstance, List<string>> controllerMaterialsToBeDetached = deeContextUtilities.GetContextParameter("CustomAutomationOnConsumableDetached_ControllerInstanceAndMaterials") as Dictionary<IAutomationControllerInstance, List<string>>;
                Dictionary<IAutomationControllerInstance, List<string>> detachedConsumablesToBeDetachedFromMainFeeder = deeContextUtilities.GetContextParameter("CustomAutomationOnConsumableDetached_DetachedMaterialsFromMainFeeder") as Dictionary<IAutomationControllerInstance, List<string>>;
                List<string> resourceList = deeContextUtilities.GetContextParameter("CustomAutomationOnConsumableDetached_DetachedResourcesList") as List<string>;

                if (controllerMaterialsToBeDetached != null && controllerMaterialsToBeDetached.Count > 0 && controllerMaterialsToBeDetached.Values.Count > 0)
                {
                    // Send message to EI indicating materials detached
                    foreach (var instanceMaterialCollection in controllerMaterialsToBeDetached)
                    {
                        // Get EI default timeout
                        int requestTimeout = _genericUtilities.GetConfigurationValueByPath<int>(IKEAConstants.DownloadOrderToAutomationSendRequestDefaultTimeout);

                        //Calculate total quantity of detached consumables
                        decimal totalDetachedQuantity = 0;
                        foreach (string materialId in instanceMaterialCollection.Value)
                        {
                            if (detachedConsumablesToBeDetachedFromMainFeeder.Keys.Contains(instanceMaterialCollection.Key) &&
                                detachedConsumablesToBeDetachedFromMainFeeder[instanceMaterialCollection.Key].Contains(materialId))
                            {
                                IMaterial consumable = entityFactory.Create<IMaterial>();
                                consumable.Load(long.Parse(materialId));
                                totalDetachedQuantity += consumable.PrimaryQuantity ?? 0;
                            }
                        }
                        //Send confirmation message to IOT
                        instanceMaterialCollection.Key.Publish("DetachSuccessfull", instanceMaterialCollection.Value.ToJsonString());
                        instanceMaterialCollection.Key.Publish("DetachedQuantity", totalDetachedQuantity);
                        if (resourceList != null && resourceList.Count > 0)
                        {
                            instanceMaterialCollection.Key.Publish("DettachSuccessfullResourceList", resourceList);
                        }
                    }
                }
                deeContextUtilities.SetContextParameter("CustomAutomationOnConsumableDetached_ControllerInstanceAndMaterials", null);
                deeContextUtilities.SetContextParameter("CustomAutomationOnConsumableDetached_DetachedResourcesList", null);
            }

            //---End DEE Code---

            return Input;
        }
    }
}
