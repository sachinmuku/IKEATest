﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Custom.IKEA.Common;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessObjects.QueryObject;
using Cmf.Foundation.Common.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.Automation
{
	public class CustomLoadAutomationJobsOnSetup : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
	{
		public override bool ValidateAction(Dictionary<string, object> Input)
		{
			//---Start DEE Condition Code---
			#region Info
			/// <summary>
			/// Summary text
			///     Loads the Automation Jobs missing from persistence.
			/// </summary>
			#endregion
			return true;
			//---End DEE Condition Code--- 
		}

		public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
		{
            //---Start DEE Code--- 
            UseReference("%MicrosoftNetPath%System.Data.Common.dll", "System.Data");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects.QueryObject");
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("", "Cmf.Foundation.Common.Exceptions");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.BusinessObjects.CustomWMSMaterialTracker.dll", "Cmf.Custom.IKEA.BusinessObjects");
            UseReference("", "Cmf.Custom.IKEA.BusinessObjects.Abstractions");
            UseReference("Newtonsoft.Json.dll", "Newtonsoft.Json");

            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            var entityFactory = serviceProvider.GetService<IEntityFactory>();

            List<long> automationJobIds = Newtonsoft.Json.JsonConvert.DeserializeObject<List<long>>(IKEADEEActionUtilities.GetInputItem<Object>(Input, "AutomationJobIds")?.ToString());

            IIoTEventDefinition wmsIotEventDefinition = entityFactory.Create<IIoTEventDefinition>();
            wmsIotEventDefinition.Name = IKEAConstants.EventDefinitionWMSOrderRequest;
            wmsIotEventDefinition.Load();

            IAutomationJobCollection automationJobs = entityFactory.CreateCollection<IAutomationJobCollection>();

            IQueryObject query = entityFactory.Create<IQueryObject>();
            query.Description = "";
            query.EntityTypeName = "AutomationJob";
            query.Name = "CustomGetRunningAutomationJobs";
            query.Query = new Query();
            query.Query.Distinct = false;
            query.Query.Filters = new FilterCollection() {
                new Cmf.Foundation.BusinessObjects.QueryObject.Filter()
                {
                    Name = IKEAConstants.AutomationJobTriggerEventIdColumnName,
                    ObjectName = "AutomationJob",
                    ObjectAlias = "AutomationJob_1",
                    Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                    Value = wmsIotEventDefinition.Id,
                    LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND,
                    FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                },
                new Cmf.Foundation.BusinessObjects.QueryObject.Filter()
                {
                    Name = IKEAConstants.AutomationJobSystemStateColumnName,
                    ObjectName = "AutomationJob",
                    ObjectAlias = "AutomationJob_1",
                    Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                    Value = Cmf.Foundation.BusinessObjects.ConnectIoT.AutomationJobSystemState.Executing,
                    LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND,
                    FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                },
                new Cmf.Foundation.BusinessObjects.QueryObject.Filter()
                {
                    Name = IKEAConstants.AutomationJobSchedulingStateColumnName,
                    ObjectName = "AutomationJob",
                    ObjectAlias = "AutomationJob_1",
                    Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                    Value = Cmf.Foundation.BusinessObjects.ConnectIoT.AutomationJobSchedulingState.Running,
                    LogicalOperator = Cmf.Foundation.Common.LogicalOperator.Nothing,
                    FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                }
            };
            query.Query.Fields = new FieldCollection() {
                new Field()
                {
                    Alias = "Id",
                    ObjectName = "AutomationJob",
                    ObjectAlias = "AutomationJob_1",
                    IsUserAttribute = false,
                    Name = "Id",
                    Position = 0,
                    Sort = Cmf.Foundation.Common.FieldSort.NoSort
                },
                new Field()
                {
                    Alias = "Name",
                    ObjectName = "AutomationJob",
                    ObjectAlias = "AutomationJob_1",
                    IsUserAttribute = false,
                    Name = "Name",
                    Position = 1,
                    Sort = Cmf.Foundation.Common.FieldSort.NoSort
                }
            };
            query.Query.Relations = new RelationCollection();


            DataSet automationJobsDataSet = query.Execute(false, new QueryParameterCollection());

            if (automationJobsDataSet.HasData())
            {
                // Create the Genealogy objects from the query results
                automationJobs.LoadByIDs<IAutomationJob, AutomationJob>(
                    automationJobsDataSet.Tables[0].Rows
                        .OfType<DataRow>()
                        .Select(row => row.Field<long>("Id"))
                        .ToList()
                );
            }

            Dictionary<string, object> output = new Dictionary<string, object>();
            output.Add("MissingAutomationJobIds", automationJobs.Where(job => !automationJobIds.Contains(job.Id)).Select(job => job.Id).ToList());

            return output;
            //---End DEE Code---

        }


    }
}
