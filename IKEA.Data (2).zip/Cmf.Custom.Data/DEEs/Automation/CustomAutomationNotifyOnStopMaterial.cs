﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.Enums;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System.Collections.Generic;
using System.Threading;

namespace Cmf.Custom.IKEA.Actions.Automation
{
    public class CustomAutomationNotifyOnStopMaterial : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Creates a nofication when the order is aborted due to an OPC failure
            /// </summary>
            #endregion

            return true;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
            UseReference("%MicrosoftNetPath%System.Private.CoreLib.dll", "System.Threading");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
            //UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "");
            UseReference("", "Cmf.Foundation.Common.Exceptions");
            UseReference("", "Cmf.Foundation.Common");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Orchestration.dll", "Cmf.Custom.IKEA.Orchestration");
            UseReference("Cmf.Custom.IKEA.Orchestration.dll", "Cmf.Custom.IKEA.Orchestration.InputObjects");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IAlarmHandlingUtilities ahUtilities = serviceProvider.GetService<IAlarmHandlingUtilities>();
            ILocalizedMessage _localizedMessage = serviceProvider.GetService<ILocalizedMessage>();
            IGenericUtilities _genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();

            // Get Input from IoT
            string materialName = IKEADEEActionUtilities.GetInputItem<string>(Input, "MaterialName");
            string ioTStopReason = IKEADEEActionUtilities.GetInputItem<string>(Input, "StopReason");


            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();


            if (materialName != null)
            {
                CustomMaterialStopReasonEnum stopReason = (CustomMaterialStopReasonEnum)Enum.Parse(typeof(CustomMaterialStopReasonEnum), ioTStopReason);

                if (stopReason == CustomMaterialStopReasonEnum.Abort)
                {
                    IMaterial material = entityFactory.Create<IMaterial>();
                    material.Name = materialName;
                    material.Load();

                    if (material.LastProcessedResource != null)
                    {
                        IEmployeeCollection employeesToBeNotified = _genericUtilities.GetCheckedInEmployees(material.LastProcessedResource.Name);

                        // Check if there are any employees to be notified
                        if (!employeesToBeNotified.IsNullOrEmpty())
                        {
                            //Validate Severity in config
                            string severity = ikeaUtilities.GetValueFromConfigurationWithPath(IKEAConstants.DefaultNotificationSeverityConfig);

                            Cmf.Foundation.BusinessObjects.Abstractions.INotificationCollection notifications = entityFactory.CreateCollection<Cmf.Foundation.BusinessObjects.Abstractions.INotificationCollection>();

                            // Get the notification severity level
                            string notificationSeverity = ikeaUtilities.GetValueFromLookupTable(IKEAConstants.NotificationSeverityLookupTableName, severity, true);

                            // Get the duration for the notification
                            int notificationDuration = _genericUtilities.GetConfigurationValueByPath<int>(IKEAConstants.InterlockNotificationDuration);

                            // Get message details
                            string title = String.Format(_localizedMessage.LoadLocalizedMessage(Thread.CurrentThread.CurrentCulture.Name, IKEAConstants.CustomStopMaterialIoTAbortNotification).MessageText, material.Name, material.LastProcessedResource.Name);
                            string details = _localizedMessage.LoadLocalizedMessage(Thread.CurrentThread.CurrentCulture.Name, IKEAConstants.CustomStopMaterialIoTReasonNotification).MessageText;

                            foreach (IEmployee employee in employeesToBeNotified)
                            {
                                // Create Notification
                                var notification = entityFactory.Create<Cmf.Foundation.BusinessObjects.Abstractions.INotification>();
                                notification.Type = "System";
                                notification.Title = title;
                                notification.Details = String.Format("{0}. {1}", title, details);
                                notification.Severity = notificationSeverity;
                                notification.AssignmentType = (NotificationAssignmentType)AssignmentType.Employee;
                                notification.AssignedToUser = (Foundation.Security.Abstractions.IUser)employee;
                                notification.ClearanceMode = ClearanceMode.ManualSingleUser;
                                notification.ValidTo = DateTime.Now.AddMinutes(notificationDuration);
                                notifications.Add(notification);
                            }

                            notifications.Create();
                        }
                    }
                }
            }
            //---End DEE Code---

            return Input;
        }
    }
}
