﻿using Cmf.Common.CustomActionUtilities;

using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Orchestration.Abstractions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.Automation
{
    public class CustomAutomationValidateIsOrderCompletable : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code--- 
            #region Info
            /// <summary>
            /// Summary text
            ///     Receives a MO name and verifies if the conditions to advance with the complete process are met
            /// </summary>
            #endregion
            var executionVerdict = true;
            if (IKEADEEActionUtilities.GetInputItem<string>(Input, "MaterialName") == null)
            {
                executionVerdict = false;
            }

            return executionVerdict;
            //---End DEE Condition Code--- 
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code--- 
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "");
            UseReference("", "Cmf.Foundation.Common.Exceptions");
            UseReference("", "Cmf.Foundation.Common");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Extensions");
            
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");

            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            string materialName = IKEADEEActionUtilities.GetInputItem<string>(Input, "MaterialName");

            var entityFactory = serviceProvider.GetService<IEntityFactory>();

            IMaterial materialMO = entityFactory.Create<IMaterial>();
            materialMO.Name = materialName;
            materialMO.Load();

            // Call utility to verify if order is completable
            bool isMOCompletable = ikeaUtilities.IsMOCompletable(materialMO);

            // If MO is completable, then it is going to be completed by IoT, if not, it is going to be aborted
            if (isMOCompletable)
            {
                materialMO.SaveAttributes(new AttributeCollection { { IKEAConstants.CustomMaterialAttributeInCompletion, true },
                                                                    {IKEAConstants.CustomMaterialAttributeForceOrderCompletionAllowed, CustomMaterialStopReasonEnum.Complete} });
            }
            else
            {
                materialMO.SaveAttributes(new AttributeCollection { { IKEAConstants.CustomMaterialAttributeInCompletion, true },
                                                                    {IKEAConstants.CustomMaterialAttributeForceOrderCompletionAllowed, CustomMaterialStopReasonEnum.Abort} });
            }

            Dictionary<string, object> output = new Dictionary<string, object>();
            output.Add("IsMOCompletable", isMOCompletable);
            return output;

            //---End DEE Code--- 
        }
    }
}
