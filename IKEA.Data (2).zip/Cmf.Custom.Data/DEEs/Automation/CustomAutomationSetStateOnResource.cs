﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Orchestration.InputObjects;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.Abstractions;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects;
using Cmf.Navigo.BusinessOrchestration.ResourceManagement;
using Cmf.Navigo.BusinessOrchestration.ResourceManagement.InputObjects;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.Automation
{
    public class CustomAutomationSetStateOnResource : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Set Resource state from automation
            /// </summary>
            #endregion

            var executionVeridict = true;
            if (IKEADEEActionUtilities.GetInputItem<string>(Input, "Resource") == null ||
                IKEADEEActionUtilities.GetInputItem<string>(Input, "MainState") == null ||
                IKEADEEActionUtilities.GetInputItem<string>(Input, "SubState") == null)
            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            UseReference("", "Cmf.Navigo.BusinessOrchestration.Abstractions");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "");
            UseReference("", "Cmf.Foundation.Common.Exceptions");
            UseReference("", "Cmf.Foundation.Common");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.ResourceManagement.InputObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.ResourceManagement");
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            var resourceOrchestration = serviceProvider.GetService<IResourceOrchestration>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();

            // Get Input from IoT
            long resourceId = long.Parse(IKEADEEActionUtilities.GetInputItem<string>(Input, Constants.Resource));

            IResource resource = entityFactory.Create<IResource>();
            resource.Load(resourceId);

            string state = Input["MainState"].ToString();
            string subState = Input["SubState"].ToString();

            ikeaUtilities.SetStateOnResource(resource, state, subState, true);
            //---End DEE Code---

            return Input;
        }
    }
}
