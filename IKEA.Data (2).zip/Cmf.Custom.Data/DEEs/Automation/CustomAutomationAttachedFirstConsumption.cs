﻿using System;
using System.Collections.Generic;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Orchestration.Abstractions;
using Cmf.Custom.IKEA.Orchestration.InputObjects;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;

namespace Cmf.Custom.IKEA.Actions.Automation
{
    public class CustomAutomationAttachedFirstConsumption : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     IoT report first comsunption
            /// </summary>
            #endregion

            return true;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            // CORE
            UseReference("", "Cmf.Custom.IKEA.Orchestration.Abstractions");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.GenericServiceManagement.OutputObjects");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.GenericServiceManagement.InputObjects");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "");
            UseReference("", "Cmf.Foundation.Common.Exceptions");
            UseReference("", "Cmf.Foundation.Common");

            // MES
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            // CUSTOM
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Orchestration.dll", "Cmf.Custom.IKEA.Orchestration");
            UseReference("Cmf.Custom.IKEA.Orchestration.dll", "Cmf.Custom.IKEA.Orchestration.InputObjects");
            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();

            var iKEABusinessManagementOrchestration = serviceProvider.GetService<IIKEABusinessManagementOrchestration>();


            var materialId = Input["AttachedMaterialId"];
            // Total Consumed Quantity (not considering the current pallet)
            var inFeederQuant = decimal.Parse(Input["InfeederQuantity"].ToString());
            // Current Pallet Quantity
            var inBufferQuant = decimal.Parse(Input["InbufferQuantity"].ToString());
            string orderName = IKEADEEActionUtilities.GetInputItem<string>(Input, "OrderName");

            // If there is a problem loading the material (The input is wrong or the material does not exist) then reporting should be blocked
            bool blockReporting = false;

            IMaterial material = entityFactory.Create<IMaterial>();
            if (materialId != null)
            {
                try
                {
                    material.Load(Convert.ToInt64(materialId));
                }
                catch
                {
                    blockReporting = true;
                }
            }
            else
            {
                throw new Exception("Missing mandatory input");
            }


            if (!blockReporting)
            {
                try
                {
                    iKEABusinessManagementOrchestration.CustomMaterialConsumptionReport(new CustomMaterialConsumptionReportInput()
                    {
                        Material = material,
                        InBufferQuantity = inBufferQuant,
                        InFeederQuantity = inFeederQuant,
                        OrderName = orderName
                    });
                }
                catch (Exception ex)
                {
                    if (!String.IsNullOrWhiteSpace(ex.Message) && ex.Message.Contains("deadlock"))
                    {
                        throw new DataChangedSinceLastViewedCmfException("Material", material.Name);
                    }
                    else
                    {
                        throw ex;
                    }
                }
            }

            //---End DEE Code---

            return Input;
        }
    }
}
