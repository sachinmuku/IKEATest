﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;

using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common;
using Cmf.Foundation.Configuration;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace Cmf.Custom.IKEA.Actions.Automation
{
    public class CustomAutomationLoadConfigurations : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Set Resource state from automation
            /// </summary>
            #endregion

            return true;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "");
            UseReference("", "Cmf.Foundation.Common.Exceptions");
            UseReference("", "Cmf.Foundation.Common");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.ResourceManagement.InputObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.ResourceManagement");
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IDirectFeedingUtilities idUtilities = serviceProvider.GetService<IDirectFeedingUtilities>();
            ILocalizedMessage _localizedMessage = serviceProvider.GetService<ILocalizedMessage>();
            IGenericUtilities _genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();

            Dictionary<string, object> output = new Dictionary<string, object>();
            IResource resource = Input[Constants.Resource] as IResource;
            if (resource == null)
            {
                throw new CmfBaseException(String.Format(IKEAConstants.CustomAutomationLoadConfigurationFailed, Constants.Resource));
            }
            resource.Load();
            resource.LoadAttributes(new Collection<string>() {
                IKEAConstants.CustomResourceDirectFeedingEnabled,
                IKEAConstants.CustomResourceDirectFeedingIsFirstLine,
                IKEAConstants.CustomResourceDirectFeedingSendRequestTo,
                IKEAConstants.CustomNumberOfOrderSlots,
                IKEAConstants.ParentResourceLineName,
                IKEAConstants.CustomAllowAlternativeOverproduction,
                IKEAConstants.CustomSendPalletIDToLCEnabled
            });

            bool directFeedingEnabled = resource.GetAttributeValueOrDefault(IKEAConstants.CustomResourceDirectFeedingEnabled, false);
            object directFeedingConfigurations;
            if (directFeedingEnabled)
            {
                if (!idUtilities.IsDirectFeedingResourceMatchValid(resource))
                {
                    throw new CmfBaseException(IKEAConstants.CustomResourceDirectFeedingMatchNotValid);
                }
                directFeedingConfigurations = new
                {
                    DirectFeedingEnabled = true,
                    DirectFeedingIsFirstLine = resource.GetAttributeValue(IKEAConstants.CustomResourceDirectFeedingIsFirstLine),
                    DirectFeedingSendRequestTo = resource.GetAttributeValue(IKEAConstants.CustomResourceDirectFeedingSendRequestTo),
                };
            }
            else
            {
                directFeedingConfigurations = new
                {
                    DirectFeedingEnabled = false,
                    DirectFeedingIsFirstLine = string.Empty,
                    DirectFeedingSendRequestTo = string.Empty,
                };
            }

            if (!resource.HasRelations(Cmf.Navigo.Common.Constants.SubResource, true))
            {
                throw new CmfBaseException(IKEAConstants.CustomResourceMessageMissingSubResourceRelations);
            }
            IEntityRelationCollection<IEntityRelation> resourceCollection = resource.RelationCollection[Cmf.Navigo.Common.Constants.SubResource];

            string labelStorageResource = string.Empty;
            List<object> infeederConfigurations = new List<object>();
            List<object> outsorterConfigurations = new List<object>();
            List<object> outfeederConfigurations = new List<object>();
            List<object> printerConfigurations = new List<object>();
            List<object> workUnitsAlarmData = new List<object>();

            foreach (ISubResource subRes in resourceCollection)
            {
                IResource subResource = subRes.TargetEntity;
                subResource.LoadAttributes();
                if (subResource.AutomationMode != ResourceAutomationMode.Online)
                {
                    continue;
                }
                string tagBaseName = subResource.GetAttributeValueOrDefault<string>(IKEAConstants.AutomationResourceTagBaseName);
                int alarmBufferSize = subResource.GetAttributeValueOrDefault<int>(IKEAConstants.AutomationAlarmBufferSize);
                bool CustomSendPalletIDToLCEnabled = subResource.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomSendPalletIDToLCEnabled);

                if (alarmBufferSize > 0)
                {
                    workUnitsAlarmData.Add(new
                    {
                        ResourceName = subResource.Name,
                        AutomationResourceTagBaseName = tagBaseName,
                        WorkUnitAlarmQuantity = alarmBufferSize,
                    });
                }

                if (subResource.ProcessingType == ProcessingType.ConsumableFeed && subResource.Type == IKEAConstants.ResourceTypeConsumable)
                {
                    string lineControllerInfeeder = resource.GetAttributeValueOrDefault<string>(IKEAConstants.MESAutomationInFeederSubResourceController);
                    bool scanInFeeder = subResource.GetAttributeValueOrDefault<bool>(IKEAConstants.AutomationScanInFeeder);
                    int infeederPosition = subResource.GetAttributeValueOrDefault<int>(IKEAConstants.AutomationInFeederPosition);
                    bool infeederController = subResource.Name == lineControllerInfeeder ? true : false;
                    // Get feeder consumption mode from feeder attribute
                    CustomFeederConsumptionModeEnum feederConsumptionMode = subResource.GetAttributeValueOrDefault<CustomFeederConsumptionModeEnum>(IKEAConstants.CustomResourceAttributeFeederConsumptionMode);

                    if (infeederController)
                    {
                        labelStorageResource = subResource.GetAttributeValueOrDefault<string>(IKEAConstants.CustomLabelStorageResourceAttribute) ?? string.Empty;
                    }

                    infeederConfigurations.Add(new
                    {
                        MesResourceName = subResource.Name,
                        AutomationResourceTagBaseName = tagBaseName,
                        AutomationScanInFeeder = scanInFeeder,
                        InFeederController = infeederController,
                        AutomationInFeederPosition = infeederPosition,
                        FeederConsumptionMode = feederConsumptionMode,
                    });
                }
                if (subResource.Type == IKEAConstants.ResourceTypeOutsorter)
                {
                    int outsorterPosition = subResource.GetAttributeValueOrDefault<int>(IKEAConstants.AutomationProductionCounterPosition);
                    outsorterConfigurations.Add(new
                    {
                        MesResourceName = subResource.Name,
                        AutomationResourceTagBaseName = tagBaseName,
                        AutomationProductionCounterPosition = outsorterPosition,
                        SendPalletIDToLCEnabled = CustomSendPalletIDToLCEnabled,
                    });
                }
                if (subResource.Type == IKEAConstants.ResourceTypeOutfeeder)
                {
                    int outfeederPosition = subResource.GetAttributeValueOrDefault<int>(IKEAConstants.AutomationProductionCounterPosition);
                    outfeederConfigurations.Add(new
                    {
                        MesResourceName = subResource.Name,
                        AutomationResourceTagBaseName = tagBaseName,
                        AutomationProductionCounterPosition = outfeederPosition,
                        SendPalletIDToLCEnabled = CustomSendPalletIDToLCEnabled,
                    });
                }
                if (subResource.Type == IKEAConstants.ResourceTypePrinter)
                {

                    printerConfigurations.Add(new
                    {
                        MesResourceName = subResource.Name,
                        AutomationResourceTagBaseName = tagBaseName,
                    });


                }

            }
            Dictionary<string, object> generalConfigurations = new Dictionary<string, object>();
            int keepAliveTimeout = _genericUtilities.GetConfigurationValueByPath<int>(IKEAConstants.KeepAliveCounterTimeout);
            int numberOfOrderSlots = resource.GetAttributeValueOrDefault<int>(IKEAConstants.CustomNumberOfOrderSlots);
            string parentResourceLineName = resource.GetAttributeValueOrDefault<string>(IKEAConstants.ParentResourceLineName);
            bool allowAlternativeOverproduction = resource.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomAllowAlternativeOverproduction);

            generalConfigurations.Add(IKEAConstants.KeepAliveCounterTimeoutProperty, keepAliveTimeout);
            generalConfigurations.Add(IKEAConstants.CustomLabelStorageResourceAttribute, labelStorageResource);
            generalConfigurations.Add(IKEAConstants.CustomNumberOfOrderSlots, numberOfOrderSlots);
            generalConfigurations.Add(IKEAConstants.ParentResourceLineName, parentResourceLineName);
            generalConfigurations.Add(IKEAConstants.CustomAllowAlternativeOverproduction, allowAlternativeOverproduction);

            //IoT Security
            CustomSecurityModeEnum securityMode = resource.GetAttributeValueOrDefault<CustomSecurityModeEnum>(IKEAConstants.SecurityMode);
            CustomSecurityPolicyEnum securityPolicy = resource.GetAttributeValueOrDefault<CustomSecurityPolicyEnum>(IKEAConstants.SecurityPolicy);

            //Get password from configuration
            string username = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.OPCUAParentPath + "Default/Username/");

            if (Config.ConfigExists(IKEAConstants.OPCUAParentPath + resource.Name + "/Username/"))
            {
                username = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.OPCUAParentPath + resource.Name + "/Username/");
            }

            //Get password from configuration
            string password = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.OPCUAParentPath + "Default/Password/");

            if (Config.ConfigExists(IKEAConstants.OPCUAParentPath + resource.Name + "/Password/"))
            {
                password = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.OPCUAParentPath + resource.Name + "/Password/");
            }

            //Validate if the security None is empty
            if (securityMode.Equals(CustomSecurityModeEnum.None))
            {
                username = String.Empty;
                password = String.Empty;
                securityPolicy = CustomSecurityPolicyEnum.None;
            }

            output.Add("FeedConfigurations", infeederConfigurations);
            output.Add("OutfeederConfigurations", outfeederConfigurations);
            output.Add("OutsorterConfigurations", outsorterConfigurations);
            output.Add("PrinterConfigurations", printerConfigurations);
            output.Add("AlarmConfigurations", workUnitsAlarmData);
            output.Add("DirectFeedingConfigurations", directFeedingConfigurations);
            output.Add("GeneralConfigurations", generalConfigurations);
            output.Add("Username", username);
            output.Add("Password", password);
            output.Add("SecurityMode", securityMode.ToString());
            output.Add("SecurityPolicy", securityPolicy.ToString());
            return output;
            //---End DEE Code---
        }
    }
}
