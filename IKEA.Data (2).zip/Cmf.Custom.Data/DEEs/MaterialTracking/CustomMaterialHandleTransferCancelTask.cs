﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Orchestration.Abstractions;
using Cmf.Custom.IKEA.Orchestration.InputObjects;
using Cmf.Custom.IKEA.Orchestration.OutputObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;

using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace Cmf.Custom.IKEA.Actions.MaterialTracking
{
    class CustomMaterialHandleTransferCancelTask : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {

        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---

            #region Info
            /// <summary>
            /// DEE to handle the creation of a Notification after a Emplyee cancels the Task for material movement (TaskType = 'TransferRequest')
            /// Action Groups: BusinessObjects.TaskCollection.Cancel.Post
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion

            // By default, action is not to be executed
            bool executionVeridict = false;

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.TaskCollection.Cancel.Post"
            };

            // only proceed if within expected triggers (action groups)
            executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---

            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");


            //System
            UseReference("", "Cmf.Custom.IKEA.Orchestration.Abstractions");
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("", "System");
            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Orchestration.dll", "Cmf.Custom.IKEA.Orchestration");
            UseReference("Cmf.Custom.IKEA.Orchestration.dll", "Cmf.Custom.IKEA.Orchestration.InputObjects");
            UseReference("Cmf.Custom.IKEA.Orchestration.dll", "Cmf.Custom.IKEA.Orchestration.OutputObjects");
            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            var iKEABusinessManagementOrchestration = serviceProvider.GetService<IIKEABusinessManagementOrchestration>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            INiceLabelUtilities nbUtilities = serviceProvider.GetService<INiceLabelUtilities>();
            ILocalizedMessage _localizedMessage = serviceProvider.GetService<ILocalizedMessage>();
            IGenericUtilities _genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();

            // Get all Tasks that are being Canceled in the Cancel Post:
            ITaskCollection taskCollection = IKEADEEActionUtilities.GetInputItem<ITaskCollection>(Input, "TaskCollection");

            // Gather all necessary attributes from the tasks:
            Collection<string> attributeCollection = new Collection<string>
            {
                IKEAConstants.MaterialTransferFromArea,
                IKEAConstants.MaterialTransferFromLocation,
                IKEAConstants.MaterialTransferFromFacility,
                IKEAConstants.MaterialTransferRequiredProduct,
                IKEAConstants.MaterialTransferRequiredQuantity,
                IKEAConstants.MaterialTransferRequiredMaterial,
                IKEAConstants.MaterialTransferToArea,
                IKEAConstants.MaterialTransferToLocation,
                IKEAConstants.MaterialTransferToFacility,
                IKEAConstants.CustomTaskAttributeTaskType
            };


            // Loads attributes:
            taskCollection.LoadAttributes(attributeCollection);

            // Load Config:
            string configNotificationType = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.CustomMaterialTransferRequestTypePath);

            foreach (ITask task in taskCollection)
            {
                if (attributeCollection != null && attributeCollection.Count > 0)
                {
                    string attributeTaskType = task.GetAttributeValueOrDefault<string>(IKEAConstants.CustomTaskAttributeTaskType);

                    if (!attributeTaskType.IsNullOrEmpty() && attributeTaskType.Equals(configNotificationType, StringComparison.InvariantCultureIgnoreCase))
                    {
                        // Configure a 'RequestMaterialTransfer' service:
                        CustomRequestMaterialTransferInput customRequestMaterialTransferInput = new CustomRequestMaterialTransferInput();

                        customRequestMaterialTransferInput.FromArea = task.GetAttributeValueOrDefault<string>(IKEAConstants.MaterialTransferFromArea);
                        customRequestMaterialTransferInput.FromLocation = task.GetAttributeValueOrDefault<string>(IKEAConstants.MaterialTransferFromLocation);
                        customRequestMaterialTransferInput.FromFacility = task.GetAttributeValueOrDefault<string>(IKEAConstants.MaterialTransferFromFacility);
                        customRequestMaterialTransferInput.RequiredProduct = task.GetAttributeValueOrDefault<string>(IKEAConstants.MaterialTransferRequiredProduct);
                        customRequestMaterialTransferInput.RequiredQuantity = task.GetAttributeValueOrDefault<decimal>(IKEAConstants.MaterialTransferRequiredQuantity);
                        customRequestMaterialTransferInput.RequiredMaterial = task.GetAttributeValueOrDefault<string>(IKEAConstants.MaterialTransferRequiredMaterial);
                        customRequestMaterialTransferInput.ToArea = task.GetAttributeValueOrDefault<string>(IKEAConstants.MaterialTransferToArea);
                        customRequestMaterialTransferInput.ToLocation = task.GetAttributeValueOrDefault<string>(IKEAConstants.MaterialTransferToLocation);
                        customRequestMaterialTransferInput.ToFacility = task.GetAttributeValueOrDefault<string>(IKEAConstants.MaterialTransferToFacility);
                        customRequestMaterialTransferInput.SourceMaterialRequestId = Convert.ToInt64(task.GetAttributeValueOrDefault<string>(IKEAConstants.SourceMaterialRequestId) ?? "0");

                        // Invoke service:
                        CustomRequestMaterialTransferOutput customRequestMaterialTransferOutput = iKEABusinessManagementOrchestration.CustomRequestMaterialTransfer(customRequestMaterialTransferInput);
                    }
                }
            }

            //---End DEE Code---
            return null;
        }

    }
}




