﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Custom.IKEA.BusinessObjects;
using Cmf.Custom.IKEA.BusinessObjects.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Extensions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects;
using Microsoft.Extensions.DependencyInjection;

using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace Cmf.Custom.IKEA.Actions.MaterialTracking
{
    class CustomHandleMultipleOutsortersTrackIn : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {


        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text:
            ///     Action to create relations between the MO and sub-resources that are OutSorters or OutFeeders
            /// Action Groups:
            ///     MaterialManagement.MaterialManagementOrchestration.ComplexTrackInMaterials.Post
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "MaterialManagement.MaterialManagementOrchestration.ComplexTrackInMaterials.Post"
            };

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            if (executionVeridict && IKEADEEActionUtilities.GetInputItem<ComplexTrackInMaterialsInput>(Input, "ComplexTrackInMaterialsInput") == null)
            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
                        
            //System
            UseReference("", "Cmf.Custom.IKEA.BusinessObjects.Abstractions");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("", "System.Linq");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.BusinessObjects.CustomManufacturingOrderOutFeeder.dll", "Cmf.Custom.IKEA.BusinessObjects");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Extensions");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();

            ComplexTrackInMaterialsOutput output = IKEADEEActionUtilities.GetInputItem<ComplexTrackInMaterialsOutput>(Input, "ComplexTrackInMaterialsOutput");

            // Get the resource:
            IResource trackInResource = output.Resource;

            // Get the MOs:
            IMaterialCollection materials = output.Materials;

            // Only lines with automation online:
            if (trackInResource.AutomationMode == ResourceAutomationMode.Online)
            {
                // Check if the resource has subresources:
                if (trackInResource.HasRelations("SubResource", true))
                {
                    var resourceCollection = trackInResource.RelationCollection["SubResource"];

                    materials.LoadRelations(IKEAConstants.CustomManufacturingOrderOutFeeder);

                    foreach (IMaterial materialMO in materials)
                    {

                        // Remove existing relations:
                        if (materialMO.RelationCollection.ContainsKey(IKEAConstants.CustomManufacturingOrderOutFeeder))
                        {
                            // remove all relations
                            ICmfEntityRelationCollection relationCollection = serviceProvider.GetService<ICmfEntityRelationCollection>();

                            relationCollection.Add(materialMO.RelationCollection[IKEAConstants.CustomManufacturingOrderOutFeeder]);
                            materialMO.RemoveRelations(relationCollection);
                        }

                        // Do not include MOs that are child og group MOs:
                        if (!materialMO.IsChildOfGroupMO())
                        {
                            ICmfEntityRelationCollection collection = serviceProvider.GetService<ICmfEntityRelationCollection>();
                            foreach (ISubResource subResource in resourceCollection)
                            {
                                if (subResource.TargetEntity.AutomationMode == ResourceAutomationMode.Online)
                                {
                                    // Only feeders and outsorters with automation mode online:
                                    if (subResource.TargetEntity.Type == IKEAConstants.ResourceTypeOutsorter ||
                                        subResource.TargetEntity.Type == IKEAConstants.ResourceTypeOutfeeder)
                                    {
                                        ICustomManufacturingOrderOutFeeder customManufacturingOrderOutFeeder = entityFactory.Create<ICustomManufacturingOrderOutFeeder>();
                                        customManufacturingOrderOutFeeder.SourceEntity = materialMO;
                                        customManufacturingOrderOutFeeder.TargetEntity = subResource.TargetEntity;

                                        customManufacturingOrderOutFeeder.CurrentKnownOutsortedQuantity = 0;
                                        customManufacturingOrderOutFeeder.CurrentProcessedOutsortedQuantity = 0;

                                        collection.Add(customManufacturingOrderOutFeeder);
                                    }
                                }
                            }
                            // Add the relations to the MO:
                            if (!collection.IsNullOrEmpty())
                            {
                                materialMO.AddRelations(collection);
                            }
                        }
                    }
                }
            }

            //---End DEE Code---
            return Input;
        }




    }
}
