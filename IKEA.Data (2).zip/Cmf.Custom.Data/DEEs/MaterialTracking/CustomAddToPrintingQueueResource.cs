﻿using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using Cmf.Custom.IKEA.Common.Utilities;

namespace Cmf.Custom.IKEA.Actions.MaterialTracking
{
    public class CustomAddToPrintingQueueResource : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---

            #region Info

            /* Description: 
             *   When a material is tracked out, and if the resource has an attribute  {IKEAConstants.CustomResourceAttributePrintingQueueResource},
             *   stores the tracked out material in it.
             *      
             * Action groups:
             *   - BusinessObjects.MaterialCollection.TrackOut.Post
            */

            #endregion

            // By default, action is not to be executed
            bool executionVeridict = false;

            // List of eligible action groups (configuration sanity check)
            Collection<string> eligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.MaterialCollection.TrackOut.Post"
            };

            // only proceed if within expected triggers (action groups)
            executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, eligibleActionGroups);

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---

            // MES
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects");

            // Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Extensions");
            UseReference("Cmf.Custom.IKEA.Orchestration.dll", "Cmf.Custom.IKEA.Orchestration");
            UseReference("", "Cmf.Custom.IKEA.Orchestration.InputObjects");
            UseReference("", "Cmf.Custom.IKEA.Orchestration.OutputObjects");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
            UseReference("", "System.Globalization");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            INiceLabelUtilities nbUtilities = serviceProvider.GetService<INiceLabelUtilities>();
            ILocalizedMessage _localizedMessage = serviceProvider.GetService<ILocalizedMessage>();
            IGenericUtilities _genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();

            // Get the list of materials being tracked out
            IMaterialCollection materialCollection = IKEADEEActionUtilities.GetInputItem<IMaterialCollection>(Input, Navigo.Common.Constants.MaterialCollection);

            // Dictionary mapping each line's name and the dummy feeder resource (or null if the line does not have any)
            // So if multiple materials have the same last processed resource, we avoid multiple loads
            Dictionary<string, IResource> printingQueueResourceDictionary = new Dictionary<string, IResource>();

            Dictionary<IResource, IMaterialCollection> materialsToAddToQueues = new Dictionary<IResource, IMaterialCollection>();
            // Get the good type quantity
            string goodType = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.DefaultGoodTypeConfig);
            foreach (IMaterial trackOutMaterial in materialCollection)
            {
                // Only add to the printing queue completed materials
                if (trackOutMaterial.Form != ikeaUtilities.GetCompletedMaterialForm(trackOutMaterial) || trackOutMaterial.Type != goodType)
                {
                    continue;
                }

                IResource lineResource = trackOutMaterial.LastProcessedResource;

                // Will contain the resource that serves as the printing queue associated with the materials' last processed resource.
                // Can be null the printing queue is not enabled for this line
                IResource printingQueueResource;

                if (!printingQueueResourceDictionary.TryGetValue(lineResource.Name, out printingQueueResource))
                {
                    printingQueueResource = ikeaUtilities.GetAssociatedPrintingQueueResource(lineResource);

                    printingQueueResourceDictionary[lineResource.Name] = printingQueueResource;
                }

                // The line has a printing resource configured
                if (printingQueueResource != null)
                {
                    IMaterialCollection materialsForThisQueue;

                    // Check if there are already materials to be added to the queue of this resource
                    if (!materialsToAddToQueues.TryGetValue(printingQueueResource, out materialsForThisQueue))
                    {
                        materialsForThisQueue = entityFactory.CreateCollection<IMaterialCollection>();

                        materialsToAddToQueues[printingQueueResource] = materialsForThisQueue;
                    }

                    materialsForThisQueue.Add(trackOutMaterial);
                }
            }

            foreach (KeyValuePair<IResource, IMaterialCollection> kv in materialsToAddToQueues)
            {
                ikeaUtilities.AddMaterialToPrintingQueue(kv.Key, kv.Value);
            }

            //---End DEE Code---
            return null;
        }
    }
}
