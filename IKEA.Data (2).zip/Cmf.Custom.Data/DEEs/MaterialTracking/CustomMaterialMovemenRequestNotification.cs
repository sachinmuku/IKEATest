﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Orchestration.Abstractions;
using Cmf.Custom.IKEA.Orchestration.InputObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.MaterialTracking
{
    public class CustomMaterialMovemenRequestNotification : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text: Dee that invokes CustomRequestMaterialTransfer service to generate a notification for Material transfer
            ///     
            /// Action Groups:MaterialManagement.MaterialManagementOrchestration.ComplexMoveMaterialsToNextStep.Post
            ///               MaterialManagement.MaterialManagementOrchestration.ChangeMaterialFlowAndStep.Post
            ///               MaterialManagement.MaterialManagementOrchestration.ComplexMoveMaterialsToNextStep.Pre
            ///               MaterialManagement.MaterialManagementOrchestration.ChangeMaterialFlowAndStep.Pre
            /// 
            /// Depends On: ND
            /// Is Dependency For: ND
            /// Exceptions: ND
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "MaterialManagement.MaterialManagementOrchestration.ComplexMoveMaterialsToNextStep.Post",
                "MaterialManagement.MaterialManagementOrchestration.ChangeMaterialFlowAndStep.Post",
                "MaterialManagement.MaterialManagementOrchestration.ComplexMoveMaterialsToNextStep.Pre",
                "MaterialManagement.MaterialManagementOrchestration.ChangeMaterialFlowAndStep.Pre"
            };

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            if (executionVeridict &&
                IKEADEEActionUtilities.GetInputItem<ComplexMoveMaterialsToNextStepInput>(Input, "ComplexMoveMaterialsToNextStepInput") == null &&
                IKEADEEActionUtilities.GetInputItem<ChangeMaterialFlowAndStepInput>(Input, "ChangeMaterialFlowAndStepInput") == null)
            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---  

            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");


            //System
            UseReference("", "Cmf.Custom.IKEA.Orchestration.Abstractions");
            UseReference("", "System");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("", "System.Linq");
            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            //Foundation
            UseReference("", "Cmf.Foundation.Common");
            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects");
            //Custom
            UseReference("Cmf.Custom.IKEA.Orchestration.dll", "Cmf.Custom.IKEA.Orchestration.InputObjects");
            UseReference("Cmf.Custom.IKEA.Orchestration.dll", "Cmf.Custom.IKEA.Orchestration.OutputObjects");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Extensions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.BusinessObjects.CustomERPOperationTracking.dll", "Cmf.Custom.IKEA.BusinessObjects");
            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            //IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            var iKEABusinessManagementOrchestration = serviceProvider.GetService<IIKEABusinessManagementOrchestration>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            INiceLabelUtilities nbUtilities = serviceProvider.GetService<INiceLabelUtilities>();
            ILocalizedMessage _localizedMessage = serviceProvider.GetService<ILocalizedMessage>();
            IGenericUtilities _genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();

            DeeContext currentContext = deeContextUtilities.SetCurrentServiceContext("CustomMaterialMovemenRequestNotification");

            #region PRE Trigger

            if (currentContext.TriggerPoint == DeeTriggerPoint.Pre)
            {
                List<MaterialMovementEntity> materialMovementData = new List<MaterialMovementEntity>();

                // Handle MoveNext 
                if (currentContext.MethodName.StartsWith("ComplexMoveMaterialsToNextStep", System.StringComparison.InvariantCultureIgnoreCase))
                {
                    if (Input["ComplexMoveMaterialsToNextStepInput"] is ComplexMoveMaterialsToNextStepInput)
                    {
                        ComplexMoveMaterialsToNextStepInput data = Input["ComplexMoveMaterialsToNextStepInput"] as ComplexMoveMaterialsToNextStepInput;
                        //Gather Materials 
                        var dictionary = data.Materials;
                        foreach (IMaterial mat in dictionary.Keys)
                        {
                            //Check if Material form is one of the CompletedForms defined in the SmartTable
                            if (mat.ObjectExists() && mat.Form.CompareStrings(ikeaUtilities.GetCompletedMaterialForm(mat)))
                            {
                                Tuple<MaterialMovementEntity, bool> materialMovementBehavior = ikeaUtilities.ValidateMaterialMovement(mat, "StepOut");

                                //Validate if movement request is required
                                if (materialMovementBehavior?.Item2 ?? false)
                                {
                                    materialMovementData.Add(materialMovementBehavior.Item1);
                                }
                            }
                        }

                    }
                }

                //Change Flow and Step
                if (currentContext.MethodName.StartsWith("ChangeMaterialFlowAndStep", System.StringComparison.InvariantCultureIgnoreCase))
                {
                    if (Input["ChangeMaterialFlowAndStepInput"] is ChangeMaterialFlowAndStepInput)
                    {
                        ChangeMaterialFlowAndStepInput data = Input["ChangeMaterialFlowAndStepInput"] as ChangeMaterialFlowAndStepInput;

                        IMaterial material = data.Material;

                        if (material.ObjectExists() && material.Type == null)
                        {
                            material.Load();
                        }
                        //Check if Material form is one of the CompletedForms defined in the SmartTable
                        if (material.Form.CompareStrings(ikeaUtilities.GetCompletedMaterialForm(material)))
                        {
                            Tuple<MaterialMovementEntity, bool> materialMovementBehavior = ikeaUtilities.ValidateMaterialMovement(material, "StepOut");

                            //Validate if movement request is required
                            if (materialMovementBehavior?.Item2 ?? false)
                            {
                                materialMovementData.Add(materialMovementBehavior.Item1);
                            }
                        }
                    }
                }
                deeContextUtilities.SetContextParameter("CustomMaterialMovemenRequestNotification_Materials", materialMovementData);
            }

            #endregion

            #region POST trigger

            if (currentContext.TriggerPoint == DeeTriggerPoint.Post)
            {
                //Get gathered MaterialMovementEntity at Pre
                List<MaterialMovementEntity> materialsMovementData = deeContextUtilities.GetContextParameter("CustomMaterialMovemenRequestNotification_Materials") as List<MaterialMovementEntity>;
                CustomRequestMaterialTransferInput customRequestMaterialTransferInput = null;
                foreach (var materialMovementData in materialsMovementData)
                {
                    IMaterial materialBeingMoved = entityFactory.Create<IMaterial>();
                    materialBeingMoved.Name = materialMovementData.MaterialToTransfer;
                    materialBeingMoved.Load();

                    //Call service with Source and Target information
                    customRequestMaterialTransferInput = new CustomRequestMaterialTransferInput();

                    #region Source location

                    //Extracted from the Material information collected at PRE
                    customRequestMaterialTransferInput.FromFacility = materialMovementData.SourceFacility;
                    customRequestMaterialTransferInput.FromArea = materialMovementData.SourceArea;
                    customRequestMaterialTransferInput.FromLocation = materialMovementData.SourceResource;

                    #endregion

                    #region Material to Transfer

                    customRequestMaterialTransferInput.RequiredMaterial = materialMovementData.MaterialToTransfer;

                    #endregion

                    #region Target location

                    //Extracted from the Material at the current location
                    string areaName = null;
                    IStep step = materialBeingMoved.Step;
                    String resourceName = null;

                    //Get Area 
                    step.LoadRelations("StepArea");
                    long facilityId = materialBeingMoved.GetNativeValue<long>(IKEAConstants.Facility);
                    if (step.RelationCollection.ContainsKey("StepArea"))
                    {
                        IStepArea stepArea = step.RelationCollection["StepArea"].FirstOrDefault(r => facilityId == (r as IStepArea).TargetEntity.GetNativeValue<long>(IKEAConstants.Facility)) as IStepArea;
                        if (stepArea != null)
                        {
                            areaName = stepArea.TargetEntity.Name;
                        }
                    }

                    //Get Location
                    materialBeingMoved.LoadRelations(Constants.MaterialResource);
                    if (materialBeingMoved.RelationCollection.ContainsKey(Constants.MaterialResource))
                    {
                        IMaterialResource materialResource = materialBeingMoved.RelationCollection[Constants.MaterialResource].FirstOrDefault() as IMaterialResource;
                        resourceName = materialResource.TargetEntity.Name;
                    }

                    customRequestMaterialTransferInput.ToFacility = materialBeingMoved.Facility.Name;
                    customRequestMaterialTransferInput.ToArea = areaName;


                    //Extracted from the Material information collected at PRE
                    customRequestMaterialTransferInput.ToLocation = materialMovementData.ToResource;

                    //grab the product and primary quantity
                    customRequestMaterialTransferInput.RequiredProduct = materialBeingMoved.Product.Name;
                    customRequestMaterialTransferInput.RequiredQuantity = materialBeingMoved.PrimaryQuantity;
                    #endregion

                    //Service call
                    iKEABusinessManagementOrchestration.CustomRequestMaterialTransfer(customRequestMaterialTransferInput);
                }
            }

            #endregion

            //---End DEE Code---
            return Input;
        }
    }
}
