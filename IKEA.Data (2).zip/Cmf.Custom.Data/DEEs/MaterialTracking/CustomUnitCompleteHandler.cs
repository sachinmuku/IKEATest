﻿using Accord;
using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;

using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Exceptions;
using Cmf.Custom.IKEA.Common.Extensions;
using Cmf.Custom.IKEA.Common.Utilities;
using Cmf.Custom.IKEA.Orchestration.Abstractions;
using Cmf.Custom.IKEA.Orchestration.InputObjects;
using Cmf.Custom.IKEA.Orchestration.OutputObjects;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects;
using Microsoft.Extensions.DependencyInjection;

using Newtonsoft.Json;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Linq;
using System.Threading;

namespace Cmf.Custom.IKEA.Actions.MaterialTracking
{

    /// <summary>
    /// This class is responsible for detecting existence of {IKEAConstants.UnitCompletionDataCollectionParameterName} parameter in a data collection and if present and defined, trigger the creation
    /// of a tracking unit according to the resolved form and replacing it as the input material in the orchestration layer.
    /// </summary>
    public class CustomUnitCompleteHandler : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---

            #region Info

            /* Description: 
             *   This class is responsible for detecting existence of {IKEAConstants.UnitCompletionDataCollectionParameterName} parameter in a data collection and if present and defined, trigger the creation
             *   of a tracking unit according to the resolved form and replacing it as the input material in the orchestration layer.
             *      
             * Action groups:
             *   - MaterialManagement.MaterialManagementOrchestration.ComplexTrackOutMaterials.Pre
            */

            #endregion

            // By default, action is not to be executed
            bool executionVeridict = false;

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "MaterialManagement.MaterialManagementOrchestration.ComplexTrackOutMaterials.Pre"
            };

            // only proceed if within expected triggers (action groups)
            executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---

            UseReference("%MicrosoftNetPath%System.Private.CoreLib.dll", "System.Threading");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");


            // System
            UseReference("", "System.Globalization");

            // MES
            UseReference("", "Cmf.Custom.IKEA.Orchestration.Abstractions");
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            // Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Exceptions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Extensions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Orchestration.InputObjects");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Orchestration.OutputObjects");
            
            UseReference("Cmf.Custom.IKEA.Orchestration.dll", "Cmf.Custom.IKEA.Orchestration");

            // Newtonsoft
            UseReference("Newtonsoft.Json.dll", "Newtonsoft.Json");


            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            var iKEABusinessManagementOrchestration = serviceProvider.GetService<IIKEABusinessManagementOrchestration>();
            IEntityFactory entityFactory = serviceProvider.GetRequiredService<IEntityFactory>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IDirectFeedingUtilities drUtilities = serviceProvider.GetService<IDirectFeedingUtilities>();
            ILocalizedMessage _localizedMessage = serviceProvider.GetService<ILocalizedMessage>();
            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();


            // collect all materials in the collection posting a data collection and containing the required parameter
            ComplexTrackOutMaterialsInput inputItem = IKEADEEActionUtilities.GetInputItem<ComplexTrackOutMaterialsInput>(Input, "ComplexTrackOutMaterialsInput");

            // The quantity and type pof the material is sent through operation attributes in the GUI
            // it is necessary to validate if they exist otherwise it is a pallet
            if (inputItem != null && inputItem.Materials != null)
            {
                Decimal completedQuantity = 0;
                Decimal realCompletedQuantity = 0;
                string type = null;
                IResource palletizeResource = null;
                bool guiSource = false;

                if (inputItem.OperationAttributes != null)
                {
                    if (inputItem.OperationAttributes.Any(item => item.Name == IKEAConstants.OperationAttributeType) &&
                        inputItem.OperationAttributes.Any(item => item.Name == IKEAConstants.OperationAttributeCompletedQuantity))
                    {
                        completedQuantity = decimal.Parse(inputItem.OperationAttributes.Where(item => item.Name == IKEAConstants.OperationAttributeCompletedQuantity).FirstOrDefault().Value.ToString(), CultureInfo.InvariantCulture);
                        type = inputItem.OperationAttributes.Where(item => item.Name == IKEAConstants.OperationAttributeType).FirstOrDefault().Value.ToString();
                    }
                    if (inputItem.OperationAttributes.Any(item => item.Name == IKEAConstants.OperationAttributePalletizeResource))
                    {
                        palletizeResource = inputItem.OperationAttributes.Where(item => item.Name == IKEAConstants.OperationAttributePalletizeResource).FirstOrDefault().Value as IResource;
                    }

                    guiSource = inputItem.OperationAttributes.FirstOrDefault(item => item.Name == IKEAConstants.OperationAttributeGUISource)?.Value as bool? == true;
                }

                // Create twin dictionary to replace original complex trackout parameter settings
                Dictionary<IMaterial, ComplexTrackOutParameters> replacingDictionary = new Dictionary<IMaterial, ComplexTrackOutParameters>();

                // get process order form to determine need of processing
                string processOrderForm = ikeaUtilities.GetOrderMaterialForm();

                // go through each configured material for trackout and try to check for the existence of a data collection with the necessary parameter
                foreach (KeyValuePair<IMaterial, ComplexTrackOutParameters> materialConfig in inputItem.Materials)
                {
                    // In case of group MO, store the accumulated trackout quantities of the child MOs (The Group MO does not TrackOut):
                    decimal quantityToRemoveFromGroupMO = 0;

                    //6.4.1 needs the objects to be loaded at Pre
                    IMaterial material = entityFactory.Create<IMaterial>();

                    material.Name = materialConfig.Key.Name;

                    material.Load();

                    // if material is in process order form and trackout parameters are set, proceed with checking parameter existence
                    if (String.Equals(material.Form, processOrderForm, StringComparison.InvariantCultureIgnoreCase) && materialConfig.Value != null)
                    {

                        IMaterialCollection sourceMoMaterials = entityFactory.CreateCollection<IMaterialCollection>();

                        Dictionary<IMaterial, decimal> groupMoMaterialInformation = new Dictionary<IMaterial, decimal>();

                        if (material.IsGroupMO())
                        {
                            // Get child MOs and parts per cycle from the group MO:
                            groupMoMaterialInformation = ikeaUtilities.GetChildMaterialsAndPartsPerCycleFromGroupMO(material);
                            sourceMoMaterials.AddRange(groupMoMaterialInformation.Keys);
                        }
                        else
                        {
                            sourceMoMaterials.Add(material);
                        }

                        #region Create Left-Overs
                        sourceMoMaterials.LoadAttributes(new Collection<string> { IKEAConstants.CustomMaterialMESLeftOversByCycleAttribute });

                        IMaterial moWithLeftOver = sourceMoMaterials.Where(m => m.GetAttributeValueOrDefault<decimal>(IKEAConstants.CustomMaterialMESLeftOversByCycleAttribute) > 0).FirstOrDefault();

                        if (moWithLeftOver != null)
                        {
                            IBOMProductCollection materialBOMProducts = ikeaUtilities.GetCurrentBOMProductsFromMaterials(new List<string>() { moWithLeftOver.Name });

                            if (materialBOMProducts.Any())
                            {
                                materialBOMProducts.LoadAttributes(new Collection<string>
                                    {
                                        IKEAConstants.BomProductIsByProductSegmentAttribute
                                    });

                                IBOMProduct bomProduct = materialBOMProducts.Where(d => d.GetAttributeValueOrDefault<bool>(IKEAConstants.BomProductIsByProductSegmentAttribute)).FirstOrDefault();

                                //Get the Bom Product with by-product as true
                                if (bomProduct != null)
                                {
                                    IProduct productLeftOver = bomProduct.TargetEntity;
                                    productLeftOver.Load();
                                    decimal leftOverQuantity = moWithLeftOver.GetAttributeValueOrDefault<decimal>(IKEAConstants.CustomMaterialMESLeftOversByCycleAttribute);
                                    ikeaUtilities.CreateLeftOvers(moWithLeftOver, productLeftOver, leftOverQuantity, true, true);
                                }
                            }
                        }

                        #endregion  Create Left-Overs

                        if (material.IsGroupMO())
                        {
                            IResource line = material.LastProcessedResource;
                            line.Load();

                            material.UpdateCustomManufacturingOrderOutFeederRelation(line, type, palletizeResource, completedQuantity);
                        }

                        IResource mainLineResource = material.LastProcessedResource;
                        mainLineResource.Load();
                        CustomUnitCompletionModeEnum unitCompletionMode = mainLineResource.GetAttributeValueOrDefault<CustomUnitCompletionModeEnum>(IKEAConstants.CustomResourceAttributeUnitCompletionMode, true);
                        CustomAutomationTrackingModeEnum automationTrackingMode = mainLineResource.GetAttributeValueOrDefault<CustomAutomationTrackingModeEnum>(IKEAConstants.CustomAutomationTrackingMode, true);

                        foreach (var sourceMoMaterial in sourceMoMaterials)
                        {
                            // Set the adjusted quantity to default:
                            decimal adjustedQuantity = completedQuantity;

                            // If we are dealing with MOs that belong to a GroupMO, we must check the parts per cycle:
                            if (!groupMoMaterialInformation.IsNullOrEmpty())
                            {
                                // Get the parts per cyle value:
                                decimal partsPerCycle = groupMoMaterialInformation.Where(GMI => GMI.Key.Id == sourceMoMaterial.Id).First().Value;

                                // Update the quantity to trackout according to the number of parts per cycle:
                                adjustedQuantity = completedQuantity * partsPerCycle;

                                quantityToRemoveFromGroupMO += adjustedQuantity;
                            }



                            // If it's direct feeding
                            bool isDirectFeedingEnabled = genericUtilities.GetConfigurationValueByPath<bool>(IKEAConstants.EnableDirectFeedingConfig);
                            if (isDirectFeedingEnabled)
                            {
                                IResource line = material.LastProcessedResource;
                                line.Load();

                                CustomDirectFeedingModeEnum materialDirectFeedingMode = material.GetAttributeValueOrDefault<CustomDirectFeedingModeEnum>(IKEAConstants.CustomMaterialAttributeDirectFeedingMode, loadAttribute: true);
                                bool isLineUsingDirectFeeding = line.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomResourceDirectFeedingEnabled, loadAttribute: true);
                                bool directFeedingIsFirstLine = line.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomResourceDirectFeedingIsFirstLine, loadAttribute: true);

                                // Only if the request comes from the second line
                                if (materialDirectFeedingMode == CustomDirectFeedingModeEnum.DirectFeeding
                                    && isLineUsingDirectFeeding
                                    && !directFeedingIsFirstLine)
                                {

                                    // Calculate quantity to palletize
                                    decimal fullQuantity = drUtilities.CalculateDirectFeedingQuantityAccordingWithBomRatio(line, material, adjustedQuantity);


                                    IResource topmostResourceSecondLine = palletizeResource.GetTopMostResource();
                                    topmostResourceSecondLine.Load();

                                    // Get resource counterpart
                                    IResource firstLine = drUtilities.GetDirectFeedingCounterpartResource(topmostResourceSecondLine);

                                    if (firstLine == null)
                                    {
                                        throw new IKEAException(IKEAConstants.CustomDirectFeedingResourceCounterPartNoValid, line.Name);
                                    }

                                    // Get counterpart material
                                    string counterpartMaterialName = material.GetAttributeValueOrDefault<string>(IKEAConstants.CustomMaterialAttributeDirectFeedingCounterPart, loadAttribute: true);
                                    IMaterial counterpartMaterial = entityFactory.Create<IMaterial>();
                                    counterpartMaterial.Name = counterpartMaterialName;

                                    // Flag to determine if counterpart material is valid
                                    bool isCounterpartMaterialValid = drUtilities.ValidateCounterpartMaterialForPalletization(counterpartMaterial, fullQuantity);

                                    // If the counterpart material is valid then continue with process
                                    if (isCounterpartMaterialValid)
                                    {

                                        // Perform trackout, move-next and attach, with necessary quantity to pallet created on counter part line, the service will validate quantity
                                        try
                                        {
                                            string completedUnitType = genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.DefaultGoodTypeConfig);

                                            // Invoke palletization service
                                            IMaterial palletProduced = iKEABusinessManagementOrchestration.CustomUnitComplete(
                                                    new CustomUnitCompleteInput()
                                                    {
                                                        ProcessOrderMaterial = counterpartMaterial,
                                                        CompletedPrimaryQuantity = fullQuantity,
                                                        CompletedSecondaryQuantity = null,
                                                        ExcludeTrackout = false,
                                                        IgnoreOrderMaterialState = true,
                                                        CompletedUnitType = completedUnitType,
                                                        IsProcessLoss = false,
                                                        IsAutomationInvoke = true
                                                    }).CompletedUnit;

                                            // Get counterpart resource and main feeder
                                            string secondLineMainFeederName = line.GetAttributeValueOrDefault<string>(IKEAConstants.MESAutomationInFeederSubResourceController, true);
                                            IResource secondLineMainFeeder = entityFactory.Create<IResource>();
                                            secondLineMainFeeder.Name = secondLineMainFeederName;
                                            secondLineMainFeeder.Load();

                                            // Get consumption flow path
                                            string consumptionFlowPath = ikeaUtilities.ResolveConsumptionMaterialFlowByResource(resource: secondLineMainFeeder);

                                            // Perform move-next and attach operations
                                            deeContextUtilities.SetContextParameter(IKEAConstants.CustomDirectFeedingIsToSpecialAttach, true);
                                            deeContextUtilities.SetContextParameter(IKEAConstants.CustomDirectFeedingAutomaticAttach, true);
                                            IStep consumptionStep = genericUtilities.GetStepByFlowPath(consumptionFlowPath);
                                            IFlow consumptionFlow = genericUtilities.GetFlowsInFlowPath(consumptionFlowPath).FirstOrDefault();
                                            palletProduced.ChangeFlowAndStep(consumptionFlow, consumptionFlowPath, consumptionStep, new OperationAttributeCollection { });
                                            ikeaUtilities.ApplyOperationActions(palletProduced, secondLineMainFeeder, "Attach");


                                            // Send request to IoT
                                            drUtilities.SendRequestReducePalletQuantityOnOutfeeder(firstLine, counterpartMaterial, fullQuantity);
                                        }
                                        catch (Exception ex)
                                        {
                                            throw new IKEAException(IKEAConstants.CustomPalletizeNotSuccessfulOnFirstLine, ex.Message);
                                        }
                                    }
                                }
                            }

                            Dictionary<string, decimal> materialsToConsume = new Dictionary<string, decimal>();
                            Dictionary<IResource, List<IMaterial>> materialsToConsumeMap = new Dictionary<IResource, List<IMaterial>>();
                            if (guiSource && unitCompletionMode == CustomUnitCompletionModeEnum.ManualOutsorting && mainLineResource.AutomationMode == ResourceAutomationMode.Online && automationTrackingMode == CustomAutomationTrackingModeEnum.ExplicitTracking)
                            {
                                // Call IoT to get the explicit materials to be used in assemble
                                IAutomationControllerInstance controllerInstance = mainLineResource.GetAutomationControllerInstance();
                                string requestType = IKEAConstants.AutomationRequestTypeOutsorterExplicitPalletsRequest;

                                Dictionary<string, string> reply = genericUtilities.RequestFromIoT<Dictionary<string, string>>(controllerInstance, requestType, new
                                {
                                    OrderName = material.Name,
                                    SubResourceName = palletizeResource?.Name,
                                    QuantityToRetrieve = adjustedQuantity,
                                }); ;

                                string parsedReply;
                                if (reply != null && reply.ContainsKey(IKEAConstants.AutomationRequestReplyField))
                                {
                                    parsedReply = reply[IKEAConstants.AutomationRequestReplyField];
                                    materialsToConsume = JsonConvert.DeserializeObject<Dictionary<string, decimal>>(parsedReply);
                                }


                                // if there are undefined pieces, it means that they were not consumed on IoT. 
                                // It will throw an exception to inform the operator that there are null pieces, consumption should be checked and ReloadPendingTrackouts button should be pressed
                                if (materialsToConsume.Any((mat) => mat.Key.IsNullOrEmpty()))
                                {
                                    // Enable the Reload Pensing Trackouts button in the cockpit by requesting IoT to save attribute CustomResourcePalletizeErrorHandleEnabledAttribute to true
                                    string saveAttributesRequestType = IKEAConstants.AutomationRequestTypeSaveAttributesOnResource;
                                    _ = genericUtilities.RequestFromIoT<Dictionary<string, string>>(controllerInstance, saveAttributesRequestType, new
                                    {
                                        ResourceName = palletizeResource?.Name,
                                    });

                                    int numberOfNullPieces = (int)materialsToConsume[""];
                                    throw new Exception(String.Format(_localizedMessage.LoadLocalizedMessage(Thread.CurrentThread.CurrentCulture.Name, IKEAConstants.CustomManualOutsortingExplicitTrackingUndefinedPieces).MessageText, numberOfNullPieces, palletizeResource?.Name));
                                }

                                foreach (var materialToConsume in materialsToConsume)
                                {
                                    IMaterial mat = entityFactory.Create<IMaterial>();
                                    mat.Load(Int64.Parse(materialToConsume.Key));
                                    mat.PrimaryQuantity = materialToConsume.Value;


                                    IResource feeder = null;
                                    if (mat.HasRelations("MaterialResource", true))
                                    {
                                        feeder = mat.RelationCollection["MaterialResource"][0].TargetEntity as IResource;
                                    }

                                    // The material is not attached to the feeder anymore. Try to get it from the SourceConsumptionMaterial attribute:
                                    if (feeder == null)
                                    {
                                        // Get only the online feeders of the main line:
                                        var onlineConsumableFeedsMaterials = ikeaUtilities.GetOnlineConsumableFeedsMaterials(mainLineResource);
                                        foreach (var consumableFeedMaterials in onlineConsumableFeedsMaterials)
                                        {
                                            // Load attribute CustomSourceConsumptionMaterial in all materials:
                                            consumableFeedMaterials.Value.LoadAttributes(new Collection<string> { IKEAConstants.CustomSourceConsumptionMaterial });

                                            // Check if any material contains the name of the source material in the attribute (the material from where it was splitted):
                                            if (consumableFeedMaterials.Value.Where(CFM => CFM.GetAttributeValueOrDefault<string>(IKEAConstants.CustomSourceConsumptionMaterial).CompareStrings(mat.Name)).Any())
                                            {
                                                feeder = consumableFeedMaterials.Key;
                                                break;
                                            }
                                        }
                                    }

                                    // If the feeder was not found, throw an error:
                                    if (feeder == null)
                                    {
                                        string sourceConsumptionMaterial = mat.GetAttributeValueOrDefault<string>(IKEAConstants.CustomSourceConsumptionMaterial, true);
                                        throw new IKEAException(IKEAConstants.CustomFeederNotFoundForTheSpecifiedAttachedMaterialLocalizedMessage,
                                                                                                     mat.Name,
                                                                                                     sourceConsumptionMaterial ?? "");
                                    }


                                    if (materialsToConsumeMap.Any(f => f.Key.Id == feeder.Id))
                                    {
                                        materialsToConsumeMap.Where(f => f.Key.Id == feeder.Id).FirstOrDefault().Value.Add(mat);
                                    }
                                    else
                                    {
                                        materialsToConsumeMap.Add(feeder, new List<IMaterial>() { mat });
                                    }
                                }
                            }


                            // invoke palletization service
                            CustomUnitCompleteOutput customUnitCompleteOutput = iKEABusinessManagementOrchestration.CustomUnitComplete(
                                    new CustomUnitCompleteInput()
                                    {
                                        ProcessOrderMaterial = sourceMoMaterial,
                                        CompletedPrimaryQuantity = adjustedQuantity,
                                        ExcludeTrackout = true,
                                        CompletedUnitType = type,
                                        PalletizeResource = palletizeResource,
                                        MaterialsToConsume = materialsToConsumeMap
                                    });

                            // sanity check. output is defined and palletized material exists
                            if (customUnitCompleteOutput != null && customUnitCompleteOutput.CompletedUnit != null)
                            {
                                realCompletedQuantity += customUnitCompleteOutput.CompletedQuantity;
                                // Keep the existing parameters if they exist:
                                ComplexTrackOutParameters p = new ComplexTrackOutParameters()
                                {
                                    ChecklistParameters = materialConfig.Value.ChecklistParameters,
                                    CurrentDataCollectionPoints = materialConfig.Value.CurrentDataCollectionPoints,
                                    DataCollectionPointsToDelete = materialConfig.Value.DataCollectionPointsToDelete
                                };

                                replacingDictionary.Add(customUnitCompleteOutput.CompletedUnit, p);
                            }
                        }


                        #region Notify Manually Outsorted Quantities to IoT

                        // If this TrackOut was triggered by the MES GUI
                        if (guiSource)
                        {
                            mainLineResource.Load();

                            if (mainLineResource.AutomationMode == ResourceAutomationMode.Online)
                            {
                                string processLossMaterialType = genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.CustomProcessLossMaterialDefaultTypePath);

                                // If automation mode is Online, Unit Completion is Manual Outsorting, and the type is not Process Loss,
                                // Notify IoT about the outsorted quantity so it can update the persistency counters
                                string currentMaterialState = material.CurrentMainState.CurrentState.Name;

                                if (unitCompletionMode == CustomUnitCompletionModeEnum.ManualOutsorting && !currentMaterialState.CompareStrings(IKEAConstants.MaterialStateModelAborted) &&
                                    !currentMaterialState.CompareStrings(IKEAConstants.MaterialStateModelCompleted) && !currentMaterialState.CompareStrings(IKEAConstants.MaterialStateModelQueued) &&
                                    !string.Equals(type, processLossMaterialType, StringComparison.InvariantCultureIgnoreCase))
                                {
                                    ikeaUtilities.IoTOutsorterRequestConfirmation(mainLineResource, material, palletizeResource, completedQuantity, realCompletedQuantity, replacingDictionary.Keys.ToList());

                                }
                            }
                        }

                        #endregion
                    }
                    else
                    {
                        material.CustomPerformAutomaticAssemble();
                        material.Load();
                        replacingDictionary.Add(material, materialConfig.Value);
                    }

                    // Update the Group MO primary quantity by subtracting the accumulated value of the child Mos: 
                    if (quantityToRemoveFromGroupMO > 0)
                    {
                        deeContextUtilities.SetContextParameter(IKEAConstants.CustomUnitCompleteHandlerUpdateGroupMOQuantityContextKey, true);

                        decimal newGroupMOQuantity = material.PrimaryQuantity.Value - quantityToRemoveFromGroupMO;
                        material.ChangeQuantity(newGroupMOQuantity, 0, null, null, null);

                        deeContextUtilities.SetContextParameter(IKEAConstants.CustomUnitCompleteHandlerUpdateGroupMOQuantityContextKey, false);
                    }

                }

                if (!inputItem.OperationAttributes.IsNullOrEmpty())
                {
                    // remove operation attributes from input because they are needed only for the custom unit complete
                    inputItem.OperationAttributes.Remove(inputItem.OperationAttributes.FirstOrDefault(item => item.Name == IKEAConstants.OperationAttributeType));
                    inputItem.OperationAttributes.Remove(inputItem.OperationAttributes.FirstOrDefault(item => item.Name == IKEAConstants.OperationAttributeCompletedQuantity));
                    inputItem.OperationAttributes.Remove(inputItem.OperationAttributes.FirstOrDefault(item => item.Name == IKEAConstants.OperationAttributePalletizeResource));
                    inputItem.OperationAttributes.Remove(inputItem.OperationAttributes.FirstOrDefault(item => item.Name == IKEAConstants.OperationAttributeGUISource));
                }

                // replace incoming dictionary with processed one
                inputItem.Materials.Clear();
                replacingDictionary.ToList().ForEach(E => inputItem.Materials.Add(E.Key, E.Value));

            }

            //---End DEE Code---
            return null;
        }

    }
}
