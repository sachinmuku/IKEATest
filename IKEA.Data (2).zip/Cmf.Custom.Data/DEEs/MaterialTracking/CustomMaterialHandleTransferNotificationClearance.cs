﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;

using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using INotification = Cmf.Navigo.BusinessObjects.Abstractions.INotification;
using INotificationCollection = Cmf.Navigo.BusinessObjects.Abstractions.INotificationCollection;

namespace Cmf.Custom.IKEA.Actions.MaterialTracking
{
    class CustomMaterialHandleTransferNotificationClearance : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---

            #region Info
            /// <summary>
            /// DEE to handle the creation of a Task after a clearance of a notification of the type MaterialTransferRequest 
            /// Action Groups: BusinessObjects.NotificationCollection.Terminate.Post
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion
            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();


            // By default, action is not to be executed
            bool executionVeridict = false;

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.NotificationCollection.Terminate.Post"
            };

            // Check if the notifications is being terminated by TerminateStockingPointTrackersAndTasks
            bool? terminateStockingPointTracker = deeContextUtilities.GetContextParameter(IKEAConstants.TerminateStockingPointTrackersAndTasksTerminateNotifications) as bool?;

            // only proceed if within expected triggers (action groups)
            executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups) && !terminateStockingPointTracker.GetValueOrDefault();

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---

            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");


            //System
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("", "System");
            //Foundation
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration");
            UseReference("Cmf.Foundation.Common.dll", "Cmf.Foundation.Common");
            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects");
            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            INiceLabelUtilities nbUtilities = serviceProvider.GetService<INiceLabelUtilities>();
            ILocalizedMessage _localizedMessage = serviceProvider.GetService<ILocalizedMessage>();
            IGenericUtilities _genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();

            // Get all notifications in the collection post:
            Cmf.Navigo.BusinessObjects.Abstractions.INotificationCollection inputItem = IKEADEEActionUtilities.GetInputItem<Cmf.Navigo.BusinessObjects.Abstractions.INotificationCollection>(Input, "NotificationCollection");

            // Get notification type:
            string notificationType = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.CustomMaterialTransferRequestTypePath);

            // Get task completion time:
            int materialTransferTargetCompletionTime = _genericUtilities.GetConfigurationValueByPath<int>(IKEAConstants.CustomMaterialTransferTargetCompletionTimePath);

            if (!notificationType.IsNullOrEmpty() && materialTransferTargetCompletionTime > 0)
            {
                // Get current logged Employee:
                IEmployee currentEmployee = ikeaUtilities.GetCurrentEmployee();

                // Gather all necessary attributes from notification:
                Collection<string> attributeCollection = new Collection<string>
                {
                    IKEAConstants.MaterialTransferFromArea,
                    IKEAConstants.MaterialTransferFromLocation,
                    IKEAConstants.MaterialTransferFromFacility,
                    IKEAConstants.MaterialTransferRequiredProduct,
                    IKEAConstants.MaterialTransferRequiredQuantity,
                    IKEAConstants.MaterialTransferRequiredMaterial,
                    IKEAConstants.MaterialTransferToArea,
                    IKEAConstants.MaterialTransferToLocation,
                    IKEAConstants.MaterialTransferToFacility,
                    IKEAConstants.SourceMaterialRequestId
                };

                ITaskCollection tasksToCreate = entityFactory.CreateCollection<ITaskCollection>();

                foreach (Cmf.Navigo.BusinessObjects.Abstractions.INotification notification in inputItem.Where(n => n.Type.Equals(notificationType, StringComparison.InvariantCultureIgnoreCase)))
                {
                    // Get all notification 'TransferRequest' attributes from notification:
                    notification.LoadAttributes(attributeCollection);

                    // Configure a new Task:
                    ITask task = entityFactory.Create<ITask>();

                    task.Title = notification.Title;
                    task.Details = notification.Details;
                    task.OriginalOwner = currentEmployee;
                    task.Owner = currentEmployee;
                    task.OriginalDueDate = DateTime.UtcNow.AddMinutes(materialTransferTargetCompletionTime);
                    task.DueDate = DateTime.UtcNow.AddMinutes(materialTransferTargetCompletionTime);


                    // Add the same 'TransferRequest' attributes from notification:
                    task.Attributes.AddRange((AttributeCollection)notification.Attributes);

                    // Add the TaskType attribute to be the same as the notification type: 
                    task.Attributes.Add(IKEAConstants.CustomTaskAttributeTaskType, notificationType);

                    // add the task to be created
                    tasksToCreate.Add(task);
                }

                if (tasksToCreate.Count > 0)
                {
                    tasksToCreate.Create();

                    // collect all task attributes
                    var notificationsToSend = tasksToCreate.Select(E => new
                    {
                        Facility = E.GetAttributeValueOrDefault<string>(IKEAConstants.MaterialTransferFromFacility) ?? String.Empty
                        ,
                        Area = E.GetAttributeValueOrDefault<string>(IKEAConstants.MaterialTransferFromArea) ?? String.Empty
                        ,
                        Resource = E.GetAttributeValueOrDefault<string>(IKEAConstants.MaterialTransferFromLocation) ?? String.Empty
                    }).Distinct();

                    foreach (var entry in notificationsToSend)
                    {
                        ikeaUtilities.PublishMaterialMovementEvent(entry.Facility, entry.Area, entry.Resource);
                    }
                }
            }


            //---End DEE Code---
            return null;
        }

    }
}


