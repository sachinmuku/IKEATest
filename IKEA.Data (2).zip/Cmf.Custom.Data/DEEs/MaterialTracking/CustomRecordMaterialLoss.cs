﻿using Cmf.Custom.IKEA.BusinessObjects;
using Cmf.Custom.IKEA.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Actions.MaterialTracking
{
    /// <summary>
    /// This class is responsible for loss recording tracking
    /// </summary>
    public class CustomRecordMaterialLoss : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---



            // MES
            UseReference("", "Cmf.Custom.IKEA.BusinessObjects.Abstractions");
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            // Custom
            UseReference("Cmf.Custom.IKEA.BusinessObjects.CustomMaterialLoss.dll", "Cmf.Custom.IKEA.BusinessObjects");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();

            //Before read check if MaterialCollection key exists in Input
            IMaterialCollection materialCollection = null;
            if (Input.ContainsKey("MaterialCollection"))
                materialCollection = Input["MaterialCollection"] as IMaterialCollection;

            //Before read check if Parameters key exists in Input
            Dictionary<IMaterial, IRecordLossParameters> materialWithLossParameters = null;
            if (Input.ContainsKey("Parameters"))
                materialWithLossParameters = Input["Parameters"] as Dictionary<IMaterial, IRecordLossParameters>;

            //Create new Dictionary to store relations to add
            Dictionary<IMaterial, ICmfEntityRelationCollection> relationsToAdd = new Dictionary<IMaterial, ICmfEntityRelationCollection>();
            foreach (var item in materialWithLossParameters)
            {
                //Add the key Material to the dictionary 
                relationsToAdd.Add(item.Key, serviceProvider.GetService<ICmfEntityRelationCollection>());
                foreach (var lossReason in item.Value.LossReasons)
                {
                    ICustomMaterialLoss customMaterialLoss = entityFactory.Create<ICustomMaterialLoss>();

                    customMaterialLoss.Step = item.Key.Step;
                    customMaterialLoss.SourceEntity = item.Key;

                    customMaterialLoss.TargetEntity = lossReason.Reason;
                    customMaterialLoss.PrimaryQuantity = lossReason.ReasonPrimaryQuantity;
                    customMaterialLoss.SecondaryQuantity = lossReason.ReasonSecondaryQuantity;

                    //Add to the key Material (item.Key) the loss info
                    relationsToAdd[item.Key].Add(customMaterialLoss);
                }
            }

            //Sanity check and add relation (insert into DB)
            if (relationsToAdd.Any())
            {
                materialCollection.AddRelations(relationsToAdd);
            }

            //---End DEE Code---
            return null;
        }

        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---

            #region Info

            /// <summary>
            /// Summary text
            ///     Records Material Loss relations
            /// Action Groups:
            ///     Cmf.Navigo.BusinessObjects.MaterialCollection.RecordLoss.Post
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>

            #endregion

            return true;
            //---End DEE Condition Code---
        }
    }
}
