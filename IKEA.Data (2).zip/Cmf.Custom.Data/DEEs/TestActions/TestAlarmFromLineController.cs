﻿using Cmf.Custom.IKEA.Orchestration.InputObjects;
using System.Collections.Generic;
using Cmf.Custom.IKEA.Orchestration.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.Enums;

namespace Cmf.Custom.IKEA.Actions.TestActions
{
    public class TestAlarmFromLineController : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     
            /// Action Groups:
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion

            return true;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            // Foundation
            UseReference("", "Cmf.Custom.IKEA.Orchestration.Abstractions");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "");
            UseReference("", "Cmf.Foundation.Common.Exceptions");
            UseReference("", "Cmf.Foundation.Common");
            // Navigo
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement");
            // Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Orchestration.dll", "Cmf.Custom.IKEA.Orchestration.InputObjects");
            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            var iKEABusinessManagementOrchestration = serviceProvider.GetService<IIKEABusinessManagementOrchestration>();


            //Please start code here
            //
            //This input values need to be changed accordingly to the desired behavior
            //  > CustomAlarmHandlingActions Smart Table needs to be configured
            //  > This example requires the Material MO000000001 to be in process on the Resource Cutting Line 1
            //
            // ** Input Values for DEE ** //

            string AlarmCodeOnSmartTable = "test";
            string AlarmCategoryOnSmartTable = "testCategory";
            string MaterialNameOnSmartTable = "MO000000001";
            string ResourceNameOnSmartTable = "Cutting Line 1";
            bool logAlarmOccurrence = false;
            //bool AlarmOccurrenceNotification = false;

            // ** Input Values for DEE ** //



            // ** DEE Body to simulate the request from line controller ** //

            CustomLogAlarmOccurrenceInput input = new CustomLogAlarmOccurrenceInput()
            {
                AlarmOperation = CustomAlarmOccurrenceOperationEnum.ToCreate,
                AlarmCode = AlarmCodeOnSmartTable,
                AlarmCategory = AlarmCategoryOnSmartTable,
                Material = MaterialNameOnSmartTable,
                Resource = ResourceNameOnSmartTable,
                Log = logAlarmOccurrence,
                AlarmOccurrenceUID = null
            };

            long? id = iKEABusinessManagementOrchestration.CustomLogAlarmOccurrence(input).AlarmOccurrenceUID;

            // ** End of DEE body ** //

            //---End DEE Code---

            return Input;
        }
    }
}
