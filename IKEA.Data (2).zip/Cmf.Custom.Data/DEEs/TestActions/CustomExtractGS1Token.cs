﻿using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Barcode;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;

namespace Cmf.Custom.IKEA.Actions.TestActions
{
    public class CustomExtractGS1Token : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text    Test action to parse Token information based on CustomScanningConfigurationToken and CustomScanningConfiguration
            ///     
            /// Action Groups:
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion

            return true;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            // CORE
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "");
            UseReference("", "Cmf.Foundation.Common.Exceptions");
            UseReference("", "Cmf.Foundation.Common");
            
            // COMMON
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            // CUSTOM
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Extensions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Barcode");

            Dictionary<string, object> output = new Dictionary<string, object>();
            string resultKeyWord = "Result";

            //Get input items
            string tokenName = IKEADEEActionUtilities.GetInputItem<string>(Input, IKEAConstants.TokenNameKey);
            string standardToken = IKEADEEActionUtilities.GetInputItem<string>(Input, IKEAConstants.StandardTokenKey);
            string barcodeInformation = IKEADEEActionUtilities.GetInputItem<string>(Input, IKEAConstants.BarcodeKey);

            //Parse barcode token based on token name and standard token
            // TokenName represents the name of the entity in MES ( eg. Material, Product, etc)
            // StandardToken represents the numeric id of the token (eg. 240 > Material; 90 > Product, etc )
            // BarcodeInformation represents the extracted information about the token

            //Example to set decimal case in Quantity
            int standardTokenInt = Convert.ToInt32(standardToken);
            if (standardTokenInt >= 3100 && standardTokenInt <= 3699)
            {
                // extract up until 3rd character and use it as base line (0) characters
                int numberOfDecimals = Convert.ToInt32(standardToken) - Convert.ToInt32(standardToken.Substring(0, 3) + "0");
                decimal divisor = (decimal)Math.Pow(10, numberOfDecimals);
                output[resultKeyWord] = (Decimal.Parse(barcodeInformation) / divisor).ToString();
            }
            else
            {
                //Return data from DEE
                output[resultKeyWord] = barcodeInformation;
            }

            return output;

            //---End DEE Code---
        }
    }
}
