﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.BusinessObjects;
using Cmf.Custom.IKEA.BusinessObjects.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Exceptions;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading;

namespace Cmf.Custom.IKEA.Actions.Steps
{
    public class CustomScrapRoomValidations : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Validate the materials that are going into a Scrap Room and terminate all the ones that enter it
            /// Action Groups:
            ///     MaterialManagement.MaterialManagementOrchestration.ComplexMoveMaterialsToNextStep.Pre
            ///     MaterialManagement.MaterialManagementOrchestration.ComplexMoveMaterialsToNextStep.Post
            ///     MaterialManagement.MaterialManagementOrchestration.ChangeMaterialFlowAndStep.Pre
            ///     MaterialManagement.MaterialManagementOrchestration.ChangeMaterialFlowAndStep.Post
            ///     MaterialManagement.MaterialManagementOrchestration.MoveMaterialToStep.Pre
            ///     MaterialManagement.MaterialManagementOrchestration.MoveMaterialToStep.Post
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "MaterialManagement.MaterialManagementOrchestration.ComplexMoveMaterialsToNextStep.Post",
                "MaterialManagement.MaterialManagementOrchestration.ChangeMaterialFlowAndStep.Post",
                "MaterialManagement.MaterialManagementOrchestration.ComplexMoveMaterialsToNextStep.Pre",
                "MaterialManagement.MaterialManagementOrchestration.ChangeMaterialFlowAndStep.Pre",
                "MaterialManagement.MaterialManagementOrchestration.MoveMaterialToStep.Pre",
                "MaterialManagement.MaterialManagementOrchestration.MoveMaterialToStep.Post"
            };

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            if (executionVeridict &&
                IKEADEEActionUtilities.GetInputItem<ComplexMoveMaterialsToNextStepInput>(Input, "ComplexMoveMaterialsToNextStepInput") == null &&
                IKEADEEActionUtilities.GetInputItem<ChangeMaterialFlowAndStepInput>(Input, "ChangeMaterialFlowAndStepInput") == null &&
                IKEADEEActionUtilities.GetInputItem<MoveMaterialToStepInput>(Input, "MoveMaterialToStepInput") == null)
            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            //System
            UseReference("", "Cmf.Custom.IKEA.BusinessObjects.Abstractions");
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("", "System.Text");
            UseReference("", "System");

            //Foundation
            UseReference("Cmf.Foundation.Common.dll", "Cmf.Foundation.Common");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");

            //Custom
            UseReference("Cmf.Custom.IKEA.BusinessObjects.CustomMaterialLoss.dll", "Cmf.Custom.IKEA.BusinessObjects");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Exceptions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");


            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            ILocalizedMessage localizedMessage = serviceProvider.GetService<ILocalizedMessage>();
            IIKEAUtilities ikeaUtillties = serviceProvider.GetService<IIKEAUtilities>();
            IKEAException ikeaException = serviceProvider.GetService<IKEAException>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();
            DeeContext currentContext = deeContextUtilities.SetCurrentServiceContext("CustomScrapRoomValidations");

            // Get configured Scrap Room type
            string scrapRoomType = genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.ScrapRoomType);

            // Check if there is any Scrap Room type configured
            if (!string.IsNullOrWhiteSpace(scrapRoomType))
            {
                // On Pre we will validate if the material can go into the Scrap Room
                if (currentContext.TriggerPoint == DeeTriggerPoint.Pre)
                {
                    StringBuilder errorMessage = new StringBuilder();

                    IMaterialCollection materialsToValidate = entityFactory.CreateCollection<IMaterialCollection>();

                    ComplexMoveMaterialsToNextStepInput materialsToNextStepInput = IKEADEEActionUtilities.GetInputItem<ComplexMoveMaterialsToNextStepInput>(Input, "ComplexMoveMaterialsToNextStepInput");
                    ChangeMaterialFlowAndStepInput materialFlowAndStepInput = IKEADEEActionUtilities.GetInputItem<ChangeMaterialFlowAndStepInput>(Input, "ChangeMaterialFlowAndStepInput");
                    MoveMaterialToStepInput moveMaterialToStepInput = IKEADEEActionUtilities.GetInputItem<MoveMaterialToStepInput>(Input, "MoveMaterialToStepInput");

                    // Get configured Scrap Material Type
                    string scrapMaterialType = genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.MaterialTypeScrapConfig);

                    // Get the default reject unit
                    string rejectUnit = genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.ScrapManagementRejectUnit);

                    IStepCollection steps = entityFactory.CreateCollection<IStepCollection>();

                    Dictionary<IMaterial, IStep> materialSteps = new Dictionary<IMaterial, IStep>();

                    // Get materials and target steps from MaterialsToNextStep
                    if (materialsToNextStepInput != null)
                    {
                        if (!materialsToNextStepInput.Materials.IsNullOrEmpty())
                        {
                            foreach (var materialFlowPath in materialsToNextStepInput.Materials)
                            {
                                materialSteps.Add(materialFlowPath.Key, genericUtilities.GetStepByFlowPath(materialFlowPath.Value, false));
                            }
                        }
                    }
                    // Get materials and target steps from ChangeMaterialFlowAndStep
                    else if (materialFlowAndStepInput != null)
                    {
                        materialSteps.Add(materialFlowAndStepInput.Material, materialFlowAndStepInput.Step);
                    }
                    // Get materials and target steps from MoveMaterialToStep
                    else if (moveMaterialToStepInput != null)
                    {
                        materialSteps.Add(moveMaterialToStepInput.Material, genericUtilities.GetStepByFlowPath(moveMaterialToStepInput.FlowPath, false));
                    }

                    // Check if there are any materials to validate
                    if (!materialSteps.IsNullOrEmpty())
                    {
                        steps.AddRange(materialSteps.Values);
                        steps.Load();

                        List<string> materialsWithPrimaryQuantity = new List<string>();
                        List<string> materialsWithoutRejectUnits = new List<string>();
                        List<string> materialsWrongSecondaryQuantity = new List<string>();
                        List<string> materialsWrongType = new List<string>();
                        List<string> materialsWrongForm = new List<string>();

                        // Get all the materials that are going into a Scrap Room step
                        materialsToValidate.AddRange(materialSteps.Where(ms => ms.Value.Type == scrapRoomType).Select(ms => ms.Key).ToList());

                        // Check if there are any materials to validate
                        if (!materialsToValidate.IsNullOrEmpty())
                        {
                            materialsToValidate.LoadRelations(IKEAConstants.CustomMaterialLoss);

                            // Go throw all the materials to validate and if it fails in any validation
                            // it will then be put in the list corresponding to the fail validation
                            foreach (IMaterial materialToValidate in materialsToValidate)
                            {

                                // Get the complete form for the material
                                string completedForm = ikeaUtillties.GetCompletedMaterialForm(materialToValidate);


                                // Check if the material is of the configured scrap type
                                if (!materialToValidate.Type.CompareStrings(scrapMaterialType))
                                {
                                    materialsWrongType.Add(materialToValidate.Name);
                                }

                                // Check if the material form is not a Completed Form 
                                if (!materialToValidate.Form.CompareStrings(completedForm))
                                {
                                    materialsWrongForm.Add(materialToValidate.Name);
                                }

                                // Check if the material primary is zero
                                if (materialToValidate.PrimaryQuantity.GetValueOrDefault() > 0)
                                {
                                    materialsWithPrimaryQuantity.Add(materialToValidate.Name);
                                }

                                // Check if the material secondary unit is the configured Reject unit
                                if (!materialToValidate.SecondaryUnits.CompareStrings(rejectUnit))
                                {
                                    materialsWithoutRejectUnits.Add(materialToValidate.Name);
                                }

                                // Check if the material has any CustomMaterialLoss relation
                                if (!materialToValidate.RelationCollection.ContainsKey(IKEAConstants.CustomMaterialLoss))
                                {
                                    materialsWrongSecondaryQuantity.Add(materialToValidate.Name);
                                }
                                else
                                {
                                    // Get the sum of all CustomMaterialLoss quantities of the material
                                    decimal rejectedQuantities = materialToValidate.RelationCollection[IKEAConstants.CustomMaterialLoss].Select(ml => ml as ICustomMaterialLoss).Sum(ml => ml.PrimaryQuantity.GetValueOrDefault());

                                    // Check if the Secondary Quantity is different from the sum of all material losses
                                    if (materialToValidate.SecondaryQuantity != rejectedQuantities)
                                    {
                                        materialsWrongSecondaryQuantity.Add(materialToValidate.Name);
                                    }
                                }
                            }
                        }

                        // Check if there are any materials with form different than completed form
                        if (!materialsWrongForm.IsNullOrEmpty())
                        {
                            errorMessage.AppendLine(ikeaUtillties.GetLocalizedMessage(IKEAConstants.ScrapRoomMaterialWrongFormLocalizedMessage,  scrapRoomType, string.Join(",", materialsWrongForm)));
                        }

                        // Check if there are any materials with the wrong type to be reported
                        if (!materialsWrongType.IsNullOrEmpty())
                        {
                            errorMessage.AppendLine(ikeaUtillties.GetLocalizedMessage(IKEAConstants.ScrapRoomMaterialWrongTypeLocalizedMessage, scrapMaterialType, scrapRoomType, string.Join(",", materialsWrongType)));
                        }

                        // Check if there are any materials with primary quantity to be reported
                        if (!materialsWithPrimaryQuantity.IsNullOrEmpty())
                        {
                            errorMessage.AppendLine(ikeaUtillties.GetLocalizedMessage(IKEAConstants.ScrapRoomMaterialWrongPrimaryQuantityLocalizedMessage, scrapRoomType, string.Join(",", materialsWithPrimaryQuantity)));
                        }

                        // Check if there are any materials without reject units to be reported
                        if (!materialsWithoutRejectUnits.IsNullOrEmpty())
                        {
                            errorMessage.AppendLine(ikeaUtillties.GetLocalizedMessage(IKEAConstants.ScrapRoomMaterialWrongSecondaryUnitLocalizedMessage, rejectUnit, scrapRoomType, string.Join(",", materialsWithoutRejectUnits)));
                        }

                        // Check if there are any materials with wrong secondary quantity to be reported
                        if (!materialsWrongSecondaryQuantity.IsNullOrEmpty())
                        {
                            errorMessage.AppendLine(ikeaUtillties.GetLocalizedMessage(IKEAConstants.ScrapRoomMaterialWrongSecondaryQuantityLocalizedMessage, scrapRoomType, string.Join(",", materialsWrongSecondaryQuantity)));
                        }

                        // Check if there are any errors to report
                        if (errorMessage.Length > 0)
                        {
                            throw new CmfBaseException(errorMessage.ToString());
                        }

                    }
                }
                // On Post of the events any material that enters the Scrap Room will be terminated
                else
                {
                    IMaterialCollection materialsToTerminate = entityFactory.CreateCollection<IMaterialCollection>();
                    // Get the configured Scrap Loss Reason
                    string scrapReason = genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.MaterialLossReasonScrap);

                    // Check if there are any Scrap Loss Reason configured
                    if (!string.IsNullOrWhiteSpace(scrapReason))
                    {
                        ComplexMoveMaterialsToNextStepOutput materialsToNextStepOutput = IKEADEEActionUtilities.GetInputItem<ComplexMoveMaterialsToNextStepOutput>(Input, "ComplexMoveMaterialsToNextStepOutput");
                        ChangeMaterialFlowAndStepOutput materialFlowAndStepOutput = IKEADEEActionUtilities.GetInputItem<ChangeMaterialFlowAndStepOutput>(Input, "ChangeMaterialFlowAndStepOutput");
                        MoveMaterialToStepOutput moveMaterialToStepOutput = IKEADEEActionUtilities.GetInputItem<MoveMaterialToStepOutput>(Input, "MoveMaterialToStepOutput");

                        // Get materials that will go into Scrap Room from MaterialsToNextStep
                        if (materialsToNextStepOutput != null)
                        {
                            if (!materialsToNextStepOutput.Materials.IsNullOrEmpty())
                            {
                                materialsToTerminate.AddRange(materialsToNextStepOutput.Materials.Where(m => m.Step.Type == scrapRoomType));
                            }
                        }
                        // Get materials that will go into Scrap Room from ChangeMaterialFlowAndStep
                        else if (materialFlowAndStepOutput != null && materialFlowAndStepOutput.Material.Step.Type == scrapRoomType)
                        {
                            materialsToTerminate.Add(materialFlowAndStepOutput.Material);
                        }
                        // Get materials that will go into Scrap Room from MoveMaterialToStep
                        else if (moveMaterialToStepOutput != null && moveMaterialToStepOutput.Material.Step.Type == scrapRoomType)
                        {
                            materialsToTerminate.Add(moveMaterialToStepOutput.Material);
                        }

                        // Check if there are any materials to terminate
                        if (!materialsToTerminate.IsNullOrEmpty())
                        {
                            materialsToTerminate.LoadRelations(IKEAConstants.CustomMaterialLoss);
                            ICustomMaterialLossCollection materialLosses = entityFactory.CreateCollection<ICustomMaterialLossCollection>();
                            materialLosses.AddRange(materialsToTerminate.SelectMany(m => m.RelationCollection[IKEAConstants.CustomMaterialLoss].Select(ml => ml as ICustomMaterialLoss)));

                            IReasonCollection reasons = entityFactory.CreateCollection<IReasonCollection>();
                            reasons.LoadByIDs<IReason, Reason>(materialsToTerminate.SelectMany(m => m.RelationCollection[IKEAConstants.CustomMaterialLoss].Select(ml => ml.GetNativeValue<long>("TargetEntity"))).ToList());

                            // Report all the losses for all the materials
                            foreach (var materialLoss in materialLosses.GroupBy(x => new { SourceEntity = x.GetNativeValue<long>("SourceEntity"), TargetEntity = x.GetNativeValue<long>("TargetEntity") }))
                            {
                                string materialName = materialsToTerminate.First(m => m.Id == materialLoss.Key.SourceEntity).Name;
                                IReason reasonLoss = reasons.First(r => r.Id == materialLoss.Key.TargetEntity);
                                decimal lossQuantitySum = materialLoss.ToList().Sum(x => x.PrimaryQuantity.GetValueOrDefault());
                                ikeaUtillties.ReportMaterialScrapLoss(reasonLoss, materialName, lossQuantitySum);
                            }

                            IReason reason = entityFactory.Create<IReason>();

                            reason.Name = scrapReason;


                            if (reason.ObjectExists())
                            {
                                reason.Load();
                                materialsToTerminate.Terminate(reason);
                            }
                            else
                            {
                                throw new CmfBaseException(ikeaUtillties.GetLocalizedMessage(IKEAConstants.ScrapRoomScrapLossDoesNotExistLocalizedMessage, scrapReason));
                            }
                        }
                    }
                    else
                    {
                        throw new CmfBaseException(ikeaUtillties.GetLocalizedMessage(IKEAConstants.ScrapRoomNoScrapLossConfiguredLocalizedMessage, scrapReason));
                    }
                }
            }

            //---End DEE Code---

            return Input;
        }
    }
}
