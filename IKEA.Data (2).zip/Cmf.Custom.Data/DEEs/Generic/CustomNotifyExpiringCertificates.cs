﻿using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;

namespace Cmf.Custom.IKEA.Actions.Generic
{
    /// <summary>
    /// Notify when a certification is about to expire
    /// </summary>
    public class CustomNotifyExpiringCertificates : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---
            return true;
            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
			UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();

            IGenericUtilities _genericUtilities = serviceProvider.GetService<IGenericUtilities>();

            Dictionary<string, object> output = new Dictionary<string, object>();

            // Get Config to validate if it is supose to notify employees about certification expiration
            bool enable = _genericUtilities.GetConfigurationValueByPath<bool>(IKEAConstants.CertificationExpirationNotificationEnable);
            if (enable)
            {
                // Get Config with the number of day from when is to notify
                int threshold = _genericUtilities.GetConfigurationValueByPath<int>(IKEAConstants.CertificationExpirationNotification);

                ikeaUtilities.NotifyAbouCertificationsAlmostExpired(threshold);


                output.Add("Result", "Success");
            }
            else
            {
                output.Add("Result", "Feature disable");
            }

            return output;
            //---End DEE Code---

        }

    }
}
