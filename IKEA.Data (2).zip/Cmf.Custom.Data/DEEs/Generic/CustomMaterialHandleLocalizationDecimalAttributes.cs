﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Actions.Generic
{
    /// <summary>
    /// This DEE converts to string any decimal typed attribute values prior to save to ensure compatibility with polish language
    /// </summary>
    public class CustomMaterialHandleLocalizationDecimalAttributes : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Handles decimal attribute values to ensure correct parsing in certain cultures
            /// Action Groups:
            ///     BusinessObjects.MaterialCollection.SaveAttributes.Pre
            ///     BusinessObjects.MaterialCollection.SaveAttributes.Post
            ///     BusinessObjects.Material.SaveAttributes.Pre
            ///     BusinessObjects.Material.SaveAttributes.Post
            ///     
            /// </summary>
            #endregion


            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.MaterialCollection.SaveAttributes.Pre"
                , "BusinessObjects.MaterialCollection.SaveAttributes.Post"
                , "BusinessObjects.Material.SaveAttributes.Pre"
                , "BusinessObjects.Material.SaveAttributes.Post"
            };

            // only proceed if within expected triggers (action groups) and for eligible cultures
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups) 
                                    && 
                                    (
                                        String.Equals(System.Threading.Thread.CurrentThread.CurrentCulture.Name, "pl-PL", StringComparison.InvariantCultureIgnoreCase)
                                        ||
                                        String.Equals(System.Threading.Thread.CurrentThread.CurrentCulture.Name, "pt-PT", StringComparison.InvariantCultureIgnoreCase)
                                    );

            // FORCE DISABLE this DEE. Always return false so that it never runs.
            return false; // executionVeridict

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
            // CORE
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "");
            UseReference("", "Cmf.Foundation.Common.Exceptions");
            UseReference("", "Cmf.Foundation.Common");

            // MES
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            // COMMON
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            // CUSTOM
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Extensions");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();


            DeeContext currentContext = deeContextUtilities.SetCurrentServiceContext("CustomMaterialHandleLocalizationDecimalAttributes");

            // get action group
            string actionGroup = IKEADEEActionUtilities.GetActionGroup(Input);

            // at pre we check for attributes that need to be converted and store their original values for later restoring
            if (currentContext.TriggerPoint == DeeTriggerPoint.Pre)
            {
                // Stores attributes that were manipulated
                Dictionary<string, object> manipulatedAttributes = new Dictionary<string, object>();

                IAttributeCollection inputAttributes = IKEADEEActionUtilities.GetInputItem<IAttributeCollection>(Input, "Attributes");


                IEntityType etMaterial = null;
                IMaterial materialToUseAsBase = null;

                if (String.Equals(actionGroup, "BusinessObjects.MaterialCollection.SaveAttributes.Pre", StringComparison.InvariantCultureIgnoreCase))
                {
                    IMaterialCollection incomingMaterials = IKEADEEActionUtilities.GetInputItem<IMaterialCollection>(Input, "MaterialCollection");
                    if (incomingMaterials != null && incomingMaterials.Count > 0)
                    {
                        materialToUseAsBase = incomingMaterials[0];
                    }

                }
                else if (String.Equals(actionGroup, "BusinessObjects.Material.SaveAttributes.Pre", StringComparison.InvariantCultureIgnoreCase))
                {
                    materialToUseAsBase = IKEADEEActionUtilities.GetInputItem<IMaterial>(Input, "Material");
                }

                if (materialToUseAsBase != null)
                {
                    etMaterial = materialToUseAsBase.EntityType;
                }

                if (etMaterial != null && inputAttributes != null && inputAttributes.Count > 0)
                {
                    IScalarType stDecimal = new ScalarType();
                    stDecimal.Load("Decimal");

                    etMaterial.LoadAllProperties();
                    Dictionary<string, bool> propertyIsDecimalDictionary = etMaterial.Properties.Where(E => E.PropertyType == EntityTypePropertyType.Attribute).ToDictionary(E => E.Name, E => E.ScalarType.Id == stDecimal.Id);

                    Collection<string> incommingAttributeNames = new Collection<string>(inputAttributes.Keys.ToList());
                    foreach (string varAttributeEntryKey in incommingAttributeNames)
                    {
                        if (propertyIsDecimalDictionary.ContainsKey(varAttributeEntryKey) && propertyIsDecimalDictionary[varAttributeEntryKey] && inputAttributes[varAttributeEntryKey] != null)
                        {
                            manipulatedAttributes.Add(varAttributeEntryKey, inputAttributes[varAttributeEntryKey]);
                            inputAttributes[varAttributeEntryKey] = inputAttributes[varAttributeEntryKey].ToString();
                        }
                    }
                }

                deeContextUtilities.SetContextParameter("CustomMaterialHandleLocalizationDecimalAttributesManipulatedAttributes", manipulatedAttributes);
            }
            else
            {

                // at post we check for attributes that need to be restored to their original format
                Dictionary<string, object> manipulatedAttributes = deeContextUtilities.GetContextParameter("CustomMaterialHandleLocalizationDecimalAttributesManipulatedAttributes") as Dictionary<string, object>;
                if (manipulatedAttributes != null && manipulatedAttributes.Count > 0)
                {
                    IMaterialCollection materialsToSet = entityFactory.CreateCollection<IMaterialCollection>();

                    if (String.Equals(actionGroup, "BusinessObjects.MaterialCollection.SaveAttributes.Post", StringComparison.InvariantCultureIgnoreCase))
                    {
                        IMaterialCollection incomingMaterials = IKEADEEActionUtilities.GetInputItem<IMaterialCollection>(Input, "MaterialCollection");
                        if (incomingMaterials != null && incomingMaterials.Count > 0)
                        {
                            materialsToSet.AddRange(incomingMaterials);
                        }

                    }
                    else if (String.Equals(actionGroup, "BusinessObjects.Material.SaveAttributes.Post", StringComparison.InvariantCultureIgnoreCase))
                    {
                        IMaterial incomingMaterial = IKEADEEActionUtilities.GetInputItem<IMaterial>(Input, "Material");
                        if (incomingMaterial != null)
                        {
                            materialsToSet.Add(incomingMaterial);
                        }
                    }

                    // go through each material and attribute and restore original value
                    foreach (IMaterial material in materialsToSet)
                    {
                        foreach (KeyValuePair<string, object> kvpAttributeToRestore in manipulatedAttributes)
                        {
                            material.Attributes[kvpAttributeToRestore.Key] = kvpAttributeToRestore.Value;
                        }
                    }
                }
            }

            //---End DEE Code---

            return Input;
        }



    }
}
