﻿using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Threading;

namespace Cmf.Custom.IKEA.Actions.SPC
{
    public class Custom1WE1SpcViolationRule : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     
            /// Action Groups:
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion

            return true;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            //System
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.IO");
            UseReference("", "System.Threading");
            UseReference("", "System");

            //Foundation
            UseReference("Cmf.Foundation.Common.dll", "Cmf.Foundation.Common");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];

            ILocalizedMessage localizedMessage = serviceProvider.GetService<ILocalizedMessage>();


            Dictionary<String, Object> Output = new Dictionary<String, Object>();

            String ChartDataPointKey = "ChartDataPoint";
            IChartDataPoint chartDataPoint = Input[ChartDataPointKey] as IChartDataPoint;

            Boolean isRuleViolated = false;

            List<String> missingProperties = new List<string>();
            if (chartDataPoint == null)
            {
                missingProperties.Add("ChartDataPoint");
            }
            if (chartDataPoint.Value1 == null)
            {
                missingProperties.Add("ChartDataPointValue");
            }

            if (missingProperties.Count > 0)
            {
                throw new CmfBaseException(localizedMessage.LoadLocalizedMessage(Thread.CurrentThread.CurrentCulture.Name, IKEAConstants.CustomWE1SpcViolationRule).MessageText);
            }

            if (
                //1 of 1 points above +3 sigma, if Upper Control Limit 1 is defined
                (chartDataPoint.UpperControlLimit1.HasValue && ((chartDataPoint.Value1 ?? 0) > chartDataPoint.UpperControlLimit1))
                    //1 of 1 points below -3 sigma, if Lower Control Limit 1 is defined
                    ||
                (chartDataPoint.LowerControlLimit1.HasValue && ((chartDataPoint.Value1 ?? 0) < chartDataPoint.LowerControlLimit1))
               )
            {
                isRuleViolated = true;
            }

            Output["Result"] = isRuleViolated;

            return Output;

            //---End DEE Code---

        }
    }
}
