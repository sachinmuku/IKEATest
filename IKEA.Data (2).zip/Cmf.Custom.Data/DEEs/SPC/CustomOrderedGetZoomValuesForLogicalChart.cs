﻿using Cmf.Foundation.Common;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessOrchestration.SpcManagement.OutputObjects;
using System.Collections.Generic;
using System.Linq;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Actions.SPC
{
    public class CustomOrderedGetZoomValuesForLogicalChart : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            /// When viewing a logical chart, data in the zoom slider control is being displayed in the opposite order of occurrence.
            /// This causes the slider to malfunction and not positioning itself correctly based on the display settings... when moving one of the limits, the chart stops displaying data.
            /// With this DEE it is possible, though, to avoid this by injecting a DEE at GetZoomValuesForLogicalChart.Post to prevent this from happening
            /// Action Groups:
            /// SpcManagement.SpcManagementOrchestration.GetZoomValuesForLogicalChart.Post
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion

            return true;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---
            
            //Foundation
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "");
            UseReference("", "Cmf.Foundation.Common.Exceptions");
            UseReference("", "Cmf.Foundation.Common");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.SpcManagement.OutputObjects");

            IZoomValueCollection zoom1 = new ZoomValueCollection();
            IZoomValueCollection zoom2 = new ZoomValueCollection();

            GetZoomValuesForLogicalChartOutput output = Input["GetZoomValuesForLogicalChartOutput"] as GetZoomValuesForLogicalChartOutput;

            if (output.ZoomForValue1 != null)
            {
                zoom1.AddRange(output.ZoomForValue1.OrderBy(E => E.ChartDataPointId));
                output.ZoomForValue1 = zoom1;
            }

            if (output.ZoomForValue2 != null)
            {
                zoom2.AddRange(output.ZoomForValue2.OrderBy(E => E.ChartDataPointId));
                output.ZoomForValue2 = zoom2;
            }

            //---End DEE Code---

            return Input;
        }

    }
}
