﻿using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.Common;
using Cmf.Navigo.BusinessObjects;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Actions.SPC
{
    class CustomKpiGetCpkFromLogicalChart : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {

        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     This Rule is used for KPIs.
            ///     In the input, besides a KPI and a KPIDimension, receives a LogicalChart and gets its statistical CpK.
            /// Action Groups:
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion

            return true;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            UseReference("Cmf.Foundation.Common.dll", "");
            UseReference("%MicrosoftNetPath%\\System.XML.dll", "System.Xml");
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("%MicrosoftNetPath%\\System.Data.dll", "System.Data");

            // Get KPI data
            if (Input == null)
            {
                Input = new Dictionary<string, object>();
            }
            if (!Input.ContainsKey("KPI") || Input["KPI"] == null || !(Input["KPI"] is IKPI))
            {
                throw new ArgumentNullCmfException("KPI");
            }
            IKPI kpi = Input["KPI"] as IKPI;
            if (kpi.Id <= 0)
            {
                throw new MissingMandatoryPropertyCmfException("Id", "KPI");
            }

            // Get KPIDimension data
            if (!Input.ContainsKey("KPIDimension") || Input["KPIDimension"] == null || !(Input["KPIDimension"] is IKPIDimension))
            {
                throw new ArgumentNullCmfException("KPIDimension");
            }
            IKPIDimension kpiDimension = Input["KPIDimension"] as IKPIDimension;
            if (kpiDimension.Id <= 0)
            {
                throw new MissingMandatoryPropertyCmfException("Id", "KPIDimension");
            }

            Dictionary<string, object> Output = new Dictionary<string, object>();

            Collection<IEntity> objects = null;
            if (Input.ContainsKey("Objects") && Input["Objects"] != null && Input["Objects"] is Collection<IEntity>)
            {
                objects = Input["Objects"] as Collection<IEntity>;

                if (objects.Count > 0 && objects[0] is ILogicalChart)
                {
                    ILogicalChart logicalChart = objects[0] as ILogicalChart;

                    logicalChart.LoadChartDataPoints();
                    logicalChart.GetDrawingValues(logicalChart.ChartDataPoints.Count);

                    if (logicalChart.StatisticalIndicators != null)
                    {
                        // initialize DataTable
                        DataTable dataTable = new DataTable("DataTableResult");

                        // add mandatory structure (columns)
                        dataTable.Columns.Add("Category");
                        dataTable.Columns.Add("EntityName");
                        dataTable.Columns.Add("Name");
                        dataTable.Columns.Add("Value");

                        // Add data:
                        if (logicalChart.StatisticalIndicators.Cpk.HasValue)
                        {
                            dataTable.Rows.Add("", "", "", logicalChart.StatisticalIndicators.Cpk.Value);
                        }

                        DataSet dataSet = new DataSet("DataSetResult");
                        dataSet.Tables.Add(dataTable);

                        // create output
                        Output.Add("Result", NgpDataSet.FromDataSet(dataSet));
                    }
                }
            }

            // return output
            return Output;
            
            //---End DEE Code---
        }

    }
}






