﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Foundation.Configuration;
using Cmf.Foundation.Configuration.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.SPC
{
    public class CustomResolveSPCViolationActions : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Based on violation rule and chart coming from input, resolve SPC Actions smart table for configured actions to take, if existing.
            ///     Blocks MO(import code from DEE to deprecate) if defined
            ///     Notifies configured audience if defined(import code from DEE to deprecate) if defined
            ///     Creates maintenance activity if defined(use config for SPC sourced maintenance activities)
            ///         > If MAO already existing do not create, and if SPC Administrators config defined, create notification informing that no MAO was created as it already existed
            /// Action Groups:
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion

            return true;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            //System
            UseReference("", "System");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("%MicrosoftNetPath%\\System.Data.dll", "System.Data");
            UseReference("%MicrosoftNetPath%\\System.XML.dll", "System.Xml");

            //Foundation
            UseReference("Cmf.Foundation.Common.dll", "Cmf.Foundation.Common");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            ISPCViolationHandlingUtilities ispcViolationHandlingUtilities = serviceProvider.GetService<ISPCViolationHandlingUtilities>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();

            Dictionary<string, object> Output = new Dictionary<string, object>();

            if (Input.ContainsKey(IKEAConstants.ChartDataPoint))
            {
                // Prepare data from Input to resolve Smart Table
                IChartDataPoint chartDataPoint = IKEADEEActionUtilities.GetInputItem<IChartDataPoint>(Input, IKEAConstants.ChartDataPoint);
                string ruleName = String.Empty;
                if (Input.ContainsKey(IKEAConstants.RuleName))
                {
                    ruleName = IKEADEEActionUtilities.GetInputItem<string>(Input, IKEAConstants.RuleName);
                }
                List<String> resourceNames = new List<String>();
                if (chartDataPoint.ContextInformation.Any(ET => ET.Name == Constants.Resource))
                {
                    resourceNames.AddRange(chartDataPoint.ContextInformation.Where(ET => ET.Name == Constants.Resource).Select(ET => ET.Value));
                }

                // Resolve Smart Table
                var dataRow = ispcViolationHandlingUtilities.ResolveSmartTableCustomSPCViolationActions(chartDataPoint, ruleName, resourceNames.FirstOrDefault());

                if (dataRow != null && dataRow.Table.Rows.Count > 0)
                {
                    List<String> actionsToPerform = new List<String>();
                    IMaterialCollection materialsToBlock = entityFactory.CreateCollection<IMaterialCollection>();

                    // MES Notify Role And/or Employee if configured
                    if (dataRow.Field<bool>(IKEAConstants.MESNotification)
                        && (!String.IsNullOrWhiteSpace(dataRow.Field<string>(IKEAConstants.Employee)) ||
                            !String.IsNullOrWhiteSpace(dataRow.Field<string>(IKEAConstants.Role))))
                    {
                        actionsToPerform.Add(IKEAConstants.Notify);
                    }

                    // Email Notify 
                    if (dataRow.Field<bool>(IKEAConstants.EmailNotification)
                        && (!String.IsNullOrWhiteSpace(dataRow.Field<string>(IKEAConstants.DistributionList)) ||
                            !String.IsNullOrWhiteSpace(dataRow.Field<string>(IKEAConstants.Role))))
                    {
                        actionsToPerform.Add(IKEAConstants.EmailNotification);
                    }

                    // Notify Checked in employees
                    if (dataRow.Field<bool>(IKEAConstants.NotifyCheckedInEmployees))
                    {
                        actionsToPerform.Add(IKEAConstants.NotifyCheckedInEmployees);
                    }

                    // BlockMO if configured
                    if (dataRow.GetValue<bool>(IKEAConstants.BlockMO))
                    {
                        actionsToPerform.Add(IKEAConstants.Block);
                        if (chartDataPoint.ContextInformation.Any(ET => ET.Name == Constants.Material))
                        {
                            IMaterialCollection contextMaterials = entityFactory.CreateCollection<IMaterialCollection>();
                            contextMaterials.AddRange(chartDataPoint.ContextInformation.Where(ET => ET.Name == Constants.Material).Select(ET => {var m = entityFactory.Create<IMaterial>(); m.Name = ET.Value;return m; }));
                            contextMaterials.Load();
                            //Get source Material
                            materialsToBlock.AddRange(contextMaterials.Select(ET => { var m = entityFactory.Create<IMaterial>(); m.Name = ikeaUtilities.GetPossibleBaseMaterial(ET, false);return m; }));
                        }
                    }

                    // Get Maintenance Activity if configured
                    if (!String.IsNullOrWhiteSpace(dataRow[IKEAConstants.MaintenanceActivity].ToString()))
                    {
                        actionsToPerform.Add(IKEAConstants.MaintenanceActivity);
                    }

                    // Check if both configurations have a not null value
                    IConfig html5Config = Config.GetConfig(Cmf.Foundation.Common.Constants.HTML5GuiPath);

                    string logicalChartLink = String.Empty;
                    if (html5Config.Value != null)
                    {
                        // Get config value
                        string html5GuiAddress = html5Config.GetConfigValue<string>();

                        // build the link
                        logicalChartLink = string.Format("{0}/Entity/LogicalChart/{1}/View/Chart", html5GuiAddress, chartDataPoint.LogicalChart.Id);
                    }

                    ispcViolationHandlingUtilities.HandleSPCViolation(dataRow, actionsToPerform, materialsToBlock, resourceNames, logicalChartLink: logicalChartLink, chartDataPoint);
                }
            }

            //Set the Result output
            Output.Add("Result", true);
            return Output;
            //---End DEE Code---

        }

        
    }
}
