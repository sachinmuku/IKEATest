﻿using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessOrchestration.EntityTypeManagement;
using Cmf.Foundation.BusinessOrchestration.EntityTypeManagement.InputObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessOrchestration.Abstractions;
using Microsoft.Extensions.DependencyInjection;


namespace Cmf.Custom.IKEA.Actions.ProcessRules._2._20._0.Before
{
    class Sprint20UpdateProductAttributes : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            /// Change the number of decimal places in 7 properties of the product to 3 decimal places,
            /// then update the new information to the database.
            /// Action Groups:
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion

            return true;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---
            UseReference("", "Cmf.Foundation.BusinessOrchestration.Abstractions");
UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "");
            UseReference("", "Cmf.Foundation.Common.Exceptions");
            UseReference("", "Cmf.Foundation.Common");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "");
            UseReference("", "Cmf.Foundation.BusinessOrchestration.EntityTypeManagement");
            UseReference("", "Cmf.Foundation.BusinessOrchestration.EntityTypeManagement.InputObjects");
var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
var entityTypeOrchestration = serviceProvider.GetService<IEntityTypeOrchestration>();

            #region Change Product Decimal Places

            var productEntityType = entityTypeOrchestration.GetEntityTypeByName(new GetEntityTypeByNameInput { Name = "Product" }).EntityType;
            productEntityType.Load();
            string[] attributes = {
                "FinishedLength",
                "FinishedWidth",
                "Thickness",
                "UnitLoadFootPrintDepth",
                "UnitLoadFootPrintWidth",
                "UnitLoadStackingCapacity",
                "UnitWeight"
             };

            var productAttributes = new EntityTypePropertyCollection();
            productAttributes.AddRange(productEntityType.Properties.Where(ETP => attributes.Contains(ETP.Name)).Select(ETP => ETP));
            productAttributes.Load();
            foreach (var productAttribute in productAttributes)
            {
                productAttribute.ScalarSize = 3;
                productAttribute.ScalarPrecision = 18;
            }

            #endregion

            #region Update Product

            productEntityType = entityTypeOrchestration.FullUpdateEntityType(new FullUpdateEntityTypeInput()
            {
                EntityType = productEntityType as IEntityType,
                EntityTypePropertiesToAddOrUpdate = productAttributes,
            }).EntityType;

            #endregion

            #region Update DB

            entityTypeOrchestration.GenerateEntityTypeDBSchema(new GenerateEntityTypeDBSchemaInput
            {
                EntityType = productEntityType as IEntityType
            });

            #endregion
            
            //---End DEE Code---
            return Input;
        }
    }
}
