﻿using Cmf.Custom.IKEA.Common;
using Cmf.Foundation.BusinessObjects;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;

namespace Cmf.Custom.IKEA.Actions.ProcessRules._3._51._0.After
{
    public class Sprint51CreateTimerForCheckShiftChange : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Process Rule to create timer to report shift quantities at shift changes
            /// </summary>
            #endregion

            return true;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
            UseReference("", "Cmf.Foundation.Common.Exceptions");
            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];

            // Define new timer
            ICmfTimer shiftChangeTimer = serviceProvider.GetService<ICmfTimer>();
            shiftChangeTimer.Name = "CustomCheckShiftChangeTimer";

            // Define timer recurrence
            shiftChangeTimer.Recurrence = CmfTimerRecurrence.DefinedSeconds;

            // Frequency timer is executed
            shiftChangeTimer.RecurrenceDefinedFrequency = 1;

            // Define timer interval (1hour = 3600 seconds)
            shiftChangeTimer.RecurrenceDefinedSeconds = 3600;

            // Define timer rule
            IRule initialShiftQuantityRule = serviceProvider.GetService<IRule>();
            string ruleName = "CustomShiftChangeReportInitialShiftQuantity";
            initialShiftQuantityRule.Load(ruleName);
            shiftChangeTimer.Rule = initialShiftQuantityRule;

            // Define timer 1st execution - This run's next day
            DateTime now = DateTime.Now;
            DateTime tomorrow = now.AddDays(1).Date;
            shiftChangeTimer.Start = tomorrow;

            // Define timer scope
            shiftChangeTimer.Scope = CmfTimerScope.General;

            // Add Attribute "CustomIsShiftTimer" as true
            shiftChangeTimer.Attributes.Add("CustomIsShiftTimer", true);

            // Define CmfTimer enabled status
            shiftChangeTimer.IsEnabled = true;

            // Create CmfTimer object
            if (!shiftChangeTimer.ObjectExists())
            {
                shiftChangeTimer.Create();
            }
            //---End DEE Code---

            return Input;
        }
    }
}
