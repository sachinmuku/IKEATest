﻿using Cmf.Custom.IKEA.Common;
using Cmf.Foundation.BusinessObjects;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using Cmf.Foundation.BusinessObjects.QueryObject;
using Cmf.Navigo.BusinessObjects.Abstractions;
using System.Collections.ObjectModel;
using System.Data;

namespace Cmf.Custom.IKEA.Actions.ProcessRules._3._51._0.After
{
    public class Sprint51UpdateResourceAttributes : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Process Rule to create timer to report shift quantities at shift changes
            /// </summary>
            #endregion

            return true;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
            // Foundation
            UseReference("Cmf.Foundation.BusinessObjects.dll", "");
            UseReference("", "Cmf.Foundation.BusinessObjects.QueryObject");
            UseReference("", "Cmf.Foundation.Common.Exceptions");

            // Custom
            

            // System
            UseReference("", "System.Data");

            //Please start code here
            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];

            QueryObject query = new QueryObject();
            query.Description = "";
            query.EntityTypeName = "Resource";
            query.Name = "AllMainProductionResources";
            query.Query = new Query();
            query.Query.Distinct = false;
            query.Query.Filters = new FilterCollection() {
                new Cmf.Foundation.BusinessObjects.QueryObject.Filter()
                {
                    Name = "Type",
                    ObjectName = "Resource",
                    ObjectAlias = "Resource_1",
                    Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                    Value = "Production",
                    LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND,
                    FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                },
                new Cmf.Foundation.BusinessObjects.QueryObject.Filter()
                {
                    Name = "ParentResourcesCount",
                    ObjectName = "Resource",
                    ObjectAlias = "Resource_1",
                    Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                    Value = "0",
                    LogicalOperator = Cmf.Foundation.Common.LogicalOperator.Nothing,
                    FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                }
            };
            query.Query.Fields = new FieldCollection() {
                new Field()
                {
                    Alias = "Id",
                    ObjectName = "Resource",
                    ObjectAlias = "Resource_1",
                    IsUserAttribute = false,
                    Name = "Id",
                    Position = 0,
                    Sort = Cmf.Foundation.Common.FieldSort.NoSort
                },
                new Field()
                {
                    Alias = "Name",
                    ObjectName = "Resource",
                    ObjectAlias = "Resource_1",
                    IsUserAttribute = false,
                    Name = "Name",
                    Position = 1,
                    Sort = Cmf.Foundation.Common.FieldSort.Ascending
                },
                new Field()
                {
                    Alias = "Type",
                    ObjectName = "Resource",
                    ObjectAlias = "Resource_1",
                    IsUserAttribute = false,
                    Name = "Type",
                    Position = 2,
                    Sort = Cmf.Foundation.Common.FieldSort.Ascending
                },
                new Field()
                {
                    Alias = "ParentResourcesCount",
                    ObjectName = "Resource",
                    ObjectAlias = "Resource_1",
                    IsUserAttribute = false,
                    Name = "ParentResourcesCount",
                    Position = 3,
                    Sort = Cmf.Foundation.Common.FieldSort.NoSort
                }
            };
            query.Query.Relations = new RelationCollection();

            DataSet dataset = query.Execute(false, new QueryParameterCollection());

            // Exit action if no entity instances were returned
            if (dataset.Tables.Count == 0)
            {
                return Input;
            }

            // Exit action if no entity instances were returned
            if (dataset.Tables[0].Rows.Count == 0)
            {
                return Input;
            }

            // Load all Resources
            IResourceCollection resources = serviceProvider.GetService<IResourceCollection>();

            foreach (DataRow row in dataset.Tables[0].Rows)
            {
                IResource resource = serviceProvider.GetService<IResource>();
                resource.Name = row.Field<string>("Name");
                resources.Add(resource);
            }

            resources.Load();

            // Load attribute "CustomCurrentQuantityUpdateFrequency" for all resources and save it with the default timne
            IAttributeCollection attributes = serviceProvider.GetService<IAttributeCollection>();
            attributes.Add("CustomCurrentQuantityUpdateFrequency", 300000);

            resources.LoadAttributes(new Collection<string>() { "CustomCurrentQuantityUpdateFrequency" });
            resources.SaveAttributes(attributes);
            //---End DEE Code---

            return Input;
        }
    }
}
