﻿using Cmf.Custom.IKEA.Common;
using Cmf.Foundation.BusinessObjects;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using Cmf.Foundation.BusinessObjects.QueryObject;
using Cmf.Navigo.BusinessObjects.Abstractions;
using System.Collections.ObjectModel;
using System.Data;
using Cmf.Common.CustomActionUtilities;
using Cmf.Foundation.BusinessOrchestration.Abstractions;
using Cmf.Foundation.BusinessOrchestration.TableManagement.InputObjects;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Abstractions;

namespace Cmf.Custom.IKEA.Actions.ProcessRules._4._0._0.After
{
    public class CustomScanningConfigurationRestore : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---
            return true;
            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
            UseReference("%MicrosoftNetPath%System.Data.Common.dll", "System.Data");
            UseReference("System.Data.SqlClient.dll", "System.Data.SqlClient");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.Abstractions");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.TableManagement.InputObjects");
            // Common
            // Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");

            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            ITableOrchestration _tableOrchestration = serviceProvider.GetService<ITableOrchestration>();
            string sqlQuery = @"
                                IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES
                                WHERE TABLE_SCHEMA = 'UserDataModel'
                                AND TABLE_NAME = 'T_GT_CustomScanningConfigurationTemp')
                                BEGIN
                                -- Copy data from temp table to generic table
                                SELECT *
                                FROM [UserDataModel].[T_GT_CustomScanningConfigurationTemp]
                                END";
            DataSet dataSet = ikeaUtilities.ExecuteReader(sqlQuery, CommandType.Text);
            if (dataSet.Tables[0].Rows.Count > 0)
            {
                IGenericTable genericTable = entityFactory.Create<IGenericTable>();
                genericTable.Load(IKEAConstants.CustomScanningConfigurationGenericTable);
                genericTable.LoadData();
                DataSet dataSetGT = NgpDataSet.ToDataSet(genericTable.Data);
                foreach (DataRow row in dataSet.Tables[0].Rows)
                {
                    DataRow newRow = dataSetGT.Tables[0].NewRow();
                    newRow[genericTable.Name + "Id"] = -1;
                    newRow["LastServiceHistoryId"] = -1;
                    newRow["LastOperationHistorySeq"] = -1;
                    newRow["ScanningConfiguration"] = row["ScanningConfiguration"] == DBNull.Value ? DBNull.Value : row.Field<string>("ScanningConfiguration");
                    newRow["Format"] = row["Format"] == DBNull.Value ? DBNull.Value : row.Field<int>("Format");
                    newRow["Separator"] = row.Field<string>("Separator");
                    newRow["LeadFiller"] = row.Field<string>("LeadFiller");
                    dataSetGT.Tables[0].Rows.Add(newRow);
                }

                _tableOrchestration.InsertOrUpdateGenericTableRows(new InsertOrUpdateGenericTableRowsInput()
                {
                    GenericTable = genericTable,
                    Table = NgpDataSet.FromDataSet(dataSetGT)
                });
                string dropTable = @"DROP TABLE [UserDataModel].[T_GT_CustomScanningConfigurationTemp]";
                ikeaUtilities.ExecuteReader(dropTable, CommandType.Text);
            }
            else
            {
                string sqldropQuery = @"
                        IF EXISTS(SELECT * FROM INFORMATION_SCHEMA.TABLES
                        WHERE TABLE_SCHEMA = 'UserDataModel'
                        AND TABLE_NAME = 'T_GT_CustomScanningConfigurationTemp')
                        BEGIN
                        -- Drop temp table if table exists without data
                        DROP TABLE [UserDataModel].[T_GT_CustomScanningConfigurationTemp]
                        END";
                DataSet dataSet1 = ikeaUtilities.ExecuteReader(sqldropQuery, CommandType.Text);
            }
            //---End DEE Code---
            return Input;
        }
    }
}
