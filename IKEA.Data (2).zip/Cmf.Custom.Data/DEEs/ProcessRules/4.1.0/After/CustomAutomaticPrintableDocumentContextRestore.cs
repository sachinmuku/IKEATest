﻿using System;
using System.Collections.Generic;
using System.Data;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessOrchestration.Abstractions;
using Cmf.Foundation.BusinessOrchestration.TableManagement.InputObjects;
using Cmf.Foundation.Common.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using Cmf.Common.CustomActionUtilities;

namespace Cmf.Custom.IKEA.Actions.ProcessRules._4._1._0.After
{
    public class CustomAutomaticPrintableDocumentContextRestore : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            UseReference("%MicrosoftNetPath%System.Data.Common.dll", "System.Data");
            UseReference("System.Data.SqlClient.dll", "System.Data.SqlClient");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.Abstractions");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.TableManagement.InputObjects");
            // Common
            // Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");

            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            ITableOrchestration _tableOrchestration = serviceProvider.GetService<ITableOrchestration>();
            string sqlQuery = @"
                                IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES
                                WHERE TABLE_SCHEMA = 'UserDataModel'
                                AND TABLE_NAME = 'T_ST_CustomAutomaticPrintableDocumentContextTemp')
                                BEGIN
                                -- Copy data from temp table to generic table
                                SELECT *
                                FROM [UserDataModel].[T_ST_CustomAutomaticPrintableDocumentContextTemp]
                                END";
            DataSet dataSet = ikeaUtilities.ExecuteReader(sqlQuery, CommandType.Text);
            if (dataSet.HasData())
            {
                if (dataSet.Tables[0].Rows.Count > 0)
                {
                    ISmartTable smartTable = entityFactory.Create<ISmartTable>();
                    smartTable.Load(IKEAConstants.CustomAutomaticPrintableDocumentContext);
                    smartTable.LoadData();
                    DataSet dataSetST = NgpDataSet.ToDataSet(smartTable.Data);
                    foreach (DataRow row in dataSet.Tables[0].Rows)
                    {
                        DataRow newRow = dataSetST.Tables[0].NewRow();
                        newRow[smartTable.Name + "Id"] = -1;
                        newRow["LastServiceHistoryId"] = -1;
                        newRow["LastOperationHistorySeq"] = -1;
                        newRow["Step"] = row["Step"]== DBNull.Value ? DBNull.Value : row.Field<string>("Step");
                        newRow["PrintingSequence"] = row["PrintingSequence"] == DBNull.Value ? DBNull.Value : row.Field<string>("PrintingSequence");
                        newRow["Resource"] = row.Field<string>("Resource");
                        newRow["ProductGroup"] = row.Field<string>("ProductGroup");
                        newRow["Product"] = row.Field<string>("Product");
                        newRow["MaterialType"] = row.Field<string>("MaterialType");
                        newRow["PrintableDocument"] = row["PrintableDocument"] == DBNull.Value ? DBNull.Value : row.Field<string>("PrintableDocument");
                        newRow["Printer"] = row["Printer"] == DBNull.Value ? DBNull.Value : row.Field<string>("Printer");
                        newRow["IsEnabled"] = row.Field<bool>("IsEnabled");
                        newRow["PrintOptions"] = row["PrintOptions"] == DBNull.Value ? DBNull.Value : row.Field<int>("PrintOptions");
                        newRow["PrintSourceSplitMaterial"] = row.Field<bool>("PrintSourceSplitMaterial");
                        //newRow["RowId"] = row["RowId"] == DBNull.Value ? DBNull.Value : row.Field<int>("RowId");
                        //newRow["ChangeSetId"] = row["ChangeSetId"] == DBNull.Value ? DBNull.Value : row.Field<int>("ChangeSetId");
                        //newRow["ChangeSetOperation"] = row.Field<string>("ChangeSetOperation");
                        //newRow["ProductGroup_Revision"] = row.Field<string>("ProductGroup_Revision");
                        //newRow["Product_Revision"] = row.Field<string>("Product_Revision");
                        //newRow["ResourceToAttach"] = row.Field<string>("ResourceToAttach");
                        dataSetST.Tables[0].Rows.Add(newRow);
                    }

                    _tableOrchestration.InsertOrUpdateSmartTableRows(new InsertOrUpdateSmartTableRowsInput()
                    {
                        SmartTable = smartTable,
                        Table = NgpDataSet.FromDataSet(dataSetST)
                    });
                    string dropTable = @"DROP TABLE [UserDataModel].[T_ST_CustomAutomaticPrintableDocumentContextTemp]";
                    ikeaUtilities.ExecuteReader(dropTable, CommandType.Text);
                }
                else
                {
                    string sqldropQuery = @"
                        IF EXISTS(SELECT * FROM INFORMATION_SCHEMA.TABLES
                        WHERE TABLE_SCHEMA = 'UserDataModel'
                        AND TABLE_NAME = 'T_ST_CustomAutomaticPrintableDocumentContextTemp')
                        BEGIN
                        -- Drop temp table if table exists without data
                        DROP TABLE [UserDataModel].[T_ST_CustomAutomaticPrintableDocumentContextTemp]
                        END";
                    DataSet dataSet1 = ikeaUtilities.ExecuteReader(sqldropQuery, CommandType.Text);
                }
            }
            //---End DEE Code---
            return Input;
        }

        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---
            return true;
            //---End DEE Condition Code---
        }
    }
}
