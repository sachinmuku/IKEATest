﻿using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Linq;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessOrchestration.EntityTypeManagement;
using Cmf.Foundation.BusinessOrchestration.EntityTypeManagement.InputObjects;
using Cmf.Foundation.Common.Base;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessOrchestration.Abstractions;
using Microsoft.Extensions.DependencyInjection;

namespace Cmf.Custom.IKEA.Actions.ProcessRules.EntityTypes
{
    public class CustomResourceStateReclassification : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            return true;

            //---End DEE Condition Code---
        }

        /// <summary>
        /// DEE Action Condition abstract Method
        /// 
        /// </summary>
        /// <param name="Input"></param>
        /// <returns></returns>
        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
            UseReference("", "Cmf.Foundation.BusinessOrchestration.Abstractions");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "");
            UseReference("", "Cmf.Foundation.BusinessOrchestration.EntityTypeManagement");
            UseReference("", "Cmf.Foundation.BusinessOrchestration.EntityTypeManagement.InputObjects");
            
            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            var entityTypeOrchestration = serviceProvider.GetService<IEntityTypeOrchestration>();

            // name of the entity to be generated...
            string newEntityName = "CustomResourceStateReclassification";

            // only makes sense to proceed if entity type doesn't exist yet...
            IEntityType foundEntity = entityTypeOrchestration.GetAllEntityTypes(new GetAllEntityTypesInput()).EntityTypes.FirstOrDefault(e => String.Equals(e.Name, newEntityName, StringComparison.InvariantCultureIgnoreCase));
            if (foundEntity == null)
            {
                // set new entity type to be created
                foundEntity = new EntityType()
                {
                    Name = newEntityName,
                    Description = "Entity Type to store resource state reclassification",
                    CloneBehavior = CloneBehavior.NoCopy,
                    HistoryRetentionTime = 1,
                    IsHistoryEnabled = true,
                    IsUniqueNameRequired = true,
                    ReplicateToODS = true,
                    AllowAttributes = true,
                    AllowDeleteInstances = true,
                    IsVisible = true,
                    IsCloneable = true,
                    IsRelation = false
                };

                foundEntity = entityTypeOrchestration.CreateEntityType(new CreateEntityTypeInput() { EntityType = foundEntity as IEntityType }).EntityType;
            }

            // if entity is still in Created state, check if all necessary properties are already added...
            if (foundEntity.UniversalState == UniversalState.Created)
            {
                #region Set Properties

                IScalarType bigIntScalarType = new ScalarType();
                bigIntScalarType.Load("BigInt");
                IScalarType nvarcharScalarType = new ScalarType();
                nvarcharScalarType.Load("NVarChar");

                // set properties to be added
                IEntityTypePropertyCollection propertiesToAdd = new EntityTypePropertyCollection();

                #region ServiceHistoryIdStart

                if (!foundEntity.Properties.Any(e => String.Equals(e.Name, "ServiceHistoryIdStart", StringComparison.InvariantCultureIgnoreCase)))
                {
                    IEntityTypeProperty serviceHistoryIdStartProp = new EntityTypeProperty()
                    {
                        Name = "ServiceHistoryIdStart",
                        PropertyType = EntityTypePropertyType.Property,
                        Description = "ServiceHistoryId Start",
                        ReferenceType = Cmf.Foundation.Common.ReferenceType.None,
                        ReferencedObjectId = 0,
                        ScalarType = bigIntScalarType,
                        IsEnabled = true,
                        IsIndexed = true,
                        IsMandatory = true,
                        IsHistoryEnable = true,
                        LoadToDWH = true
                    };

                    // add property to list of properties to add...
                    propertiesToAdd.Add(serviceHistoryIdStartProp);
                }
                #endregion

                #region ServiceHistoryIdEnd

                if (!foundEntity.Properties.Any(e => String.Equals(e.Name, "ServiceHistoryIdEnd", StringComparison.InvariantCultureIgnoreCase)))
                {
                    IEntityTypeProperty serviceHistoryIdEndProp = new EntityTypeProperty()
                    {
                        Name = "ServiceHistoryIdEnd",
                        PropertyType = EntityTypePropertyType.Property,
                        Description = "ServiceHistoryId End",
                        ReferenceType = Cmf.Foundation.Common.ReferenceType.None,
                        ReferencedObjectId = 0,
                        ScalarType = bigIntScalarType,
                        IsEnabled = true,
                        IsIndexed = true,
                        IsMandatory = true,
                        IsHistoryEnable = true,
                        LoadToDWH = true
                    };

                    // add property to list of properties to add...
                    propertiesToAdd.Add(serviceHistoryIdEndProp);
                }

                #endregion

                #region OperationHistorySequenceStart

                if (!foundEntity.Properties.Any(e => String.Equals(e.Name, "OperationHistorySequenceStart", StringComparison.InvariantCultureIgnoreCase)))
                {
                    IEntityTypeProperty operationHistorySequenceStart = new EntityTypeProperty()
                    {
                        Name = "OperationHistorySequenceStart",
                        PropertyType = EntityTypePropertyType.Property,
                        Description = "OperationHistorySequence Start",
                        ReferenceType = Cmf.Foundation.Common.ReferenceType.None,
                        ReferencedObjectId = 0,
                        ScalarType = bigIntScalarType,
                        IsEnabled = true,
                        IsIndexed = true,
                        IsMandatory = true,
                        IsHistoryEnable = true,
                        LoadToDWH = true
                    };

                    // add property to list of properties to add...
                    propertiesToAdd.Add(operationHistorySequenceStart);
                }

                #endregion

                #region OperationHistorySequenceEnd

                if (!foundEntity.Properties.Any(e => String.Equals(e.Name, "OperationHistorySequenceEnd", StringComparison.InvariantCultureIgnoreCase)))
                {
                    IEntityTypeProperty operationHistorySequenceEndProp = new EntityTypeProperty()
                    {
                        Name = "OperationHistorySequenceEnd",
                        PropertyType = EntityTypePropertyType.Property,
                        Description = "OperationHistorySequence End",
                        ReferenceType = Cmf.Foundation.Common.ReferenceType.None,
                        ReferencedObjectId = 0,
                        ScalarType = bigIntScalarType,
                        IsEnabled = true,
                        IsIndexed = true,
                        IsMandatory = true,
                        IsHistoryEnable = true,
                        LoadToDWH = true
                    };

                    // add property to list of properties to add...
                    propertiesToAdd.Add(operationHistorySequenceEndProp);
                }

                #endregion

                #region Resource

                if (!foundEntity.Properties.Any(e => String.Equals(e.Name, "ResourceId", StringComparison.InvariantCultureIgnoreCase)))
                {
                    IEntityTypeProperty resourceProp = new EntityTypeProperty()
                    {
                        Name = "ResourceId",
                        PropertyType = EntityTypePropertyType.Property,
                        Description = "Resource Id",
                        ReferenceType = Cmf.Foundation.Common.ReferenceType.None,
                        ReferencedObjectId = 0,
                        ScalarType = bigIntScalarType,
                        IsEnabled = true,
                        IsIndexed = true,
                        IsMandatory = true,
                        IsHistoryEnable = true,
                        LoadToDWH = true
                    };

                    // add property to list of properties to add...
                    propertiesToAdd.Add(resourceProp);
                }

                #endregion

                #region StateModel

                if (!foundEntity.Properties.Any(e => String.Equals(e.Name, "StateModelId", StringComparison.InvariantCultureIgnoreCase)))
                {
                    IEntityTypeProperty stateModelProp = new EntityTypeProperty()
                    {
                        Name = "StateModelId",
                        PropertyType = EntityTypePropertyType.Property,
                        Description = "State Model ID",
                        ReferenceType = Cmf.Foundation.Common.ReferenceType.None,
                        ReferencedObjectId = 0,
                        ScalarType = bigIntScalarType,
                        IsEnabled = true,
                        IsIndexed = true,
                        IsMandatory = true,
                        IsHistoryEnable = true,
                        LoadToDWH = true
                    };

                    // add property to list of properties to add...
                    propertiesToAdd.Add(stateModelProp);
                }

                #endregion

                #region StateModelState

                if (!foundEntity.Properties.Any(e => String.Equals(e.Name, "StateModelStateId", StringComparison.InvariantCultureIgnoreCase)))
                {
                    IEntityTypeProperty stateModelStateProp = new EntityTypeProperty()
                    {
                        Name = "StateModelStateId",
                        PropertyType = EntityTypePropertyType.Property,
                        Description = "State Model State ID",
                        ReferenceType = Cmf.Foundation.Common.ReferenceType.None,
                        ReferencedObjectId = 0,
                        ScalarType = bigIntScalarType,
                        IsEnabled = true,
                        IsIndexed = true,
                        IsMandatory = true,
                        IsHistoryEnable = true,
                        LoadToDWH = true
                    };

                    // add property to list of properties to add...
                    propertiesToAdd.Add(stateModelStateProp);
                }

                #endregion

                #region StateModelStateReason

                if (!foundEntity.Properties.Any(e => String.Equals(e.Name, "StateModelStateReason", StringComparison.InvariantCultureIgnoreCase)))
                {
                    IEntityTypeProperty stateModelStateReasonProp = new EntityTypeProperty()
                    {
                        Name = "StateModelStateReason",
                        PropertyType = EntityTypePropertyType.Property,
                        Description = "State Model State Reason",
                        ReferenceType = Cmf.Foundation.Common.ReferenceType.None,
                        ReferencedObjectId = 0,
                        ScalarType = nvarcharScalarType,
                        IsEnabled = true,
                        IsIndexed = true,
                        IsMandatory = true,
                        IsHistoryEnable = true,
                        LoadToDWH = true
                    };

                    // add property to list of properties to add...
                    propertiesToAdd.Add(stateModelStateReasonProp);
                }

                #endregion

                if (propertiesToAdd.Count > 0)
                {
                    foundEntity = entityTypeOrchestration.AddEntityTypeProperties(new AddEntityTypePropertiesInput()
                    {
                        EntityType = foundEntity as IEntityType,
                        EntityTypeProperties = propertiesToAdd
                    }).EntityType;
                } 
                #endregion

                #region Generate Schema

                entityTypeOrchestration.GenerateEntityTypeDBSchema(new GenerateEntityTypeDBSchemaInput
                {
                    EntityType = foundEntity as IEntityType
                });

                #endregion
            }

            //---End DEE Code---

            return Input;
        }
    }
}