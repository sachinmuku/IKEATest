﻿using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Linq;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessOrchestration.EntityTypeManagement;
using Cmf.Foundation.BusinessOrchestration.EntityTypeManagement.InputObjects;
using Cmf.Foundation.Common.Base;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessOrchestration.Abstractions;
using Microsoft.Extensions.DependencyInjection;

namespace Cmf.Custom.IKEA.Actions.ProcessRules.EntityTypes
{
    public class CustomAlarmOccurrence : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            return true;

            //---End DEE Condition Code---
        }

        /// <summary>
        /// DEE Action Condition abstract Method
        /// 
        /// </summary>
        /// <param name="Input"></param>
        /// <returns></returns>
        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
            UseReference("", "Cmf.Foundation.BusinessOrchestration.Abstractions");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "");
            UseReference("", "Cmf.Foundation.BusinessOrchestration.EntityTypeManagement");
            UseReference("", "Cmf.Foundation.BusinessOrchestration.EntityTypeManagement.InputObjects");

            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            var entityTypeOrchestration = serviceProvider.GetService<IEntityTypeOrchestration>();

            // name of the entity to be generated...
            string newEntityName = "CustomAlarmOccurrence";

            // only makes sense to proceed if entity type doesn't exist yet...
            IEntityType foundEntity = entityTypeOrchestration.GetAllEntityTypes(new GetAllEntityTypesInput()).EntityTypes.FirstOrDefault(e => String.Equals(e.Name, newEntityName, StringComparison.InvariantCultureIgnoreCase));
            if (foundEntity == null)
            {
                // set new entity type to be created
                foundEntity = new EntityType()
                {
                    Name = newEntityName,
                    Description = "Entity Type to store all alarm occurrences",
                    CloneBehavior = CloneBehavior.NoCopy,
                    HistoryRetentionTime = 1,
                    IsHistoryEnabled = true,
                    IsUniqueNameRequired = true,
                    ReplicateToODS = true,
                    AllowAttributes = true,
                    AllowDeleteInstances = true,
                    IsVisible = true,
                    IsCloneable = true,
                    IsRelation = false
                };

                foundEntity = entityTypeOrchestration.CreateEntityType(new CreateEntityTypeInput() { EntityType = foundEntity as IEntityType}).EntityType;
            }

            // if entity is still in Created state, check if all necessary properties are already added...
            if (foundEntity.UniversalState == UniversalState.Created)
            {
                long facilityEntityTypeId = entityTypeOrchestration.GetEntityTypeByName(new GetEntityTypeByNameInput { Name = "Facility" }).EntityType.Id;
                long areaEntityTypeId = entityTypeOrchestration.GetEntityTypeByName(new GetEntityTypeByNameInput { Name = "Area" }).EntityType.Id;
                long resourceEntityTypeId = entityTypeOrchestration.GetEntityTypeByName(new GetEntityTypeByNameInput { Name = "Resource" }).EntityType.Id;
                long materialEntityTypeId = entityTypeOrchestration.GetEntityTypeByName(new GetEntityTypeByNameInput { Name = "Material" }).EntityType.Id;

                #region Set Properties

                IScalarType nvarcharScalarType = new ScalarType();
                nvarcharScalarType.Load("NVarChar");
                IScalarType decimalScalarType = new ScalarType();
                decimalScalarType.Load("Decimal");
                IScalarType bigIntScalarType = new ScalarType();
                bigIntScalarType.Load("BigInt");
                IScalarType datetimeScalarType = new ScalarType();
                datetimeScalarType.Load("DateTime");

                // set properties to be added
                IEntityTypePropertyCollection propertiesToAdd = new EntityTypePropertyCollection();

                #region AlarmCode

                if (!foundEntity.Properties.Any(e => String.Equals(e.Name, "AlarmCode", StringComparison.InvariantCultureIgnoreCase)))
                {
                    IEntityTypeProperty alarmCodeProp = new EntityTypeProperty()
                    {
                        Name = "AlarmCode",
                        PropertyType = EntityTypePropertyType.Property,
                        Description = "Alarm Code",
                        ReferenceType = Cmf.Foundation.Common.ReferenceType.None,
                        ReferencedObjectId = 0,
                        ScalarType = nvarcharScalarType,
                        IsEnabled = true,
                        IsIndexed = true,
                        IsMandatory = true,
                        IsHistoryEnable = true,
                        LoadToDWH = false
                    };

                    // add property to list of properties to add...
                    propertiesToAdd.Add(alarmCodeProp);
                }

                #endregion

                #region AlarmCategory

                if (!foundEntity.Properties.Any(e => String.Equals(e.Name, "AlarmCategory", StringComparison.InvariantCultureIgnoreCase)))
                {
                    IEntityTypeProperty alarmCategoryProp = new EntityTypeProperty()
                    {
                        Name = "AlarmCategory",
                        PropertyType = EntityTypePropertyType.Property,
                        Description = "Alarm Category",
                        ReferenceType = Cmf.Foundation.Common.ReferenceType.None,
                        ReferencedObjectId = 0,
                        ScalarType = nvarcharScalarType,
                        IsEnabled = true,
                        IsIndexed = true,
                        IsMandatory = true,
                        IsHistoryEnable = true,
                        LoadToDWH = false
                    };

                    // add property to list of properties to add...
                    propertiesToAdd.Add(alarmCategoryProp);
                }

                #endregion

                #region AlarmType

                if (!foundEntity.Properties.Any(e => String.Equals(e.Name, "AlarmType", StringComparison.InvariantCultureIgnoreCase)))
                {
                    IEntityTypeProperty alarmTypeProp = new EntityTypeProperty()
                    {
                        Name = "AlarmType",
                        PropertyType = EntityTypePropertyType.Property,
                        Description = "Alarm Type",
                        ReferenceType = Cmf.Foundation.Common.ReferenceType.None,
                        ReferencedObjectId = 0,
                        ScalarType = nvarcharScalarType,
                        IsEnabled = true,
                        IsIndexed = true,
                        IsMandatory = true,
                        IsHistoryEnable = true,
                        LoadToDWH = false
                    };

                    // add property to list of properties to add...
                    propertiesToAdd.Add(alarmTypeProp);
                }

                #endregion

                #region AlarmSeverity

                if (!foundEntity.Properties.Any(e => String.Equals(e.Name, "AlarmSeverity", StringComparison.InvariantCultureIgnoreCase)))
                {
                    IEntityTypeProperty alarmSeverityProp = new EntityTypeProperty()
                    {
                        Name = "AlarmSeverity",
                        PropertyType = EntityTypePropertyType.Property,
                        Description = "Alarm Severity",
                        ReferenceType = Cmf.Foundation.Common.ReferenceType.None,
                        ReferencedObjectId = 0,
                        ScalarType = nvarcharScalarType,
                        IsEnabled = true,
                        IsIndexed = true,
                        IsMandatory = true,
                        IsHistoryEnable = true,
                        LoadToDWH = false
                    };

                    // add property to list of properties to add...
                    propertiesToAdd.Add(alarmSeverityProp);
                }

                #endregion

                #region AlarmMessage

                if (!foundEntity.Properties.Any(e => String.Equals(e.Name, "AlarmMessage", StringComparison.InvariantCultureIgnoreCase)))
                {
                    IEntityTypeProperty alarmMessageProp = new EntityTypeProperty()
                    {
                        Name = "AlarmMessage",
                        PropertyType = EntityTypePropertyType.Property,
                        Description = "Alarm Message",
                        ReferenceType = Cmf.Foundation.Common.ReferenceType.None,
                        ReferencedObjectId = 0,
                        ScalarType = nvarcharScalarType,
                        IsEnabled = true,
                        IsIndexed = true,
                        IsMandatory = false,
                        IsHistoryEnable = true,
                        LoadToDWH = false
                    };

                    // add property to list of properties to add...
                    propertiesToAdd.Add(alarmMessageProp);
                }

                #endregion

                #region AlarmStart

                if (!foundEntity.Properties.Any(e => String.Equals(e.Name, "AlarmStart", StringComparison.InvariantCultureIgnoreCase)))
                {
                    IEntityTypeProperty alarmStartProp = new EntityTypeProperty()
                    {
                        Name = "AlarmStart",
                        PropertyType = EntityTypePropertyType.Property,
                        Description = "Alarm Start",
                        ReferenceType = Cmf.Foundation.Common.ReferenceType.None,
                        ReferencedObjectId = 0,
                        ScalarType = datetimeScalarType,
                        IsEnabled = true,
                        IsIndexed = true,
                        IsMandatory = true,
                        IsHistoryEnable = true,
                        LoadToDWH = false
                    };

                    // add property to list of properties to add...
                    propertiesToAdd.Add(alarmStartProp);
                }

                #endregion

                #region AlarmEnd

                if (!foundEntity.Properties.Any(e => String.Equals(e.Name, "AlarmEnd", StringComparison.InvariantCultureIgnoreCase)))
                {
                    IEntityTypeProperty alarmEndProp = new EntityTypeProperty()
                    {
                        Name = "AlarmEnd",
                        PropertyType = EntityTypePropertyType.Property,
                        Description = "Alarm End",
                        ReferenceType = Cmf.Foundation.Common.ReferenceType.None,
                        ReferencedObjectId = 0,
                        ScalarType = datetimeScalarType,
                        IsEnabled = true,
                        IsIndexed = true,
                        IsMandatory = false,
                        IsHistoryEnable = true,
                        LoadToDWH = false
                    };

                    // add property to list of properties to add...
                    propertiesToAdd.Add(alarmEndProp);
                }

                #endregion

                #region Facility

                if (!foundEntity.Properties.Any(e => String.Equals(e.Name, "Facility", StringComparison.InvariantCultureIgnoreCase)))
                {
                    IEntityTypeProperty facilityProp = new EntityTypeProperty()
                    {
                        Name = "Facility",
                        PropertyType = EntityTypePropertyType.Property,
                        Description = "Facility",
                        ReferenceType = Cmf.Foundation.Common.ReferenceType.EntityType,
                        ReferencedObjectId = facilityEntityTypeId,
                        ScalarType = bigIntScalarType,
                        IsEnabled = true,
                        IsIndexed = true,
                        IsMandatory = true,
                        IsHistoryEnable = true,
                        LoadToDWH = false
                    };

                    // add property to list of properties to add...
                    propertiesToAdd.Add(facilityProp);
                }

                #endregion

                #region Area

                if (!foundEntity.Properties.Any(e => String.Equals(e.Name, "Area", StringComparison.InvariantCultureIgnoreCase)))
                {
                    IEntityTypeProperty areaProp = new EntityTypeProperty()
                    {
                        Name = "Area",
                        PropertyType = EntityTypePropertyType.Property,
                        Description = "Area",
                        ReferenceType = Cmf.Foundation.Common.ReferenceType.EntityType,
                        ReferencedObjectId = areaEntityTypeId,
                        ScalarType = bigIntScalarType,
                        IsEnabled = true,
                        IsIndexed = true,
                        IsMandatory = true,
                        IsHistoryEnable = true,
                        LoadToDWH = false
                    };

                    // add property to list of properties to add...
                    propertiesToAdd.Add(areaProp);
                }

                #endregion

                #region Resource

                if (!foundEntity.Properties.Any(e => String.Equals(e.Name, "Resource", StringComparison.InvariantCultureIgnoreCase)))
                {
                    IEntityTypeProperty resourceProp = new EntityTypeProperty()
                    {
                        Name = "Resource",
                        PropertyType = EntityTypePropertyType.Property,
                        Description = "Resource",
                        ReferenceType = Cmf.Foundation.Common.ReferenceType.EntityType,
                        ReferencedObjectId = resourceEntityTypeId,
                        ScalarType = bigIntScalarType,
                        IsEnabled = true,
                        IsIndexed = true,
                        IsMandatory = true,
                        IsHistoryEnable = true,
                        LoadToDWH = false
                    };

                    // add property to list of properties to add...
                    propertiesToAdd.Add(resourceProp);
                }

                #endregion

                #region TopMostResource

                if (!foundEntity.Properties.Any(e => String.Equals(e.Name, "TopMostResource", StringComparison.InvariantCultureIgnoreCase)))
                {
                    IEntityTypeProperty topMostResourceProp = new EntityTypeProperty()
                    {
                        Name = "TopMostResource",
                        PropertyType = EntityTypePropertyType.Property,
                        Description = "Top Most Resource",
                        ReferenceType = Cmf.Foundation.Common.ReferenceType.EntityType,
                        ReferencedObjectId = resourceEntityTypeId,
                        ScalarType = bigIntScalarType,
                        IsEnabled = true,
                        IsIndexed = true,
                        IsMandatory = true,
                        IsHistoryEnable = true,
                        LoadToDWH = false
                    };

                    // add property to list of properties to add...
                    propertiesToAdd.Add(topMostResourceProp);
                }

                #endregion

                #region Material

                if (!foundEntity.Properties.Any(e => String.Equals(e.Name, "Material", StringComparison.InvariantCultureIgnoreCase)))
                {
                    IEntityTypeProperty materialProp = new EntityTypeProperty()
                    {
                        Name = "Material",
                        PropertyType = EntityTypePropertyType.Property,
                        Description = "Material",
                        ReferenceType = Cmf.Foundation.Common.ReferenceType.None,
                        ReferencedObjectId = 0,
                        ScalarType = nvarcharScalarType,
                        IsEnabled = true,
                        IsIndexed = true,
                        IsMandatory = false,
                        IsHistoryEnable = true,
                        LoadToDWH = false
                    };

                    // add property to list of properties to add...
                    propertiesToAdd.Add(materialProp);
                }

                #endregion

                #region MAO ID

                if (!foundEntity.Properties.Any(e => String.Equals(e.Name, "MAOId", StringComparison.InvariantCultureIgnoreCase)))
                {
                    IEntityTypeProperty maoIdProp = new EntityTypeProperty()
                    {
                        Name = "MAOId",
                        PropertyType = EntityTypePropertyType.Property,
                        Description = "MAO Id",
                        ReferenceType = Cmf.Foundation.Common.ReferenceType.None,
                        ReferencedObjectId = 0,
                        ScalarType = bigIntScalarType,
                        IsEnabled = true,
                        IsIndexed = true,
                        IsMandatory = false,
                        AccessLevel = 1872, //Code for Not visible in every operation
                        IsHistoryEnable = true,
                        LoadToDWH = false
                    };

                    // add property to list of properties to add...
                    propertiesToAdd.Add(maoIdProp);
                }

                #endregion

                #region MAO Name

                if (!foundEntity.Properties.Any(e => String.Equals(e.Name, "MAOName", StringComparison.InvariantCultureIgnoreCase)))
                {
                    IEntityTypeProperty maoNameProp = new EntityTypeProperty()
                    {
                        Name = "MAOName",
                        PropertyType = EntityTypePropertyType.Property,
                        Description = "MAO Name",
                        ReferenceType = Cmf.Foundation.Common.ReferenceType.None,
                        ReferencedObjectId = 0,
                        ScalarType = nvarcharScalarType,
                        IsEnabled = true,
                        IsIndexed = true,
                        IsMandatory = false,
                        AccessLevel = 1360, //Code for visible only in view mode
                        IsHistoryEnable = true,
                        LoadToDWH = false
                    };

                    // add property to list of properties to add...
                    propertiesToAdd.Add(maoNameProp);
                }

                #endregion

                if (propertiesToAdd.Count > 0)
                {
                    foundEntity = entityTypeOrchestration.AddEntityTypeProperties(new AddEntityTypePropertiesInput()
                    {
                        EntityType = foundEntity as IEntityType,
                        EntityTypeProperties = propertiesToAdd
                    }).EntityType;
                }

                #endregion

                #region Generate Schema

                entityTypeOrchestration.GenerateEntityTypeDBSchema(new GenerateEntityTypeDBSchemaInput
                {
                    EntityType = foundEntity as IEntityType
                });

                #endregion
            }

            //---End DEE Code---

            return Input;
        }
    }
}
