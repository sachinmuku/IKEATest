﻿using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Linq;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessOrchestration.EntityTypeManagement;
using Cmf.Foundation.BusinessOrchestration.EntityTypeManagement.InputObjects;
using Cmf.Foundation.Common.Base;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessOrchestration.Abstractions;
using Microsoft.Extensions.DependencyInjection;


namespace Cmf.Custom.IKEA.Actions.ProcessRules.EntityTypes
{
    public class RelationMaterialBatch : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        /// <summary>
        /// DEE Action Condition abstract Method
        /// This class is responsible for the creation of the relation for material loss
        /// </summary>
        /// <param name="Input"></param>
        /// <returns></returns>
        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---
            UseReference("", "Cmf.Foundation.BusinessOrchestration.Abstractions");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "");
            UseReference("", "Cmf.Foundation.BusinessOrchestration.EntityTypeManagement");
            UseReference("", "Cmf.Foundation.BusinessOrchestration.EntityTypeManagement.InputObjects");
            
            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            var entityTypeOrchestration = serviceProvider.GetService<IEntityTypeOrchestration>();

            // name of the entity to be generated...
            string newEntityName = "CustomMaterialBatch";

            // only makes sense to proceed if entity type doesn't exist yet...
            IEntityType foundEntity = entityTypeOrchestration.GetAllEntityTypes(new GetAllEntityTypesInput()).EntityTypes.FirstOrDefault(e => String.Equals(e.Name, newEntityName, StringComparison.InvariantCultureIgnoreCase));
            if (foundEntity == null)
            {
                long sourceRelationEntityTypeId = entityTypeOrchestration.GetEntityTypeByName(new GetEntityTypeByNameInput { Name = "Material" }).EntityType.Id;
                long targetRelationEntityTypeId = entityTypeOrchestration.GetEntityTypeByName(new GetEntityTypeByNameInput { Name = "Material" }).EntityType.Id;

                // set new entity type to be created
                foundEntity = new EntityType()
                {
                    Name = newEntityName,
                    Description = "Batch Materials",
                    CloneBehavior = CloneBehavior.CopyIfSource,
                    HistoryRetentionTime = 180,
                    IsHistoryEnabled = true,
                    IsUniqueNameRequired = false,
                    ReplicateToODS = true,
                    AllowAttributes = true,
                    AllowDeleteInstances = true,
                    IsVisible = false,
                    IsCloneable = false,
                    IsRelation = true,
                    SourceRelationEntityTypeId = sourceRelationEntityTypeId,
                    TargetRelationEntityTypeId = targetRelationEntityTypeId
                };

                foundEntity = entityTypeOrchestration.CreateEntityType(new CreateEntityTypeInput() { EntityType = foundEntity as IEntityType}).EntityType;
            }

            // if entity is still in Created state, check if all necessary properties are already added...
            if (foundEntity.UniversalState == UniversalState.Created)
            {
                #region Set Properties

                IScalarType bitScalarType = new ScalarType();
                bitScalarType.Load("Bit");

                // set properties to be added
                IEntityTypePropertyCollection propertiesToAdd = new EntityTypePropertyCollection();

                #region Is Reported

                if (!foundEntity.Properties.Any(e => String.Equals(e.Name, "IsReported", StringComparison.InvariantCultureIgnoreCase)))
                {
                    IEntityTypeProperty isReported = new EntityTypeProperty()
                    {
                        Name = "IsParentBatch",
                        PropertyType = EntityTypePropertyType.Property,
                        Description = "Is Parent Batch",
                        ReferenceType = Cmf.Foundation.Common.ReferenceType.None,
                        ReferencedObjectId = 0,
                        ScalarType = bitScalarType,
                        IsEnabled = true,
                        IsIndexed = false,
                        IsMandatory = true,
                        IsHistoryEnable = true,
                        LoadToDWH = false
                    };

                    // add property to list of properties to add...
                    propertiesToAdd.Add(isReported);
                }

                #endregion

                if (propertiesToAdd.Count > 0)
                {
                    foundEntity = entityTypeOrchestration.AddEntityTypeProperties(new AddEntityTypePropertiesInput()
                    {
                        EntityType = foundEntity as IEntityType,
                        EntityTypeProperties = propertiesToAdd
                    }).EntityType;
                }

                #endregion

                #region Generate Schema

                entityTypeOrchestration.GenerateEntityTypeDBSchema(new GenerateEntityTypeDBSchemaInput
                {
                    EntityType = foundEntity as IEntityType
                });

                #endregion
            }

            //---End DEE Code---
            return Input;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="Input"></param>
        /// <returns></returns>
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---

            return true;

            //---End DEE Condition Code---
        }

    }
}
