﻿using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Linq;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessOrchestration.EntityTypeManagement;
using Cmf.Foundation.BusinessOrchestration.EntityTypeManagement.InputObjects;
using Cmf.Foundation.Common.Base;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessOrchestration.Abstractions;
using Microsoft.Extensions.DependencyInjection;

namespace Cmf.Custom.IKEA.Actions.ProcessRules.EntityTypes
{
    public class CustomMaterialReplenishmentRequestTracker : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            return true;

            //---End DEE Condition Code---
        }

        /// <summary>
        /// DEE Action Condition abstract Method
        /// DEE to create the Entity Type for Replenishment requests tracking
        /// </summary>
        /// <param name="Input"></param>
        /// <returns></returns>
        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
            UseReference("", "Cmf.Foundation.BusinessOrchestration.Abstractions");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "");
            UseReference("", "Cmf.Foundation.BusinessOrchestration.EntityTypeManagement");
            UseReference("", "Cmf.Foundation.BusinessOrchestration.EntityTypeManagement.InputObjects");
            
            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            var entityTypeOrchestration = serviceProvider.GetService<IEntityTypeOrchestration>();

            // name of the entity to be generated...
            string newEntityName = "CustomMaterialReplenishmentRequestTracker";

            // only makes sense to proceed if entity type doesn't exist yet...
            IEntityType foundEntity = entityTypeOrchestration.GetAllEntityTypes(new GetAllEntityTypesInput()).EntityTypes.FirstOrDefault(e => String.Equals(e.Name, newEntityName, StringComparison.InvariantCultureIgnoreCase));
            if (foundEntity == null)
            {
                // set new entity type to be created
                foundEntity = new EntityType()
                {
                    Name = newEntityName,
                    Description = "Entity Type to track replenishment requests",
                    CloneBehavior = CloneBehavior.NoCopy,
                    HistoryRetentionTime = 1,
                    IsHistoryEnabled = true,
                    IsUniqueNameRequired = true,
                    ReplicateToODS = true,
                    AllowAttributes = true,
                    AllowDeleteInstances = true,
                    IsVisible = true,
                    IsCloneable = true,
                    IsRelation = false
                };

                foundEntity = entityTypeOrchestration.CreateEntityType(new CreateEntityTypeInput() { EntityType = foundEntity as IEntityType }).EntityType;
            }

            // if entity is still in Created state, check if all necessary properties are already added...
            if (foundEntity.UniversalState == UniversalState.Created)
            {
                #region Set Properties

                IScalarType decimalScalarType = new ScalarType();
                decimalScalarType.Load("Decimal");
                IScalarType bigIntScalarType = new ScalarType();
                bigIntScalarType.Load("BigInt");
                IScalarType nvarcharScalarType = new ScalarType();
                nvarcharScalarType.Load("NVarChar");

                // set properties to be added
                IEntityTypePropertyCollection propertiesToAdd = new EntityTypePropertyCollection();

                #region RequestedQuantity

                if (!foundEntity.Properties.Any(e => String.Equals(e.Name, "RequestedQuantity", StringComparison.InvariantCultureIgnoreCase)))
                {
                    IEntityTypeProperty requestedQuantityProp = new EntityTypeProperty()
                    {
                        Name = "RequestedQuantity",
                        PropertyType = EntityTypePropertyType.Property,
                        Description = "Requested Quantity",
                        ReferenceType = Cmf.Foundation.Common.ReferenceType.None,
                        ReferencedObjectId = 0,
                        ScalarType = decimalScalarType,
                        ScalarPrecision = 18,
                        ScalarSize = 8,
                        IsEnabled = true,
                        IsIndexed = true,
                        IsMandatory = true,
                        IsHistoryEnable = true,
                        LoadToDWH = false
                    };

                    // add property to list of properties to add...
                    propertiesToAdd.Add(requestedQuantityProp);
                }

                #endregion

                #region DeliveredQuantity

                if (!foundEntity.Properties.Any(e => String.Equals(e.Name, "DeliveredQuantity", StringComparison.InvariantCultureIgnoreCase)))
                {
                    IEntityTypeProperty deliveredQuantityProp = new EntityTypeProperty()
                    {
                        Name = "DeliveredQuantity",
                        PropertyType = EntityTypePropertyType.Property,
                        Description = "Delivered Quantity",
                        ReferenceType = Cmf.Foundation.Common.ReferenceType.None,
                        ReferencedObjectId = 0,
                        ScalarType = decimalScalarType,
                        ScalarPrecision = 18,
                        ScalarSize = 8,
                        IsEnabled = true,
                        IsIndexed = true,
                        IsMandatory = true,
                        IsHistoryEnable = true,
                        LoadToDWH = false
                    };

                    // add property to list of properties to add...
                    propertiesToAdd.Add(deliveredQuantityProp);
                }

                #endregion

                #region Product

                if (!foundEntity.Properties.Any(e => String.Equals(e.Name, "ProductName", StringComparison.InvariantCultureIgnoreCase)))
                {
                    IEntityTypeProperty productProp = new EntityTypeProperty()
                    {
                        Name = "ProductName",
                        PropertyType = EntityTypePropertyType.Property,
                        Description = "Product Name",
                        ReferenceType = Cmf.Foundation.Common.ReferenceType.None,
                        ReferencedObjectId = 0,
                        ScalarType = nvarcharScalarType,
                        IsEnabled = true,
                        IsIndexed = true,
                        IsMandatory = true,
                        IsHistoryEnable = true,
                        LoadToDWH = false
                    };

                    // add property to list of properties to add...
                    propertiesToAdd.Add(productProp);
                }

                #endregion

                #region StockingPoint

                if (!foundEntity.Properties.Any(e => String.Equals(e.Name, "StockingPoint", StringComparison.InvariantCultureIgnoreCase)))
                {
                    IEntityTypeProperty stockingPointProp = new EntityTypeProperty()
                    {
                        Name = "StockingPoint",
                        PropertyType = EntityTypePropertyType.Property,
                        Description = "Stocking Point",
                        ReferenceType = Cmf.Foundation.Common.ReferenceType.None,
                        ReferencedObjectId = 0,
                        ScalarType = nvarcharScalarType,
                        IsEnabled = true,
                        IsIndexed = true,
                        IsMandatory = true,
                        IsHistoryEnable = true,
                        LoadToDWH = false
                    };

                    // add property to list of properties to add...
                    propertiesToAdd.Add(stockingPointProp);
                }

                #endregion

                if (propertiesToAdd.Count > 0)
                {
                    foundEntity = entityTypeOrchestration.AddEntityTypeProperties(new AddEntityTypePropertiesInput()
                    {
                        EntityType = foundEntity as IEntityType,
                        EntityTypeProperties = propertiesToAdd
                    }).EntityType;
                }

                #endregion


                #region Generate Schema

                entityTypeOrchestration.GenerateEntityTypeDBSchema(new GenerateEntityTypeDBSchemaInput
                {
                    EntityType = foundEntity as IEntityType
                });

                #endregion
            }

            //---End DEE Code---

            return Input;
        }
    }
}
