﻿using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Linq;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessOrchestration.EntityTypeManagement;
using Cmf.Foundation.BusinessOrchestration.EntityTypeManagement.InputObjects;
using Cmf.Foundation.Common.Base;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessOrchestration.Abstractions;
using Microsoft.Extensions.DependencyInjection;

namespace Cmf.Custom.IKEA.Actions.ProcessRules.EntityTypes
{
    public class CustomERPOperationTracking : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            return true;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
            UseReference("", "Cmf.Foundation.BusinessOrchestration.Abstractions");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "");
            UseReference("", "Cmf.Foundation.BusinessOrchestration.EntityTypeManagement");
            UseReference("", "Cmf.Foundation.BusinessOrchestration.EntityTypeManagement.InputObjects");
            
            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            var entityTypeOrchestration = serviceProvider.GetService<IEntityTypeOrchestration>();

            // name of the entity to be generated...
            string newEntityName = "CustomERPOperationTracking";

            // only makes sense to proceed if entity type doesn't exist yet...
            IEntityType foundEntity = entityTypeOrchestration.GetAllEntityTypes(new GetAllEntityTypesInput()).EntityTypes.FirstOrDefault(e => String.Equals(e.Name, newEntityName, StringComparison.InvariantCultureIgnoreCase));
            if (foundEntity == null)
            {
                // set new entity type to be created
                foundEntity = new EntityType()
                {
                    Name = newEntityName,
                    Description = "Entity Type to track operations to be reported to ERP",
                    CloneBehavior = CloneBehavior.NoCopy,
                    HistoryRetentionTime = 1,
                    IsHistoryEnabled = true,
                    IsUniqueNameRequired = true,
                    ReplicateToODS = true,
                    AllowAttributes = true,
                    AllowDeleteInstances = true,
                    IsVisible = true,
                    IsCloneable = true,
                    IsRelation = false
                };

                foundEntity = entityTypeOrchestration.CreateEntityType(new CreateEntityTypeInput() { EntityType = foundEntity as IEntityType }).EntityType;
            }

            // if entity is still in Created state, check if all necessary properties are already added...
            if (foundEntity.UniversalState == UniversalState.Created)
            {
                #region Set Properties

                IScalarType nvarcharScalarType = new ScalarType();
                nvarcharScalarType.Load("NVarChar");
                IScalarType decimalScalarType = new ScalarType();
                decimalScalarType.Load("Decimal");
                IScalarType bigIntScalarType = new ScalarType();
                bigIntScalarType.Load("BigInt");
                IScalarType datetimeScalarType = new ScalarType();
                datetimeScalarType.Load("DateTime");
                IScalarType intScalarType = new ScalarType();
                intScalarType.Load("Int");
                IScalarType bitScalarType = new ScalarType();
                bitScalarType.Load("Bit");

                // set properties to be added
                IEntityTypePropertyCollection propertiesToAdd = new EntityTypePropertyCollection();

                #region Order Material

                if (!foundEntity.Properties.Any(e => String.Equals(e.Name, "OrderMaterial", StringComparison.InvariantCultureIgnoreCase)))
                {
                    IEntityTypeProperty orderMaterial = new EntityTypeProperty()
                    {
                        Name = "OrderMaterial",
                        PropertyType = EntityTypePropertyType.Property,
                        Description = "Order Material",
                        ReferenceType = Cmf.Foundation.Common.ReferenceType.None,
                        ReferencedObjectId = 0,
                        ScalarType = nvarcharScalarType,
                        IsEnabled = true,
                        IsIndexed = true,
                        IsMandatory = true,
                        IsHistoryEnable = true,
                        LoadToDWH = false
                    };

                    // add property to list of properties to add...
                    propertiesToAdd.Add(orderMaterial);
                }

                #endregion

                #region Order Run Number

                if (!foundEntity.Properties.Any(e => String.Equals(e.Name, "OrderRunNumber", StringComparison.InvariantCultureIgnoreCase)))
                {
                    IEntityTypeProperty orderRunNumber = new EntityTypeProperty()
                    {
                        Name = "OrderRunNumber",
                        PropertyType = EntityTypePropertyType.Property,
                        Description = "Order Run Number",
                        ReferenceType = Cmf.Foundation.Common.ReferenceType.None,
                        ReferencedObjectId = 0,
                        ScalarType = intScalarType,
                        IsEnabled = true,
                        IsIndexed = true,
                        IsMandatory = true,
                        IsHistoryEnable = true,
                        LoadToDWH = false
                    };

                    // add property to list of properties to add...
                    propertiesToAdd.Add(orderRunNumber);
                }

                #endregion

                #region Order Operation

                if (!foundEntity.Properties.Any(e => String.Equals(e.Name, "OrderOperation", StringComparison.InvariantCultureIgnoreCase)))
                {
                    IEntityTypeProperty orderOperation = new EntityTypeProperty()
                    {
                        Name = "OrderOperation",
                        PropertyType = EntityTypePropertyType.Property,
                        Description = "Order Operation",
                        ReferenceType = Cmf.Foundation.Common.ReferenceType.None,
                        ReferencedObjectId = 0,
                        ScalarType = nvarcharScalarType,
                        IsEnabled = true,
                        IsIndexed = true,
                        IsMandatory = true,
                        IsHistoryEnable = true,
                        LoadToDWH = false
                    };

                    // add property to list of properties to add...
                    propertiesToAdd.Add(orderOperation);
                }

                #endregion

                #region Order Operation Sequence

                if (!foundEntity.Properties.Any(e => String.Equals(e.Name, "OrderOperationSequence", StringComparison.InvariantCultureIgnoreCase)))
                {
                    IEntityTypeProperty orderOperationSequence = new EntityTypeProperty()
                    {
                        Name = "OrderOperationSequence",
                        PropertyType = EntityTypePropertyType.Property,
                        Description = "Order Operation Sequence",
                        ReferenceType = Cmf.Foundation.Common.ReferenceType.None,
                        ReferencedObjectId = 0,
                        ScalarType = intScalarType,
                        IsEnabled = true,
                        IsIndexed = false,
                        IsMandatory = true,
                        IsHistoryEnable = true,
                        LoadToDWH = false
                    };

                    // add property to list of properties to add...
                    propertiesToAdd.Add(orderOperationSequence);
                }

                #endregion

                #region Order Operation Start

                if (!foundEntity.Properties.Any(e => String.Equals(e.Name, "OrderOperationStart", StringComparison.InvariantCultureIgnoreCase)))
                {
                    IEntityTypeProperty orderOperationStart = new EntityTypeProperty()
                    {
                        Name = "OrderOperationStart",
                        PropertyType = EntityTypePropertyType.Property,
                        Description = "Order Operation Start",
                        ReferenceType = Cmf.Foundation.Common.ReferenceType.None,
                        ReferencedObjectId = 0,
                        ScalarType = datetimeScalarType,
                        IsEnabled = true,
                        IsIndexed = false,
                        IsMandatory = true,
                        IsHistoryEnable = true,
                        LoadToDWH = false
                    };

                    // add property to list of properties to add...
                    propertiesToAdd.Add(orderOperationStart);
                }

                #endregion

                #region Order Operation End

                if (!foundEntity.Properties.Any(e => String.Equals(e.Name, "OrderOperationEnd", StringComparison.InvariantCultureIgnoreCase)))
                {
                    IEntityTypeProperty orderOperationEnd = new EntityTypeProperty()
                    {
                        Name = "OrderOperationEnd",
                        PropertyType = EntityTypePropertyType.Property,
                        Description = "Order Operation End",
                        ReferenceType = Cmf.Foundation.Common.ReferenceType.None,
                        ReferencedObjectId = 0,
                        ScalarType = datetimeScalarType,
                        IsEnabled = true,
                        IsIndexed = false,
                        IsMandatory = false,
                        IsHistoryEnable = true,
                        LoadToDWH = false
                    };

                    // add property to list of properties to add...
                    propertiesToAdd.Add(orderOperationEnd);
                }

                #endregion

                #region Order Operation Duration

                if (!foundEntity.Properties.Any(e => String.Equals(e.Name, "OrderOperationDuration", StringComparison.InvariantCultureIgnoreCase)))
                {
                    IEntityTypeProperty orderOperationDuration = new EntityTypeProperty()
                    {
                        Name = "OrderOperationDuration",
                        PropertyType = EntityTypePropertyType.Property,
                        Description = "Order Operation Duration",
                        ReferenceType = Cmf.Foundation.Common.ReferenceType.None,
                        ReferencedObjectId = 0,
                        ScalarType = decimalScalarType,
                        ScalarPrecision = 9,
                        ScalarSize = 2,
                        IsEnabled = true,
                        IsIndexed = false,
                        IsMandatory = false,
                        IsHistoryEnable = true,
                        LoadToDWH = false
                    };

                    // add property to list of properties to add...
                    propertiesToAdd.Add(orderOperationDuration);
                }

                #endregion

                #region Order Scheduled Quantity

                if (!foundEntity.Properties.Any(e => String.Equals(e.Name, "OrderScheduledQuantity", StringComparison.InvariantCultureIgnoreCase)))
                {
                    IEntityTypeProperty orderScheduledQuantity = new EntityTypeProperty()
                    {
                        Name = "OrderScheduledQuantity",
                        PropertyType = EntityTypePropertyType.Property,
                        Description = "Order Scheduled Quantity",
                        ReferenceType = Cmf.Foundation.Common.ReferenceType.None,
                        ReferencedObjectId = 0,
                        ScalarType = decimalScalarType,
                        ScalarPrecision = 18,
                        ScalarSize = 8,
                        IsEnabled = true,
                        IsIndexed = false,
                        IsMandatory = true,
                        IsHistoryEnable = true,
                        LoadToDWH = false
                    };

                    // add property to list of properties to add...
                    propertiesToAdd.Add(orderScheduledQuantity);
                }

                #endregion

                #region Order Finished Quantity

                if (!foundEntity.Properties.Any(e => String.Equals(e.Name, "OrderFinishedQuantity", StringComparison.InvariantCultureIgnoreCase)))
                {
                    IEntityTypeProperty orderFinishedQuantity = new EntityTypeProperty()
                    {
                        Name = "OrderFinishedQuantity",
                        PropertyType = EntityTypePropertyType.Property,
                        Description = "Order Finished Quantity",
                        ReferenceType = Cmf.Foundation.Common.ReferenceType.None,
                        ReferencedObjectId = 0,
                        ScalarType = decimalScalarType,
                        ScalarPrecision = 18,
                        ScalarSize = 8,
                        IsEnabled = true,
                        IsIndexed = false,
                        IsMandatory = true,
                        IsHistoryEnable = true,
                        LoadToDWH = false
                    };

                    // add property to list of properties to add...
                    propertiesToAdd.Add(orderFinishedQuantity);
                }

                #endregion

                #region Order Resource

                if (!foundEntity.Properties.Any(e => String.Equals(e.Name, "OrderResource", StringComparison.InvariantCultureIgnoreCase)))
                {
                    IEntityTypeProperty orderMaterial = new EntityTypeProperty()
                    {
                        Name = "OrderResource",
                        PropertyType = EntityTypePropertyType.Property,
                        Description = "Order Resource",
                        ReferenceType = Cmf.Foundation.Common.ReferenceType.None,
                        ReferencedObjectId = 0,
                        ScalarType = nvarcharScalarType,
                        IsEnabled = true,
                        IsIndexed = true,
                        IsMandatory = true,
                        IsHistoryEnable = true,
                        LoadToDWH = false
                    };

                    // add property to list of properties to add...
                    propertiesToAdd.Add(orderMaterial);
                }

                #endregion

                #region Is Original

                if (!foundEntity.Properties.Any(e => String.Equals(e.Name, "IsOriginal", StringComparison.InvariantCultureIgnoreCase)))
                {
                    IEntityTypeProperty isReported = new EntityTypeProperty()
                    {
                        Name = "IsOriginal",
                        PropertyType = EntityTypePropertyType.Property,
                        Description = "Is Original",
                        ReferenceType = Cmf.Foundation.Common.ReferenceType.None,
                        ReferencedObjectId = 0,
                        ScalarType = bitScalarType,
                        IsEnabled = true,
                        IsIndexed = false,
                        IsMandatory = true,
                        IsHistoryEnable = true,
                        LoadToDWH = false
                    };

                    // add property to list of properties to add...
                    propertiesToAdd.Add(isReported);
                }

                #endregion

                if (propertiesToAdd.Count > 0)
                {
                    foundEntity = entityTypeOrchestration.AddEntityTypeProperties(new AddEntityTypePropertiesInput()
                    {
                        EntityType = foundEntity as IEntityType,
                        EntityTypeProperties = propertiesToAdd,
                    }).EntityType;
                }

                #endregion

                #region Set Operations

                // Operations to be added to the entity type
                IOperationCollection operationsToAdd = new OperationCollection();

                #region Report Consumption

                if (!foundEntity.Operations.Any(e => String.Equals(e.Name, "ReportConsumption", StringComparison.InvariantCultureIgnoreCase)))
                {
                    IOperation reportConsumption = new Operation()
                    {
                        Name = "ReportConsumption",
                        Description = "Report Consumption",
                        IsPublishEnabled = true,
                        IsHistoryEnable = true,
                        IsSystemOperation = true,
                        IsFabLiveVisible = false,
                    };

                    // add operation to the collection of Operations to add...
                    operationsToAdd.Add(reportConsumption);
                }

                #endregion

                #region Update Progress

                if (!foundEntity.Operations.Any(e => String.Equals(e.Name, "UpdateProgress", StringComparison.InvariantCultureIgnoreCase)))
                {
                    IOperation updateProgress = new Operation()
                    {
                        Name = "UpdateProgress",
                        Description = "Update Progress",
                        IsPublishEnabled = true,
                        IsHistoryEnable = true,
                        IsSystemOperation = true,
                        IsFabLiveVisible = false,
                    };

                    // add operation to the collection of Operations to add...
                    operationsToAdd.Add(updateProgress);
                }

                #endregion

                #region Update Scheduled Quantity

                if (!foundEntity.Operations.Any(e => String.Equals(e.Name, "UpdateScheduledQuantity", StringComparison.InvariantCultureIgnoreCase)))
                {
                    IOperation updateScheduledQuantity = new Operation()
                    {
                        Name = "UpdateScheduledQuantity",
                        Description = "Update Scheduled Quantity",
                        IsPublishEnabled = true,
                        IsHistoryEnable = true,
                        IsSystemOperation = true,
                        IsFabLiveVisible = false,
                    };

                    // add operation to the collection of Operations to add...
                    operationsToAdd.Add(updateScheduledQuantity);
                }

                #endregion

                #region Log Consumption

                if (!foundEntity.Operations.Any(e => String.Equals(e.Name, "LogConsumption", StringComparison.InvariantCultureIgnoreCase)))
                {
                    IOperation logConsumption = new Operation()
                    {
                        Name = "LogConsumption",
                        Description = "Log Consumption",
                        IsPublishEnabled = true,
                        IsHistoryEnable = true,
                        IsSystemOperation = true,
                        IsFabLiveVisible = false,
                    };

                    // add operation to the collection of Operations to add...
                    operationsToAdd.Add(logConsumption);
                }

                #endregion

                #region Report Operation

                if (!foundEntity.Operations.Any(e => String.Equals(e.Name, "ReportOperation", StringComparison.InvariantCultureIgnoreCase)))
                {
                    IOperation reportOperation = new Operation()
                    {
                        Name = "ReportOperation",
                        Description = "Report Consumption",
                        IsPublishEnabled = true,
                        IsHistoryEnable = true,
                        IsSystemOperation = true,
                        IsFabLiveVisible = false,
                    };

                    // add operation to the collection of Operations to add...
                    operationsToAdd.Add(reportOperation);
                }

                #endregion

                #region Transfer Scheduled Quantity

                if (!foundEntity.Operations.Any(e => String.Equals(e.Name, "TransferScheduledQuantity", StringComparison.InvariantCultureIgnoreCase)))
                {
                    IOperation transferScheduledQuantityreportOperation = new Operation()
                    {
                        Name = "TransferScheduledQuantity",
                        Description = "Transfer Scheduled Quantity",
                        IsPublishEnabled = true,
                        IsHistoryEnable = true,
                        IsSystemOperation = true,
                        IsFabLiveVisible = false,
                    };

                    // add operation to the collection of Operations to add...
                    operationsToAdd.Add(transferScheduledQuantityreportOperation);
                }

                #endregion

                if (operationsToAdd.Count > 0)
                {
                    foundEntity = entityTypeOrchestration.AddEntityTypeOperations(new AddEntityTypeOperationsInput()
                    {
                        EntityType = foundEntity as IEntityType,
                        Operations = operationsToAdd,
                    }).EntityType;
                }

                #endregion

                #region Generate Schema

                entityTypeOrchestration.GenerateEntityTypeDBSchema(new GenerateEntityTypeDBSchemaInput
                {
                    EntityType = foundEntity as IEntityType
                });

                #endregion
            }

            //---End DEE Code---

            return Input;
        }
    }
}
