﻿using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Linq;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessOrchestration.EntityTypeManagement;
using Cmf.Foundation.BusinessOrchestration.EntityTypeManagement.InputObjects;
using Cmf.Foundation.Common.Base;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessOrchestration.Abstractions;
using Microsoft.Extensions.DependencyInjection;


namespace Cmf.Custom.IKEA.Actions.ProcessRules.EntityTypes
{
    public class CustomERPOperationTrackingConsumptionLog : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            return true;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            //System
            UseReference("", "Cmf.Foundation.BusinessOrchestration.Abstractions");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "");
            UseReference("", "Cmf.Foundation.BusinessOrchestration.EntityTypeManagement");
            UseReference("", "Cmf.Foundation.BusinessOrchestration.EntityTypeManagement.InputObjects");
            
            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            var entityTypeOrchestration = serviceProvider.GetService<IEntityTypeOrchestration>();

            // name of the entity to be generated...
            string newEntityName = "CustomERPOperationTrackingConsumptionLog";

            // only makes sense to proceed if entity type doesn't exist yet...
            IEntityType foundEntity = entityTypeOrchestration.GetAllEntityTypes(new GetAllEntityTypesInput()).EntityTypes.FirstOrDefault(e => String.Equals(e.Name, newEntityName, StringComparison.InvariantCultureIgnoreCase));
            if (foundEntity == null)
            {
                // set new entity type to be created
                foundEntity = new EntityType()
                {
                    Name = newEntityName,
                    Description = "Entity Type to log all consumptions to be reported to ERP",
                    CloneBehavior = CloneBehavior.NoCopy,
                    HistoryRetentionTime = 1,
                    IsHistoryEnabled = true,
                    IsUniqueNameRequired = true,
                    ReplicateToODS = true,
                    AllowAttributes = true,
                    AllowDeleteInstances = true,
                    IsVisible = true,
                    IsCloneable = true,
                    IsRelation = false
                };

                foundEntity = entityTypeOrchestration.CreateEntityType(new CreateEntityTypeInput() { EntityType = foundEntity as IEntityType }).EntityType;
            }


            // if entity is still in Created state, check if all necessary properties are already added...
            if (foundEntity.UniversalState == UniversalState.Created)
            {
                #region Set Properties

                long customERPOperationTrackingEntityTypeId = entityTypeOrchestration.GetEntityTypeByName(new GetEntityTypeByNameInput { Name = "CustomERPOperationTracking" }).EntityType.Id;

                IScalarType nvarcharScalarType = new ScalarType();
                nvarcharScalarType.Load("NVarChar");
                IScalarType decimalScalarType = new ScalarType();
                decimalScalarType.Load("Decimal");
                IScalarType bigIntScalarType = new ScalarType();
                bigIntScalarType.Load("BigInt");
                IScalarType datetimeScalarType = new ScalarType();
                datetimeScalarType.Load("DateTime");
                IScalarType intScalarType = new ScalarType();
                intScalarType.Load("Int");
                IScalarType bitScalarType = new ScalarType();
                bitScalarType.Load("Bit");


                // set properties to be added
                IEntityTypePropertyCollection propertiesToAdd = new EntityTypePropertyCollection();

                #region ERP Operation Tracking

                if (!foundEntity.Properties.Any(e => String.Equals(e.Name, "CustomERPOperationTracking", StringComparison.InvariantCultureIgnoreCase)))
                {
                    IEntityTypeProperty customERPOperationTracking = new EntityTypeProperty()
                    {
                        Name = "CustomERPOperationTracking",
                        PropertyType = EntityTypePropertyType.Property,
                        Description = "ERP Operation Tracking",
                        ReferenceType = Cmf.Foundation.Common.ReferenceType.EntityType,
                        ReferencedObjectId = customERPOperationTrackingEntityTypeId,
                        ScalarType = bigIntScalarType,
                        IsEnabled = true,
                        IsIndexed = true,
                        IsMandatory = true,
                        IsHistoryEnable = true,
                        LoadToDWH = false
                    };

                    // add property to list of properties to add...
                    propertiesToAdd.Add(customERPOperationTracking);
                }

                #endregion

                #region Product Name

                if (!foundEntity.Properties.Any(e => String.Equals(e.Name, "ProductName", StringComparison.InvariantCultureIgnoreCase)))
                {
                    IEntityTypeProperty productName = new EntityTypeProperty()
                    {
                        Name = "ProductName",
                        PropertyType = EntityTypePropertyType.Property,
                        Description = "Product Name",
                        ReferenceType = Cmf.Foundation.Common.ReferenceType.None,
                        ReferencedObjectId = 0,
                        ScalarType = nvarcharScalarType,
                        IsEnabled = true,
                        IsIndexed = true,
                        IsMandatory = true,
                        IsHistoryEnable = true,
                        LoadToDWH = false
                    };

                    // add property to list of properties to add...
                    propertiesToAdd.Add(productName);
                }

                #endregion

                #region Quantity

                if (!foundEntity.Properties.Any(e => String.Equals(e.Name, "Quantity", StringComparison.InvariantCultureIgnoreCase)))
                {
                    IEntityTypeProperty quantity = new EntityTypeProperty()
                    {
                        Name = "Quantity",
                        PropertyType = EntityTypePropertyType.Property,
                        Description = "Quantity",
                        ReferenceType = Cmf.Foundation.Common.ReferenceType.None,
                        ReferencedObjectId = 0,
                        ScalarType = decimalScalarType,
                        ScalarPrecision = 18,
                        ScalarSize = 8,
                        IsEnabled = true,
                        IsIndexed = false,
                        IsMandatory = true,
                        IsHistoryEnable = true,
                        LoadToDWH = false
                    };

                    // add property to list of properties to add...
                    propertiesToAdd.Add(quantity);
                }

                #endregion

                #region Units

                if (!foundEntity.Properties.Any(e => String.Equals(e.Name, "Units", StringComparison.InvariantCultureIgnoreCase)))
                {
                    IEntityTypeProperty batchName = new EntityTypeProperty()
                    {
                        Name = "Units",
                        PropertyType = EntityTypePropertyType.Property,
                        Description = "Units",
                        ReferenceType = Cmf.Foundation.Common.ReferenceType.None,
                        ReferencedObjectId = 0,
                        ScalarType = nvarcharScalarType,
                        IsEnabled = true,
                        IsIndexed = false,
                        IsMandatory = false,
                        IsHistoryEnable = true,
                        LoadToDWH = false
                    };

                    // add property to list of properties to add...
                    propertiesToAdd.Add(batchName);
                }

                #endregion

                #region Batch Name

                if (!foundEntity.Properties.Any(e => String.Equals(e.Name, "BatchName", StringComparison.InvariantCultureIgnoreCase)))
                {
                    IEntityTypeProperty batchName = new EntityTypeProperty()
                    {
                        Name = "BatchName",
                        PropertyType = EntityTypePropertyType.Property,
                        Description = "Batch Name",
                        ReferenceType = Cmf.Foundation.Common.ReferenceType.None,
                        ReferencedObjectId = 0,
                        ScalarType = nvarcharScalarType,
                        IsEnabled = true,
                        IsIndexed = false,
                        IsMandatory = false,
                        IsHistoryEnable = true,
                        LoadToDWH = false
                    };

                    // add property to list of properties to add...
                    propertiesToAdd.Add(batchName);
                }

                #endregion

                #region Material Name

                if (!foundEntity.Properties.Any(e => String.Equals(e.Name, "MaterialName", StringComparison.InvariantCultureIgnoreCase)))
                {
                    IEntityTypeProperty materialName = new EntityTypeProperty()
                    {
                        Name = "MaterialName",
                        PropertyType = EntityTypePropertyType.Property,
                        Description = "Material Name",
                        ReferenceType = Cmf.Foundation.Common.ReferenceType.None,
                        ReferencedObjectId = 0,
                        ScalarType = nvarcharScalarType,
                        IsEnabled = true,
                        IsIndexed = false,
                        IsMandatory = false,
                        IsHistoryEnable = true,
                        LoadToDWH = false
                    };

                    // add property to list of properties to add...
                    propertiesToAdd.Add(materialName);
                }

                #endregion

                #region BOM Sequence Number

                if (!foundEntity.Properties.Any(e => String.Equals(e.Name, "BOMSequenceNumber", StringComparison.InvariantCultureIgnoreCase)))
                {
                    IEntityTypeProperty bomSequenceNumber = new EntityTypeProperty()
                    {
                        Name = "BOMSequenceNumber",
                        PropertyType = EntityTypePropertyType.Property,
                        Description = "BOM Sequence Number",
                        ReferenceType = Cmf.Foundation.Common.ReferenceType.None,
                        ReferencedObjectId = 0,
                        ScalarType = intScalarType,
                        IsEnabled = true,
                        IsIndexed = false,
                        IsMandatory = false,
                        IsHistoryEnable = true,
                        LoadToDWH = false
                    };

                    // add property to list of properties to add...
                    propertiesToAdd.Add(bomSequenceNumber);
                }

                #endregion

                #region Is Reported

                if (!foundEntity.Properties.Any(e => String.Equals(e.Name, "IsReported", StringComparison.InvariantCultureIgnoreCase)))
                {
                    IEntityTypeProperty isReported = new EntityTypeProperty()
                    {
                        Name = "IsReported",
                        PropertyType = EntityTypePropertyType.Property,
                        Description = "Is Reported",
                        ReferenceType = Cmf.Foundation.Common.ReferenceType.None,
                        ReferencedObjectId = 0,
                        ScalarType = bitScalarType,
                        IsEnabled = true,
                        IsIndexed = false,
                        IsMandatory = true,
                        IsHistoryEnable = true,
                        LoadToDWH = false
                    };

                    // add property to list of properties to add...
                    propertiesToAdd.Add(isReported);
                }

                #endregion

                if (propertiesToAdd.Count > 0)
                {
                    foundEntity = entityTypeOrchestration.AddEntityTypeProperties(new AddEntityTypePropertiesInput()
                    {
                        EntityType = foundEntity as IEntityType,
                        EntityTypeProperties = propertiesToAdd,
                    }).EntityType;
                }

                #endregion

                #region Generate Schema

                entityTypeOrchestration.GenerateEntityTypeDBSchema(new GenerateEntityTypeDBSchemaInput
                {
                    EntityType = foundEntity as IEntityType
                });

                #endregion
            }


            //---End DEE Code---

            return Input;
        }
    }
}
