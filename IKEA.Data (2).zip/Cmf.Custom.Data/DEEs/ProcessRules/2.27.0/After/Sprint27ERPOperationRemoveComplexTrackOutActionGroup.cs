﻿using Cmf.Custom.IKEA.Common;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessOrchestration.DynamicExecutionEngineManagement;
using Cmf.Foundation.BusinessOrchestration.DynamicExecutionEngineManagement.InputObjects;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Linq;
using Cmf.Foundation.BusinessOrchestration.Abstractions;
using Microsoft.Extensions.DependencyInjection;

namespace Cmf.Custom.IKEA.Actions.ProcessRules._2._27._0.After
{
    class Sprint27ERPOperationRemoveComplexTrackOutActionGroup : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     
            /// Action Groups:
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion

            return true;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            //System
            UseReference("", "Cmf.Foundation.BusinessOrchestration.Abstractions");
UseReference("", "System");
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");

            //Foundation
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.DynamicExecutionEngineManagement");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.DynamicExecutionEngineManagement.InputObjects");
            
            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
var dynamicExecutionEngineOrchestration = serviceProvider.GetService<IDynamicExecutionEngineOrchestration>();

            var output = dynamicExecutionEngineOrchestration.GetAllActions(new GetAllActionsInput { });

            var action = output.Actions.FirstOrDefault(eachAction => eachAction.Name == "CustomERPOperationTrackingProcess");

            if (action != null)
            {
                action.Load();

                var complexTrackOutActionGroups = action.ActionGroupActions
                    .Where(group => group.ActionGroup.Name == "MaterialManagement.MaterialManagementOrchestration.ComplexTrackOutMaterials.Post")
                    .ToList();

                if (complexTrackOutActionGroups.Any())
                {
                    var actionGroupsCollection = new Foundation.Common.DynamicExecutionEngine.ActionGroupActionCollection();
                    actionGroupsCollection.AddRange(complexTrackOutActionGroups);

                    action.RemoveActionGroups(actionGroupsCollection);
                }
            }

            //---End DEE Code---

            return Input;
        }
    }
}
