﻿using Cmf.Custom.IKEA.Common;
using Cmf.Foundation.BusinessObjects.QueryObject;
using Cmf.Foundation.BusinessObjects.SmartTables;
using Cmf.Foundation.BusinessOrchestration.TableManagement;
using Cmf.Foundation.BusinessOrchestration.TableManagement.InputObjects;
using Cmf.Foundation.BusinessOrchestration.TableManagement.OutputObjects;
using Cmf.Foundation.Common;
using System.Collections.Generic;
using System.Linq;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessOrchestration.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using Cmf.Common.CustomActionUtilities;


namespace Cmf.Custom.IKEA.Actions.ProcessRules.Sprint_31
{
    public class Sprint31AddPrecedenceKeyToCustomOverProductionResolution : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Process Rule to add a new Precedence Key for the Resource and another for the Workcenter in the smart table CustomOverProductionResolution
            /// </summary>
            #endregion

            return true;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            //System
            UseReference("", "Cmf.Foundation.BusinessOrchestration.Abstractions");
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");

            //Foundation
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.TableManagement");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.TableManagement.InputObjects");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.TableManagement.OutputObjects");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects.QueryObject");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects.SmartTables");
            UseReference("Cmf.Foundation.Common.dll", "Cmf.Foundation.Common");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            
            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            var tableOrchestration = serviceProvider.GetService<ITableOrchestration>();

            string tableName = "CustomOverProductionResolution";

            // Get Smart Table by name
            GetSmartTablesByFilterOutput output = tableOrchestration.GetSmartTablesByFilter(new GetSmartTablesByFilterInput()
            {
                Filter = new FilterCollection()
                {
                    new Foundation.BusinessObjects.QueryObject.Filter()
                    {
                        Name = "Name"
                        , Operator = FieldOperator.IsEqualTo
                        , Value = tableName
                    }
                }

            });

            // Check if the smart table was found
            if (output != null && !output.SmartTableCollection.IsNullOrEmpty())
            {
                ISmartTable smartTable = output.SmartTableCollection.First();

                // Load the precedence keys of the smart table
                smartTable.LoadPrecedenceKeys();

                IPrecedenceKeysCollection precedenceKeys = new PrecedenceKeysCollection();

                if (!smartTable.PrecedenceKeys.Any(pk => pk.RuleString == "Resource" || pk.RuleString == "Workcenter"))
                {
                    precedenceKeys.AddRange(smartTable.PrecedenceKeys.Where(pk => pk.RuleOrder >= 13).ToList());
                    precedenceKeys.ToList().ForEach(pk => pk.RuleOrder += 2);

                    // Check if the precedence key already exists
                    if (!smartTable.PrecedenceKeys.Any(pk => pk.RuleString == "Resource"))
                    {
                        // Create the new precedence key for Facility
                        precedenceKeys.Add(new PrecedenceKey()
                        {
                            RuleOrder = 13,
                            RuleString = "Resource"
                        });
                    }

                    // Check if the precedence key already exists
                    if (!smartTable.PrecedenceKeys.Any(pk => pk.RuleString == "WorkCenter"))
                    {
                        // Create the new precedence key for Facility
                        precedenceKeys.Add(new PrecedenceKey()
                        {
                            RuleOrder = 14,
                            RuleString = "WorkCenter"
                        });
                    }

                    // Insert the new precedence key
                    InsertOrUpdatePrecedenceKeysOutput insertOrUpdatePrecedenceKeysOutput = tableOrchestration.InsertOrUpdatePrecedenceKeys(new InsertOrUpdatePrecedenceKeysInput()
                    {
                        SmartTable = smartTable,
                        PrecedenceKeys = precedenceKeys
                    });

                    // Generate the smart table schema
                    tableOrchestration.GenerateSmartTableSchema(new GenerateSmartTableSchemaInput()
                    {
                        SmartTable = insertOrUpdatePrecedenceKeysOutput.SmartTable
                    });
                }
            }

            //---End DEE Code---

            return Input;
        }
    }
}
