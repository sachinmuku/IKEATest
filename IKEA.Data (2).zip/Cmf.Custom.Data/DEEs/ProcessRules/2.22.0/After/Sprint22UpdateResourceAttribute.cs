﻿using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessOrchestration.EntityTypeManagement;
using Cmf.Foundation.BusinessOrchestration.EntityTypeManagement.InputObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessOrchestration.Abstractions;
using Microsoft.Extensions.DependencyInjection;


namespace Cmf.Custom.IKEA.Actions.ProcessRules._2._22._0.After
{
    class Sprint22UpdateResourceAttribute : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            /// Change Access level for the resource Attribute Automation Line Speed threshold Reduced speed,
            /// Action Groups:
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion

            return true;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---
            UseReference("", "Cmf.Foundation.BusinessOrchestration.Abstractions");
UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "");
            UseReference("", "Cmf.Foundation.Common.Exceptions");
            UseReference("", "Cmf.Foundation.Common");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "");
            UseReference("", "Cmf.Foundation.BusinessOrchestration.EntityTypeManagement");
            UseReference("", "Cmf.Foundation.BusinessOrchestration.EntityTypeManagement.InputObjects");
var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
var entityTypeOrchestration = serviceProvider.GetService<IEntityTypeOrchestration>();

            #region Change Attribute Access Level

            var resourceEntityType = entityTypeOrchestration.GetEntityTypeByName(new GetEntityTypeByNameInput { Name = "Resource" }).EntityType;
            resourceEntityType.Load();

            var attribute = resourceEntityType.Properties.FirstOrDefault(props => props.Name == "AutomationLineSpeedThresholdPercentageToSetInReducedSpeed");
            attribute.AccessLevel = 0;

            resourceEntityType = entityTypeOrchestration.FullUpdateEntityType(new FullUpdateEntityTypeInput()
            {
                EntityType = resourceEntityType as IEntityType,
                EntityTypePropertiesToAddOrUpdate = new EntityTypePropertyCollection() { attribute },
            }).EntityType;

            #endregion

            #region Update DB

            entityTypeOrchestration.GenerateEntityTypeDBSchema(new GenerateEntityTypeDBSchemaInput
            {
                EntityType = resourceEntityType as IEntityType
            });

            #endregion
            
            //---End DEE Code---
            return Input;
        }
    }
}
