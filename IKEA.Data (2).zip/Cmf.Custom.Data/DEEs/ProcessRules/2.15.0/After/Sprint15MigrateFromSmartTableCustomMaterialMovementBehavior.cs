﻿
using Cmf.Custom.IKEA.Common;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.SmartTables;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Cmf.Common.CustomActionUtilities;


namespace Cmf.Custom.IKEA.Actions.ProcessRules._2._14._0.After
{
    class Sprint15MigrateFromSmartTableCustomMaterialMovementBehavior : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Migrates any records found in the now deprecated smart table `CustomMaterialMovementBehavior` into the new
            ///     smart table `CustomMaterialMovementConfiguration`. Only runs if the new table is empty, to avoid migrating duplicated data.
            ///     Also adds a prefix to the description of the old table mentioning that it is deprecated.
            ///     
            /// Action Groups:
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion

            return true;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            //System
            UseReference("", "System");
            UseReference("", "System.Linq");
            UseReference("", "System.Data");
            UseReference("", "System.Collections.Generic");

            //Foundation
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects.SmartTables");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.DynamicExecutionEngineManagement");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.DynamicExecutionEngineManagement.InputObjects");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            var oldSmartTable = new SmartTable { Name = "CustomMaterialMovementBehavior" };
            var newSmartTable = new SmartTable { Name = "CustomMaterialMovementConfiguration" };

            if (oldSmartTable.ObjectExists() && newSmartTable.ObjectExists())
            {
                // Load both smart tables
                oldSmartTable.Load();
                newSmartTable.Load();

                #region Add "Deprecated" notice on old table's description
                string deprecatedNotice = "DEPRECATED. Use the newer CustomMaterialMovementConfiguration instead.";

                if (oldSmartTable.Description.IsNullOrEmpty())
                {
                    oldSmartTable.Description = deprecatedNotice;
                    oldSmartTable.Save();
                }
                else if (!oldSmartTable.Description.Contains(deprecatedNotice))
                {
                    oldSmartTable.Description = deprecatedNotice + " " + oldSmartTable.Description;
                    oldSmartTable.Save();
                }
                #endregion

                newSmartTable.LoadData();

                // Only run the migration if the smart table has no data
                if (!newSmartTable.HasData)
                {
                    #region Declare row types for each Smart Table
                    // Value-type tuple with named fields
                    (
                        string Facility,
                        string Area,
                        string Step,
                        string Resource,
                        string MaterialType,
                        string TrackOutAction,
                        bool MovementRequest
                    ) oldRow;

                    // Value-type tuple with named fields
                    (
                        string Facility,
                        string Area,
                        string Step,
                        string Resource,
                        string ProductGroup,
                        string Product,
                        string MaterialType,
                        string Event,
                        string EventAction,
                        bool MovementRequest,
                        CustomWMSOrderRequestType WMSRequest,
                        string DestinationResource
                    ) newRow = default;
                    #endregion

                    oldSmartTable.LoadData();

                    DataSet oldDataSet = NgpDataSet.ToDataSet(oldSmartTable.Data);

                    // Clone copies the table structure but keeps data empty on the new copies
                    DataTable rowsToInsert = NgpDataSet.ToDataSet(newSmartTable.Data).Tables[0].Clone();

                    Action AddRowToNewDataSet = () =>
                    {
                        var dataRow = rowsToInsert.GetNewRow(new Dictionary<string, object>
                        {
                            { "CustomMaterialMovementConfigurationId", 0L },
                            { "Facility", newRow.Facility },
                            { "Area", newRow.Area },
                            { "Step", newRow.Step },
                            { "Resource", newRow.Resource },
                            { "ProductGroup", newRow.ProductGroup },
                            { "Product", newRow.Product },
                            { "MaterialType", newRow.MaterialType },
                            { "Event", newRow.Event },
                            { "EventAction", newRow.EventAction },
                            { "MovementRequest", newRow.MovementRequest },
                            { "WMSRequest", (int)newRow.WMSRequest },
                            { "DestinationResource", newRow.DestinationResource },
                            { "LastServiceHistoryId", -1L },
                            { "LastOperationHistorySeq", -1L },
                        });

                        rowsToInsert.Rows.Add(dataRow);
                    };

                    if (oldDataSet.HasData())
                    {
                        foreach (DataRow row in oldDataSet.Tables[0].Rows)
                        {
                            oldRow = (
                                Facility: row.Field<string>("Facility"),
                                Area: row.Field<string>("Area"),
                                Step: row.Field<string>("Step"),
                                Resource: row.Field<string>("Resource"),
                                MaterialType: row.Field<string>("MaterialType"),
                                TrackOutAction: row.Field<string>("TrackOutAction"),
                                MovementRequest: row.Field<bool?>("MovementRequest") ?? false
                            );

                            // Each row in the old table can correspond to one or two rows in the new table
                            // This happens because when the old TrackOutAction != None, then new EventAction must be TrackOut
                            // And when the old MovementRequest == true, then new EventAction must be StepOut

                            // First possible new row
                            if ((!oldRow.TrackOutAction.IsNullOrEmpty() && oldRow.TrackOutAction != "None") || !oldRow.MovementRequest)
                            {
                                newRow = (
                                    Facility: oldRow.Facility,
                                    Area: oldRow.Area,
                                    Step: oldRow.Step,
                                    Resource: oldRow.Resource,
                                    ProductGroup: null,
                                    Product: null,
                                    MaterialType: oldRow.MaterialType,
                                    Event: "TrackOut",
                                    EventAction: oldRow.TrackOutAction ?? "None",
                                    MovementRequest: false,
                                    WMSRequest: CustomWMSOrderRequestType.None,
                                    DestinationResource: null
                                );

                                // Puts the contents stored in newRow inside the new data set
                                AddRowToNewDataSet();
                            }

                            // Second possible new row
                            if (oldRow.MovementRequest)
                            {
                                newRow = (
                                    Facility: oldRow.Facility,
                                    Area: oldRow.Area,
                                    Step: oldRow.Step,
                                    Resource: oldRow.Resource,
                                    ProductGroup: null,
                                    Product: null,
                                    MaterialType: oldRow.MaterialType,
                                    Event: "StepOut",
                                    EventAction: "None",
                                    MovementRequest: true,
                                    WMSRequest: CustomWMSOrderRequestType.None,
                                    DestinationResource: null
                                );

                                // Puts the contents stored in newRow inside the new data set
                                AddRowToNewDataSet();
                            }
                        }

                        if (rowsToInsert.Rows.Count > 0)
                        {
                            newSmartTable.InsertOrUpdateRows(NgpDataSet.FromDataSet(rowsToInsert.ToDataSet()));
                        }
                    }
                }
            }

            //---End DEE Code---

            return Input;
        }
    }
}
