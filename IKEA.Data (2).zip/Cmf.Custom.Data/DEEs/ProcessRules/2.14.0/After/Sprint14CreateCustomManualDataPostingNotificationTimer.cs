﻿using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Utilities;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Threading;

namespace Cmf.Custom.IKEA.Actions.ProcessRules._2._14._0.After
{
    class Sprint14CreateCustomManualDataPostingNotificationTimer : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {


        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     
            /// Action Groups:
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion

            return true;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            //System
            UseReference("", "System");
            UseReference("", "System.Collections.Generic");

            //Foundation
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            ILocalizedMessage localizedMessage = serviceProvider.GetService<ILocalizedMessage>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            //Get the Rule object
            IRule rule = entityFactory.Create< IRule >();

            rule.Name = IKEAConstants.CustomManualDataPostingNotification;
            

            if (rule.ObjectExists())
            {
                rule.Load();

                //Retrieve timer frequency from config
                int? frequencyMinutes = genericUtilities.GetConfigurationValueByPath<int>(IKEAConstants.CustomManualDataPostingNotificationTimerFrequency);

                //Create Timer
                ICmfTimer ruleTimer = entityFactory.Create<ICmfTimer>();

                ruleTimer.Name = IKEAConstants.CustomManualDataPostingNotificationTimerName;
                ruleTimer.Description = ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomManualDataPostingNotificationTimerDescriptionLocalizedMessage, rule.Name);
                ruleTimer.IsEnabled = true;
                ruleTimer.Start = DateTime.Now.AddSeconds(10); // The start date needs to be a date after the timer is created
                ruleTimer.Recurrence = CmfTimerRecurrence.DefinedSeconds;
                ruleTimer.RecurrenceDefinedSeconds = frequencyMinutes * 60;
                ruleTimer.RecurrenceDefinedFrequency = 1;
                ruleTimer.Rule = rule;
                ruleTimer.Scope = CmfTimerScope.General;
                ruleTimer.SendEmailOnError = false;
                

                if (!ruleTimer.ObjectExists())
                {
                    ruleTimer.Create();
                }
            }

            //---End DEE Code---

            return Input;
        }




    }
}
