using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.SmartTables;
using Cmf.Foundation.BusinessOrchestration.TableManagement.InputObjects;
using Cmf.Foundation.Common;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Linq;
using Cmf.Foundation.BusinessOrchestration.TableManagement;
using Cmf.Foundation.BusinessOrchestration.EntityTypeManagement;
using Cmf.Foundation.BusinessOrchestration.TableManagement.OutputObjects;
using Cmf.Custom.IKEA.Common;
using Cmf.Foundation.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Actions.ProcessRules._3._33._0.Before
{
    public class Sprint31AlterSmartTableCustomMaterialMovementConfiguration : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---

            #region Info

            /* Description:
             *  
             *      It changes the Smart Table 'Custom MAO Handling OEE' 
             *      to handle multiple values for the same precedence keys
             * 
            */

            #endregion
            

            ISmartTable customMaoHandlingOee = new SmartTable();
            customMaoHandlingOee.Load(IKEAConstants.CustomMAOHandlingOEEState);

            if (customMaoHandlingOee == null)
            {
                return false;
            }

            if (customMaoHandlingOee.IsRepeatedValuesAllowed == true)
            {
                return false;
            }

            return true;
            //---End DEE Condition Code---
        }

        /// <summary>
        /// Dees the action code.
        /// </summary>
        /// <param name="Input">The input.</param>
        /// <returns></returns>
        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---

            UseReference("", "Cmf.Foundation.Common.Exceptions");

            //Foundation
            UseReference("Cmf.Foundation.BusinessObjects.dll", "");
            UseReference("", "Cmf.Foundation.BusinessObjects");
            UseReference("", "Cmf.Foundation.BusinessObjects.SmartTables");
            UseReference("", "Cmf.Foundation.BusinessObjects.QueryObject");
            UseReference("", "Cmf.Foundation.BusinessOrchestration.TableManagement.InputObjects");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            ISmartTable customMaoHandlingOee = new SmartTable();
            customMaoHandlingOee.Load(IKEAConstants.CustomMAOHandlingOEEState);

            customMaoHandlingOee.IsRepeatedValuesAllowed = true;
            customMaoHandlingOee.Save();
            customMaoHandlingOee.GenerateSchema();

            //---End DEE Code---

            return Input;
        }
    }
}
