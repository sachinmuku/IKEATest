﻿using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.GenericTables;
using Cmf.Foundation.BusinessObjects.QueryObject;
using Cmf.Foundation.BusinessOrchestration.TableManagement;
using Cmf.Foundation.BusinessOrchestration.TableManagement.InputObjects;
using Cmf.Foundation.BusinessOrchestration.TableManagement.OutputObjects;
using Cmf.Foundation.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessOrchestration.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Foundation.BusinessOrchestration.EntityTypeManagement.InputObjects;
using Cmf.Foundation.Common.Base;

namespace Cmf.Custom.IKEA.Actions.ProcessRules._4._0._2.Before
{
    public class UpdateEnumPropertiesForResourceEntity : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<String, Object> Input)
        {
            //---Start DEE Condition Code---

            return true;

            //---End DEE Condition Code---  
        }

        public override Dictionary<String, Object> EvaluateRule(Dictionary<String, Object> Input)
        {
            //---Start DEE Code---

            UseReference("", "Cmf.Foundation.BusinessOrchestration.Abstractions");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.EntityTypeManagement");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.EntityTypeManagement.InputObjects");

            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            var entityTypeOrchestration = serviceProvider.GetService<IEntityTypeOrchestration>();

            IEntityType entityResource = new EntityType
            {
                Name = "Resource"
            };

            if (entityResource.ObjectExists())
            {
                entityResource.Load();
                entityResource.LoadProperties();

                // If entity is still in Created or Active state, load the properties to check their access level...
                if (entityResource.UniversalState == UniversalState.Created || entityResource.UniversalState == UniversalState.Active)
                {
                    // Collection that will contain properties which might need to be updated
                    IEntityTypePropertyCollection propertiesToUpdate = new EntityTypePropertyCollection();

                    #region Check Enum Properties

                    // UnitCompletionMode Property
                    IEntityTypeProperty automationPalletOutMode = entityResource.Properties.FirstOrDefault(E => E.Name == "AutomationPalletOutMode") as IEntityTypeProperty;
                    if (automationPalletOutMode != null && automationPalletOutMode.ReferenceName != "Cmf.Custom.IKEA.Common.Enums.CustomPalletOutModeEnum")
                    {
                        automationPalletOutMode.ReferenceName = "Cmf.Custom.IKEA.Common.Enums.CustomPalletOutModeEnum";

                        propertiesToUpdate.Add(automationPalletOutMode);
                    }

                    // AutomationCompletionCounterType Property
                    IEntityTypeProperty automationCompletionCounterType = entityResource.Properties.FirstOrDefault(E => E.Name == "AutomationCompletionCounterType") as IEntityTypeProperty;
                    if (automationCompletionCounterType != null && automationCompletionCounterType.ReferenceName != "Cmf.Custom.IKEA.Common.Enums.CustomAutomationCompletionCounterTypeEnum")
                    {
                        automationCompletionCounterType.ReferenceName = "Cmf.Custom.IKEA.Common.Enums.CustomAutomationCompletionCounterTypeEnum";

                        propertiesToUpdate.Add(automationCompletionCounterType);
                    }

                    // AutomationTrackingMode Property
                    IEntityTypeProperty automationTrackingMode = entityResource.Properties.FirstOrDefault(E => E.Name == "AutomationTrackingMode") as IEntityTypeProperty;
                    if (automationTrackingMode != null && automationTrackingMode.ReferenceName != "Cmf.Custom.IKEA.Common.Enums.CustomAutomationTrackingModeEnum")
                    {
                        automationTrackingMode.ReferenceName = "Cmf.Custom.IKEA.Common.Enums.CustomAutomationTrackingModeEnum";

                        propertiesToUpdate.Add(automationTrackingMode);
                    }

                    // FeederConsumptionMode Property
                    IEntityTypeProperty feederConsumptionMode = entityResource.Properties.FirstOrDefault(E => E.Name == "FeederConsumptionMode") as IEntityTypeProperty;
                    if (feederConsumptionMode != null && feederConsumptionMode.ReferenceName != "Cmf.Custom.IKEA.Common.Enums.CustomFeederConsumptionModeEnum")
                    {
                        feederConsumptionMode.ReferenceName = "Cmf.Custom.IKEA.Common.Enums.CustomFeederConsumptionModeEnum";

                        propertiesToUpdate.Add(feederConsumptionMode);
                    }

                    // InterlockAdmissionState Property
                    IEntityTypeProperty interlockAdmissionState = entityResource.Properties.FirstOrDefault(E => E.Name == "InterlockAdmissionState") as IEntityTypeProperty;
                    if (interlockAdmissionState != null && interlockAdmissionState.ReferenceName != "Cmf.Custom.IKEA.Common.Enums.CustomInterlockAdmissionStateEnum")
                    {
                        interlockAdmissionState.ReferenceName = "Cmf.Custom.IKEA.Common.Enums.CustomInterlockAdmissionStateEnum";

                        propertiesToUpdate.Add(interlockAdmissionState);
                    }

                    // SecurityMode Property
                    IEntityTypeProperty securityMode = entityResource.Properties.FirstOrDefault(E => E.Name == "SecurityMode") as IEntityTypeProperty;
                    if (securityMode != null && securityMode.ReferenceName != "Cmf.Custom.IKEA.Common.Enums.CustomSecurityModeEnum")
                    {
                        securityMode.ReferenceName = "Cmf.Custom.IKEA.Common.Enums.CustomSecurityModeEnum";

                        propertiesToUpdate.Add(securityMode);
                    }

                    // SecurityPolicy Property
                    IEntityTypeProperty securityPolicy = entityResource.Properties.FirstOrDefault(E => E.Name == "SecurityPolicy") as IEntityTypeProperty;
                    if (securityPolicy != null && securityPolicy.ReferenceName != "Cmf.Custom.IKEA.Common.Enums.CustomSecurityPolicyEnum")
                    {
                        securityPolicy.ReferenceName = "Cmf.Custom.IKEA.Common.Enums.CustomSecurityPolicyEnum";

                        propertiesToUpdate.Add(securityPolicy);
                    }

                    // UnitCompletionMode Property
                    IEntityTypeProperty unitCompletionMode = entityResource.Properties.FirstOrDefault(E => E.Name == "UnitCompletionMode") as IEntityTypeProperty;
                    if (unitCompletionMode != null && unitCompletionMode.ReferenceName != "Cmf.Custom.IKEA.Common.Enums.CustomUnitCompletionModeEnum")
                    {
                        unitCompletionMode.ReferenceName = "Cmf.Custom.IKEA.Common.Enums.CustomUnitCompletionModeEnum";

                        propertiesToUpdate.Add(unitCompletionMode);
                    }

                    if (propertiesToUpdate.Count > 0)
                    {
                        entityResource = entityTypeOrchestration.UpdateEntityTypeProperties(new UpdateEntityTypePropertiesInput()
                        {
                            EntityType = entityResource,
                            EntityTypeProperties = propertiesToUpdate
                        }).EntityType;

                        #region Generate Schema

                        entityTypeOrchestration.GenerateEntityTypeDBSchema(new GenerateEntityTypeDBSchemaInput
                        {
                            EntityType = entityResource
                        });

                        entityResource.Load();

                        #endregion
                    }
                    #endregion
                }
            }

            //---End DEE Code---

            return null;
        }
    }
}