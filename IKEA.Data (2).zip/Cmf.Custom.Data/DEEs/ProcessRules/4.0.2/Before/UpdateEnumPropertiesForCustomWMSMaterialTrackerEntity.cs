﻿using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.GenericTables;
using Cmf.Foundation.BusinessObjects.QueryObject;
using Cmf.Foundation.BusinessOrchestration.TableManagement;
using Cmf.Foundation.BusinessOrchestration.TableManagement.InputObjects;
using Cmf.Foundation.BusinessOrchestration.TableManagement.OutputObjects;
using Cmf.Foundation.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessOrchestration.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Foundation.BusinessOrchestration.EntityTypeManagement.InputObjects;
using Cmf.Foundation.Common.Base;

namespace Cmf.Custom.IKEA.Actions.ProcessRules._4._0._2.Before
{
    public class UpdateEnumPropertiesForCustomWMSMaterialTrackerEntity : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<String, Object> Input)
        {
            //---Start DEE Condition Code---

            return true;

            //---End DEE Condition Code---  
        }

        public override Dictionary<String, Object> EvaluateRule(Dictionary<String, Object> Input)
        {
            //---Start DEE Code---

            UseReference("", "Cmf.Foundation.BusinessOrchestration.Abstractions");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.EntityTypeManagement");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.EntityTypeManagement.InputObjects");

            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            var entityTypeOrchestration = serviceProvider.GetService<IEntityTypeOrchestration>();

            IEntityType entityResource = new EntityType
            {
                Name = "CustomWMSMaterialTracker"
            };

            if (entityResource.ObjectExists())
            {
                entityResource.Load();
                entityResource.LoadProperties();

                // If entity is still in Created or Active state, load the properties to check their access level...
                if (entityResource.UniversalState == UniversalState.Created || entityResource.UniversalState == UniversalState.Active)
                {
                    // Collection that will contain properties which might need to be updated
                    IEntityTypePropertyCollection propertiesToUpdate = new EntityTypePropertyCollection();

                    #region Check Enum Properties

                    // OrderRequestType Property
                    IEntityTypeProperty orderRequestType = entityResource.Properties.FirstOrDefault(E => E.Name == "OrderRequestType") as IEntityTypeProperty;
                    if (orderRequestType != null && orderRequestType.ReferenceName != "Cmf.Custom.IKEA.Common.Enums.CustomWMSOrderRequestType")
                    {
                        orderRequestType.ReferenceName = "Cmf.Custom.IKEA.Common.Enums.CustomWMSOrderRequestType";

                        propertiesToUpdate.Add(orderRequestType);
                    }

                    if (propertiesToUpdate.Count > 0)
                    {
                        entityResource = entityTypeOrchestration.UpdateEntityTypeProperties(new UpdateEntityTypePropertiesInput()
                        {
                            EntityType = entityResource,
                            EntityTypeProperties = propertiesToUpdate
                        }).EntityType;

                        #region Generate Schema

                        entityTypeOrchestration.GenerateEntityTypeDBSchema(new GenerateEntityTypeDBSchemaInput
                        {
                            EntityType = entityResource
                        });

                        entityResource.Load();

                        #endregion
                    }
                    #endregion
                }
            }

            //---End DEE Code---

            return null;
        }
    }
}