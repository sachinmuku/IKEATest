﻿using Cmf.Foundation.BusinessOrchestration.DynamicExecutionEngineManagement.InputObjects;
using Cmf.Foundation.Common.DynamicExecutionEngine;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Foundation.BusinessOrchestration.Abstractions;
using Microsoft.Extensions.DependencyInjection;

namespace Cmf.Custom.IKEA.Actions.ProcessRules._2._43._0.After
{
    public class Sprint43ChangeOrderOfCustomCalculateMESLeftOversByCycle : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            return true;

            //---End DEE Condition Code---
        }

        public override Dictionary<String, Object> EvaluateRule(Dictionary<String, Object> Input)
        {
            //---Start DEE Code---
            //System
            UseReference("", "Cmf.Foundation.BusinessOrchestration.Abstractions");
UseReference("", "System");
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");

            //Foundation
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.DynamicExecutionEngineManagement");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.DynamicExecutionEngineManagement.InputObjects");
            UseReference("Cmf.Foundation.Common.dll", "Cmf.Foundation.Common.DynamicExecutionEngine");
var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
var dynamicExecutionEngineOrchestration = serviceProvider.GetService<IDynamicExecutionEngineOrchestration>();

            string actionGroupName = "MaterialManagement.MaterialManagementOrchestration.ComplexTrackInMaterials.Post";

            string actionName = "CustomCalculateMESLeftOversByCycle";

            IActionGroup ag = new ActionGroup();
            ag.Load(actionGroupName);

            GetActionGroupActionsFromActionGroupInput inputGet = new GetActionGroupActionsFromActionGroupInput()
            {
                ActionGroup = ag
            };

            IActionGroupActionCollection agas = dynamicExecutionEngineOrchestration.GetActionGroupActionsFromActionGroup(inputGet).ActionGroupActions;


            if (agas != null && agas.Count > 0)
            {
                foreach (IActionGroupAction aga in agas)
                {
                    if (aga.Action.Name == actionName)
                    {
                        aga.EvaluateOrder = agas.Count;
                    }
                    else
                    {
                        aga.EvaluateOrder = aga.EvaluateOrder - 1;
                    }
                }


                UpdateActionGroupActionsInput input = new UpdateActionGroupActionsInput()
                {
                    ActionGroup = ag,
                    ActionGroupActions = agas
                };

                dynamicExecutionEngineOrchestration.UpdateActionGroupActions(input);

            }



            //---End DEE Code---
            return null;
        }
    }
}
