﻿using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Data;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.GenericTables;
using Cmf.Foundation.BusinessObjects.SmartTables;
using Cmf.Foundation.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Actions.ProcessRules.Permanent.Before
{
    public class CustomRemoveDefaultSapIntegrationHandler : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<String, Object> Input)
        {
            //---Start DEE Condition Code---

            return true;

            //---End DEE Condition Code---  
        }

        public override Dictionary<String, Object> EvaluateRule(Dictionary<String, Object> Input)
        {
            //---Start DEE Code---

            // System
            UseReference("System.Data.dll", "System.Data");
            UseReference("%MicrosoftNetPath%\\System.Xml.dll", "System.Xml");

            // Foundation
            UseReference("", "Cmf.Foundation.BusinessObjects.QueryObject");
            UseReference("", "Cmf.Foundation.BusinessObjects.GenericTables");
            UseReference("", "Cmf.Foundation.BusinessObjects.SmartTables");
            
            // Select and delete default sap integration rows in GenericTable IntegrationHandler
            IGenericTable gt = new GenericTable();
            gt.Load("IntegrationHandler");
            gt.LoadData(new Foundation.BusinessObjects.QueryObject.FilterCollection { new Foundation.BusinessObjects.QueryObject.Filter { Name = "Name", Value = "SapIntegrationHandler" } });

            DataSet gtDs = NgpDataSet.ToDataSet(gt.Data);
            if (gtDs.Tables[0].Rows.Count == 1)
            {
                gt.RemoveRows(NgpDataSet.FromDataSet(gtDs));
            }

            // Select and delete default sap integration rows in SmartTable IntegrationHandlerResolution
            ISmartTable st = new SmartTable();
            st.Load("IntegrationHandlerResolution");
            st.LoadData(new Foundation.BusinessObjects.QueryObject.FilterCollection { new Foundation.BusinessObjects.QueryObject.Filter { Name = "HandlerType", Value = "SapIntegrationHandler" } });

            DataSet stDs = NgpDataSet.ToDataSet(st.Data);
            if(stDs.Tables[0].Rows.Count == 2)
            {
                st.RemoveRows(NgpDataSet.FromDataSet(stDs));
            }

            //---End DEE Code---

            return null;
        }
    }
}
