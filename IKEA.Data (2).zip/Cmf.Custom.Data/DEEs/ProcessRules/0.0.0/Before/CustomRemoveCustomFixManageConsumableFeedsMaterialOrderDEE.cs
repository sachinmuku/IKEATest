﻿using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Linq;

using Cmf.Foundation.BusinessOrchestration.DynamicExecutionEngineManagement;
using Cmf.Foundation.BusinessOrchestration.DynamicExecutionEngineManagement.InputObjects;
using Cmf.Foundation.BusinessOrchestration.DynamicExecutionEngineManagement.OutputObjects;
using Cmf.Foundation.BusinessOrchestration.Abstractions;
using Microsoft.Extensions.DependencyInjection;

namespace Cmf.Custom.IKEA.Actions.ProcessRules.Permanent.Before
{
    public class CustomFixManageConsumableFeedsMaterialOrderDEE : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     
            /// Action Groups:
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion

            return true;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            UseReference("", "Cmf.Foundation.BusinessOrchestration.Abstractions");
UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.DynamicExecutionEngineManagement.OutputObjects");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.DynamicExecutionEngineManagement");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.DynamicExecutionEngineManagement.InputObjects");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "");
            UseReference("", "Cmf.Foundation.Common.Exceptions");
            UseReference("", "Cmf.Foundation.Common");
var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
var dynamicExecutionEngineOrchestration = serviceProvider.GetService<IDynamicExecutionEngineOrchestration>();

            string deeActionName = "CustomFixManageConsumableFeedsMaterialOrder";

            GetAllActionsOutput getAllActionsOutput = dynamicExecutionEngineOrchestration.GetAllActions(new GetAllActionsInput());
            
            if (getAllActionsOutput.Actions != null)
            {
                var actionToDelete = getAllActionsOutput.Actions.FirstOrDefault(E => String.Equals(E.Name, deeActionName, StringComparison.InvariantCultureIgnoreCase));
                
                if (actionToDelete != null)
                {
                    dynamicExecutionEngineOrchestration.RemoveAction(new RemoveActionInput()
                    {
                        Action = actionToDelete,
                        IsToRemoveAllVersions = true
                    });

                    Console.WriteLine(String.Format("{0} successfully removed.", actionToDelete.Name));
                }
            }

            //---End DEE Code---

            return Input;
        }
    }
}
