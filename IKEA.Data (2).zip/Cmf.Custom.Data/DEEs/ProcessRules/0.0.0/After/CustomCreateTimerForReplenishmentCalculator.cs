﻿using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Threading;


namespace Cmf.Custom.IKEA.Actions.ProcessRules.Permanent.After
{
    public class CustomCreateTimerForReplenishmentCalculator : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Process Rule to create timer to require replenishment of a stocking point
            /// </summary>
            #endregion

            return true;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            //System
            UseReference("", "System.Collections.Generic");
            UseReference("", "System");

            //Foundation
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");

            //Foundation
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.Common.dll", "Cmf.Foundation.Common");
            UseReference("Cmf.Foundation.Security.dll", "Cmf.Foundation.Security");

            //Navigo
            UseReference("Cmf.Navigo.Common.dll", "Cmf.Navigo.Common");
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaintenanceManagement");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaintenanceManagement.InputObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaintenanceManagement.OutputObjects");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];

            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            ILocalizedMessage localizedMessage = serviceProvider.GetService<ILocalizedMessage>();

            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            // Get Rule object to set in CmfTimer
            IRule rule = entityFactory.Create<IRule>();

            rule.Name = IKEAConstants.CustomReplenishmentOfStockingPoints;


            // Check if there is a rule with the given name
            if (rule.ObjectExists())
            {
                rule.Load();

                int frequency = genericUtilities.GetConfigurationValueByPath<int>(IKEAConstants.StockingPointReplenishmentTimerFrequencyConfig);

                // Create Timer
                ICmfTimer timer = entityFactory.Create<ICmfTimer>();

                timer.Name = IKEAConstants.CustomReplenishmentOfStockingPoints;
                timer.Description = localizedMessage.LoadLocalizedMessage(Thread.CurrentThread.CurrentCulture.Name, IKEAConstants.CustomReplenishmentOfStockingPointsTimerDescriptionMessage).MessageText;
                timer.IsEnabled = true;
                timer.Start = DateTime.Now.AddSeconds(10); // The start date needs to be a date after the timer is created
                timer.Recurrence = CmfTimerRecurrence.DefinedSeconds;
                timer.RecurrenceDefinedSeconds = frequency;
                timer.RecurrenceDefinedFrequency = 1;
                timer.Rule = rule;
                timer.Scope = CmfTimerScope.General;
                timer.SendEmailOnError = false;


                if (!timer.ObjectExists())
                {
                    timer.Create();
                }
            }

            //---End DEE Code---

            return Input;
        }
    }
}
