﻿using Cmf.Foundation.BusinessObjects;
using System.Collections.Generic;
using Cmf.Foundation.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Actions.ProcessRules.Permanent.After
{
    /// <summary>
    /// Process Rule to change the Synchronicity of all the Material Name Generators
    /// </summary>
    public class CustomChangeNameGeneratorSynchronicity : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text:
            ///      Process Rule to change the Synchronicity of all the Material Name Generators
            /// </summary>
            #endregion

            return true;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            //System
            UseReference("", "System.Collections.Generic");
            UseReference("", "System");

            //Foundation
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
        
            // Names of all the name generators to be changed
            List<string> nameGenerators = new List<string>()
            {
                "CustomMaterialNameGenerator",
                "CustomMOMaterialNameGenerator",
                "CustomPalletMaterialNameGenerator"
            };

            // The name generators need to be change one-by-one 
            // because there isn't a way to save by collection
            foreach (string nameGeneratorName in nameGenerators)
            {
                INameGenerator nameGenerator = new NameGenerator();
                nameGenerator.Load(nameGeneratorName);
                nameGenerator.IsSynchronous = true;
                nameGenerator.Save();
            }

            //---End DEE Code---

            return Input;
        }
    }
}
