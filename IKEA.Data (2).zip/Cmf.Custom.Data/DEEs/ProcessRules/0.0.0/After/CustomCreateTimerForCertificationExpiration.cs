﻿using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessObjects.Cultures;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Threading;

namespace Cmf.Custom.IKEA.Actions.ProcessRules.Permanent.After
{
    /// <summary>
    /// Process Rule to create timer to notify when a certification is about to expire
    /// </summary>
    public class CustomCreateTimerForCertificationExpiration : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text:
            ///      Process Rule to create timer to notify when a certification is about to expire
            /// </summary>
            #endregion

            return true;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            //System
            UseReference("", "System.Collections.Generic");
            UseReference("", "System");
            //Foundation
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");

            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "");
            UseReference("", "Cmf.Foundation.Common.Exceptions");
            UseReference("", "Cmf.Foundation.Common");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            
            ILocalizedMessage localizedMessage = serviceProvider.GetService<ILocalizedMessage>();
            // Get Rule object to set in CmfTimer
            IRule rule = entityFactory.Create<IRule> ();
           
            rule.Name = IKEAConstants.CustomNotifyCertificationExpiration;
            

            // Check if there is a rule with the given name
            if (rule.ObjectExists())
            {
                rule.Load();

                // Create Timer
                ICmfTimer timer = entityFactory.Create< ICmfTimer > ();

                timer.Name = IKEAConstants.CustomNotifyCertificationExpiration;
                timer.Description = localizedMessage.LoadLocalizedMessage(Thread.CurrentThread.CurrentCulture.Name, IKEAConstants.CustomTimerDescriptionMessage).MessageText;
                timer.IsEnabled = true;
                timer.Start = DateTime.Now.AddSeconds(10); // The start date needs to be a date after the timer is created
                timer.Recurrence = CmfTimerRecurrence.Daily;
                timer.RecurrenceDefinedFrequency = 1;
                timer.Rule = rule;
                timer.Scope = CmfTimerScope.General;
                timer.SendEmailOnError = false;
                

                if (!timer.ObjectExists())
                {
                    timer.Create();
                }
            }

            //---End DEE Code---

            return Input;
        }
    }
}
