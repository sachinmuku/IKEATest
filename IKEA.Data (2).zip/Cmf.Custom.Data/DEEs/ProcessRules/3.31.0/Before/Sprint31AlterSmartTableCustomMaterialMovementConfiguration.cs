using Cmf.Custom.IKEA.Common;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessObjects.SmartTables;
using Cmf.Foundation.BusinessOrchestration.Abstractions;
using Cmf.Foundation.BusinessOrchestration.EntityTypeManagement;
using Cmf.Foundation.BusinessOrchestration.TableManagement;
using Cmf.Foundation.BusinessOrchestration.TableManagement.InputObjects;
using Cmf.Foundation.BusinessOrchestration.TableManagement.OutputObjects;
using Cmf.Foundation.Common;
using Microsoft.Extensions.DependencyInjection;
using Org.BouncyCastle.Math.EC;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.ProcessRules._3._31._0.Before
{
    public class Sprint31AlterSmartTableCustomMaterialMovementConfiguration : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---

            #region Info

            /* Description:
             *  
             *      It will add 1 columns to Smart Table CustomMaterialMovementConfiguration
             * 
            */

            #endregion

            return true;

            //---End DEE Condition Code---
        }

        /// <summary>
        /// Dees the action code.
        /// </summary>
        /// <param name="Input">The input.</param>
        /// <returns></returns>
        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---

            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "");
            UseReference("", "Cmf.Foundation.Common.Exceptions");
            UseReference("", "Cmf.Foundation.Common");
            UseReference("", "Cmf.Foundation.BusinessObjects.SmartTables");
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("", "Cmf.Foundation.BusinessObjects.Cultures");
            UseReference("", "Cmf.Foundation.BusinessObjects.QueryObject");
            UseReference("", "Cmf.Foundation.BusinessOrchestration.GenericServiceManagement.InputObjects");
            UseReference("", "Cmf.Foundation.BusinessOrchestration.GenericServiceManagement.OutputObjects");
            UseReference("", "Cmf.Foundation.BusinessOrchestration.TableManagement.InputObjects");
            UseReference("", "Cmf.Foundation.BusinessOrchestration.EntityTypeManagement");
            UseReference("", "Cmf.Foundation.BusinessOrchestration.TableManagement");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            
            UseReference("", "Cmf.Foundation.BusinessOrchestration.TableManagement.OutputObjects");
            UseReference("", "Cmf.Foundation.BusinessObjects.Abstractions");

            #region Load Smarttable
            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            var tableOrchestration = serviceProvider.GetService<ITableOrchestration>();
            const string smartTableName = IKEAConstants.CustomMaterialMovementConfigurationSmartTable;

            bool isToSave = false;
            SmartTable smartTable = new SmartTable();
            PrecedenceKeysCollection precedenceKeysCollection = new PrecedenceKeysCollection();
            SmartTablePropertiesCollection propertiesToAddCollection = new SmartTablePropertiesCollection();

            smartTable.Load(smartTableName);
            smartTable.LoadProperties();
            smartTable.LoadPrecedenceKeys();

            #endregion

            if (smartTable.SmartTableProperties != null
                && smartTable.SmartTableProperties.Count > 0
                && (!smartTable.SmartTableProperties.Any(prop => prop.Name.Equals(IKEAConstants.CustomMaterialMovementConfigurationResourceToAttach))))
            {
                #region insert new columns

                int position = smartTable.SmartTableProperties.Max(prop => prop.Position);

                ScalarType sType = new ScalarType();
                sType.Load("NVarChar");

                IEntityType resourceEntityType = new EntityType()
                {
                    Name = "Resource"
                };
                resourceEntityType.Load();

                IEntityTypeProperty resourceNameProperty = resourceEntityType.Properties.Where(x => x.Name == "Name").FirstOrDefault();
                resourceNameProperty.Load();

                ISmartTableProperty stPropertyToAdd = new SmartTableProperty
                {
                    Name = IKEAConstants.CustomMaterialMovementConfigurationResourceToAttach,
                    Description = smartTableName + " - " + IKEAConstants.CustomMaterialMovementConfigurationResourceToAttach,
                    ReferenceType = ReferenceType.EntityType,
                    ReferenceTypeId = resourceEntityType.Id,
                    ReferencePropertyId = resourceNameProperty.Id,
                    IsKey = false,
                    IsIndexed = false,
                    IsMandatory = false,
                    ScalarType = sType,
                    Size = 512,
                    Position = position + 1
                };

                propertiesToAddCollection.Add(stPropertyToAdd);

                #endregion

                isToSave = true;
            }

            #region Save

            if (isToSave)
            {
                tableOrchestration.FullUpdateSmartTable(new FullUpdateSmartTableInput
                {
                    SmartTable = smartTable,
                    PrecedenceKeysToAddOrUpdate = precedenceKeysCollection,
                    PropertiesToAddOrUpdate = propertiesToAddCollection
                });

                smartTable.Load();
                GenerateSmartTableSchemaInput generateSTSchema = new GenerateSmartTableSchemaInput();
                generateSTSchema.SmartTable = smartTable;
                tableOrchestration.GenerateSmartTableSchema(generateSTSchema);
            }

            #endregion

            //---End DEE Code---

            return Input;
        }
    }
}
