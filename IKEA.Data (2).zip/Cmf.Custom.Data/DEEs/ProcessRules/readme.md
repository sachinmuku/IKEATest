*** Folder naming convention should be like

 - PackageName              Example '1.0.0'
 - SomeText PackageVersion  Example 'Package 1.0.0'