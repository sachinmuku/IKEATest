﻿using Cmf.Custom.IKEA.Common;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.QueryObject;
using Cmf.Foundation.BusinessObjects.SmartTables;
using Cmf.Foundation.BusinessOrchestration.TableManagement;
using Cmf.Foundation.BusinessOrchestration.TableManagement.InputObjects;
using Cmf.Foundation.BusinessOrchestration.TableManagement.OutputObjects;
using Cmf.Foundation.Common;
using System.Collections.Generic;
using System.Linq;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessOrchestration.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using Cmf.Common.CustomActionUtilities;


namespace Cmf.Custom.IKEA.Actions.ProcessRules.Sprint_30.After
{
    public class Sprint30AddOrderTypeAndStructureTypeToCustomBOMTemplateHandle : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text:
            ///     Process Rule to add OrderType And StructureType to CustomBOMTemplateHandle
            /// </summary>
            #endregion

            return true;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            //System
            UseReference("", "Cmf.Foundation.BusinessOrchestration.Abstractions");
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");

            //Foundation
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.TableManagement");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.TableManagement.InputObjects");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.TableManagement.OutputObjects");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects.QueryObject");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects.SmartTables");
            UseReference("Cmf.Foundation.Common.dll", "Cmf.Foundation.Common");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            var tableOrchestration = serviceProvider.GetService<ITableOrchestration>();

            string tableName = "CustomBOMTemplateHandler";
            string propertyOrderType = "OrderType";
            string propertyStructureType = "StructureType";

            // Get Smart Table by name
            GetSmartTablesByFilterOutput output = tableOrchestration.GetSmartTablesByFilter(new GetSmartTablesByFilterInput()
            {
                Filter = new FilterCollection()
                {
                    new Foundation.BusinessObjects.QueryObject.Filter()
                    {
                        Name = "Name"
                        , Operator = FieldOperator.IsEqualTo
                        , Value = tableName
                    }
                }

            });

            // Check if the smart table was found
            if (output != null && !output.SmartTableCollection.IsNullOrEmpty())
            {
                ISmartTable smartTable = output.SmartTableCollection.First();

                // Load the properties of the smart table
                smartTable.LoadProperties();

                // Check if the precedence key already exists
                if (!smartTable.SmartTableProperties.Any(pk => pk.Name == propertyOrderType)
                    && !smartTable.SmartTableProperties.Any(pk => pk.Name == propertyStructureType))
                {
                    ISmartTablePropertiesCollection properties = new SmartTablePropertiesCollection();
                    // Get all the properties that are from the position 4 forward so that we can update its order
                    properties.AddRange(smartTable.SmartTableProperties.Where(pk => pk.Position >= 4).ToList());
                    properties.ToList().ForEach(pk => pk.Position += 2);

                    IScalarType nvarcharScalarType = new ScalarType();
                    nvarcharScalarType.Load("NVarChar");

                    // Get Smart Table by name
                    GetLookupTableByNameOutput getLookupTableByName = tableOrchestration.GetLookupTableByName(new GetLookupTableByNameInput()
                    {
                        Name = "ProductionOrderType"
                    });

                    ILookupTable lookupTable = getLookupTableByName.LookupTable;

                    properties.Add(new SmartTableProperty()
                    {
                        Name = "OrderType",
                        Position = 4,
                        Description = "Production Order Type",
                        IsKey = true,
                        IsIndexed = false,
                        IsMandatory = false,
                        ScalarType = nvarcharScalarType,
                        Size = 512,
                        ReferenceType = ReferenceType.LookupValue,
                        ReferenceTypeId = lookupTable.Id
                    });

                    properties.Add(new SmartTableProperty()
                    {
                        Name = "StructureType",
                        Position = 5,
                        Description = "Structure Type",
                        IsKey = true,
                        IsIndexed = false,
                        IsMandatory = false,
                        ScalarType = nvarcharScalarType,
                        Size = 512,
                        ReferenceType = ReferenceType.None
                    });

                    // Get all the precedence keys that are from the position forward so that we can update its order
                    IPrecedenceKeysCollection precedenceKeys = new PrecedenceKeysCollection();
                    precedenceKeys.AddRange(smartTable.PrecedenceKeys.Where(pk => pk.RuleOrder >= 6).ToList());
                    precedenceKeys.ToList().ForEach(pk => pk.RuleOrder += 3);

                    // Create the new precedence key for OrderType
                    precedenceKeys.Add(new PrecedenceKey()
                    {
                        RuleOrder = 6,
                        RuleString = "OrderType+Product"
                    });

                    // Create the new precedence key for StructureType
                    precedenceKeys.Add(new PrecedenceKey()
                    {
                        RuleOrder = 7,
                        RuleString = "StructureType+Product"
                    });

                    // Create the new precedence key for StructureType
                    precedenceKeys.Add(new PrecedenceKey()
                    {
                        RuleOrder = 8,
                        RuleString = "OrderType+StructureType+Product"
                    });

                    // Update properties and Precedence Keys of the smart table
                    FullUpdateSmartTableOutput fullUpdateSmartTableOutput = tableOrchestration.FullUpdateSmartTable(new FullUpdateSmartTableInput()
                    {
                        SmartTable = smartTable,
                        PropertiesToAddOrUpdate = properties,
                        PrecedenceKeysToAddOrUpdate = precedenceKeys
                    });

                    // Generate the smart table schema
                    tableOrchestration.GenerateSmartTableSchema(new GenerateSmartTableSchemaInput()
                    {
                        SmartTable = fullUpdateSmartTableOutput.SmartTable
                    });
                }
            }
            //---End DEE Code---

            return Input;
        }
    }
}
