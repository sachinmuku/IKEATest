﻿using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.GenericTables;
using Cmf.Foundation.BusinessObjects.QueryObject;
using Cmf.Foundation.BusinessOrchestration.TableManagement;
using Cmf.Foundation.BusinessOrchestration.TableManagement.InputObjects;
using Cmf.Foundation.BusinessOrchestration.TableManagement.OutputObjects;
using Cmf.Foundation.Common;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessOrchestration.Abstractions;
using Microsoft.Extensions.DependencyInjection;

namespace Cmf.Custom.IKEA.Actions.ProcessRules.Sprint_24.Before
{
    public class Sprint24AddNewScanningConfigurationTokens : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<String, Object> Input)
        {
            //---Start DEE Condition Code---

            return true;

            //---End DEE Condition Code---  
        }

        public override Dictionary<String, Object> EvaluateRule(Dictionary<String, Object> Input)
        {
            //---Start DEE Code---

            // Foundation
            UseReference("", "Cmf.Foundation.BusinessOrchestration.Abstractions");
UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects.GenericTables");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects.QueryObject");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.TableManagement");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.TableManagement.InputObjects");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.TableManagement.OutputObjects");
            UseReference("Cmf.Foundation.Common.dll", "Cmf.Foundation.Common");
            UseReference("", "Cmf.Foundation.Common.Exceptions");
            UseReference("", "Cmf.Foundation.Common");
var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
var tableOrchestration = serviceProvider.GetService<ITableOrchestration>();

            // table and columns to add
            string tableName = "CustomScanningConfigurationToken";
            string[] expectedColumnNames = { "LeadFiller", "ParserRule" };

            // Get table name with expected name
            GetGenericTablesByFilterOutput output = tableOrchestration.GetGenericTablesByFilter(
                new GetGenericTablesByFilterInput()
                {
                    Filter = new FilterCollection()
                    {
                        new Cmf.Foundation.BusinessObjects.QueryObject.Filter()
                        {
                            Name = "Name"
                            , Operator = FieldOperator.IsEqualTo
                            , Value = tableName
                        }
                    }
                });

            // only proceed if table exists
            if (output != null && output.GenericTableCollection != null && output.GenericTableCollection.Count > 0)
            {
                // Load Generic table and properties
                IGenericTable gtTable = output.GenericTableCollection.First();
                gtTable.LoadProperties();

                // If  lead filler and parser rule are not yet present in generic table, proceed to adding them
                if (!gtTable.GenericTableProperties.Any(E => expectedColumnNames.Contains(E.Name)))
                {
                    // Prepare next position
                    int nextPosition = 0;
                    if (gtTable.GenericTableProperties != null && gtTable.GenericTableProperties.Count > 0)
                    {
                        nextPosition = gtTable.GenericTableProperties.Max(E => E.Position) + 1;
                    }

                    // get string scalar type
                    IScalarType stringScalarType = new ScalarType();
                    stringScalarType.Load("NVarChar");

                    // get Rule EntityType id and its Name EntityTypePropertyId
                    IEntityType etRule = new EntityType();
                    etRule.Load("Rule");
                    etRule.LoadProperties();
                    long etRuleETId = etRule.Id;
                    long etRuleEtpNameId = etRule.Properties.First(E => String.Equals(E.Name, "Name", StringComparison.InvariantCultureIgnoreCase)).Id;

                    // perform full update on table
                    gtTable = tableOrchestration.FullUpdateGenericTable(
                        new FullUpdateGenericTableInput()
                        {
                            GenericTable = gtTable
                            , PropertiesToAddOrUpdate = new GenericTablePropertiesCollection()
                            {
                                new GenericTableProperty()
                                {
                                    Name = "LeadFiller"
                                    , Position = nextPosition
                                    , Description = "Lead filler of a given token"
                                    , DefaultValue = null
                                    , IsKey = false
                                    , IsMandatory = false
                                    , ScalarType = stringScalarType
                                    , Size = 512
                                    , ReferenceType = ReferenceType.None
                                }
                                , new GenericTableProperty()
                                {
                                    Name = "ParserRule"
                                    , Position = nextPosition + 1
                                    , Description = "Rule to be executed to extract a token"
                                    , DefaultValue = null
                                    , IsKey = false
                                    , IsMandatory = false
                                    , ScalarType = stringScalarType
                                    , Size = 512
                                    , ReferenceType = ReferenceType.EntityType
                                    , ReferenceTypeId = etRuleETId
                                    , ReferencePropertyId = etRuleEtpNameId
                                }
                            }
                        }).GenericTable;

                    // Generate its schema...
                    tableOrchestration.GenerateGenericTableSchema(new GenerateGenericTableSchemaInput()
                    {
                        GenericTable = gtTable
                    });
                }
            }

            //---End DEE Code---

            return null;
        }
    }
}