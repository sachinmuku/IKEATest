﻿using Cmf.Custom.IKEA.Common;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.QueryObject;
using Cmf.Foundation.BusinessObjects.SmartTables;
using Cmf.Foundation.BusinessOrchestration.TableManagement;
using Cmf.Foundation.BusinessOrchestration.TableManagement.InputObjects;
using Cmf.Foundation.BusinessOrchestration.TableManagement.OutputObjects;
using Cmf.Foundation.Common;
using System.Collections.Generic;
using System.Linq;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessOrchestration.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using Cmf.Common.CustomActionUtilities;


namespace Cmf.Custom.IKEA.Actions.ProcessRules.Sprint_38.After
{
    public class Sprint38AddEnfCommentAndTimeAtStateToCustomResourceStateReclassificationPermissions : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {

        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text:
            ///     Process Rule to add two columns (EnforceComment and TimeAtState) to CustomResourceStateReclassificationPermissions smart table
            /// </summary>
            #endregion

            return true;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            //System
            UseReference("", "Cmf.Foundation.BusinessOrchestration.Abstractions");
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");

            //Foundation
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.TableManagement");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.TableManagement.InputObjects");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.TableManagement.OutputObjects");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects.QueryObject");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects.SmartTables");
            UseReference("Cmf.Foundation.Common.dll", "Cmf.Foundation.Common");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            
            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            var tableOrchestration = serviceProvider.GetService<ITableOrchestration>();

            string tableName = "CustomResourceStateReclassificationPermissions";
            string propertyEnforceComment = "EnforceComment";
            string propertyTimeAtState = "TimeAtState";

            // Get Smart Table by name
            GetSmartTablesByFilterOutput output = tableOrchestration.GetSmartTablesByFilter(new GetSmartTablesByFilterInput()
            {
                Filter = new FilterCollection()
                {
                    new Foundation.BusinessObjects.QueryObject.Filter()
                    {
                        Name = "Name",
                        Operator = FieldOperator.IsEqualTo,
                        Value = tableName
                    }
                }
            });

            // Check if the smart table was found
            if (output != null && !output.SmartTableCollection.IsNullOrEmpty())
            {
                ISmartTable smartTable = output.SmartTableCollection.First();

                // Load the properties of the smart table
                smartTable.LoadProperties();

                // Check if the precedence key already exists
                if (!smartTable.SmartTableProperties.Any(pk => pk.Name == propertyEnforceComment) &&
                    !smartTable.SmartTableProperties.Any(pk => pk.Name == propertyTimeAtState))
                {
                    ISmartTablePropertiesCollection properties = new SmartTablePropertiesCollection();

                    // Define Scalar types:
                    IScalarType bitScalarType = new ScalarType();
                    bitScalarType.Load("Bit");

                    IScalarType decimalScalarType = new ScalarType();
                    decimalScalarType.Load("Decimal");

                    properties.Add(new SmartTableProperty()
                    {
                        Name = propertyEnforceComment,
                        Position = 7,
                        Description = "Enforce a comment on reclassification",
                        IsKey = false,
                        IsIndexed = false,
                        IsMandatory = false,
                        ScalarType = bitScalarType,                        
                        ReferenceType = ReferenceType.None                     
                    });

                    properties.Add(new SmartTableProperty()
                    {
                        Name = propertyTimeAtState,
                        Position = 8,
                        Description = "Minimum Time at state to enforce a comment",
                        IsKey = false,
                        IsIndexed = false,
                        IsMandatory = false,
                        ScalarType = decimalScalarType,
                        Size = 8,
                        Precision = 18,
                        ReferenceType = ReferenceType.None
                    });


                    // Update properties and Precedence Keys of the smart table
                    FullUpdateSmartTableOutput fullUpdateSmartTableOutput = tableOrchestration.FullUpdateSmartTable(new FullUpdateSmartTableInput()
                    {
                        SmartTable = smartTable,
                        PropertiesToAddOrUpdate = properties,
                    });

                    // Generate the smart table schema
                    tableOrchestration.GenerateSmartTableSchema(new GenerateSmartTableSchemaInput()
                    {
                        SmartTable = fullUpdateSmartTableOutput.SmartTable
                    });
                }
            }
            //---End DEE Code---

            return Input;
        }

    }
}
