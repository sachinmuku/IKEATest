﻿using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Base;
using Namotion.Reflection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Text;
using Cmf.Foundation.BusinessOrchestration.EntityTypeManagement;
using System.Linq;
using Cmf.Foundation.BusinessOrchestration.EntityTypeManagement.InputObjects;
using Cmf.Custom.IKEA.BusinessObjects;
using Cmf.Custom.IKEA.Common;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessOrchestration.Abstractions;
using Microsoft.Extensions.DependencyInjection;

namespace Cmf.Custom.IKEA.Actions.ProcessRules.Version_3_65_0.Before
{
    public class AddOrderReportableQuantityPropertyToCustomERPOperationTracking : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<String, Object> Input)
        {
            //---Start DEE Condition Code---

            #region Info
            /// <summary>
            /// Summary text:
            ///     Process Rule to add column Comment to CustomERPOperationTracking entity
            /// </summary>
            #endregion

            return true;

            //---End DEE Condition Code---  
        }

        public override Dictionary<String, Object> EvaluateRule(Dictionary<String, Object> Input)
        {
            //---Start DEE Code---
            UseReference("", "Cmf.Foundation.BusinessOrchestration.Abstractions");
UseReference("Cmf.Foundation.BusinessOrchestration.dll", "");
            UseReference("", "Cmf.Foundation.BusinessOrchestration.EntityTypeManagement");
            UseReference("", "Cmf.Foundation.BusinessOrchestration.EntityTypeManagement.InputObjects");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
var entityTypeOrchestration = serviceProvider.GetService<IEntityTypeOrchestration>();

            string entityName = IKEAConstants.CustomERPOperationTracking;
            string orderReportableQuantityPropertyName = IKEAConstants.CustomERPOperationTrackingAttributeOrderReportableQuantity;
            string orderReportableQuantityPropertyDescription = "Order Reportable Quantity";

            IScalarType decimalScalarType = new ScalarType();
            decimalScalarType.Load("Decimal");

            IEntityType entity = new EntityType
            {
                Name = entityName
            };

            if (entity.ObjectExists())
            {
                //only proceed entity is active and property doesn't exist
                if ((entity.UniversalState == UniversalState.Created || entity.UniversalState == UniversalState.Active))
                {
                    entity.Load();

                    if (!entity.Properties.Any(e => String.Equals(e.Name, orderReportableQuantityPropertyName, StringComparison.InvariantCultureIgnoreCase)))
                    {
                        IEntityTypeProperty orderReportableQuantityProperty = new EntityTypeProperty()
                        {
                            Name = orderReportableQuantityPropertyName,
                            PropertyType = EntityTypePropertyType.CustomProperty,
                            Description = orderReportableQuantityPropertyDescription,
                            ReferenceType = Cmf.Foundation.Common.ReferenceType.None,
                            ReferencedObjectId = 0,
                            ScalarType = decimalScalarType,
                            ScalarSize = 8,
                            ScalarPrecision = 18,
                            IsEnabled = true,
                            IsIndexed = false,
                            IsMandatory = false,
                            IsHistoryEnable = true,
                            LoadToDWH = false,
                            AccessLevel = (int)PropertyAccessLevel.Full,
                        };

                        // set properties to be added
                        IEntityTypePropertyCollection propertiesToAdd = new EntityTypePropertyCollection { orderReportableQuantityProperty };

                        entity = entityTypeOrchestration.FullUpdateEntityType(new FullUpdateEntityTypeInput()
                        {
                            EntityType = entity,
                            EntityTypePropertiesToAddOrUpdate = propertiesToAdd,
                        }).EntityType;

                        entityTypeOrchestration.GenerateEntityTypeDBSchema(new GenerateEntityTypeDBSchemaInput
                        {
                            EntityType = entity
                        });

                    }
                }
            }

            //---End DEE Code---

            return Input;
        }
    }
}
