﻿using Cmf.Custom.IKEA.Common;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessOrchestration.DynamicExecutionEngineManagement;
using Cmf.Foundation.BusinessOrchestration.DynamicExecutionEngineManagement.InputObjects;
using Cmf.Foundation.BusinessOrchestration.EntityTypeManagement;
using Cmf.Foundation.BusinessOrchestration.EntityTypeManagement.InputObjects;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Base;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Linq;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessOrchestration.Abstractions;
using Microsoft.Extensions.DependencyInjection;

namespace Cmf.Custom.IKEA.Actions.ProcessRules._2._28._0.After
{
    class Sprint28ChangeAttributeSubProcessSegmentAccessLevel : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Updates the AccessLevel of the Resource's Attribute "SubProcessSegmentName" to Full (0) if it is not already
            ///     
            /// Action Groups:
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion

            return true;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            //System
            UseReference("", "Cmf.Foundation.BusinessOrchestration.Abstractions");
UseReference("", "System");
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");

            //Foundation
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.DynamicExecutionEngineManagement");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.DynamicExecutionEngineManagement.InputObjects");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");

            //---Start DEE Code---

            // System
            UseReference("", "System.Text");
            UseReference("%MicrosoftNetPath%\\mscorlib.dll", "System.Globalization");

            // Foundation
            UseReference("Cmf.Foundation.Common.dll", "Cmf.Foundation.Common.Base");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.CommunicationLayer.Sap.dll", "Cmf.Foundation.CommunicationLayer.Converters");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.ErpManagement.InputObjects");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.EntityTypeManagement");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.EntityTypeManagement.InputObjects");

            // Navigo
            UseReference("Cmf.Navigo.Common.dll", "Cmf.Navigo.Common");
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects");
var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
var entityTypeOrchestration = serviceProvider.GetService<IEntityTypeOrchestration>();

            IEntityType entityResource = new EntityType
            {
                Name = Constants.Resource
            };

            if (entityResource.ObjectExists())
            {
                entityResource.Load();
                entityResource.LoadProperties();

                // If entity is still in Created or Active state, load the properties to check their access level...
                if (entityResource.UniversalState == UniversalState.Created || entityResource.UniversalState == UniversalState.Active)
                {
                    // Collection that will contain properties which might need to be updated
                    IEntityTypePropertyCollection propertiesToUpdate = new EntityTypePropertyCollection();

                    #region Check SubProcessSegmentName

                    IEntityTypeProperty subProcessSegmentName = entityResource.Properties.FirstOrDefault(E => E.Name == IKEAConstants.SubProcessSegmentName) as IEntityTypeProperty;
                    // Set the AccessLevel to Full, only if it is not Full already
                    if (subProcessSegmentName != null && subProcessSegmentName.AccessLevel != (int)PropertyAccessLevel.Full)
                    {
                        subProcessSegmentName.AccessLevel = (int)PropertyAccessLevel.Full; // 0

                        propertiesToUpdate.Add(subProcessSegmentName);
                    }

                    if (propertiesToUpdate.Count > 0)
                    {
                        entityResource = entityTypeOrchestration.UpdateEntityTypeProperties(new UpdateEntityTypePropertiesInput()
                        {
                            EntityType = entityResource,
                            EntityTypeProperties = propertiesToUpdate
                        }).EntityType;

                        #region Generate Schema

                        entityTypeOrchestration.GenerateEntityTypeDBSchema(new GenerateEntityTypeDBSchemaInput
                        {
                            EntityType = entityResource
                        });

                        #endregion
                    }
                    #endregion
                }
            }

            //---End DEE Code---

            return Input;
        }
    }
}
