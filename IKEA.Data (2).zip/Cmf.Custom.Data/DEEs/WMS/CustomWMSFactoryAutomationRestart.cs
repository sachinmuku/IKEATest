﻿using Cmf.Custom.IKEA.Common;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessOrchestration.ConnectIoTManagement.OutputObjects;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace Cmf.Custom.IKEA.Actions.WMS
{
    class CustomWMSFactoryAutomationRestart : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text: 
            /// Restart job when Controller Failure is encountered
            /// Action Groups: N/A
            /// Depends On: N/A
            /// Is Dependency For: N/A
            /// Exceptions: N/A
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "ConnectIoTManagement.ConnectIoTManagementOrchestration.SetAutomationJobsSystemState.Post"
            };


            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            //System
            UseReference("", "System");
            UseReference("", "System.Text");
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");

            //Foundation
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.WMS");
            
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.ConnectIoTManagement.OutputObjects");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();

            // Will hold the instance of "WMSOrderRequest". Is null by default, and is only loaded once when first needed
            IIoTEventDefinition automationEvent = null;

            SetAutomationJobsSystemStateOutput autoJobOutput = IKEADEEActionUtilities.GetInputItem<SetAutomationJobsSystemStateOutput>(Input, "SetAutomationJobsSystemStateOutput");

            foreach (var job in autoJobOutput.AutomationJobs)
            {
                // Check if the automation job's state is Error and if the Error Code is "ControllerFailuer",
                // which indicate that the FA Manager went down and was restarted, cancelling it's jobs on the way
                if (job.SystemState == Foundation.BusinessObjects.ConnectIoT.AutomationJobSystemState.Error &&
                    job.ErrorCode == IKEAConstants.WMSFactoryAutomationControllerFailureErrorCode)
                {
                    // Only load the automation event if it is needed, meaning, if there is any job in the correct state
                    if (automationEvent == null)
                    {
                        automationEvent = entityFactory.Create<IIoTEventDefinition>();

                        automationEvent.Name = IKEAConstants.EventDefinitionWMSOrderRequest;

                        automationEvent.Load();
                    }

                    // Only restart jobs for the event "WMSOrderRequest"
                    if (job.TriggerEvent?.Id == automationEvent.Id)
                    {
                        job.Restart();
                    }
                }
            }

            //---End DEE Code---

            return Input;
        }
    }
}
