﻿
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Exceptions;
using Cmf.Custom.IKEA.Common.Utilities;
using Cmf.Custom.IKEA.Common.WMS;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Xml;

namespace Cmf.Custom.IKEA.Actions.WMS
{
    public class CustomWMSPalletStatusHandler : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text: 
            /// Action used by the integration handler when performing a new GetPalletStatus or StePalletStatus from MES to WMS.
            /// Check smart table IntegrationHandlerResolution for the configuration
            /// Action Groups: N/A
            /// Depends On: N/A
            /// Is Dependency For: N/A
            /// Exceptions: N/A
            /// </summary>
            #endregion

            return true;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     


            //System
            UseReference("", "System");
            UseReference("", "System.Text");
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");

            UseReference("%MicrosoftNetPath%\\System.Net.Http.dll", "System.Net.Http");
            UseReference("%MicrosoftNetPath%\\System.XML.XDocument.dll", "");
            UseReference("%MicrosoftNetPath%\\System.XML.ReaderWriter.dll", "");
            UseReference("%MicrosoftNetPath%\\System.Private.XML.dll", "");
            UseReference("%MicrosoftNetPath%\\System.XML.dll", "System.Xml");

            //Foundation
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.WMS");
            
            UseReference("Cmf.Custom.IKEA.BusinessObjects.CustomWMSMaterialTracker.dll", "Cmf.Custom.IKEA.BusinessObjects");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Exceptions");
            // Newtonsoft
            UseReference("Newtonsoft.Json.dll", "Newtonsoft.Json");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            IIKEAUtilities IkeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IWMSUtilities wMSUtilities = serviceProvider.GetService<IWMSUtilities>();
            if (Input.ContainsKey("IntegrationEntry"))
            {
                // Get input item
                IIntegrationEntry integrationEntry = IKEADEEActionUtilities.GetInputItem<IIntegrationEntry>(Input, "IntegrationEntry");

                XmlDocument xmlMessage = new XmlDocument();
                xmlMessage.LoadXml(Encoding.UTF8.GetString(integrationEntry.IntegrationMessage.Message));

                MESWMSCommunication mesWMSCommunication;
                try
                {
                    // Deserialize the Xml from the integration entry message
                    mesWMSCommunication = genericUtilities.DeserializeXmlToObject<MESWMSCommunication>(xmlMessage);
                }
                catch (Exception exception)
                {
                    throw new IKEAException(IKEAConstants.CustomWMSInvalidResponseLocalizedMessage, exception.Message);
                }

                // Validate if MESWMSCommunication key is present:
                if (mesWMSCommunication != null)
                {
                    // Extract API and Message from IntegrationEntry message
                    string rawEndpointConfigName = mesWMSCommunication.API;
                    string rawMessage = mesWMSCommunication.Message;

                    // Validate API and rawMessage
                    if (!string.IsNullOrWhiteSpace(rawEndpointConfigName) && !string.IsNullOrWhiteSpace(rawMessage))
                    {
                        string config = IKEAConstants.WMSEndPoint + rawEndpointConfigName;
                        string endPoint = genericUtilities.GetConfigurationValueByPath<string>(config);

                        // Validate if config was successfully extracted
                        if (!string.IsNullOrWhiteSpace(endPoint))
                        {

                            #region Send message to WMS and validate response
                            // Send message to WMS system:
                            WMSIntegrationMessage message = new();
                            try
                            {
                                message = JsonConvert.DeserializeObject<WMSIntegrationMessage>(rawMessage);
                            }
                            catch (Exception exception)
                            {
                                throw new IKEAException(IKEAConstants.CustomWMSInvalidResponseLocalizedMessage, exception.Message);
                            }

                            WMSIntegrationMessage wmsResponse = wMSUtilities.SendWMSMessageWithIntegrationEntry(message, endPoint, HttpMethod.Post);

                            if (wmsResponse.Response == CustomWMSOrderResponseType.Rejected)
                            {
                                throw new IKEAException(IKEAConstants.CustomWMSExceptionLocalizedMessage, wmsResponse.Details);
                            }
                            #endregion

                            #region Process WMS response
                            if (integrationEntry.MessageType == "GetPalletStatus")
                            {
                                // TODO - Define with IKEA what to this message GetPalletStatus should be used for
                            }
                            #endregion

                            // Add the message result to the integration entry:
                            if (message != null)
                            {
                                Input.Add("Result", JsonConvert.SerializeObject(message));
                            }
                        }
                        else
                        {
                            throw new IKEAException(IKEAConstants.CustomWMSMissingEndpointConfigLocalizedMessage, config);
                        }
                    }
                    else
                    {
                        throw new IKEAException(IKEAConstants.CustomWMSNoApiMessageFoundLocalizedMessage);
                    }
                }
                else
                {
                    throw new IKEAException(IKEAConstants.CustomWMSDeserializationFailedLocalizedMessage);
                }
            }

            //---End DEE Code---

            return Input;
        }
    }
}
