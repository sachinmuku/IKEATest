﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace Cmf.Custom.IKEA.Actions.WMS
{

    /// <summary>
    /// DEE responsible for creating messages and log entries when changing a material type
    /// </summary>

    public class CustomWMSSetPalletStatusAction : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Updates the status of the pallet in the WMS system when the type of the Material is changed in MES.
            /// Action Groups:
            ///     MaterialManagement.MaterialManagementOrchestration.ChangeMaterialType.Post
            ///     MaterialManagement.MaterialManagementOrchestration.ChangeMaterialsType.Post
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "MaterialManagement.MaterialManagementOrchestration.ChangeMaterialType.Post",
                "MaterialManagement.MaterialManagementOrchestration.ChangeMaterialsType.Post"
            };

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IWMSUtilities wmsUtilities = serviceProvider.GetService<IWMSUtilities>();
            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();
            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            if (executionVeridict && IKEADEEActionUtilities.GetInputItem<ChangeMaterialTypeOutput>(Input, "ChangeMaterialTypeOutput") == null
                                  && IKEADEEActionUtilities.GetInputItem<ChangeMaterialsTypeOutput>(Input, "ChangeMaterialsTypeOutput") == null)
            {
                executionVeridict = false;
            }

            if (executionVeridict && !genericUtilities.GetConfigurationValueByPath<bool>(IKEAConstants.WMSEnableMaterialChangeTypeReporting))
            {
                executionVeridict = false;
            }

            // Check if operation is made by Unit Completion, if so return
            if (executionVeridict && deeContextUtilities.GetContextParameter(IKEAConstants.ERPChangeTypeReportUnitCompletion) as bool? == true)
            {
                executionVeridict = false;
            }

            // Check if Material Type is defined in CustomWMSMaterialTypeMappingGenericTable
            DeeContext currentContext = deeContextUtilities.SetCurrentServiceContext("CustomWMSSetPalletStatusAction");
            switch (currentContext.MethodName)
            {
                case "ChangeMaterialType":
                    {
                        ChangeMaterialTypeOutput input = (ChangeMaterialTypeOutput)Input["ChangeMaterialTypeOutput"];
                        int status = wmsUtilities.GetWMSStatus(input.Material.Type);
                        if(executionVeridict && status == -1)
                        {
                            executionVeridict = false;
                        }
                        break;
                    }
                case "ChangeMaterialsType":
                    {
                        ChangeMaterialsTypeOutput input = (ChangeMaterialsTypeOutput)Input["ChangeMaterialsTypeOutput"];
                        foreach (IMaterial material in input.Materials)
                        {
                            int status = wmsUtilities.GetWMSStatus(material.Type);
                            if (executionVeridict && status == -1)
                            {
                                executionVeridict = false;
                            }
                        }
                        break;
                    }
                default:
                    break;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            //System
            UseReference("", "System");
            UseReference("", "System.Text");
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");
            UseReference("%MicrosoftNetPath%\\System.XML.XDocument.dll", "");
            UseReference("%MicrosoftNetPath%\\System.XML.ReaderWriter.dll", "");
            UseReference("%MicrosoftNetPath%\\System.Private.XML.dll", "");
            UseReference("%MicrosoftNetPath%\\System.XML.dll", "System.Xml");

            //Foundation
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects");
            UseReference("", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            UseReference("", "Cmf.Foundation.Common");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.WMS");
            
            UseReference("Cmf.Custom.IKEA.BusinessObjects.CustomWMSMaterialTracker.dll", "Cmf.Custom.IKEA.BusinessObjects");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");

            // Newtonsoft
            UseReference("Newtonsoft.Json.dll", "Newtonsoft.Json");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IWMSUtilities wmsUtilities = serviceProvider.GetService<IWMSUtilities>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();

            DeeContext currentContext = deeContextUtilities.SetCurrentServiceContext("CustomWMSSetPalletStatusAction");

            switch (currentContext.MethodName)
            {
                case "ChangeMaterialType":
                    {
                        ChangeMaterialTypeOutput input = (ChangeMaterialTypeOutput)Input["ChangeMaterialTypeOutput"];

                        string requestEndpoint = IKEAConstants.WMSSetPalletStatusMessageType;

                        WMSIntegrationMessage integrationMessage = wmsUtilities.CreateSetPalletStatusMessage(input.Material);

                        IIntegrationEntry integrationEntry = wmsUtilities.CreateWMSIntegrationEntry(integrationMessage,
                                                                                                    requestEndpoint,
                                                                                                    requestType: IKEAConstants.WMSSetPalletStatusMessageType,
                                                                                                    eventName: IKEAConstants.WMSSetPalletStatusMessageType);

                        break;
                    }
                case "ChangeMaterialsType":
                    {
                        ChangeMaterialsTypeOutput input = (ChangeMaterialsTypeOutput)Input["ChangeMaterialsTypeOutput"];

                        string requestEndpoint = IKEAConstants.WMSSetPalletStatusMessageType;
                        foreach (IMaterial material in input.Materials)
                        {
                            WMSIntegrationMessage integrationMessage = wmsUtilities.CreateSetPalletStatusMessage(material);

                            IIntegrationEntry integrationEntry = wmsUtilities.CreateWMSIntegrationEntry(integrationMessage,
                                                                                                        requestEndpoint,
                                                                                                        requestType: IKEAConstants.WMSSetPalletStatusMessageType,
                                                                                                        eventName: IKEAConstants.WMSSetPalletStatusMessageType);

                        }
                        break;
                    }

                default:
                    break;
            }


            //---End DEE Code---

            return Input;
        }
    }
}
