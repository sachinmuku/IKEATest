﻿using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Common.CustomActionUtilities;

using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Orchestration.Abstractions;
using Cmf.Custom.IKEA.Orchestration.InputObjects;
using Cmf.Custom.IKEA.Orchestration.OutputObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.Common;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cmf.Custom.IKEA.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Actions.Shifts
{
    public class CustomUpdateAndRetrieveInitialShiftQuantity : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            var executionVeridict = true;
            if (IKEADEEActionUtilities.GetInputItem<string>(Input, "MaterialName") == null
                || Input.ContainsKey("QuantityToReduce") == false
                || IKEADEEActionUtilities.GetInputItem<string>(Input, "OutFeederName") == null)
            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            UseReference("", "Cmf.Foundation.Common.Exceptions");

            // Custom
            UseReference("Cmf.Custom.IKEA.BusinessObjects.CustomManufacturingOrderOutFeeder.dll", "");
            UseReference("", "Cmf.Custom.IKEA.BusinessObjects");
            UseReference("", "Cmf.Custom.IKEA.BusinessObjects.Abstractions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");

            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];

            string materialName = Input["MaterialName"] as string;
            decimal quantityToReduce = Convert.ToDecimal(Input["QuantityToReduce"].ToString(), System.Globalization.CultureInfo.InvariantCulture);
            string outFeederName = Input["OutFeederName"] as string;

            // Obtain MO/Outfeeder relation and it's attribute "CustomInitialShiftQuantity"
            ICustomManufacturingOrderOutFeeder moof = serviceProvider.GetService<ICustomManufacturingOrderOutFeeder>();
            moof.RemoveFromInstanceCache();
            moof.Load($"{materialName}To{outFeederName}");
            moof.LoadAttributes(new Collection<string>() { "CustomInitialShiftQuantity" });

            // Establish the original "InitialShiftQuantity"
            moof.Attributes.TryGetValue("CustomInitialShiftQuantity", out object originalInitialShiftQuantity);

            // Calculate the new "InitialShiftQuantity", by reducing the quantity given on input
            decimal newInitialshiftQuantity =
                Convert.ToDecimal(originalInitialShiftQuantity) - quantityToReduce < 0
                ? 0 : Convert.ToDecimal(originalInitialShiftQuantity) - quantityToReduce;

            // Store the recalculated "InitialShiftQuantity" on MO/Outfeeder relation
            IAttributeCollection attributesToUpdate = serviceProvider.GetService<IAttributeCollection>();
            attributesToUpdate.Add("CustomInitialShiftQuantity", newInitialshiftQuantity);
            moof.SaveAttributes(attributesToUpdate);

            // Return the original "InitialShiftQuantity" to be used in automation
            Dictionary<string, object> output = new Dictionary<string, object>();
            output.Add("ShiftQuantity", Convert.ToDecimal(originalInitialShiftQuantity));

            return output;

            //---End DEE Code---

            //return Input;
        }

    }
}
