using Cmf.Common.CustomActionUtilities;
using Cmf.Custom.IKEA.BusinessObjects;
using Cmf.Custom.IKEA.BusinessObjects.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessObjects.QueryObject;
using Cmf.Foundation.BusinessOrchestration.Abstractions;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.Abstractions;
using Cmf.Navigo.BusinessOrchestration.FacilityManagement.AreaManagement.InputObjects;
using Cmf.Navigo.BusinessOrchestration.FacilityManagement.AreaManagement.OutputObjects;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.Shifts
{
    public class CustomShiftChangeReportInitialShiftQuantity : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text:
            ///     This action updates the attribute "CustomInitialShiftQuantity" from the relation "CustomManufacturingOrderOutFeeder": 
            ///       - The CmfTimer "CustomIsShiftTimer" will run each hour of the day and call this DEE.
            ///       - Production areas where a shift definition is defined and the start time matches the current system time are obtained
            ///       - The relations "CustomManufacturingOrderOutFeeder" where the related resource belongs with the areas obtained above 
            ///       have the attribute updated
            /// Action Groups:
            ///     None: this action is explicitely called by a CmfTimer
            /// </summary>
            #endregion

            return true;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            // Custom
            UseReference("Cmf.Custom.IKEA.BusinessObjects.CustomManufacturingOrderOutFeeder.dll", "");
            UseReference("", "Cmf.Custom.IKEA.BusinessObjects");
            UseReference("", "Cmf.Custom.IKEA.BusinessObjects.Abstractions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");

            // Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "");
            UseReference("", "Cmf.Common.CustomActionUtilities");
            UseReference("Cmf.Custom.IKEA.Common.dll", "");
            UseReference("", "Cmf.Custom.IKEA.Common");

            // Foundation
            UseReference("", "Cmf.Foundation.Common.Exceptions");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "");
            UseReference("", "Cmf.Foundation.BusinessObjects.QueryObject");

            // Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "");
            UseReference("", "Cmf.Navigo.BusinessOrchestration.FacilityManagement.AreaManagement");
            UseReference("", "Cmf.Navigo.BusinessOrchestration.FacilityManagement.AreaManagement.InputObjects");
            UseReference("", "Cmf.Navigo.BusinessOrchestration.FacilityManagement.AreaManagement.OutputObjects");
            UseReference("", "Cmf.Navigo.BusinessOrchestration.ResourceManagement");
            UseReference("", "Cmf.Navigo.BusinessOrchestration.ResourceManagement.InputObjects");
            UseReference("", "Cmf.Navigo.BusinessOrchestration.ResourceManagement.OutputObjects");
            UseReference("", "System.Data");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.Abstractions");

            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            //IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();

            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();

            Dictionary<string, object> Output = new Dictionary<string, object>(Input);

            var AreaManagementOrchestration = serviceProvider.GetService<IAreaOrchestration>();

            DateTime currentDateTime = DateTime.Now;
            Int16 offsetSecondsForDateTime = genericUtilities.GetConfigurationValueByPath<Int16>(IKEAConstants.CustomShiftChangeOffsetTime);
            DateTime offsetDateTime = currentDateTime.AddSeconds(-offsetSecondsForDateTime);

            #region ObtainAllFacilities
            // Obtain all production facilities

            // Call service
            GetAllFacilitiesOutput getAllFacilitiesOutput = AreaManagementOrchestration.GetAllFacilities(new GetAllFacilitiesInput());

            // Transform result to dataset
            INgpDataSet facilitiesNdpDataset = getAllFacilitiesOutput.AllFacilities;
            DataSet facilitiesDataset = NgpDataSet.ToDataSet(facilitiesNdpDataset);

            // Exit action if not data is returned
            if (facilitiesDataset.Tables.Count == 0)
            {
                return Input;
            }

            // Exit action if not data is returned
            if (facilitiesDataset.Tables[0].Rows.Count == 0)
            {
                return Input;
            }

            // Store production facilities in memory
            IFacilityCollection facilities = serviceProvider.GetService<IFacilityCollection>();
            foreach (DataRow row in facilitiesDataset.Tables[0].Rows)
            {
                if (row.Field<string>("Type").Equals("Production", StringComparison.InvariantCultureIgnoreCase))
                {
                    IFacility facility = entityFactory.Create<IFacility>();
                    facility.Name = row.Field<string>("Name");
                    facilities.Add(facility);
                }
            }

            // Exit action if no production facilities were found
            if (facilities.Count() == 0)
            {
                return Input;
            }
            #endregion

            #region ObtainAllAreas
            // Obtain all areas from production facilities
            IAreaCollection areas = serviceProvider.GetService<IAreaCollection>();

            facilities.Load();
            foreach (IFacility facility in facilities)
            {
                GetAreasForFacilityOutput getAreasOutput = AreaManagementOrchestration.GetAreasForFacility(new GetAreasForFacilityInput()
                {
                    FacilityId = facility.Id
                });

                INgpDataSet areasNdpDataset = getAreasOutput.AllAreas;
                DataSet areasDataset = NgpDataSet.ToDataSet(areasNdpDataset);

                if (areasDataset.Tables.Count == 0)
                {
                    continue;
                }

                if (areasDataset.Tables[0].Rows.Count == 0)
                {
                    continue;
                }

                foreach (DataRow row in areasDataset.Tables[0].Rows)
                {
                    IArea area = entityFactory.Create<IArea>();
                    area.Name = row.Field<string>("Name");
                    areas.Add(area);
                }
            }
            #endregion

            #region FilterAreasWhenShiftIsDefined
            // Filter areas where the current time matches a valid CalendarDay / Shift Definition Shift
            areas.Load();
            foreach (Area area in areas)
            {
                area.Calendar.Load();
                area.Calendar.LoadDays(DateTime.Now, DateTime.Now);
            }

            List<long> areaIds = areas
                .Where(
                    area => area.Calendar.CalendarDays.FirstOrDefault().ShiftDefinition.ShiftsCollection
                        .Where(
                            sds => ikeaUtilities.IsTimeIntersect(sds.EndTime, offsetDateTime.TimeOfDay, currentDateTime.TimeOfDay)
                        ).Count() > 0
                    )
                .Select(area => area.Id)
                .ToList();

            if (areaIds.Count() == 0)
            {
                // Here, no areas were listed with shifts being switched at the current moment.
                // This is an expected scenario as the timer triggering this DEE is runnin each hour
                // and shifts are, normally, switched each 8 hours
                return Input;
            }
            #endregion

            #region ObtainAllCustomManufacturingOrderOutFeeder
            // Obtain all CustomManufacturingOrderOutFeeder instances from those areas where shift is currently changing
            IResourceCollection resources = serviceProvider.GetService<IResourceCollection>();
            QueryObject query = new QueryObject();
            query.Description = "";
            query.EntityTypeName = IKEAConstants.CustomManufacturingOrderOutFeeder;
            query.Name = "ObtainCustomManufacturingOrderOutFeederByResource";
            query.Query = new Query();
            query.Query.Distinct = false;
            query.Query.Filters = new Foundation.BusinessObjects.QueryObject.FilterCollection() {
    // Filters for ResourceType (Outsorter and Outfeeder only)
    new Cmf.Foundation.BusinessObjects.QueryObject.Filter()
    {
        LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND,
        FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.AlwaysTrue,
        InnerFilters = new FilterCollection() {
            new Cmf.Foundation.BusinessObjects.QueryObject.Filter()
            {
                Name = "Type",
                ObjectName = "Resource",
                ObjectAlias = "CustomManufacturingOrderOutFeeder_TargetEntity_2",
                Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                Value = "Outfeeder",
                LogicalOperator = Cmf.Foundation.Common.LogicalOperator.OR,
                FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
            },
            new Cmf.Foundation.BusinessObjects.QueryObject.Filter()
            {
                Name = "Type",
                ObjectName = "Resource",
                ObjectAlias = "CustomManufacturingOrderOutFeeder_TargetEntity_2",
                Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                Value = "Outsorter",
                LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND,
                FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
            }
        }
    },
    // Filter for Resource's Area
    new Cmf.Foundation.BusinessObjects.QueryObject.Filter()
    {
        Name = "AreaId",
        ObjectName = "Resource",
        ObjectAlias = "CustomManufacturingOrderOutFeeder_TargetEntity_2",
        Operator = Cmf.Foundation.Common.FieldOperator.In,
        Value = areaIds.ToList(),
        LogicalOperator = Cmf.Foundation.Common.LogicalOperator.Nothing,
        FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
    },
    // Filter for MO SystemState (In Process only)
    new Cmf.Foundation.BusinessObjects.QueryObject.Filter()
    {
        Name = "SystemState",
        ObjectName = "Material",
        ObjectAlias = "CustomManufacturingOrderOutFeeder_SourceEntity_2",
        Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
        Value = Cmf.Navigo.BusinessObjects.MaterialSystemState.InProcess,
        LogicalOperator = Cmf.Foundation.Common.LogicalOperator.Nothing,
        FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
    }
};
            query.Query.Fields = new FieldCollection() {
    // CustomManufacturingOrderOutFeeder: Name
    new Field()
    {
        Alias = "Name",
        ObjectName = IKEAConstants.CustomManufacturingOrderOutFeeder,
        ObjectAlias = $"{IKEAConstants.CustomManufacturingOrderOutFeeder}_1",
        IsUserAttribute = false,
        Name = "Name",
        Position = 0,
        Sort = Cmf.Foundation.Common.FieldSort.NoSort
    },
    // CustomCurrentQuantity
    new Field()
    {
        Alias = IKEAConstants.CustomManufacturingOrderOutFeederCurrentQuantity,
        ObjectName = IKEAConstants.CustomManufacturingOrderOutFeeder,
        ObjectAlias = $"{IKEAConstants.CustomManufacturingOrderOutFeeder}_1",
        IsUserAttribute = true,
        Name =IKEAConstants.CustomManufacturingOrderOutFeederCurrentQuantity,
        Position = 3,
        Sort = Cmf.Foundation.Common.FieldSort.NoSort
    },
    // CustomInitialShiftQuantity
    new Field()
    {
        Alias = IKEAConstants.CustomManufacturingOrderOutFeederInitialShiftQuantity,
        ObjectName = IKEAConstants.CustomManufacturingOrderOutFeeder,
        ObjectAlias = $"{IKEAConstants.CustomManufacturingOrderOutFeeder}_1",
        IsUserAttribute = true,
        Name = IKEAConstants.CustomManufacturingOrderOutFeederInitialShiftQuantity,
        Position = 4,
        Sort = Cmf.Foundation.Common.FieldSort.NoSort
    },
    // Material: Id
    new Field()
    {
        Alias = "MaterialId",
        ObjectName = "Material",
        ObjectAlias = $"{IKEAConstants.CustomManufacturingOrderOutFeeder}_SourceEntity_2",
        IsUserAttribute = false,
        Name = "Id",
        Position = 1,
        Sort = Cmf.Foundation.Common.FieldSort.NoSort
    },
    // Material: Name
    new Field()
    {
        Alias = "MaterialName",
        ObjectName = "Material",
        ObjectAlias = $"{IKEAConstants.CustomManufacturingOrderOutFeeder}_SourceEntity_2",
        IsUserAttribute = false,
        Name = "Name",
        Position = 6,
        Sort = Cmf.Foundation.Common.FieldSort.NoSort
    },
    // Resource: Id
    new Field()
    {
        Alias = "ResourceId",
        ObjectName = "Resource",
        ObjectAlias = $"{IKEAConstants.CustomManufacturingOrderOutFeeder}_TargetEntity_2",
        IsUserAttribute = false,
        Name = "Id",
        Position = 2,
        Sort = Cmf.Foundation.Common.FieldSort.NoSort
    },
    // Resource: Name
    new Field()
    {
        Alias = "ResourceName",
        ObjectName = "Resource",
        ObjectAlias = $"{IKEAConstants.CustomManufacturingOrderOutFeeder}_TargetEntity_2",
        IsUserAttribute = false,
        Name = "Name",
        Position = 7,
        Sort = Cmf.Foundation.Common.FieldSort.NoSort
    }
};
            query.Query.Relations = new RelationCollection() {
    // Relation CustomManufacturingOrderOutFeeder <-> Resource
    new Relation()
    {
        Alias = "",
        IsRelation = false,
        Name = "",
        SourceEntity = IKEAConstants.CustomManufacturingOrderOutFeeder,
        SourceEntityAlias = $"{IKEAConstants.CustomManufacturingOrderOutFeeder}_1",
        SourceJoinType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.JoinType.InnerJoin,
        SourceProperty = "TargetEntityId",
        TargetEntity = "Resource",
        TargetEntityAlias = $"{IKEAConstants.CustomManufacturingOrderOutFeeder}_TargetEntity_2",
        TargetJoinType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.JoinType.InnerJoin,
        TargetProperty = "Id"
    },
    // Relation CustomManufacturingOrderOutFeeder <-> Material
    new Relation()
    {
        Alias = "",
        IsRelation = false,
        Name = "",
        SourceEntity = IKEAConstants.CustomManufacturingOrderOutFeeder,
        SourceEntityAlias = $"{IKEAConstants.CustomManufacturingOrderOutFeeder}_1",
        SourceJoinType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.JoinType.InnerJoin,
        SourceProperty = "SourceEntityId",
        TargetEntity = "Material",
        TargetEntityAlias = $"{IKEAConstants.CustomManufacturingOrderOutFeeder}_SourceEntity_2",
        TargetJoinType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.JoinType.InnerJoin,
        TargetProperty = "Id"
    }
};

            DataSet dataset = query.Execute(false, new QueryParameterCollection());

            // Exit action if no entity instances were returned
            if (dataset.Tables.Count == 0)
            {
                return Input;
            }

            // Exit action if no entity instances were returned
            if (dataset.Tables[0].Rows.Count == 0)
            {
                return Input;
            }

            // Load all CustomManufacturingOrderOutFeeder
            ICustomManufacturingOrderOutFeederCollection orderOutFeederCollection = serviceProvider.GetService<ICustomManufacturingOrderOutFeederCollection>();

            foreach (DataRow row in dataset.Tables[0].Rows)
            {
                ICustomManufacturingOrderOutFeeder customManufacturingOrderOutFeeder = entityFactory.Create<ICustomManufacturingOrderOutFeeder>();
                customManufacturingOrderOutFeeder.Name = row.Field<string>("Name");
                orderOutFeederCollection.Add(customManufacturingOrderOutFeeder);
            }
            #endregion

            #region Call IoT to update the current quantity attribute
            orderOutFeederCollection.Load();
            IResourceCollection resourceCollection = serviceProvider.GetService<IResourceCollection>();
            resourceCollection.AddRange(
                orderOutFeederCollection
                    .Where(
                        orderOutFeeder => orderOutFeeder.TargetEntity != null
                    )
                    .Select(
                        orderOutFeeder =>
                        orderOutFeeder.TargetEntity.GetTopMostResource()
                    )
                    .DistinctBy(topMost => topMost.Name)
                );

            resourceCollection.Load();
            resourceCollection.LoadAttributes(new Collection<string>() { IKEAConstants.AutomationPalletOutMode });

            foreach (IResource resource in resourceCollection)
            {
                if (!resource.Attributes.ContainsKey(IKEAConstants.AutomationPalletOutMode)
                    || resource.Attributes[IKEAConstants.AutomationPalletOutMode].ToString() != "MultipleOrdersOutSignal")
                {
                    _ = genericUtilities.RequestFromIoT<Dictionary<string, string>>(resource.GetAutomationControllerInstance(), requestType: "CustomResourceUpdateCurrentQuantity", requestData: "");
                }
            }
            #endregion

            #region UpdateCustomInitialShiftQuantity
            // Update the CustomInitialShiftQuantity value from the relation with the CustomCurrentQuantity
            orderOutFeederCollection.Load();
            orderOutFeederCollection.LoadAttributes(new Collection<string> {
    IKEAConstants.CustomManufacturingOrderOutFeederInitialShiftQuantity,
    IKEAConstants.CustomManufacturingOrderOutFeederCurrentQuantity
});

            foreach (ICustomManufacturingOrderOutFeeder orderOutFeeder in orderOutFeederCollection)
            {
                if (!orderOutFeeder.TargetEntity.Attributes.ContainsKey(IKEAConstants.AutomationPalletOutMode)
                    || orderOutFeeder.TargetEntity.Attributes[IKEAConstants.AutomationPalletOutMode].ToString() != "MultipleOrdersOutSignal")
                {
                    IAttributeCollection attributesToSave = serviceProvider.GetService<IAttributeCollection>();
                    decimal currentQuantity = orderOutFeeder.GetAttributeValueOrDefault<decimal>(IKEAConstants.CustomManufacturingOrderOutFeederCurrentQuantity);
                    attributesToSave.Add(IKEAConstants.CustomManufacturingOrderOutFeederInitialShiftQuantity, currentQuantity);

                    // Note: is not possible to update different attribute values on a custom entity collection
                    orderOutFeeder.SaveAttributes(attributesToSave);
                }
            }

            #endregion
            Output["Result"] = true;

            //---End DEE Code---
            return Output;
        }

    }
}