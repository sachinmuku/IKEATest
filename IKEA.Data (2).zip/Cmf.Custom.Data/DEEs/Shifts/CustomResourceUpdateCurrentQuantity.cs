using Accord.IO;
using Cmf.Common.CustomActionUtilities;
using Cmf.Custom.IKEA.BusinessObjects.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.Shifts
{
    public class CustomResourceUpdateCurrentQuantity : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text:
            ///     This action updates the attribute "CustomCurrentQuantity" from the relation "CustomManufacturingOrderOutFeeder": 
            ///       - Actions is called by periodically by IoT with an Input containing a list of Materials and it's related 
            ///         subresources / current quantities
            ///       - For each material, and it's related "CustomManufacturingOrderOutFeeder" relation:
            ///             - Relation attribute "CustomCurrentQuantity" is obtained and compared with the Input value
            ///             - If the attribute value is different than the one from Input, then it is updated on the Relation
            ///       have the attribute updated
            /// Action Groups:
            ///     None: this action is explicitely called by IoT
            /// </summary>
            #endregion

            return true;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
            // Custom
            UseReference("Cmf.Custom.IKEA.BusinessObjects.CustomManufacturingOrderOutFeeder.dll", "");
            UseReference("", "Cmf.Custom.IKEA.BusinessObjects");
            UseReference("", "Cmf.Custom.IKEA.BusinessObjects.Abstractions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            //IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            Dictionary<string, object> materialsCurrentValues
                = IKEADEEActionUtilities.GetInputItem<Dictionary<string, object>>(Input, "materialsCurrentValues")
                as Dictionary<string, object>;

            // Load MO collection
            IMaterialCollection materials = serviceProvider.GetService<IMaterialCollection>();
            materials.AddRange(materialsCurrentValues.Select(k =>  {var m=entityFactory.Create<IMaterial>(); m.Name = k.Key;return m; }).ToList());

            materials.Load();

            // Load MOs relations where outfeeders/outsorters resources are defined
            materials.LoadRelations(IKEAConstants.CustomManufacturingOrderOutFeeder);

            // Iterate each MO / Subresource value pair
            foreach (KeyValuePair<string, object> materialValue in materialsCurrentValues)
            {
                // Establish iterated material
                IMaterial material = materials.FirstOrDefault(mat => mat.Name == materialValue.Key);

                if (material == null)
                {
                    continue;
                }

                // Establish iterated material relation collection
                ICustomManufacturingOrderOutFeederCollection orderOutFeederCollection = serviceProvider.GetService<ICustomManufacturingOrderOutFeederCollection>();
                orderOutFeederCollection.AddRange(
                    material.RelationCollection
                        .FirstOrDefault(rc => rc.Key == IKEAConstants.CustomManufacturingOrderOutFeeder)
                        .Value
                        .Select(v => (ICustomManufacturingOrderOutFeeder)v)
                        .ToList()
                    );

                // Load relation attribute "CustomCurrentQuantity" for the relation collection
                orderOutFeederCollection.LoadAttributes(new Collection<string>() { IKEAConstants.CustomManufacturingOrderOutFeederCurrentQuantity });

                // Iterate relation collection
                foreach (ICustomManufacturingOrderOutFeeder orderOutFeeder in orderOutFeederCollection)
                {
                    // Update relation attribute "CustomCurrentQuantity"
                    string resourceName = orderOutFeeder.TargetEntity.Name;

                    Dictionary<string, object> outfeederQuantities = materialValue.Value as Dictionary<string, object>;
                    IAttributeCollection attributesToSave = serviceProvider.GetService<IAttributeCollection>();
                    attributesToSave.Add(IKEAConstants.CustomManufacturingOrderOutFeederCurrentQuantity,
                        Convert.ToDecimal(outfeederQuantities.Where(mv => mv.Key == resourceName).FirstOrDefault().Value)
                        );

                    // Save attribute only if changed
                    orderOutFeeder.Attributes.TryGetValue(IKEAConstants.CustomManufacturingOrderOutFeederCurrentQuantity, out object originalValue);
                    if (originalValue == null || (originalValue is decimal && (decimal)originalValue != (decimal)attributesToSave.FirstOrDefault().Value))
                    {
                        orderOutFeeder.SaveAttributes(attributesToSave);
                    }

                }
            }

            //---End DEE Code---
            return Input;
        }

    }
}