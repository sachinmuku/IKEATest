﻿using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.FacilityManagement.FlowManagement.InputObjects;
using Cmf.Navigo.BusinessOrchestration.FacilityManagement.FlowManagement.OutputObjects;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.Materials
{
    public class CustomFilterNextStepBasedOnMaterialType : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Validates the next steps for move next in generic table CustomMaterialTypeStepType
            /// Action Groups:
            ///     MaterialManagement.MaterialManagementOrchestration.GetDataForMultipleMoveNextWizard.Post,
            ///     FlowManagement.FlowManagementOrchestration.GetNextStepsForMaterial.Post
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "MaterialManagement.MaterialManagementOrchestration.GetDataForMultipleMoveNextWizard.Post",
                "FlowManagement.FlowManagementOrchestration.GetNextStepsForMaterial.Post"
            };

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            if (executionVeridict && IKEADEEActionUtilities.GetInputItem<GetDataForMultipleMoveNextWizardOutput>(Input, "GetDataForMultipleMoveNextWizardOutput") == null
                                  && IKEADEEActionUtilities.GetInputItem<GetNextStepsForMaterialInput>(Input, "GetNextStepsForMaterialInput") == null
                                  && IKEADEEActionUtilities.GetInputItem<GetNextStepsForMaterialOutput>(Input, "GetNextStepsForMaterialOutput") == null)
            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
     

            //System
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.FacilityManagement.FlowManagement.InputObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.FacilityManagement.FlowManagement.OutputObjects");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();

            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IMaterialCollection materials = entityFactory.CreateCollection<IMaterialCollection>();
            INextStepsResultCollection nextStepsResults = serviceProvider.GetRequiredService<INextStepsResultCollection>();
            //INextStepsResultCollection nextStepsResults = Activator.CreateInstance<INextStepsResultCollection>();
            IStepCollection steps = entityFactory.CreateCollection<IStepCollection>();
            INextStepsResultCollection newNextStepsResults = serviceProvider.GetRequiredService<INextStepsResultCollection>();
           // INextStepsResultCollection newNextStepsResults = Activator.CreateInstance<INextStepsResultCollection>();

            if (IKEADEEActionUtilities.GetInputItem<GetNextStepsForMaterialInput>(Input, "GetNextStepsForMaterialInput") != null
                   && IKEADEEActionUtilities.GetInputItem<GetNextStepsForMaterialOutput>(Input, "GetNextStepsForMaterialOutput") != null)
            {
                GetNextStepsForMaterialOutput outputData = Input["GetNextStepsForMaterialOutput"] as GetNextStepsForMaterialOutput;
                GetNextStepsForMaterialInput inputData = Input["GetNextStepsForMaterialInput"] as GetNextStepsForMaterialInput;

                if (inputData.Material.Type == null)
                {
                    inputData.Material.Load();
                }

                materials.Add(inputData.Material);
                nextStepsResults = outputData.NextStepsResults;

                newNextStepsResults = ikeaUtilities.ValidateMaterialAndStepTypeAtMoveNext(materials, nextStepsResults);

                if (newNextStepsResults != null)
                {
                    // Set output data
                    outputData.NextStepsResults = newNextStepsResults;
                }

            }
            else if (IKEADEEActionUtilities.GetInputItem<GetDataForMultipleMoveNextWizardOutput>(Input, "GetDataForMultipleMoveNextWizardOutput") != null)
            {
                GetDataForMultipleMoveNextWizardOutput data = Input["GetDataForMultipleMoveNextWizardOutput"] as GetDataForMultipleMoveNextWizardOutput;
                materials = data.Materials;
                nextStepsResults = data.NextStepsResults;

                if (materials.Any(m => m.Type == null))
                {
                    materials.Load();
                }

                newNextStepsResults = ikeaUtilities.ValidateMaterialAndStepTypeAtMoveNext(materials, nextStepsResults);

                if (newNextStepsResults != null)
                {
                    // Set data
                    data.NextStepsResults = newNextStepsResults;
                }

            }

            

            //---End DEE Code---

            return Input;
        }

    }
}
