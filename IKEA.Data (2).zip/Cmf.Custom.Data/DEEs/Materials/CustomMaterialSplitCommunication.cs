﻿using Cmf.Common.CustomActionUtilities;

using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.ERP;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.Materials
{
    public class CustomMaterialSplitCommunication : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Communicates the new materials generated in the split to ERP
            /// Action Groups:
            ///     BusinessObjects.MaterialCollection.Split.Post
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.MaterialCollection.Split.Post"
            };

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            if (executionVeridict && IKEADEEActionUtilities.GetInputItem<Dictionary<IMaterial, IMaterialCollection>>(Input, "OutputChildMaterials") == null)
            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---   
			
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            //System
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("", "System.Linq");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.ERP");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();

            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            IERPUtilities erpUtilities = serviceProvider.GetService<IERPUtilities>();
            Dictionary<IMaterial, IMaterialCollection> childMaterials = IKEADEEActionUtilities.GetInputItem<Dictionary<IMaterial, IMaterialCollection>>(Input, "OutputChildMaterials");

            if (!childMaterials.IsNullOrEmpty())
            {
                // Get configurations
                string partnerConfig = genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.SupplierCodeConfig);
                string messageTypeConfig = genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.MessageTypeCodeConfig);
                string responsibleConfig = genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.ErpResponsibleConfig);
                string processFlag = genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.MaterialSplitCommunicationProcessFlag) ?? "*EXE";
                int integrationRetries = genericUtilities.GetConfigurationValueByPath<int>(IKEAConstants.MaterialSplitCommunicationIntegrationEntryRetries);

                // Collect all the materials to load the attributes
                IMaterialCollection materials = entityFactory.CreateCollection<IMaterialCollection>();
                materials.AddRange(childMaterials.Keys);
                materials.AddRange(childMaterials.Values.SelectMany(m => m));

                // Load all the necessary attributes
                materials.LoadAttributes(new Collection<string>() { IKEAConstants.CustomMaterialAttributeERPInventoryLocation });

                // Group all the products
                var groupedProducts = materials.Select(m => m.Product).GroupBy(p => p.Id);
                IProductCollection products = entityFactory.CreateCollection<IProductCollection>();
                products.AddRange(groupedProducts.Select(p => p.ToList()[0]));

                // Load all the necessary attributes
                products.LoadAttributes(new Collection<string>() { IKEAConstants.CustomProductAttributeBaseProduct });

                // Group all the facilities
                var groupedFacility = materials.Select(m => m.Facility).GroupBy(f => f.Id);
                IFacilityCollection facilities = entityFactory.CreateCollection<IFacilityCollection>();
                facilities.AddRange(groupedFacility.Select(f => f.ToList()[0]));

                // Load all the necessary attributes
                facilities.LoadAttributes(new Collection<string>() { IKEAConstants.CustomFaciltyAttributeERPWarehouseLocation });

                // Get all the reportable forms
                List<string> reportableForms = erpUtilities.GetERPReportableForms();

                foreach (var materialChildMaterials in childMaterials.Where(cm => reportableForms.Contains(cm.Key.Form)))
                {
                    IMaterial parentMaterial = materialChildMaterials.Key;

                    parentMaterial.LoadAttributes(new Collection<string>() { IKEAConstants.CustomMaterialAttributeERPOriginalName });

                    // Get Material ERP Original Name
                    string erpOriginalName = parentMaterial.GetAttributeValueOrDefault<string>(IKEAConstants.CustomMaterialAttributeERPOriginalName);
                    string parentMaterialName = string.IsNullOrWhiteSpace(erpOriginalName) ? parentMaterial.Name : erpOriginalName;

                    // Get all necessary attributes
                    string warehouse = parentMaterial.Facility.GetAttributeValueOrDefault<string>(IKEAConstants.CustomFaciltyAttributeERPWarehouseLocation);
                    string location = parentMaterial.GetAttributeValueOrDefault<string>(IKEAConstants.CustomMaterialAttributeERPInventoryLocation);
                    string productName = parentMaterial.Product.GetRelatedAttributeValueOrDefault<string>(IKEAConstants.CustomProductAttributeBaseProduct) ?? parentMaterial.Product.Name;

                    // Communicate all the new materials to ERP
                    foreach (IMaterial childMaterial in materialChildMaterials.Value)
                    {
                        string childLocation = childMaterial.GetAttributeValueOrDefault<string>(IKEAConstants.CustomMaterialAttributeERPInventoryLocation);

                        // If primary quantity is 0 then report the secondary quantity
                        decimal childTotalQuantity = childMaterial.PrimaryQuantity ?? 0;
                        if (childTotalQuantity == 0)
                        {
                            childTotalQuantity += childMaterial.SecondaryQuantity ?? 0;
                        }
                        
                            // Instantiate communication class
                            MaterialSplitMergeCommunication materialSplitCommunication = new MaterialSplitMergeCommunication()
                        {
                            Partner = partnerConfig,
                            MessageType = messageTypeConfig,
                            Warehouse = warehouse ?? string.Empty,
                            Location = location ?? string.Empty,
                            ItemNumber = productName ?? string.Empty,
                            Container = parentMaterialName,
                            Quantity = childTotalQuantity.ToString(),
                            ToLocation = childLocation ?? string.Empty,
                            ToContainer = childMaterial.Name,
                            Responsible = responsibleConfig,
                            ProcessFlag = processFlag
                        };

                        bool materialAttributeERPIsCreationReported = parentMaterial.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomMaterialAttributeERPIsCreationReported);
                        // Create the Integration Entry
                        if (materialAttributeERPIsCreationReported)
                        {
                            // Create the Integration Entry
                            ikeaUtilities.CreateJsonIntegrationEntry(materialSplitCommunication,
                                                                IKEAConstants.ERPReportMaterialSplit,
                                                                IKEAConstants.ERPReportMaterialSplitMessageType,
                                                                IKEAConstants.ERPReportMaterialSplitEventName,
                                                                isRetriable: (integrationRetries > 0),
                                                                numberOfRetries: integrationRetries);
                        }
                    }
                }
            }

            //---End DEE Code---

            return Input;
        }
    }
}
