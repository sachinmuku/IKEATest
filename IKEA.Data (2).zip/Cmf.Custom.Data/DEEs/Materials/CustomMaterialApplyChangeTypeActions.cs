﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Custom.IKEA.Common;
using Cmf.Navigo.BusinessObjects;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using Cmf.Custom.IKEA.Common.Abstractions;



namespace Cmf.Custom.IKEA.Actions.Materials
{
    public class CustomMaterialApplyChangeTypeActions : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   
            #region Info
            /// <summary>
            /// Summary text
            /// DEE for applying actions on material type change depending on the old and new types
            /// Action Groups:
            /// BusinessObjects.MaterialCollection.ChangeType.Pre
            /// BusinessObjects.MaterialCollection.ChangeType.Post
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.MaterialCollection.ChangeType.Pre",
                "BusinessObjects.MaterialCollection.ChangeType.Post"
            };
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);
            return executionVeridict;
            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
     
            //System
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.IO");
            UseReference("", "System");
            //Foundation

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");

            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();

            DeeContext currentContext = deeContextUtilities.SetCurrentServiceContext("CustomMaterialApplyChangeTypeActions");

            Dictionary<IMaterial, string> materialTypes = null;
            if (currentContext.TriggerPoint == DeeTriggerPoint.Pre)
            {
                if (Input.ContainsKey("MaterialTypes"))
                {
                    // Get the material types from the input
                    materialTypes = Input["MaterialTypes"] as Dictionary<IMaterial, string>;
                    deeContextUtilities.SetContextParameter("CustomMaterialApplyChangeTypeActions_MaterialTypes", materialTypes);
                }
            }
            else if (currentContext.TriggerPoint == DeeTriggerPoint.Post)
            {
                materialTypes = deeContextUtilities.GetContextParameter("CustomMaterialApplyChangeTypeActions_MaterialTypes") as Dictionary<IMaterial, string>;
                if (!materialTypes.IsNullOrEmpty())
                {
                    foreach (var materialType in materialTypes)
                    {
                        ikeaUtilities.ApplyChangeTypeActions(materialType.Key, materialType.Value);
                    }
                }
            }
            
            //---End DEE Code---
            return Input;
        }
    }
}