﻿using Cmf.Custom.IKEA.Common;
using Cmf.Navigo.BusinessObjects;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Custom.IKEA.Common.Abstractions;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using Microsoft.Extensions.DependencyInjection;

namespace Cmf.Custom.IKEA.Actions.Materials
{
    public class CustomCreateMaterialSetDefaultRejectQuantity : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Set the default Reject unit and secondary quantity if nothing is define
            /// Action Groups:
            ///     BusinessObjects.MaterialCollection.Create.Pre
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.MaterialCollection.Create.Pre"
            };

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            if (executionVeridict && IKEADEEActionUtilities.GetInputItem<IMaterialCollection>(Input, Navigo.Common.Constants.MaterialCollection) == null)
            {
                executionVeridict = false;
            }

            return executionVeridict;


            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
     

            //System
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.Common.dll", "Cmf.Navigo.Common");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");

            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            IMaterialCollection materials = IKEADEEActionUtilities.GetInputItem<IMaterialCollection>(Input, Navigo.Common.Constants.MaterialCollection);

            if (materials.Count > 0)
            {
                // Get the default reject unit
                string rejectUnit = genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.ScrapManagementRejectUnit);

                // Check if any reject unit is configured
                if (!string.IsNullOrWhiteSpace(rejectUnit))
                {
                    // Go through all materials without a secondary unit and quantity defined to set the default reject unit and quantity
                    foreach (IMaterial material in materials.Where(m => string.IsNullOrWhiteSpace(m.SecondaryUnits) && (m.SecondaryQuantity == null || m.SecondaryQuantity == 0)))
                    {
                        material.SecondaryUnits = rejectUnit;
                        material.SecondaryQuantity = 0;
                    }
                }
            }

            

            //---End DEE Code---

            return Input;
        }
    }
}
