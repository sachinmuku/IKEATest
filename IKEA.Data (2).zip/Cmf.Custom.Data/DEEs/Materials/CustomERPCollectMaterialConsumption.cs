﻿using Cmf.Custom.IKEA.BusinessObjects;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Extensions;
using Cmf.Custom.IKEA.Common.Extensions.BOM;
using Cmf.Foundation.Common;
using Cmf.Navigo.BusinessObjects;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using Cmf.Custom.IKEA.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Common.CustomActionUtilities;
using Cmf.Custom.IKEA.Actions.ProcessRules.EntityTypes;
using Cmf.Custom.IKEA.Common.DEE;


namespace Cmf.Custom.IKEA.Actions.Materials
{
    public class CustomERPCollectMaterialConsumption : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Logs all material consumptions to be reported in the future to the ERP
            /// Action Groups:
            ///      BusinessObjects.Material.Assemble.Post
            ///      BusinessObjects.Material.AutomaticAssemble.Post
            /// </summary>
            #endregion
          
            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "Extensions.CustomAssembleEngine.CustomPerformAutomaticAssemble.Post",
            };

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            if (executionVeridict
                && IKEADEEActionUtilities.GetInputItem<IMaterial>(Input, "Material") == null
                && IKEADEEActionUtilities.GetInputItem<Dictionary<CustomBOMProductInformation, CustomBOMConsumptionInformation>>(Input, "CustomAssembleConsumptionDetails") == null)
            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            //System
            UseReference("", "Cmf.Custom.IKEA.BusinessObjects.Abstractions");
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("", "System");

            //Foundation
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            //Custom
            UseReference("Cmf.Custom.IKEA.BusinessObjects.CustomERPOperationTracking.dll", "Cmf.Custom.IKEA.BusinessObjects");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Extensions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Extensions.BOM");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            IMaterial assembledMaterial = IKEADEEActionUtilities.GetInputItem<IMaterial>(Input, "Material");
            Dictionary<long, Dictionary<CustomBOMProductInformation, CustomBOMConsumptionInformation>> quantitiesToAssemble = IKEADEEActionUtilities.GetInputItem<Dictionary<long, Dictionary<CustomBOMProductInformation, CustomBOMConsumptionInformation>>>(Input, "CustomAssembleConsumptionDetails");



            // Get the ERPOperationTracking for the material and ERP Operation code
            ICustomERPOperationTracking erpOperationTracking = assembledMaterial.GetCurrentCustomERPOperatingTracking(false);

            if (!quantitiesToAssemble.IsNullOrEmpty() && erpOperationTracking != null)
            {
                CustomBOMConsumptionInformationCollection consumedMaterialData = new CustomBOMConsumptionInformationCollection();
                consumedMaterialData.AddRange(quantitiesToAssemble.SelectMany(QA => QA.Value.Values).ToList());

                // Log Consumptions
                erpOperationTracking.LogConsumption(assembledMaterial, consumedMaterialData);
            }

            //---End DEE Code---

            return Input;
        }

    }
}
