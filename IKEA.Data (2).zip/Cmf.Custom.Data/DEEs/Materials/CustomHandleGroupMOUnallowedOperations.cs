﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Extensions;
using Cmf.Custom.IKEA.Orchestration.InputObjects;
using Cmf.Custom.IKEA.Orchestration.OutputObjects;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.Materials
{
    class CustomHandleGroupMOUnallowedOperations : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info

            /// <summary>
            /// Summary text
            ///     This DEE invalidates operations that are not yet prepared to handle with Group MOs 
            /// Action Groups:
            ///    "BusinessObjects.Material.Merge.Pre"
            ///    "BusinessObjects.Material.Release.Post"
            ///    "BusinessObjects.MaterialCollection.Split.Pre"
            ///    "BusinessObjects.MaterialCollection.ChangeFlowAndStep.Pre"
            ///    "BusinessObjects.MaterialCollection.ChangeQuantity.Pre"    
            ///    "BusinessObjects.MaterialCollection.ChangeType.Pre"
            ///    "BusinessObjects.MaterialCollection.MoveToNextStep.Pre"
            ///    "BusinessObjects.MaterialCollection.MoveToStep.Pre"
            ///    "BusinessObjects.MaterialCollection.Hold.Post"
            ///    "Orchestration.IKEABusinessOrchestration.CustomPostponeMaterial.Pre"
            /// </summary>

            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                  "BusinessObjects.Material.Merge.Pre"
                , "BusinessObjects.Material.Release.Post"
                , "BusinessObjects.MaterialCollection.Split.Pre"
                , "BusinessObjects.MaterialCollection.ChangeFlowAndStep.Pre"
                , "BusinessObjects.MaterialCollection.ChangeQuantity.Pre"
                , "BusinessObjects.MaterialCollection.ChangeType.Pre"
                , "BusinessObjects.MaterialCollection.MoveToNextStep.Pre"
                , "BusinessObjects.MaterialCollection.MoveToStep.Pre"
                , "BusinessObjects.MaterialCollection.Hold.Post"
                , "Orchestration.IKEABusinessOrchestration.CustomPostponeMaterial.Pre"
                
            };

            // Only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
     

            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "");
            UseReference("", "Cmf.Foundation.Common.Exceptions");
            UseReference("", "Cmf.Foundation.Common");
            UseReference("Cmf.Navigo.Common.dll", "Cmf.Navigo.Common");
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.ResourceManagement");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.ResourceManagement.InputObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.ResourceManagement.OutputObjects");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Extensions");
            UseReference("Cmf.Custom.IKEA.Orchestration.dll", "Cmf.Custom.IKEA.Orchestration.OutputObjects");
            UseReference("Cmf.Custom.IKEA.Orchestration.dll", "Cmf.Custom.IKEA.Orchestration.InputObjects");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();

            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();

            Collection<long> processedResources = deeContextUtilities.GetContextParameter(IKEAConstants.CustomResourceMaterialEventsPublisherProcessedResourceEvents) as Collection<long>;

            // holds list of distinct resources received.
            Collection<long> incomingResourceIds = new Collection<long>();

            // extract resources based on input
            if (Input != null)
            {
                // get triggering action group
                string actionGroup = IKEADEEActionUtilities.GetActionGroup(Input);

                // initialize a collection for the materials to validate:
                IMaterialCollection materials = entityFactory.CreateCollection<IMaterialCollection>();

                // When it's true (default) blocks the operations both for GroupMO materials
                // as well as their children. When it's false, blocks only for their children (but allows for GroupMOs)
                bool blockParentOperations = true;

                // If the groupExtract the materials based on action group
                bool? isGroupMoBeingEdited = deeContextUtilities.GetContextParameter(IKEAConstants.CustomHandleGroupManufacturingOrdersEditGroupMOContextKey) as bool?;
                if (!isGroupMoBeingEdited.GetValueOrDefault())
                {

                    switch (actionGroup)
                    {

                        case "BusinessObjects.MaterialCollection.ChangeType.Pre":
                            Dictionary<IMaterial, string> materialTypes = Input["MaterialTypes"] as Dictionary<IMaterial, string>;
                            materials.AddRange(materialTypes.Keys);
                            break;

                        case "BusinessObjects.MaterialCollection.ChangeFlowAndStep.Pre":
                        case "BusinessObjects.MaterialCollection.MoveToNextStep.Pre":
                        case "BusinessObjects.MaterialCollection.MoveToStep.Pre":
                            IMaterialCollection materialCollection = IKEADEEActionUtilities.GetInputItem<IMaterialCollection>(Input, Navigo.Common.Constants.MaterialCollection);
                            materials.AddRange(materialCollection);
                            break;

                        case "BusinessObjects.MaterialCollection.ChangeQuantity.Pre":
                            // check if change quantity is coming from palletization process:
                            bool? isGroupMOChangeQty = deeContextUtilities.GetContextParameter(IKEAConstants.CustomUnitCompleteHandlerUpdateGroupMOQuantityContextKey) as bool?;
                            // check if change quantity is coming from overproduction:
                            bool? isOverProdChangeQty = deeContextUtilities.GetContextParameter(IKEAConstants.UpdateGroupMOPrimaryQuantityOverProductionContextKey) as bool?;

                            if (!isGroupMOChangeQty.GetValueOrDefault() && !isOverProdChangeQty.GetValueOrDefault())
                            {
                                IMaterialQuantityChangeCollection materialQuantities = IKEADEEActionUtilities.GetInputItem<IMaterialQuantityChangeCollection>(Input, "MaterialQuantityChangeCollection");
                                materials.AddRange(materialQuantities.Select(MQ => MQ.Material));
                            }
                            break;

                        case "Orchestration.IKEABusinessOrchestration.CustomPostponeMaterial.Pre":
                            // We want to allow postponing of a Group MO as a whole, but not of the children individually
                            blockParentOperations = false;

                            CustomPostponeMaterialInput customPostponeMaterialInput = IKEADEEActionUtilities.GetInputItem<CustomPostponeMaterialInput>(Input, "CustomPostponeMaterialInput");
                            if (customPostponeMaterialInput != null && customPostponeMaterialInput.Material != null)
                            {
                                materials.Add(customPostponeMaterialInput.Material);
                            }
                            break;

                        case "BusinessObjects.Material.Release.Post":
                        case "BusinessObjects.Material.Merge.Pre":
                            IMaterial material = IKEADEEActionUtilities.GetInputItem<IMaterial>(Input, "Material");
                            materials.Add(material);
                            break;

                        case "BusinessObjects.MaterialCollection.Split.Pre":
                            // check if split is coming from palletization process
                            bool? isPalletizationSplit = deeContextUtilities.GetContextParameter(IKEAConstants.CustomUnitCompletePalletizationSplitContextKey) as bool?;
                            if (!isPalletizationSplit.GetValueOrDefault())
                            {
                                Dictionary<IMaterial, ISplitInputParametersCollection> childMaterialsInformation = Input["ChildMaterialsInformation"] as Dictionary<IMaterial, ISplitInputParametersCollection>;
                                materials.AddRange(childMaterialsInformation.Keys);
                            }
                            break;

                        case "BusinessObjects.MaterialCollection.Hold.Post":
                            IMaterialCollection materialsOnHold = IKEADEEActionUtilities.GetInputItem<IMaterialCollection>(Input, "MaterialCollection");
                            materials.AddRange(materialsOnHold);
                            break;

                        default:
                            break;

                    }

                    if (!materials.IsNullOrEmpty())
                    {
                        // Get order form (we only want to evaluate MO materials)
                        string orderForm = ikeaUtilities.GetOrderMaterialForm();

                        // Load atribute 'IsGroupMO' 
                        materials.LoadAttributes(new Collection<string> { IKEAConstants.CustomMaterialAttributeIsGroupMO });

                        // Load relations with child MOs:
                        materials.LoadRelations(IKEAConstants.CustomGroupMaterialManufacturingOrder);

                        foreach (var material in materials)
                        {
                            if (material.Form.CompareStrings(orderForm))
                            {
                                if ((blockParentOperations && material.IsGroupMO(loadAttributes: false, loadRelations: false)) || 
                                    material.IsChildOfGroupMO())
                                {
                                    throw new CmfBaseException(ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomGroupMOUnsupportedMESOperationLocalizedMessage, actionGroup));
                                }
                            }
                        }
                    }

                }
            }

            
            //---End DEE Code---

            return Input;
        }
    }
}
