﻿using Cmf.Custom.IKEA.Common;
using Cmf.Navigo.BusinessObjects;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cmf.Foundation.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Common.CustomActionUtilities;
using Cmf.Custom.IKEA.Common.Abstractions;
using Microsoft.Extensions.DependencyInjection;


namespace Cmf.Custom.IKEA.Actions.Materials
{
    public class CustomUpdateMOQuantityOnPalletHold : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text:
            /// Action that decreases the MO quantity, when a pallet with type ReRun or DirectRepair (InLine) is put on hold and saves that operation it to a flag attribute.
            /// Requisites:
            /// The MO must be InProcess; 
            /// The MO and pallet must belong to the same Run.
            /// Action Groups:
            /// BusinessObjects.MaterialCollection.Hold.Post
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.MaterialCollection.Hold.Post"
            };

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            if (executionVeridict
                && IKEADEEActionUtilities.GetInputItem<IMaterialCollection>(Input, "MaterialCollection") == null
                && IKEADEEActionUtilities.GetInputItem<IMaterialHoldReasonCollection>(Input, "MaterialHoldReasonCollection") == null)
            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }
        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            //System
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");

            //Foundation
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IMaterialCollection materials = IKEADEEActionUtilities.GetInputItem<IMaterialCollection>(Input, "MaterialCollection");

            // Check if the list contains materials
            if (!materials.IsNullOrEmpty())
            {
                ikeaUtilities.DecrementMOPrimaryQuantityOnMaterialHold(materials);
            }

            //---End DEE Code---

            return Input;
        }


    }
}