﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.BusinessObjects;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Utilities;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessObjects.QueryObject;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Foundation.Common.Base;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.Materials
{
    public class CustomAugmentMaterialGenealogy : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Adds additional fields to the Genealogy objects created as a result of certain operations on materials,
            ///     such as adding the Resource of the materials after Splits.
            /// Action Groups:
            ///     BusinessObjects.MaterialCollection.Split.Pre
            ///     BusinessObjects.MaterialCollection.Split.Post
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.MaterialCollection.Split.Pre",
                "BusinessObjects.MaterialCollection.Split.Post",
            };

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            if (executionVeridict)
            {
                if (IKEADEEActionUtilities.GetInputItem<IMaterialCollection>(Input, "MaterialCollection") == null)
                {
                    executionVeridict = false;
                }
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

 UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
     

            // System
            UseReference("", "System.Linq");
            UseReference("", "System.Data");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System");
            UseReference("", "System.Collections.ObjectModel");

            // Foundation
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects.QueryObject");

            // Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            // Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            // Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.BusinessObjects.CustomPOOperationResource.dll", "Cmf.Custom.IKEA.BusinessObjects");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();


            const string ParentResourcesContextKey = "CustomAugmentMaterialGenealogy_ParentResourceByMaterialId";

            DeeContext currentContext = deeContextUtilities.SetCurrentServiceContext("CustomAugmentMaterialGenealogy");

            // Get the reference of the parent materials being split
            var parentMaterials = IKEADEEActionUtilities.GetInputItem<IMaterialCollection>(Input, "MaterialCollection");

            if (currentContext.TriggerPoint == DeeTriggerPoint.Pre)
            {
                // Load the Material Resource relation
                parentMaterials.LoadRelations(nameof(MaterialResource));

                // Create a dictionary associating each parent material (by it's Id) with it's resource
                Dictionary<long, IResource> parentResourceByMaterialId = parentMaterials.ToDictionary(
                    material => material.Id,
                    material =>
                    {
                        if (  material.RelationCollection == null
                          || !material.RelationCollection.ContainsKey(nameof(MaterialResource))
                          ||  material.RelationCollection[nameof(MaterialResource)].IsNullOrEmpty())
                        {
                            return null;
                        }

                        return material.RelationCollection[nameof(MaterialResource)]
                            .Cast<IMaterialResource>()
                            .First()
                            .TargetEntity;
                    }
                );

                // Save the parent resource by material
                deeContextUtilities.SetContextParameter(ParentResourcesContextKey, parentResourceByMaterialId);
            }
            else if (currentContext.TriggerPoint == DeeTriggerPoint.Post)
            {
                var parentResourceByMaterialId = deeContextUtilities.GetContextParameter(ParentResourcesContextKey) as Dictionary<long, IResource>;

                // Get the references of the child materials created after the split, grouped by their parents
                var childMaterials = IKEADEEActionUtilities.GetInputItem<Dictionary<IMaterial, IMaterialCollection>>(Input, "OutputChildMaterials");

                // Create a collection which we will use to load the material resource relations, from the children 
                IMaterialCollection materialsWithResources = entityFactory.CreateCollection<IMaterialCollection>();

                // And add all the children
                materialsWithResources.AddRange(
                    childMaterials.SelectMany(pair => pair.Value)
                );

                // Load the Material Resource relation
                materialsWithResources.LoadRelations(nameof(MaterialResource));

                IGenealogyCollection genealogyCollection = entityFactory.CreateCollection<IGenealogyCollection>();
                

                #region Query the Genealogy objects created for the children

                IQueryObject query = new QueryObject();
                query.Description = "";
                query.EntityTypeName = "Genealogy";
                query.Name = "GetGenealogySplits";
                query.Query = new Query();
                query.Query.Distinct = false;
                query.Query.Filters = new FilterCollection() {
                new Cmf.Foundation.BusinessObjects.QueryObject.Filter()
                    {
                        Name = "Operation",
                        ObjectName = "Genealogy",
                        ObjectAlias = "Genealogy_1",
                        Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                        Value = "Split",
                        LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND,
                        FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                    },
                    new Cmf.Foundation.BusinessObjects.QueryObject.Filter()
                    {
                        Name = "Name",
                        ObjectName = "Material",
                        ObjectAlias = "Genealogy_DescMaterial_2",
                        Operator = Cmf.Foundation.Common.FieldOperator.In,
                        Value = childMaterials.SelectMany(pair => pair.Value).Select(mat => mat.Name).ToList(),
                        LogicalOperator = Cmf.Foundation.Common.LogicalOperator.Nothing,
                        FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                    },
                    // Ignore results where the AscMaterial is Terminated (because in those instances
                    // we cannot Unterminate the Genealogy in order to change it)
                    new Cmf.Foundation.BusinessObjects.QueryObject.Filter()
                    {
                        Name = "UniversalState",
                        ObjectName = "Material",
                        ObjectAlias = "Genealogy_AscMaterial_3",
                        Operator = Cmf.Foundation.Common.FieldOperator.IsNotEqualTo,
                        Value = 4,
                        LogicalOperator = Cmf.Foundation.Common.LogicalOperator.Nothing,
                        FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                    }
                };
                query.Query.Fields = new FieldCollection() {
                    new Field()
                    {
                        Alias = "Id",
                        ObjectName = "Genealogy",
                        ObjectAlias = "Genealogy_1",
                        IsUserAttribute = false,
                        Name = "Id",
                        Position = 0,
                        Sort = Cmf.Foundation.Common.FieldSort.NoSort
                    },
                    new Field()
                    {
                        Alias = "Name",
                        ObjectName = "Genealogy",
                        ObjectAlias = "Genealogy_1",
                        IsUserAttribute = false,
                        Name = "Name",
                        Position = 1,
                        Sort = Cmf.Foundation.Common.FieldSort.NoSort
                    },
                    new Field()
                    {
                        Alias = "Operation",
                        ObjectName = "Genealogy",
                        ObjectAlias = "Genealogy_1",
                        IsUserAttribute = false,
                        Name = "Operation",
                        Position = 3,
                        Sort = Cmf.Foundation.Common.FieldSort.NoSort
                    },
                };
                query.Query.Relations = new RelationCollection() {
                    new Relation()
                    {
                        Alias = "",
                        IsRelation = false,
                        Name = "",
                        SourceEntity = "Genealogy",
                        SourceEntityAlias = "Genealogy_1",
                        SourceJoinType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.JoinType.InnerJoin,
                        SourceProperty = "DescMaterialId",
                        TargetEntity = "Material",
                        TargetEntityAlias = "Genealogy_DescMaterial_2",
                        TargetJoinType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.JoinType.InnerJoin,
                        TargetProperty = "Id"
                    },
                    new Relation()
                    {
                        Alias = "",
                        IsRelation = false,
                        Name = "",
                        SourceEntity = "Genealogy",
                        SourceEntityAlias = "Genealogy_1",
                        SourceJoinType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.JoinType.InnerJoin,
                        SourceProperty = "AscMaterialId",
                        TargetEntity = "Material",
                        TargetEntityAlias = "Genealogy_AscMaterial_3",
                        TargetJoinType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.JoinType.InnerJoin,
                        TargetProperty = "Id"
                    }
                };

                #endregion

                DataSet genealogyDataSet = query.Execute(false, new QueryParameterCollection());

                if (genealogyDataSet.HasData())
                {
                    // Create the Genealogy objects from the query results
                    genealogyCollection.LoadByIDs<IGenealogy, Genealogy>(
                        genealogyDataSet.Tables[0].Rows
                            .OfType<DataRow>()
                            .Select(row => row.Field<long>("Id"))
                            .ToList()
                    );
                }

                // If there is any genealogy object returned
                if (genealogyCollection.Any())
                {
                    // Create a dictionary associating each child material (by it's Id) with it's resource
                    Dictionary<long, IResource> resourceByMaterialId = materialsWithResources.ToDictionary(
                        material => material.Id,
                        material =>
                        {
                            if (  material.RelationCollection == null
                              || !material.RelationCollection.ContainsKey(nameof(MaterialResource))
                              ||  material.RelationCollection[nameof(MaterialResource)].IsNullOrEmpty())
                            {
                                return null;
                            }

                            return material.RelationCollection[nameof(MaterialResource)]
                                .Cast<IMaterialResource>()
                                .First()
                                .TargetEntity;
                        }
                    );

                    // Add the parent resources collected during the Pre trigger point
                    resourceByMaterialId.AddRange(parentResourceByMaterialId);

                    // Collection that will contain any modified genealogies that need saving
                    IGenealogyCollection genealogiesToSave = entityFactory.CreateCollection<IGenealogyCollection>();

                    // Collection that will contain any genealogies that are already terminated. We must unterminate 
                    // them before we can make any modifications to them
                    IGenealogyCollection genelaogiesToUnterminate = entityFactory.CreateCollection<IGenealogyCollection>();

                    // Store the fields that can be changed in the genealogy here, so that if we need to Load
                    // the genealogy, we don't lose these values
                    var genealogyChanges = new Dictionary<long, (IResource ParentResource, IResource ChildResource)>();

                    foreach (var genealogy in genealogyCollection)
                    {
                        bool needsSaving = false;

                        // Only store the parent resource if the field is empty
                        // Note: genealogy.ParentResource is actually stored in the column AscResource in the database
                        if (genealogy.GetNativeValue<long>("AscResource") == 0)
                        {
                            // Get the parent material Id
                            long materialId = genealogy.GetNativeValue<long>(nameof(Genealogy.AscMaterial));

                            if (resourceByMaterialId.ContainsKey(materialId) && resourceByMaterialId[materialId] != null)
                            {
                                genealogy.ParentResource = resourceByMaterialId[materialId];
                                needsSaving = true;
                            }
                        }

                        // Only store the child resource if the field is empty
                        // Note: genealogy.ChildResource is actually stored in the column DescResource in the database
                        if (genealogy.GetNativeValue<long>("DescResource") == 0)
                        {
                            // Get the parent material Id
                            long materialId = genealogy.GetNativeValue<long>(nameof(Genealogy.DescMaterial));

                            if (resourceByMaterialId.ContainsKey(materialId) && resourceByMaterialId[materialId] != null)
                            {
                                genealogy.ChildResource = resourceByMaterialId[materialId];
                                needsSaving = true;
                            }
                        }

                        // If any properties of this genealogy instance were modified, add it to the collection
                        // which will later be used to save them
                        if (needsSaving)
                        {
                            genealogiesToSave.Add(genealogy);

                            genealogyChanges[genealogy.Id] = (genealogy.ParentResource, genealogy.ChildResource);

                            if (genealogy.UniversalState == UniversalState.Terminated)
                            {
                                genelaogiesToUnterminate.Add(genealogy);
                            }
                        }
                    }

                    if (genelaogiesToUnterminate.Any())
                    {
                        genelaogiesToUnterminate.Unterminate();

                        // After we unterminate them, we lost the changes we made to the genealogiy objects in memory, 
                        // so we re-apply them
                        foreach (var genealogy in genelaogiesToUnterminate)
                        {
                            var pair = genealogyChanges[genealogy.Id];

                            genealogy.ParentResource = pair.ParentResource;
                            genealogy.ChildResource = pair.ChildResource;
                        }
                    }

                    if (genealogiesToSave.Any())
                    {
                        genealogiesToSave.Save();
                    }

                    // After making the changes, terminate back any genealogy instances that were previously terminated
                    if (genelaogiesToUnterminate.Any())
                    {
                        genelaogiesToUnterminate.Terminate();
                    }
                }
            }

            
            //---End DEE Code---

            return Input;
        }

    }
}
