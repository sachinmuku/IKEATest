﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Exceptions;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.DispatchManagement.InputObjects;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.Materials
{
    public class CustomValidateResourcesAtPreDispatch : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   
            #region Info
            /// <summary>
            /// Summary text
            ///     Validates if there is resources in order to dispatch material. If no resources are Up, it will throw an error
            /// Action Groups:
            ///     BusinessObjects.MaterialCollection.Dispatch.Pre
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion
            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];

            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();


            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "DispatchManagement.DispatchManagementOrchestration.GetDispatchListForMaterial.Pre"
            };

            // only proceed if within expected triggers (action groups)
            if (IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups) && Input.TryGetValue("GetDispatchListForMaterialInput", out object materialToDispatch))
            {
                IMaterial material = (materialToDispatch as GetDispatchListForMaterialInput).Material;
                material.Load();
                if (material.Step.ProcessingType == StepProcessingType.Logistical)
                {
                    return false;
                }
                
                // only proceed if DispatchType is process:
                ProcessingType dispatchProcessingType = (materialToDispatch as GetDispatchListForMaterialInput).DispatchType;
                if (dispatchProcessingType != ProcessingType.Process)
                {
                    return false;
                }
                
                deeContextUtilities.SetContextParameter("MaterialToDispatch", material);
                return true;
            }

            return false;
            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---  
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Exceptions");
UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");			
            //System
            UseReference("", "System");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("", "System.Linq");
            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Extensions");
            //Foundation
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration");
            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.DispatchManagement.InputObjects");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();

            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();


            IMaterial material = deeContextUtilities.GetContextParameter("MaterialToDispatch") as IMaterial;
            IResourceCollection activeResourcesList = entityFactory.CreateCollection<IResourceCollection>();

            IResourceCollection resourceList = material.Step.GetResourcesForStep();

            // If all resources associated with the step have a system state different from 'Up' it triggers the associated error.
            if (resourceList.All(r => r.SystemState != ResourceSystemState.Up))
            {
                throw new IKEAException(IKEAConstants.CustomNoResourcesUpAvailable);
            }

            //---End DEE Code---

            return Input;
        }

       
    }
}
