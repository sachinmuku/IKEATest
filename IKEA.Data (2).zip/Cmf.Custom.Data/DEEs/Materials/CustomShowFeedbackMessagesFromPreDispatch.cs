﻿using System.Collections.Generic;
using System.Collections.ObjectModel;
using Cmf.Common.CustomActionUtilities;
using Cmf.Custom.IKEA.Common;
using Cmf.Foundation.BusinessOrchestration;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;

namespace Cmf.Custom.IKEA.Actions.Materials
{
    public class CustomShowFeedbackMessagesFromPreDispatch : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     
            /// Action Groups:
            ///     BusinessOrchestration.MaterialManagement.MaterialManagementOrchestration.DispatchMaterials.Post
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "MaterialManagement.MaterialManagementOrchestration.DispatchMaterials.Post"
            };

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            if (executionVeridict && Input == null)
            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
			UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
            //System
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            //Foundation
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration");
            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects");


            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];

            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();
            string contextFeedbackMessages = "CustomValidateFlowPathAtPreDispatch_FeedbackMessages";


            Dictionary<IMaterial, FeedbackMessage> messages = deeContextUtilities.GetContextParameter(contextFeedbackMessages) as Dictionary<IMaterial, FeedbackMessage>;

            if (messages != null)
            {
                BaseOutput output = null;
                IMaterialCollection materials = null;
                if (Input.ContainsKey("DispatchMaterialsOutput"))
                {
                    materials = (Input["DispatchMaterialsOutput"] as DispatchMaterialsOutput).Materials;
                    output = Input["DispatchMaterialsOutput"] as DispatchMaterialsOutput;
                }

                if (output != null && materials != null)
                {
                    if (output.FeedbackMessages == null)
                    {
                        output.FeedbackMessages = new Collection<FeedbackMessage>();
                    }

                    foreach (var item in messages)
                    {
                        if (materials.Exists(item.Key))
                        {
                            output.FeedbackMessages.Add(item.Value);
                        }
                    }
                }

            }

            //---End DEE Code---

            return Input;
        }

    }
}
