﻿using Cmf.Custom.IKEA.Common;
using Cmf.Foundation.Common;
using Cmf.Navigo.BusinessObjects;
using Cmf.Common.CustomActionUtilities;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Custom.IKEA.Common.Abstractions;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using Microsoft.Extensions.DependencyInjection;


namespace Cmf.Custom.IKEA.Actions.Materials
{
    public class CustomSplitMaterialValidation : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Prevents generating materials on split with a total quantity of zero units.              
            /// Action Groups:
            ///     BusinessObjects.MaterialCollection.Split.Pre
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.MaterialCollection.Split.Pre",
            };

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            if (executionVeridict && IKEADEEActionUtilities.GetInputItem<Dictionary<IMaterial, ISplitInputParametersCollection>>(Input, "ChildMaterialsInformation") == null)
            {
                executionVeridict = false;
            }
            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            //System
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("", "System");

            //Foundation
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.Common.dll", "Cmf.Foundation.Common");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");


            Dictionary<IMaterial, ISplitInputParametersCollection> childMaterialsInformation = Input["ChildMaterialsInformation"] as Dictionary<IMaterial, ISplitInputParametersCollection>;
            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];

            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();

            if (!childMaterialsInformation.IsNullOrEmpty())
            {
                // Get the default reject unit
                string rejectUnit = genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.ScrapManagementRejectUnit);

                foreach (var childMaterialInformation in childMaterialsInformation)
                {
                    // Get source material:
                    IMaterial sourceMaterial = childMaterialInformation.Key;

                    // Determine total quantity except 'Rejects':
                    decimal sourceTotalQuantity = sourceMaterial.PrimaryQuantity.GetValueOrDefault();

                    if ((!sourceMaterial.SecondaryUnits.CompareStrings(rejectUnit) || sourceTotalQuantity == 0) && sourceMaterial.SecondaryQuantity.HasValue)
                    {
                        sourceTotalQuantity += sourceMaterial.SecondaryQuantity.Value;
                    }

                    // If the source material total quantity, without rejects, is 0, it is not possible to generate a child with a quantity different than 0:
                    if (sourceTotalQuantity == 0)
                    {
                        throw new CmfBaseException(ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomMaterialZeroQuantityNotPossibleLocalizedMessage));
                    }

                    // Check each child total quantities:
                    foreach (ISplitInputParameters splitInputParameters in childMaterialInformation.Value)
                    {
                        decimal childTotalQuantity = splitInputParameters.PrimaryQuantity;
                        childTotalQuantity += splitInputParameters.SecondaryQuantity.HasValue ? splitInputParameters.SecondaryQuantity.Value : 0;

                        if (childTotalQuantity == 0)
                        {
                            throw new CmfBaseException(ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomMaterialZeroQuantitySplitNotPossibleLocalizedMessage));
                        }
                    }
                }
            }
            //---End DEE Code---

            return Input;
        }
    }
}

