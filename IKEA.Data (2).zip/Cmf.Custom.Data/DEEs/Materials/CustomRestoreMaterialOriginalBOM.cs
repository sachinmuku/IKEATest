﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Foundation.BusinessOrchestration.Abstractions;
using Cmf.Foundation.BusinessOrchestration.GenericServiceManagement;
using Cmf.Foundation.BusinessOrchestration.GenericServiceManagement.InputObjects;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Foundation.Common.Base;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.Materials
{
    public class CustomRestoreMaterialOriginalBOM : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text:
            ///     Action to restore the UniversalState of certain BOMs to effective in the end of the TrackIn
            ///     When performing TrackIn on certain lines, the operator can replace some consumable feeders with alternative feeders
            ///     only for the MO being tracked in. In such cases, we create a new BOM version with the updated BOM Product relation attributes
            ///     before the TrackIn, and after the TrackIn we need to set back the main version as effective.
            /// Action Groups:
            ///     MaterialManagement.MaterialManagementOrchestration.ComplexTrackInMaterials.Post
            /// </summary>
            #endregion

            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();
            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "MaterialManagement.MaterialManagementOrchestration.ComplexTrackInMaterials.Post"
            };

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            if (executionVeridict
                && IKEADEEActionUtilities.GetInputItem<ComplexTrackInMaterialsInput>(Input, "ComplexTrackInMaterialsInput") == null)
            {
                executionVeridict = false;
            }

            if (executionVeridict)
            {
                var originalBOMVersions = deeContextUtilities.GetContextParameter(IKEAConstants.CustomRevertOriginalMaterialBOMVersionsAfterTrackInContextKey) as HashSet<long>;

                if (originalBOMVersions.IsNullOrEmpty())
                {
                    executionVeridict = false;
                }
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
            //System
            UseReference("", "Cmf.Foundation.BusinessOrchestration.Abstractions");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("%MicrosoftNetPath%\\System.Data.dll", "System.Data");
            UseReference("%MicrosoftNetPath%\\System.Data.DataSetExtensions.dll", "");
            UseReference("", "System.Linq");
            UseReference("%MicrosoftNetPath%\\System.XML.dll", "System.Xml");

            //Foundation
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessOrchestration.GenericServiceManagement");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessOrchestration.GenericServiceManagement.InputObjects");
            UseReference("Cmf.Foundation.Common.dll", "Cmf.Foundation.Common");

            //Navigo
            UseReference("Cmf.Navigo.Common.dll", "Cmf.Navigo.Common");
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            //IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();
            var genericServiceOrchestration = serviceProvider.GetService<IGenericServiceOrchestration>();

            var originalBOMVersions = deeContextUtilities.GetContextParameter(IKEAConstants.CustomRevertOriginalMaterialBOMVersionsAfterTrackInContextKey) as HashSet<long>;

            if (originalBOMVersions.IsNullOrEmpty())
            {
                IBOMCollection originalBOMs = entityFactory.CreateCollection<IBOMCollection>();
                originalBOMs.LoadByIDs<IBOM, BOM>(originalBOMVersions.ToList());

                Collection<object> bomsToSetEffective = new Collection<object>();
                bomsToSetEffective.AddRange(
                    originalBOMs.Where(bom => bom.UniversalState == UniversalState.Active)
                );

                genericServiceOrchestration.SetObjectVersionsEffective(new SetObjectVersionsEffectiveInput
                {
                    Objects = bomsToSetEffective,
                });
            }

            deeContextUtilities.SetContextParameter(IKEAConstants.CustomRevertOriginalMaterialBOMVersionsAfterTrackInContextKey, null);

            //---End DEE Code---
            return Input;
        }

    }
}
