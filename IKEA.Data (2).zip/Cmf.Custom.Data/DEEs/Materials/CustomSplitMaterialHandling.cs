﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Exceptions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessObjects.QueryObject;
using Cmf.Foundation.BusinessObjects.SmartTables;
using Cmf.Foundation.BusinessOrchestration.Abstractions;
using Cmf.Foundation.BusinessOrchestration.TableManagement;
using Cmf.Foundation.BusinessOrchestration.TableManagement.InputObjects;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.Materials
{
    public class CustomSplitMaterialHandling : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Set the base material on split of the materials
            ///     Validate if Split is being done on secondary unit of type Reject
            /// Action Groups:
            ///     BusinessObjects.MaterialCollection.Split.Post
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.MaterialCollection.Split.Post",
            };

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);
            if (executionVeridict && Input == null)
            {
                executionVeridict = false;
            }
            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---    
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Exceptions");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
            //System
            UseReference("", "Cmf.Foundation.BusinessOrchestration.Abstractions");
UseReference("", "System.Data");
            UseReference("System.Data.SqlClient.dll", "System.Data.SqlClient");
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("", "System.IO");
            UseReference("", "System.Threading");
            UseReference("", "System");
            UseReference("%MicrosoftNetPath%\\System.XML.dll", "System.Xml");
            UseReference("%MicrosoftNetPath%\\System.XML.Linq.dll", "System.Xml.Linq");

            //Foundation
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("", "Cmf.Foundation.BusinessObjects.QueryObject");
            UseReference("", "Cmf.Foundation.BusinessObjects.SmartTables");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.TableManagement");
            UseReference("", "Cmf.Foundation.BusinessOrchestration.TableManagement.InputObjects");
            UseReference("Cmf.Foundation.Common.dll", "Cmf.Foundation.Common");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            //IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            var tableOrchestration = serviceProvider.GetService<ITableOrchestration>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();

            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();


            if (Input.ContainsKey("OutputChildMaterials"))
            {
                Dictionary<IMaterial, IMaterialCollection> outputChildMaterials = Input["OutputChildMaterials"] as Dictionary<IMaterial, IMaterialCollection>;

                bool? completeUnit = ApplicationContext.CallContext.GetInformationContext("CustomMaterialAssembleRework_CompleteUnit") as bool?;

                // check if split is coming from palletization process
                bool? isPalletizationSplit = deeContextUtilities.GetContextParameter(IKEAConstants.CustomUnitCompletePalletizationSplitContextKey) as bool?;

                // Get the default reject unit
                string rejectUnit = genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.ScrapManagementRejectUnit);

                // get order material form to use
                string orderMaterialForm = ikeaUtilities.GetOrderMaterialForm();

                Dictionary<IMaterial, IAttributeCollection> materialAttributesToSave = new Dictionary<IMaterial, IAttributeCollection>();

                // Remove ERP Original Name from child materials
                IMaterialCollection childMaterials = entityFactory.CreateCollection<IMaterialCollection>();
                childMaterials.AddRange(outputChildMaterials.Values.SelectMany(E => E));
                childMaterials.RemoveAttributes(new Collection<string> { IKEAConstants.CustomMaterialAttributeERPOriginalName });

                // if source material is of form Order (config) and not within palletization process, collect all BOM Contexts to be added...
                if (!isPalletizationSplit.GetValueOrDefault())
                {
                    // collect main material names and respective child materials to copy
                    Dictionary<long, Collection<string>> materialAndChildsToProcess = outputChildMaterials.Where(E => String.Equals(E.Key.Form, orderMaterialForm) && E.Value != null).ToDictionary(E => E.Key.Id, E => new Collection<string>(E.Value.Select(CI => CI.Name).ToList()));

                    if (materialAndChildsToProcess.Any())
                    {
                        SqlParameter sqlMaterialIdList = new SqlParameter("@Materials", SqlDbType.NVarChar, 512) { Value = String.Join(";", materialAndChildsToProcess.Keys.Select(E => E.ToString())) };
                        DataSet dataSet = ikeaUtilities.ExecuteReader("[Custom].[P_GetMaterialBOMContextReferences]"
                                                                    , CommandType.StoredProcedure
                                                                    , sqlMaterialIdList);

                        // if any data found prepare records to insert
                        if (dataSet.HasData())
                        {
                            var foundSettings = dataSet.Tables[0].Rows.Cast<DataRow>().Select(E => new { 
                                    MaterialId = Convert.ToInt64(E["MaterialId"])
                                    , MaterialName = Convert.ToString(E["Material"])
                                    , Step = Convert.ToString(E["Step"])
                                    , Product = Convert.ToString(E["Product"])
                                    , ProductGroup = Convert.ToString(E["ProductGroup"])
                                    , Flow = Convert.ToString(E["Flow"])
                                    , BOM = Convert.ToString(E["BOM"])
                                    , AssemblyType = E["AssemblyType"] == DBNull.Value ? (Int32?)null : Convert.ToInt32(E["AssemblyType"])
                                    , TrackInCheckMode = E["TrackInCheckMode"] == DBNull.Value ? (Int32?)null : Convert.ToInt32(E["TrackInCheckMode"])
                                    , TrackOutLossesMode = E["TrackOutLossesMode"] == DBNull.Value ? (Int32?)null : Convert.ToInt32(E["TrackOutLossesMode"])
                                    , WeighAndDispenseMode = E["WeighAndDispenseMode"] == DBNull.Value ? (Int32?) null : Convert.ToInt32(E["WeighAndDispenseMode"])
                            });

                            // get template data set to handle
                            ISmartTable smartTable = new SmartTable();
                            smartTable.Load("BOMContext");
                            smartTable.LoadData(new Cmf.Foundation.BusinessObjects.QueryObject.FilterCollection()
                            {
                                new Cmf.Foundation.BusinessObjects.QueryObject.Filter()
                                {
                                    Name = "BOM",
                                    Operator = FieldOperator.IsNull
                                }
                            });

                            // ensure data set is empty
                            DataSet baseSet = NgpDataSet.ToDataSet(smartTable.Data);
                            baseSet.Tables[0].Rows.Clear();

                            // go through each found setting and replicate it to the children
                            foreach (var entry in foundSettings)
                            {
                                foreach(var childMaterial in materialAndChildsToProcess[entry.MaterialId])
                                {
                                    DataRow newRow = baseSet.Tables[0].NewRow();
                                    newRow[smartTable.Name + "Id"] = -1;
                                    newRow["LastServiceHistoryId"] = -1;
                                    newRow["LastOperationHistorySeq"] = -1;
                                    newRow["Step"] = entry.Step;
                                    newRow["Material"] = childMaterial;
                                    newRow["Product"] = String.IsNullOrWhiteSpace(entry.Product) ? (object) DBNull.Value : entry.Product;
                                    newRow["ProductGroup"] = String.IsNullOrWhiteSpace(entry.ProductGroup) ? (object) DBNull.Value : entry.ProductGroup;
                                    newRow["Flow"] = String.IsNullOrWhiteSpace(entry.Flow) ? (object) DBNull.Value : entry.Flow;
                                    newRow["BOM"] = entry.BOM;
                                    newRow["AssemblyType"] = entry.AssemblyType;
                                    newRow["TrackInCheckMode"] = entry.TrackInCheckMode;
                                    newRow["TrackOutLossesMode"] = entry.TrackOutLossesMode;
                                    newRow["WeighAndDispenseMode"] = (object) entry.WeighAndDispenseMode ?? DBNull.Value;
                                    baseSet.Tables[0].Rows.Add(newRow);
                                }
                            }

                            tableOrchestration.InsertOrUpdateSmartTableRows(new InsertOrUpdateSmartTableRowsInput()
                            {
                                SmartTable = smartTable,
                                Table = NgpDataSet.FromDataSet(baseSet)
                            });
                        }

                    }
                }

                foreach (var outputChildMaterial in outputChildMaterials)
                {
                    // Get Base Material
                    string baseMaterial = ikeaUtilities.GetPossibleBaseMaterial(outputChildMaterial.Key, completeUnit.HasValue ? !completeUnit.Value : true);

                    foreach (var childMaterial in outputChildMaterial.Value)
                    {
                        if (childMaterial.SecondaryUnits.CompareStrings(rejectUnit) && childMaterial.SecondaryQuantity > 0 && childMaterial.PrimaryQuantity > 0)
                        {
                            throw new IKEAException(IKEAConstants.CustomSplitRejectUnitErrorMessage, rejectUnit);
                        }
                        
                        IAttributeCollection attributes = new AttributeCollection
                        {
                            { IKEAConstants.CustomMaterialAttributeBaseMaterial, baseMaterial }
                        };

                        materialAttributesToSave.Add(childMaterial, attributes);
                    }
                }

                // Check if there are any attributes to save
                if (!materialAttributesToSave.IsNullOrEmpty())
                {
                    ikeaUtilities.SaveAttributesToMultipleMaterials(materialAttributesToSave); 
                }
            }
            //---End DEE Code---

            return Input;
        }

    }
}
