﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Exceptions;
using Cmf.Custom.IKEA.Common.Extensions;
using Cmf.Custom.IKEA.Orchestration.Abstractions;
using Cmf.Custom.IKEA.Orchestration.DataStructures;
using Cmf.Custom.IKEA.Orchestration.InputObjects;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessObjects.SmartTables;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Foundation.Marshalling.Serialization;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.Materials
{
    public class CustomMaterialHandleTrackInParameters : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text:
            ///     Action to set the selected Recipe and Default Completion Quantity at track in of the material
            /// Action Groups:
            ///     MaterialManagement.MaterialManagementOrchestration.ComplexTrackInMaterials.Pre
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "MaterialManagement.MaterialManagementOrchestration.ComplexTrackInMaterials.Pre"
            };

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            if (executionVeridict
                && IKEADEEActionUtilities.GetInputItem<ComplexTrackInMaterialsInput>(Input, "ComplexTrackInMaterialsInput") == null)
            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Exceptions");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
     

            //System
            UseReference("", "Cmf.Custom.IKEA.Orchestration.Abstractions");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("%MicrosoftNetPath%\\System.Data.dll", "System.Data");
            UseReference("%MicrosoftNetPath%\\System.Data.DataSetExtensions.dll", "");
            UseReference("", "System.Linq");
            UseReference("%MicrosoftNetPath%\\System.XML.dll", "System.Xml");
            UseReference("Newtonsoft.Json.dll", "Newtonsoft.Json");

            //Foundation
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects.SmartTables");
            UseReference("Cmf.Foundation.Marshalling.dll", "Cmf.Foundation.Marshalling.Converters");
            UseReference("Cmf.Foundation.Marshalling.dll", "Cmf.Foundation.Marshalling.Serialization");
            UseReference("Cmf.Foundation.Common.dll", "Cmf.Foundation.Common");

            //Navigo
            UseReference("Cmf.Navigo.Common.dll", "Cmf.Navigo.Common");
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Extensions");
            UseReference("Cmf.Custom.IKEA.Orchestration.dll", "Cmf.Custom.IKEA.Orchestration");
            UseReference("Cmf.Custom.IKEA.Orchestration.dll", "Cmf.Custom.IKEA.Orchestration.InputObjects");
            UseReference("Cmf.Custom.IKEA.Orchestration.dll", "Cmf.Custom.IKEA.Orchestration.DataStructures");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            var iKEABusinessManagementOrchestration = serviceProvider.GetService<IIKEABusinessManagementOrchestration>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();

            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();

            DeeContext currentContext = deeContextUtilities.SetCurrentServiceContext("CustomMaterialHandleTrackInParameters");

            ComplexTrackInMaterialsInput trackInMaterialsInput = IKEADEEActionUtilities.GetInputItem<ComplexTrackInMaterialsInput>(Input, "ComplexTrackInMaterialsInput");

            if (!trackInMaterialsInput.Materials.IsNullOrEmpty())
            {

                // Collect materials
                IMaterialCollection materials = trackInMaterialsInput.Materials;

                // Collect Resource
                IResource resourceTrackedIn = trackInMaterialsInput.Resource;

                // Collect Facility
                IFacility resourceFacility = resourceTrackedIn.Area.Facility;

                // Materials whose attribute should be removed if existing
                IMaterialCollection materialsToClear = entityFactory.CreateCollection<IMaterialCollection>();

                // This region should always be first, so that every code that needs the material BOMs already resolves the correct BOM version
                // (in case we need to change the BOMs here, at the request of the Operator)
                #region Create Alternative BOM (if the operator made any changes)

                // This HashSet will later be stored in a context parameter. It contains the Ids of all original BOM Versions
                // that had a new version created specifically during this TrackIn. We do this so we can revert that (set the
                // versions stored in this HashSet as effective again) during the ComplexTrackInMaterials.Post
                HashSet<long> originalBOMVersions = new HashSet<long>();

                // A dictionary of alternative subresources, group by Material.name, and then BOMProduct.Id
                // The value is the SubResource Name
                Dictionary<string, Dictionary<long, string>> alternativeSubResourcesByMaterial = null;
                IOperationAttribute operationAttributeAlternativeSubResources = null;

                // Check if there are any alternative sub resources passed in the OperationAttributes
                if (!trackInMaterialsInput.OperationAttributes.IsNullOrEmpty())
                {
                    operationAttributeAlternativeSubResources = trackInMaterialsInput.OperationAttributes.FirstOrDefault(oa => oa.Name == IKEAConstants.OperationAttributeAlternativeSubResources);
                    if (operationAttributeAlternativeSubResources != null && operationAttributeAlternativeSubResources.Value != null)
                    {
                        alternativeSubResourcesByMaterial = JsonConvert.DeserializeObject<Dictionary<string, Dictionary<long, string>>>(
                            JsonConvert.SerializeObject(operationAttributeAlternativeSubResources.Value),
                            SerializationSettings.JsonAllConvertersSettings
                        );
                    }
                }

                // If the alternative sub-resources dictionary is not empty, validate what resources are really different
                if (!alternativeSubResourcesByMaterial.IsNullOrEmpty())
                {
                    foreach (var material in materials)
                    {
                        // Validate if the operator defined any alternative resource for this Manufacturing Order. If not, we can move on
                        if (!alternativeSubResourcesByMaterial.ContainsKey(material.Name))
                        {
                            continue;
                        }

                        if (material.Form.CompareStrings(ikeaUtilities.GetOrderMaterialForm()))
                        {
                            Dictionary<long, string> alternativeSubResources = alternativeSubResourcesByMaterial[material.Name];

                            if (!alternativeSubResources.IsNullOrEmpty())
                            {
                                // Get the latest information about what sub-resources can be used as alternatives to this material
                                var resolvedSubResources = iKEABusinessManagementOrchestration.CustomResolveAlternativeSubResources(new CustomResolveAlternativeSubResourcesInput
                                {
                                    Material = material,
                                    IgnoreLastServiceId = true,
                                });

                                var originalBOMCollection = resolvedSubResources.BOMCollection;

                                foreach (var originalBOM in originalBOMCollection)
                                {

                                    if (originalBOM == null)
                                    {
                                        throw new IKEAException(IKEAConstants.CustomTrackInAlternativeSubResourcesNoBomMessage,
                                            material.Name
                                        );
                                    }

                                    originalBOM.Load();

                                    // Dictionary to hold the BOMProduct Attributes that need to be changed, grouped by the BOMProduct.Id
                                    var bomProductAttributes = new Dictionary<long, IAttributeCollection>();

                                    foreach (KeyValuePair<long, string> alternativePair in alternativeSubResources)
                                    {
                                        long bomProductId = alternativePair.Key;
                                        string alternativeResourceName = alternativePair.Value;

                                        // Find the BOMProduct instance for the given Id
                                        var bomProduct = resolvedSubResources.OriginalResources
                                            .Select(keyValue => keyValue.Key)
                                            .FirstOrDefault(bp => bp.Id == bomProductId);

                                        if (bomProduct == null)
                                        {
                                            throw new IKEAException(IKEAConstants.CustomTrackInAlternativeSubResourcesNoBomProductMessage,
                                                alternativeResourceName,
                                                bomProductId.ToString(),
                                                originalBOM.Name,
                                                material.Name
                                            );
                                        }

                                        var originalResource = resolvedSubResources.OriginalResources[bomProduct];

                                        if (originalResource == null)
                                        {
                                            throw new IKEAException(IKEAConstants.CustomTrackInAlternativeSubResourcesBomProductNoOriginalResourceMessage,
                                                alternativeResourceName,
                                                bomProductId.ToString(),
                                                originalBOM.Name,
                                                material.Name
                                            );
                                        }

                                        if (!resolvedSubResources.AlternativeResources.ContainsKey(originalResource) ||
                                            resolvedSubResources.AlternativeResources[originalResource].IsNullOrEmpty())
                                        {
                                            throw new IKEAException(IKEAConstants.CustomTrackInAlternativeSubResourcesBomProductAlternativesMessage,
                                                alternativeResourceName,
                                                bomProductId.ToString(),
                                                originalBOM.Name,
                                                material.Name,
                                                originalResource.Name,
                                                IKEAConstants.CustomAlternativeSubResourcesGenericTable
                                            );
                                        }

                                        // If the alternative 
                                        if (originalResource?.Name != alternativeResourceName)
                                        {
                                            var alternativeResource = resolvedSubResources.AlternativeResources[originalResource]
                                                ?.FirstOrDefault(subResource => subResource.Name == alternativeResourceName);

                                            if (alternativeResource == null)
                                            {
                                                throw new IKEAException(IKEAConstants.CustomTrackInAlternativeSubResourcesBomProductNoAlternativesMatchMessage,
                                                    alternativeResourceName,
                                                    bomProductId.ToString(),
                                                    originalBOM.Name,
                                                    material.Name,
                                                    originalResource.Name,
                                                    IKEAConstants.CustomAlternativeSubResourcesGenericTable,
                                                    string.Join(", ", resolvedSubResources.AlternativeResources[originalResource])
                                                );
                                            }

                                            alternativeResource.LoadAttributes(new Collection<string>
                                        {
                                            IKEAConstants.ProcessSegmentSequence,
                                            IKEAConstants.SubProcessSegmentName
                                        });

                                            // Save the updated attributes
                                            bomProductAttributes[bomProduct.Id] = new AttributeCollection
                                        {
                                            { IKEAConstants.BomProductProcessSegmentAttribute, alternativeResource.GetAttributeValueOrDefault<string>(IKEAConstants.ProcessSegmentSequence) },
                                            { IKEAConstants.BomProductSubProcessSegmentAttribute, alternativeResource.GetAttributeValueOrDefault<string>(IKEAConstants.SubProcessSegmentName) },
                                        };
                                        }
                                    }

                                    // If any of the BOMProduct's Attributes need updating, we must:
                                    //   - Create a new BOMVersion
                                    //   - Set it as Effective
                                    //   - Update the attributes of the bomProducts
                                    //   - Save the original Effective Version in a ContextParameter, to be able to revert back to it at the very end of the TrackIn
                                    if (bomProductAttributes.Any())
                                    {
                                        // Store the original BOM Instance Id, so that after TrackIn we can restore it as the effective version
                                        originalBOMVersions.Add(originalBOM.Id);

                                        // Here we load all attributes, to make sure that when we create the new version,
                                        // those attributes are also saved on the new version (and not just the ones we might change,
                                        // such as the ProcessSegment and SubProcessSegment)
                                        originalBOM.BomProducts.LoadAttributes();

                                        // For each BOMProduct that has attributes to be changed, save them in the Attributes property in memory
                                        // The CreateNewEntityVersion method will then pick them up and save them in the database
                                        foreach (var bomProduct in originalBOM.BomProducts)
                                        {
                                            if (bomProductAttributes.TryGetValue(bomProduct.Id, out IAttributeCollection attrsToChange))
                                            {
                                                foreach (string attr in attrsToChange.Keys)
                                                {
                                                    bomProduct.Attributes[attr] = attrsToChange[attr];
                                                }
                                            }
                                        }

                                        // Creates the new version (with the updated attributes), approves the change set, and marks the BOM as effective
                                        // IMPORTANT! Do not remove the full namespace, when running as a DEE it is needed here
                                        Cmf.Custom.IKEA.Common.GenericExtensions.CreateNewEntityVersion(originalBOM, requestApproval: true, isEffectiveOnApproval: true);
                                    }
                                }
                            }
                        }
                    }
                }

                // If any custom BOM Versions were created during this TrackIn operation, then save them in a ContextParameter so we can revert them later
                if (originalBOMVersions.Any())
                {
                    deeContextUtilities.SetContextParameter(IKEAConstants.CustomRevertOriginalMaterialBOMVersionsAfterTrackInContextKey, originalBOMVersions);
                }

                // If the attribute is defined, remove it
                if (operationAttributeAlternativeSubResources != null)
                {
                    trackInMaterialsInput.OperationAttributes.Remove(operationAttributeAlternativeSubResources);
                }

                #endregion

                #region Resolve Minimum pallet quantities for Feeders

                // collect distinct products
                var productMoMaterialCollection = materials.Where(MT => MT.Form.CompareStrings(ikeaUtilities.GetOrderMaterialForm())).GroupBy(E => E.GetNativeValue<long>("Product")).ToDictionary(E => E.Key, E => new Collection<IMaterial>(E.ToList()));

                // load all products
                IProductCollection moProducts = entityFactory.CreateCollection<IProductCollection>();
                moProducts.LoadByIDs<IProduct, Product>(productMoMaterialCollection.Select(E => E.Key).ToList());

                int? numberOfPallets = null;

                foreach (IProduct productToResolve in moProducts)
                {
                    numberOfPallets = ikeaUtilities.ResolveCustomMinimumConsumableQuantity(resourceFacility, resourceTrackedIn.Area, resourceTrackedIn, productToResolve, productToResolve.ProductGroup, productToResolve.Type);
                    if (numberOfPallets.HasValue && numberOfPallets.Value > 0)
                    {
                        // Get all materials in collection from each product and save the 'numberOfPallets' attribute value
                        IMaterialCollection productMaterials = entityFactory.CreateCollection<IMaterialCollection>();
                        productMaterials.AddRange(productMoMaterialCollection[productToResolve.DefinitionId]);

                        // set up attributes to save
                        IAttributeCollection attributesToSave = new AttributeCollection();
                        attributesToSave.Add(IKEAConstants.CustomMaterialAttributeNumberOfPallets, numberOfPallets.Value);

                        // save attributes
                        productMaterials.SaveAttributes(attributesToSave);
                    }
                    else
                    {
                        // no default quantity was resolved. old entry if existing should be removed. add to materials where default quantity should be removed
                        materialsToClear.AddRange(productMoMaterialCollection[productToResolve.DefinitionId]);
                    }
                }

                // clear attribute for materials that have not had a successful completed quantity resolve.
                if (materialsToClear.Count > 0)
                {
                    materialsToClear.RemoveAttributes(new Collection<string>() { IKEAConstants.CustomMaterialAttributeNumberOfPallets });
                }

                #endregion

                #region Default Completion Quantity

                decimal? defaultCompletionQuantity = null;
                IOperationAttribute operationAttributeDefaultCompletionQuantity = null;


                // Load the attribute to identify if the materials being TrackedIn are group MOs>
                materials.LoadAttributes(new Collection<string>
                {
                    IKEAConstants.CustomMaterialAttributeIsGroupMO,
                    IKEAConstants.CustomMaterialAttributeGroupOrderHPOEnabled
                });

                // if there is any default completion quantity, set it in all the materials being track in
                if (!trackInMaterialsInput.OperationAttributes.IsNullOrEmpty())
                {
                    operationAttributeDefaultCompletionQuantity = trackInMaterialsInput.OperationAttributes.FirstOrDefault(oa => oa.Name == IKEAConstants.OperationAttributeDefaultCompletionQuantity);
                    if (operationAttributeDefaultCompletionQuantity != null
                        && !string.IsNullOrWhiteSpace(operationAttributeDefaultCompletionQuantity.Value.ToString()))
                    {

                        // If we are Tracking In a Group MO, the default completion quantity represents the number of cycles:
                        defaultCompletionQuantity = decimal.Parse(operationAttributeDefaultCompletionQuantity.Value.ToString());

                        // if there are group MOs being tracked in:
                        if (materials.Where(x => x.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomMaterialAttributeIsGroupMO)).Any())
                        {
                            // Lines with HPO do not validate the default completion quantity:
                            if (!materials.Where(x => x.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomMaterialAttributeGroupOrderHPOEnabled)).Any())
                            {

                                // The value supplied by the default completion quantity (represents the number of cycles) must be greater than zero
                                if (defaultCompletionQuantity <= 0)
                                {
                                    throw new CmfBaseException(ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomGroupMOCompletionNumberOfCyclesGreaterThanZeroLocalizedMessage));
                                }

                                IMaterialCollection materialGroupMOs = entityFactory.CreateCollection<IMaterialCollection>();
                                materialGroupMOs.AddRange(materials.Where(x => x.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomMaterialAttributeIsGroupMO)));

                                foreach (IMaterial materialGroupMO in materialGroupMOs)
                                {

                                    // Get the child MOs materials and parts per cycle from the Group:
                                    var materialChildMOs = ikeaUtilities.GetChildMaterialsAndPartsPerCycleFromGroupMO(materialGroupMO);

                                    foreach (var materialChild in materialChildMOs)
                                    {
                                        // Calculate the default completion quantity (number parts per cycle x number cycles):
                                        decimal moDefaultCompletionQuantity = materialChild.Value * defaultCompletionQuantity.Value;
                                        IMaterial child = materialChild.Key;

                                        // Save default completion quantity to child MO:
                                        child.Load();
                                        child.SaveAttributes(new AttributeCollection()
                                        {
                                            { IKEAConstants.CustomMaterialAttributeDefaultCompletedQuantity, (moDefaultCompletionQuantity)}
                                        });
                                    }
                                }

                            }
                        }

                        materials.SaveAttributes(new AttributeCollection()
                        {
                            { IKEAConstants.CustomMaterialAttributeDefaultCompletedQuantity, defaultCompletionQuantity }
                        });

                    }
                }
                // If no value came from the track in wizard, we try to resolve it from the smart table
                else
                {
                    // if there are group MOs being tracked and no valu from the GUI, throw error:
                    if (materials.Where(x => x.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomMaterialAttributeIsGroupMO)).Any())
                    {
                        throw new CmfBaseException("the number of cycles must be greater than zero");
                    }

                    // select only materials who are top most
                    IMaterialCollection materialsToCheck = entityFactory.CreateCollection<IMaterialCollection>();
                    materialsToCheck.AddRange(materials.Where(E => E.GetNativeValue<long>("ParentMaterial") <= 0));

                    // Materials whose attribute should be removed if existing
                    materialsToClear = entityFactory.CreateCollection<IMaterialCollection>();

                    // only proceed if topmost materials exist
                    if (materialsToCheck.Count > 0)
                    {
                        // collect distinct products
                        var productMaterials = materialsToCheck.GroupBy(E => E.GetNativeValue<long>("Product")).ToDictionary(E => E.Key, E => new Collection<IMaterial>(E.ToList()));

                        // load all products
                        IProductCollection allProducts = entityFactory.CreateCollection<IProductCollection>();
                        allProducts.LoadByIDs<IProduct, Product>(productMaterials.Select(E => E.Key).ToList());

                        // for each product, resolve the default completed quantity
                        foreach (IProduct productToResolve in allProducts)
                        {
                            // prepare resolution for product
                            decimal? defaultQuantity = ikeaUtilities.ResolveCustomDefaultCompletionQuantity(productToResolve, resourceFacility, resourceTrackedIn);

                            // if a default quantity was successfully resolved, save each material within that product with that value.
                            if (defaultQuantity != null)
                            {
                                // Get all materials in collection and save the same attribute value
                                IMaterialCollection allProductMaterials = entityFactory.CreateCollection<IMaterialCollection>();
                                allProductMaterials.AddRange(productMaterials[productToResolve.DefinitionId]);

                                // set up attributes to save
                                IAttributeCollection attributesToSave = new AttributeCollection();
                                attributesToSave.Add(IKEAConstants.CustomMaterialAttributeDefaultCompletedQuantity, defaultQuantity.GetValueOrDefault());

                                // save attributes
                                allProductMaterials.SaveAttributes(attributesToSave);
                            }
                            else
                            {
                                // no default quantity was resolved. old entry if existing should be removed. add to materials where default quantity should be removed
                                materialsToClear.AddRange(productMaterials[productToResolve.DefinitionId]);
                            }
                        }


                        // clear attribute for materials that have not had a successful completed quantity resolve.
                        if (materialsToClear.Count > 0)
                        {
                            materialsToClear.RemoveAttributes(new Collection<string>() { IKEAConstants.CustomMaterialAttributeDefaultCompletedQuantity });
                        }
                    }
                }


                // If the attribute is defined, remove it
                if (operationAttributeDefaultCompletionQuantity != null)
                {
                    trackInMaterialsInput.OperationAttributes.Remove(operationAttributeDefaultCompletionQuantity);
                }
                #endregion

                #region Main Feeder Name

                // Grab the attribute "MainFeederName"
                IOperationAttribute operationAttributeMainFeederName = trackInMaterialsInput.OperationAttributes?.FirstOrDefault(oa => oa.Name == IKEAConstants.OperationAttributeMainFeederName);

                // Only handle the OperationAttribute if this MainLine is configured in the Generic Table
                CustomDefaultMainFeederConfiguration configuration = ikeaUtilities.GetDefaultMainFeederConfigurationForMainLine(resourceTrackedIn);
                if (configuration != null)
                {
                    if (operationAttributeMainFeederName != null
                        && !string.IsNullOrWhiteSpace(operationAttributeMainFeederName.Value?.ToString()))
                    {
                        string newMainFeederName = operationAttributeMainFeederName.Value.ToString();

                        // If Operator Selection is not enabled, the main feeder must be either the configured Default or Alternative
                        if (!configuration.EnableOperatorSelection && configuration.DefaultFeeder.Name != newMainFeederName && configuration.AlternativeFeeder?.Name != newMainFeederName)
                        {
                            throw new IKEAException(IKEAConstants.CustomResourceMainFeederInvalidInputLocalizedMessage,
                                resourceTrackedIn.Name,
                                IKEAConstants.CustomDefaultMainFeederConfigurationGenericTable,
                                newMainFeederName,
                                configuration.AlternativeFeeder != null
                                    ? (configuration.DefaultFeeder.Name + ", " + configuration.AlternativeFeeder.Name)
                                    : configuration.DefaultFeeder.Name
                            );
                        }

                        string currentMainFeederName = resourceTrackedIn.GetAttributeValueOrDefault<string>(IKEAConstants.MESAutomationInFeederSubResourceController, loadAttribute: true);

                        // If the resource already has InProcess MOs, this main feeder must be the same as the current one
                        // Because no concurrent InProcess MOs with different main feeders are allowed on the same main line
                        if (resourceTrackedIn.MaterialsInProcessCount > 0)
                        {
                            if (currentMainFeederName != newMainFeederName)
                            {
                                throw new IKEAException(IKEAConstants.CustomResourceMainFeederCurrentInProcessMismatchLocalizedMessage,
                                    resourceTrackedIn.Name,
                                    newMainFeederName,
                                    currentMainFeederName
                                );
                            }
                        }

                        if (newMainFeederName != currentMainFeederName)
                        {
                            // Validate if the new sub-resource
                            if (!resourceTrackedIn.HasConsumableFeed(newMainFeederName, online: true, loadRelations: true))
                            {
                                throw new IKEAException(IKEAConstants.CustomResourceMainFeederSubResourceNotFoundLocalizedMessage,
                                    newMainFeederName,
                                    resourceTrackedIn.Name
                                );
                            }

                            // Update the attribute with the new Main Feeder Name
                            resourceTrackedIn.SaveAttributes(new AttributeCollection
                            {
                                { IKEAConstants.MESAutomationInFeederSubResourceController, newMainFeederName }
                            });
                        }
                    }
                    else
                    {
                        // Error about missing OperationAttribute
                        throw new IKEAException(IKEAConstants.CustomResourceMainFeederMissingInputLocalizedMessage,
                            IKEAConstants.OperationAttributeMainFeederName,
                            resourceTrackedIn.Name,
                            IKEAConstants.CustomDefaultMainFeederConfigurationGenericTable
                        );
                    }
                }

                // If the attribute is defined, remove it
                if (operationAttributeMainFeederName != null)
                {
                    trackInMaterialsInput.OperationAttributes.Remove(operationAttributeMainFeederName);
                }

                #endregion

                #region Update Dimensions

                IOperationAttribute operationAttributeUpdateDimensions = null;
                IOperationAttribute operationAttributeLength = null;
                IOperationAttribute operationAttributeWidth = null;
                IOperationAttribute operationAttributeThickness = null;
                IOperationAttribute operationAttributeWeight = null;

                // If the flag UpdateDimensionsAttributes is true, set it in all the materials being track in
                if (!trackInMaterialsInput.OperationAttributes.IsNullOrEmpty())
                {
                    operationAttributeUpdateDimensions = trackInMaterialsInput.OperationAttributes.FirstOrDefault(oa => oa.Name == IKEAConstants.OperationAttributeUpdateDimensionAttributes);
                    operationAttributeLength = trackInMaterialsInput.OperationAttributes.FirstOrDefault(oa => oa.Name == IKEAConstants.OperationAttributeLength);
                    operationAttributeWidth = trackInMaterialsInput.OperationAttributes.FirstOrDefault(oa => oa.Name == IKEAConstants.OperationAttributeWidth);
                    operationAttributeThickness = trackInMaterialsInput.OperationAttributes.FirstOrDefault(oa => oa.Name == IKEAConstants.OperationAttributeThickness);
                    operationAttributeWeight = trackInMaterialsInput.OperationAttributes.FirstOrDefault(oa => oa.Name == IKEAConstants.OperationAttributeWeight);

                    if (operationAttributeUpdateDimensions != null
                        && !string.IsNullOrWhiteSpace(operationAttributeUpdateDimensions.Value.ToString())
                        && operationAttributeUpdateDimensions.Value as bool? == true)
                    {
                        // Grab the value from the dimension operation attributes (null values are converted to 0)
                        decimal length = Convert.ToDecimal(operationAttributeLength?.Value);
                        decimal width = Convert.ToDecimal(operationAttributeWidth?.Value);
                        decimal thickness = Convert.ToDecimal(operationAttributeThickness?.Value);
                        decimal weight = Convert.ToDecimal(operationAttributeWeight?.Value);

                        // Load any dimensions that might already exist in the materials
                        trackInMaterialsInput.Materials.LoadAttributes(new Collection<string>
                        {
                            IKEAConstants.CustomMaterialLengthAttribute,
                            IKEAConstants.CustomMaterialWidthAttribute,
                            IKEAConstants.CustomMaterialThicknessAttribute,
                            IKEAConstants.CustomMaterialWeightAttribute
                        });

                        foreach (var material in trackInMaterialsInput.Materials)
                        {
                            material.SetDimensionAttributes(length, width, thickness, weight, loadAttributes: false);
                        }
                    }

                    // If the attribute is defined, remove it
                    if (operationAttributeUpdateDimensions != null)
                    {
                        trackInMaterialsInput.OperationAttributes.Remove(operationAttributeUpdateDimensions);
                    }

                    if (operationAttributeLength != null)
                    {
                        trackInMaterialsInput.OperationAttributes.Remove(operationAttributeLength);
                    }

                    if (operationAttributeWidth != null)
                    {
                        trackInMaterialsInput.OperationAttributes.Remove(operationAttributeWidth);
                    }

                    if (operationAttributeThickness != null)
                    {
                        trackInMaterialsInput.OperationAttributes.Remove(operationAttributeThickness);
                    }

                    if (operationAttributeWeight != null)
                    {
                        trackInMaterialsInput.OperationAttributes.Remove(operationAttributeWeight);
                    }
                }

                #endregion

                #region Recipe
                IOperationAttribute operationAttributeSelectedRecipe = null;
                if (trackInMaterialsInput.OperationAttributes != null)
                {
                    operationAttributeSelectedRecipe = trackInMaterialsInput.OperationAttributes.FirstOrDefault(oa => oa.Name == IKEAConstants.OperationAttributeSelectedRecipe);
                }

                // Check if the recipe is defined
                if (operationAttributeSelectedRecipe != null
                    && !string.IsNullOrWhiteSpace(operationAttributeSelectedRecipe.Value.ToString()))
                {
                    string selectedRecipe = operationAttributeSelectedRecipe.Value.ToString();

                    // Get all the required services from the materials
                    Collection<long> materialServicesIds = new Collection<long>(materials.Select(m => m.GetNativeValue<long>("RequiredService")).Where(v => v > 0).Distinct().ToList());

                    if (!materialServicesIds.IsNullOrEmpty())
                    {
                        // NOTE: Do not remove Navigo.BusinessObjects. because the DEE will fail to be updated because it will 
                        // have a conflict between this namespace and another
                        Cmf.Navigo.BusinessObjects.Abstractions.IServiceCollection services = entityFactory.CreateCollection<Cmf.Navigo.BusinessObjects.Abstractions.IServiceCollection>();
                        services.LoadByIDs<Cmf.Navigo.BusinessObjects.Abstractions.IService, Cmf.Navigo.BusinessObjects.Service>(materialServicesIds);

                        Dictionary<long, string> materialServices = services.ToDictionary(s => s.Id, s => s.Name);

                        DataTable dataTable = new DataTable(Navigo.Common.Constants.RecipeContext);

                        System.Type stringType = typeof(string);
                        System.Type longType = typeof(long);

                        // Create the structure for the smart table RecipeContext
                        dataTable.Columns.AddRange(new DataColumn[]
                        {
                            new DataColumn() { ColumnName = string.Format("{0}Id", Navigo.Common.Constants.RecipeContext), DataType = longType },
                            new DataColumn() { ColumnName = Constants.LastServiceHistoryId, DataType = longType },
                            new DataColumn() { ColumnName = Constants.LastOperationHistorySeq, DataType = longType },
                            new DataColumn() { ColumnName = Navigo.Common.Constants.Service, DataType = stringType },
                            new DataColumn() { ColumnName = Navigo.Common.Constants.Product, DataType = stringType },
                            new DataColumn() { ColumnName = Navigo.Common.Constants.ProductGroup, DataType = stringType },
                            new DataColumn() { ColumnName = Navigo.Common.Constants.Flow, DataType = stringType },
                            new DataColumn() { ColumnName = Navigo.Common.Constants.Material, DataType = stringType },
                            new DataColumn() { ColumnName = Navigo.Common.Constants.MaterialType, DataType = stringType },
                            new DataColumn() { ColumnName = Navigo.Common.Constants.Resource, DataType = stringType },
                            new DataColumn() { ColumnName = Navigo.Common.Constants.ResourceType, DataType = stringType },
                            new DataColumn() { ColumnName = Navigo.Common.Constants.Model, DataType = stringType },
                            new DataColumn() { ColumnName = "RunningMode", DataType = stringType },
                            new DataColumn() { ColumnName = Navigo.Common.Constants.Recipe, DataType = stringType },
                        });

                        foreach (IMaterial material in materials)
                        {
                            string materialService = materialServices[material.GetNativeValue<long>("RequiredService")];
                            string materialName = material.Name;

                            // Try to resolve the recipe by Service and Material Name
                            DataSet recipeDataContext = ikeaUtilities.ResolveRecipeContextDataSet(serviceName: materialService,
                                                                                                    materialName: materialName);

                            // If a context is found for the give material and the recipe is different from the selected
                            // update the context
                            if (recipeDataContext.HasData()
                                && recipeDataContext.Tables[0].Rows[0].Field<string>(Navigo.Common.Constants.Material).CompareStrings(materialName))
                            {
                                if (!recipeDataContext.Tables[0].Rows[0].Field<string>(Navigo.Common.Constants.Recipe).CompareStrings(selectedRecipe))
                                {
                                    dataTable = recipeDataContext.Tables[0].Copy();

                                    DataRow newRow = dataTable.Rows[0];

                                    newRow[Navigo.Common.Constants.Service] = materialService;
                                    newRow[Navigo.Common.Constants.Material] = materialName;
                                    newRow[Navigo.Common.Constants.Recipe] = selectedRecipe;
                                }
                            }
                            // If there are no matches for the material then create a new one
                            else
                            {
                                DataRow newRow = dataTable.NewRow();

                                newRow[Navigo.Common.Constants.Service] = materialService;
                                newRow[Navigo.Common.Constants.Material] = materialName;
                                newRow[Navigo.Common.Constants.Recipe] = selectedRecipe;
                                dataTable.Rows.Add(newRow);
                            }
                        }

                        // If there are any new contexts, save them in the Smart Table
                        if (dataTable.HasData())
                        {
                            ISmartTable smartTable = new SmartTable();
                            smartTable.Load(Navigo.Common.Constants.RecipeContext);

                            DataSet baseSet = new DataSet();
                            baseSet.Tables.Add(dataTable);
                            smartTable.InsertOrUpdateRows(NgpDataSet.FromDataSet(baseSet));
                        }
                    }
                }

                // If the attribute is defined, remove it
                if (operationAttributeSelectedRecipe != null)
                {
                    trackInMaterialsInput.OperationAttributes.Remove(operationAttributeSelectedRecipe);
                }
                #endregion

                #region Alternative ResourceIdealCycleTimes

                DataTable rowsToUpdate = null;
                Dictionary<long, ResourceAlternativeCycleTime> rowsToUpdateById = new Dictionary<long, ResourceAlternativeCycleTime>();

                foreach (IMaterial material in materials)
                {
                    // Gather information about possible alternative cycle times 
                    var cycleTimesOutput = iKEABusinessManagementOrchestration.CustomResolveAlternativeCyclesTimes(new CustomResolveAlternativeCyclesTimesInput
                    {
                        Material = material,
                        Resource = resourceTrackedIn
                    });

                    // Ignore this material if it does not require anything with the alternative cycle times
                    if (!cycleTimesOutput.RequiresAlternativeCycleTime)
                    {
                        continue;
                    }

                    if (cycleTimesOutput.AlternativeCycleTime == null)
                    {
                        throw new IKEAException(IKEAConstants.CustomRequiredAlternativeIdealCycleTimeNoMatchForStructureTypeLocalizedMessage,
                            material.Name,
                            resourceTrackedIn.Name);
                    }

                    // If this track in requires an alternative cycle time that is the same already set on the ResourceIdealCycleTime's table, we can skip this material
                    if (cycleTimesOutput.OriginalCycleTime.TimePerUnitValue == cycleTimesOutput.AlternativeCycleTime?.TimePerUnitValue
                     && cycleTimesOutput.OriginalCycleTime.TimeScaleValue == cycleTimesOutput.AlternativeCycleTime?.TimeScaleValue)
                    {
                        // Record that this row is already "locked" for this cycle time during this Track-In
                        rowsToUpdateById.Add(cycleTimesOutput.OriginalCycleTime.Id, cycleTimesOutput.AlternativeCycleTime);

                        continue;
                    }

                    if (cycleTimesOutput.CycleTimeInUse == true)
                    {
                        throw new IKEAException(IKEAConstants.CustomRequiredAlternativeIdealCycleTimeConflictsWithInProcessOrdersLocalizedMessage,
                            material.Name,
                            resourceTrackedIn.Name,
                            string.Join(", ", cycleTimesOutput.CycleTimeMaterialsInProcess));
                    }

                    var newCycleTime = cycleTimesOutput.AlternativeCycleTime;

                    // Get the row from the original Smart Table, so we can update it by changing only the TiemScale and TimePerUnit columns
                    var dataIdealResourceTime = ikeaUtilities.GetDataSetIdealResourceCycleTime(material, resourceTrackedIn, out INgpDataRow filters);

                    if (dataIdealResourceTime.HasData())
                    {
                        DataTable dataSetCycleTime = dataIdealResourceTime.Tables[0];

                        long rowId = dataSetCycleTime.Rows[0].Field<long>(IKEAConstants.ResourceIdealCycleTimeIdColumn);

                        // If we are already updating this row, we must decide if we skip or throw an error
                        if (rowsToUpdateById.ContainsKey(rowId))
                        {
                            var currentCycleTime = rowsToUpdateById[rowId];

                            // If the alternative time cycle is the same as some material already set in this loop, no need to update
                            // twice for the same values, so we can skip
                            if (currentCycleTime.TimePerUnitValue == newCycleTime.TimePerUnitValue
                             && currentCycleTime.TimeScaleValue == newCycleTime.TimeScaleValue)
                            {
                                continue;
                            }
                            else
                            {
                                // On the other hand, if the values are different, we cannot track in two materials at the same time
                                // that need different alternative cycle times
                                throw new IKEAException(IKEAConstants.CustomRequiredAlternativeIdealCycleTimeConflictsWithTrackInOrderLocalizedMessage,
                                    material.Name,
                                    resourceTrackedIn.Name);
                            }
                        }
                        else
                        {
                            rowsToUpdateById.Add(rowId, newCycleTime);

                            // On the first row, create the DataTable
                            if (rowsToUpdate == null)
                            {
                                rowsToUpdate = dataSetCycleTime.Clone();
                            }

                            // Set information of rows to be inserted                            
                            var dataRow = rowsToUpdate.NewRow();
                            dataRow.CopyFrom(dataSetCycleTime.Rows[0]);

                            dataRow.SetField("TimeScale", newCycleTime.TimeScaleValue);
                            dataRow.SetField("TimePerUnit", newCycleTime.TimePerUnitValue);

                            rowsToUpdate.Rows.Add(dataRow);
                        }
                    }
                    else
                    {
                        throw new IKEAException(IKEAConstants.CustomCannotSetAlternativeCycleTimeNoRowsFoundLocalizedMessage,
                            material.Name,
                            resourceTrackedIn.Name,
                            IKEAConstants.ResourceIdealCycleTimeSmartTable
                        );
                    }
                }

                if (rowsToUpdate != null && rowsToUpdate.Rows.Count > 0)
                {
                    // Get Smart table 
                    ISmartTable smartTable = new SmartTable();
                    smartTable.Load(IKEAConstants.ResourceIdealCycleTimeSmartTable);

                    // Get skipValidation value
                    bool? skipValidation = deeContextUtilities.GetContextParameter(IKEAConstants.CustomPreventUpdateResourceIdealCycleTimeDirectlyContextKey) as bool?;

                    // Set skipValidation to true if not.
                    if (skipValidation == null || skipValidation == false)
                    {
                        deeContextUtilities.SetContextParameter(IKEAConstants.CustomPreventUpdateResourceIdealCycleTimeDirectlyContextKey, true);
                    }

                    // Update Rows
                    smartTable.InsertOrUpdateRows(NgpDataSet.FromDataSet(rowsToUpdate.ToDataSet()));

                    // Reset skipValidation value
                    deeContextUtilities.SetContextParameter(IKEAConstants.CustomPreventUpdateResourceIdealCycleTimeDirectlyContextKey, skipValidation);
                }

                #endregion

            }

            
            //---End DEE Code---
            return Input;
        }

    }
}
