﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace Cmf.Custom.IKEA.Actions.Materials
{
    class CustomUpdateMaterialIteration : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   
UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
            #region Info
            /// <summary>
            /// Summary text
            ///     Checks if a material being changed to DirectRepair, if it has Iterations, the iteration counter must be decremented
            /// Action Groups:
            ///     MaterialManagement.MaterialManagementOrchestration.ChangeMaterialType.Post
            ///     MaterialManagement.MaterialManagementOrchestration.ChangeMaterialsType.Post
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "MaterialManagement.MaterialManagementOrchestration.ChangeMaterialType.Post",
                "MaterialManagement.MaterialManagementOrchestration.ChangeMaterialsType.Post"
            };
            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];

            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();

            // Get the context for the CustomERPChangeTypeReport indicating if the change type is being done by the unit completion
            bool? unitCompletion = deeContextUtilities.GetContextParameter(IKEAConstants.ERPChangeTypeReportUnitCompletion) as bool?;

            // Check if the functionality is enabled and if is being executed by the right action group
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups) && unitCompletion != true;

            if (executionVeridict && IKEADEEActionUtilities.GetInputItem<ChangeMaterialTypeOutput>(Input, "ChangeMaterialTypeOutput") == null
                                  && IKEADEEActionUtilities.GetInputItem<ChangeMaterialsTypeOutput>(Input, "ChangeMaterialsTypeOutput") == null)
            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            //System
            UseReference("", "System");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects");

            // Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();

            IMaterialCollection materials = entityFactory.CreateCollection<IMaterialCollection>();

            ChangeMaterialTypeOutput changeMaterialTypeOutput = IKEADEEActionUtilities.GetInputItem<ChangeMaterialTypeOutput>(Input, "ChangeMaterialTypeOutput");
            ChangeMaterialsTypeOutput changeMaterialsTypeOutput = IKEADEEActionUtilities.GetInputItem<ChangeMaterialsTypeOutput>(Input, "ChangeMaterialsTypeOutput");

            if (changeMaterialTypeOutput != null)
            {
                materials.Add(changeMaterialTypeOutput.Material);
            }
            else if (changeMaterialsTypeOutput != null)
            {
                materials.AddRange(changeMaterialsTypeOutput.Materials);
            }


            if (materials.Count > 0)
            {
                // Get DirectRepair type name:
                string directRepairMaterialType = genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.CustomDirectRepairMaterialDefaultTypePath);

                materials.LoadAttributes(new Collection<string>() { IKEAConstants.CustomMaterialAttributeCurrentIteration,
                                                                    IKEAConstants.CustomMaterialAttributeMaxIterations });

                foreach (IMaterial material in materials)
                {
                    if (material.Type.CompareStrings(directRepairMaterialType))
                    {

                        // Get max iteration from source material and the current iteration from the completed unit
                        int maxIterations = material.GetAttributeValueOrDefault<int>(IKEAConstants.CustomMaterialAttributeMaxIterations, false);

                        // Get max iteration from source material and the current iteration from the completed unit
                        int currentIteration = material.GetAttributeValueOrDefault<int>(IKEAConstants.CustomMaterialAttributeCurrentIteration, false);

                        // If there are iterations to decrement, do it:
                        if (currentIteration > 0)
                        {
                            currentIteration--;
                            material.SaveAttributes(new AttributeCollection
                            {
                                {IKEAConstants.CustomMaterialAttributeCurrentIteration, currentIteration }
                            });
                        }
                    }

                }
            }

            //---End DEE Code---

            return Input;
        }
    }
}
