﻿using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.Materials
{
    public class CustomLoadMaterialsForDispatchLoadPOs : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.MaterialCollection.LoadMaterialsForDispatch.Post",
            };

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            if (executionVeridict)
            {
                if (IKEADEEActionUtilities.GetInputItem<IMaterialCollection>(Input, "MaterialCollection") == null)
                {
                    executionVeridict = false;
                }
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            // System
            UseReference("", "Cmf.Foundation.Common.Exceptions");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IMaterialCollection material = Input["MaterialCollection"] as IMaterialCollection;

            if (material == null)
            {
                throw new ArgumentNullException("MaterialCollection");
            }

            IProductionOrderCollection listPo = serviceProvider.GetService<IProductionOrderCollection>();
            IEnumerable<IProductionOrder> productionOrders = material
                .Where(m => m.ProductionOrder != null)
                .Select(m => m.ProductionOrder)
                .Distinct();
            listPo.AddRange(productionOrders);
            listPo.Load();
            listPo.LoadRelations("CustomPOOperationResource", 1);

            listPo.LoadAttributes();

            Dictionary<long, IProductionOrder> poDictionary = listPo.GroupBy(po => po.Id).ToDictionary(group => group.Key, group => group.FirstOrDefault());

            foreach (IMaterial mat in material)
            {
                if (mat.ProductionOrder != null && poDictionary.TryGetValue(mat.ProductionOrder.Id, out var updatedPo))
                {
                    mat.ProductionOrder = updatedPo;
                }
            }

            serviceProvider.GetService<IDeeContextUtilities>().SetContextParameter(IKEAConstants.CustomLoadMaterialsForDispatchContext, material);

            Input["MaterialCollection"] = material;

            //---End DEE Code---

            return Input;
        }

    }
}
