﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.ERP;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.Materials
{
    class CustomMaterialMergeCommunication : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {


        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Communicates the Merged materials to ERP
            /// Action Groups:
            ///     BusinessObjects.Material.Merge.Pre
            ///     BusinessObjects.Material.Merge.Post
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.Material.Merge.Pre",
                "BusinessObjects.Material.Merge.Post"
            };

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            if (executionVeridict && IKEADEEActionUtilities.GetInputItem<IMaterial>(Input, "Material") == null
                                  && IKEADEEActionUtilities.GetInputItem<Dictionary<IMaterial, IMergeMaterialParameters>>(Input, "ChildMaterials") == null)
            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            //System
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("", "System.Linq");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.ERP");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();

            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            IERPUtilities erpUtilities = serviceProvider.GetService<IERPUtilities>();

            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();
            DeeContext currentContext = deeContextUtilities.SetCurrentServiceContext("CustomMaterialMergeCommunication");

            if (currentContext.TriggerPoint == DeeTriggerPoint.Pre)
            {
                IMaterial parentMaterial = IKEADEEActionUtilities.GetInputItem<IMaterial>(Input, "Material");
                Dictionary<IMaterial, IMergeMaterialParameters> childMaterials = IKEADEEActionUtilities.GetInputItem<Dictionary<IMaterial, IMergeMaterialParameters>>(Input, "ChildMaterials");

                // Only completed materials should be reported:
                if (!childMaterials.IsNullOrEmpty())
                {
                    // Get configurations
                    string partnerConfig = genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.SupplierCodeConfig);
                    string messageTypeConfig = genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.MessageTypeCodeConfig);
                    string responsibleConfig = genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.ErpResponsibleConfig);
                    string processFlag = genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.MaterialMergeCommunicationProcessFlag) ?? "*EXE";

                    parentMaterial.LoadAttributes(new Collection<string>() { IKEAConstants.CustomMaterialAttributeERPOriginalName });

                    // Collect all the materials to load the attributes
                    IMaterialCollection materials = entityFactory.CreateCollection<IMaterialCollection>();
                    materials.Add(parentMaterial);
                    materials.AddRange(childMaterials.Keys);

                    // Load all the necessary attributes
                    materials.LoadAttributes(new Collection<string>() { IKEAConstants.CustomMaterialAttributeERPInventoryLocation });

                    // Group all the products
                    var groupedProducts = materials.Select(m => m.Product).GroupBy(p => p.Id);
                    IProductCollection products = entityFactory.CreateCollection<IProductCollection>();
                    products.AddRange(groupedProducts.Select(p => p.ToList()[0]));

                    // Load all the necessary attributes
                    products.LoadAttributes(new Collection<string>() { IKEAConstants.CustomProductAttributeBaseProduct });

                    // Group all the facilities
                    var groupedFacility = materials.Select(m => m.Facility).GroupBy(f => f.Id);
                    IFacilityCollection facilities = entityFactory.CreateCollection<IFacilityCollection>();
                    facilities.AddRange(groupedFacility.Select(f => f.ToList()[0]));

                    // Load all the necessary attributes
                    facilities.LoadAttributes(new Collection<string>() { IKEAConstants.CustomFaciltyAttributeERPWarehouseLocation });

                    // Get all the reportable forms
                    List<string> reportableForms = erpUtilities.GetERPReportableForms();

                    // Communicate all the materials to be merged to ERP
                    if (reportableForms.Contains(parentMaterial.Form))
                    {
                        // Get Material ERP Original Name
                        string erpOriginalName = parentMaterial.GetAttributeValueOrDefault<string>(IKEAConstants.CustomMaterialAttributeERPOriginalName);
                        string parentMaterialName = string.IsNullOrWhiteSpace(erpOriginalName) ? parentMaterial.Name : erpOriginalName;

                        // Get all necessary attributes
                        string warehouse = parentMaterial.Facility.GetAttributeValueOrDefault<string>(IKEAConstants.CustomFaciltyAttributeERPWarehouseLocation);
                        string location = parentMaterial.GetAttributeValueOrDefault<string>(IKEAConstants.CustomMaterialAttributeERPInventoryLocation);
                        string productName = parentMaterial.Product.GetRelatedAttributeValueOrDefault<string>(IKEAConstants.CustomProductAttributeBaseProduct) ?? parentMaterial.Product.Name;

                        List<MaterialSplitMergeCommunication> materialMergeCommunications = new List<MaterialSplitMergeCommunication>();

                        foreach (IMaterial childMaterial in childMaterials.Keys.Where(cm => reportableForms.Contains(cm.Form)))
                        {
                            string childLocation = childMaterial.GetAttributeValueOrDefault<string>(IKEAConstants.CustomMaterialAttributeERPInventoryLocation);

                            // If primary quantity is 0 then report the secondary quantity
                            decimal childTotalQuantity = childMaterial.PrimaryQuantity ?? 0;
                            if (childTotalQuantity == 0)
                            {
                                childTotalQuantity += childMaterial.SecondaryQuantity ?? 0;
                            }

                            // Instantiate communication class
                            MaterialSplitMergeCommunication materialMergeCommunication = new MaterialSplitMergeCommunication()
                            {
                                Partner = partnerConfig,
                                MessageType = messageTypeConfig,
                                Warehouse = warehouse ?? string.Empty,
                                Location = location ?? string.Empty,
                                ItemNumber = productName ?? string.Empty,
                                Container = childMaterial.Name, // The merged material is the container. Its quantity will be moved to the parent in 'ToContainer'.
                                Quantity = childTotalQuantity.ToString(),
                                ToLocation = childLocation ?? string.Empty,
                                ToContainer = parentMaterialName,
                                Responsible = responsibleConfig,
                                ProcessFlag = processFlag
                            };

                            materialMergeCommunications.Add(materialMergeCommunication);
                        }

                        deeContextUtilities.SetContextParameter("CustomMaterialMergeCommunication_MaterialMergeCommunications", materialMergeCommunications);
                    }
                }
            }
            else if (currentContext.TriggerPoint == DeeTriggerPoint.Post)
            {
                int integrationRetries = genericUtilities.GetConfigurationValueByPath<int>(IKEAConstants.MaterialMergeCommunicationIntegrationEntryRetries);
                var materialMergeCommunications = deeContextUtilities.GetContextParameter("CustomMaterialMergeCommunication_MaterialMergeCommunications") as List<MaterialSplitMergeCommunication>;
                if (materialMergeCommunications != null)
                {
                    foreach (var materialMergeCommunication in materialMergeCommunications)
                    {
                        // Create the Integration Entry
                        ikeaUtilities.CreateJsonIntegrationEntry(materialMergeCommunication,
                                                                IKEAConstants.ERPReportMaterialMerge,
                                                                IKEAConstants.ERPReportMaterialMergeMessageType,
                                                                IKEAConstants.ERPReportMaterialMergeEventName,
                                                                isRetriable: (integrationRetries > 0),
                                                                numberOfRetries: integrationRetries);
                    }
                }
            }

            //---End DEE Code---

            return Input;
        }



    }
}
