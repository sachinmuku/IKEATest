﻿using Cmf.Custom.IKEA.BusinessObjects;
using Cmf.Custom.IKEA.BusinessObjects.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Extensions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Foundation.Common.Base;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.Abstractions;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects;
using Cmf.Navigo.BusinessOrchestration.ResourceManagement.OutputObjects;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;

namespace Cmf.Custom.IKEA.Actions.Materials
{
    public class CustomGetGroupBomData : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Replace the BOM information in the TrackIn wizard of Group MO materials

            /// Action Groups:
            ///     MaterialManagement.MaterialManagementOrchestration.GetDataForMultipleTrackInWizard.Post
            ///     MaterialManagement.MaterialManagementOrchestration.GetDataForTrackInWizard.Post
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "MaterialManagement.MaterialManagementOrchestration.GetDataForMultipleTrackInWizard.Post",
                "MaterialManagement.MaterialManagementOrchestration.GetDataForTrackInWizard.Post"
            };

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            if (executionVeridict)
            {
                if (IKEADEEActionUtilities.GetInputItem<GetDataForMultipleTrackInWizardInput>(Input, "GetDataForMultipleTrackInWizardInput") == null
                 && IKEADEEActionUtilities.GetInputItem<GetDataForTrackInWizardInput>(Input, "GetDataForTrackInWizardInput") == null)
                {
                    executionVeridict = false;
                }
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
     

            //System
            UseReference("", "Cmf.Navigo.BusinessOrchestration.Abstractions");
            UseReference("", "Cmf.Custom.IKEA.BusinessObjects.Abstractions");
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System");
            UseReference("", "System.Collections.ObjectModel");

            //Foundation
            UseReference("Cmf.Foundation.Common.dll", "Cmf.Foundation.Common.Base");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.ResourceManagement.OutputObjects");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Extensions");

            UseReference("Cmf.Custom.IKEA.BusinessObjects.CustomGroupMaterialManufacturingOrder.dll", "Cmf.Custom.IKEA.BusinessObjects");
            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            //IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            var materialOrchestration = serviceProvider.GetService<IMaterialOrchestration>();

            // Virtual Bom that will be created and will replace the output Bom
            IBOM parentGroupBom = null;
            BOMSetupInformation setupInfo = new BOMSetupInformation
            {
                BOM = null,
                BOMProductToConsumableFeed = new Dictionary<long, long>(),
                ConsumableFeedResources = entityFactory.CreateCollection<IResourceCollection>(),
                ConsumableFeedPossibleMaterials = new Dictionary<long, INgpDataSet>(),
            };

            #region Retrieve Input Values
            //MaterialCollection materials = new MaterialCollection();
            IMaterial parentMaterial = null;

            int bomLevelsToLoad = 1;
            int bomProductLevelsToLoad = 0;

            GetDataForMultipleTrackInWizardOutput multipleWizardOutput = null;
            GetDataForTrackInWizardOutput singleWizardOutput = null;

            if (Input.TryGetValue("GetDataForMultipleTrackInWizardInput", out object inputMultipleObj) && inputMultipleObj is GetDataForMultipleTrackInWizardInput inputMultiple)
            {
                parentMaterial = inputMultiple.Materials.FirstOrDefault();
                bomLevelsToLoad = inputMultiple.BomLevelsToLoad;
                bomProductLevelsToLoad = inputMultiple.BOMProductLevelsToLoad;

                // Retrieve the matching multiple output object
                multipleWizardOutput = Input["GetDataForMultipleTrackInWizardOutput"] as GetDataForMultipleTrackInWizardOutput;
            }
            else if (Input.TryGetValue("GetDataForTrackInWizardInput", out object inputSingleObj) && inputSingleObj is GetDataForTrackInWizardInput inputSingle)
            {
                parentMaterial = inputSingle.Material;
                bomLevelsToLoad = inputSingle.BomLevelsToLoad;
                bomProductLevelsToLoad = inputSingle.BOMProductLevelsToLoad;

                // Retrieve the matching single output object
                singleWizardOutput = Input["GetDataForTrackInWizardOutput"] as GetDataForTrackInWizardOutput;
            }
            #endregion

            if (parentMaterial != null)
            {
                parentMaterial.LoadRelations(IKEAConstants.CustomGroupMaterialManufacturingOrder);

                if (parentMaterial.IsGroupMO(loadRelations: false))
                {
                    var groupBomProducts = new Dictionary<long, IBOMProduct>();

                    #region Group Child Bom Quantities by Product
                    var children = parentMaterial.RelationCollection[IKEAConstants.CustomGroupMaterialManufacturingOrder]
                        .Cast<ICustomGroupMaterialManufacturingOrder>();

                    foreach (ICustomGroupMaterialManufacturingOrder relation in children)
                    {
                        IMaterial childMaterial = relation.TargetEntity;

                        IResolveBomContextsResult bomContext = childMaterial.Product.ResolveBomContexts(childMaterial);
                        var childMaterialCollection = entityFactory.CreateCollection<IMaterialCollection>();
                        childMaterialCollection.Add(childMaterial);
                        BOMSetupInformation childSetupInfo = materialOrchestration.GetDataForMultipleTrackInWizard(new GetDataForMultipleTrackInWizardInput
                        {
                            Materials = childMaterialCollection,
                        }).BOMSetupInformation;

                        setupInfo.BOMAssemblyType = bomContext.BomAssemblyType;

                        var missingConsumableResources = childSetupInfo.ConsumableFeedResources.Where(resource => setupInfo.ConsumableFeedResources.Any(consumable => consumable.Name == resource.Name) == false);
                        setupInfo.ConsumableFeedResources.AddRange(missingConsumableResources);

                        // load the BOMAssemblyType                    
                        //output.BOMAssemblyType = bomContext.BomAssemblyType;

                        if (bomContext != null &&
                            bomContext.Bom != null &&
                            bomContext.Bom.UniversalState == UniversalState.Effective)
                        {
                            // load the Bom effective version
                            var bom = entityFactory.Create<IBOM>();
                            bom.Load(bomContext.Bom.Id, bomLevelsToLoad);

                            // load BOMProduct relations
                            bom.LoadBOMProductsForStep(bomProductLevelsToLoad + 1, childMaterial.Step);

                            // Initial values
                            if (parentGroupBom == null)
                            {
                                parentGroupBom = entityFactory.Create<IBOM>();
                                parentGroupBom.Name = "Group Manufacturing Order BOM";
                            }

                            foreach (IBOMProduct bomProduct in bom.BomProducts)
                            {
                                long bomId = bomProduct.Id;

                                if (!groupBomProducts.ContainsKey(bomId))
                                {
                                    groupBomProducts[bomId] = bomProduct;
                                    bomProduct.Quantity = bomProduct.Quantity * relation.PartsPerCycle;

                                    if (childSetupInfo.BOMProductToConsumableFeed.ContainsKey(bomId))
                                    {
                                        setupInfo.BOMProductToConsumableFeed[bomId] = childSetupInfo.BOMProductToConsumableFeed[bomId];
                                    }
                                }
                                else
                                {
                                    groupBomProducts[bomId].Quantity += bomProduct.Quantity * relation.PartsPerCycle;
                                }
                            }
                        }
                    }
                    #endregion

                    #region Create virtual BOM object
                    if (groupBomProducts.Count > 0)
                    {
                        setupInfo.BOM = parentGroupBom;
                        var bOMProductCollection = entityFactory.CreateCollection<IBOMProductCollection>();
                        bOMProductCollection.AddRange(groupBomProducts.Values);
                        //parentGroupBom.Load();
                        //parentGroupBom.LoadRelations(Navigo.Common.Constants.BOMProduct);
                       var  relationCollection  = serviceProvider.GetService<ICmfEntityRelationCollection>();
                        relationCollection.Add(bOMProductCollection);
                        parentGroupBom.RelationCollection= relationCollection;
                    }

                    #endregion
                }
            }

            #region Replace Output Bom object
            if (parentGroupBom?.BomProducts != null)
            {
                if (multipleWizardOutput != null)
                {
                    multipleWizardOutput.Bom = parentGroupBom;
                    multipleWizardOutput.BOMSetupInformation = setupInfo;
                }
                else if (singleWizardOutput != null)
                {
                    singleWizardOutput.Bom = parentGroupBom;
                }
            }
            #endregion

            
            //---End DEE Code---

            return Input;
        }
    }
}
