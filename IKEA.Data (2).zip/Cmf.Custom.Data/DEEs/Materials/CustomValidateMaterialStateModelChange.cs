﻿using Cmf.Custom.IKEA.Common;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.Common;
using Cmf.Navigo.BusinessObjects;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Custom.IKEA.Common.Exceptions;

namespace Cmf.Custom.IKEA.Actions.Materials
{
    public class CustomValidateMaterialStateModelChange : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     DEE to validate the change of material state model depending on material's system state
            /// Action Groups:
            ///     BusinessObjects.Material.LogEvent.Pre
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.Material.LogEvent.Pre"
            };

            // Only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            if (executionVeridict && (IKEADEEActionUtilities.GetInputItem<IMaterial>(Input, "Material") == null ||
                                      IKEADEEActionUtilities.GetInputItem<IStateModel>(Input, "StateModel") == null ||
                                      IKEADEEActionUtilities.GetInputItem<string>(Input, "TransitionName") == null))
            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Exceptions");
            //System
            UseReference("", "System");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            //Foundation
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.Common.dll", "Cmf.Foundation.Common");
            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");


            IMaterial material = Input["Material"] as IMaterial;
            IStateModel stateModel = Input["StateModel"] as IStateModel;
            string transitionName = Input["TransitionName"] as string;

            if (stateModel.Name.CompareStrings(IKEAConstants.MaterialStateModel))
            {
                string spliter = " to ";
                // Extract to witch state model is the material being changed
                var newState = transitionName.Split(new[] { spliter }, StringSplitOptions.None)[1];

                // validate if the action is valid depending on the material's system state
                bool allowChangeState = true;
                switch (newState)
                {
                    case IKEAConstants.MaterialStateModelQueued:
                        if (material.SystemState != MaterialSystemState.Queued)
                        {
                            allowChangeState = false;
                        }
                        break;

                    case IKEAConstants.MaterialStateModelDispatched:
                        if (material.SystemState != MaterialSystemState.Dispatched)
                        {
                            allowChangeState = false;
                        }
                        break;

                    case IKEAConstants.MaterialStateModelSetup:
                    case IKEAConstants.MaterialStateModelInProcess:
                    case IKEAConstants.MaterialStateModelAborting:
                    case IKEAConstants.MaterialStateModelCompleting:
                        if (material.SystemState != MaterialSystemState.InProcess)
                        {
                            allowChangeState = false;
                        }
                        break;

                    case IKEAConstants.MaterialStateModelAborted:
                        if (material.SystemState != MaterialSystemState.InProcess
                            && material.SystemState != MaterialSystemState.Queued)
                        {
                            allowChangeState = false;
                        }
                        break;

                    case IKEAConstants.MaterialStateModelCompleted:
                        if (material.SystemState != MaterialSystemState.InProcess
                            && material.SystemState != MaterialSystemState.Processed)
                        {
                            allowChangeState = false;
                        }
                        break;
                }

                if (!allowChangeState)
                {
                    throw new IKEAException(IKEAConstants.CustomValidateMaterialStateModelChangeNotAllowed, newState, material.SystemState.ToString());
                }
            }

            //---End DEE Code---

            return Input;
        }

        
    }
}
