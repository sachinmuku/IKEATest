﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Custom.IKEA.BusinessObjects.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Navigo.BusinessObjects.Abstractions;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Data;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.Materials
{
    public class CustomSortMaterialsToDispatch : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            bool executionVeridict = true;

            if (executionVeridict)
            {
                if (IKEADEEActionUtilities.GetInputItem<IMaterial>(Input, "Material") == null)
                {
                    executionVeridict = false;
                }
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            UseReference("Cmf.Custom.IKEA.BusinessObjects.CustomPOOperationResource.dll", "Cmf.Custom.IKEA.BusinessObjects.Abstractions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IMaterial material = Input["Material"] as IMaterial;

            if (material == null)
            {
                throw new ArgumentNullException("Material");
            }
            var output = new Dictionary<string, object>();
            if (material.ProductionOrder != null)
            {
                if (material.ProductionOrder.HasRelations(IKEAConstants.CustomPOOperationResource))
                {
                    if (material.ProductionOrder.RelationCollection[IKEAConstants.CustomPOOperationResource] != null && material.ProductionOrder.RelationCollection[IKEAConstants.CustomPOOperationResource].Select(pr => pr as ICustomPOOperationResource).FirstOrDefault().StartTime.HasValue)
                    {
                        output["Result"] = material.ProductionOrder.RelationCollection[IKEAConstants.CustomPOOperationResource].Select(pr => pr as ICustomPOOperationResource).FirstOrDefault().StartTime;
                    }
                    else
                    {
                        output["Result"] = DateTime.MaxValue;
                    }
                }
                else
                {
                    output["Result"] = DateTime.MaxValue;
                }
            }
            else
            {
                output["Result"] = DateTime.MaxValue;
            }

            return output;
            //---End DEE Code---
        }

    }
}
