﻿using Cmf.Common.CustomActionUtilities;

using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Extensions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.Materials
{
    public class CustomCalculateMESLeftOversByCycle : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text:
            ///     Calculate in MES the left-overs by cycle after the trackin (setup) 
            ///     For GMO or MO with HPO disable
            /// Action Groups:
            ///     MaterialManagement.MaterialManagementOrchestration.ComplexTrackInMaterials.Post
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "MaterialManagement.MaterialManagementOrchestration.ComplexTrackInMaterials.Post"
            };

            bool executionVeridict = false;

            // only proceed if within expected triggers (action groups)
            bool isGroupValid = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            ComplexTrackInMaterialsInput trackInMaterialsInput = IKEADEEActionUtilities.GetInputItem<ComplexTrackInMaterialsInput>(Input, "ComplexTrackInMaterialsInput");

            if (isGroupValid && trackInMaterialsInput != null)
            {
                executionVeridict = true;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

     

            //System
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("", "System.Linq");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Extensions");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();

            ComplexTrackInMaterialsInput trackInMaterialsInput = IKEADEEActionUtilities.GetInputItem<ComplexTrackInMaterialsInput>(Input, "ComplexTrackInMaterialsInput");

            if (!trackInMaterialsInput.Materials.IsNullOrEmpty())
            {
                IMaterialCollection materials = trackInMaterialsInput.Materials;

                materials.LoadAttributes(new Collection<string> {
                        IKEAConstants.CustomMaterialAttributeIsGroupMO,
                        IKEAConstants.CustomMaterialAttributeGroupOrderHPOEnabled
                    });

                foreach (IMaterial material in materials)
                {
                    Dictionary<string, IBOMProductCollection> materialBOMProducts = new Dictionary<string, IBOMProductCollection>();

                    Dictionary<IMaterial, decimal> materialsMOsPartsPerCycle = new Dictionary<IMaterial, decimal>();

                    //If returns a GMO means this material is a MO inside a GMO and the calculation is only for a GMO or a MO alone
                    if (material.IsChildOfGroupMO())
                    {
                        continue;
                    }

                    //Only calculate the left overs if it is not HPO 
                    if (!material.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomMaterialAttributeGroupOrderHPOEnabled))
                    {
                        //Group MO
                        if (material.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomMaterialAttributeIsGroupMO))
                        {
                            // Get the child MOs materials and parts per cycle from the Group:
                            materialsMOsPartsPerCycle = ikeaUtilities.GetChildMaterialsAndPartsPerCycleFromGroupMO(material, loadAttributes: false);
                        }
                        //MO
                        else
                        {
                            //For MOs the parts per cycle is always 1 
                            materialsMOsPartsPerCycle.Add(material, 1);
                        }

                        if(materialsMOsPartsPerCycle == null || materialsMOsPartsPerCycle.Count() == 0)
                        {
                            continue;
                        }

                        #region Check if a MO has the attribute MESLeftOversByCycle filled
                        //To garantee there is only one MO with this attribute filled
                        IMaterialCollection mosCollection = entityFactory.CreateCollection<IMaterialCollection>();
                        
                        IMaterial moWithAttributeFilled = null;

                        if (materialsMOsPartsPerCycle.Count() > 1)
                        {
                            mosCollection.AddRange(materialsMOsPartsPerCycle.Keys.Select(m => m));

                            mosCollection.LoadAttributes(new Collection<string> {
                                IKEAConstants.CustomMaterialMESLeftOversByCycleAttribute
                            });

                            moWithAttributeFilled = mosCollection.Where(m => m.GetAttributeValueOrDefault<decimal>(IKEAConstants.CustomMaterialMESLeftOversByCycleAttribute) > 0).FirstOrDefault();
                        }
                        #endregion

                        List<string> childrenNames = new List<string>();
                        if(moWithAttributeFilled != null)
                        {
                            childrenNames.Add(moWithAttributeFilled.Name);
                        }
                        else
                        {
                            childrenNames = materialsMOsPartsPerCycle.Keys.Select(child => child.Name).ToList();
                        }
                            
                        materialBOMProducts = ikeaUtilities.GetCurrentBOMProductsWithMOsFromMaterials(childrenNames);

                        if (materialBOMProducts.Any())
                        {
                            IBOMProductCollection bOMProductsOfMO = null;
                            IMaterial moToSaveLeftOver = null;
                            IBOMProduct byProduct = null;

                            #region Get the Bom Product with ByProduct as true and the respective material
                            foreach (string moName in materialBOMProducts.Keys)
                            {
                                materialBOMProducts[moName].LoadAttributes(new Collection<string>
                                {
                                    IKEAConstants.BomProductIsByProductSegmentAttribute
                                });

                                //If there is a by-product is to calculate the left-over in MES
                                byProduct = materialBOMProducts[moName].FirstOrDefault(d => d.GetAttributeValueOrDefault<bool>(IKEAConstants.BomProductIsByProductSegmentAttribute));
                                if (byProduct != null)
                                {
                                    bOMProductsOfMO = materialBOMProducts[moName];
                                    moToSaveLeftOver = materialsMOsPartsPerCycle.Keys.FirstOrDefault(m => m.Name == moName);
                                }
                            }
                            #endregion

                            if (moToSaveLeftOver != null && bOMProductsOfMO != null && byProduct != null)
                            {
                                //First Bom product with is refence false - should be the plain board
                                IBOMProduct bOMProductPlainBoard = bOMProductsOfMO.FirstOrDefault(d => !d.IsReference.HasValue || !d.IsReference.Value);

                                if (bOMProductPlainBoard != null)
                                {
                                    #region Calculate the board area
                                    IProduct productBoard = bOMProductPlainBoard.TargetEntity;
                                    productBoard.Load();
                                    productBoard.LoadAttributes(new Collection<string>
                                    {
                                        IKEAConstants.CustomProductAttributeThickness,
                                        IKEAConstants.CustomProductAttributeFinishedWidth,
                                        IKEAConstants.CustomProductAttributeFinishedLength,
                                    });

                                    //TODO CHECK IF ALL BOARD AND MOS HAVE THE SAME m2 OR m3 
                                    decimal? width = productBoard.GetRelatedAttributeValueOrDefault<decimal?>(IKEAConstants.CustomProductAttributeFinishedWidth);
                                    decimal? length = productBoard.GetRelatedAttributeValueOrDefault<decimal?>(IKEAConstants.CustomProductAttributeFinishedLength);
                                    decimal? thickness = productBoard.GetRelatedAttributeValueOrDefault<decimal?>(IKEAConstants.CustomProductAttributeThickness);

                                    decimal areaBoard = 0;

                                    if (width.HasValue && length.HasValue && thickness.HasValue)
                                    {
                                        areaBoard = width.Value * length.Value * thickness.Value;
                                    }
                                    else if (width.HasValue && length.HasValue)
                                    {
                                        areaBoard = width.Value * length.Value;
                                    }
                                    #endregion Calculate the board area

                                    if (areaBoard > 0)
                                    {
                                        decimal areaOfAllMOs = 0;

                                        foreach (IMaterial mo in materialsMOsPartsPerCycle.Keys)
                                        {
                                            #region Calculate the MO area
                                            IProduct productMO = mo.Product;
                                            productMO.Load();
                                            productMO.LoadAttributes(new Collection<string>
                                            {
                                                IKEAConstants.CustomProductAttributeThickness,
                                                IKEAConstants.CustomProductAttributeFinishedWidth,
                                                IKEAConstants.CustomProductAttributeFinishedLength,
                                            });

                                            decimal areaMO = 0;

                                            decimal? widthMO = productMO.GetRelatedAttributeValueOrDefault<decimal?>(IKEAConstants.CustomProductAttributeFinishedWidth);
                                            decimal? lengthMO = productMO.GetRelatedAttributeValueOrDefault<decimal?>(IKEAConstants.CustomProductAttributeFinishedLength);
                                            decimal? thicknessMO = productMO.GetRelatedAttributeValueOrDefault<decimal?>(IKEAConstants.CustomProductAttributeThickness);

                                            if (widthMO.HasValue && lengthMO.HasValue && thicknessMO.HasValue)
                                            {
                                                areaMO = widthMO.Value * lengthMO.Value * thicknessMO.Value;
                                            }
                                            else if (widthMO.HasValue && lengthMO.HasValue)
                                            {
                                                areaMO = widthMO.Value * lengthMO.Value;
                                            }
                                            #endregion Calculate the MO area

                                            //By cycle - multiply the area for the parts per cycle
                                            areaOfAllMOs += areaMO * materialsMOsPartsPerCycle[mo];
                                        }

                                        decimal leftovers = 0;

                                        if (areaOfAllMOs > 0)
                                        {
                                            leftovers = areaBoard - areaOfAllMOs;
                                        }

                                        if (leftovers > 0)
                                        {
                                            #region Save attribute MESLeftOversByCycle
                                            IProduct productLeftOver = byProduct.TargetEntity;
                                            productLeftOver.Load();

                                            //New quantity is always in mm because IKEA maintains the dimension attributes for consumables and products in millimeters (mm)
                                            if (productLeftOver.DefaultUnits != IKEAConstants.MillimetersUnits)
                                            {
                                                decimal conversion = 1;
                                                
                                                ikeaUtilities.GetUnitConversionFactor(IKEAConstants.MillimetersUnits, productLeftOver.DefaultUnits, ref conversion);

                                                leftovers *= conversion;
                                            }

                                            //Round to the maximum possible decimal
                                            leftovers = Math.Round(leftovers, 6);

                                            IAttributeCollection attributeLeftOver = new AttributeCollection
                                            {
                                                {IKEAConstants.CustomMaterialMESLeftOversByCycleAttribute, leftovers }
                                            };

                                            moToSaveLeftOver.SaveAttributes(attributeLeftOver);

                                            #endregion
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }


            


            //---End DEE Code---
            return Input;
        }


    }
}
