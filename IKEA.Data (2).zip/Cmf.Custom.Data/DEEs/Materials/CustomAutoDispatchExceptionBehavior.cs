﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.BusinessObjects.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessOrchestration.Abstractions;
using Cmf.Foundation.BusinessOrchestration.SecurityManagement.InputObjects;
using Cmf.Foundation.BusinessOrchestration.SecurityManagement.OutputObjects;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;



namespace Cmf.Custom.IKEA.Actions.Materials
{
    public class CustomAutoDispatchExceptionBehavior : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Auto dispatch Exception Behavior

            /// Action Groups:
            ///     BusinessObjects.MaterialCollection.Create.Post
            ///     BusinessObjects.MaterialCollection.MoveToNextStep.Post
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.MaterialCollection.Create.Post",
                "BusinessObjects.MaterialCollection.MoveToNextStep.Post"
            };

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            if (executionVeridict && IKEADEEActionUtilities.GetInputItem<IMaterialCollection>(Input, "MaterialCollection") == null)
            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
			//---Start DEE Code---     

UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
     

			// System
			UseReference("", "Cmf.Foundation.BusinessOrchestration.Abstractions");
UseReference("", "Cmf.Custom.IKEA.BusinessObjects.Abstractions");
UseReference("", "System.Linq");
			UseReference("", "System.Collections.Generic");
			UseReference("", "System");
			UseReference("", "System.Collections.ObjectModel");

			// Navigo
			UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

			// Custom
			UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
			UseReference("Cmf.Custom.IKEA.BusinessObjects.CustomPOOperationResource.dll", "Cmf.Custom.IKEA.BusinessObjects");

			// Common
			UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

			// Foundation
			UseReference("Cmf.Foundation.Common.dll", "Cmf.Foundation.Common");
			UseReference("Cmf.Foundation.Security.dll", "Cmf.Foundation.Security");
			UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
			UseReference("Cmf.Foundation.BusinessOrchestration.dll", "");
			UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.SecurityManagement");
			UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.SecurityManagement.OutputObjects");
			UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.SecurityManagement.InputObjects");

            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();
            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IAlarmHandlingUtilities alarmHandlingUtilities = serviceProvider.GetService<IAlarmHandlingUtilities>();
            IProductionOrderHandlingUtilities productionOrderHandlingUtilities = serviceProvider.GetService<IProductionOrderHandlingUtilities>();
            var functionalityManagementOrchestration = serviceProvider.GetService<IFunctionalityManagementOrchestration>();


			IMaterialCollection materials = Input["MaterialCollection"] as IMaterialCollection;


            // Check if, by creating a new PO we need to prevent auto dipatch (in the case it is an MO to be included in a GroupMO)
            bool? preventAutoDispatch = deeContextUtilities.GetContextParameter("CustomERPProductionOrderHandler_PreventToAutoDispatch") as bool?;
            if (!preventAutoDispatch.HasValue || !preventAutoDispatch.Value)
            {

                foreach (var material in materials)
                {
                    IFlow flow = genericUtilities.GetFlowsInFlowPath(material.FlowPath).LastOrDefault();

                    if (flow != null)
                    {
                        flow.Load();
                        IFlowStep flowStep = genericUtilities.GetFirstOrLastFlowStepFromFlow(flow);

                        if (material.ProductionOrder != null)
                        {
                            if (flowStep != null)
                            {
                                // Load ERP operation code from flow attribute
                                flow.LoadAttributes(new Collection<string>() { IKEAConstants.ERPOperationCode });
                                string flowERPOperationCode = flow.GetRelatedAttributeValueOrDefault<string>(IKEAConstants.ERPOperationCode);

                                if (!String.IsNullOrEmpty(flowERPOperationCode))
                                {
                                    var useToValidate = string.Format("{0}:{1}", flowStep.TargetEntity.Name, flowStep.CorrelationID.Value);

                                    // check if the material current step is the first step in the flow
                                    if (material.FlowPath.Split('/').Last() == useToValidate)
                                    {
                                        IProductionOrder productionOrder = material.ProductionOrder;
                                        Cmf.Navigo.BusinessObjects.Abstractions.IResource resource = null;
                                        ICustomPOOperationResourceCollection returnVal = entityFactory.CreateCollection<ICustomPOOperationResourceCollection>();

                                        // Load PO relation Custom PO Operation Resource
                                        productionOrder.LoadRelations(IKEAConstants.CustomPOOperationResource);
                                        if (productionOrder.RelationCollection != null)
                                        {
                                            var relations = productionOrder.RelationCollection.FirstOrDefault(E => E.Key.CompareStrings(IKEAConstants.CustomPOOperationResource));
                                            if (relations.Value != null)
                                            {
                                                returnVal.AddRange(relations.Value.Cast<ICustomPOOperationResource>());

                                                // gets the resource that has the same operation code as the flow attribute ERPOperationCode
                                                var relation = returnVal.Where(x => x.OperationCode == flowERPOperationCode).FirstOrDefault();
                                                if (relation != null)
                                                {
                                                    resource = relation.TargetEntity;
                                                }
                                            }
                                        }

                                        if (resource != null)
                                        {
                                            // Check if it is an AdHoc PO for type rework/repair
                                            Dictionary<string, string> integrationEntryAttributes = productionOrderHandlingUtilities.GetIntegrationEntryAttributes(productionOrder.Name);
                                            bool isAdHocPO = integrationEntryAttributes.Any(key => !string.IsNullOrWhiteSpace(key.Value));

                                            // If it is an AdHoc PO, dispatch the requested MO to the requesting resource
                                            if (isAdHocPO)
                                            {
                                                bool isResourceReadyToDispatch = (resource.SystemState == ResourceSystemState.Up) && (resource.IsDispatchable == true);

												if (isResourceReadyToDispatch)
                                                {
													ikeaUtilities.DispatchMaterial(material, resource);
												}
                                                else
                                                {
                                                    IEmployeeCollection employeesToBeNotified = entityFactory.CreateCollection<IEmployeeCollection>();													

													if (!string.IsNullOrWhiteSpace(resource.Name))
													{
                                                        // Get employees chechecked-in at the resource
														employeesToBeNotified = genericUtilities.GetCheckedInEmployees(resource.Name);

                                                        if (employeesToBeNotified != null && employeesToBeNotified.Any())
                                                        {
                                                            employeesToBeNotified.Load();
                                                        }

														//Validate if Severity exists in config
														string severity = ikeaUtilities.GetValueFromConfigurationWithPath(IKEAConstants.DefaultNotificationSeverityConfig);

														if (string.IsNullOrWhiteSpace(severity))
														{
															throw new CmfBaseException(ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomDefaultNotificationSeverityConfigNotDefined, IKEAConstants.DefaultNotificationSeverityConfig));
														}

														double notificationDuration = genericUtilities.GetConfigurationValueByPath<int>(IKEAConstants.InterlockNotificationDuration);

														// Create Notification
														foreach (IEmployee employee in employeesToBeNotified)
														{
															// Check if checked-in user has feature Custom.CreateProductionOrder
															Cmf.Foundation.BusinessOrchestration.SecurityManagement.InputObjects.GetUserFunctionalitiesInput input = new GetUserFunctionalitiesInput() 
                                                            {
                                                                User = employee.User,
                                                            };
															GetUserFunctionalitiesOutput output = functionalityManagementOrchestration.GetUserFunctionalities(input);

                                                            string userFeature = output.Functionalities.Select(funct => funct.Name = IKEAConstants.CreateProductionOrder).ToString();

                                                            if (!string.IsNullOrWhiteSpace(userFeature))
                                                            {
                                                                Cmf.Navigo.BusinessObjects.Abstractions.INotification notification = entityFactory.Create<Cmf.Navigo.BusinessObjects.Abstractions.INotification>();


                                                                notification.Type = "System";
																notification.Title = ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomAdhocMaterialCouldNotBeAutomaticallyDispatchedTitle, material.Name);
                                                                notification.Details = ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomAdhocMaterialCouldNotBeAutomaticallyDispatched, material.Name, material.SystemState, resource.Name, resource.SystemState);
                                                                notification.Severity = ikeaUtilities.GetValueFromLookupTable(IKEAConstants.NotificationSeverityLookupTableName, severity, true);
                                                                notification.AssignmentType = (NotificationAssignmentType)AssignmentType.Employee;
                                                                notification.AssignedToUser = employee.User;
                                                                notification.ClearanceMode = ClearanceMode.ManualEveryUser;
                                                                notification.ValidTo = DateTime.Now.AddMinutes(notificationDuration);
                                                                notification.SendEmailToAssignedParty = false;
																
																notification.Create();
															}
														}
													}
												}
											}
                                            else 
                                            {
												// If material is not from an Ad hoc PO, handle it using the Auto Dispatch feature
												// Validate if resource has AutoDispatch flag enabled
												bool resourceHasAutoDispatch = resource.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomAutomaticDispatch, true);
												if (resourceHasAutoDispatch)
												{
													ikeaUtilities.CustomAutoDispatchUtility(material, resource);
												}
											}                                           
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            
            //---End DEE Code---

            return Input;
        }

    }
}
