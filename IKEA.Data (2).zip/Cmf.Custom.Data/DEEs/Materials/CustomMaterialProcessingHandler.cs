﻿using Cmf.Common.CustomActionUtilities;

using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Extensions;
using Cmf.Custom.IKEA.Common.WMS;
using Cmf.Foundation.BusinessObjects;
using Cmf.Navigo.BusinessObjects;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Foundation.Common;
using Microsoft.Extensions.DependencyInjection;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common.Abstractions;



namespace Cmf.Custom.IKEA.Actions.Materials
{
    public class CustomMaterialProcessingHandler : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Based on the configuration in the CustomMaterialMovementConfiguration SmartTable,
            ///     it will ether automatically Move Next, Move Next and Store, Store or do nothing
            /// Action Groups:
            ///     BusinessObjects.MaterialCollection.TrackIn.Post
            ///     BusinessObjects.MaterialCollection.TrackOut.Post
            ///     BusinessObjects.MaterialCollection.Dispatch.Post
            ///     BusinessObjects.MaterialCollection.Undispatch.Pre
            ///     BusinessObjects.MaterialCollection.Undispatch.Post
            ///     BusinessObjects.MaterialCollection.AbortProcess.Post
            ///     BusinessObjects.Resource.AttachConsumables.Post
            ///     BusinessObjects.Resource.DetachConsumables.Post
            ///     BusinessObjects.Resource.DetachConsumable.Post
            ///     BusinessObjects.MaterialCollection.MoveToNextStep.Pre
            ///     BusinessObjects.MaterialCollection.MoveToNextStep.Post
            ///     BusinessObjects.MaterialCollection.ChangeFlowAndStep.Pre
            ///     BusinessObjects.MaterialCollection.ChangeFlowAndStep.Post
            ///     BusinessObjects.MaterialCollection.Store.Post
            ///     BusinessObjects.MaterialCollection.Retrieve.Pre
            ///     BusinessObjects.MaterialCollection.Retrieve.Post
            ///     BusinessObjects.MaterialCollection.Terminate.Post
            ///     BusinessObjects.MaterialCollection.ChangeType.Post
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.MaterialCollection.TrackIn.Post",
                "BusinessObjects.MaterialCollection.TrackOut.Post",
                "BusinessObjects.MaterialCollection.Dispatch.Post",
                "BusinessObjects.MaterialCollection.Undispatch.Pre",
                "BusinessObjects.MaterialCollection.Undispatch.Post",
                "BusinessObjects.MaterialCollection.AbortProcess.Post",
                "BusinessObjects.Resource.AttachConsumables.Post",
                "BusinessObjects.Resource.DetachConsumables.Post",
                "BusinessObjects.Resource.DetachConsumable.Post",
                "BusinessObjects.MaterialCollection.MoveToNextStep.Pre",
                "BusinessObjects.MaterialCollection.MoveToNextStep.Post",
                "BusinessObjects.MaterialCollection.ChangeFlowAndStep.Pre",
                "BusinessObjects.MaterialCollection.ChangeFlowAndStep.Post",
                "BusinessObjects.MaterialCollection.Store.Post",
                "BusinessObjects.MaterialCollection.Retrieve.Pre",
                "BusinessObjects.MaterialCollection.Retrieve.Post",
                "BusinessObjects.MaterialCollection.Terminate.Post",
                "BusinessObjects.MaterialCollection.ChangeType.Post"
            };

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            if (executionVeridict && 
                (IKEADEEActionUtilities.GetInputItem<IMaterialCollection>(Input, Navigo.Common.Constants.MaterialCollection) == null)
                && (IKEADEEActionUtilities.GetInputItem<IMaterialCollection>(Input, Navigo.Common.Constants.Materials) == null)
                && (IKEADEEActionUtilities.GetInputItem<IMaterial>(Input, Navigo.Common.Constants.Material) == null))

            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
     

            //System
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("", "System");

            //Navigo
            UseReference("Cmf.Navigo.Common.dll", "Cmf.Navigo.Common");
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Extensions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.WMS");
            
            UseReference("Cmf.Custom.IKEA.Orchestration.dll", "Cmf.Custom.IKEA.Orchestration.DataStructures");
            UseReference("Cmf.Custom.IKEA.BusinessObjects.CustomWMSMaterialTracker.dll", "");


            System.IServiceProvider serviceProvider = ApplicationContext.CurrentServiceProvider;
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            IWMSUtilities wmsUtilities = serviceProvider.GetService<IWMSUtilities>();

            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();

            DeeContext currentContext = deeContextUtilities.SetCurrentServiceContext("CustomMaterialProcessingHandler");

            IEntityFactory entityFactory = serviceProvider.GetRequiredService<IEntityFactory>();

            IMaterialCollection materials = null;
            // Dictionary associating each Material with the id of it's current Resource
            Dictionary<string, long> resourcesByMaterial = null;
            // Dictionary associating each Material with the id of it's current Step
            Dictionary<string, long> stepsByMaterial = null;
            // Dictionary associating each Material with the id of it's previous Step
            Dictionary<string, long> previousStepsByMaterial = null;

            #region Compile material, resource and step data from the input

            // ActionGroups in the ResourceCollection
            if (currentContext.MethodName == "AttachConsumables" || currentContext.MethodName == "DetachConsumables" || currentContext.MethodName == "DetachConsumable")
            {
                if (currentContext.MethodName == "AttachConsumables")
                {
                    materials = entityFactory.CreateCollection<IMaterialCollection>();
                    materials.AddRange(
                        IKEADEEActionUtilities.GetInputItem<Dictionary<IMaterial, IAttachConsumableParameters>>(Input, Navigo.Common.Constants.Materials).Keys
                    );
                }
                else if (currentContext.MethodName == "DetachConsumables")
                {
                    // The Detach method already gives us a MaterialCollection
                    materials = IKEADEEActionUtilities.GetInputItem<IMaterialCollection>(Input, Navigo.Common.Constants.Materials);
                }
                else if (currentContext.MethodName == "DetachConsumable")
                {
                    materials = entityFactory.CreateCollection<IMaterialCollection>();
                    materials.Add(IKEADEEActionUtilities.GetInputItem<IMaterial>(Input, Navigo.Common.Constants.Material));
                }

                // All the materials will have the same associated resource, the one they're being attached to
                IResource attachResource = IKEADEEActionUtilities.GetInputItem<IResource>(Input, Navigo.Common.Constants.Resource);
                resourcesByMaterial = materials.ToDictionary(mat => mat.Name, _ => attachResource.Id);
            }
            else
            {
                // All the remaining action groups are for methods of the MaterialCollection class
                materials = IKEADEEActionUtilities.GetInputItem<IMaterialCollection>(Input, Navigo.Common.Constants.MaterialCollection);

                if (currentContext.MethodName == "MoveToNextStep" || currentContext.MethodName == "ChangeFlowAndStep")
                {
                    // Save the Steps before the materials are moved
                    if (currentContext.TriggerPoint == DeeTriggerPoint.Pre)
                    {
                        previousStepsByMaterial = materials.ToDictionary(mat => mat.Name, mat => mat.GetNativeValue<long>(Navigo.Common.Constants.Step));

                        deeContextUtilities.SetContextParameter(IKEAConstants.CustomMaterialProcessingHandlerPreviousStepsByMaterialContextKey, previousStepsByMaterial);
                    }
                    else if (currentContext.TriggerPoint == DeeTriggerPoint.Post)
                    {
                        previousStepsByMaterial = (Dictionary<string, long>)deeContextUtilities.GetContextParameter(IKEAConstants.CustomMaterialProcessingHandlerPreviousStepsByMaterialContextKey);
                    }
                }
                else if (currentContext.MethodName == "Retrieve" || currentContext.MethodName == "Undispatch")
                {
                    // Save the Resources before the materials are retrieved or dispatched
                    if (currentContext.TriggerPoint == DeeTriggerPoint.Pre)
                    {
                        materials.LoadRelations(Navigo.Common.Constants.MaterialResource);

                        resourcesByMaterial = materials.ToDictionary(mat => mat.Name, mat => mat.MaterialResourceRelations?[0].TargetEntity.Id ?? 0);

                        deeContextUtilities.SetContextParameter(IKEAConstants.CustomMaterialProcessingHandlerResourcesByMaterialContextKey, resourcesByMaterial);
                    }
                    else if (currentContext.TriggerPoint == DeeTriggerPoint.Post)
                    {
                        resourcesByMaterial = (Dictionary<string, long>)deeContextUtilities.GetContextParameter(IKEAConstants.CustomMaterialProcessingHandlerResourcesByMaterialContextKey);
                    }
                }
                else if (currentContext.MethodName == "Store" || currentContext.MethodName == "Dispatch")
                {
                    materials.LoadRelations(Navigo.Common.Constants.MaterialResource);

                    resourcesByMaterial = materials.ToDictionary(mat => mat.Name, mat => mat.MaterialResourceRelations?[0].TargetEntity.Id ?? 0);
                }
            }

            if (resourcesByMaterial == null) resourcesByMaterial = new Dictionary<string, long>();
            if (stepsByMaterial == null) stepsByMaterial = new Dictionary<string, long>();
            if (previousStepsByMaterial == null) previousStepsByMaterial = new Dictionary<string, long>();

            foreach (var material in materials)
            {
                if (!resourcesByMaterial.ContainsKey(material.Name))
                {
                    long resourceId = material.GetNativeValue<long>(IKEAConstants.MaterialPropertyLastProcessedResource);

                    resourcesByMaterial.Add(material.Name, resourceId);
                }

                if (!stepsByMaterial.ContainsKey(material.Name))
                {
                    long stepId = material.GetNativeValue<long>(Navigo.Common.Constants.Step);

                    stepsByMaterial.Add(material.Name, stepId);
                }

                if (!previousStepsByMaterial.ContainsKey(material.Name))
                {
                    long stepId = material.GetNativeValue<long>(Navigo.Common.Constants.Step);

                    previousStepsByMaterial.Add(material.Name, 0);
                }
            }

            #endregion

            // All the Pre trigger points are used only to save information in the call context, therefore no actual action needs to be performed for them
            if (currentContext.TriggerPoint == DeeTriggerPoint.Post)
            {
                Dictionary<IMaterial, MaterialMovementBehavior> materialMovementBehaviors = new Dictionary<IMaterial, MaterialMovementBehavior>();

                #region Retrieve all matching movement behaviors from the Smart Table

                // The material events (TrackIn, Dispatch, etc...) triggered by this operation.
                List<string> eventsList = new List<string>();

                #region Calculate the appropriate event names based on the action group
                if (currentContext.MethodName == "MoveToNextStep" || currentContext.MethodName == "ChangeFlowAndStep")
                {
                    eventsList.AddRange(new string[] { "StepOut", "StepIn" });
                }
                else if (currentContext.MethodName == "AbortProcess")
                {
                    eventsList.Add("Abort");
                }
                else if (currentContext.MethodName == "DetachConsumables" || currentContext.MethodName == "DetachConsumable")
                {
                    eventsList.Add(IKEAConstants.WMSDetach);
                }
                else
                {
                    eventsList.Add(currentContext.MethodName);
                }
                #endregion

                // Load all resources
                List<long> resourceIds = resourcesByMaterial.Values.Where(id => id > 0).Distinct().ToList();
                IResourceCollection resources = entityFactory.CreateCollection<IResourceCollection>();
                resources.LoadByIDs<IResource, Resource>(resourceIds);

                // Load all areas
                List<long> areaIds = resources.Select(r => r.GetNativeValue<long>(Navigo.Common.Constants.Area)).Distinct().ToList();
                IAreaCollection areas = entityFactory.CreateCollection<IAreaCollection>();
                areas.LoadByIDs<IArea, Area>(areaIds);

                // Load all facilities
                List<long> facilityIds = areas.Select(r => r.GetNativeValue<long>(Navigo.Common.Constants.Facility))
                    .Concat(materials.Select(m => m.GetNativeValue<long>(Navigo.Common.Constants.Facility))).Distinct().ToList();
                IFacilityCollection facilities = entityFactory.CreateCollection<IFacilityCollection>(); 
                facilities.LoadByIDs<IFacility, Facility>(facilityIds);

                // Load all steps
                List<long> stepIds = stepsByMaterial.Values.Concat(previousStepsByMaterial.Values).Distinct().ToList();
                IStepCollection steps = entityFactory.CreateCollection<IStepCollection>();
                steps.LoadByIDs<IStep, Step>(stepIds);

                // Load all products
                List<long> productIds = materials.Select(m => m.GetNativeValue<long>(Navigo.Common.Constants.Product)).Distinct().ToList();
                IProductCollection products = entityFactory.CreateCollection<IProductCollection>();
                products.LoadByIDs<IProduct, Product>(productIds);

                // Load all product groups
                List<long> productGroupIds = products.Select(p => p.GetNativeValue<long>(Navigo.Common.Constants.ProductGroup)).Where(id => id > 0).Distinct().ToList();
                IProductGroupCollection productGroups = entityFactory.CreateCollection<IProductGroupCollection>();
                productGroups.LoadByIDs<IProductGroup, ProductGroup>(productGroupIds);

                // Get all material movement behaviors
                foreach (IMaterial material in materials)
                {
                    foreach (var eventName in eventsList)
                    {
                        IResource resource = null;
                        IArea area = null;
                        IFacility facility = null;
                        IStep step = null;
                        IProduct product = null;
                        IProductGroup productGroup = null;

                        // Get resource of the material
                        if (eventName != "StepIn")
                        {
                            long materialResourceId = resourcesByMaterial[material.Name];
                            resource = resources.FirstOrDefault(r => r.Id == materialResourceId);
                        }

                        // Get area of the resource
                        if (resource != null)
                        {
                            long materialAreaId = resource.GetNativeValue<long>(Navigo.Common.Constants.Area);
                            area = areas.FirstOrDefault(a => a.Id == materialAreaId);
                        }

                        // Get facility for the area
                        if (area != null)
                        {
                            long materialFacilityId = area.GetNativeValue<long>(Navigo.Common.Constants.Facility);
                            facility = facilities.FirstOrDefault(f => f.Id == materialFacilityId);
                        }

                        // Get step of the material
                        if (eventName == "StepOut")
                        {
                            long materialStepId = previousStepsByMaterial[material.Name];
                            step = steps.First(s => s.Id == materialStepId);
                        }
                        else
                        {
                            long materialStepId = stepsByMaterial[material.Name];
                            step = steps.First(s => s.Id == materialStepId);
                        }

                        long materialProductId = material.GetNativeValue<long>(Navigo.Common.Constants.Product);
                        product = products.FirstOrDefault(p => p.Id == materialProductId || p.DefinitionId == materialProductId);

                        if (product != null)
                        {
                            long materialProductGroupId = product.GetNativeValue<long>(Navigo.Common.Constants.ProductGroup);
                            productGroup = productGroups.FirstOrDefault(p => p.Id == materialProductGroupId);
                        }

                        MaterialMovementBehavior movementBehavior =
                            ikeaUtilities.ResolveMaterialMovementBehavior(facility?.Name, area?.Name, step.Name, resource?.Name, productGroup?.Name, product?.Name, material.Type, eventName);

                        // Get material behavior excluding None
                        if (movementBehavior != null && !movementBehavior.IsNone)
                        {
                            materialMovementBehaviors.Add(material, movementBehavior);
                        }
                    }
                }

                #endregion

                // Check if there are any material movement behavior defined for the materials
                if (!materialMovementBehaviors.IsNullOrEmpty())
                {
                    Dictionary<IMaterial, string> materialNextStep = new Dictionary<IMaterial, string>();

                    #region Handle WMSRequest != None
                    List<WMSAutomationJobInput> jobInputs = new List<WMSAutomationJobInput>();
                    HashSet<long> jobCancelIds = new HashSet<long>();

                    // Load any resources that might be stored in the DestinationResource column
                    IResourceCollection destinationResources = entityFactory.CreateCollection<IResourceCollection>();
                    destinationResources.AddRange(materialMovementBehaviors
                        .Where(m => !m.Value.DestinationResource.IsNullOrEmpty())
                        .Where(m => m.Value.WMSRequest == CustomWMSOrderRequestType.Move || m.Value.WMSRequest == CustomWMSOrderRequestType.Feed)
                        .Select(m => { var r = entityFactory.Create<IResource>(); r.Name = m.Value.DestinationResource; return r; })
                    );
                    destinationResources.Load();

                    // Cache associating each MainLine resource's Name with the destination's resources information to use for FEED orders
                    Dictionary<string, FeedDestinations> feedDestinationsByMainLine = new Dictionary<string, FeedDestinations>();

                    foreach (var materialMovementBehavior in materialMovementBehaviors.Where(m => m.Value.WMSRequest != CustomWMSOrderRequestType.None))
                    {
                        IMaterial manufacturingOrder = materialMovementBehavior.Key;
                        CustomWMSOrderRequestType requestType = materialMovementBehavior.Value.WMSRequest;

                        // Cancel requests are handled differently: instead of being sent through the Data Platform, and spawning new AutomationJobs,
                        // they are sent to a IoT controller that handles them based on their existing Inventory Order Id
                        if (requestType == CustomWMSOrderRequestType.Cancel)
                        {
                            foreach (var tracker in wmsUtilities.GetCustomWMSMaterialTrackers(manufacturingOrder))
                            {
                                if (!jobCancelIds.Contains(tracker.InventoryOrderId.Value))
                                {
                                    jobCancelIds.Add(tracker.InventoryOrderId.Value);
                                }
                            }
                        }
                        else
                        {
                            #region Calculate the source and destination resources
                            IResource resource = resources.FirstOrDefault(r => r.Id == resourcesByMaterial[manufacturingOrder.Name]);

                            IResource sourceResource = resource;
                            IResource targetResource = null;

                            if (requestType == CustomWMSOrderRequestType.Feed)
                            {
                                // When requesting a FEED operation, there should be no source resource
                                sourceResource = null;

                                // Target Resource is the Main Line. For that reason, call GetTopMostResource()
                                targetResource = resource.GetTopMostResource();
                            }

                            if (requestType == CustomWMSOrderRequestType.Move)
                            {
                                if (materialMovementBehavior.Value.DestinationResource.IsNullOrEmpty())
                                {
                                    // A move must have configured a custom Destination Resource. The Main Line cannot be the default value
                                    // because it is the Source Resource in this case. This means the Smart Table has been misconfigured.
                                    continue;
                                }

                                // Target Resource is as configured in the main table
                                targetResource = destinationResources.FirstOrDefault(r => r.Name == materialMovementBehavior.Value.DestinationResource);
                            }
                            #endregion

                            jobInputs.AddRange(wmsUtilities.CreateWMSManufacturingOrderJobInputs(
                                type: requestType,
                                sourceResource: sourceResource,
                                targetResource: targetResource,
                                operationMaterial: manufacturingOrder,
                                feedDestinationsByMainLine: feedDestinationsByMainLine
                            ));
                        }
                    }

                    if (jobInputs.IsNullOrEmpty() == false)
                    {
                        wmsUtilities.SendOrderAutomationJobInputs(jobInputs);
                    }

                    if (jobCancelIds.IsNullOrEmpty() == false)
                    {
                        wmsUtilities.SendRequestToFactoryAutomation(jobCancelIds, IKEAConstants.WMSFactoryAutomationRequestTypeCancel);
                    }
                    #endregion

                    #region Handle EventAction "MoveNext" and "MoveNextAndStore"

                    // Go through all the material that the configured behavior requires a move next (MoveNext and MoveNextAndStore)
                    foreach (var materialMovementBehavior in materialMovementBehaviors.Where(m => m.Value.EventAction.CompareStrings(IKEAConstants.CustomMaterialMovementConfigurationMoveNext)
                                                                                                    || m.Value.EventAction.CompareStrings(IKEAConstants.CustomMaterialMovementConfigurationMoveNextAndStore)))
                    {
                        IMaterial material = materialMovementBehavior.Key;

                        // Get all the possible next steps of the material
                        INextStepsResultCollection nextStepsResults = material.GetNextSteps();

                        // Check if there are any next steps for the material
                        if (!nextStepsResults.IsNullOrEmpty())
                        {
                            // Validate if the next steps by material type
                            var materialCollection = entityFactory.CreateCollection<IMaterialCollection>();
                            materialCollection.Add(material);
                            INextStepsResultCollection validNextStepsResults = ikeaUtilities.ValidateMaterialAndStepTypeAtMoveNext(materialCollection, nextStepsResults);

                            if (!validNextStepsResults.IsNullOrEmpty())
                            {
                                steps.Add(validNextStepsResults[0].Step);
                                materialNextStep.Add(material, validNextStepsResults[0].FlowPath);
                            }
                        }
                    }

                    // If there are any materials to move to the next step, move them
                    // Edge case: when is triggered from 'Retrieve' context, NiceLabel integration must happen first
                    //            Considering this trigger happens before the integration to happen, and 'MoveNext' changes 
                    //            some of the material properties, such ProductionOrder relation, this movement was moved
                    //            on the label integration call (after the integration is sent)
                    if (!materialNextStep.IsNullOrEmpty())
                    {
                        if (currentContext.MethodName == "Retrieve")
                        {
                            // Nice label integration and Report to ERP must happen before the MoveNext, therefore this 
                            // movement has to happen in the future
                            Dictionary<IMaterial, string> materialProductionOrderList = new Dictionary<IMaterial,string>();
                            Dictionary<IMaterial, string> materialFlowPathList = new Dictionary<IMaterial, string>();
                            Dictionary<IMaterial, string> materialStepList = new Dictionary<IMaterial, string>();

                            foreach (IMaterial material in materialNextStep.Keys)
                            {
                                materialProductionOrderList.Add(material, material.ProductionOrder.Name);
                                materialFlowPathList.Add(material, material.FlowPath);
                                materialStepList.Add(material, material.Step.Name);
                            }
                            
                            deeContextUtilities.SetContextParameter("CustomMaterialProcessingHandlerMaterialProductionOrder", materialProductionOrderList);
                            deeContextUtilities.SetContextParameter("CustomMaterialProcessingHandlerMaterialFlowPath", materialFlowPathList);
                            deeContextUtilities.SetContextParameter("CustomMaterialProcessingHandlerMaterialStep", materialStepList);
                        }
                        materials.ComplexMoveMaterialsToNextStep(materialNextStep);
                    }

                    #endregion

                    #region Handle EventAction "Store" and "MoveNextAndStore"

                    Dictionary<IMaterial, IResource> materialStorage = new Dictionary<IMaterial, IResource>();

                    // Get Storage Services form the step
                    List<long> serviceIds = steps.Where(s => s.GetNativeValue<long>(IKEAConstants.StepPropertyProcessedStorageService) > 0).Select(s => s.GetNativeValue<long>(IKEAConstants.StepPropertyProcessedStorageService)).Distinct().ToList();
                    serviceIds.AddRange(steps.Where(s => s.GetNativeValue<long>(IKEAConstants.StepPropertyQueuedStorageService) > 0 && !serviceIds.Contains(s.GetNativeValue<long>(IKEAConstants.StepPropertyQueuedStorageService))).Select(s => s.GetNativeValue<long>(IKEAConstants.StepPropertyQueuedStorageService)).Distinct().ToList());

                    // Only proceed if there are any services configured
                    if (!serviceIds.IsNullOrEmpty())
                    {
                        Cmf.Navigo.BusinessObjects.Abstractions.IServiceCollection services = entityFactory.CreateCollection<Cmf.Navigo.BusinessObjects.Abstractions.IServiceCollection>();
                        services.LoadByIDs<Cmf.Navigo.BusinessObjects.Abstractions.IService, Cmf.Navigo.BusinessObjects.Service>(serviceIds);

                        // Load all the resources related with the storage service
                        services.LoadRelations(Navigo.Common.Constants.ResourceService);

                        // Get all the storage resources from the services
                        List<long> resourcesToStoreIds = services.Where(s => !s.ServiceResources.IsNullOrEmpty()).SelectMany(s => s.ServiceResources.Select(sr => sr.GetNativeValue<long>("SourceEntity"))).Distinct().ToList();
                        IResourceCollection resourcesToStore = entityFactory.CreateCollection<IResourceCollection>();
                        resourcesToStore.LoadByIDs<IResource, Resource>(resourcesToStoreIds);

                        // Go through all the material that the configured behavior requires to store (Store and MoveNextAndStore)
                        foreach (var materialMovementBehavior in materialMovementBehaviors.Where(m => m.Value.EventAction.CompareStrings(IKEAConstants.CustomMaterialMovementConfigurationStore)
                                                                                                        || m.Value.EventAction.CompareStrings(IKEAConstants.CustomMaterialMovementConfigurationMoveNextAndStore)))
                        {
                            IMaterial material = materialMovementBehavior.Key;

                            IStep step = steps.First(s => s.Id == material.GetNativeValue<long>(Navigo.Common.Constants.Step));

                            Cmf.Navigo.BusinessObjects.Abstractions.IService service = services.FirstOrDefault(s => s.Id == step.GetNativeValue<long>((material.SystemState == MaterialSystemState.Processed ? IKEAConstants.StepPropertyProcessedStorageService : IKEAConstants.StepPropertyQueuedStorageService)));

                            var serviceResources = service
                                ?.ServiceResources
                                // Ignore Printing Queue resources from all automatic stores
                                ?.Where(resource => resource.SourceEntity.Type != IKEAConstants.ResourceTypePrintingQueue)
                                ?.ToList();

                            // If there is only one storage resource, then the material will be stored, otherwise does nothing
                            if (serviceResources != null
                                && !serviceResources.IsNullOrEmpty()
                                && serviceResources.Count() == 1)
                            {
                                IResource resourceToStore = resourcesToStore.FirstOrDefault(rs => rs.Id == serviceResources[0].GetNativeValue<long>("SourceEntity"));
                                materialStorage.Add(material, resourceToStore);
                            }

                        }
                    }

                    // If there are any material to store, store them
                    if (!materialStorage.IsNullOrEmpty())
                    {
                        // Group all the materials to store by the storage resource so that we can store several material at the same time
                        var groupedMaterialsToStore = materialStorage.GroupBy(m => m.Value.Id);

                        foreach (var groupedMaterial in groupedMaterialsToStore)
                        {
                            // Get the Storage Resource of the material
                            IResource resource = groupedMaterial.ToList()[0].Value;

                            IMaterialCollection materialsToStore = entityFactory.CreateCollection<IMaterialCollection>();
                            materialsToStore.AddRange(groupedMaterial.ToList().Select(m => m.Key));

                            // Store the materials
                            materialsToStore.StoreMaterials(resource);
                        }
                    }
                    #endregion

                    #region Handle EventAction "ChangeFlowStepAndAttach"

                    if (currentContext.MethodName == "MoveToNextStep")
                    {

                        // On a MoveNext, if the EventAction is defined to "ChangeFlowStepAndAttach", the material will be attach to the ResourceToAttach (resolved on material movement)
                        // and moved to the resolved flow path (using CustomMaterialFlowResolution SmartTable)
                        foreach (var materialMovementBehavior in materialMovementBehaviors.Where(m => m.Value.EventAction.CompareStrings(IKEAConstants.CustomMaterialMovementConfigurationChangeFlowStepAndAttach)))
                        {

                            // Get material and movement information
                            IMaterial material = materialMovementBehavior.Key;
                            MaterialMovementBehavior materialMovement = materialMovementBehavior.Value;

                            material.Load();
                            IFacility materialFacility = material.Facility;
                            IProduct materialProduct = material.Product;

                            IResource resourceToAttach = entityFactory.Create<IResource>();
                            resourceToAttach.Name = materialMovement.ResourceToAttach;

                            if (resourceToAttach.Name.IsNullOrEmpty() || !resourceToAttach.ObjectExists())
                            {
                                throw new CmfBaseException(ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomMaterialProcessingHandlerResourceToAttachException, material.Name));
                            }

                            resourceToAttach.Load();

                            // Resolve flow path to attach material
                            Tuple<string, string> materialFlows = genericUtilities.ResolveAllMaterialFlows(materialFacility, materialProduct, resourceToAttach, null, null);

                            // Get Flow Path name, first try with Flow Path input, if it is empty then try with consumption Flow Path, if it can't be resolved then send exception
                            string flowPath = String.Empty;
                            if (materialFlows != null && !materialFlows.Item1.IsNullOrEmpty())
                            {
                                flowPath = materialFlows.Item1;
                            }
                            else if (materialFlows != null && !materialFlows.Item2.IsNullOrEmpty())
                            {
                                flowPath = materialFlows.Item2;
                            }
                            else
                            {
                                throw new CmfBaseException(ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomMaterialProcessingHandlerFlowPathException, material.Name));
                            }

                            // Change flow path and step and attach to feeder
                            IStep step = genericUtilities.GetStepByFlowPath(flowPath);
                            IFlow flow = genericUtilities.GetFlowsInFlowPath(flowPath).FirstOrDefault();

                            material.ChangeFlowAndStep(flow, flowPath, step, new OperationAttributeCollection());
                            ikeaUtilities.ApplyOperationActions(material, resourceToAttach, "Attach");

                        }

                    }

                    #endregion

                }
            }
            
            //---End DEE Code---

            return Input;
        }


    }
}
