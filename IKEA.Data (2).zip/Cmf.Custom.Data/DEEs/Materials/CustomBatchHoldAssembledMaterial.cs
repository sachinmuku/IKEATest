﻿using Cmf.Common.CustomActionUtilities;

using Cmf.Custom.IKEA.BusinessObjects;
using Cmf.Custom.IKEA.BusinessObjects.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.Abstractions;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.Materials
{
    public class CustomBatchHoldAssembledMaterial : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Action to put on hold a material being assembled that belongs to a batch that is on hold with the configured complete hold reason
            /// Action Groups:
            ///     BusinessObjects.Material.Assemble.Post
            ///     BusinessObjects.Material.AutomaticAssemble.Post
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.Material.Assemble.Post",
                "BusinessObjects.Material.AutomaticAssemble.Post",
            };

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            if (executionVeridict
                && IKEADEEActionUtilities.GetInputItem<IMaterial>(Input, "Material") == null
                && IKEADEEActionUtilities.GetInputItem<IAssembleMaterialCollection>(Input, "AssembleMaterialCollection") == null)
            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
     

            //System
            UseReference("", "Cmf.Navigo.BusinessOrchestration.Abstractions");
            UseReference("", "Cmf.Custom.IKEA.BusinessObjects.Abstractions");
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");

            //Navigo
            UseReference("Cmf.Navigo.Common.dll", "Cmf.Navigo.Common");
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement");

            //Custom
            UseReference("Cmf.Custom.IKEA.BusinessObjects.CustomMaterialBatch.dll", "Cmf.Custom.IKEA.BusinessObjects");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            var materialOrchestration = serviceProvider.GetService<IMaterialOrchestration>();
            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IMaterial assembledMaterial = IKEADEEActionUtilities.GetInputItem<IMaterial>(Input, "Material");

            assembledMaterial.LoadRelations(IKEAConstants.CustomMaterialBatchRelation);

            // Check if the material being assembled has any batch associated
            if (assembledMaterial.RelationCollection.ContainsKey(IKEAConstants.CustomMaterialBatchRelation)
                && !assembledMaterial.RelationCollection[IKEAConstants.CustomMaterialBatchRelation].IsNullOrEmpty())
            {
                IMaterialCollection batchMaterials = entityFactory.CreateCollection<IMaterialCollection>();

                batchMaterials.AddRange(assembledMaterial.RelationCollection[IKEAConstants.CustomMaterialBatchRelation].Select(mb => (mb as ICustomMaterialBatch).TargetEntity));

                if (!batchMaterials.IsNullOrEmpty())
                {
                    // Get the configured complete batch hold reason
                    string batchHoldReason = genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.BatchCompleteHoldReason);

                    IReason reason = entityFactory.Create<IReason>();
                    reason.Name = batchHoldReason;


                    // Check if the configured Reason exists
                    if (reason.ObjectExists())
                    {
                        reason.Load();

                        batchMaterials.LoadRelations(Navigo.Common.Constants.MaterialHoldReason);

                        // Check if there is any batch that is on hold with the configured Complete Hold Reason
                        bool holdMaterial = batchMaterials.Where(m => m.RelationCollection!=null && m.RelationCollection.ContainsKey(Navigo.Common.Constants.MaterialHoldReason)
                                                                                    && !m.RelationCollection[Navigo.Common.Constants.MaterialHoldReason].IsNullOrEmpty())
                                                            .Select(m => m.RelationCollection[Navigo.Common.Constants.MaterialHoldReason].Select(b => b as IMaterialHoldReason)
                                                                                                                                        .Where(r => r.GetNativeValue<long>("TargetEntity") == reason.Id)).Any();

                        // If there is a batch with the configured Complete Hold Reason
                        // then a future action will be created to put the material on hold
                        if (holdMaterial)
                        {
                            if (!assembledMaterial.GetMaterialFutureActionsByType(FutureActionType.Hold).Any(ER => ER.Reason.Name == reason.Name))
                            {
                                IFutureAction futureActionToUseOnTrackout = entityFactory.Create<IFutureAction>();

                                futureActionToUseOnTrackout.Material = assembledMaterial;
                                futureActionToUseOnTrackout.Action = FutureActionType.Hold;
                                futureActionToUseOnTrackout.Reason = reason;
                                futureActionToUseOnTrackout.FlowPath = assembledMaterial.FlowPath;
                                futureActionToUseOnTrackout.ExecutionMode = FutureActionExecutionMode.Automatic;
                                futureActionToUseOnTrackout.Source = FutureActionSource.User;
                                futureActionToUseOnTrackout.State = FutureActionState.Processed;
                                futureActionToUseOnTrackout.Step = assembledMaterial.Step;


                                //Apply future action to Pallets generated by the MO
                                var fc = entityFactory.CreateCollection<IFutureActionCollection>();
                                fc.Add(futureActionToUseOnTrackout);
                                materialOrchestration.ManageFutureActions(
                                    new ManageFutureActionsInput()
                                    {
                                        AddedUpdatedFutureActions = fc
                                    });
                            }
                        }
                    }
                }
            }

            

            //---End DEE Code---

            return Input;
        }
    }
}
