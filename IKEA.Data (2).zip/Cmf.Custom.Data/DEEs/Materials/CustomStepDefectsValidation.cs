﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Exceptions;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.Materials
{
    public class CustomStepDefectsValidation : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///    Before allowing the material to go to the next step, the DEE will check if the smart table has any configuration 
            ///    that indicates if the material should be validated before going to the next step.
            ///    If it does, then the Material has to pass the following validations before going to the next step:
            ///    1. Material need to have Secondary quantity bigger than 0
            ///    2. The Material Secondary Quantity Units needs to be the same as the one configured in the Config / Cmf / Custom / ScrapManagement / RejectUnit /
            ///    3. Material Primary Quantity needs to be 0
            /// Action Groups:
            ///     MaterialManagement.MaterialManagementOrchestration.ComplexMoveMaterialsToNextStep.Pre
            ///     MaterialManagement.MaterialManagementOrchestration.ChangeMaterialFlowAndStep.Pre
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "MaterialManagement.MaterialManagementOrchestration.ComplexMoveMaterialsToNextStep.Pre",
                "MaterialManagement.MaterialManagementOrchestration.ChangeMaterialFlowAndStep.Pre"
            };

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            if (executionVeridict &&
                IKEADEEActionUtilities.GetInputItem<ComplexMoveMaterialsToNextStepInput>(Input, "ComplexMoveMaterialsToNextStepInput") == null &&
                IKEADEEActionUtilities.GetInputItem<ChangeMaterialFlowAndStepInput>(Input, "ChangeMaterialFlowAndStepInput") == null)
            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---  
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Exceptions");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
            //System
            UseReference("", "System");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("", "System.Linq");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            
            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();



            DeeContext currentContext = deeContextUtilities.SetCurrentServiceContext("CustomStepDefectsValidation");

            // Get the default reject unit
            string rejectUnit = genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.ScrapManagementRejectUnit);

            IMaterialCollection materials = entityFactory.CreateCollection<IMaterialCollection>();

            switch (currentContext.MethodName)
            {
                // MaterialManagementOrchestration.ComplexMoveMaterialsToNextStep.Pre
                case "ComplexMoveMaterialsToNextStep":
                    {
                        ComplexMoveMaterialsToNextStepInput input = IKEADEEActionUtilities.GetInputItem<ComplexMoveMaterialsToNextStepInput>(Input, "ComplexMoveMaterialsToNextStepInput");
                        if (!input.Materials.IsNullOrEmpty())
                        {
                            //Gather Materials 
                            materials.AddRange(input.Materials.Keys);
                        }
                        break;
                    }
                // MaterialManagementOrchestration.ChangeMaterialFlowAndStep.Pre
                case "ChangeMaterialFlowAndStep":
                    {
                        ChangeMaterialFlowAndStepInput input = IKEADEEActionUtilities.GetInputItem<ChangeMaterialFlowAndStepInput>(Input, "ChangeMaterialFlowAndStepInput");
                        if (input.Material != null)
                        {
                            //Gather Materials 
                            materials.Add(input.Material);
                        }
                        break;
                    }
            }


            foreach (IMaterial material in materials)
            {

                IFacility facility = material.Facility;
                string stepType = null;
                IArea area = null;
                IStep step = material.Step;

                if (step != null)
                {
                    // Get StepType:
                    stepType = step.Type;

                    // Get Area:
                    material.Step.LoadRelations("StepArea");
                    long facilityId = material.GetNativeValue<long>("Facility");
                    IStepArea stepArea = step.RelationCollection["StepArea"].FirstOrDefault(r => facilityId == (r as IStepArea).TargetEntity.GetNativeValue<long>("Facility")) as IStepArea;
                    if (stepArea != null)
                    {
                        area = stepArea.TargetEntity;
                    }
                }
                // Check if the material needs to be classified before moving to the next step:
                bool SmartTableReturnValue = ikeaUtilities.ResolveCustomStepDefectsValidation(facility: facility,
                                                                                              area: area,
                                                                                              stepType: stepType,
                                                                                              resource: material.LastProcessedResource,
                                                                                              step: step,
                                                                                              materialType: material.Type
                                                                                              );
                if (SmartTableReturnValue == true)
                {
                    //Material Primary Quantity needs to be 0
                    //Material need to have Secondary quantity bigger than 0
                    //The Material Secondary Quantity Units needs to be the same as the one configured in the Config /Cmf/Custom/ScrapManagement/RejectUnit/
                    if (!(material.PrimaryQuantity == 0 && material.SecondaryQuantity > 0 && material.SecondaryUnits.CompareStrings(rejectUnit)))
                    {
                       throw new IKEAException(IKEAConstants.CustomStepDefectsValidationLocalizedMessage, material.Name, material.Step.Name);
                    }
                }
            }

            //---End DEE Code---

            return Input;
        }

    }
}
