﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Exceptions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.Materials
{
    public class CustomMaterialAssembleRework : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Automatically set the rework counter of the material being assembled with the
            ///     max rework counter of the materials being consumed
            /// Action Groups:
            ///     BusinessObjects.Material.Assemble.Post
            ///     BusinessObjects.Material.AutomaticAssemble.Post
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion


            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.Material.Assemble.Pre",
                "BusinessObjects.Material.Assemble.Post",
                "BusinessObjects.Material.AutomaticAssemble.Pre",
                "BusinessObjects.Material.AutomaticAssemble.Post",
            };

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);
            if (executionVeridict && Input == null)
            {
                executionVeridict = false;
            }
            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Exceptions");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
            //System
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.IO");
            UseReference("", "System.Threading");
            UseReference("", "System");

            //Foundation
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            IWMSUtilities wmsUtilities = serviceProvider.GetService<IWMSUtilities>();

            DeeContext currentContext = deeContextUtilities.SetCurrentServiceContext("CustomMaterialAssembleRework");

            IMaterial material;
            IAssembleMaterialCollection assembleMaterials;
            Dictionary<string, string> materialFeeders;
            IMaterialCollection materials = entityFactory.CreateCollection<IMaterialCollection>();

            string palletTypeContext = deeContextUtilities.GetContextParameter(IKEAConstants.CustomUnitCompletePalletTypeContextKey) as string;

            if ((currentContext.MethodName == "Assemble" || currentContext.MethodName == "AutomaticAssemble" || currentContext.MethodName == "InternalAutomaticAssemble")
                && Input.ContainsKey("Material"))
            {
                material = Input["Material"] as IMaterial;

                // We must grab the relation between each material and in which feeder it is in Pre, because after assemble,
                // in Post, those relations are already gone
                if (currentContext.TriggerPoint == DeeTriggerPoint.Pre)
                {
                    // Load the resource where the material is currently in
                    material.LoadRelations(Navigo.Common.Constants.MaterialResource, 1);

                    IResource resource = material.MaterialResourceRelations
                        // The ProcessingType of a Main Line must be Process
                        ?.Where(targetEntity => targetEntity.TargetEntity.ProcessingType == ProcessingType.Process)
                        ?.FirstOrDefault()
                        ?.TargetEntity;

                    if (resource != null)
                    {
                        IResourceCollection feeders = wmsUtilities.GetMainLineFeeders(resource);
                        
                        materialFeeders = ikeaUtilities.GetMaterialsInConsumableFeeds(feeders);
                    } 
                    else
                    {
                        materialFeeders = new Dictionary<string, string>();
                    }

                    deeContextUtilities.SetContextParameter(IKEAConstants.CustomMaterialAssembleReworkMaterialFeedersRelationContextKey, materialFeeders);
                }
                else
                {
                    materialFeeders = deeContextUtilities.GetContextParameter(IKEAConstants.CustomMaterialAssembleReworkMaterialFeedersRelationContextKey) as Dictionary<string, string>;

                    if (currentContext.MethodName == "Assemble" && Input.ContainsKey("AssembleMaterialCollection"))
                    {
                        assembleMaterials = Input["AssembleMaterialCollection"] as IAssembleMaterialCollection;

                        if (!assembleMaterials.IsNullOrEmpty())
                        {
                            materials = entityFactory.CreateCollection<IMaterialCollection>();
                            materials.AddRange(assembleMaterials.Select(am => am.Material));
                        }
                    }
                    else if ((currentContext.MethodName == "AutomaticAssemble" || currentContext.MethodName == "InternalAutomaticAssemble") && Input.ContainsKey("ConsumedMaterials"))
                    {
                        materials.AddRange(Input["ConsumedMaterials"] as List<IMaterial>);
                    }

                    if (!materials.IsNullOrEmpty())
                    {
                        IAttributeCollection attributes = new AttributeCollection();

                        materials.LoadAttributes(new Collection<string>() { IKEAConstants.CustomMaterialAttributeReworkCounter,
                                                                            IKEAConstants.CustomMaterialAttributeCreationArea,
                                                                            IKEAConstants.CustomMaterialAttributeCurrentIteration });


                        // Get only materials that match the same Area that the main material:
                        var areaMaterials = materials.Where(m => m.GetAttributeValueOrDefault<string>(IKEAConstants.CustomMaterialAttributeCreationArea).CompareStrings(material.LastProcessedResource.Area.Name)).ToList();


                        #region Rework Counter

                        //Get maximum rework from materials reworked on the current Area only
                        int maxReworkCounter = !areaMaterials.IsNullOrEmpty() ? areaMaterials.Max(m => m.GetAttributeValueOrDefault<int>(IKEAConstants.CustomMaterialAttributeReworkCounter)) : 0;

                        if (maxReworkCounter > material.GetAttributeValueOrDefault<int>(IKEAConstants.CustomMaterialAttributeReworkCounter))
                        {
                            attributes.Add(IKEAConstants.CustomMaterialAttributeReworkCounter, maxReworkCounter);
                        }
                        #endregion

                        #region Iteration Counter

                        // Group the materials by feeder and validate that for each feeder, the current iterations of the
                        // assembled materials are all the same (used to prevent AllowProductMix to mix different material iterations)
                        if (!areaMaterials.IsNullOrEmpty())
                        {
                            Dictionary<string, List<IMaterial>> areaMaterialsByFeeder = 
                                ikeaUtilities.GroupMaterialsByConsumableFeed(areaMaterials, materialFeeders);
                    
                            foreach (var group in areaMaterialsByFeeder)
                            {
                                // Destructure the key-value pair
                                var feederMaterials = group.Value;
                                var feederName = group.Key;

                                if (feederMaterials.Count > 1)
                                {
                                    // Since we just want to check that all iterations are the same in this feeder
                                    // we can grab the iteration value from any material
                                    var feederIteration = feederMaterials.First()
                                        .GetAttributeValueOrDefault<int>(IKEAConstants.CustomMaterialAttributeCurrentIteration);

                                    // Validate the current iteration of all the assembled materials for this feeder is the same
                                    if (feederMaterials.Any(m =>
                                        (m.GetAttributeValueOrDefault<int>(IKEAConstants.CustomMaterialAttributeCurrentIteration) != feederIteration)
                                        && (m.Type == IKEAConstants.MaterialTypeDirectRepair || m.Type == IKEAConstants.MaterialTypeReRun)
                                        ))
                                    {
                                        throw new IKEAException(IKEAConstants.CustomCustomAssembleIterationsDifferentMessageLocalizedMessage,
                                            // Pallet Name
                                            material.Name, 
                                            // Feeder Name
                                            feederName, 
                                            // Feeder Consumable Names
                                            string.Join(", ", feederMaterials.Select(mat => mat.Name)), 
                                            // Feeder Consumable Iterations
                                            string.Join(", ", feederMaterials.Select(mat => mat.GetAttributeValueOrDefault<int>(IKEAConstants.CustomMaterialAttributeCurrentIteration))) 
                                        );
                                    }
                                }
                            }
                        }

                        // Gets current iteration from the material (in theory, only one material should exist, but we get the highest value from all):
                        int currentIteration = !areaMaterials.IsNullOrEmpty() ? areaMaterials.Max(m => m.GetAttributeValueOrDefault<int>(IKEAConstants.CustomMaterialAttributeCurrentIteration)) : 0;

                        // If material is NOT of type DirectRepair, increment iteration:
                        string directRepairMaterialType = genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.CustomDirectRepairMaterialDefaultTypePath);
                        string materialType = palletTypeContext != null ? palletTypeContext : material.Type;
                        if (!materialType.Equals(directRepairMaterialType, System.StringComparison.InvariantCultureIgnoreCase))
                        {
                            currentIteration++;
                        }

                        // Add the current iteration attribute:
                        attributes.Add(IKEAConstants.CustomMaterialAttributeCurrentIteration, currentIteration);
                        #endregion

                        // Saves material attributes (ReworkCounter and CurrentIteration): 
                        if (!attributes.IsNullOrEmpty())
                        {
                            material.SaveAttributes(attributes);
                        }
                    }
                }

            }
     
            //---End DEE Code---

            return Input;
        }

    }
}
