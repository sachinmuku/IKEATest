﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.BusinessObjects;
using Cmf.Custom.IKEA.BusinessObjects.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Exceptions;
using Cmf.Custom.IKEA.Common.Extensions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.Materials
{
    public class CustomMaterialOrderRunHandler : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     DEE to handle the MO runs and schedule quantities
            /// Action Groups:
            ///     MaterialManagement.MaterialManagementOrchestration.ComplexTrackInMaterials.Post
            ///     BusinessObjects.MaterialCollection.AbortProcess.Post
            ///     BusinessObjects.MaterialCollection.TrackIn.Post
            ///     BusinessObjects.MaterialCollection.ChangeQuantity.Pre
            ///     BusinessObjects.MaterialCollection.TrackOut.Post
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "MaterialManagement.MaterialManagementOrchestration.ComplexTrackInMaterials.Post",
                "BusinessObjects.MaterialCollection.AbortProcess.Post",
                "BusinessObjects.MaterialCollection.TrackIn.Post",
                "BusinessObjects.MaterialCollection.ChangeQuantity.Pre",
                "BusinessObjects.MaterialCollection.TrackOut.Post"
            };

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            if (executionVeridict
                && IKEADEEActionUtilities.GetInputItem<IMaterialCollection>(Input, "MaterialCollection") == null
                && IKEADEEActionUtilities.GetInputItem<ComplexTrackInMaterialsInput>(Input, "ComplexTrackInMaterialsInput") == null
                && IKEADEEActionUtilities.GetInputItem<IMaterialQuantityChangeCollection>(Input, "MaterialQuantityChangeCollection") == null)
            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Exceptions");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
            //System
            UseReference("", "Cmf.Custom.IKEA.BusinessObjects.Abstractions");
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("", "System");

            //Foundation
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");

            //Navigo
            UseReference("Cmf.Navigo.Common.dll", "Cmf.Navigo.Common");
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            //Custom
            UseReference("Cmf.Custom.IKEA.BusinessObjects.CustomERPOperationTracking.dll", "Cmf.Custom.IKEA.BusinessObjects");
            UseReference("Cmf.Custom.IKEA.BusinessObjects.CustomPOERPOperationTracking.dll", "Cmf.Custom.IKEA.BusinessObjects");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Extensions");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();

            DeeContext currentContext = deeContextUtilities.SetCurrentServiceContext("CustomMaterialOrderRunHandler");

            string orderForm = ikeaUtilities.GetOrderMaterialForm();
            IMaterialCollection materials = IKEADEEActionUtilities.GetInputItem<IMaterialCollection>(Input, "MaterialCollection");

            if (materials == null)
            {
                materials = IKEADEEActionUtilities.GetInputItem<ComplexTrackInMaterialsInput>(Input, "ComplexTrackInMaterialsInput").Materials;
            }

            switch (currentContext.MethodName)
            {
                // The Current Recipe Instance is only associated with the material during the "ComplexTrackInMaterials", and after the
                // "MaterialCollection.TrackIn" method has executed, hence why we need to add this action group as well.
                case "ComplexTrackInMaterials":
                    {
                        // Update attributes 'UnitLoadPalletType'
                        foreach (IMaterial material in materials)
                        {
                            IAttributeCollection attributes = new AttributeCollection();

                            // Only for materials with Order form, handles the number of iterations and DirectRepair mode:
                            if (material.Form.CompareStrings(orderForm) && material.GetNativeValue<long>("CurrentRecipeInstance") > 0)
                            {
                                if (material.CurrentRecipeInstance.HasRelations(Cmf.Navigo.Common.Constants.RecipeInstanceParameter))
                                {
                                    IRecipeInstanceParameterCollection recipeInstanceParameters = entityFactory.CreateCollection<IRecipeInstanceParameterCollection>();
                                    recipeInstanceParameters.AddRange(
                                        material.CurrentRecipeInstance
                                            .RelationCollection[Cmf.Navigo.Common.Constants.RecipeInstanceParameter]
                                            .OfType<IRecipeInstanceParameter>()
                                    );

                                    string palletTypeParameterName = genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.PalletTypeRecipeParameterName);

                                    IRecipeInstanceParameter recipeInstanceParameter = recipeInstanceParameters.FirstOrDefault(parameter => parameter.TargetEntity.Name == palletTypeParameterName);

                                    string palletType = recipeInstanceParameter?.Value?.ToString();

                                    if (!string.IsNullOrEmpty(palletType))
                                    {
                                        attributes.Add(IKEAConstants.CustomMaterialAttributeUnitLoadPalletType, palletType);
                                    }
                                }
                            }

                            material.SaveAttributes(attributes);
                        }
                    }
                    break;
                case "TrackIn":
                    {

                        IAttributeCollection attributesToRemove = new AttributeCollection()
                        {
                                { IKEAConstants.CustomMaterialAttributeCurrentKnownOutsortedQuantity, null },
                                { IKEAConstants.CustomMaterialAttributeCurrentProcessedOutsortedQuantity, null },
                                { IKEAConstants.CustomMaterialAttributeCompletedQuantity, null },
                                { IKEAConstants.CustomMaterialAttributeCompletedOutsortedQuantity, null },
                                { IKEAConstants.CustomMaterialAttributeResourceLossPiecesClassified, false },
                                { IKEAConstants.CustomMaterialAttributeInCompletion, false},
                                { IKEAConstants.CustomMaterialAttributeForceOrderCompletionAllowed, null },
                                { IKEAConstants.CustomMaterialAttributeOrderTargetQuantity, 0 },
                                { IKEAConstants.CustomMaterialAttributeManualCompletionInProgress, false },
                                { IKEAConstants.CustomMaterialAttributeUnitLoadPalletType, null }
                        };

                        // Remove the attributes from the materials
                        materials.RemoveAttributes(attributesToRemove);

                        CustomERPOperationTrackingEngine.HandleMaterialTrackIn(materials);

                        // Get the actual resource:
                        IResource resource = IKEADEEActionUtilities.GetInputItem<IResource>(Input, "Resource");

                        // Resolve the DirectRepair mode:
                        Tuple<bool, IStep> result = ikeaUtilities.ResolveCustomDirectRepairResolution(facilityToResolve: resource.Area.Facility,
                                                                                                     areaToResolve: resource.Area,
                                                                                                     resourceToResolve: resource);

                        materials.LoadAttributes(new Collection<string>
                        {
                            IKEAConstants.CustomMaterialAttributeIsGroupMO,
                        });

                        // Update attributes 'DirectRepairInLine', 'MaxIterations' and 'OriginalQuantity'
                        foreach (IMaterial material in materials)
                        {
                            IAttributeCollection attributes = new AttributeCollection();

                            // Set the attribute 'OriginalQuantity' with the primary quantity:
                            attributes.Add(IKEAConstants.CustomMaterialAttributeOriginalQuantity, material.PrimaryQuantity);

                            // Only for materials with Order form, handles the number of iterations and DirectRepair mode:
                            if (material.Form.CompareStrings(orderForm))
                            {

                                //Resolve smart table for MaxIterations:
                                Tuple<decimal, IStep> resultIterations = ikeaUtilities.ResolveCustomProductIterationHandler(facilityToResolve: resource.Area.Facility,
                                                                                                                           areaToResolve: resource.Area,
                                                                                                                           resourceToResolve: resource,
                                                                                                                           productGroupToResolve: null,
                                                                                                                           productToResolve: material.Product);
                                // Set the attribute 'IsInLineDirectRepair'
                                if (result != null)
                                {
                                    attributes.Add(IKEAConstants.CustomMaterialAttributeIsInLineDirectRepair, result.Item1);
                                }
                                // Set the attribute 'MaxIterations'
                                if (resultIterations != null)
                                {
                                    attributes.Add(IKEAConstants.CustomMaterialAttributeMaxIterations, resultIterations.Item1);
                                }

                                // Get the main line InFeeder
                                string mainLineInfeeder = resource.GetAttributeValueOrDefault<string>(IKEAConstants.MESAutomationInFeederSubResourceController, true);

                                decimal consumptionPerUnitProduced = 1;

                                // Check if there is any InFeeder configured for the main line
                                if (!string.IsNullOrWhiteSpace(mainLineInfeeder))
                                {
                                    IResource inFeeder = entityFactory.Create<IResource>();

                                    inFeeder.Name = mainLineInfeeder;

                                    inFeeder.Load();
                                    inFeeder.LoadAttributes(new Collection<string>() { IKEAConstants.ProcessSegmentSequence, IKEAConstants.SubProcessSegmentName });

                                    string processSegment = inFeeder.GetAttributeValueOrDefault<string>(IKEAConstants.ProcessSegmentSequence);
                                    string subProcessSegment = inFeeder.GetAttributeValueOrDefault<string>(IKEAConstants.SubProcessSegmentName);

                                    // Check if the InFeeder process segment is defined
                                    if (!string.IsNullOrWhiteSpace(processSegment) && !material.IsGroupMO(loadAttributes: false))
                                    {
                                        IBOM currentBOM = material.CurrentBOMVersion;

                                        if (currentBOM == null)
                                        {
                                            throw new IKEAException(IKEAConstants.CustomTrackInAutomationMaterialHasNoBomMessage);
                                        }

                                        currentBOM.LoadRelations(Navigo.Common.Constants.BOMProduct);

                                        // Check if it was able to load the BOM Products
                                        if (!currentBOM.BomProducts.IsNullOrEmpty())
                                        {
                                            currentBOM.BomProducts.LoadAttributes(new Collection<string>() { IKEAConstants.BomProductProcessSegmentAttribute, IKEAConstants.BomProductSubProcessSegmentAttribute });

                                            // Get the BOM Product that matches the InFeeder
                                            IBOMProduct inFeederBOMProduct = currentBOM.BomProducts.FirstOrDefault(BP => BP.GetAttributeValueOrDefault<string>(IKEAConstants.BomProductProcessSegmentAttribute).CompareStrings(processSegment)
                                                                                                                        && BP.GetAttributeValueOrDefault<string>(IKEAConstants.BomProductSubProcessSegmentAttribute).CompareStrings(subProcessSegment));

                                            // If the BOM Product was found, set the consumption per unit produced to the quantity in the BOM Product
                                            if (inFeederBOMProduct != null)
                                            {
                                                // Grab the dimentions configuration for both the order and the bom product.
                                                List<UnitDimensionsStructure> dimensionsConfiguration = ikeaUtilities.GetUnitDimensions(new string[]
                                                {
                                                    material.PrimaryUnits,
                                                    inFeederBOMProduct.Units
                                                });

                                                // Only set this value if both units are Dimensionless, meaning we will not
                                                // need to calculate the conversion factor for the units of measurement
                                                if (dimensionsConfiguration.All(config => config.Dimensionless))
                                                {
                                                    consumptionPerUnitProduced = inFeederBOMProduct.Quantity.GetValueOrDefault();
                                                }
                                            }
                                        }
                                    }
                                }

                                attributes.Add(IKEAConstants.CustomMaterialAttributeConsumptionPerUnitProduced, consumptionPerUnitProduced);
                            }

                            // Saves all attributes:
                            if (!attributes.IsNullOrEmpty())
                            {
                                material.SaveAttributes(attributes);
                            }
                        }
                        break;
                    }
                case "TrackOut":
                    {

                        IMaterialCollection terminatedMaterials = entityFactory.CreateCollection<IMaterialCollection>();
                        terminatedMaterials.AddRange(materials.Where(m => m.Form.CompareStrings(orderForm)));

                        // Check if there are any Order Materials being terminated
                        if (!terminatedMaterials.IsNullOrEmpty())
                        {
                            CustomERPOperationTrackingEngine.HandleAbortMaterial(materials);
                        }

                        break;
                    }
                case "AbortProcess":
                    {
                        IAttributeCollection attributesToRemove = new AttributeCollection()
                        {
                                { IKEAConstants.CustomMaterialAttributeManualCompletionInProgress, false }
                        };

                        // Remove the attributes from the materials
                        materials.RemoveAttributes(attributesToRemove);

                        CustomERPOperationTrackingEngine.HandleAbortMaterial(materials);

                        break;
                    }
                case "ChangeQuantity":
                    {
                        IMaterialQuantityChangeCollection materialQuantities = IKEADEEActionUtilities.GetInputItem<IMaterialQuantityChangeCollection>(Input, "MaterialQuantityChangeCollection");

                        bool? resetMOQuantity = deeContextUtilities.GetContextParameter(IKEAConstants.CustomUnitCompleteDoNotUpdateScheduledQuantityContextKey) as bool?;

                        // We should only update the scheduled quantity when not reseting the MO quantity
                        if (!resetMOQuantity.HasValue || !resetMOQuantity.GetValueOrDefault())
                        {
                            foreach (IMaterialQuantityChange materialQuantity in materialQuantities.Where(m => m.Material.Form.CompareStrings(orderForm)))
                            {
                                IMaterial material = materialQuantity.Material;

                                ICustomERPOperationTrackingCollection operationTrackings = material.GetAllCustomERPOperationTrackingFromMOByRun(true);

                                if (!operationTrackings.IsNullOrEmpty())
                                {
                                    // Calculate the delta quantity to update the scheduled quantity
                                    decimal deltaQuantity = materialQuantity.NewPrimaryQuantity.Value - material.PrimaryQuantity.Value;

                                    foreach (ICustomERPOperationTracking operationTracking in operationTrackings)
                                    {
                                        if (operationTracking.OrderOperationEnd.HasValue)   // if order is complete
                                        {
                                            if (material.SystemState == MaterialSystemState.InProcess)   // create a new ERPOperationTracking
                                            {
                                                var handleMaterialCollection = entityFactory.CreateCollection<IMaterialCollection>();
                                                handleMaterialCollection.Add(material);
                                                CustomERPOperationTrackingEngine.HandleMaterialTrackIn(handleMaterialCollection, materialQuantity.NewPrimaryQuantity.Value);
                                            }
                                        }   // if order is not complete 
                                        else
                                        {
                                            operationTracking.UpdateScheduledQuantity(deltaQuantity, material.Form.CompareStrings(orderForm));
                                        }
                                    }
                                }
                            }
                        }

                        break;
                    }
                default:
                    break;
            }

            //---End DEE Code---

            return Input;
        }


    }
}
