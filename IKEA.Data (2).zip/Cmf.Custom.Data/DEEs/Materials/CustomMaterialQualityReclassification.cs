﻿using Cmf.Common.CustomActionUtilities;

using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.Materials
{
    public class CustomMaterialQualityReclassification : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Reports the pallet creation to ERP if the pallet changes from a not reported type to a reported type
            /// Action Groups:
            ///     BusinessObjects.MaterialCollection.ChangeType.Pre
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.MaterialCollection.ChangeType.Pre"
            };

            bool executionVeridict = IKEADEEActionUtilities.GetInputItem<Dictionary<IMaterial, string>>(Input, "MaterialTypes") != null && IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            //System
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("", "System");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            IERPUtilities erpUtilities = serviceProvider.GetService<IERPUtilities>();

            Dictionary<IMaterial, string> materialTypes = IKEADEEActionUtilities.GetInputItem<Dictionary<IMaterial, string>>(Input, "MaterialTypes");

            // Get the material types that are allowed to be reported to the ERP upon pallet creation
            List<string> reportableTypes = TableHelper.GetLookupTableValues(IKEAConstants.CustomERPReportableTypes);

            IMaterialCollection materialsToReport = entityFactory.CreateCollection<IMaterialCollection>();
            // Get All the materials that the current type is not marked as to be reported to ERP but the new type is
            materialsToReport.AddRange(materialTypes.Where(m => !reportableTypes.Contains(m.Key.Type) && reportableTypes.Contains(m.Value)).Select(m => m.Key));

            // If there are any materials to report, then report them
            if (!materialsToReport.IsNullOrEmpty())
            {
                erpUtilities.ReportUnitComplete(materialsToReport, false);
            }

            //---End DEE Code---

            return Input;
        }
    }
}
