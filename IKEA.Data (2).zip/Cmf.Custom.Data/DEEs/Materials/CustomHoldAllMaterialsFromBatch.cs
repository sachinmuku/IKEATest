﻿using Cmf.Common.CustomActionUtilities;

using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.Materials
{
    public class CustomHoldAllMaterialsFromBatch : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text:
            ///     Action that will put on hold all materials of a batch that is on hold with the configured Complete Hold Reason
            /// Action Groups:
            ///     BusinessObjects.MaterialCollection.Hold.Post
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.MaterialCollection.Hold.Post"
            };

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            if (executionVeridict 
                && IKEADEEActionUtilities.GetInputItem<IMaterialCollection>(Input, "MaterialCollection") == null
                && IKEADEEActionUtilities.GetInputItem<IMaterialHoldReasonCollection>(Input, "MaterialHoldReasonCollection") == null)
            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
     

            //System
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");

            //Foundation
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();

            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            IMaterialCollection materials = IKEADEEActionUtilities.GetInputItem<IMaterialCollection>(Input, "MaterialCollection");
            IMaterialHoldReasonCollection materialHoldReasons = IKEADEEActionUtilities.GetInputItem<IMaterialHoldReasonCollection>(Input, "MaterialHoldReasonCollection");

            // Check if the list contains materials
            if (!materials.IsNullOrEmpty())
            {
                // Get Configured Batch Form
                string batchForm = genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.BatchMaterialForm);

                // Get the Ids of all the batch materials
                List<long> batchIds = new List<long>(materials.Where(m => m.Form == batchForm).Select(m => m.Id));

                // Check if there are any batch materials to hold
                if (!batchIds.IsNullOrEmpty())
                {
                    // Get the configured complete batch hold reason
                    string batchHoldReason = genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.BatchCompleteHoldReason);

                    IReason reason = entityFactory.Create<IReason>();

                    reason.Name = batchHoldReason;
                    

                    // Check if the configured reason exists
                    if (reason.ObjectExists())
                    {
                        IMaterialCollection batches = entityFactory.CreateCollection<IMaterialCollection>();

                        reason.Load();

                        // Get a collection of batch materials that contains the configured reason
                        batches.AddRange(materialHoldReasons.Where(mh => batchIds.Contains(mh.GetNativeValue<long>("SourceEntity")) 
                                                                        && mh.GetNativeValue<long>("TargetEntity") == reason.Id)
                                                            .Select(mh => mh.SourceEntity));

                        foreach (IMaterial batch in batches)
                        {
                            // Hold all the related materials of a batch
                            ikeaUtilities.HoldRelatedMaterials(batch, reason, true);
                        } 
                    }
                }
            }

            

            //---End DEE Code---

            return Input;
        }
    }
}
