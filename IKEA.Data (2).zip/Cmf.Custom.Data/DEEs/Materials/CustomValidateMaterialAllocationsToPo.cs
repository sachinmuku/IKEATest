﻿using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using Cmf.Custom.IKEA.BusinessObjects;
using Cmf.Custom.IKEA.Common;
using Cmf.Foundation.BusinessObjects;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Custom.IKEA.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Common.CustomActionUtilities;
using Cmf.Foundation.Common.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Exceptions;


namespace Cmf.Custom.IKEA.Actions.Materials
{
    public class CustomValidateMaterialAllocationsToPo : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     
            /// Action Groups:
            ///         BusinessObjects.ProductionOrderCollection.AddRelations.Post
            ///         BusinessObjects.ProductionOrder.AddRelations.Post
            ///         BusinessObjects.MaterialCollection.AddRelations.Post
            ///         BusinessObjects.Material.AddRelations.Post
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.ProductionOrderCollection.AddRelations.Post",
                "BusinessObjects.ProductionOrder.AddRelations.Post",
                "BusinessObjects.MaterialCollection.AddRelations.Post",
                "BusinessObjects.Material.AddRelations.Post"
            };

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            if (executionVeridict && IKEADEEActionUtilities.GetInputItem<Dictionary<IEntityInstance, ICmfEntityRelationCollection>>(Input, "Relations") == null
                                  && IKEADEEActionUtilities.GetInputItem<ICmfEntityRelationCollection>(Input, "Relations") == null
                                  && IKEADEEActionUtilities.GetInputItem<IEntityRelationCollection<IEntityRelation>>(Input, "Relations") == null)
            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Exceptions");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            //System
            UseReference("", "Cmf.Custom.IKEA.BusinessObjects.Abstractions");
            UseReference("", "System");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("", "System.Linq");
            //Custom
            UseReference("Cmf.Custom.IKEA.BusinessObjects.MaterialPOAllocation.dll", "Cmf.Custom.IKEA.BusinessObjects");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            //Foundation
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            IMaterialPOAllocationCollection relations = entityFactory.CreateCollection<IMaterialPOAllocationCollection>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();

            if (Input["Relations"] is Dictionary<IEntityInstance, ICmfEntityRelationCollection>)
            {
                Dictionary<IEntityInstance, ICmfEntityRelationCollection> dictionary = Input["Relations"] as Dictionary<IEntityInstance, ICmfEntityRelationCollection>;

                foreach (var relation in dictionary)
                {
                    if (relation.Value.ContainsKey("MaterialPOAllocation"))
                    {
                        relations.AddRange(relation.Value["MaterialPOAllocation"].Cast<IMaterialPOAllocation>());
                    }

                }
            }
            else if (Input["Relations"] is ICmfEntityRelationCollection)
            {
                ICmfEntityRelationCollection keyValuePairs = Input["Relations"] as ICmfEntityRelationCollection;

                if (keyValuePairs.ContainsKey("MaterialPOAllocation"))
                {
                    relations.AddRange(keyValuePairs["MaterialPOAllocation"].Cast<IMaterialPOAllocation>());
                }
            }
            else if (Input["Relations"] is IEntityRelationCollection<IEntityRelation>)
            {
                var t = Input["Relations"] as IEntityRelationCollection<IEntityRelation>;

                relations.AddRange(t.Where(x => x is IMaterialPOAllocation).Select(x => x as IMaterialPOAllocation));
            }

            if (relations.Count() > 0)
            {
                IMaterialCollection materials = ikeaUtilities.ValidateMaterialAllocations(relations);

                if (!materials.IsNullOrEmpty())
                {
                    string materialNameList = string.Join(", ", materials.Select(x => x.Name).Distinct().ToArray());

                   throw new IKEAException(IKEAConstants.CustomValidateMaterialAllocationsMessage, materialNameList);
                }
            }

            //---End DEE Code---

            return Input;
        }


    }
}
