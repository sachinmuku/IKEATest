﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;

using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Exceptions;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.Abstractions;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.Materials
{
    class CustomHandleGroupMOTrackIn : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text:
            ///     Action to TrackIn all the child materials of a Group MO
            /// Action Groups:
            ///     MaterialManagement.MaterialManagementOrchestration.ComplexTrackInMaterials.Pre
            ///     MaterialManagement.MaterialManagementOrchestration.ComplexTrackInMaterials.Post
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "MaterialManagement.MaterialManagementOrchestration.ComplexTrackInMaterials.Pre",
                "MaterialManagement.MaterialManagementOrchestration.ComplexTrackInMaterials.Post"
            };

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            if (executionVeridict && IKEADEEActionUtilities.GetInputItem<ComplexTrackInMaterialsInput>(Input, "ComplexTrackInMaterialsInput") == null)
            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Exceptions");
UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
     

            //System
            UseReference("", "Cmf.Navigo.BusinessOrchestration.Abstractions");
UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("", "System.Linq");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            var materialOrchestration = serviceProvider.GetService<IMaterialOrchestration>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();
            // Set context:
            DeeContext currentContext = deeContextUtilities.SetCurrentServiceContext("CustomMaterialHandleTrackInParameters");


            if (currentContext.TriggerPoint == DeeTriggerPoint.Pre)
            {
                ComplexTrackInMaterialsInput trackInMaterialsInput = IKEADEEActionUtilities.GetInputItem<ComplexTrackInMaterialsInput>(Input, "ComplexTrackInMaterialsInput");

                if (!trackInMaterialsInput.Materials.IsNullOrEmpty())
                {

                    // Collect materials
                    IMaterialCollection materials = trackInMaterialsInput.Materials;

                    // Load the attribute to identify if the materials being TrackedIn are group MOs>
                    materials.LoadAttributes(new Collection<string> { 
                        IKEAConstants.CustomMaterialAttributeIsGroupMO,
                        IKEAConstants.CustomMaterialAttributeGroupOrderState
                    });

                    // Materials from the Group MO that should be Tracked In in Post:
                    IMaterialCollection childMaterialsToTrackIn = entityFactory.CreateCollection<IMaterialCollection>();

                    // if there are group MOs being tracked in:
                    if (materials.Where(x => x.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomMaterialAttributeIsGroupMO)).Any())
                    {

                        IMaterialCollection materialGroupMOs = entityFactory.CreateCollection<IMaterialCollection>();
                        materialGroupMOs.AddRange(materials.Where(x => x.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomMaterialAttributeIsGroupMO)));

                        foreach (IMaterial materialGroupMO in materialGroupMOs)
                        {
                            var groupOrderState = materialGroupMO.GetAttributeValueOrDefault(IKEAConstants.CustomMaterialAttributeGroupOrderState, CustomGroupOrderStateEnum.Created);

                            if (groupOrderState != CustomGroupOrderStateEnum.Ready)
                            {
                                throw new IKEAException(IKEAConstants.CustomMaterialGroupMOWrongTrackInStateLocalizedMessage,
                                    materialGroupMO.Name,
                                    groupOrderState.ToString()
                                );
                            }

                            // Get the child MOs materials and parts per cycle from the Group:
                            var materialChildMOs = ikeaUtilities.GetChildMaterialsAndPartsPerCycleFromGroupMO(materialGroupMO);

                            // Add the child MOs to be added into the input so they can be TrackedIn also:
                            childMaterialsToTrackIn.AddRange(materialChildMOs.Keys);


                            #region Solve recipe context for groupMO
                            // Resolve recipe context for groupMO
                            IRecipe groupMORecipe = ikeaUtilities.ResolveRecipeContext(serviceName: materialGroupMO.RequiredService.Name,
                                                               productName: materialGroupMO.Product.Name);

                            // If groupMO can't be resolved, then check if childMOs can be resolved and
                            // add entry for the groupMO with the same recipe as the first childMO
                            if (groupMORecipe == null && !childMaterialsToTrackIn.IsNullOrEmpty())
                            {
                                // Get childMO recipes
                                IRecipeCollection childrenRecipes = entityFactory.CreateCollection<IRecipeCollection>();
                                foreach (IMaterial childMO in childMaterialsToTrackIn)
                                {
                                    IRecipe childRecipe = ikeaUtilities.ResolveRecipeContext(serviceName: childMO.RequiredService.Name,
                                                                                            productName: childMO.Product.Name);

                                    if (childRecipe != null) { 
                                        childrenRecipes.Add(childRecipe); 
                                    }
                                }

                                // If all childMOs could be resolved then add entry for groupMO using the first childMO recipe
                                if(!childrenRecipes.IsNullOrEmpty() && childrenRecipes.Count() == childMaterialsToTrackIn.Count())
                                {
                                    ikeaUtilities.addNewRecipeContextEntry(materialGroupMO.RequiredService, materialGroupMO.Product, childrenRecipes[0]);
                                }

                            }
                            #endregion

                        }
                    }

                    // If there are MOs on a group MO, those materials must be tracked in also:
                    if (!childMaterialsToTrackIn.IsNullOrEmpty())
                    {
                        deeContextUtilities.SetContextParameter("CustomHandleGroupMOTrackIn_GroupMOChildrenMaterials", childMaterialsToTrackIn);
                        deeContextUtilities.SetContextParameter("CustomHandleGroupMOTrackIn_GroupMOChildrenResource", trackInMaterialsInput.Resource);
                    }
                }
            }
            else if (currentContext.TriggerPoint == DeeTriggerPoint.Post)
            {
                // Gets the context parameters saved in Pre condition (materials from the Group MO):
                IMaterialCollection materialsContext = deeContextUtilities.GetContextParameter("CustomHandleGroupMOTrackIn_GroupMOChildrenMaterials") as IMaterialCollection;
                IResource resourceContext = deeContextUtilities.GetContextParameter("CustomHandleGroupMOTrackIn_GroupMOChildrenResource") as IResource;

                if (!materialsContext.IsNullOrEmpty() && resourceContext != null)
                {

                    // Get the materials from the context variables:
                    IMaterialCollection materials = entityFactory.CreateCollection<IMaterialCollection>();
                    materials.AddRange(materialsContext);

                    // Get the resource from the context variables:
                    IResource resource = entityFactory.Create<IResource>();

                    resource.Name = resourceContext.Name;
                    
                    resource.Load();

                    // IMPORTANT!! Clear the context variables to prevent recurssive conflits:
                    deeContextUtilities.SetContextParameter("CustomHandleGroupMOTrackIn_GroupMOChildrenMaterials", null);
                    deeContextUtilities.SetContextParameter("CustomHandleGroupMOTrackIn_GroupMOChildrenResource", null);

                    // Due to a Bug, it is not possible to trackout all the materials at once if there are multiple BOMs:
                    foreach (var material in materials)
                    {
                        resource.Load();

                        ComplexTrackInMaterialInput input = new ComplexTrackInMaterialInput
                        {
                            Material = material,
                            Resource = resource
                        };
                        materialOrchestration.ComplexTrackInMaterial(input);
                    }
                }
            }

            

            //---End DEE Code---
            return Input;
        }


    }
}
