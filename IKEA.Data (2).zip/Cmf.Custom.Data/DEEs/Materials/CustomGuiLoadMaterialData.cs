﻿using Cmf.Custom.IKEA.Common;
using Cmf.Navigo.BusinessObjects;
using System.Collections.Generic;
using System.Linq;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Common.CustomActionUtilities;

namespace Cmf.Custom.IKEA.Actions.MaterialTracking
{

    /// <summary>
    /// This DEE loads the material details necessary fot the track out quantity step
    /// </summary>
    public class CustomGuiLoadMaterialData : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---

            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "");
            UseReference("", "Cmf.Foundation.Common.Exceptions");
            UseReference("", "Cmf.Foundation.Common");
            //Please start code here

            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            IMaterial material = Input["Material"] as IMaterial;
            string resourceName = null;
            string areaName = null;

            material.Step.LoadRelations("StepArea");
            long facilityId = material.GetNativeValue<long>("Facility");
            IStepArea stepArea = material.Step.RelationCollection["StepArea"].FirstOrDefault(r => facilityId == (r as IStepArea).TargetEntity.GetNativeValue<long>("Facility")) as IStepArea;
            if (stepArea != null)
                areaName = stepArea.TargetEntity.Name;

            Dictionary<string, object> materialDetails = new Dictionary<string, object>();

            materialDetails.Add("ResourceName", resourceName);
            materialDetails.Add("AreaName", areaName); 
            materialDetails.Add("DefaultCompleteQuantity", material.GetAttributeValueOrDefault<decimal>(IKEAConstants.CustomMaterialAttributeDefaultCompletedQuantity, true));

            return materialDetails;

            //---End DEE Code---

        }

        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---

            #region Info

            /* Description: 
             *   This DEE loads the material details necessary for the track out quantity step
            */

            #endregion

            // By default, action is not to be executed
            bool executionVeridict = true;

            if (IKEADEEActionUtilities.GetInputItem<IMaterial>(Input, "Material") == null)
            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }
    }
}
