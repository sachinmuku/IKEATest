﻿using Cmf.Common.CustomActionUtilities;

using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Exceptions;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.Materials
{
    public class CustomValidateMoveNext : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Verifies that the material and step type are defined as compatible at MoveNext operation
            /// Action Groups:
            ///     MaterialManagement.MaterialManagementOrchestration.ComplexMoveMaterialsToNextStep.Pre
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "MaterialManagement.MaterialManagementOrchestration.ComplexMoveMaterialsToNextStep.Pre"
            };

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            if (executionVeridict && IKEADEEActionUtilities.GetInputItem<ComplexMoveMaterialsToNextStepInput>(Input, "ComplexMoveMaterialsToNextStepInput") == null)
            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Exceptions");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            //System
            UseReference("", "System");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("", "System.Linq");
            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects");
            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();

            if (Input["ComplexMoveMaterialsToNextStepInput"] is ComplexMoveMaterialsToNextStepInput)
            {
                ComplexMoveMaterialsToNextStepInput data = Input["ComplexMoveMaterialsToNextStepInput"] as ComplexMoveMaterialsToNextStepInput;

                var dictionary = data.Materials;

                IMaterialCollection materials = entityFactory.CreateCollection<IMaterialCollection>();
                materials.AddRange(dictionary.Keys);

                if (materials.Any(m => m.Type == null))
                {
                    materials.Load();
                }

                var materialTypes = materials.Select(x => x.Type).Distinct().ToArray();

                IStepCollection steps = entityFactory.CreateCollection<IStepCollection>();

                foreach (var item in dictionary)
                {
                    steps.Add(genericUtilities.GetStepByFlowPath(item.Value));
                }

                if (!steps.IsNullOrEmpty())
                {
                    var newSteps = ikeaUtilities.CheckStepTypesBasedOnMaterialTypes(materialTypes, steps);
                    if (newSteps != null && newSteps.Count == 0)
                    {
                        throw new IKEAException(IKEAConstants.CustomValidateMaterialAndStepTypeAtMoveNext);
                    }
                }

            }

            //---End DEE Code---

            return Input;
        }



    }
}
