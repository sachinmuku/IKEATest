﻿using Cmf.Common.CustomActionUtilities;

using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Exceptions;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.Materials
{
    public class CustomMaterialLossSetRejectQuantity : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Set secondary quantity of a material with the quantity recorded as loss
            /// Action Groups:
            ///     BusinessObjects.MaterialCollection.RecordLoss.Post
            /// </summary>
            #endregion
            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];

            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();

            // Get the default reject unit
            string rejectUnit = genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.ScrapManagementRejectUnit);

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.MaterialCollection.RecordLoss.Post"
            };

            // Only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups) && !string.IsNullOrWhiteSpace(rejectUnit);

            if (executionVeridict
                && IKEADEEActionUtilities.GetInputItem<Dictionary<IMaterial, IRecordLossParameters>>(Input, "Parameters") == null)
            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Exceptions");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            //System
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("", "System.IO");
            UseReference("", "System.Threading");
            UseReference("", "System");

            //Foundation
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();

            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            // Get the default reject unit
            string rejectUnit = genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.ScrapManagementRejectUnit);

            Dictionary<IMaterial, IRecordLossParameters> materialWithLossParameters = IKEADEEActionUtilities.GetInputItem<Dictionary<IMaterial, IRecordLossParameters>>(Input, "Parameters");

            IMaterialCollection materials = entityFactory.CreateCollection<IMaterialCollection>();
            materials.AddRange(materialWithLossParameters.Keys);

            // This load needs to be done due to changes in the material done in another DEE
            materials.Load();

            IMaterialQuantityChangeCollection materialQuantities = new MaterialQuantityChangeCollection();

            // Go throw all the record losses and update the secondary quantity of the material
            // with the quantity being recorded as a loss
            if (!string.IsNullOrWhiteSpace(rejectUnit))
            {
                foreach (var item in materialWithLossParameters)
                {
                    decimal rejectedQuantity = 0;
                    IMaterial material = item.Key;

                    // Check if the material secondary unit already is of the type Reject
                    if (material.SecondaryUnits.CompareStrings(rejectUnit))
                    {
                        // Validates if there is any record loss for the Secondary Quantity. If true throws an error
                        var validateSecondaryUnit = item.Value.LossReasons.Any(l => l.ReasonSecondaryQuantity.HasValue && l.ReasonSecondaryQuantity.Value > 0);
                        if (validateSecondaryUnit)
                        {
                            throw new IKEAException(IKEAConstants.CustomMaterialLossSetRejectQuantityError, rejectUnit, material.Name);
                        }

                        // Validates if there is any record loss for the Primary Quantity
                        foreach (var lossReason in item.Value.LossReasons.Where(l => l.ReasonPrimaryQuantity.HasValue && l.ReasonPrimaryQuantity.Value > 0))
                        {
                            rejectedQuantity += lossReason.ReasonPrimaryQuantity.Value;
                        }

                        if (rejectedQuantity > 0)
                        {
                            IMaterialQuantityChange materialQuantity = new MaterialQuantityChange()
                            {
                                Material = material,
                                NewSecondaryQuantity = material.SecondaryQuantity + rejectedQuantity
                            };

                            materialQuantities.Add(materialQuantity);
                        }
                    }
                }
            }

            if (!materialQuantities.IsNullOrEmpty())
            {
                materials.ChangeQuantity(materialQuantities, null);
            }

            //---End DEE Code---

            return Input;
        }
    }
}
