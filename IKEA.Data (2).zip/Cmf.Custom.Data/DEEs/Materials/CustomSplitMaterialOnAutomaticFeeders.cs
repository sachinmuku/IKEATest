﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Exceptions;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.Materials
{
    class CustomSplitMaterialOnAutomaticFeeders : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {

        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   
UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
  
            #region Info
            /// <summary>
            /// Summary text
            ///     This DEE must prevent the operator from manually splitting materials that are attached to automatic feeders.
            /// Action Groups:
            ///     BusinessObjects.MaterialCollection.Split.Pre
            /// </summary>
            #endregion

            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];

            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();


            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.MaterialCollection.Split.Pre",
            };

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);


            // check if split is coming from palletization process:
            bool? isPalletizationSplit = deeContextUtilities.GetContextParameter(IKEAConstants.CustomUnitCompletePalletizationSplitContextKey) as bool?;

            // check if the source of this split is internal:
            bool? isSystemSplit = deeContextUtilities.GetContextParameter(IKEAConstants.CustomAllowAutomaticFeederMaterialSplit) as bool?;

            // if the split has its source internally, allow the split by exiting the DEE execution:
            if (executionVeridict && (isPalletizationSplit.GetValueOrDefault() || isSystemSplit.GetValueOrDefault()))
            {
                executionVeridict = false;
            }

            if (executionVeridict && IKEADEEActionUtilities.GetInputItem<Dictionary<IMaterial, ISplitInputParametersCollection>>(Input, "ChildMaterialsInformation") == null)
            {
                executionVeridict = false;
            }
            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Exceptions");
            //System
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("", "System");

            //Foundation
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.Common.dll", "Cmf.Foundation.Common");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();

            Dictionary<IMaterial, ISplitInputParametersCollection> childMaterialsInformation = Input["ChildMaterialsInformation"] as Dictionary<IMaterial, ISplitInputParametersCollection>;

            if (!childMaterialsInformation.IsNullOrEmpty())
            {

                // Get all materials:
                IMaterialCollection materials = entityFactory.CreateCollection<IMaterialCollection>();
                materials.AddRange(childMaterialsInformation.Keys);

                // Load relations to resources:
                materials.LoadRelations(Navigo.Common.Constants.MaterialResource, levelsToLoad: 1);

                foreach (var material in materials)
                {
                    if (material.MaterialResourceRelations != null)
                    {
                        // Check if there are any resources of type consumable with automation
                        var consumableFeed = material.MaterialResourceRelations
                            .Select(relation => relation.TargetEntity)
                            .Any(resource => resource.Type == IKEAConstants.ResourceTypeConsumable &&
                                             resource.AutomationMode == ResourceAutomationMode.Online);

                        if (consumableFeed)
                        {
                            throw new IKEAException(IKEAConstants.CustomConsumableFeedMaterialSplitNotPossibleLocalizedMessage);
                        }
                    }
                }
            }

            //---End DEE Code---

            return Input;
        }
    }
}
