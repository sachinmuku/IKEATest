﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Custom.IKEA.Common;
using Cmf.Navigo.BusinessObjects;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Custom.IKEA.Common.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using Cmf.Common.CustomActionUtilities.Abstractions;

namespace Cmf.Custom.IKEA.Actions.Materials
{
    public class CustomMaterialStateModelMappingLogic : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Changes the Material State Model MSM
            /// Action Groups:
            ///     BusinessObjects.MaterialCollection.Create.Pre
            ///     BusinessObjects.MaterialCollection.Dispatch.Post
            ///     BusinessObjects.MaterialCollection.MoveToNextStep.Post
            ///     BusinessObjects.MaterialCollection.ChangeFlowAndStep.Post
            ///     BusinessObjects.MaterialCollection.AbortProcess.Post
            ///     BusinessObjects.MaterialCollection.Undispatch.Post
            ///     BusinessObjects.MaterialCollection.MoveToStep.Post
            ///     BusinessObjects.MaterialCollection.TrackIn.Post
            ///     BusinessObjects.MaterialCollection.TrackOut.Post                
            ///     BusinessObjects.MaterialCollection.Terminate.Pre
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.MaterialCollection.Create.Pre",
                "BusinessObjects.MaterialCollection.Dispatch.Post",
                "BusinessObjects.MaterialCollection.MoveToNextStep.Post",
                "BusinessObjects.MaterialCollection.ChangeFlowAndStep.Post",
                "BusinessObjects.MaterialCollection.AbortProcess.Post",
                "BusinessObjects.MaterialCollection.Undispatch.Post",
                "BusinessObjects.MaterialCollection.MoveToStep.Post",
                "BusinessObjects.MaterialCollection.TrackIn.Post",
                "BusinessObjects.MaterialCollection.TrackOut.Post",
                "BusinessObjects.MaterialCollection.Terminate.Pre"
            };

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            if (executionVeridict && IKEADEEActionUtilities.GetInputItem<IMaterialCollection>(Input, "MaterialCollection") == null)
            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            //System
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");


            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];

            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();

            if (Input["MaterialCollection"] is IMaterialCollection)
            {
                var materials = Input["MaterialCollection"] as IMaterialCollection;
                DeeContext currentContext = deeContextUtilities.SetCurrentServiceContext("CustomMaterialStateModelMappingLogic");

                genericUtilities.MaterialStateModelMappingLogic(currentContext.MethodName, materials);

            }

            //---End DEE Code---

            return Input;
        }
    }
}
