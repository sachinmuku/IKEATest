﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessObjects.SmartTables;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;

namespace Cmf.Custom.IKEA.Actions.Materials
{
    public class CustomOrderClearRecipeContext : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Action to remove from SmartTable 'RecipeContext' all entries that contain the selected recipe
            /// Action Groups:
            ///     MaterialManagement.MaterialManagementOrchestration.TerminateMaterials.Post
            ///     MaterialManagement.MaterialManagementOrchestration.AbortMaterialsProcess.Post
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "MaterialManagement.MaterialManagementOrchestration.TerminateMaterials.Post",
                "MaterialManagement.MaterialManagementOrchestration.AbortMaterialsProcess.Post"
            };

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            string actionGroup = IKEADEEActionUtilities.GetActionGroup(Input);

            if (executionVeridict
                && (actionGroup == "MaterialManagement.MaterialManagementOrchestration.TerminateMaterials.Post" && IKEADEEActionUtilities.GetInputItem<TerminateMaterialsOutput>(Input, "PerformMaterialChecklistItemsOutput") == null)
                && (actionGroup == "ResourceManagement.ResourceManagementOrchestration.AbortMaterialsProcess.Post" && IKEADEEActionUtilities.GetInputItem<AbortMaterialsProcessOutput>(Input, "DetachConsumableFromResourceOutput") == null))
            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

 UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
     

            //System
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("", "System.Data");
            UseReference("%MicrosoftNetPath%\\System.XML.dll", "System.Xml");

            //Foundation
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects.SmartTables");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.Common.dll", "Cmf.Foundation.Common");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects");

            // Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");

            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];

            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();

            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();

            DeeContext currentContext = deeContextUtilities.SetCurrentServiceContext("CustomOrderClearRecipeContext");

            IMaterialCollection materialCollection = entityFactory.CreateCollection<IMaterialCollection>();

            switch (currentContext.MethodName)
            {
                case "TerminateMaterials":
                    {
                        materialCollection = IKEADEEActionUtilities.GetInputItem<TerminateMaterialsOutput>(Input, "TerminateMaterialsOutput").Materials;
                        break;
                    }
                case "AbortMaterialsProcess":
                    {
                        materialCollection = IKEADEEActionUtilities.GetInputItem<AbortMaterialsProcessOutput>(Input, "AbortMaterialsProcessOutput").Materials;
                        break;
                    }
            }

            if (materialCollection.Count == 0)
            {
                throw new ArgumentNullCmfException("MaterialCollection");
            }

            string orderForm = ikeaUtilities.GetOrderMaterialForm();

            foreach (IMaterial material in materialCollection)
            {

                //Only applicable to Order forms
                if (material.Form == orderForm)
                {
                    // Get all the required services from the materials
                    long materialServiceId = material.GetNativeValue<long>("RequiredService");
                    Cmf.Navigo.BusinessObjects.Abstractions.IService service = entityFactory.Create<Cmf.Navigo.BusinessObjects.Abstractions.IService>();
                    service.Load(materialServiceId);

                    // Try to resolve the recipe by Service and Material Name
                    DataSet recipeDataContext = ikeaUtilities.ResolveRecipeContextDataSet(serviceName: service.Name,
                                                                                            materialName: material.Name);

                    if (recipeDataContext.HasData()
                         && recipeDataContext.Tables[0].Rows[0].Field<string>(Navigo.Common.Constants.Material).CompareStrings(material.Name))
                    {
                        ISmartTable smartTable = new SmartTable();
                        smartTable.Load(Navigo.Common.Constants.RecipeContext);
                        smartTable.RemoveRows(NgpDataSet.FromDataSet(recipeDataContext));
                    }
                }
            }

            

            //---End DEE Code---

            return Input;
        }
    }
}
