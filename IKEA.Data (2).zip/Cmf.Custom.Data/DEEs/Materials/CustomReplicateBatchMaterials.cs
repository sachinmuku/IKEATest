﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.Materials
{
    public class CustomReplicateBatchMaterials : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text:
            ///     Replicate Batch materials from source materials to target materials
            /// Action Groups:
            ///     BusinessObjects.Material.Assemble.Post
            ///     BusinessObjects.Material.AutomaticAssemble.Post
            ///     BusinessObjects.MaterialCollection.Split.Post
            ///     BusinessObjects.Material.Merge.Post
            ///     BusinessObjects.Material.Expand.Post
            ///     BusinessObjects.Material.Collapse.Post
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.Material.Assemble.Post",
                "BusinessObjects.Material.AutomaticAssemble.Post",
                "BusinessObjects.MaterialCollection.Split.Post",
                "BusinessObjects.Material.Merge.Post",
                "BusinessObjects.Material.Expand.Post",
                "BusinessObjects.Material.Collapse.Post",
            };

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            if (executionVeridict 
                && IKEADEEActionUtilities.GetInputItem<IMaterial>(Input, "Material") == null
                && IKEADEEActionUtilities.GetInputItem<IMaterialCollection>(Input, "MaterialCollection") == null
                && IKEADEEActionUtilities.GetInputItem<IAssembleMaterialCollection>(Input, "AssembleMaterialCollection") == null
                && IKEADEEActionUtilities.GetInputItem<List<IMaterial>>(Input, "ConsumedMaterials") == null
                && IKEADEEActionUtilities.GetInputItem<Dictionary<IMaterial, IMaterialCollection>>(Input, "OutputChildMaterials") == null
                && IKEADEEActionUtilities.GetInputItem<Dictionary<IMaterial, IMergeMaterialParameters>>(Input, "ChildMaterials") == null
                && IKEADEEActionUtilities.GetInputItem<IMaterialCollection>(Input, "SubMaterials") == null)
            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            //System
            UseReference("", "System");
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            DeeContext currentContext = deeContextUtilities.SetCurrentServiceContext("CustomReplicateBatchMaterials");
            IMaterialCollection materialsFrom = entityFactory.CreateCollection<IMaterialCollection>();

            Dictionary<IMaterial, IMaterialCollection> replicateToSubMaterials = new Dictionary<IMaterial, IMaterialCollection>();
            Dictionary<IMaterialCollection, IMaterial> replicateFromSubMaterials = new Dictionary<IMaterialCollection, IMaterial>();

            switch (currentContext.MethodName)
            {
                case "Assemble":
                    {
                        IAssembleMaterialCollection assembleMaterials = IKEADEEActionUtilities.GetInputItem<IAssembleMaterialCollection>(Input, "AssembleMaterialCollection");

                        if (!assembleMaterials.IsNullOrEmpty())
                        {
                            materialsFrom.AddRange(assembleMaterials.Select(am => am.Material));
                            replicateFromSubMaterials.Add(materialsFrom, IKEADEEActionUtilities.GetInputItem<IMaterial>(Input, "Material"));
                        }

                        break;
                    }
                case "InternalAutomaticAssemble": // In case of the Automatic Assemble the method name can be InternalAutomaticAssemble
                case "AutomaticAssemble":
                    {
                        materialsFrom.AddRange(IKEADEEActionUtilities.GetInputItem<List<IMaterial>>(Input, "ConsumedMaterials"));

                        replicateFromSubMaterials.Add(materialsFrom, IKEADEEActionUtilities.GetInputItem<IMaterial>(Input, "Material"));

                        break;
                    }
                case "Split":
                    {
                        replicateToSubMaterials = IKEADEEActionUtilities.GetInputItem<Dictionary<IMaterial, IMaterialCollection>>(Input, "OutputChildMaterials");

                        break;
                    }
                case "Merge":
                    {
                        Dictionary<IMaterial, IMergeMaterialParameters> childMaterials = IKEADEEActionUtilities.GetInputItem<Dictionary<IMaterial, IMergeMaterialParameters>>(Input, "ChildMaterials");
                        IMaterial material = IKEADEEActionUtilities.GetInputItem<IMaterial>(Input, "Material");
                        
                        if (!childMaterials.IsNullOrEmpty() && material != null)
                        {
                            // Load child attributes:
                            materialsFrom.AddRange(childMaterials.Select(am => am.Key));
                            materialsFrom.LoadAttributes(new Collection<string> { IKEAConstants.CustomMaterialAttributeReworkCounter });

                            // Get ReworkCounters from child and parent materials:
                            int maxReworkCounter = materialsFrom.Max(m => m.GetAttributeValueOrDefault<int>(IKEAConstants.CustomMaterialAttributeReworkCounter));
                            int parentReworkCounter = material.GetAttributeValueOrDefault<int>(IKEAConstants.CustomMaterialAttributeReworkCounter, true);

                            // Saves the maximum value:
                            material.SaveAttributes(new AttributeCollection() { { IKEAConstants.CustomMaterialAttributeReworkCounter, Math.Max(maxReworkCounter, parentReworkCounter) } });

                            replicateFromSubMaterials.Add(materialsFrom, material);
                        }
                        break;
                    }
                case "Expand":
                    {
                        IMaterialCollection materials = IKEADEEActionUtilities.GetInputItem<IMaterialCollection>(Input, "SubMaterials");
                        materials.Load(); // This load needs to happen otherwise relation cannot be added

                        replicateToSubMaterials.Add(IKEADEEActionUtilities.GetInputItem<IMaterial>(Input, "Material"), materials);

                        break;
                    }
                case "Collapse":
                    {
                        replicateFromSubMaterials.Add(IKEADEEActionUtilities.GetInputItem<IMaterialCollection>(Input, "SubMaterials"), IKEADEEActionUtilities.GetInputItem<IMaterial>(Input, "Material"));

                        break;
                    }
                default:
                    break;
            }

            ikeaUtilities.ReplicateBatchRelations(replicateToSubMaterials, replicateFromSubMaterials);

            //---End DEE Code---

            return Input;
        }
    }
}
