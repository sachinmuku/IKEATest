﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.BusinessObjects;
using Cmf.Custom.IKEA.BusinessObjects.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Extensions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.Materials
{
    public class CustomCollectAndRemoveBatchRelationsForMO : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Collect and remove all batch relations where MO Material is target on Terminate (Operation level handling)
            /// Action Groups:
            ///     BusinessObjects.MaterialCollection.Terminate.Pre
            ///     BusinessObjects.MaterialCollection.Terminate.Post
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.MaterialCollection.Terminate.Pre",
                "BusinessObjects.MaterialCollection.Terminate.Post"
            };

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            if (executionVeridict && IKEADEEActionUtilities.GetInputItem<IMaterialCollection>(Input, "MaterialCollection") == null)
            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
     

            //System
            UseReference("", "Cmf.Custom.IKEA.BusinessObjects.Abstractions");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("", "System.Linq");

            //Foundation
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.BusinessObjects.CustomMaterialBatch.dll", "Cmf.Custom.IKEA.BusinessObjects");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Extensions");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetService<IDeeContextUtilities>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();

            DeeContext currentContext = deeContextUtilities.SetCurrentServiceContext("CustomMaterialIncrementReworkCounter");
            // New Context
            string contextRemovedMaterialMoRelations = "CustomCollectAndRemoveBatchRelationsForMO_RemovedRelations";
            string contextRemovedMaterialBatchRelations = "CustomCollectAndRemoveBatchRelationsForMO_BatchRelations";
            string contextProductOrderRelations = "CustomCollectAndRemoveBatchRelationsForMO_PORelations";
            IMaterialCollection materials = entityFactory.CreateCollection<IMaterialCollection>();
            // Dictionary to aggregate all the relations for each Material of form MO
            IMaterialCollection materialsToConvert = entityFactory.CreateCollection<IMaterialCollection>();

            // get order material form to use
            string orderMaterialForm = ikeaUtilities.GetOrderMaterialForm();

            if (currentContext.TriggerPoint == DeeTriggerPoint.Pre && Input["MaterialCollection"] is IMaterialCollection)
            {
                materials = Input["MaterialCollection"] as IMaterialCollection;

                ICustomMaterialBatchCollection customMaterialBatches = entityFactory.CreateCollection<ICustomMaterialBatchCollection>();

                // Get the MO to be converted to Batch
                materialsToConvert.AddRange(materials.Where(m => m.Form.CompareStrings(orderMaterialForm) && !m.IsGroupMO()).ToList());

                // Get relation CustomMaterialBatch for MO material
                customMaterialBatches.AddRange(materialsToConvert.SelectMany(m => ikeaUtilities.GetCustomMaterialBatchRelationForMaterial(m.Id, true))
                                                        .ToList());

                if (customMaterialBatches.Count > 0)
                    customMaterialBatches.Terminate();

                Dictionary<long, IProductionOrder> productionOrders = new Dictionary<long, IProductionOrder>();
                foreach (IMaterial m in materials)
                {
                    if (m.ProductionOrder != null)
                    {
                        productionOrders.Add(m.Id, m.ProductionOrder);
                    }
                }

                deeContextUtilities.SetContextParameter(contextRemovedMaterialMoRelations, materialsToConvert);
                deeContextUtilities.SetContextParameter(contextRemovedMaterialBatchRelations, customMaterialBatches);
                deeContextUtilities.SetContextParameter(contextProductOrderRelations, productionOrders);

            }
            else if (currentContext.TriggerPoint == DeeTriggerPoint.Post && Input["MaterialCollection"] is IMaterialCollection)
            {
                materials.AddRange((Input["MaterialCollection"] as IMaterialCollection).Where(x => x.Form.CompareStrings(orderMaterialForm) && !x.IsGroupMO()));
                materialsToConvert = deeContextUtilities.GetContextParameter(contextRemovedMaterialMoRelations) as IMaterialCollection;
                Dictionary<long, IProductionOrder> productionOrders = deeContextUtilities.GetContextParameter(contextProductOrderRelations) as Dictionary<long, IProductionOrder>;


                Dictionary<IMaterial, ICmfEntityRelationCollection> relationsToAdd = new Dictionary<IMaterial, ICmfEntityRelationCollection>();
                string unterminateJustification = genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.UnterminateJustificationForMaterial);
                // Get Batch Form and Type
                string batchForm = genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.BatchMaterialForm);
                string batchType = genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.BatchMaterialType);
                // Get FLow, Step and Flow path for batch material
                string flowPath = genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.BatchDefaultFlowPath);

                // Dictionary with materials to Unterminate
                Dictionary<IMaterial, string> dictionaryToUnterminate = new Dictionary<IMaterial, string>();
                // Dictionary with materials to change flow, step and flowPath
                Dictionary<IMaterial, string> materialFlowPaths = new Dictionary<IMaterial, string>();
                // Dictionary with all materials to change type
                Dictionary<IMaterial, string> materialToChangeType = new Dictionary<IMaterial, string>();
                // MaterialCollection to change form and type
                IMaterialCollection materialToChangeForm = entityFactory.CreateCollection<IMaterialCollection>();
                // ProductionOrders to set back the POs
                Dictionary<IMaterial, IProductionOrder> productOrders = new Dictionary<IMaterial, IProductionOrder>();

                ICustomMaterialBatchCollection materialBatchRelations = deeContextUtilities.GetContextParameter(contextRemovedMaterialBatchRelations) as ICustomMaterialBatchCollection;
                foreach (IMaterial material in materialsToConvert)
                {
                    // Add Material to Unterminate in order to change form and add relations
                    dictionaryToUnterminate.Add(material, unterminateJustification);

                    // Change Flow Path
                    materialFlowPaths.Add(material, flowPath);

                    materialToChangeForm.Add(material);

                    materialToChangeType.Add(material, batchType);

                    if (productionOrders.ContainsKey(material.Id))
                    {
                        productionOrders[material.Id].Load();
                        productOrders.Add(material, productionOrders[material.Id]);
                    }
                }

                materials.Unterminate(dictionaryToUnterminate);

                materialBatchRelations.Load();
                materialBatchRelations.Unterminate();

                materials.ChangeFlowAndStep(materialFlowPaths, "ChangeFlowAndStep", null);
                foreach (var mat in materialToChangeForm)
                {
                    mat.Form = batchForm;
                }

                materialToChangeForm.Save();
                materials.ChangeType(materialToChangeType, true, null);

                if (productionOrders.Keys.Count > 0)
                {
                    materials.ChangeProductionOrder(productOrders);
                }

            }

            

            //---End DEE Code---

            return Input;
        }


    }
}
