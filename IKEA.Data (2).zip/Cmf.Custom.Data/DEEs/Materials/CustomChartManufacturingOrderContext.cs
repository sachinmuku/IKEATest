﻿using Cmf.Foundation.Common;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessOrchestration.ResourceManagement;
using Cmf.Navigo.BusinessOrchestration.ResourceManagement.InputObjects;
using Cmf.Navigo.BusinessOrchestration.ResourceManagement.OutputObjects;
using System.Collections.Generic;
using System.Linq;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Actions.Materials
{
    public class CustomChartManufacturingOrderContext : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---
            /**Using Assembles**/
            UseReference("Cmf.Navigo.BusinessObjects.dll", "");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "");
            /**Using NameSpace**/
            UseReference("", "Cmf.Navigo.BusinessObjects");
            UseReference("", "Cmf.Navigo.BusinessOrchestration.ResourceManagement");
            UseReference("", "Cmf.Navigo.BusinessOrchestration.ResourceManagement.InputObjects");
            UseReference("", "Cmf.Navigo.BusinessOrchestration.ResourceManagement.OutputObjects");
            UseReference("", "System");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Linq");
            //Please start code here

            IMaterial material = Input[nameof(Material)] as IMaterial;
            IResource resource = Input[nameof(Resource)] as IResource;
            if (material == null && resource != null)
            {
                IResource topResource = resource.GetTopMostResource();
                resource = topResource ?? resource;
                
                resource.LoadRelations(Cmf.Navigo.Common.Constants.MaterialResource);
                material = resource.ResourceMaterials?.FirstOrDefault()?.SourceEntity;
            }

            if (material != null) 
            {
                material.Load();
                Input.Add("Result", material.ProductionOrder);
            }
            
            //---End DEE Code---
            return Input;
        }

        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---
            return (Input["Resource"] is IResource)  || (Input["Material"] is IMaterial);
            //---End DEE Condition Code---
        }
    }
}
