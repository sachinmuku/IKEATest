﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Extensions;
using Cmf.Custom.IKEA.Orchestration.OutputObjects;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects;
using Cmf.Navigo.BusinessOrchestration.ResourceManagement.OutputObjects;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.Materials
{
    public class CustomMaterialValidateSetup : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Action to validate if the materials are ready for production and report that information to automation
            /// Action Groups:
            ///     BusinessObjects.Resource.ManageDurables.Post
            ///     BusinessObjects.Resource.ManageConsumableFeeds.Post
            ///     MaterialManagement.MaterialManagementOrchestration.PerformMaterialChecklistItems.Post
            ///     MaterialManagement.MaterialManagementOrchestration.ComplexTrackInMaterials.Post
            ///     BusinessObjects.MaterialCollection.TrackOut.Post
            ///     ResourceManagement.ResourceManagementOrchestration.DetachConsumableFromResource.Post
            ///     ResourceManagement.ResourceManagementOrchestration.DetachConsumablesFromResource.Post
            ///     ResourceManagement.ResourceManagementOrchestration.AttachConsumableToResource.Post
            ///     ResourceManagement.ResourceManagementOrchestration.AttachConsumablesToResource.Post
            ///     Orchestration.IKEABusinessOrchestration.CustomStopMaterial.Post
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.Resource.ManageDurables.Post",
                "BusinessObjects.Resource.ManageConsumableFeeds.Post",
                "MaterialManagement.MaterialManagementOrchestration.PerformMaterialChecklistItems.Post",
                "MaterialManagement.MaterialManagementOrchestration.ComplexTrackInMaterials.Post",
                "BusinessObjects.MaterialCollection.TrackOut.Post",
                "ResourceManagement.ResourceManagementOrchestration.DetachConsumableFromResource.Post",
                "ResourceManagement.ResourceManagementOrchestration.DetachConsumablesFromResource.Post",
                "ResourceManagement.ResourceManagementOrchestration.AttachConsumableToResource.Post",
                "ResourceManagement.ResourceManagementOrchestration.AttachConsumablesToResource.Post",
                "Orchestration.IKEABusinessOrchestration.CustomStopMaterial.Post"
            };

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            string actionGroup = IKEADEEActionUtilities.GetActionGroup(Input);

            if (executionVeridict
                && ((actionGroup == "BusinessObjects.Resource.ManageDurables.Post" || actionGroup == "BusinessObjects.Resource.ManageConsumableFeeds.Post") && IKEADEEActionUtilities.GetInputItem<IResource>(Input, Navigo.Common.Constants.Resource) == null)
                && ((actionGroup == "MaterialManagement.MaterialManagementOrchestration.ComplexTrackInMaterials.Post" || actionGroup == "BusinessObjects.MaterialCollection.TrackOut.Post") && IKEADEEActionUtilities.GetInputItem<IMaterialCollection>(Input, Navigo.Common.Constants.MaterialCollection) == null)
                && (actionGroup == "MaterialManagement.MaterialManagementOrchestration.PerformMaterialChecklistItems.Post" && IKEADEEActionUtilities.GetInputItem<PerformMaterialChecklistItemsOutput>(Input, "PerformMaterialChecklistItemsOutput") == null)
                && (actionGroup == "ResourceManagement.ResourceManagementOrchestration.DetachConsumableFromResource.Post" && IKEADEEActionUtilities.GetInputItem<DetachConsumableFromResourceOutput>(Input, "DetachConsumableFromResourceOutput") == null)
                && (actionGroup == "ResourceManagement.ResourceManagementOrchestration.DetachConsumablesFromResource.Post" && IKEADEEActionUtilities.GetInputItem<DetachConsumablesFromResourceOutput>(Input, "DetachConsumablesFromResourceOutput") == null)
                && (actionGroup == "ResourceManagement.ResourceManagementOrchestration.AttachConsumableToResource.Post" && IKEADEEActionUtilities.GetInputItem<AttachConsumableToResourceOutput>(Input, "AttachConsumableToResourceOutput") == null)
                && (actionGroup == "ResourceManagement.ResourceManagementOrchestration.AttachConsumablesToResource.Post" && IKEADEEActionUtilities.GetInputItem<AttachConsumablesToResourceOutput>(Input, "AttachConsumablesToResourceOutput") == null)
                && (actionGroup == "Orchestration.IKEABusinessOrchestration.CustomStopMaterial.Post" && IKEADEEActionUtilities.GetInputItem<CustomStopMaterialOutput>(Input, "CustomStopMaterialOutput") == null))
            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
            //System
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("", "System");

            //Foundation
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.Common.dll", "Cmf.Foundation.Common");

            //Navigo
            UseReference("Cmf.Navigo.Common.dll", "Cmf.Navigo.Common");
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.ResourceManagement");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.ResourceManagement.InputObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.ResourceManagement.OutputObjects");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Extensions");
            UseReference("Cmf.Custom.IKEA.Orchestration.dll", "Cmf.Custom.IKEA.Orchestration.OutputObjects");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();
            DeeContext currentContext = deeContextUtilities.SetCurrentServiceContext("CustomMaterialValidateSetup");
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            IDirectFeedingUtilities directFeedingUtilities = serviceProvider.GetService<IDirectFeedingUtilities>();
            IMaterialCollection materialsToValidate = entityFactory.CreateCollection<IMaterialCollection>();
            IMaterialCollection materialsAtResource = entityFactory.CreateCollection<IMaterialCollection>();
            IResource resource = null;

            string[] notificationContext =
            {
                "ComplexTrackInMaterials", "TrackOut"
            };

            bool isToNotify = notificationContext.Any(f => f.CompareStrings(currentContext.MethodName));


            switch (currentContext.MethodName)
            {
                case "ComplexTrackInMaterials":
                    {
                        // Only Validate the resource being tracked in
                        materialsAtResource = IKEADEEActionUtilities.GetInputItem<ComplexTrackInMaterialsOutput>(Input, "ComplexTrackInMaterialsOutput").Materials;
                        break;
                    }
                case "TrackOut":
                    {
                        IMaterialCollection trackedOutMaterials = IKEADEEActionUtilities.GetInputItem<IMaterialCollection>(Input, Navigo.Common.Constants.MaterialCollection);
                        trackedOutMaterials.Load();

                        // Load the BaseMaterial attribute
                        trackedOutMaterials.LoadAttributes(new Collection<string>
                        {
                            IKEAConstants.CustomMaterialAttributeBaseMaterial,
                        });

                        string orderForm = ikeaUtilities.GetOrderMaterialForm();

                        // Create a distinct list with all the base materials of the pallets tracked out
                        var orderNames = trackedOutMaterials
                            .Select(palletMaterial =>
                            {
                                if (orderForm != null && orderForm.CompareStrings(palletMaterial.Form))
                                {
                                    // If this material is a MO, return it's own name
                                    return palletMaterial.Name;
                                }
                                else
                                {
                                    // If this material is a Pallet, return it's base material
                                    return palletMaterial.GetAttributeValueOrDefault<string>(IKEAConstants.CustomMaterialAttributeBaseMaterial);
                                }
                            })
                            .Where(baseName => !string.IsNullOrEmpty(baseName))
                            .Distinct()
                            .ToList();

                        // Get all the resources of the materials being tracked out
                        IResourceCollection resources = entityFactory.CreateCollection<IResourceCollection>();
                        resources.AddRange(trackedOutMaterials.Select(m => m.LastProcessedResource));
                        if (!resources.IsNullOrEmpty())
                        {
                            // On TrackOut, only validate the Manufacturing Order materials in the resource that originated the pallets being tracked out
                            materialsAtResource.AddRange(
                                resources.GetAttachedMaterials().Where(material => orderNames.Contains(material.Name))
                            );
                        }

                        break;
                    }
                case "DetachConsumableFromResource":
                    {
                        if (currentContext.MethodName.Equals("DetachConsumableFromResource"))
                        {
                            if (IKEADEEActionUtilities.GetInputItem<DetachConsumableFromResourceOutput>(Input, "DetachConsumableFromResourceOutput") != null)
                            {
                                resource = IKEADEEActionUtilities.GetInputItem<DetachConsumableFromResourceOutput>(Input, "DetachConsumableFromResourceOutput").Resource;
                            }
                        }

                        if (resource != null)
                        {
                            materialsAtResource.AddRange(ikeaUtilities.GetAttachedMaterialsFromConsumptionSources(resource));
                        }
                        break;
                    }
                case "DetachConsumablesFromResource":
                    {
                        if (currentContext.MethodName.Equals("DetachConsumablesFromResource"))
                        {
                            if (IKEADEEActionUtilities.GetInputItem<DetachConsumablesFromResourceOutput>(Input, "DetachConsumablesFromResourceOutput") != null)
                            {
                                resource = IKEADEEActionUtilities.GetInputItem<DetachConsumablesFromResourceOutput>(Input, "DetachConsumablesFromResourceOutput").Resource;
                            }
                        }

                        if (resource != null)
                        {
                            materialsAtResource.AddRange(ikeaUtilities.GetAttachedMaterialsFromConsumptionSources(resource));
                        }
                        break;
                    }
                case "AttachConsumableToResource":
                    {
                        AttachConsumableToResourceOutput attachConsumableToResourceOutput = IKEADEEActionUtilities.GetInputItem<AttachConsumableToResourceOutput>(Input, "AttachConsumableToResourceOutput");
                        resource = attachConsumableToResourceOutput.Resource;

                        if (resource != null)
                        {
                            materialsAtResource.AddRange(ikeaUtilities.GetAttachedMaterialsFromConsumptionSources(resource));
                        }
                        break;
                    }
                case "AttachConsumablesToResource":
                    {
                        AttachConsumablesToResourceOutput attachConsumablesToResourceOutput = IKEADEEActionUtilities.GetInputItem<AttachConsumablesToResourceOutput>(Input, "AttachConsumablesToResourceOutput");
                        resource = attachConsumablesToResourceOutput.Resource;

                        if (resource != null)
                        {
                            materialsAtResource.AddRange(ikeaUtilities.GetAttachedMaterialsFromConsumptionSources(resource));
                        }
                        break;
                    }
                case "ManageConsumableFeeds":
                case "ManageDurables":
                    {
                        resource = IKEADEEActionUtilities.GetInputItem<IResource>(Input, Navigo.Common.Constants.Resource);
                        if (resource != null)
                        {
                            // Get all the materials at the resource
                            materialsAtResource = resource.GetTopMostResource().GetAttachedMaterials();
                        };
                        break;
                    }
                case "PerformMaterialChecklistItems":
                    {
                        PerformMaterialChecklistItemsOutput output = IKEADEEActionUtilities.GetInputItem<PerformMaterialChecklistItemsOutput>(Input, "PerformMaterialChecklistItemsOutput");

                        IMaterial material = output.Material;

                        // Check if the checklist is closed or terminated
                        if (material.CurrentChecklistInstance == null
                            || material.CurrentChecklistInstance.SystemState == Foundation.BusinessObjects.ChecklistInstanceSystemState.Closed
                            || material.CurrentChecklistInstance.UniversalState == Foundation.Common.Base.UniversalState.Terminated)
                        {
                            materialsAtResource.Add(material);
                        }

                        break;
                    }
                case "CustomStopMaterial":
                    {
                        CustomStopMaterialOutput output = IKEADEEActionUtilities.GetInputItem<CustomStopMaterialOutput>(Input, "CustomStopMaterialOutput");

                        IMaterial material = output.Material;

                        resource = material.LastProcessedResource;

                        if (resource != null)
                        {
                            materialsAtResource.AddRange(ikeaUtilities.GetAttachedMaterialsFromConsumptionSources(resource));
                        }

                        break;
                    }

                default:
                    break;
            }

            if (!materialsAtResource.IsNullOrEmpty())
            {

                // Only use materials in the state MSM -> SETUP and organize the list so that the GroupMOs only appear after the childMOs
                materialsToValidate.AddRange(materialsAtResource.Where(mr => mr.SystemState == MaterialSystemState.InProcess).OrderBy(m => m.IsGroupMO()));

                if (isToNotify)
                {
                    // Add all other materials to validate
                    materialsToValidate.AddRange(materialsAtResource.Where(mr => mr.SystemState != MaterialSystemState.InProcess));
                }
            }

            // Check if there are any materials to be validated
            if (!materialsToValidate.IsNullOrEmpty())
            {
                Dictionary<IMaterial, Dictionary<string, bool>> validatedMaterials = ikeaUtilities.IsOrderSetup(materialsToValidate, isToNotify);

                if (isToNotify)
                {
                    // Remove the added materials that are not in the state InProcess
                    validatedMaterials = validatedMaterials.Where(m => m.Key.SystemState == MaterialSystemState.InProcess).ToDictionary(m => m.Key, m => m.Value);
                }

                // Get automation request timeout
                int requestTimeout = genericUtilities.GetConfigurationValueByPath<int>(IKEAConstants.ReadyToStartSendRequestDefaultTimeout);

                IMaterialCollection materials = entityFactory.CreateCollection<IMaterialCollection>();
                materials.AddRange(validatedMaterials.Keys);

                // Load Material setup indicator attributes:
                materials.LoadAttributes(new Collection<string>()
                {
                    IKEAConstants.CustomMaterialAttributeCheckListCorrectlySetup,
                    IKEAConstants.CustomMaterialAttributeConsumablesCorrectlySetup,
                    IKEAConstants.CustomMaterialAttributeDurablesCorrectlySetup,
                    IKEAConstants.CustomMaterialAttributeIsReadyForProduction
                });

                // Go one by one in the materials to change the attribute IsReadyForProduction and to communicate to automation
                foreach (var validatedMaterial in validatedMaterials)
                {
                    IAttributeCollection attributesToSave = new AttributeCollection();

                    IMaterial material = validatedMaterial.Key;

                    bool checkListCorrectlySetup = false;
                    bool consumableCorrectlySetup = false;
                    bool durableCorrectlySetup = false;
                    bool materialCorrectlySetup = false;
                    if (!material.IsGroupMO())
                    {
                        //Get the state from all indicators (Checklist, Consumable and Durable are setup correctly) (Consumable should be true if Direct Feeding is correctly configured):                  
                        checkListCorrectlySetup = validatedMaterial.Value[IKEAConstants.CustomMaterialAttributeCheckListCorrectlySetup];
                        consumableCorrectlySetup = directFeedingUtilities.VerifyDirectFeedingConsumablesAttachToStart(material, validatedMaterial.Value[IKEAConstants.CustomMaterialAttributeConsumablesCorrectlySetup]);
                        validatedMaterial.Value[IKEAConstants.CustomMaterialAttributeConsumablesCorrectlySetup] = consumableCorrectlySetup;
                        durableCorrectlySetup = validatedMaterial.Value[IKEAConstants.CustomMaterialAttributeDurablesCorrectlySetup];
                        materialCorrectlySetup = !validatedMaterial.Value.Where(VM => VM.Value == false).Any();

                        //If any setup is not correct and if material is a part of a GroupMO, change status of the GroupMO itself
                        if (material.IsChildOfGroupMO())
                        {
                            IAttributeCollection attributesToSaveInGroupMO = new AttributeCollection();
                            IMaterial groupMO = material.GetGroupMOFromChild();
                            if (!checkListCorrectlySetup)
                                attributesToSaveInGroupMO.Add(IKEAConstants.CustomMaterialAttributeCheckListCorrectlySetup, checkListCorrectlySetup);
                            if (!consumableCorrectlySetup)
                                attributesToSaveInGroupMO.Add(IKEAConstants.CustomMaterialAttributeConsumablesCorrectlySetup, consumableCorrectlySetup);
                            if (!durableCorrectlySetup)
                                attributesToSaveInGroupMO.Add(IKEAConstants.CustomMaterialAttributeDurablesCorrectlySetup, durableCorrectlySetup);
                            if (!materialCorrectlySetup)
                                attributesToSaveInGroupMO.Add(IKEAConstants.CustomMaterialAttributeIsReadyForProduction, materialCorrectlySetup);

                            groupMO.SaveAttributes(attributesToSaveInGroupMO);
                        }
                    }
                    else
                    {
                        material.Load();
                        IMaterialCollection childMOs = ikeaUtilities.GetChildMaterialsFromGroupMO(material);
                        childMOs.LoadAttributes(new Collection<string>()
                        {
                            IKEAConstants.CustomMaterialAttributeCheckListCorrectlySetup,
                            IKEAConstants.CustomMaterialAttributeConsumablesCorrectlySetup,
                            IKEAConstants.CustomMaterialAttributeDurablesCorrectlySetup,
                            IKEAConstants.CustomMaterialAttributeIsReadyForProduction
                        });

                        // False if any of the childMOs are not ready for production
                        materialCorrectlySetup = childMOs.All(c => c.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomMaterialAttributeIsReadyForProduction));
                        checkListCorrectlySetup = childMOs.All(c => c.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomMaterialAttributeCheckListCorrectlySetup));
                        consumableCorrectlySetup = childMOs.All(c => c.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomMaterialAttributeConsumablesCorrectlySetup));
                        durableCorrectlySetup = childMOs.All(c => c.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomMaterialAttributeDurablesCorrectlySetup));
                    }

                    // Check if the Checklist status value has changed. If so, add it to attributesToSave list.
                    if (material.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomMaterialAttributeCheckListCorrectlySetup) != checkListCorrectlySetup)
                    {
                        attributesToSave.Add(IKEAConstants.CustomMaterialAttributeCheckListCorrectlySetup, checkListCorrectlySetup);
                    }
                    // Check if the Consumable status value has changed. If so, add it to attributesToSave list.
                    if (material.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomMaterialAttributeConsumablesCorrectlySetup) != consumableCorrectlySetup)
                    {
                        attributesToSave.Add(IKEAConstants.CustomMaterialAttributeConsumablesCorrectlySetup, consumableCorrectlySetup);
                    }
                    // Check if the Durable status value has changed. If so, add it to attributesToSave list.
                    if (material.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomMaterialAttributeDurablesCorrectlySetup) != durableCorrectlySetup)
                    {
                        attributesToSave.Add(IKEAConstants.CustomMaterialAttributeDurablesCorrectlySetup, durableCorrectlySetup);
                    }

                    // Check if the overall status value has changed. If so, send it to automation and add it to attributesToSave list.
                    if (material.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomMaterialAttributeIsReadyForProduction) != materialCorrectlySetup)
                    {
                        attributesToSave.Add(IKEAConstants.CustomMaterialAttributeIsReadyForProduction, materialCorrectlySetup);

                        // Check if the resource automation is online
                        if (material.LastProcessedResource != null
                        && !material.IsChildOfGroupMO()
                        && material.LastProcessedResource.AutomationMode == ResourceAutomationMode.Online
                        && requestTimeout > -1
                        && !currentContext.MethodName.Equals("ComplexTrackInMaterials"))
                        {
                            IAutomationControllerInstance controllerInstance = material.LastProcessedResource.GetAutomationControllerInstance();

                            if (controllerInstance != null)
                            {
                                Dictionary<string, object> materialDetails = new Dictionary<string, object>();


                                materialDetails.Add(IKEAConstants.ReadyToStartMaterialName, material.Name);
                                materialDetails.Add(IKEAConstants.ReadyToStartIsReadyForProduction, materialCorrectlySetup);

                                // Send Asynchronous request to automation
                                controllerInstance.Publish(IKEAConstants.AutomationRequestTypeReadyToStart, materialDetails.ToJsonString());
                            }
                        }
                    }

                    if (!attributesToSave.IsNullOrEmpty())
                    {
                        material.SaveAttributes(attributesToSave);
                    }
                }
            }

            //---End DEE Code---

            return Input;
        }
    }
}
