﻿using Cmf.Custom.IKEA.Common;
using Cmf.Navigo.BusinessObjects;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Custom.IKEA.Common.Abstractions;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using Microsoft.Extensions.DependencyInjection;

namespace Cmf.Custom.IKEA.Actions.Materials
{
    public class CustomReleaseAllMaterialsFromBatch : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Action to be release all the associated materials of a batch when using the configured batch complete hold reason
            /// Action Groups:
            ///     BusinessObjects.Material.Release.Post
            /// </summary>
            #endregion

            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];

            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.Material.Release.Post"
            };

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            IMaterial material = IKEADEEActionUtilities.GetInputItem<IMaterial>(Input, "Material");
            IMaterialHoldReasonCollection materialHoldReasons = IKEADEEActionUtilities.GetInputItem<IMaterialHoldReasonCollection>(Input, "MaterialHoldReasonCollection");

            // Validate inputs
            if (executionVeridict && material == null && materialHoldReasons == null)
            {
                executionVeridict = false;
            }

            // Get Configured Batch Form
            string batchForm = genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.BatchMaterialForm);
            // Get the configured complete batch hold reason
            string batchHoldReason = genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.BatchCompleteHoldReason);

            // Validate Form and reason
            if (executionVeridict && !material.Form.CompareStrings(batchForm)
                                    && !materialHoldReasons.Where(mh => mh.TargetEntity.Name == batchHoldReason).Any())
            {
                executionVeridict = false;
            }
                   
            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            //System
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IMaterialHoldReasonCollection materialHoldReasons = IKEADEEActionUtilities.GetInputItem<IMaterialHoldReasonCollection>(Input, "MaterialHoldReasonCollection");
            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            // Get the configured complete batch hold reason
            string batchHoldReason = genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.BatchCompleteHoldReason);

            IMaterialHoldReason materialHoldReason = materialHoldReasons.Where(mh => mh.TargetEntity.Name == batchHoldReason).FirstOrDefault();

            // Releases all the batch related materials that are on hold
            ikeaUtilities.BatchReleaseRelatedMaterials(materialHoldReason.SourceEntity, materialHoldReason.TargetEntity);

            //---End DEE Code---

            return Input;
        }

    }
}
