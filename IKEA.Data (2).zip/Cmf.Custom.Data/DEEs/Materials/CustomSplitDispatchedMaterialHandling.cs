﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.Materials
{
    class CustomSplitDispatchedMaterialHandling : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text:
            /// Sets the correct MaterialResource Order when splitting materials that are already dispatched
            /// Action Groups:
            /// BusinessObjects.MaterialCollection.Split.Pre
            /// BusinessObjects.MaterialCollection.Split.Post
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.MaterialCollection.Split.Pre",
                "BusinessObjects.MaterialCollection.Split.Post",
            };

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);
            if (executionVeridict 
                && IKEADEEActionUtilities.GetInputItem<Dictionary<IMaterial, ISplitInputParametersCollection>>(Input, "ChildMaterialsInformation") == null
                && IKEADEEActionUtilities.GetInputItem<Dictionary<IMaterial, IMaterialCollection>>(Input, "OutputChildMaterials") == null)
            {
                executionVeridict = false;
            }
            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code--- 
UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
            //Foundation
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("", "Cmf.Foundation.Common");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();
            DeeContext currentContext = deeContextUtilities.SetCurrentServiceContext("CustomSplitDispatchedMaterialHandling");
            string contextParameterName = "CustomSplitDispatchedMaterialHandling_ResourceMaterialInformation";

            // PRE - If the main material is dispatched, saves the resource, main material and its order on ContextParameter:
            if (currentContext.TriggerPoint == DeeTriggerPoint.Pre)
            {
                // Get Split materials information from Input:
                Dictionary<IMaterial, ISplitInputParametersCollection> childMaterialsInformation = Input["ChildMaterialsInformation"] as Dictionary<IMaterial, ISplitInputParametersCollection>;

                Dictionary<string, IResourceMaterialInformation> resourceMainMaterialOrders = new Dictionary<string, IResourceMaterialInformation>();

                if (!childMaterialsInformation.IsNullOrEmpty())
                {                    
                    foreach (var childMaterialInformation in childMaterialsInformation)
                    {
                        // Check if material is dispatched:
                        if (childMaterialInformation.Key.SystemState == MaterialSystemState.Dispatched)
                        {

                            // Get main material:
                            IMaterial mainMaterial = childMaterialInformation.Key;
                                        
                            if (mainMaterial.HasRelations("MaterialResource", true))
                            {
                                // Get resource from relation:             
                                IResource resource = mainMaterial.RelationCollection["MaterialResource"][0].TargetEntity as IResource;

                                // Get all the materials in the resource:
                                IResourceMaterialInformationCollection resourceMaterialInformationCollection = resource.GetResourceMaterialInformation(false);
                                
                                // Gets the MaterialResource information for the main material:
                                IResourceMaterialInformation resourceMaterialInformation = resourceMaterialInformationCollection.Where(x => x.Material.Id == mainMaterial.Id).First();

                                // Fill dictionary:
                                resourceMainMaterialOrders.Add(resource.Name, resourceMaterialInformation);
                            }
                        }
                    }
                }

                // Save Resources, MainMaterials and MaterialResource Orders for Split-Post:
                deeContextUtilities.SetContextParameter(contextParameterName, resourceMainMaterialOrders);
            }

            // POST - Sets the correct order for the materials:
            if (currentContext.TriggerPoint == DeeTriggerPoint.Post)
            {
                // Get child materials from  Input:
                Dictionary<IMaterial, IMaterialCollection> childMaterials = IKEADEEActionUtilities.GetInputItem<Dictionary<IMaterial, IMaterialCollection>>(Input, "OutputChildMaterials");
                
                // Get Information from Split-Pre ContextParameter:
                Dictionary<string, IResourceMaterialInformation> resourceMainMaterialOrders = deeContextUtilities.GetContextParameter(contextParameterName) as Dictionary<string, IResourceMaterialInformation>;

                if (!resourceMainMaterialOrders.IsNullOrEmpty() && !childMaterials.IsNullOrEmpty())
                {
                    foreach (var resourceMainMaterialOrder in resourceMainMaterialOrders)
                    {
                        // The resource where the main material is dispatched:
                        IResource resource = entityFactory.Create<IResource>();
                        
                        resource.Name = resourceMainMaterialOrder.Key;
                        
                        resource.Load();

                        // select only the splitted materials for the main material:
                        IMaterialCollection splitMaterials = entityFactory.CreateCollection<IMaterialCollection>();
                        splitMaterials.AddRange(childMaterials.Where(x => x.Key.Name.Equals(resourceMainMaterialOrder.Value.Material.Name)).SelectMany(y => y.Value));

                        // Get the main material actual order:
                        int order = resourceMainMaterialOrder.Value.Order;

                        IResourceMaterialManageCollection resourceMaterialManages = new ResourceMaterialManageCollection();

                        // The splitted materials will be after the main material order:
                        foreach (var splitMaterial in splitMaterials)
                        {
                            resourceMaterialManages.Add(
                            new ResourceMaterialManage
                            {
                                Material = splitMaterial,
                                Order = ++order
                            }
                            );
                        }
                        resource.ManageMaterialOrder(resourceMaterialManages);
                    }
                }
            }

            //---End DEE Code---

            return Input;
        }






    }
}
