﻿using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Extensions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessOrchestration.ResourceManagement.InputObjects;
using Cmf.Navigo.BusinessOrchestration.ResourceManagement.OutputObjects;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Common.CustomActionUtilities;
using Cmf.Foundation.Common;
using Cmf.Custom.IKEA.Orchestration.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Exceptions;


namespace Cmf.Custom.IKEA.Actions.Materials
{
    public class CustomMaterialOverProductionChangeQuantity : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info

            /// <summary>
            /// Summary text:  On Manage Consumable Feeds verify if Resource is in Overproduction and increase MO quantity accordingy
            ///     
            /// Action Groups:   ResourceManagement.ResourceManagementOrchestration.ManageResourceConsumableFeeds.Post
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "ResourceManagement.ResourceManagementOrchestration.ManageResourceConsumableFeeds.Post",
                "ResourceManagement.ResourceManagementOrchestration.AttachConsumableToResource.Post",
                "ResourceManagement.ResourceManagementOrchestration.AttachConsumablesToResource.Post"
            };
            // Check if the functionality is enabled and if is being executed by the right action group
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            if (executionVeridict && IKEADEEActionUtilities.GetInputItem<ManageResourceConsumableFeedsInput>(Input, "ManageResourceConsumableFeedsInput") == null
                                  && IKEADEEActionUtilities.GetInputItem<AttachConsumablesToResourceOutput>(Input, "AttachConsumablesToResourceOutput") == null
                                  && IKEADEEActionUtilities.GetInputItem<AttachConsumableToResourceOutput>(Input, "AttachConsumableToResourceOutput") == null)
            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Exceptions");
UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            //Foundation
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "");
            UseReference("", "Cmf.Foundation.Common.Exceptions");
            UseReference("", "Cmf.Foundation.Common");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.ResourceManagement");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.ResourceManagement.InputObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.ResourceManagement.OutputObjects");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Extensions");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetRequiredService<IEntityFactory>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IDirectFeedingUtilities directFeedingUtilities = serviceProvider.GetService<IDirectFeedingUtilities>();
            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();

            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();
            ManageResourceConsumableFeedsInput manageResourceConsumableFeedsInput = IKEADEEActionUtilities.GetInputItem<ManageResourceConsumableFeedsInput>(Input, "ManageResourceConsumableFeedsInput");
            AttachConsumablesToResourceOutput attachConsumablesToResourceOutput = IKEADEEActionUtilities.GetInputItem<AttachConsumablesToResourceOutput>(Input, "AttachConsumablesToResourceOutput");
            AttachConsumableToResourceOutput attachConsumableToResourceOutput = IKEADEEActionUtilities.GetInputItem<AttachConsumableToResourceOutput>(Input, "AttachConsumableToResourceOutput");

            Dictionary<IResource, IMaterialCollection> resourceConsumables = new Dictionary<IResource, IMaterialCollection>();

            if (manageResourceConsumableFeedsInput != null && !manageResourceConsumableFeedsInput.ConsumablesToAttach.IsNullOrEmpty())
            {
                resourceConsumables = manageResourceConsumableFeedsInput.ConsumablesToAttach;
            }
            else if (attachConsumablesToResourceOutput != null)
            {
                resourceConsumables.Add(attachConsumablesToResourceOutput.Resource, attachConsumablesToResourceOutput.Materials);
            }
            else if (attachConsumableToResourceOutput != null)
            {
                var attachConsumableToResourceOutputMaterialCollection = entityFactory.CreateCollection<IMaterialCollection>();
                attachConsumableToResourceOutputMaterialCollection.Add(attachConsumableToResourceOutput.Material);
                resourceConsumables.Add(attachConsumableToResourceOutput.Resource, attachConsumableToResourceOutputMaterialCollection);
            }

            if (resourceConsumables.Count > 0 && resourceConsumables.First().Value.Count() > 0)
            {
                foreach (IResource resource in resourceConsumables.Keys)
                {
                    resource.Load();
                    IResource topMost = resource.GetTopMostResource();
                    topMost.Load();

                    topMost.LoadAttributes(new Collection<string> { IKEAConstants.MESAutomationInFeederSubResourceController,
                                                                    IKEAConstants.WorkCenter,
                                                                    IKEAConstants.CustomAllowAlternativeOverproduction });
                    string resourceName = topMost.GetAttributeValueOrDefault<string>(IKEAConstants.MESAutomationInFeederSubResourceController, false);
                    string workcenter = topMost.GetAttributeValueOrDefault<string>(IKEAConstants.WorkCenter, false);
                    bool isAlternateOverproductionActive = topMost.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomAllowAlternativeOverproduction, false);

                    // Validate that top most resource is set to Overproduction
                    if (!resourceName.IsNullOrEmpty() && !resourceConsumables[resource].IsNullOrEmpty() && !isAlternateOverproductionActive)
                    {
                        IResource subResourceController = entityFactory.Create<IResource>();
                        subResourceController.Name = resourceName;

                        // Validate that resource is valid for overproduction
                        if (subResourceController.ObjectExists())
                        {
                            subResourceController.Load();

                            //Validate if resource is not online and subResourceController is not online
                            if (topMost.AutomationMode != ResourceAutomationMode.Online && subResourceController.AutomationMode != ResourceAutomationMode.Online)
                            {
                                // Get all the materials in process in main resource
                                List<int> systemStatesInProgress = new List<int>();
                                systemStatesInProgress.Add((int)MaterialSystemState.InProcess);
                                //Query for all materials in progress on the Resource
                                IMaterialCollection materialsInProcess = ikeaUtilities.GetMaterialsInProgressOnMainLine(topMost.Id, systemStatesInProgress, true);


                                if (!materialsInProcess.IsNullOrEmpty())
                                {
                                    //// Get materials InProcess but exclude orders that belong to group MOs:
                                    IMaterial consumable = resourceConsumables[resource].FirstOrDefault();
                                    IMaterial materialMO = ikeaUtilities.GetMaterialInProcessFromConsumable(resource, consumable, topMost);

                                    // Throw exception if mo is not valid
                                    if (materialMO == null)
                                    {
                                        throw new IKEAException(IKEAConstants.CustomOrderCouldNotBeRetrievedFromConsumable, consumable.Name);
                                    }
                                    materialMO.Load();

                                    // Get list of the products of the respective bom products of the selected material in process (if GroupMO then use the first child)
                                    IBOM currentMaterialBom = entityFactory.Create<IBOM>();
                                    if (materialMO.IsGroupMO())
                                    {
                                        IMaterial materialChild = ikeaUtilities.GetChildMaterialsFromGroupMO(materialMO).FirstOrDefault();
                                        currentMaterialBom = materialChild.Product.ResolveBomContexts(materialChild).Bom;
                                    } else {
                                        currentMaterialBom = materialMO.Product.ResolveBomContexts(materialMO).Bom;
                                    }

                                    currentMaterialBom.LoadRelations("BOMProduct");
                                    IProductCollection bomProducts = entityFactory.CreateCollection<IProductCollection>();
                                    bomProducts.AddRange(currentMaterialBom.BomProducts.Select(bp => bp.TargetEntity));

                                    // Only calculate the quantity attached for the selected material in process in case there is multiple materials in process
                                    IResourceMaterialInformationCollection resourceMaterialInformation = subResourceController.GetResourceMaterialInformation(false);
                                    decimal palletsQuantityAttachedOnSubResourceController = resourceMaterialInformation.Where(x => bomProducts.Contains(x.Material.Product)).Sum(x => x.Material.PrimaryQuantity.Value);

                                    // Get WorkCenter from PO if config is set to true
                                    IProductionOrder po = materialMO.ProductionOrder;
                                    bool validateWorkCenterAtDispatch = genericUtilities.GetConfigurationValueByPath<bool>(IKEAConstants.ValidateWorkCenterAtDispatch);
                                    if (validateWorkCenterAtDispatch)
                                    {
                                        po.LoadAttribute(IKEAConstants.CustomProductionOrderAttributeDefaultWorkCenter);
                                        workcenter = po.GetAttributeValueOrDefault<string>(IKEAConstants.CustomProductionOrderAttributeDefaultWorkCenter);
                                    }

                                    // Resolve ST CustomOverProductionResolution for Overproduction limit
                                    Tuple<decimal, decimal?> resultOverProduction = ikeaUtilities.ResolveCustomOverProductionResolution(facilityToResolve: topMost.Area.Facility,
                                                                                                                                areaToResolve: topMost.Area,
                                                                                                                                resourceToResolve: topMost,
                                                                                                                                workcenter: workcenter,
                                                                                                                                productToResolve: materialMO.Product,
                                                                                                                                productGroupToResolve: materialMO.Product.ProductGroup);

                                    if (ikeaUtilities.IsToExecuteOverProduction(resultOverProduction))
                                    {
                                        if (materialMO.IsGroupMO())
                                        {
                                            ikeaUtilities.UpdateGroupMOPrimaryQuantityOverProductionManual(palletsQuantityAttachedOnSubResourceController, resultOverProduction, materialMO, topMost);
                                        }
                                        else
                                        {
                                            // Verify if it is direct feeding, and second line, if true, overproduction should be blocked
                                            bool isToBlockOverproduction = genericUtilities.DirectFeedingIsDirectFeedingAndSecondLine(topMost, materialMO);
                                            if (!isToBlockOverproduction)
                                            {
                                                ikeaUtilities.UpdateMOPrimaryQuantityOverProductionManual(palletsQuantityAttachedOnSubResourceController, resultOverProduction, materialMO, topMost);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

            }
            //---End DEE Code---

            return Input;
        }

    }
}
