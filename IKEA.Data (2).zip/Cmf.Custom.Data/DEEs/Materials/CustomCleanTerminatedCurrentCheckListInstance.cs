﻿using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;

namespace Cmf.Custom.IKEA.Actions.Materials
{
    public class CustomCleanTerminatedCurrentCheckListInstance : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Changes the CurrentChecklistInstance value to null in all materials that were resolved by DEE CustomValidateCurrentChecklistIntanceState
            /// Action Groups:
            ///     BusinessObjects.MaterialCollection.ChangeProductionOrder.Post
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.MaterialCollection.ChangeProductionOrder.Post"
            };

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            if (executionVeridict && IKEADEEActionUtilities.GetInputItem<IMaterialCollection>(Input, "MaterialCollection") == null)
            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
     

            //System
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("", "System.Linq");
            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();
            
            string contextFeedbackMessages = "CustomValidateCurrentCheckListInstanceState_MaterialCollection";
            IMaterialCollection contextMaterials = deeContextUtilities.GetContextParameter(contextFeedbackMessages) as IMaterialCollection;

            if (contextMaterials != null)
            {
                IMaterialCollection materials = Input["MaterialCollection"] as IMaterialCollection;

                var myCollectedIds = contextMaterials.Select(E => E.Id);
                Dictionary<long, IMaterial> materialDictionary = materials.ToDictionary(E => E.Id, E => E);
                var matIDsToChange = myCollectedIds.Intersect(materialDictionary.Keys);
                foreach (var materialId in matIDsToChange)
                {
                    materialDictionary[materialId].CurrentChecklistInstance = null;
                }

            }

            

            //---End DEE Code---

            return Input;
        }
    }
}
