﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Exceptions;
using Cmf.Custom.IKEA.Common.Extensions;
using Cmf.Foundation.BusinessOrchestration;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.Materials
{
    public class CustomValidateFlowPathAtPreDispatch : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Validates in a smart table is the material flow path is the best. If there's a better flow path this material value is changed
            /// Action Groups:
            ///     BusinessObjects.MaterialCollection.Dispatch.Pre
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.MaterialCollection.Dispatch.Pre"
            };

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            if (executionVeridict && IKEADEEActionUtilities.GetInputItem<Dictionary<IMaterial, IDispatchMaterialParameters>>(Input, "MaterialDispatchParameters") == null)
            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Exceptions");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            //System
            UseReference("", "System");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("", "System.Linq");
            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Extensions");
            //Foundation
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration");
            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            Dictionary<IMaterial, IDispatchMaterialParameters> dictiorary = Input["MaterialDispatchParameters"] as Dictionary<IMaterial, IDispatchMaterialParameters>;
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();

            IMaterial material = entityFactory.Create<IMaterial>();
            IResource resource = entityFactory.Create<IResource>();
            FeedbackMessage feedbackMessage = null;
            Dictionary<IMaterial, FeedbackMessage> keyValuePairs = new Dictionary<IMaterial, FeedbackMessage>();

            foreach (var keyValuePair in dictiorary)
            {
                material = keyValuePair.Key;
                resource = keyValuePair.Value.Resource;
                material.Load();
                string workCenter = null;

                // Get WorkCenter from PO if config is set to true
                IProductionOrder po = material.ProductionOrder;
                bool validateWorkCenterAtDispatch = genericUtilities.GetConfigurationValueByPath<bool>(IKEAConstants.ValidateWorkCenterAtDispatch);
                if (po != null && validateWorkCenterAtDispatch)
                {
                    po.LoadAttribute(IKEAConstants.CustomProductionOrderAttributeDefaultWorkCenter);
                    workCenter = po.GetAttributeValueOrDefault<string>(IKEAConstants.CustomProductionOrderAttributeDefaultWorkCenter);
                }
                else
                {
                    resource.LoadAttribute(IKEAConstants.CustomResourceAttributeWorkCenter);
                    workCenter = resource.GetAttributeValueOrDefault<string>(IKEAConstants.CustomResourceAttributeWorkCenter);
                }

                string resolvedFlowPath = ikeaUtilities.ResolveMaterialFlow(material.Facility, material.Product, resource, material.Type, workCenter);

                if (resolvedFlowPath != null && material.FlowPath != resolvedFlowPath)
                {
                    IStep step = genericUtilities.GetStepByFlowPath(resolvedFlowPath);

                    IFlow flow = genericUtilities.GetFlowsInFlowPath(resolvedFlowPath, false).Last();
                    flow.Load();

                    // Set flag to ignore label printing validation during the auto dispatch
                    deeContextUtilities.SetContextParameter(IKEAConstants.PreDispatchUtilityIgnoreLabelPrintingValidation, true);

                    // Change material flowpath
                    material.ChangeFlowAndStep(flow, resolvedFlowPath, step, null);

                    IMaterialCollection materials = resource.GetDispatchList(0);

                    var materialToDispatch = materials.Where(x => x.Id == material.Id);
                    if (materialToDispatch == null)
                    {
                        throw new IKEAException(IKEAConstants.CustomValidateFlowPathAtPreDispatchFlowPathNotChanged, flow.Name, step.Name, material.Form, material.Name, material.RequiredService.Name, resource.Name);
                    }
                    else
                    {
                        feedbackMessage = new FeedbackMessage
                        {
                            MessageType = FeedbackMessageType.Information,
                            Message = ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomValidateFlowPathAtPreDispatchFlowPathChanged, material.Form, material.Name, flow.Name, step.Name)
                        };

                        keyValuePairs.Add(material, feedbackMessage);
                    }
                }

            }

            if (keyValuePairs != null)
            {
                deeContextUtilities.SetContextParameter("CustomValidateFlowPathAtPreDispatch_FeedbackMessages", keyValuePairs);
            }

            //---End DEE Code---

            return Input;
        }

       
    }
}
