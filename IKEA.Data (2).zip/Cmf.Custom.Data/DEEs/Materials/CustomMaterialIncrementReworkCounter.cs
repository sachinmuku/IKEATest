﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Extensions;
using Cmf.Custom.IKEA.Common.Utilities;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessOrchestration;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.Materials
{
    public class CustomMaterialIncrementReworkCounter : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Action to increment the rework counter of the materials
            /// Action Groups:
            ///     BusinessObjects.MaterialCollection.ChangeType.Pre
            ///     BusinessObjects.MaterialCollection.ChangeType.Post
            /// </summary>
            #endregion

            return true;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Extensions");
            //System
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("", "System.IO");
            UseReference("", "System.Threading");
            UseReference("", "System");

            //Foundation

            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();

            string contextMaterialReworkIncrement = "CustomMaterialIncrementReworkCounter_ReworkToIncrement";
            string contextMaterialReworkDecrement = "CustomMaterialIncrementReworkCounter_ReworkToDecrement";

            DeeContext currentContext = deeContextUtilities.SetCurrentServiceContext("CustomMaterialIncrementReworkCounter");

            Dictionary<IMaterial, string> materialTypes = null;

            IMaterialCollection materialsToIncrementRework = null;
            IMaterialCollection materialsToDecrementRework = null;

            if (Input.ContainsKey("MaterialTypes"))
            {
                materialTypes = Input["MaterialTypes"] as Dictionary<IMaterial, string>;

                if (currentContext.TriggerPoint == DeeTriggerPoint.Pre)
                {
                    materialsToIncrementRework = entityFactory.CreateCollection<IMaterialCollection>();
                    materialsToDecrementRework = entityFactory.CreateCollection<IMaterialCollection>();

                    // Obtain the materials where the rework counter should be incremented (the new type is rework and is different from the previous type)
                    materialsToIncrementRework.AddRange(materialTypes.Where(mt => (mt.Value == "Rework" || mt.Value == "Repair" || mt.Value == "DirectRepair")
                        && mt.Key.Type != "Rework" && mt.Key.Type != "Repair" && mt.Key.Type != "DirectRepair").Select(mt => mt.Key));

                    deeContextUtilities.SetContextParameter(contextMaterialReworkIncrement, materialsToIncrementRework);

                    // Obtain the materials where the rework counter should be decremented (the old type is rework and the new one is different than rework)
                    materialsToDecrementRework.AddRange(materialTypes.Where(mt => mt.Value != "Repair" && mt.Value != "Rework" && mt.Value != "DirectRepair" &&
                        (mt.Key.Type == "Rework" || mt.Key.Type == "Repair" || mt.Key.Type == "DirectRepair")).Select(mt => mt.Key));

                    deeContextUtilities.SetContextParameter(contextMaterialReworkDecrement, materialsToDecrementRework);
                }
                else if (currentContext.TriggerPoint == DeeTriggerPoint.Post)
                {
                    materialsToIncrementRework = deeContextUtilities.GetContextParameter(contextMaterialReworkIncrement) as IMaterialCollection;
                    materialsToDecrementRework = deeContextUtilities.GetContextParameter(contextMaterialReworkDecrement) as IMaterialCollection;

                    if (!materialsToIncrementRework.IsNullOrEmpty())
                    {
                        materialsToIncrementRework.LoadAttributes(new Collection<string>() { IKEAConstants.CustomMaterialAttributeReworkCounter });

                        foreach (IMaterial material in materialsToIncrementRework)
                        {
                            //Since this is on Post, rework counter is set to +1
                            int reworkCounter = material.GetAttributeValueOrDefault<int>(IKEAConstants.CustomMaterialAttributeReworkCounter) + 1;

                            IAttributeCollection attributes = new AttributeCollection
                            {
                                { IKEAConstants.CustomMaterialAttributeReworkCounter, reworkCounter }
                            };

                            material.SaveAttributes(attributes);

                            // Check if Feature is On
                            bool reworkCountTracking = genericUtilities.GetConfigurationValueByPath<bool>(IKEAConstants.CustomReworkCountTracking);

                            if (reworkCountTracking)
                            {
                                // Get the HoldReason name from config
                                string reworkCountTrackingReason = genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.CustomReworkHoldReason);

                                if (!string.IsNullOrEmpty(reworkCountTrackingReason))
                                {
                                    IReason reason = entityFactory.Create<IReason>(); 
                                    reason.Name = reworkCountTrackingReason;
                                    reason.Load();
                                    material.LoadRelations("MaterialHoldReason");
                                    if (material.MaterialHoldReasons == null || material.MaterialHoldReasons.Any(ER => ER.GetNativeValue<long>("TargetEntity") != reason.Id))
                                    {
                                        IArea area = null;
                                        IStep step = material.Step;
                                        if (step != null)
                                        {
                                            // Get Area from step
                                            area = step.GetFacilityArea(material.Facility);
                                        }

                                        // Get the maximum allowed reworks from the smart table
                                        int? maxReworkPossible = ikeaUtilities.ResolveMaximumAllowedReworks(material.Facility.Name, area.Name);

                                        // Check if the rework count is inferior to the max allowed
                                        if (maxReworkPossible != null && reworkCounter >= maxReworkPossible)
                                        {
                                            //Set Material on Hold
                                            var materialHoldCollection = entityFactory.CreateCollection<IMaterialHoldReasonCollection>();
                                            var materialHold = entityFactory.Create<IMaterialHoldReason>();
                                            materialHold.SourceEntity = material;
                                            materialHold.TargetEntity = reason;
                                            materialHoldCollection.Add(materialHold);

                                            material.Hold(materialHoldCollection);
                                        }
                                    }
                                }
                            }
                        }
                    }

                    if (!materialsToDecrementRework.IsNullOrEmpty())
                    {
                        materialsToDecrementRework.LoadAttributes(new Collection<string>() { IKEAConstants.CustomMaterialAttributeReworkCounter });

                        foreach (IMaterial material in materialsToDecrementRework)
                        {
                            int reworkCounter = material.GetAttributeValueOrDefault<int>(IKEAConstants.CustomMaterialAttributeReworkCounter);

                            IAttributeCollection attributes = new AttributeCollection
                            {
                                { IKEAConstants.CustomMaterialAttributeReworkCounter, reworkCounter - 1 }
                            };

                            material.SaveAttributes(attributes);
                        }
                    }
                }
            }

            //---End DEE Code---

            return Input;
        }


    }
}
