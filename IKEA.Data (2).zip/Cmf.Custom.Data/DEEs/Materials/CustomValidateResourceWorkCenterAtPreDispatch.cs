﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.BusinessObjects;
using Cmf.Custom.IKEA.BusinessObjects.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Extensions;
using Cmf.Foundation.BusinessOrchestration;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;



namespace Cmf.Custom.IKEA.Actions.Materials
{
    public class CustomValidateResourceWorkCenterAtPreDispatch : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Validates if the PO WorkCenter is the same that the WorkCenter of the Resource to dispatch.
            /// Action Groups:
            ///     BusinessObjects.MaterialCollection.Dispatch.Pre
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.MaterialCollection.Dispatch.Pre"
            };

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            if (executionVeridict && IKEADEEActionUtilities.GetInputItem<Dictionary<IMaterial, IDispatchMaterialParameters>>(Input, "MaterialDispatchParameters") == null)
            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            //System
            UseReference("", "Cmf.Custom.IKEA.BusinessObjects.Abstractions");
UseReference("", "System");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("", "System.Linq");
            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Extensions");
            UseReference("Cmf.Custom.IKEA.BusinessObjects.CustomPOOperationResource.dll", "Cmf.Custom.IKEA.BusinessObjects");
            //Foundation
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration");
            UseReference("Cmf.Foundation.Common.dll", "Cmf.Foundation.Common");
            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();

            Dictionary<IMaterial, IDispatchMaterialParameters> dictionary = Input["MaterialDispatchParameters"] as Dictionary<IMaterial, IDispatchMaterialParameters>;

            IMaterial material = entityFactory.Create<IMaterial>();
            IResource resource = entityFactory.Create<IResource>();
            IProductionOrder productionOrder = entityFactory.Create<IProductionOrder>();

            Dictionary<IMaterial, FeedbackMessage> keyValuePairs = new Dictionary<IMaterial, FeedbackMessage>();

            foreach (var keyValuePair in dictionary)
            {

                //data from input:
                material = keyValuePair.Key;
                resource = keyValuePair.Value.Resource;
                productionOrder = keyValuePair.Key.ProductionOrder;

                //Get the current material Flow and its associated ERPOperationCode:
                string materialCurrentERPOperationCode = material.GetCurrentERPOperationCode();

                if (productionOrder != null && !materialCurrentERPOperationCode.IsNullOrEmpty())
                {

                    //If the material has a current ERPOperationCode, gets all the PO relations of type 'CustomPOOperationResource'
                    productionOrder.LoadRelations();
                    if (productionOrder.RelationCollection != null)
                    {

                        //Checks if the PO has relations of type 'CustomPOOperationResource'. If not, do not validate. No error.
                        if (productionOrder.RelationCollection.ContainsKey(IKEAConstants.CustomPOOperationResource))
                        {

                            //Loads all 'CustomPOOperationResource' relations:
                            var relationsOperationResource = productionOrder.RelationCollection[IKEAConstants.CustomPOOperationResource].Select(E => E as ICustomPOOperationResource).ToList();

                            //Check if there is a relation with the specified material ERPOperationCode and validate the WorkCenters.
                            var erpOperationRelation = relationsOperationResource.FirstOrDefault(x => x.OperationCode.Equals(materialCurrentERPOperationCode, System.StringComparison.InvariantCultureIgnoreCase));
                            if (erpOperationRelation != null)
                            {
                                //Get configuration for workcenter
                                bool validateWorkCenterAtDispatch = genericUtilities.GetConfigurationValueByPath<bool>(IKEAConstants.ValidateWorkCenterAtDispatch);
                                if (validateWorkCenterAtDispatch)
                                {
                                    // Get WorkCenter from PO
                                    string defaultWorkCenter = productionOrder.GetAttributeValueOrDefault<string>(IKEAConstants.CustomProductionOrderAttributeDefaultWorkCenter, true);
                                    // get all ressources for this WC in generic table
                                    List<string> resourceList = ikeaUtilities.GetResourcesFromCustomWorkCenterResourceMapping(defaultWorkCenter);
                                    // check if resource is present in the table for this WC
                                    if (resourceList.IsNullOrEmpty() || !resourceList.Contains(resource.Name))
                                    {
                                        throw new CmfBaseException(ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomValidateResourceWorkCenterWorkCentersDoNotMatchLocalizedMessage, defaultWorkCenter, resource.Name));
                                    }
                                }
                            }
                        }
                    }
                }
            }

            if (keyValuePairs != null)
            {
                deeContextUtilities.SetContextParameter("CustomValidateResourceWorkCenterAtPreDispatch_FeedbackMessages", keyValuePairs);
            }

            //---End DEE Code---

            return Input;
        }


    }
}

