﻿using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace Cmf.Custom.IKEA.Actions.Materials
{
    class CustomMaterialStoreUpdateReplenishmentRequest : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            /// Updates, if existing, any MaterialReplenishmentRequestTracker Entities
            /// Action Groups:
            /// MaterialManagement.MaterialManagementOrchestration.StoreMaterial.Post
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "MaterialManagement.MaterialManagementOrchestration.StoreMaterial.Post",
                "MaterialManagement.MaterialManagementOrchestration.StoreMaterials.Post",
            };

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);
            if (executionVeridict && IKEADEEActionUtilities.GetInputItem<StoreMaterialOutput>(Input, "StoreMaterialOutput") == null
                                  && IKEADEEActionUtilities.GetInputItem<StoreMaterialsOutput>(Input, "StoreMaterialsOutput") == null)
            {
                executionVeridict = false;
            }
            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            //System
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];

            IStockingPointUtilities stockingPointUtilities = serviceProvider.GetService<IStockingPointUtilities>();
            // Gets Stored material input:
            StoreMaterialsOutput storeMaterialsOutput = IKEADEEActionUtilities.GetInputItem<StoreMaterialsOutput>(Input, "StoreMaterialsOutput");

            // Gets Stored material input:
            StoreMaterialOutput storeMaterialOutput = IKEADEEActionUtilities.GetInputItem<StoreMaterialOutput>(Input, "StoreMaterialOutput");

            List<Tuple<string, string, decimal>> updateReplenishments = new List<Tuple<string, string, decimal>>();

            if (storeMaterialOutput != null)
            {
                updateReplenishments.Add(new Tuple<string, string, decimal>(storeMaterialOutput.Resource.Name,
                                                                            storeMaterialOutput.Material.Product.Name,
                                                                            storeMaterialOutput.Material.PrimaryQuantity ?? 0));
            }
            else
            {
                foreach (var material in storeMaterialsOutput.Materials)
                {
                    updateReplenishments.Add(new Tuple<string, string, decimal>(storeMaterialsOutput.Resource.Name,
                                                                                material.Product.Name,
                                                                                material.PrimaryQuantity ?? 0));
                }
            }

            foreach (var updateReplenishment in updateReplenishments)
            {
                stockingPointUtilities.UpdateReplenishmentRequest(updateReplenishment.Item1,
                                                         updateReplenishment.Item2,
                                                         updateReplenishment.Item3);
            }


            //---End DEE Code---

            return Input;
        }

    }
}
