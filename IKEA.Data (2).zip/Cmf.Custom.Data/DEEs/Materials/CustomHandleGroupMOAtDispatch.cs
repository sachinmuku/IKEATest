﻿using Cmf.Common.CustomActionUtilities;


using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Exceptions;
using Cmf.Custom.IKEA.Common.Extensions;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Foundation.Configuration;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace Cmf.Custom.IKEA.Actions.Materials
{
    public class CustomHandleGroupMOAtDispatch : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {

        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     If a group MO is to be dispatched, the child MOs orders must be dispatched also
            /// Action Groups:
            ///     BusinessObjects.MaterialCollection.Dispatch.Pre
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.MaterialCollection.Dispatch.Pre"
            };

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            if (executionVeridict && IKEADEEActionUtilities.GetInputItem<Dictionary<IMaterial, IDispatchMaterialParameters>>(Input, "MaterialDispatchParameters") == null)
            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }


        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

 UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Exceptions");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
     

            //System
            UseReference("", "System");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("", "System.Linq");
            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Extensions");
            
            //Foundation
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration");
            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();

            // Get input material information:
            Dictionary<IMaterial, IDispatchMaterialParameters> materialDispatchParametersInput = Input["MaterialDispatchParameters"] as Dictionary<IMaterial, IDispatchMaterialParameters>;

            // Get input materials
            IMaterialCollection materialCollectionInput = Input["MaterialCollection"] as IMaterialCollection;
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();


            // Create materials to add:
            Dictionary<IMaterial, IDispatchMaterialParameters> groupMaterialDispatchParameters = new Dictionary<IMaterial, IDispatchMaterialParameters>();
            IMaterialCollection groupMaterialCollection =entityFactory.CreateCollection<IMaterialCollection>();


            // Iterate over the materials being dispatched and check for the group mos:
            foreach (var dispatchMaterial in materialDispatchParametersInput)
            {
                IMaterial material = dispatchMaterial.Key;
                IDispatchMaterialParameters dispatchMaterialParameters = dispatchMaterial.Value;

                // if there are group MOs being tracked in:
                if (material.IsGroupMO())
                {
                    material.LoadAttributes(new Collection<string>
                    {
                        IKEAConstants.CustomMaterialAttributeGroupOrderResource,
                        IKEAConstants.CustomMaterialAttributeGroupOrderState,
                        IKEAConstants.CustomMaterialAttributeGroupOrderHPOEnabled,
                    });

                    bool groupOrderHpoEnabled = material.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomMaterialAttributeGroupOrderHPOEnabled);
                    string groupOrderResourceName = material.GetAttributeValueOrDefault<string>(IKEAConstants.CustomMaterialAttributeGroupOrderResource);
                    CustomGroupOrderStateEnum groupOrderState = material.GetAttributeValueOrDefault(IKEAConstants.CustomMaterialAttributeGroupOrderState, CustomGroupOrderStateEnum.Created);

                    OptimizerResourceStructure optimizerConfig = material.GetHPOConfiguration();

                    // If we allow dispatching to a resource other than groupOrderResourceName when not optimized, we need to make sure that resource is not optimizeable as well
                    if (optimizerConfig == null || groupOrderHpoEnabled == false)
                    {
                        // Check the global config to verify if not optimizable GroupMO's cannot be dispatched to other resources
                        if (genericUtilities.GetConfigurationValueByPath<bool>(IKEAConstants.AllowDispatchGroupMoToAnyResource) == false)
                        {
                            if (dispatchMaterialParameters.Resource.Name != groupOrderResourceName)
                            {
                                throw new IKEAException(IKEAConstants.CustomMaterialGroupMOResourceMismatchLocalizedMessage);
                            }
                        }

                        optimizerConfig = dispatchMaterialParameters.Resource.GetHPOConfiguration();

                        if (optimizerConfig != null && optimizerConfig.AllowToDispatchNotOptimizedGroupOrders == false)
                        {
                            throw new IKEAException(IKEAConstants.CustomMaterialGroupMOResourceOptimizationMismatchLocalizedMessage);
                        }
                    }

                    // If the resource of this Group Order has optimization configured, then the material should only be dispatchable if
                    //  - The resource we're dispatching to matches the one stored in GroupOrderResource
                    //  - And either:
                    //      - The GroupOrderState is Ready
                    //      - The optimizerConfig allows dispatch without optimization
                    if (optimizerConfig != null && groupOrderHpoEnabled == true)
                    {
                        if (dispatchMaterialParameters.Resource.Name != groupOrderResourceName)
                        {
                            throw new IKEAException(IKEAConstants.CustomMaterialGroupMOResourceMismatchLocalizedMessage);
                        }

                        if (groupOrderState != CustomGroupOrderStateEnum.Ready && groupOrderState != CustomGroupOrderStateEnum.WaitingForOperator)
                        {
                            throw new IKEAException(IKEAConstants.CustomMaterialGroupMOWrongDispatchStateLocalizedMessage);
                        }
                    }

                    if (groupOrderHpoEnabled == false && dispatchMaterialParameters.Resource.Name != groupOrderResourceName)
                    {
                        material.SaveAttributes(new Foundation.BusinessObjects.AttributeCollection
                        {
                            { IKEAConstants.CustomMaterialAttributeGroupOrderResource, dispatchMaterialParameters.Resource.Name }
                        });
                    }

                    // Get the child MOs materials and parts per cycle from the Group:
                    IMaterialCollection childMOs = ikeaUtilities.GetChildMaterialsFromGroupMO(material);
                    if (!childMOs.IsNullOrEmpty())
                    {
                        // Add groupMO to Dispatch list and parameters:
                        groupMaterialCollection.Add(material); 
                        groupMaterialDispatchParameters.Add(material, dispatchMaterialParameters);

                        // Add the child materials to Dispatch list and parameters:
                        foreach (var materialChild in childMOs)
                        {
                            groupMaterialCollection.Add(materialChild);
                            groupMaterialDispatchParameters.Add(materialChild, dispatchMaterialParameters);                     
                        }
                    }
                }
                else if (material.IsChildOfGroupMO())
                {
                    throw new CmfBaseException(ikeaUtilities.GetLocalizedMessage(IKEAConstants.CustomGroupMOChildCannotBeDispatchedLocalizedMessage));
                }
            }

            if (!groupMaterialCollection.IsNullOrEmpty() && !groupMaterialDispatchParameters.IsNullOrEmpty())
            {
                materialCollectionInput.Clear();
                materialDispatchParametersInput.Clear();

                materialCollectionInput.AddRange(groupMaterialCollection);
                materialDispatchParametersInput.AddRange(groupMaterialDispatchParameters);
            }

            

            //---End DEE Code---

            return Input;
        }




    }
}
