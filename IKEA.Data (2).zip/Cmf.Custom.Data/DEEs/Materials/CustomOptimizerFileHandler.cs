﻿using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Exceptions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json;
using System;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using Cmf.Common.CustomActionUtilities;

namespace Cmf.Custom.IKEA.Actions.Materials
{
    public class CustomOptimizerFileHandler : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---   
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Exceptions");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");			
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "");
            UseReference("", "Cmf.Foundation.Common.Exceptions");
            UseReference("", "Cmf.Foundation.Common");
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Extensions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Newtonsoft.Json.dll", "Newtonsoft.Json");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();

            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IProductionOrderHandlingUtilities productionOrderHandlingUtilities = serviceProvider.GetService<IProductionOrderHandlingUtilities>();
            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            List<OptimizedOrderStructure> optimizedOrders = null;

            object aux;
            string groupOrderName = null;

            if (Input.TryGetValue("OptimizedOrders", out aux))
            {
                if (aux != null)
                {
                    optimizedOrders = JsonConvert.DeserializeObject<List<OptimizedOrderStructure>>(aux as string);
                }
            }

            if (optimizedOrders != null && optimizedOrders.Count > 0)
            {
                groupOrderName = optimizedOrders.Select(o => o.GroupMOName)?.First();
                IMaterial groupMO = entityFactory.Create<IMaterial>();
                groupMO.Name = groupOrderName;
                if (optimizedOrders.Any(o => o.GroupMOName != groupOrderName))
                {
                    throw new IKEAException(IKEAConstants.CustomMaterialGroupMOResourceMismatchLocalizedMessage);
                }

                if (!groupMO.ObjectExists())
                {
                    throw new IKEAException(IKEAConstants.CustomMaterialGroupMODontExistLocalizedMessage);
                }

                groupMO.Load();
                groupMO.LoadAttributes(new Collection<string>
                {
                    IKEAConstants.CustomMaterialIsOrderlessAttribute
                });

                // List of orders to check & update (only if the optimizer changed any of their quantities)
                Dictionary<IMaterial, decimal> ordersToCheck = new Dictionary<IMaterial, decimal>();

                // List of orders to create (new orders introduced by the Optimizer). Includes the product and quantity
                List<(IProduct, decimal)> ordersToCreate = new List<(IProduct, decimal)>();

                List<string> expectedMOList = groupMO.GetAttributeValueOrDefault<List<string>>(IKEAConstants.CustomGroupMOERPRequestedOrders, true);

                // Determine if this Group MO is orderless or not
                bool isGroupOrderless = groupMO.GetAttributeValueOrDefault<bool>(IKEAConstants.CustomMaterialIsOrderlessAttribute);

                // Update group MO orders information
                foreach (OptimizedOrderStructure order in optimizedOrders)
                {
                    IMaterial materialOrder = entityFactory.Create<IMaterial>();
                    materialOrder.Name = order.OrderName;

                    // If child does not exists, we need to create it
                    if (!materialOrder.ObjectExists())
                    {
                        IProduct product = entityFactory.Create<IProduct>();
                        product.Name = order.ProductName;
                        if (product.ObjectExists())
                        {
                            ordersToCreate.Add((product, order.OptimizedQuantity));
                        }
                    }
                    else
                    {
                        ordersToCheck.Add(materialOrder, order.OptimizedQuantity);
                    }
                }

                // Check and update existing children MO quantities
                ikeaUtilities.CheckAndUpdateMOQuantitiesFromNCL(ordersToCheck, groupMO);

                // Create new 
                if (ordersToCreate.Any())
                {
                    // If the group is not an orderless production, request to ERP to create it
                    if (!isGroupOrderless)
                    {
                        // Get Facility ERP identifier
                        string erpIdentifier = groupMO.Facility.GetAttributeValueOrDefault<string>(IKEAConstants.CustomFacilityAttributeERPIdentifier, true);

                        foreach (var (product, quantity) in ordersToCreate)
                        {
                            product.Load();

                            productionOrderHandlingUtilities.RequestERPProductionOrder(groupMO, erpIdentifier, product, quantity, updateGroupState: false);
                        }
                    }
                    else
                    {
                        // Get the Main Line resource of this group order
                        IResource resource = entityFactory.Create<IResource>();

                        resource.Name = groupMO.GetAttributeValueOrDefault<string>(IKEAConstants.CustomMaterialAttributeGroupOrderResource, loadAttribute: true);
                        
                        resource.Load();

                        // List to hold the material instances created for each order suggested by the HPO
                        IMaterialCollection createdOrders = entityFactory.CreateCollection<IMaterialCollection>();

                        // Create each individual orderless production
                        foreach (var (product, quantity) in ordersToCreate)
                        {
                            createdOrders.Add(productionOrderHandlingUtilities.CreateSingleOrderless(resource, new Cmf.Custom.IKEA.Common.DataStructures.OrderlessCreation
                            {
                                Product = product,
                                Quantity = quantity,
                            }));
                        }

                        ikeaUtilities.AddGroupOrderChildren(groupMO, createdOrders);
                    }
                }

                // If the group is not ready, it must be left in a waiting state. For orderless productions, that state is waiting for the operator,
                // for all other orders the state is waiting for the ERP to create them
                CustomGroupOrderStateEnum waitingState = isGroupOrderless ? CustomGroupOrderStateEnum.WaitingForOperator : CustomGroupOrderStateEnum.WaitingForERP;

                // Update the state of the Group MO
                CustomGroupOrderStateEnum state = ordersToCreate.Any() ? waitingState : CustomGroupOrderStateEnum.Ready;

                groupMO.SaveAttributes(new AttributeCollection()
                {
                    { IKEAConstants.CustomMaterialAttributeGroupOrderState, state }
                });

                // Notification if state is Ready or Waiting for the Operator
                if (state == CustomGroupOrderStateEnum.Ready || state == CustomGroupOrderStateEnum.WaitingForOperator)
                {
                    ikeaUtilities.GenerateNotificationGroupMOReady(groupMO.Name);
                }
            }
            else
            {
                throw new Exception("No orders given in input.");
            }
            //---End DEE Code---
            return Input;
        }

        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text:
            ///     Action to manage receivre NCL file from IoT
            /// Action Groups:
            ///    -
            /// </summary>
            #endregion

            return true;

            //---End DEE Condition Code---
        }
    }
}
