﻿using Cmf.Common.CustomActionUtilities;

using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Exceptions;
using Cmf.Custom.IKEA.Common.Extensions;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Foundation.Configuration;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.Materials
{
    class CustomHandleOrderlessMOAtDispatch : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {

        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     If a MO is to be dispatched, we must confirm that the orderless attribute matches.
            /// Action Groups:
            ///     BusinessObjects.MaterialCollection.Dispatch.Pre
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.MaterialCollection.Dispatch.Pre"
            };

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            if (executionVeridict && IKEADEEActionUtilities.GetInputItem<Dictionary<IMaterial, IDispatchMaterialParameters>>(Input, "MaterialDispatchParameters") == null)
            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }


        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Exceptions");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
     

            //System
            UseReference("", "System");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("", "System.Linq");
            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Extensions");
            
            //Foundation
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration");
            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();

            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();

            // Get input material information:
            Dictionary<IMaterial, IDispatchMaterialParameters> materialDispatchParametersInput = Input["MaterialDispatchParameters"] as Dictionary<IMaterial, IDispatchMaterialParameters>;

            Dictionary<IResource, bool> resourcesAlreadyEvaluated = new Dictionary<IResource, bool>();

            IMaterialCollection collection = entityFactory.CreateCollection<IMaterialCollection>();
            collection.AddRange(materialDispatchParametersInput.Keys);
            collection.LoadAttributes(new Collection<string>
            {
                IKEAConstants.CustomMaterialIsOrderlessAttribute
            });

            foreach (IMaterial material in materialDispatchParametersInput.Keys)
            {
                IResource resource = materialDispatchParametersInput[material].Resource;
                bool newIsOrderless = material.GetAttributeValueOrDefault(IKEAConstants.CustomMaterialIsOrderlessAttribute, false);

                //If resource has already been checked, use the resourcesAlreadyEvaluated dictionary to immediatly compare its "isOrderless" value
                if (resourcesAlreadyEvaluated.ContainsKey(resource))
                {
                    if (newIsOrderless != resourcesAlreadyEvaluated[resource])
                    {
                        throw new IKEAException(IKEAConstants.CustomMOOrderlessCannotBeDispatchedMessage, material.Name);
                    }
                }
                else
                {
                    //Check all materials of resource that are either Dispatched or InProcess
                    Dictionary<IMaterial, decimal> dispatchedMaterials = ikeaUtilities.GetMaterialsFromResourceByState(resource.Id, true, new MaterialSystemState[] {
                        MaterialSystemState.Dispatched,
                        MaterialSystemState.InProcess
                    });

                    if (dispatchedMaterials.Count > 0)
                    {
                        IMaterial dispatchedMaterial = dispatchedMaterials.First().Key;
                        bool dispatchedIsOrderless = dispatchedMaterial.GetAttributeValueOrDefault(IKEAConstants.CustomMaterialIsOrderlessAttribute, false, true);

                        //Check if can be created
                        if (dispatchedIsOrderless != newIsOrderless)
                        {
                            throw new IKEAException(IKEAConstants.CustomMOOrderlessCannotBeDispatchedMessage, material.Name);
                        }
                    }

                    //Add to resourcesAlreadyEvaluated to more quickly compare other materials with the same resource
                    resourcesAlreadyEvaluated.Add(resource, newIsOrderless);
                }

            }
            
            //---End DEE Code---

            return Input;
        }

    }
}