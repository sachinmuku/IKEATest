﻿using Cmf.Common.CustomActionUtilities;

using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Exceptions;
using Cmf.Custom.IKEA.Common.Extensions;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace Cmf.Custom.IKEA.Actions.Materials
{
    class CustomHandleGroupMOAtUndispatch : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {


        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     If a group MO is to be dispatched, the child MOs orders must be dispatched also
            /// Action Groups:
            ///     "MaterialManagement.MaterialManagementOrchestration.UndispatchMaterials.Pre"
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "MaterialManagement.MaterialManagementOrchestration.UndispatchMaterials.Pre"
            };

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            if (executionVeridict && IKEADEEActionUtilities.GetInputItem<UndispatchMaterialsInput>(Input, "UndispatchMaterialsInput") == null)
            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }


        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Exceptions");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
     

            //System
            UseReference("", "System");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("", "System.Linq");
            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Extensions");
            //Foundation
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects");
            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();

            // Get input:
            UndispatchMaterialsInput materialsToUndispatch = IKEADEEActionUtilities.GetInputItem<UndispatchMaterialsInput>(Input, "UndispatchMaterialsInput");
            //MaterialCollection materialsToUndispatch = Input["MaterialCollection"] as MaterialCollection;

            // Materials
            IMaterialCollection materialsToAdd = entityFactory.CreateCollection<IMaterialCollection>();

            // Iterate over the materials being dispathed and check for the group mos:
            foreach (var materialToUndispatch in materialsToUndispatch.Materials)
            {
                // if there are group MOs being tracked in:
                if (materialToUndispatch.IsGroupMO())
                {
                    // Get the child MOs materials and parts per cycle from the Group:
                    IMaterialCollection materialChildMOs = ikeaUtilities.GetChildMaterialsFromGroupMO(materialToUndispatch, loadAttributes: false);
                    if (!materialChildMOs.IsNullOrEmpty())
                    {
                        materialsToAdd.AddRange(materialChildMOs);
                    }
                }
                else if (materialToUndispatch.IsChildOfGroupMO())
                {
                    throw new IKEAException(IKEAConstants.CustomGroupMOChildCannotBeUndispatchedLocalizedMessage);
                }
            }

            if (!materialsToAdd.IsNullOrEmpty())
            {
                materialsToUndispatch.Materials.AddRange(materialsToAdd);
            }

            
            //---End DEE Code---

            return Input;
        }



    }
}
