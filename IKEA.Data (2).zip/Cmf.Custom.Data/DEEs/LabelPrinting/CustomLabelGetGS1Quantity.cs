﻿using Cmf.Custom.IKEA.Common;
using Cmf.Navigo.BusinessObjects;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Common.CustomActionUtilities;

namespace Cmf.Custom.IKEA.Actions.LabelPrinting
{
    public class CustomLabelGetGS1Quantity : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        /// <summary>
        /// This DEE Provides a Material quantity encoded based on the GS1 unit and number of decimal places that quantity should contain...
        /// </summary>
        /// <param name="Input"></param>
        /// <returns></returns>
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     This DEE Provides a Material quantity encoded based on the GS1 unit and number of decimal places that quantity should contain...
            /// </summary>
            #endregion

            return true;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
     

            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("", "System.Text");
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            // Before read check if Product key exists in Input
            IMaterial incomingMaterial = IKEADEEActionUtilities.GetInputItem<IMaterial>(Input, "AppliesToValue");
            
            StringBuilder gs1Builder = new StringBuilder();
            
            string token = "30";
            string value = "0";
            string strUnit = !String.IsNullOrWhiteSpace(incomingMaterial.PrimaryUnits) ? incomingMaterial.PrimaryUnits : (incomingMaterial.Product != null ? incomingMaterial.Product.DefaultUnits : string.Empty);
            // try to check for specific GS1 handled units... anything else falls back to token 30
            if (incomingMaterial != null
                && incomingMaterial.PrimaryQuantity != null
                && !String.IsNullOrWhiteSpace(strUnit)
                && incomingMaterial.Product != null)
            {
                // get number of decimals based on product
                int numberDecimalPlaces = incomingMaterial.Product.GetRelatedAttributeValueOrDefault<int>(IKEAConstants.GS1DecimalPlaces, true);
                string numberDecimalPlacesStr = numberDecimalPlaces.ToString();
                int multiplier = (int)Math.Pow(10, numberDecimalPlaces);
                
                switch (strUnit.ToUpper())
                {
                    /// <seealso cref="https://ref.gs1.org/ai/"/>
                    /// 
                    /// 5.7.1 Quantity in Meters (AI=311n)
                    /// Format: N4+N6 (fixed length - 6 digit)
                    /// FNC1:   Not required
                    /// Note:   The fourth digit (0) of this AI indicates the number of decimal places (see GS1 General Specifications for details). 
                    ///         i.e. N6 = nnnnnn kilograms
                    case "M":
                        token = "311" + numberDecimalPlacesStr;
                        value = ((int)(incomingMaterial.PrimaryQuantity * multiplier)).ToString(IKEAConstants.GS1StringFormatN6);
                        break;

                    /// 5.7.2 Quantity in Pieces (AI=30)
                    /// Format: N2+N..8 (variable length - up to 8 digit)
                    /// FNC1:   Required
                    case "PCS":
                        token = "30";
                        value = ((int)incomingMaterial.PrimaryQuantity).ToString();
                        break;

                    /// 5.7.3 Quantity in Cubic meters (AI=316n)
                    /// Format: N4+N6 (fixed length - 6 digit)
                    /// FNC1:   Not required
                    /// Note:   The fourth digit (0) of this AI indicates the number of decimal places (see GS1 General Specifications for details). 
                    ///         i.e. N6 = nnnnnn cubic metres
                    case "M3":
                      //  string gs1Format = "D6";
                        token = "316" + numberDecimalPlacesStr;
                        value = ((int)(incomingMaterial.PrimaryQuantity * multiplier)).ToString(IKEAConstants.GS1StringFormatN6);
                        break;

                    /// 5.7.4 Quantity in Kilograms (AI=310n)
                    /// Format: N4+N6 (fixed length - 6 digit)
                    /// FNC1:   Not required
                    /// Note:   The fourth digit (0) of this AI indicates the number of decimal places (see GS1 General Specifications for details). 
                    ///         i.e. N6 = nnnnnn kilograms
                    case "KG":
                        token = "310" + numberDecimalPlacesStr;
                        value = ((int)(incomingMaterial.PrimaryQuantity * multiplier)).ToString(IKEAConstants.GS1StringFormatN6);
                        break;

                    /// 5.7.5 Quantity in Square Meters (AI=314n)
                    /// Format: N4+N6 (fixed length - 6 digit)
                    /// FNC1:   Not required
                    /// Note:   The fourth digit (0) of this AI indicates the number of decimal places (see GS1 General Specifications for details). 
                    ///         i.e. N6 = nnnnnn square metres
                    case "M2":
                        token = "314" + numberDecimalPlacesStr;
                        value = ((int)(incomingMaterial.PrimaryQuantity * multiplier)).ToString(IKEAConstants.GS1StringFormatN6);
                        break;

                    /// 5.7.6 Quantity in Liters (AI=315n)
                    /// Format: N4+N6 (fixed length - 6 digit)
                    /// FNC1:   Not required
                    /// Note:   The fourth digit (0) of this AI indicates the number of decimal places (see GS1 General Specifications for details). i.e. N6 = nnnnnn litres
                    case "L":
                        token = "315" + numberDecimalPlacesStr;
                        value = ((int)(incomingMaterial.PrimaryQuantity * multiplier)).ToString(IKEAConstants.GS1StringFormatN6);
                        break;

                    /// Fall back to AI 30
                    /// Format: N2+N..8 (variable length - up to 8 digit)
                    /// FNC1:   Required  
                    default:
                        token = "30";
                        value = ((int)incomingMaterial.PrimaryQuantity).ToString();
                        break;
                }
            }
            
            //Clear Input Dictionary
            Input = new Dictionary<string, object>
            {
                //{ "Result", Convert.ToInt32(value) }
                { "Result", String.Format("({0}){1}", token, value) }
            };

            
            //---End DEE Code---

            return null;
        }
    }
}