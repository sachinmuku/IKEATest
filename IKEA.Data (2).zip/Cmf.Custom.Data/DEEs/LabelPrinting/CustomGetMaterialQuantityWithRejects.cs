﻿using Cmf.Custom.IKEA.Common;
using Cmf.Navigo.BusinessObjects;
using System.Collections.Generic;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Foundation.Common.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using Cmf.Custom.IKEA.Common.Abstractions;

namespace Cmf.Custom.IKEA.Actions.LabelPrinting
{
    public class CustomGetMaterialQuantityWithRejects : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Obtains the material primary quantity with the secondary quantity in case of rejects
            /// </summary>
            #endregion

            bool executionVeridict = true;

            if (IKEADEEActionUtilities.GetInputItem<IMaterial>(Input, "AppliesToValue") == null)
            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
     

            //System
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.IO");
            UseReference("", "System.Threading");
            UseReference("", "System");

            //Foundation
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            IGenericUtilities _genericUtilities = serviceProvider.GetService<IGenericUtilities>();

            // Get the default reject unit
            string rejectUnit = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.ScrapManagementRejectUnit);

            IMaterial material = IKEADEEActionUtilities.GetInputItem<IMaterial>(Input, "AppliesToValue");

            // Load the material only if not already loaded
            if (material.Id > 0 && material.LastServiceHistoryId == 0)
            {
                material.Load();
            }

            // Initiate the material quantity with the material primary quantity
            decimal materialQuantity = (material.PrimaryQuantity.HasValue ? material.PrimaryQuantity.Value : 0);

            // When the material secondary unit is Reject, it will also be added to the material quantity
            if (material.SecondaryUnits.CompareStrings(rejectUnit))
            {
                materialQuantity += (material.SecondaryQuantity.HasValue ? material.SecondaryQuantity.Value : 0);
            }

            //Clear Input Dictionary
            Input = new Dictionary<string, object>
            {
                { "Result", materialQuantity }
            };

            

            //---End DEE Code---

            return null;
        }
    }
}
