﻿using Cmf.Navigo.BusinessObjects;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Actions.LabelPrinting
{
    /// <summary>
    /// DEE that extracts creation date from a given material object
    /// </summary>
    public class CustomLabelGetPalletCreationDate : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     DEE that extracts creation date from a given material object
            /// </summary>
            #endregion

            return true;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
UseReference("Cmf.Foundation.BusinessOrchestration.dll", "");
UseReference("", "Cmf.Foundation.Common.Exceptions");
UseReference("", "Cmf.Foundation.Common");
UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");

            // Before read check if material key exists in Input
            IMaterial incomingMaterial = null;
            if (Input.ContainsKey("AppliesToValue"))
            {
                incomingMaterial = Input["AppliesToValue"] as IMaterial;
            }

            // By default, creation date  shall be now
            DateTime returnValue = DateTime.Now;

            // try to extract creation date of materiak
            if (incomingMaterial != null && incomingMaterial.CreatedOn != null
                && incomingMaterial.CreatedOn != DateTime.MinValue)
            {
                returnValue = incomingMaterial.CreatedOn;
            }

            //Clear Input Dictionary
            Input = new Dictionary<string, object>
            {
                { "Result", returnValue }
            };

         
            //---End DEE Code---

            return null;
        }
    }
}