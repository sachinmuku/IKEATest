﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Custom.IKEA.Common;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Linq;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.ResourceManagement.OutputObjects;
using Cmf.Foundation.Common.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using Cmf.Navigo.BusinessOrchestration.ResourceManagement.InputObjects;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common.Abstractions;

namespace Cmf.Custom.IKEA.Actions.LabelPrinting
{
    public class CustomAutomaticPrintingDocuments : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text:
            ///     Auto Print labels based on configuration in the CustomAutomaticPrintableDocumentContext Smart Table
            /// Action Groups:
            //BusinessObjects.Material.Merge.Post
            //BusinessObjects.MaterialCollection.Retrieve.Post
            //BusinessObjects.MaterialCollection.TrackOut.Post
            //MaterialManagement.MaterialManagementOrchestration.CreateMaterial.Post
            //MaterialManagement.MaterialManagementOrchestration.CreateMaterials.Post
            //MaterialManagement.MaterialManagementOrchestration.ShipMaterials.Post
            //MaterialManagement.MaterialManagementOrchestration.ShipMaterials.Pre
            //MaterialManagement.MaterialManagementOrchestration.SplitMaterial.Post
            //ResourceManagement.ResourceManagementOrchestration.ManageResourceConsumableFeeds.Post
            //MaterialManagement.MaterialManagementOrchestration.ChangeMaterialsType.Post
            //MaterialManagement.MaterialManagementOrchestration.ChangeMaterialType.Post
            //"ResourceManagement.ResourceManagementOrchestration.ManageResourceConsumableFeeds.Pre",
            //"ResourceManagement.ResourceManagementOrchestration.DetachConsumableFromResource.Post",
            //"ResourceManagement.ResourceManagementOrchestration.DetachConsumablesFromResource.Post"

            /// </summary>
            #endregion

            return true;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
     

            //System
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.IO");
            UseReference("", "System.Threading");
            UseReference("", "System");

            //Foundation
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration");

            //Navigo
            UseReference("Cmf.Navigo.Common.dll", "Cmf.Navigo.Common");
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
                UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.ResourceManagement.InputObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.ResourceManagement.OutputObjects");

            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetRequiredService<IEntityFactory>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IAutomaticPrintingUtilities automaticPrintingUtilities = serviceProvider.GetService<IAutomaticPrintingUtilities>();

            string contextShippingSteps = "CustomAutomaticPrintingDocuments_ShippingSteps";

            string printSequence = string.Empty;

            DeeContext currentContext = deeContextUtilities.SetCurrentServiceContext("CustomAutomaticPrintingDocuments");

            Dictionary<string, IStep> materialStepsToUse = new Dictionary<string, IStep>();
            Dictionary<string, IResource> materialResourcesToUse = new Dictionary<string, IResource>();
            IMaterialCollection materials = null;

            switch (currentContext.MethodName)
            {
                case "ShipMaterials":
                    {
                        if (currentContext.TriggerPoint == DeeTriggerPoint.Pre)
                        {
                            printSequence = IKEAConstants.AutomaticPrintingSequenceBeforeShipping;

                            ShipMaterialsInput input = Input["ShipMaterialsInput"] as ShipMaterialsInput;

                            if (input != null)
                            {
                                if (!input.Materials.IsNullOrEmpty())
                                {
                                    materials = entityFactory.CreateCollection<IMaterialCollection>();
                                    bool printSource = false;

                                    foreach (IMaterial material in input.Materials)
                                    {
                                        if (automaticPrintingUtilities.HasAutomaticPrinting(material, printSequence, out printSource))
                                        {
                                            materials.Add(material);
                                        }
                                    }

                                    materialStepsToUse = materials.ToDictionary(material => material.Name, material => material.Step);
                                    deeContextUtilities.SetContextParameter(contextShippingSteps, materialStepsToUse);
                                }
                            }
                        }
                        else
                        {
                            printSequence = IKEAConstants.AutomaticPrintingSequenceAfterShipping;

                            ShipMaterialsOutput output = Input["ShipMaterialsOutput"] as ShipMaterialsOutput;

                            if (output != null)
                            {
                                if (!output.Materials.IsNullOrEmpty())
                                {
                                    materials = entityFactory.CreateCollection<IMaterialCollection>();
                                    bool printSource = false;

                                    foreach (IMaterial material in output.Materials)
                                    {
                                        if (automaticPrintingUtilities.HasAutomaticPrinting(material, printSequence, out printSource))
                                        {
                                            materials.Add(material);
                                        }
                                    }
                                    materialStepsToUse = materialStepsToUse == null || materialStepsToUse.Count == 0 ?
                                                         materials.ToDictionary(material => material.Name, material => material.Step) :
                                                         deeContextUtilities.GetContextParameter(contextShippingSteps) as Dictionary<string, IStep>;
                                }
                            }
                        }

                        break;
                    }
                case "TrackOut":
                    {
                        printSequence = IKEAConstants.AutomaticPrintingSequenceOnTrackOut;

                        // Check if it's a process loss
                        bool? isProcessLoss = deeContextUtilities.GetContextParameter(IKEAConstants.CustomUnitCompleteIsProcessLossContext) as bool?;

                        IMaterialCollection trackout = IKEADEEActionUtilities.GetInputItem<IMaterialCollection>(Input, Navigo.Common.Constants.MaterialCollection);
                        if (!trackout.IsNullOrEmpty() && !isProcessLoss.GetValueOrDefault())
                        {
                            bool printSource = false;
                            materials = entityFactory.CreateCollection<IMaterialCollection>();
                            foreach (IMaterial material in trackout)
                            {
                                if (automaticPrintingUtilities.HasAutomaticPrinting(material, printSequence, out printSource))
                                {
                                    materials.Add(material);
                                }
                            }

                            materials.Load();
                            materialStepsToUse = materials.ToDictionary(material => material.Name, material => material.Step);
                        }

                        break;
                    }
                case "DetachConsumableFromResource":
                    {
                        printSequence = IKEAConstants.AutomaticPrintingSequenceOnDetach;
                        bool printSource = false;

                        DetachConsumableFromResourceOutput detachConsumableFromResourceOutput = IKEADEEActionUtilities.GetInputItem<DetachConsumableFromResourceOutput>(Input, "DetachConsumableFromResourceOutput");

                        if (detachConsumableFromResourceOutput != null && detachConsumableFromResourceOutput.Material != null)
                        {
                            materials = entityFactory.CreateCollection<IMaterialCollection>();
                            if (automaticPrintingUtilities.HasAutomaticPrinting(detachConsumableFromResourceOutput.Material, printSequence, out printSource, resource: detachConsumableFromResourceOutput.Resource))
                            {
                                materials.Add(detachConsumableFromResourceOutput.Material);
                                materialResourcesToUse.Add(detachConsumableFromResourceOutput.Material.Name, detachConsumableFromResourceOutput.Resource);
                            }
                        }

                        materials.Load();
                        materialStepsToUse = materials.ToDictionary(material => material.Name, material => material.Step);

                        break;
                    }
                case "DetachConsumablesFromResource":
                    {
                        printSequence = IKEAConstants.AutomaticPrintingSequenceOnDetach;
                        bool printSource = false;

                        DetachConsumablesFromResourceOutput detachConsumablesFromResourceOutput = IKEADEEActionUtilities.GetInputItem<DetachConsumablesFromResourceOutput>(Input, "DetachConsumablesFromResourceOutput");

                        if (detachConsumablesFromResourceOutput != null && detachConsumablesFromResourceOutput.Materials != null && detachConsumablesFromResourceOutput.Materials.Count > 0)
                        {
                            materials = entityFactory.CreateCollection<IMaterialCollection>();
                            foreach (IMaterial detachedMaterial in detachConsumablesFromResourceOutput.Materials)
                            {
                                if (automaticPrintingUtilities.HasAutomaticPrinting(detachedMaterial, printSequence, out printSource, resource: detachConsumablesFromResourceOutput.Resource))
                                {
                                    materials.Add(detachedMaterial);
                                    materialResourcesToUse.Add(detachedMaterial.Name, detachConsumablesFromResourceOutput.Resource);
                                }
                            }
                        }

                        materials.Load();
                        materialStepsToUse = materials.ToDictionary(material => material.Name, material => material.Step);

                        break;
                    }
                case "ManageResourceConsumableFeeds":
                    {
                        if (currentContext.TriggerPoint == DeeTriggerPoint.Pre)
                        {
                            ManageResourceConsumableFeedsInput manageResourceConsumableFeedsInput = IKEADEEActionUtilities.GetInputItem<ManageResourceConsumableFeedsInput>(Input, "ManageResourceConsumableFeedsInput");
                            Dictionary<IResource, IMaterialCollection> resourceConsumablesDict = new Dictionary<IResource, IMaterialCollection>();

                            if (manageResourceConsumableFeedsInput != null && !manageResourceConsumableFeedsInput.ConsumablesToDetach.IsNullOrEmpty())
                            {
                                resourceConsumablesDict = manageResourceConsumableFeedsInput.ConsumablesToDetach;
                            }

                            deeContextUtilities.SetContextParameter("CustomAutomationOnManageResourceConsumablesDetach_DetachedConsumablesAndResourceDict", resourceConsumablesDict);
                        }
                        else if (currentContext.TriggerPoint == DeeTriggerPoint.Post)
                        {
                            printSequence = IKEAConstants.AutomaticPrintingSequenceOnDetach;
                            bool printSource = false;

                            Dictionary<IResource, IMaterialCollection> resourceConsumablesDict = deeContextUtilities.GetContextParameter("CustomAutomationOnManageResourceConsumablesDetach_DetachedConsumablesAndResourceDict") as Dictionary<IResource, IMaterialCollection>;

                            materials = entityFactory.CreateCollection<IMaterialCollection>();
                            foreach (KeyValuePair<IResource, IMaterialCollection> resourceMaterials in resourceConsumablesDict)
                            {
                                foreach (IMaterial detachedMaterial in resourceMaterials.Value)
                                {
                                    if (automaticPrintingUtilities.HasAutomaticPrinting(detachedMaterial, printSequence, out printSource, resource: resourceMaterials.Key))
                                    {
                                        materials.Add(detachedMaterial);
                                        materialResourcesToUse.Add(detachedMaterial.Name, resourceMaterials.Key);
                                    }
                                }
                            }

                            materials.Load();
                            materialStepsToUse = materials.ToDictionary(material => material.Name, material => material.Step);
                        }

                        break;
                    }
                case "SplitMaterial":
                    {
                        // Check if it is a split coming from CustomUnitComplete, if it is, prevent label generation
                        bool? customUnitCompleteSplit = deeContextUtilities.GetContextParameter(IKEAConstants.CustomUnitCompletePalletizationSplitContextKey) as bool?;

                        if (customUnitCompleteSplit != true)
                        {
                            printSequence = IKEAConstants.AutomaticPrintingSequenceOnSplit;

                            SplitMaterialOutput splitMaterialOutput = Input["SplitMaterialOutput"] as SplitMaterialOutput;
                            if (splitMaterialOutput != null)
                            {
                                bool printSource = false;
                                if (automaticPrintingUtilities.HasAutomaticPrinting(splitMaterialOutput.Material, printSequence, out printSource))
                                {
                                    materials = entityFactory.CreateCollection<IMaterialCollection>();
                                    materials.AddRange(splitMaterialOutput.ChildMaterials);
                                    if (printSource)
                                    {
                                        materials.Add(splitMaterialOutput.Material);
                                    }
                                    materialStepsToUse = materials.ToDictionary(material => material.Name, material => material.Step);

                                }
                            }
                        }

                        break;
                    }
                case "CreateMaterial":
                    {
                        printSequence = IKEAConstants.AutomaticPrintingSequenceOnCreate;

                        CreateMaterialOutput output = IKEADEEActionUtilities.GetInputItem<CreateMaterialOutput>(Input, "CreateMaterialOutput");

                        // Get the completed form for the material
                        string completedForm = ikeaUtilities.GetCompletedMaterialForm(output.Material);

                        // Only materials of a completed form will be printed
                        if (output.Material.Form.CompareStrings(completedForm))
                        {
                            bool printSource;
                            materials = entityFactory.CreateCollection<IMaterialCollection>();
                            if (automaticPrintingUtilities.HasAutomaticPrinting(output.Material, printSequence, out printSource))
                            {
                                materials.Add(output.Material);
                            }

                            materialStepsToUse = materials.ToDictionary(material => material.Name, material => material.Step);
                        }

                        break;
                    }
                case "CreateMaterials":
                    {
                        printSequence = IKEAConstants.AutomaticPrintingSequenceOnCreate;

                        CreateMaterialsOutput output = IKEADEEActionUtilities.GetInputItem<CreateMaterialsOutput>(Input, "CreateMaterialsOutput");

                        if (output != null && output.Materials != null && output.Materials.Count > 0)
                        {
                            materials = entityFactory.CreateCollection<IMaterialCollection>();
                            bool printSource = false;

                            foreach (IMaterial material in output.Materials)
                            {
                                // Get the completed form for the material
                                string completedForm = ikeaUtilities.GetCompletedMaterialForm(material);

                                // Only materials of a completed form will be printed
                                if (automaticPrintingUtilities.HasAutomaticPrinting(material, printSequence, out printSource))
                                {
                                    materials.Add(material);
                                }
                            }

                            if (!materials.IsNullOrEmpty())
                            {
                                materialStepsToUse = materials.ToDictionary(material => material.Name, material => material.Step);
                            }

                        }

                        break;
                    }
                case "ChangeMaterialType":
                    {
                        bool? unitCompletion = deeContextUtilities.GetContextParameter(IKEAConstants.ERPChangeTypeReportUnitCompletion) as bool?;
                        if (unitCompletion != true)
                        {
                            printSequence = IKEAConstants.AutomaticPrintingSequenceOnChangeType;
                            ChangeMaterialTypeOutput output = IKEADEEActionUtilities.GetInputItem<ChangeMaterialTypeOutput>(Input, "ChangeMaterialTypeOutput");

                            bool printSource = false;
                            materials = entityFactory.CreateCollection<IMaterialCollection>();
                            if (automaticPrintingUtilities.HasAutomaticPrinting(output.Material, printSequence, out printSource))
                            {
                                materials.Add(output.Material);
                            }

                            materialStepsToUse = materials.ToDictionary(material => material.Name, material => material.Step);
                        }

                        break;
                    }
                case "ChangeMaterialsType":
                    {
                        bool? unitCompletion = deeContextUtilities.GetContextParameter(IKEAConstants.ERPChangeTypeReportUnitCompletion) as bool?;
                        if (unitCompletion != true)
                        {
                            printSequence = IKEAConstants.AutomaticPrintingSequenceOnChangeType;
                            ChangeMaterialsTypeOutput output = IKEADEEActionUtilities.GetInputItem<ChangeMaterialsTypeOutput>(Input, "ChangeMaterialsTypeOutput");

                            if (output != null && output.Materials != null && output.Materials.Count > 0)
                            {
                                materials = entityFactory.CreateCollection<IMaterialCollection>();
                                bool printSource = false;

                                foreach (IMaterial material in output.Materials)
                                {

                                    if (automaticPrintingUtilities.HasAutomaticPrinting(material, printSequence, out printSource))
                                    {
                                        materials.Add(material);
                                    }
                                }

                                if (!materials.IsNullOrEmpty())
                                {
                                    materialStepsToUse = materials.ToDictionary(material => material.Name, material => material.Step);
                                }

                            }
                        }
                        break;
                    }
                case "Merge":
                    {
                        printSequence = IKEAConstants.AutomaticPrintingSequenceOnMerge;
                        IMaterial parentMaterial = IKEADEEActionUtilities.GetInputItem<IMaterial>(Input, "Material");
                        bool printSource = false;
                        materials = entityFactory.CreateCollection<IMaterialCollection>();
                        if (automaticPrintingUtilities.HasAutomaticPrinting(parentMaterial, printSequence, out printSource))
                        {
                            materials.Add(parentMaterial);
                        }

                        materialStepsToUse = materials.ToDictionary(material => material.Name, material => material.Step);
                        break;
                    }
                case "Retrieve":
                    {
                        IMaterialCollection retrieve = IKEADEEActionUtilities.GetInputItem<IMaterialCollection>(Input, Navigo.Common.Constants.MaterialCollection);
                            
                        // Before retrieving the materials, save their PrintingQueue resources on the call context
                        if (currentContext.TriggerPoint == DeeTriggerPoint.Pre)
                        {
                            // Association between material names and the printing queue resource name they belong to (if any)
                            Dictionary<string, IResource> materialStorageResources = new Dictionary<string, IResource>();

                            if (!retrieve.IsNullOrEmpty())
                            {
                                // Load material resource relations
                                retrieve.LoadRelations(Navigo.Common.Constants.MaterialResource);

                                foreach (IMaterial material in retrieve)
                                {
                                    if (material.MaterialResourceRelations != null)
                                    {
                                        // Get the associated resource
                                        IResource printingQueueResource = material.MaterialResourceRelations
                                            .Select(relation => relation.TargetEntity)
                                            .FirstOrDefault();

                                        if (printingQueueResource != null)
                                        {
                                            materialStorageResources[material.Name] = printingQueueResource;
                                        }
                                    }
                                }
                            }

                            // Save the dictionary on the call context to read it in the Post trigger point
                            deeContextUtilities.SetContextParameter(IKEAConstants.CustomAutomaticPrintingDocumentsRetrievePrintingResourcesContextKey, materialStorageResources);
                        }
                        else
                        {
                            printSequence = IKEAConstants.AutomaticPrintingSequenceOnRetrieve;

                            materialResourcesToUse = deeContextUtilities.GetContextParameter(IKEAConstants.CustomAutomaticPrintingDocumentsRetrievePrintingResourcesContextKey)
                                as Dictionary<string, IResource>;

                            if (!retrieve.IsNullOrEmpty())
                            {
                                bool printSource = false;
                                materials = entityFactory.CreateCollection<IMaterialCollection>();
                                foreach (IMaterial material in retrieve)
                                {
                                    IResource printingResource = null;
                                    materialResourcesToUse.TryGetValue(material.Name, out printingResource);

                                    if (automaticPrintingUtilities.HasAutomaticPrinting(material, printSequence, out printSource, resource: printingResource))
                                    {
                                        materials.Add(material);
                                    }
                                }

                                materials.Load();
                                materialStepsToUse = materials.ToDictionary(material => material.Name, material => material.Step);
                            }
                        }

                        break;
                    }

                default:
                    break;
            }

            if (materialStepsToUse != null && materialStepsToUse.Count > 0 && materials != null && materials.Count > 0)
            {
                Dictionary<string, IMaterial> materialDictionary = materials.ToDictionary(E => E.Name, E => E);
                List<Tuple<IMaterial, IStep, IResource>> finalMaterialsAndSteps = materialStepsToUse
                    .Select(E => Tuple.Create(
                        materialDictionary[E.Key], 
                        E.Value,
                        materialResourcesToUse.ContainsKey(E.Key) ? materialResourcesToUse[E.Key] : null
                    ))
                    .ToList();

                automaticPrintingUtilities.GeneratePrintingTimers(finalMaterialsAndSteps, printSequence);
                automaticPrintingUtilities.RegisterMaterialLabelPrinted(finalMaterialsAndSteps.ToDictionary(pair => pair.Item1, pair => pair.Item2));
            }

            
            //---End DEE Code---

            return Input;
        }


    }
}
