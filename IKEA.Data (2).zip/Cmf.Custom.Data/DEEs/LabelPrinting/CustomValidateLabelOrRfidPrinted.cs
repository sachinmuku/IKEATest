﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;

using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Exceptions;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Foundation.Configuration;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace Cmf.Custom.IKEA.Actions.Materials
{
    public class CustomValidateLabelOrRfidPrinted : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   
UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");
            #region Info
            /// <summary>
            /// Summary text
            ///     Validate if the label or rfid have been printed

            /// Action Groups:
            ///     BusinessObjects.MaterialCollection.MoveToStep.Pre
            ///     BusinessObjects.MaterialCollection.MoveToNextStep.Pre
            ///     BusinessObjects.MaterialCollection.ChangeFlowAndStep.Pre
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "BusinessObjects.MaterialCollection.MoveToStep.Pre",
                "BusinessObjects.MaterialCollection.MoveToNextStep.Pre",
                "BusinessObjects.MaterialCollection.ChangeFlowAndStep.Pre"
            };

            // Get flag to ignore label printing validation during the auto dispatch
            bool? ignoreLabelPrintingValidation = deeContextUtilities.GetContextParameter(IKEAConstants.PreDispatchUtilityIgnoreLabelPrintingValidation) as bool?;
            
            // Enforce label print must be enabled to validate
            bool enforceLabelPrint = genericUtilities.GetConfigurationValueByPath<bool>(IKEAConstants.CustomEnforceLabelPrint);

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = enforceLabelPrint 
                                        && IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups) 
                                        && !ignoreLabelPrintingValidation.GetValueOrDefault(false);

            if (executionVeridict && IKEADEEActionUtilities.GetInputItem<IMaterialCollection>(Input, "MaterialCollection") == null)
            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
     

            //System
            UseReference("", "System.Collections.Generic");
            UseReference("", "System");
            UseReference("", "System.Collections.ObjectModel");

            //Foundation
            UseReference("Cmf.Foundation.Configuration.dll", "Cmf.Foundation.Configuration");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Exceptions");
            
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();

            IMaterialCollection materials = Input["MaterialCollection"] as IMaterialCollection;
            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();

            foreach (IMaterial material in materials)
            {
                if (material.Form == IKEAConstants.CustomPrintMOType || material.Form == IKEAConstants.CustomPrintBatchType) continue;
                IStep step = entityFactory.Create<IStep>();
                step = material.Step;
                step.Load();
                
                if (step.HasAttribute(IKEAConstants.CustomPrintOptions, true))
                {
                    if (!step.Attributes[IKEAConstants.CustomPrintOptions].Equals(CustomPrintingOptionsEnum.None))
                    {
                        if (material.HasAttribute(IKEAConstants.CustomIsRfidOrLabelPrinted, true))
                        {
                            if (!Convert.ToBoolean(material.Attributes[IKEAConstants.CustomIsRfidOrLabelPrinted]))
                            {
                                throw new IKEAException(IKEAConstants.CustomValidateIfLabelOrRfidPrinted, material.Name);
                            }
                        }
                        else
                        {
                            throw new IKEAException(IKEAConstants.CustomValidateIfLabelOrRfidPrinted, material.Name);
                        }
                    }

                }

            }

            
            //---End DEE Code---

            return Input;
        }


    }
}
