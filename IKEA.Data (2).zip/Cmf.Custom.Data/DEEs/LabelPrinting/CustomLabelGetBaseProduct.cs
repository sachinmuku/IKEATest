﻿using Cmf.Custom.IKEA.Common;
using Cmf.Navigo.BusinessObjects;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Actions.LabelPrinting
{
    /// <summary>
    /// This DEE Extracts the base product, if existing from a given material
    /// </summary>
    public class CustomLabelGetBaseProduct : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     This DEE Extracts the base product, if existing from a given material
            /// </summary>
            #endregion

            return true;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
UseReference("Cmf.Foundation.BusinessOrchestration.dll", "");
UseReference("", "Cmf.Foundation.Common.Exceptions");
UseReference("", "Cmf.Foundation.Common");
UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");

            // Before read check if material key exists in Input
            IMaterial incomingMaterial = null;
            if (Input.ContainsKey("AppliesToValue"))
            {
                incomingMaterial = Input["AppliesToValue"] as IMaterial;
            }

            // By default, product name shall be N/A
            string returnValue = "N/A";

            // try to extract product base product name and if not default to current product
            if (incomingMaterial != null && incomingMaterial.Product != null)
            {
                IProduct productToCheck = incomingMaterial.Product;
                productToCheck.LoadAttributes(new Collection<string>() { IKEAConstants.CustomProductAttributeBaseProduct });

                // by default return name of the product
                returnValue = productToCheck.Name;

                if (productToCheck.RelatedAttributes != null
                    && productToCheck.RelatedAttributes.ContainsKey(IKEAConstants.CustomProductAttributeBaseProduct)
                    && !String.IsNullOrWhiteSpace(Convert.ToString(productToCheck.RelatedAttributes[IKEAConstants.CustomProductAttributeBaseProduct])))
                {
                    returnValue = Convert.ToString(productToCheck.RelatedAttributes[IKEAConstants.CustomProductAttributeBaseProduct]);
                }
            }

            //Clear Input Dictionary
            Input = new Dictionary<string, object>
            {
                { "Result", returnValue }
            };

         
            //---End DEE Code---

            return null;
        }
    }
}