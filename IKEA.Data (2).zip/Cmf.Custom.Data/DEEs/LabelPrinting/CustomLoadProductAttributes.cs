﻿using Cmf.Custom.IKEA.Common;
using Cmf.Foundation.BusinessObjects;
using Cmf.Navigo.BusinessObjects;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Actions.LabelPrinting
{
    public class CustomLoadProductAttributes : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        /// <summary>
        /// This class is responsible to load product attributes
        /// </summary>
        /// <param name="Input"></param>
        /// <returns></returns>
        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---
UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");


            // Before read check if Product key exists in Input
            IMaterial incomingMaterial = null;
            if (Input.ContainsKey("AppliesToValue"))
            {
                incomingMaterial = Input["AppliesToValue"] as IMaterial;
            }

            IProduct returnValue = null;
            if (incomingMaterial != null)
            {
                returnValue = incomingMaterial.Product;
                returnValue.LoadAttributes(new Collection<string>() { IKEAConstants.ItemDescription });
            }

            //Clear Input Dictionary
            Input = new Dictionary<string, object>
            {
                { "Result", returnValue }
            };


         

            //---End DEE Code---
            return null;
        }

        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---
            return true;
            //---End DEE Condition Code---
        }
    }
}
