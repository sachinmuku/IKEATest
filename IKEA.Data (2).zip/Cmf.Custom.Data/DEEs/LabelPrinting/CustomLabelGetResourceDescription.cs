﻿using Cmf.Navigo.BusinessObjects;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.IKEA.Actions.LabelPrinting
{
    /// <summary>
    /// This DEE tries to extract last processed resource description from an incoming material
    /// </summary>
    public class CustomLabelGetResourceDescription : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     This DEE tries to extract last processed resource description from an incoming material
            /// </summary>
            #endregion

            return true;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
UseReference("Cmf.Foundation.BusinessOrchestration.dll", "");
UseReference("", "Cmf.Foundation.Common.Exceptions");
UseReference("", "Cmf.Foundation.Common");
UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");

            // Before read check if material key exists in Input
            IMaterial incomingMaterial = null;
            if (Input.ContainsKey("AppliesToValue"))
            {
                incomingMaterial = Input["AppliesToValue"] as IMaterial;
            }

            // By default, resource description shall be N/A
            string returnValue = "N/A";

            // try to extract resource description
            if (incomingMaterial != null && incomingMaterial.LastProcessedResource != null)
            {
                returnValue = incomingMaterial.LastProcessedResource.Description ?? returnValue;
            }

            //Clear Input Dictionary
            Input = new Dictionary<string, object>
            {
                { "Result", returnValue }
            };

         
            //---End DEE Code---

            return null;
        }
    }
}