﻿using Cmf.Custom.IKEA.BusinessObjects;
using Cmf.Custom.IKEA.BusinessObjects.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.LabelPrinting
{
    public class CustomGetMaterialLossRecords : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        /// <summary>
        /// This class is responsible to get all the data from the Material loss relation
        /// </summary>
        /// <param name="Input"></param>
        /// <returns></returns>
        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---


            // MES
            UseReference("", "Cmf.Custom.IKEA.BusinessObjects.Abstractions");
UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            // CUSTOM
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.BusinessObjects.CustomMaterialLoss.dll", "Cmf.Custom.IKEA.BusinessObjects");


            var serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();

            //Before read check if Material key exists in Input
            IMaterial material = null;
            if (Input.ContainsKey("AppliesToValue"))
                material = Input["AppliesToValue"] as IMaterial;

            //Sanity check
            ICustomMaterialLossCollection returnVal = entityFactory.CreateCollection<ICustomMaterialLossCollection>();
            if (material != null)
            {
                material.LoadRelations(IKEAConstants.CustomMaterialLoss);
                if (material.RelationCollection != null)
                {
                    var relation = material.RelationCollection.FirstOrDefault(E => String.Equals(E.Key, IKEAConstants.CustomMaterialLoss, StringComparison.InvariantCultureIgnoreCase));
                    if (relation.Value != null)
                    {
                        returnVal.AddRange(relation.Value.Cast<ICustomMaterialLoss>());
                    }
                }
            }

            //Clear Input Dictionary
            Input = new Dictionary<string, object>
            {
                { "Result", returnVal }
            };

            
            //---End DEE Code---
            return null;
        }

        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---
            return true;
            //---End DEE Condition Code---
        }
    }
}
