﻿using Cmf.Custom.IKEA.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Cmf.Common.CustomActionUtilities;

namespace Cmf.Custom.IKEA.Actions.LabelPrinting
{
    /// <summary>
    /// This DEE tries to extract Production order information based an incoming material
    /// </summary>
    public class CustomLabelGetProductionOrder : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     This DEE tries to extract Production order information based an incoming material
            /// </summary>
            #endregion

            return true;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
     


            // CORE
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "");
            UseReference("", "Cmf.Foundation.Common.Exceptions");
            UseReference("", "Cmf.Foundation.Common");

            // MES
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            // CUSTOM
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.BusinessObjects.CustomMaterialBatch.dll", "Cmf.Custom.IKEA.BusinessObjects");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();

            // Before read check if material key exists in Input
            IMaterial incomingMaterial = null;
            if (Input.ContainsKey("AppliesToValue"))
            {
                incomingMaterial = Input["AppliesToValue"] as IMaterial;
            }

            // By default, Production Order shall be an empty object
            IProductionOrder returnValue = entityFactory.Create<IProductionOrder>();
            returnValue.Name = "N/A";
            returnValue.Quantity = 0;
            
            // try to extract resource name
            if (incomingMaterial != null && incomingMaterial.ProductionOrder != null)
            {
                returnValue = incomingMaterial.ProductionOrder;
            }
            else if (!String.IsNullOrWhiteSpace(incomingMaterial.Name))
            {
                // try to extract order from pallet Id
                string[] palletIdentifiers = incomingMaterial.Name.Split('.');
                IProductionOrder theoreticalOrder = entityFactory.Create<IProductionOrder>();
                theoreticalOrder.Name = palletIdentifiers[0];
                if (theoreticalOrder.ObjectExists())
                {
                    theoreticalOrder.Load();
                    returnValue = theoreticalOrder;
                }
                else if (incomingMaterial.Attributes.ContainsKey(IKEAConstants.CustomMaterialAttributeBaseMaterial))
                {
                    // try to extract order from pallet Id
                    returnValue = entityFactory.Create<IProductionOrder>();
                    returnValue.Name = incomingMaterial.GetAttributeValueOrDefault<string>(IKEAConstants.CustomMaterialAttributeBaseMaterial);
                    returnValue.Quantity = incomingMaterial.PrimaryQuantity;
                }
            }
            
            //Clear Input Dictionary
            Input = new Dictionary<string, object>
            {
                { "Result", returnValue }
            };

            
            //---End DEE Code---

            return null;
        }
    }
}