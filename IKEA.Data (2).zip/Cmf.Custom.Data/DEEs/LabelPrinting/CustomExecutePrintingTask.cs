﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.IKEA.Actions.LabelPrinting
{
    /// <summary>
    /// This DEE serves as an actiont to be executed during the palletization process when invoked by the Rule with the same name
    /// </summary>
    public class CustomExecutePrintingTask : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text:
            ///     This DEE serves as an actiont to be executed during the palletization process when invoked by the Rule with the same name
            /// Action Groups:
            ///     None
            /// </summary>
            #endregion

            bool executionVeridict = IKEADEEActionUtilities.GetInputItem<ICmfTimer>(Input, "CmfTimer") != null;

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
     

            //System
            UseReference("", "System.Linq");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.IO");
            UseReference("", "System.Threading");
            UseReference("", "System");

            //Foundation
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            IAutomaticPrintingUtilities automaticPrintingUtilities = serviceProvider.GetService<IAutomaticPrintingUtilities>();

            ICmfTimer cmfTimer = IKEADEEActionUtilities.GetInputItem<ICmfTimer>(Input, "CmfTimer");

            // CustomExecutePrintingTask_{GUID}_{MaterialId}_{StepId}_{PrintSequence}
            string[] timerNameTokens = cmfTimer.Name.Split('_');

            if (timerNameTokens != null && timerNameTokens.Length == 5)
            {
                // load material
                IMaterial incomingMaterial = entityFactory.Create<IMaterial>();
                incomingMaterial.Load(Convert.ToInt64(timerNameTokens[2]));

                // incoming step
                IStep incomingStep = entityFactory.Create<IStep>();
                incomingStep.Load(Convert.ToInt64(timerNameTokens[3]));

                // Load custom resource from timer if needed
                IResource resource = null;
                string resourceName = cmfTimer.GetAttributeValueOrDefault<string>(IKEAConstants.CmfTimerAttributePrintCustomResource, true);
                if (resourceName != null)
                {
                    resource = entityFactory.Create<IResource>();
                    resource.Name = resourceName;
                    resource.Load();
                }

                // incoming print sequence
                string incomingSequence = timerNameTokens[4];
                var step = entityFactory.Create<IStep>();
                step.Name = incomingStep.Name;

                automaticPrintingUtilities.ResolveAndPrintAutomaticPrintableDocuments(
                    incomingMaterial, step, incomingSequence,
                    // Optional resource
                    resource: resource
                );
            }

            Input["Result"] = true;

            
            //---End DEE Code---

            return Input;
        }


    }
}
