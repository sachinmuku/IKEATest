﻿using Cmf.Custom.IKEA.Common;
using Cmf.Navigo.BusinessObjects;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Common.CustomActionUtilities;
using Cmf.Custom.IKEA.Common.Abstractions;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;


namespace Cmf.Custom.IKEA.Actions.LabelPrinting
{
    public class CustomGetGS1LabelInformation : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Action to obtain a GS1 label string for a given material
            /// </summary>
            #endregion

            return true;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
     

            //System
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("", "System.Text");

            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");

            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");

            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");

            // Before read check if Product key exists in Input
            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];

            IMaterial incomingMaterial = IKEADEEActionUtilities.GetInputItem<IMaterial>(Input, "AppliesToValue");
            IGenericUtilities _genericUtilities = serviceProvider.GetService<IGenericUtilities>();

            StringBuilder gs1Builder = new StringBuilder();

            if (incomingMaterial != null && 
                incomingMaterial.Product != null && 
                incomingMaterial.Name != null && 
                incomingMaterial.PrimaryQuantity != null)
            {

                // Get GS1 Tokens
                string productToken = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.GS1ProductToken);                
                string palletNameToken = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.GS1PalletNameToken);
                string quantityToken = _genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.GS1QuantityToken);

                // Load Base Product
                incomingMaterial.Product.LoadAttributes(new Collection<string>() { IKEAConstants.CustomProductAttributeBaseProduct });

                // Token Format (e.g.: (12)Cutting Board Cut Board 30x30_001)
                string tokenFormat = "({0}){1}";

                // Char separator
                char separator = (char)29;

                // Get the base product. If it does not exist get the product name:
                string baseProduct = incomingMaterial.Product.GetRelatedAttributeValueOrDefault<string>(IKEAConstants.CustomProductAttributeBaseProduct);
                if (baseProduct.IsNullOrEmpty())
                {
                    baseProduct = incomingMaterial.Product.Name;
                }

                // Build GS1 label information
                gs1Builder.AppendFormat(tokenFormat, productToken, baseProduct) // Product
                            .Append(separator)
                            .AppendFormat(tokenFormat, palletNameToken, incomingMaterial.Name) // Pallet Name
                            .Append(separator)
                            .AppendFormat("({0}){1:######0}", quantityToken, incomingMaterial.PrimaryQuantity); // Pallet Quantity
            }

            // Clear Input Dictionary
            Input = new Dictionary<string, object>
            {
                { "Result", gs1Builder.ToString()}
            };

            
            //---End DEE Code---

            return null;
        }
    }
}
