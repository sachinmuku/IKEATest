﻿using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.RecipeManagement.OutputObjects;
using Microsoft.Extensions.DependencyInjection;
using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Cmf.Custom.IKEA.Actions.ParallelExecution
{
    public class CustomOverrideRecipeParametersOnParallel : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Overrides the parameter values in the preview menu of a recipe during the trackin wizard.
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "RecipeManagement.RecipeManagement.PreviewRecipeInstance.Post",
            };

            // only proceed if within expected triggers (action groups)
            bool isActionGroupValid = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            return isActionGroupValid;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     

            // System
            UseReference("", "System.Linq");
            UseReference("", "System");

            // Foundation
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration");
            UseReference("Cmf.Foundation.BusinessObjects.dll", "Cmf.Foundation.BusinessObjects");

            // MES
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");

            // Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Extensions");
            
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");

            // RecipeManagement
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.RecipeManagement");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.RecipeManagement.InputObjects");
            UseReference("Cmf.Navigo.BusinessOrchestration.dll", "Cmf.Navigo.BusinessOrchestration.RecipeManagement.OutputObjects");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
            IGenericUtilities genericUtilities = serviceProvider.GetService<IGenericUtilities>();


            bool isInParallelMode;
            List<string> linkedParallelProducts = null;

            PreviewRecipeInstanceOutput previewRecipeInstanceOutput = null;
            previewRecipeInstanceOutput = Input["PreviewRecipeInstanceOutput"] as PreviewRecipeInstanceOutput;

            if (previewRecipeInstanceOutput.RecipeInstance == null || !previewRecipeInstanceOutput.RecipeInstance.RelationCollection.ContainsKey(Navigo.Common.Constants.RecipeInstanceParameter))
            {
                return Input;
            }

            if (previewRecipeInstanceOutput.RecipeInstance.Material == null || previewRecipeInstanceOutput.RecipeInstance.Resource == null || previewRecipeInstanceOutput.RecipeInstance.ParentEntity == null)
            {
                return Input;
            }

            IEntityRelationCollection<IEntityRelation> recipeInstanceParameterRelations = previewRecipeInstanceOutput.RecipeInstance.RelationCollection[Navigo.Common.Constants.RecipeInstanceParameter];

            if (recipeInstanceParameterRelations.Any(parameterRelation => parameterRelation.TargetEntity.Name.Contains(IKEAConstants.ParallelModeRecipeParameter)))
            {
                (isInParallelMode, linkedParallelProducts) = ikeaUtilities.ResolveCustomParallelExecutionRecipeModeSmartTable(previewRecipeInstanceOutput.RecipeInstance.Material, previewRecipeInstanceOutput.RecipeInstance.Resource, previewRecipeInstanceOutput.RecipeInstance.ParentEntity);

                recipeInstanceParameterRelations.FirstOrDefault(relation => relation.TargetEntity.Name.Contains(IKEAConstants.ParallelModeRecipeParameter)).SetNativeValue("Value", isInParallelMode ? "1" : "0");
            }

            if (recipeInstanceParameterRelations.Any(parameterRelation => parameterRelation.TargetEntity.Name.Contains(IKEAConstants.ParallelProductRecipeParameter)))
            {
                if (linkedParallelProducts == null)
                {
                    return Input;
                }

                string separatorParallelProduct = genericUtilities.GetConfigurationValueByPath<string>(IKEAConstants.ParallelExecutionParallelProductSeparator);
                string parallelProductNames = String.Join(separatorParallelProduct, linkedParallelProducts.ToArray());
                recipeInstanceParameterRelations.FirstOrDefault(relation => relation.TargetEntity.Name.Contains(IKEAConstants.ParallelProductRecipeParameter)).SetNativeValue("Value", parallelProductNames);
            }

            //---End DEE Code---

            return Input;
        }

    }
}
