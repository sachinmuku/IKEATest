﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.IKEA.Common;
using Cmf.Custom.IKEA.Common.Abstractions;
using Cmf.Custom.IKEA.Common.Exceptions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessOrchestration;
using Cmf.Foundation.BusinessOrchestration.GenericServiceManagement.OutputObjects;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;

using System;
using Cmf.Custom.IKEA.Common.DEE;
using Cmf.Custom.IKEA.Common.DataStructures;
using Cmf.Custom.IKEA.Common.Enums;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Threading;
using INotification = Cmf.Navigo.BusinessObjects.Abstractions.INotification;

namespace Cmf.Custom.IKEA.Actions.Resources
{
    public class CustomSetEffectiveFlowFeedbackMessage : Cmf.Foundation.Common.DynamicExecutionEngine.RuleEvaluatorAdapter
    {
        public override bool ValidateAction(Dictionary<string, object> Input)
        {
            //---Start DEE Condition Code---   

            #region Info
            /// <summary>
            /// Summary text
            ///     Creates a notification for the user when a flow is set effective
            /// Action Groups:
            ///     GenericServiceManagement.GenericServiceManagementOrchestration.SetObjectVersionsEffective.Post
            ///     GenericServiceManagement.GenericServiceManagementOrchestration.SetObjectVersionEffective.Post
            /// Depends On:
            /// Is Dependency For:
            /// Exceptions:
            /// </summary>
            #endregion

            // List of eligible action groups (configuration sanity check)
            Collection<string> EligibleActionGroups = new Collection<string>()
            {
                "GenericServiceManagement.GenericServiceManagementOrchestration.SetObjectVersionsEffective.Post",
                "GenericServiceManagement.GenericServiceManagementOrchestration.SetObjectVersionEffective.Post"
            };

            // only proceed if within expected triggers (action groups)
            bool executionVeridict = IKEADEEActionUtilities.IsActionGroupValid(Input, EligibleActionGroups);

            if (executionVeridict && IKEADEEActionUtilities.GetInputItem<SetObjectVersionEffectiveOutput>(Input, "SetObjectVersionEffectiveOutput") == null
                                  && IKEADEEActionUtilities.GetInputItem<SetObjectVersionsEffectiveOutput>(Input, "SetObjectVersionsEffectiveOutput") == null)
            {
                executionVeridict = false;
            }

            return executionVeridict;

            //---End DEE Condition Code---
        }

        public override Dictionary<string, object> EvaluateRule(Dictionary<string, object> Input)
        {
            //---Start DEE Code---     
UseReference("%MicrosoftNetPath%System.Private.CoreLib.dll", "System.Threading");
     

            //System
            UseReference("", "System");
            UseReference("", "System.Collections.Generic");
            UseReference("", "System.Collections.ObjectModel");
            UseReference("%MicrosoftNetPath%\\System.Data.dll", "System.Data");
            UseReference("%MicrosoftNetPath%\\System.XML.dll", "System.Xml");
            //Custom
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Enums");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DEE");
UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.DataStructures");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Exceptions");
            UseReference("Cmf.Custom.IKEA.Common.dll", "Cmf.Custom.IKEA.Common.Abstractions");
            //Foundation
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration");
            UseReference("Cmf.Foundation.BusinessOrchestration.dll", "Cmf.Foundation.BusinessOrchestration.GenericServiceManagement.OutputObjects");
            UseReference("", "Cmf.Foundation.Common");
            //Navigo
            UseReference("Cmf.Navigo.BusinessObjects.dll", "Cmf.Navigo.BusinessObjects");
            //Common
            UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities");
UseReference("Cmf.Common.CustomActionUtilities.dll", "Cmf.Common.CustomActionUtilities.Abstractions");

            IServiceProvider serviceProvider = (IServiceProvider)Input["ServiceProvider"];
            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
            
            IIKEAUtilities ikeaUtilities = serviceProvider.GetService<IIKEAUtilities>();
           
            ILocalizedMessage _localizedMessage = serviceProvider.GetService<ILocalizedMessage>();
            IGenericUtilities _genericUtilities = serviceProvider.GetService<IGenericUtilities>();
            IDeeContextUtilities deeContextUtilities = serviceProvider.GetRequiredService<IDeeContextUtilities>();


            BaseOutput output = null;
            FeedbackMessage feedbackMessage = new FeedbackMessage();
            if (Input.ContainsKey("SetObjectVersionEffectiveOutput"))
            {
                var objectSetEffective = Input["SetObjectVersionEffectiveOutput"] as SetObjectVersionEffectiveOutput;
                output = objectSetEffective;
                if (objectSetEffective.Object is IFlow)
                {
                    feedbackMessage = new FeedbackMessage
                    {
                        MessageType = FeedbackMessageType.Information,
                        Message = _localizedMessage.LoadLocalizedMessage(Thread.CurrentThread.CurrentCulture.Name, IKEAConstants.CustomVerifyFlowPathsInSmartTable).MessageText
                    };
                }
            }
            else if (Input["SetObjectVersionsEffectiveOutput"] is SetObjectVersionsEffectiveOutput)
            {
                var objectsSetEffective = Input["SetObjectVersionsEffectiveInput"] as SetObjectVersionsEffectiveOutput;
                output = objectsSetEffective;
                if (objectsSetEffective.Objects is IFlowCollection)
                {
                    feedbackMessage = new FeedbackMessage
                    {
                        MessageType = FeedbackMessageType.Information,
                        Message = _localizedMessage.LoadLocalizedMessage(Thread.CurrentThread.CurrentCulture.Name, IKEAConstants.CustomVerifyFlowPathsInSmartTable).MessageText
                    };
                }
            }

            if (output.FeedbackMessages == null)
            {
                output.FeedbackMessages = new Collection<FeedbackMessage>();
            }

            output.FeedbackMessages.Add(feedbackMessage);

            IEmployee employee = ikeaUtilities.GetCurrentEmployee();
            if (employee != null && employee.Name != null && employee.UniversalState != Foundation.Common.Base.UniversalState.Terminated)
            {
                //Validate if Severity exists in config
                string severity = ikeaUtilities.GetValueFromConfigurationWithPath(IKEAConstants.DefaultNotificationSeverityConfig);

                if (severity.IsNullOrEmpty())
                {
                    throw new IKEAException(IKEAConstants.CustomDefaultNotificationSeverityConfigNotDefined, IKEAConstants.DefaultNotificationSeverityConfig);
                }

                Cmf.Navigo.BusinessObjects.Abstractions.INotification notification = entityFactory.Create<Cmf.Navigo.BusinessObjects.Abstractions.INotification>();

                notification.Type = "System";
                notification.Title = _localizedMessage.LoadLocalizedMessage(Thread.CurrentThread.CurrentCulture.Name, IKEAConstants.CustomVerifyFlowPathsInSmartTable).MessageText;
                notification.Details = _localizedMessage.LoadLocalizedMessage(Thread.CurrentThread.CurrentCulture.Name, IKEAConstants.CustomVerifyFlowPathsInSmartTable).MessageText;
                notification.Severity = ikeaUtilities.GetValueFromLookupTable(IKEAConstants.NotificationSeverityLookupTableName, severity, true);
                notification.AssignmentType = (NotificationAssignmentType)AssignmentType.Employee;
                notification.AssignedToUser = employee.User;
                
                notification.Create();
            }

            
            //---End DEE Code---

            return Input;
        }




    }
}
