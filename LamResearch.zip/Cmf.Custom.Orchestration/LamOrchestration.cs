﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using Cmf.Common.CustomActionUtilities;
using Cmf.Custom.Lam.BusinessObjects;
using Cmf.Custom.Lam.BusinessObjects.Abstractions;
using Cmf.Custom.Lam.Common;
using Cmf.Custom.Lam.Common.Interfaces;
using Cmf.Custom.Lam.Common.Utilities;
using Cmf.Custom.Lam.Orchestration.InputObjects;
using Cmf.Custom.Lam.Orchestration.OutputObjects;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessObjects.GenericTables;
using Cmf.Foundation.BusinessOrchestration;
using Cmf.Foundation.BusinessOrchestration.Abstractions;
using Cmf.Foundation.BusinessOrchestration.GenericServiceManagement.InputObjects;
using Cmf.Foundation.BusinessOrchestration.SecurityManagement.InputObjects;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Foundation.Common.LocalizationService;
using Cmf.Foundation.Security;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.LaborManagement;
using Cmf.Navigo.BusinessOrchestration.LaborManagement.InputObjects;
using Microsoft.Extensions.DependencyInjection;
using AttributeCollection = Cmf.Foundation.BusinessObjects.AttributeCollection;

namespace Cmf.Custom.Lam.Orchestration
{
    public class LamOrchestration : ILamOrchestration
    {
        private const string OBJECT_TYPE_NAME = "Cmf.Custom.Lam.Orchestration.LamManagementOrchestration";
        private readonly IMaterial material;
        private readonly IMaterialCollection materialCollection;
        private readonly IBOM bom;
        private readonly IGenericServiceOrchestration genericServiceOrchestration;
        private readonly IEntityFactory entityFactory;
        private readonly ILocalizationService localizationService;
        private readonly IMetrologyEstimatesQueries metrologyEstimatesQueries;

        public LamOrchestration(
            IMaterial material,
            IMaterialCollection materialCollection,
            IBOM bom,
            IGenericServiceOrchestration genericServiceOrchestration,
            IEntityFactory entityFactory,
            ILocalizationService localizationService,
            IMetrologyEstimatesQueries metrologyEstimatesQueries)
        {
            this.material = material;
            this.materialCollection = materialCollection;
            this.bom = bom;
            this.genericServiceOrchestration = genericServiceOrchestration;
            this.entityFactory = entityFactory;
            this.localizationService = localizationService;
            this.metrologyEstimatesQueries = metrologyEstimatesQueries;
        }

        public AssembleMaterialWithCustomQtyOutput AssembleMaterialWithCustomQty(AssembleMaterialWithCustomQtyIntput assembleMaterialsInput)
        {
            Utilities.ValidateNullInput(assembleMaterialsInput);
            Utilities.StartMethod(OBJECT_TYPE_NAME, "AssembleMaterialWithCustomQty",
                    new KeyValuePair<string, object>(nameof(AssembleMaterialWithCustomQtyIntput),
                        assembleMaterialsInput));

            // Copying the  data from input to output
            AssembleMaterialWithCustomQtyOutput assembleMaterialsOutput = new()
            {
                AssembleQuantity = assembleMaterialsInput.AssembleQuantity,
                Material = assembleMaterialsInput.Material,
                SourceMaterials = assembleMaterialsInput.SourceMaterials
            };

            try
            {
                // Fetching the bom from a custom attribute of the main material
                if (assembleMaterialsOutput.Material.Attributes.TryGetValue(LamConstants.MaterialAttachmentBOMCurrent, out dynamic bomName))
                {
                    bom.Name = bomName;
                    bom.Load();
                    bom.LoadBOMProductsForStep(0, assembleMaterialsOutput.Material.Step);
                }
                var bomProducts = bom.BomProducts;
                bomProducts?.Load(1);

                // Load Material and existing children to avoid issues on Splitting
                assembleMaterialsOutput.Material.Load();
                assembleMaterialsOutput.Material.LoadChildren(0, true);

                // creating materials from bomProducts which has IsReference property set to true if there are no materials in SourceMaterials 
                if ((bomProducts != null && bomProducts.Count > 0))
                {
                    if (assembleMaterialsOutput.SourceMaterials == null)
                        assembleMaterialsOutput.SourceMaterials = new AssembleMaterialCollection();

                    foreach (BOMProduct bomProduct in bomProducts)
                    {
                        if (bomProduct?.IsReference ?? false)
                        {
                            // If a BomProduct has the IsReference flag on true without a SerializationSize defined, a feedback message will be sent.
                            if (bomProduct.TargetEntity.MaterialTransferSerializationSize == null)
                            {
                                if (assembleMaterialsOutput.FeedbackMessages == null)
                                {
                                    assembleMaterialsOutput.FeedbackMessages = new Collection<FeedbackMessage>();
                                }
                                assembleMaterialsOutput.FeedbackMessages.Add(new FeedbackMessage()
                                {
                                    Message = $"BOM Product {bomProduct.TargetEntity.Name} has IsReference property set to true, but there is no MaterialTransferSerializationSize defined.",
                                    MessageType = FeedbackMessageType.Warning,
                                }); ;
                            }
                            material.Name = NameGenerator.GenerateName("SplitLotNameGenerator", bomProduct.TargetEntity);
                            material.Description = bomProduct.TargetEntity.Description;
                            material.Type = bomProduct.TargetEntity?.DefaultMaterialType;
                            material.PrimaryQuantity = bomProduct.Quantity;
                            material.PrimaryUnits = bomProduct.TargetEntity?.DefaultUnits;
                            material.Form = bomProduct.TargetEntity?.DefaultMaterialForm;
                            material.Product = bomProduct.TargetEntity;
                            material.Facility = assembleMaterialsOutput.Material.Facility;
                            material.Flow = bomProduct.TargetEntity.Flow;
                            material.Step = bomProduct.TargetEntity.Step;
                            if (assembleMaterialsOutput.Material.SecondaryQuantity != null)
                            {
                                material.SecondaryQuantity = 0;
                                material.SecondaryUnits = assembleMaterialsOutput.Material.SecondaryUnits;
                            }
                            material.Create();
                            assembleMaterialsOutput.SourceMaterials.Add(new AssembleMaterial()
                            {
                                Material = material,
                                SourceProduct = bomProduct.TargetEntity,
                                Quantity = bomProduct?.Quantity ?? 0,
                                BOMProduct = bomProduct
                            });
                        }
                    }
                }

                foreach (var assembleMaterial in assembleMaterialsOutput.SourceMaterials)
                {
                    //reload material as material information passed from Assembly GUI is not always complete
                    assembleMaterial.Material.Load();

                    // source products are serialized if a SerializationSize is defined and if it is greater then the assemble quantity
                    var sourceProduct = assembleMaterial.SourceProduct;
                    sourceProduct.Load();
                    decimal? serializationSize = sourceProduct.MaterialTransferSerializationSize;

                    MaterialCollection materialsToAssemble = new MaterialCollection();

                    if (serializationSize != null
                    && serializationSize > 0
                    && (assembleMaterial.Material.PrimaryQuantity > serializationSize || assembleMaterial.Material.Form != sourceProduct.DefaultMaterialForm))
                    {
                        var splitInputParametersCollection = new SplitInputParametersCollection();
                        var materialQuantity = assembleMaterial.Quantity;

                        while (materialQuantity > 0)
                        {
                            var splitQty = Math.Min(serializationSize.Value, materialQuantity);
                            splitInputParametersCollection.Add(new SplitInputParameters
                            {
                                Name = NameGenerator.GenerateName("SplitLotNameGenerator", assembleMaterial.Material),
                                PrimaryQuantity = splitQty,
                                SecondaryQuantity = (assembleMaterial.Material.SecondaryQuantity != null) ? 0 : null,
                            });

                            materialQuantity -= serializationSize.Value;
                        }

                        if (splitInputParametersCollection.Any())
                        {
                            var splitMaterials = assembleMaterial.Material.Split(splitInputParametersCollection, true);

                            // Form conversion
                            // if the DefaultMaterialForm of the Material's Product is defined
                            // And if it is different then the current form of the material
                            // the material will be converted as its Product defines
                            if (sourceProduct.DefaultMaterialForm != null
                                && sourceProduct.DefaultMaterialForm != assembleMaterial.Material.Form)
                            {
                                foreach (IMaterial material in splitMaterials)
                                {
                                    if (material.ParentMaterial != null)
                                    {
                                        material.ParentMaterial.RemoveSubMaterials(new MaterialCollection() { material }, false);
                                    }
                                    material.Form = sourceProduct.DefaultMaterialForm;
                                    material.Save();
                                }
                            }
                            materialsToAssemble.AddRange
                                (splitMaterials);
                        }
                    }
                    else
                    {

                        // If material quantity exceeds required quantity
                        if (assembleMaterial.Material.PrimaryQuantity > assembleMaterial.Quantity)
                        {
                            LamUtilities.ThrowLocalizedException(LamConstants.LocalizedExceptions.MaterialQuantityBiggerThenBomQuantity, assembleMaterial.Material.Name, assembleMaterial.Material.PrimaryQuantity.ToString(), assembleMaterial.Quantity.ToString(), bom.Name);
                        }

                        //if the source Material already has a parent (e.g. Test Wafer lot with wafers) detach it first
                        if (assembleMaterial.Material.ParentMaterial != null)
                            assembleMaterial.Material.ParentMaterial.RemoveSubMaterials(new MaterialCollection() { assembleMaterial.Material }, false);

                        materialsToAssemble.Add(assembleMaterial.Material);
                    }

                    string lastMaterialForm = materialsToAssemble.Last().Form;
                    bool differentForms = false;
                    if (assembleMaterialsOutput.Material.SubMaterials != null && assembleMaterialsOutput.Material.SubMaterials.Count > 0)
                    {
                        foreach (var existingSubMaterial in assembleMaterialsOutput.Material.SubMaterials)
                        {
                            if (existingSubMaterial.Form != lastMaterialForm)
                            {
                                differentForms = true;
                                break;
                            }
                        }
                    }

                    if (differentForms)
                    {
                        var splitInputParametersCollection = new SplitInputParametersCollection();
                        splitInputParametersCollection.Add(new SplitInputParameters()
                        {
                            Name = NameGenerator.GenerateName("SplitLotNameGenerator", assembleMaterialsOutput.Material),
                            PrimaryQuantity = 0,
                            SecondaryQuantity = (assembleMaterialsOutput.Material.SecondaryQuantity != null) ? 0 : null,
                            SubMaterials = new SplitInputSubMaterialCollection() { }
                        });

                        IMaterialCollection splitMainMaterial = assembleMaterialsOutput.Material.Split(splitInputParametersCollection, false);
                        splitMainMaterial[0].SpecialAddSubMaterials(materialsToAssemble, new OperationAttributeCollection());
                        assembleMaterialsOutput.Material.TransferSubMaterials(splitMainMaterial[0].SubMaterials, null, null, null, true, true, new OperationAttributeCollection());
                        splitMainMaterial[0].Load();
                        splitMainMaterial[0].Terminate(new OperationAttributeCollection());
                    }
                    else
                    {
                        assembleMaterialsOutput.Material.SpecialAddSubMaterials
                            (materialsToAssemble, new OperationAttributeCollection());
                    }
                    assembleMaterialsOutput.Material.SaveAttributes(new AttributeCollection()
                    {
                        { LamConstants.MaterialAttachmentBOMIsComplete,true }
                    });
                }

            }
            catch (CmfBaseException)
            {
                throw;

            }
            catch (Exception e)
            {
                throw new CmfBaseException(e.Message, e);
            }
            finally
            {
                // throw new NotImplementedException();

                Utilities.EndMethod(-1, -1,
                    new KeyValuePair<string, object>(nameof(AssembleMaterialWithCustomQtyIntput), assembleMaterialsInput),
                    new KeyValuePair<string, object>(nameof(AssembleMaterialWithCustomQtyOutput), assembleMaterialsOutput));
            }
            return assembleMaterialsOutput;
        }

        public CustomResolveGTForProjectCodeOutput CustomResolveGTForProjectCode(CustomResolveGTForProjectCodeInput customResolveGTForProjectCodeInput)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomResolveGTForProjectCode",
                    new KeyValuePair<string, object>("CustomResolveGTForProjectCodeInput",
                        customResolveGTForProjectCodeInput));

            // Copying the  data from input to output
            CustomResolveGTForProjectCodeOutput customResolveGTForProjectCodeOutput = new CustomResolveGTForProjectCodeOutput();
            List<string> ignoreUnit = new List<string>();
            List<string> ignoreSubGroup = new List<string>();
            List<string> ignoreProductLine = new List<string>();
            List<string> ignoreApplication = new List<string>();
            string processGroup = String.Empty;
            string processGroupID = String.Empty;
            string businessUnit = String.Empty;
            string subGroup = String.Empty;
            string productLine = String.Empty;
            string applic = String.Empty;
            customResolveGTForProjectCodeOutput.SelectedProcessGroup = processGroup;
            customResolveGTForProjectCodeOutput.SelectedBusinessUnit = String.Empty;
            customResolveGTForProjectCodeOutput.SelectedSubGroup = String.Empty;
            customResolveGTForProjectCodeOutput.SelectedProductLine = String.Empty;
            customResolveGTForProjectCodeOutput.SelectedApplication = String.Empty;
            customResolveGTForProjectCodeOutput.HasInformation = true;

            #region Parse DropDownSelector
            if (customResolveGTForProjectCodeInput.ProcessGroup != null)
            {
                string parserID = customResolveGTForProjectCodeInput.ProcessGroup.ToString().Split(',')[0].Trim().Split(':')[1];
                processGroupID = Regex.Replace(parserID, @"^\s*""?|""?\s*$[^0-9a-zA-Z/]^\s*""?|""?\s*$+", "").Trim();

                string parser = customResolveGTForProjectCodeInput.ProcessGroup.ToString().Split(',')[1].Trim().Split(':')[1];
                processGroup = Regex.Replace(parser, @"^\s*""?|""?\s*$[^0-9a-zA-Z/]^\s*""?|""?\s*$+", "").Trim();
                customResolveGTForProjectCodeOutput.SelectedProcessGroup = processGroup;
            }

            if (customResolveGTForProjectCodeInput.BusinessUnit != null)
            {
                string parser = customResolveGTForProjectCodeInput.BusinessUnit.ToString().Split(',')[1].Trim().Split(':')[1];
                businessUnit = Regex.Replace(parser, @"^\s*""?|""?\s*$[^0-9a-zA-Z/]^\s*""?|""?\s*$+", "").Trim();
                customResolveGTForProjectCodeOutput.SelectedBusinessUnit = businessUnit;
            }

            if (customResolveGTForProjectCodeInput.CustomSubGroup != null)
            {
                string parser = customResolveGTForProjectCodeInput.CustomSubGroup.ToString().Split(',')[1].Trim().Split(':')[1];
                subGroup = Regex.Replace(parser, @"^\s*""?|""?\s*$[^0-9a-zA-Z/]^\s*""?|""?\s*$+", "").Trim();
                customResolveGTForProjectCodeOutput.SelectedSubGroup = subGroup;
            }

            if (customResolveGTForProjectCodeInput.CustomProductLine != null)
            {
                string parser = customResolveGTForProjectCodeInput.CustomProductLine.ToString().Split(',')[1].Trim().Split(':')[1];
                productLine = Regex.Replace(parser, @"^\s*""?|""?\s*$[^0-9a-zA-Z/]^\s*""?|""?\s*$+", "").Trim();
                customResolveGTForProjectCodeOutput.SelectedProductLine = productLine;
            }

            if (customResolveGTForProjectCodeInput.CustomApplication != null)
            {
                string parser = customResolveGTForProjectCodeInput.CustomApplication.ToString().Split(',')[1].Trim().Split(':')[1];
                applic = Regex.Replace(parser, @"^\s*""?|""?\s*$[^0-9a-zA-Z/]^\s*""?|""?\s*$+", "").Trim();
                if (applic.Equals("3DNAND and DRAM"))
                {
                    applic += " :" + customResolveGTForProjectCodeInput.CustomApplication.ToString().Split(',')[1].Trim().Split(':')[2].ToString().TrimEnd('\t', '"');
                }
                customResolveGTForProjectCodeOutput.SelectedApplication = applic;
            }
            #endregion

            try
            {
                if (string.IsNullOrEmpty(applic))
                {
                    GenericTable customGroupDependencies = new();
                    customGroupDependencies = new();
                    DataSet customGroupDependenciesDataSet = new();
                    customGroupDependencies.Load("CustomGroupDependencies");
                    if (customResolveGTForProjectCodeInput.BusinessUnit != null && customResolveGTForProjectCodeInput.CustomSubGroup == null)
                    {
                        customGroupDependencies.LoadData(new Cmf.Foundation.BusinessObjects.QueryObject.FilterCollection()
                        {
                            new Cmf.Foundation.BusinessObjects.QueryObject.Filter
                            {
                                LogicalOperator = LogicalOperator.AND,
                                Name = LamConstants.ProcessGroup,
                                Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                                Value = processGroup
                            },
                            new Cmf.Foundation.BusinessObjects.QueryObject.Filter
                            {
                                LogicalOperator = LogicalOperator.OR,
                                Name = LamConstants.BusinessUnit,
                                Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                                Value = businessUnit
                            }
                        });
                    }
                    else if (customResolveGTForProjectCodeInput.CustomSubGroup != null)
                    {
                        customGroupDependencies.LoadData(new Cmf.Foundation.BusinessObjects.QueryObject.FilterCollection()
                        {
                            new Cmf.Foundation.BusinessObjects.QueryObject.Filter
                            {
                                LogicalOperator = LogicalOperator.AND,
                                Name = LamConstants.ProcessGroup,
                                Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                                Value = processGroup
                            },
                            new Cmf.Foundation.BusinessObjects.QueryObject.Filter
                            {
                                LogicalOperator = LogicalOperator.OR,
                                Name = LamConstants.BusinessUnit,
                                Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                                Value = businessUnit
                            },
                            new Cmf.Foundation.BusinessObjects.QueryObject.Filter
                            {
                                LogicalOperator = LogicalOperator.OR,
                                Name = LamConstants.PropertySubGroup,
                                Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                                Value = subGroup
                            }
                        });
                    }
                    else if (customResolveGTForProjectCodeInput.CustomProductLine != null)
                    {
                        customGroupDependencies.LoadData(new Cmf.Foundation.BusinessObjects.QueryObject.FilterCollection()
                        {
                            new Cmf.Foundation.BusinessObjects.QueryObject.Filter
                            {
                                LogicalOperator = LogicalOperator.AND,
                                Name = LamConstants.ProcessGroup,
                                Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                                Value = processGroup
                            },
                            new Cmf.Foundation.BusinessObjects.QueryObject.Filter
                            {
                                LogicalOperator = LogicalOperator.OR,
                                Name = LamConstants.BusinessUnit,
                                Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                                Value = businessUnit
                            },
                            new Cmf.Foundation.BusinessObjects.QueryObject.Filter
                            {
                                LogicalOperator = LogicalOperator.OR,
                                Name = LamConstants.PropertySubGroup,
                                Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                                Value = subGroup
                            },
                            new Cmf.Foundation.BusinessObjects.QueryObject.Filter
                            {
                                LogicalOperator = LogicalOperator.OR,
                                Name = LamConstants.ProductLine,
                                Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                                Value = productLine
                            }
                        });
                    }
                    else
                    {
                        customGroupDependencies.LoadData(new Cmf.Foundation.BusinessObjects.QueryObject.FilterCollection()
                        {
                            new Cmf.Foundation.BusinessObjects.QueryObject.Filter
                            {
                                LogicalOperator = LogicalOperator.OR,
                                Name = LamConstants.ProcessGroup,
                                Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                                Value = processGroup
                            }
                        });
                    }

                    if (customGroupDependencies.HasData)
                    {
                        customGroupDependenciesDataSet = NgpDataSet.ToDataSet(customGroupDependencies.Data);
                        if (customGroupDependenciesDataSet.Tables != null && customGroupDependenciesDataSet.Tables.Count > 0 &&
                        customGroupDependenciesDataSet.Tables[0].Rows != null && customGroupDependenciesDataSet.Tables[0].Rows.Count > 0)
                        {
                            customResolveGTForProjectCodeOutput.BusinessUnit = new List<string>();
                            customResolveGTForProjectCodeOutput.CustomSubGroup = new List<string>();
                            customResolveGTForProjectCodeOutput.CustomProductLine = new List<string>();
                            customResolveGTForProjectCodeOutput.CustomApplication = new List<string>();
                            for (int i = 0; i < customGroupDependenciesDataSet.Tables[0].Rows.Count; i++)
                            {
                                if (customResolveGTForProjectCodeOutput.BusinessUnit != null &&
                                    !customResolveGTForProjectCodeOutput.BusinessUnit.Contains(customGroupDependenciesDataSet.Tables[0].Rows[i][LamConstants.BusinessUnit].ToString()))
                                {
                                    customResolveGTForProjectCodeOutput.BusinessUnit.Add(customGroupDependenciesDataSet.Tables[0].Rows[i][LamConstants.BusinessUnit].ToString());
                                }

                                if (customResolveGTForProjectCodeOutput.CustomSubGroup != null &&
                                    !customResolveGTForProjectCodeOutput.CustomSubGroup.Contains(customGroupDependenciesDataSet.Tables[0].Rows[i][LamConstants.PropertySubGroup].ToString()))
                                {
                                    customResolveGTForProjectCodeOutput.CustomSubGroup.Add(customGroupDependenciesDataSet.Tables[0].Rows[i][LamConstants.PropertySubGroup].ToString());
                                }

                                if (customResolveGTForProjectCodeOutput.CustomProductLine != null &&
                                    !customResolveGTForProjectCodeOutput.CustomProductLine.Contains(customGroupDependenciesDataSet.Tables[0].Rows[i][LamConstants.ProductLine].ToString()))
                                {
                                    customResolveGTForProjectCodeOutput.CustomProductLine.Add(customGroupDependenciesDataSet.Tables[0].Rows[i][LamConstants.ProductLine].ToString());
                                }

                                if (customResolveGTForProjectCodeOutput.CustomApplication != null &&
                                    !customResolveGTForProjectCodeOutput.CustomApplication.Contains(customGroupDependenciesDataSet.Tables[0].Rows[i][LamConstants.Application].ToString()))
                                {
                                    customResolveGTForProjectCodeOutput.CustomApplication.Add(customGroupDependenciesDataSet.Tables[0].Rows[i][LamConstants.Application].ToString());
                                }
                            }
                        }
                        customResolveGTForProjectCodeOutput.HasInformation = false;
                    }
                    else
                    {
                        customResolveGTForProjectCodeOutput.SelectedProcessGroup = processGroup;
                        customResolveGTForProjectCodeOutput.SelectedBusinessUnit = String.Empty;
                        customResolveGTForProjectCodeOutput.SelectedSubGroup = String.Empty;
                        customResolveGTForProjectCodeOutput.SelectedProductLine = String.Empty;
                        customResolveGTForProjectCodeOutput.SelectedApplication = String.Empty;
                        customResolveGTForProjectCodeOutput.BusinessUnit = new List<string>();
                        customResolveGTForProjectCodeOutput.CustomSubGroup = new List<string>();
                        customResolveGTForProjectCodeOutput.CustomProductLine = new List<string>();
                        customResolveGTForProjectCodeOutput.CustomApplication = new List<string>();
                        customResolveGTForProjectCodeInput.BusinessUnit = null;
                        customResolveGTForProjectCodeInput.CustomSubGroup = null;
                        customResolveGTForProjectCodeInput.CustomProductLine = null;
                        customResolveGTForProjectCodeInput.CustomApplication = null;
                        customResolveGTForProjectCodeOutput.HasInformation = true;
                    }
                }
            }
            catch (CmfBaseException)
            {
                throw;

            }
            catch (Exception e)
            {
                throw new CmfBaseException(e.Message, e);
            }
            finally
            {

                Utilities.EndMethod(-1, -1,
                    new KeyValuePair<string, object>("CustomResolveGTForProjectCodeInput", customResolveGTForProjectCodeInput),
                    new KeyValuePair<string, object>("CustomResolveGTForProjectCodeOutput", customResolveGTForProjectCodeOutput));
            }
            return customResolveGTForProjectCodeOutput;
        }

        public CustomGetLookUpValuesOutput CustomResolveLTsForProjectCode(CustomGetLookUpValuesInput customGetLookUpValuesInput)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomResolveLTsForProjectCode",
                    new KeyValuePair<string, object>("CustomGetLookUpValuesInput",
                        customGetLookUpValuesInput));

            CustomGetLookUpValuesOutput customGetLookUpValuesOutput = new CustomGetLookUpValuesOutput();
            try
            {
                customGetLookUpValuesOutput.ProcessGroupValues = new List<string>();
                customGetLookUpValuesOutput.BusinessUnitValues = new List<string>();
                customGetLookUpValuesOutput.SubGroupValues = new List<string>();
                customGetLookUpValuesOutput.ProductLineValues = new List<string>();
                customGetLookUpValuesOutput.ApplicationValues = new List<string>();

                if (!String.IsNullOrEmpty(customGetLookUpValuesInput.ProcessGroup))
                {
                    LookupTable customBusinessUnitLookupTable = new LookupTable { Name = customGetLookUpValuesInput.ProcessGroup };
                    customBusinessUnitLookupTable.Load();
                    for (int i = 0; i < customBusinessUnitLookupTable.Values.Count; i++)
                    {
                        customGetLookUpValuesOutput.ProcessGroupValues.Add(customBusinessUnitLookupTable.Values[i].Value);
                    }
                }

                if (!String.IsNullOrEmpty(customGetLookUpValuesInput.BusinessUnit))
                {
                    LookupTable customBusinessUnitLookupTable = new LookupTable { Name = customGetLookUpValuesInput.BusinessUnit };
                    customBusinessUnitLookupTable.Load();
                    for (int i = 0; i < customBusinessUnitLookupTable.Values.Count; i++)
                    {
                        customGetLookUpValuesOutput.BusinessUnitValues.Add(customBusinessUnitLookupTable.Values[i].Value);
                    }
                }

                if (!String.IsNullOrEmpty(customGetLookUpValuesInput.SubGroup))
                {
                    LookupTable customBusinessUnitLookupTable = new LookupTable { Name = customGetLookUpValuesInput.SubGroup };
                    customBusinessUnitLookupTable.Load();
                    for (int i = 0; i < customBusinessUnitLookupTable.Values.Count; i++)
                    {
                        customGetLookUpValuesOutput.SubGroupValues.Add(customBusinessUnitLookupTable.Values[i].Value);
                    }
                }

                if (!String.IsNullOrEmpty(customGetLookUpValuesInput.ProductLine))
                {
                    LookupTable customBusinessUnitLookupTable = new LookupTable { Name = customGetLookUpValuesInput.ProductLine };
                    customBusinessUnitLookupTable.Load();
                    for (int i = 0; i < customBusinessUnitLookupTable.Values.Count; i++)
                    {
                        customGetLookUpValuesOutput.ProductLineValues.Add(customBusinessUnitLookupTable.Values[i].Value);
                    }
                }

                if (!String.IsNullOrEmpty(customGetLookUpValuesInput.Application))
                {
                    LookupTable customBusinessUnitLookupTable = new LookupTable { Name = customGetLookUpValuesInput.Application };
                    customBusinessUnitLookupTable.Load();
                    for (int i = 0; i < customBusinessUnitLookupTable.Values.Count; i++)
                    {
                        customGetLookUpValuesOutput.ApplicationValues.Add(customBusinessUnitLookupTable.Values[i].Value);
                    }
                }
            }
            catch (CmfBaseException)
            {
                throw;

            }
            catch (Exception e)
            {
                throw new CmfBaseException(e.Message, e);
            }
            finally
            {

                Utilities.EndMethod(-1, -1,
                    new KeyValuePair<string, object>("CustomGetLookUpValuesInput", customGetLookUpValuesInput),
                    new KeyValuePair<string, object>("CustomGetLookUpValuesOutput", customGetLookUpValuesOutput));
            }
            return customGetLookUpValuesOutput;
        }

        public CustomCreateProjectCodeOutput CustomCreateProjectCode(CustomCreateProjectCodeInput customCreateProjectCodeInput)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomCreateProjectCode",
                    new KeyValuePair<string, object>("CustomCreateProjectCodeInput",
                        customCreateProjectCodeInput));

            CustomCreateProjectCodeOutput customCreateProjectCodeOutput = new CustomCreateProjectCodeOutput();
            try
            {
                BusinessPartner customer = customCreateProjectCodeInput.Customer;
                customer.Load();
                customer.LoadAttribute("CustomPartnerRegion");
                customer.LoadRelations();
                bool customerFacilityExists = customer.RelationCollection["CustomCustomerFacility"].Any(a => a.TargetEntity.Name.Equals(customCreateProjectCodeInput.Fab.Name));
                
                if (customer["CustomPartnerRegion"].ToString().Equals(customCreateProjectCodeInput.Region) && customerFacilityExists)
                {
                    #region Validate GT
                    GenericTable customGroupDependencies = new();
                    customGroupDependencies = new();
                    DataSet customGroupDependenciesDataSet = new();
                    customGroupDependencies.Load("CustomGroupDependencies");

                    customGroupDependencies.LoadData(new Cmf.Foundation.BusinessObjects.QueryObject.FilterCollection()
                        {
                            new Cmf.Foundation.BusinessObjects.QueryObject.Filter
                            {
                                LogicalOperator = LogicalOperator.AND,
                                Name = LamConstants.ProcessGroup,
                                Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                                Value = customCreateProjectCodeInput.ProcessGroup
                            },
                            new Cmf.Foundation.BusinessObjects.QueryObject.Filter
                            {
                                LogicalOperator = LogicalOperator.AND,
                                Name = LamConstants.BusinessUnit,
                                Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                                Value = customCreateProjectCodeInput.BusinessUnit
                            },
                            new Cmf.Foundation.BusinessObjects.QueryObject.Filter
                            {
                                LogicalOperator = LogicalOperator.AND,
                                Name = LamConstants.PropertySubGroup,
                                Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                                Value = customCreateProjectCodeInput.SubGroup
                            },
                            new Cmf.Foundation.BusinessObjects.QueryObject.Filter
                            {
                                LogicalOperator = LogicalOperator.AND,
                                Name = LamConstants.ProductLine,
                                Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                                Value = customCreateProjectCodeInput.ProductLine
                            },
                            new Cmf.Foundation.BusinessObjects.QueryObject.Filter
                            {
                                LogicalOperator = LogicalOperator.AND,
                                Name = LamConstants.Application,
                                Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                                Value = customCreateProjectCodeInput.Application
                            }
                        });

                    if (customGroupDependencies.HasData)
                    {
                        customGroupDependenciesDataSet = NgpDataSet.ToDataSet(customGroupDependencies.Data);
                        if (customGroupDependenciesDataSet.Tables != null && customGroupDependenciesDataSet.Tables.Count > 0 &&
                        customGroupDependenciesDataSet.Tables[0].Rows != null && customGroupDependenciesDataSet.Tables[0].Rows.Count > 0)
                        {
                            CustomProjectCode projectCode = new CustomProjectCode
                            {
                                Name = customCreateProjectCodeInput.Title,
                                Description = customCreateProjectCodeInput.Description,
                                Product = customCreateProjectCodeInput.Product,
                                ProjectProtocol = customCreateProjectCodeInput.ProjectProtocol,
                                Customer = customCreateProjectCodeInput.Customer,
                                SubGroup = customCreateProjectCodeInput.SubGroup,
                                BusinessUnit = customCreateProjectCodeInput.BusinessUnit,
                                ProcessGroup = customCreateProjectCodeInput.ProcessGroup,
                                Fab = customCreateProjectCodeInput.Fab,
                                ProductLine = customCreateProjectCodeInput.ProductLine,
                                Application = customCreateProjectCodeInput.Application,
                                Title = customCreateProjectCodeInput.Title,
                                Region = customCreateProjectCodeInput.Region
                            };

                            CreateObjectInput projectCodeToCreate = new CreateObjectInput();
                            projectCodeToCreate.Object = projectCode;
                            projectCodeToCreate.NameGeneratorName = "CustomProjectCodeNameGenerator";
                            Cmf.Foundation.BusinessOrchestration.GenericServiceManagement.GenericServiceManagementOrchestration.CreateObject(projectCodeToCreate);
                            projectCode.Load();

                            ProtocolInstance instanceCreated = new ProtocolInstance { Name = projectCode.Name };
                            instanceCreated.Load();

                            #region Set FeedbackMessage

                            customCreateProjectCodeOutput.FeedbackMessages = new Collection<FeedbackMessage>
                        {
                            new()
                            {
                                MessageType = FeedbackMessageType.Success,
                                Message = LamUtilities.GetLocalizedMessage("CustomProtocolInstanceCreatedSuccessfully")
                            },
                            new()
                            {
                                MessageType = FeedbackMessageType.ObjectsToOpen,
                                Objects = new BindingList<object>
                                {
                                    instanceCreated
                                }
                            }
                        };

                            #endregion
                        }
                        #endregion
                    }
                    else
                    {
                        throw new CmfBaseException("Not a valid combination of the GT CustomGroupDependencies was selected.");
                    }
                }
                else
                {
                    throw new CmfBaseException("Not a valid combination of Region/Customer/Facility was selected.");
                }
            }
            catch (CmfBaseException)
            {
                throw;

            }
            catch (Exception e)
            {
                throw new CmfBaseException(e.Message, e);
            }
            finally
            {

                Utilities.EndMethod(-1, -1,
                    new KeyValuePair<string, object>("CustomCreateProjectCodeInput", customCreateProjectCodeInput),
                    new KeyValuePair<string, object>("CustomCreateProjectCodeOutput", customCreateProjectCodeOutput));
            }
            return customCreateProjectCodeOutput;
        }

        public CustomProjectMetrologyEstimatesOutput CustomProjectMetrologyEstimates(CustomProjectMetrologyEstimatesInput customProjectMetrologyEstimatesInput)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomProjectMetrologyEstimates",
                    new KeyValuePair<string, object>("CustomProjectMetrologyEstimatesInput",
                        customProjectMetrologyEstimatesInput));

            CustomProjectMetrologyEstimatesOutput customProjectMetrologyEstimatesOutput = new();

            try
            {
                var allMetrologyEstimatesByProtocol = metrologyEstimatesQueries
                    .GetMetrologyEstimatesByProtocolInstance(customProjectMetrologyEstimatesInput.CustomProjectMetrologyEstimates.First().ProtocolInstance.Id);

                var actualEstimates = customProjectMetrologyEstimatesInput.CustomProjectMetrologyEstimates.Where(e => !string.IsNullOrWhiteSpace(e.Name));

                // Add Estimates
                var estimatesToAdd = entityFactory.CreateCollection<ICustomProjectMetrologyEstimatesCollection>();
                estimatesToAdd.AddRange(actualEstimates.ExceptBy(allMetrologyEstimatesByProtocol.Select(m => m.Name), obj => obj.Name));
                foreach (var estimate in estimatesToAdd)
                {
                    estimate.Name = string.Empty;
                    CreateObjectInput projectMetrologyEstimatesToCreate = new()
                    {
                        Object = estimate,
                        NameGeneratorName = "CustomProjectMetrologyEstimatesNameGenerator"
                    };

                    genericServiceOrchestration.CreateObject(projectMetrologyEstimatesToCreate);
                }

                // Update Estimates
                var estimatesToUpdate = entityFactory.CreateCollection<ICustomProjectMetrologyEstimatesCollection>();
                estimatesToUpdate.AddRange(allMetrologyEstimatesByProtocol.IntersectBy(actualEstimates.Select(m => m.Name), obj => obj.Name));
                estimatesToUpdate.ToList().ForEach(estimate =>
                {
                    var update = actualEstimates.FirstOrDefault(u => u.Name.Equals(estimate.Name));
                    estimate.Cost = update.Cost;
                    estimate.Quantity = update.Quantity;
                    estimate.IsApproved = false;
                });
                estimatesToUpdate.Save();

                // Delete Estimates
                var estimatesToDelete = entityFactory.CreateCollection<ICustomProjectMetrologyEstimatesCollection>();
                estimatesToDelete.AddRange(allMetrologyEstimatesByProtocol.ExceptBy(actualEstimates.Select(m => m.Name), obj => obj.Name));
                estimatesToDelete.Terminate();

                #region Set FeedbackMessage

                customProjectMetrologyEstimatesOutput.FeedbackMessages = new Collection<FeedbackMessage>
                {
                    new()
                    {
                        MessageType = FeedbackMessageType.Success,
                        Message = localizationService.Localize(Thread.CurrentThread.CurrentCulture.Name, "CustomProjectMetrologyEstimatesSavedSuccessfully")
                    }
                };

                #endregion
            }
            catch (CmfBaseException)
            {
                throw;
            }
            catch (Exception e)
            {
                throw new CmfBaseException(e.Message, e);
            }
            finally
            {
                Utilities.EndMethod(-1, -1,
                    new KeyValuePair<string, object>("CustomProjectMetrologyEstimatesInput", customProjectMetrologyEstimatesInput),
                    new KeyValuePair<string, object>("CustomProjectMetrologyEstimatesOutput", customProjectMetrologyEstimatesOutput));
            }

            return customProjectMetrologyEstimatesOutput;
        }

        public LamExecuteActionOutput ExecuteAction(LamExecuteActionInput input)
        {
            Utilities.ValidateNullInput(input);
            Utilities.StartMethod(OBJECT_TYPE_NAME, "ExecuteAction", new KeyValuePair<string, object>(nameof(LamExecuteActionInput), input));

            // Save the original input, because the service return will be anything the dee action returns, except the original inputs
            var originalInput = input.Params.ToDictionary(d => d.Key, d => d.Value);
            var output = new LamExecuteActionOutput();
            try
            {
                var deeActionToRun = new Foundation.Common.DynamicExecutionEngine.Action();
                deeActionToRun.Load(input.ActionName);

                var result = deeActionToRun.ExecuteAction(input.Params);
                result = result.Except(originalInput).ToDictionary(d => d.Key, d => d.Value);
                output.Result = result.Values.ToList();
                output.TotalRows = result.Values.ToList().Count;
            }
            finally
            {
                Utilities.EndMethod(-1, -1,
                    new KeyValuePair<string, object>(nameof(LamExecuteActionInput), input),
                    new KeyValuePair<string, object>(nameof(Dictionary<string, object>), output));
            }
            return output;
        }

        public CustomGetProtocolInstancesOutput CustomGetProtocolInstances(CustomGetProtocolInstancesInput customGetProtocolInstancesInput)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomGetProtocolInstances",
                    new KeyValuePair<string, object>("CustomGetProtocolInstancesInput",
                        customGetProtocolInstancesInput));

            CustomGetProtocolInstancesOutput customGetProtocolInstancesOutput = new CustomGetProtocolInstancesOutput();
            try
            {
                Dictionary<string, object> Input = new Dictionary<string, object>();
                if (customGetProtocolInstancesInput != null)
                {
                    Input.Add("ProjectId", String.IsNullOrEmpty(customGetProtocolInstancesInput.ProjectCode) ? null : customGetProtocolInstancesInput.ProjectCode);
                    Input.Add("Type", String.IsNullOrEmpty(customGetProtocolInstancesInput.ProjectType) ? null : customGetProtocolInstancesInput.ProjectType);
                    Input.Add("StateModel", "ProjectProtocol-A-1");
                    Input.Add("ModelState", customGetProtocolInstancesInput.State == null ? null : customGetProtocolInstancesInput.State.Name);
                    Input.Add("ProjectOwner", customGetProtocolInstancesInput.ProjectOwner == null ? null : customGetProtocolInstancesInput.ProjectOwner.Name);
                    Input.Add("Customer", customGetProtocolInstancesInput.Customer == null ? null : customGetProtocolInstancesInput.Customer.Name);
                    Input.Add("CreationDateFrom", customGetProtocolInstancesInput.CreationDateFrom.ToString() == "1/1/0001 12:00:00 AM" ? DateTime.UnixEpoch : customGetProtocolInstancesInput.CreationDateFrom);
                    Input.Add("CreationDateUntil", customGetProtocolInstancesInput.CreationDateUntil.ToString() == "1/1/0001 12:00:00 AM" ? DateTime.MaxValue : customGetProtocolInstancesInput.CreationDateUntil);
                    Input.Add("PageNumber", customGetProtocolInstancesInput.PageNumber.ToString());
                    Input.Add("PageSize", customGetProtocolInstancesInput.PageSize.ToString());
                    Input.Add("SortingColumn", String.IsNullOrEmpty(customGetProtocolInstancesInput.SortBy) ? null : customGetProtocolInstancesInput.SortBy.Replace(" ", ""));
                    Input.Add("Ascending", customGetProtocolInstancesInput.Ascending.ToString());
                }

                DataSet Output = new DataSet();

                if (customGetProtocolInstancesInput.MyProjects)
                {
                    Input.Remove("PageNumber");
                    Input.Remove("PageSize");
                }

                Output = DatabaseUtilities.GetDee(Input);
                customGetProtocolInstancesOutput.ProtocolInstanceParameters = new ProtocolInstanceCollection();
                if (Output.Tables != null && Output.Tables.Count > 0 &&
                        Output.Tables[0].Rows != null && Output.Tables[0].Rows.Count > 0)
                {
                    ProtocolInstanceCollection instances = new ProtocolInstanceCollection();
                    foreach (DataRow dr in Output.Tables[0].Rows)
                    {
                        ProtocolInstance protocol = new ProtocolInstance { Name = dr[0].ToString() };
                        protocol.Load();
                        protocol.CurrentPath.LoadParameters();
                        protocol.LoadRelations();
                        protocol.ParentEntity.Load();
                        protocol.ParentEntity.LoadParameters();

                        if (customGetProtocolInstancesInput.MyProjects)
                        {
                            protocol.CurrentMainState.StateModel.Load();
                            IServiceProvider serviceProvider = ApplicationContext.CurrentServiceProvider;
                            ISecurityOrchestration securityOrchestration = serviceProvider.GetService<ISecurityOrchestration>();
                            IEntityFactory entityFactory = serviceProvider.GetService<IEntityFactory>();
                            IFilterCollection filters = serviceProvider.GetService<IFilterCollection>();
                            IFilter filterState = serviceProvider.GetService<IFilter>();
                            filterState.Name = LamConstants.SmartTables.CustomProtocolSpecificNotifications.ToState;
                            filterState.Operator = FieldOperator.IsEqualTo;
                            filterState.Value = protocol.CurrentMainState.CurrentState.Name;
                            filters.Add(filterState);

                            IFilter filterProtocol = serviceProvider.GetService<IFilter>();
                            filterProtocol.Name = LamConstants.SmartTables.CustomProtocolSpecificNotifications.Protocol;
                            filterProtocol.Operator = FieldOperator.IsEqualTo;
                            filterProtocol.Value = protocol.ParentEntity.Name;
                            filters.Add(filterProtocol);

                            ISmartTable smartTable = serviceProvider.GetService<ISmartTable>();
                            DataSet smartTableData = SmartTables.getData(
                                                        smartTable,
                                                        LamConstants.SmartTables.CustomProtocolSpecificNotifications.TableName,
                                                        filters
                                                     );
                            if (smartTableData.HasData())
                            {
                                string user = securityOrchestration.GetCurrentUser(new GetCurrentUserInput()).User.Name;
                                IEmployee emp = LaborManagementOrchestration.GetEmployeeByUserAccount(
                                    new GetEmployeeByUserAccountInput
                                    {
                                        UserAccount = user
                                    }).Employee;

                                DataRowCollection dataRowCollection = smartTableData.Tables[0].Rows;
                                foreach (DataRow row in dataRowCollection)
                                {
                                    bool isMainRecipient = (bool)row[LamConstants.SmartTables.CustomProtocolSpecificNotifications.IsMainRecipient];
                                    if (isMainRecipient && !customGetProtocolInstancesOutput.ProtocolInstanceParameters.Contains(protocol))
                                    {
                                        string sourceName = row[LamConstants.SmartTables.CustomProtocolSpecificNotifications.SourceName] == null ? String.Empty : row[LamConstants.SmartTables.CustomProtocolSpecificNotifications.SourceName].ToString();
                                        if (!string.IsNullOrEmpty(sourceName))
                                        {
                                            if (protocol.CurrentPath.Parameters.Where(a => a.ParameterName.Equals(sourceName) && a.ParameterValue != null && a.ParameterValue.Equals(emp.Name)).Any())
                                            {
                                                customGetProtocolInstancesOutput.ProtocolInstanceParameters.Add(protocol);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        else
                        {
                            customGetProtocolInstancesOutput.ProtocolInstanceParameters.Add(protocol);
                        }
                    }
                }

                if ((customGetProtocolInstancesOutput.ProtocolInstanceParameters.Count < customGetProtocolInstancesInput.PageSize && customGetProtocolInstancesInput.PageNumber <= 1))
                {
                    customGetProtocolInstancesOutput.TotalRows = customGetProtocolInstancesOutput.ProtocolInstanceParameters.Count;
                    customGetProtocolInstancesOutput.PageNumer = (customGetProtocolInstancesInput.PageNumber + 1);
                    customGetProtocolInstancesOutput.PageSize = customGetProtocolInstancesInput.PageSize;
                }
                else
                {
                    if (customGetProtocolInstancesInput.PageSize > 0)
                    {
                        Input.Remove("PageNumber");
                        Input.Remove("PageSize");
                        Input.Remove("Result");
                        DataSet totalRecords = DatabaseUtilities.GetDee(Input);
                        decimal totalResults = Decimal.Divide(totalRecords.Tables[0].Rows.Count, customGetProtocolInstancesInput.PageSize);
                        if (totalRecords.Tables[0].Rows.Count > customGetProtocolInstancesInput.PageSize && customGetProtocolInstancesInput.PageNumber <= Math.Ceiling(totalResults) && customGetProtocolInstancesInput.PageNumber >= 0)
                        {
                            customGetProtocolInstancesOutput.TotalRows = totalRecords.Tables[0].Rows.Count;
                            customGetProtocolInstancesOutput.PageNumer = (customGetProtocolInstancesInput.PageNumber + 1);
                            customGetProtocolInstancesOutput.PageSize = customGetProtocolInstancesInput.PageSize;
                        }
                        else
                        {
                            totalRecords = DatabaseUtilities.GetDee();
                            customGetProtocolInstancesOutput.TotalRows = totalRecords.Tables[0].Rows.Count;
                            customGetProtocolInstancesOutput.PageNumer = (customGetProtocolInstancesInput.PageNumber + 1);
                            customGetProtocolInstancesOutput.PageSize = customGetProtocolInstancesInput.PageSize;
                        }
                    }
                }
            }
            catch (CmfBaseException)
            {
                throw;

            }
            catch (Exception e)
            {
                throw new CmfBaseException(e.Message, e);
            }
            finally
            {

                Utilities.EndMethod(-1, -1,
                    new KeyValuePair<string, object>("CustomGetProtocolInstancesInput", customGetProtocolInstancesInput),
                    new KeyValuePair<string, object>("CustomGetProtocolInstancesOutput", customGetProtocolInstancesOutput));
            }
            return customGetProtocolInstancesOutput;
        }
    }
}
