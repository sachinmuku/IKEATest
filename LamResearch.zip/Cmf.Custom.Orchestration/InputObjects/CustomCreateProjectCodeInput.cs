﻿using Cmf.Custom.Lam.Common.DataStructures;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessOrchestration;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.Lam.Orchestration.InputObjects
{
    [DataContract(Name = "CustomCreateProjectCodeInput")]
    public class CustomCreateProjectCodeInput : BaseInput
    {
        [DataMember(Name = "Title", Order = 1)]
        public string Title { get; set; }

        [DataMember(Name = "Description", Order = 2)]
        public string Description { get; set; }

        [DataMember(Name = "Product", Order = 3)]
        public Product Product { get; set; }

        [DataMember(Name = "ProjectProtocol", Order = 3)]
        public Protocol ProjectProtocol { get; set; }

        [DataMember(Name = "Region", Order = 3)]
        public string Region { get; set; }

        [DataMember(Name = "Customer", Order = 3)]
        public BusinessPartner Customer { get; set; }

        [DataMember(Name = "Fab", Order = 3)]
        public Facility Fab { get; set; }

        [DataMember(Name = "ProcessGroup", Order = 3)]
        public string ProcessGroup { get; set; }

        [DataMember(Name = "BusinessUnit", Order = 3)]
        public string BusinessUnit { get; set; }

        [DataMember(Name = "SubGroup", Order = 3)]
        public string SubGroup { get; set; }

        [DataMember(Name = "ProductLine", Order = 3)]
        public string ProductLine { get; set; }

        [DataMember(Name = "Application", Order = 3)]
        public string Application { get; set; }
    }
}
