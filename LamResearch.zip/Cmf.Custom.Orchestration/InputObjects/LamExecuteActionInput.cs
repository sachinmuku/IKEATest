﻿using Cmf.Foundation.BusinessOrchestration;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Cmf.Custom.Lam.Orchestration.InputObjects
{
    [DataContract(Name = "LamExecuteActionInput")]
    public class LamExecuteActionInput : BaseInput
    {
        [DataMember(Name = "ActionName", Order = 1)]
        public string ActionName { get; set; }

        [DataMember(Name = "Params", Order = 2)]
        public Dictionary<string, object> Params { get; set; }
    }
}
