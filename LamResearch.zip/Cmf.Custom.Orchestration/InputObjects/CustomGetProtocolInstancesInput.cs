﻿using Cmf.Custom.Lam.Common.DataStructures;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessOrchestration;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.Lam.Orchestration.InputObjects
{
    [DataContract(Name = "CustomGetProtocolInstancesInput")]
    public class CustomGetProtocolInstancesInput : BaseInput
    {
        [DataMember(Name = "ProjectCode", Order = 1)]
        public string ProjectCode { get; set; }

        [DataMember(Name = "ProjectType", Order = 2)]
        public string ProjectType { get; set; }

        [DataMember(Name = "State", Order = 3)]
        public ProtocolStateDetail State { get; set; }

        [DataMember(Name = "CreationDateFrom", Order = 4)]
        public DateTime CreationDateFrom { get; set; }

        [DataMember(Name = "CreationDateUntil", Order = 5)]
        public DateTime CreationDateUntil { get; set; }

        [DataMember(Name = "ProjectOwner", Order = 6)]
        public Employee ProjectOwner { get; set; }

        [DataMember(Name = "Customer", Order = 7)]
        public BusinessPartner Customer { get; set; }

        [DataMember(Name = "SortBy", Order = 8)]
        public string SortBy { get; set; }

        [DataMember(Name = "Ascending", Order = 9)]
        public bool Ascending { get; set; }

        [DataMember(Name = "MyProjects", Order = 10)]
        public bool MyProjects { get; set; }
    }
}
