﻿using Cmf.Custom.Lam.Common.DataStructures;
using Cmf.Foundation.BusinessOrchestration;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.Lam.Orchestration.InputObjects
{
    [DataContract(Name = "AssembleMaterialWithCustomQtyIntput")]
    public class AssembleMaterialWithCustomQtyIntput : BaseInput
    {
        [DataMember(Name = "Material",Order = 1)]
        public Material Material { get; set; }

        [DataMember(Name = "AssembleQuantity", Order = 2)]
        public decimal AssembleQuantity { get; set; }

        [DataMember(Name = "QuantityMode", Order = 3)]
        public CustomBomQuantityMode QuantityMode { get; set; }

        [DataMember(Name = "SourceMaterials", Order = 4)]
        public AssembleMaterialCollection SourceMaterials { get; set; }
    }
}
