﻿using Cmf.Custom.Lam.Common.DataStructures;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessOrchestration;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.Lam.Orchestration.InputObjects
{
    [DataContract(Name = "CustomGetLookUpValuesInput")]
    public class CustomGetLookUpValuesInput : BaseInput
    {
        [DataMember(Name = "ProcessGroup", Order = 1)]
        public string ProcessGroup { get; set; }

        [DataMember(Name = "BusinessUnit", Order = 2)]
        public string BusinessUnit { get; set; }

        [DataMember(Name = "SubGroup", Order = 3)]
        public string SubGroup { get; set; }

        [DataMember(Name = "ProductLine", Order = 4)]
        public string ProductLine { get; set; }
        
        [DataMember(Name = "Application", Order = 5)]
        public string Application { get; set; }
    }
}
