﻿using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Cmf.Custom.Lam.Orchestration.InputObjects
{
    [DataContract(Name = "CustomGetProjectsForUserInput")]
    public class CustomGetProjectsForUserInput : LamExecuteActionInput
    {
        [DataMember(Name = "UserId", Order = 1)]
        public string UserId {  get; set; }
        [DataMember(Name = "Status", Order = 2)]
        public string Status { get; set; }
        [DataMember(Name = "UniversalState", Order = 3)]
        public string UniversalState { get; set; }

        public CustomGetProjectsForUserInput() {
            new LamExecuteActionInput()
            {
                ActionName = "CustomGetProjectsForUser",
                Params = new Dictionary<string, object>()
                {
                    { "UserId", UserId },
                    { "Status", Status},
                    { "UniversalState", UniversalState}
                }
            };
        }
    }
}
