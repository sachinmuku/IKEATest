﻿using System.Runtime.Serialization;
using Cmf.Custom.Lam.BusinessObjects;
using Cmf.Foundation.BusinessOrchestration;

namespace Cmf.Custom.Lam.Orchestration.InputObjects
{
    [DataContract(Name = "CustomProjectMetrologyEstimatesInput")]
    public class CustomProjectMetrologyEstimatesInput : BaseInput
    {
        [DataMember(Name = "CustomProjectMetrologyEstimates", Order = 1)]
        public CustomProjectMetrologyEstimatesCollection CustomProjectMetrologyEstimates { get; set; }
    }
}
