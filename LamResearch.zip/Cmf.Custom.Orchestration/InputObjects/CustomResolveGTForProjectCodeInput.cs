﻿using Cmf.Custom.Lam.Common.DataStructures;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessOrchestration;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.Lam.Orchestration.InputObjects
{
    [DataContract(Name = "CustomResolveGTForProjectCodeInput")]
    public class CustomResolveGTForProjectCodeInput : BaseInput
    {
        [DataMember(Name = "ProcessGroup", Order = 1)]
        public object ProcessGroup { get; set; }

        [DataMember(Name = "BusinessUnit", Order = 2)]
        public object BusinessUnit { get; set; }

        [DataMember(Name = "CustomSubGroup", Order = 3)]
        public object CustomSubGroup { get; set; }

        [DataMember(Name = "CustomProductLine", Order = 3)]
        public object CustomProductLine { get; set; }

        [DataMember(Name = "CustomApplication", Order = 4)]
        public object CustomApplication { get; set; }
    }
}
