using Cmf.Custom.Lam.Orchestration.InputObjects;
using Cmf.Custom.Lam.Orchestration.OutputObjects;

namespace Cmf.Custom.Lam;

public interface ILamOrchestration
{
    /// <summary>
    /// Assemble Material with sepcified Fixed or PerUnit quantity type
    /// </summary>
    /// <param name="assembleMaterialsInput"></param>
    /// <returns></returns>
    public AssembleMaterialWithCustomQtyOutput AssembleMaterialWithCustomQty(AssembleMaterialWithCustomQtyIntput assembleMaterialsInput);

    /// <summary>
    /// Resolve GT for Project Code
    /// </summary>
    /// <param name="customResolveGTForProjectCodeInput"></param>
    /// <returns></returns>
    public CustomResolveGTForProjectCodeOutput CustomResolveGTForProjectCode(CustomResolveGTForProjectCodeInput customResolveGTForProjectCodeInput);

    /// <summary>
    /// Resolve LTs for Project Code GUI
    /// </summary>
    /// <param name="customGetLookUpValuesInput"></param>
    /// <returns></returns>
    public CustomGetLookUpValuesOutput CustomResolveLTsForProjectCode(CustomGetLookUpValuesInput customGetLookUpValuesInput);

    /// <summary>
    /// Create ProjectCode from GUI
    /// </summary>
    /// <param name="customCreateProjectCodeInput"></param>
    /// <returns></returns>
    public CustomCreateProjectCodeOutput CustomCreateProjectCode(CustomCreateProjectCodeInput customCreateProjectCodeInput);

    /// <summary>
    /// Metrology Estimates from GUI
    /// </summary>
    /// <param name="customProjectMetrologyEstimatesInput"></param>
    /// <returns></returns>
    CustomProjectMetrologyEstimatesOutput CustomProjectMetrologyEstimates(CustomProjectMetrologyEstimatesInput customProjectMetrologyEstimatesInput);

    /// <summary>
    /// Executes a DEE action with better and cleaner responses than the out of the box method
    /// </summary>    
    public LamExecuteActionOutput ExecuteAction(LamExecuteActionInput input);

    /// <summary>
    /// Get Protocol Instances for GUI
    /// </summary>
    /// <param name="customGetProtocolInstancesInput"></param>
    /// <returns></returns>
    public CustomGetProtocolInstancesOutput CustomGetProtocolInstances(CustomGetProtocolInstancesInput customGetProtocolInstancesInput);
}