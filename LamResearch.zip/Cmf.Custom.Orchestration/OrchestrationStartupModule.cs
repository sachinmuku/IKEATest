using Cmf.Common.CustomActionUtilities;
using Cmf.Common.CustomActionUtilities.Abstractions;
using Cmf.Custom.Lam.BusinessObjects;
using Cmf.Custom.Lam.BusinessObjects.Abstractions;
using Cmf.Custom.Lam.Common.DataRepositories;
using Cmf.Custom.Lam.Common.ExternalAccess;
using Cmf.Custom.Lam.Common.Interfaces;
using Cmf.Custom.Lam.Common.Queries;
using Cmf.Custom.Lam.Common.Services;
using Cmf.Custom.Lam.Common.Utilities;
using Cmf.Custom.Lam.Common.UtilityAbstractions;
using Cmf.Foundation.Services.HostStartup;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;

namespace Cmf.Custom.Lam.Orchestration;

public class OrchestrationStartupModule : IStartupModule
{
    public MiddlewarePositioning MiddlewarePositioning => MiddlewarePositioning.None;

    public int ServiceRegistrationOrder => 0;

    public void Configure(IApplicationBuilder app, ConfigureMiddlewareContext context)
    {
    }

    public void ConfigureRootServices(IServiceCollection services)
    {
    }

    public void ConfigureServices(IServiceCollection services, ConfigureServicesContext context)
    {
        services.AddTransient<ILamOrchestration, LamOrchestration>();
        services.AddTransient<IDeeContextUtilities, DeeContextUtilities>();
        services.AddSingleton<IExternalConnection, ExternalConnection>();
        services.AddTransient<ICustomProjectDefaultAccessRoles, CustomProjectDefaultAccessRolesService>();
        services.AddTransient<ICustomProjectDefaultAccessRolesAssignment, CustomProjectDefaultAccessRolesService>();
        services.AddTransient<ICustomProjectCodeProtocolInstance, CustomProjectCodeProtocolInstance>();
        services.AddTransient<IEnforceTagVueStationMappingRepository, EnforceTagVueStationMappingRepository>();
        services.AddScoped<IEmployeeUtilities, EmployeeUtilities>();
        services.AddScoped<INotificationUtilities, NotificationUtilities>();
        services.AddScoped<IProtocolInstanceUtilities, ProtocolInstanceUtilities>();
        services.AddScoped<IProtocolUtilities, ProtocolUtilities>();
        services.AddTransient<IDeeContextUtilities, DeeContextUtilities>();
        services.AddTransient<IProjectMaxDurationRepository, ProjectMaxDurationRepository>();
        services.AddTransient<IProtocolSpecificNotifRepository, ProtocolSpecificNotifRepository>();
        services.AddTransient<IMetrologyEstimatesQueries, MetrologyEstimatesQueries>();
    }
}
