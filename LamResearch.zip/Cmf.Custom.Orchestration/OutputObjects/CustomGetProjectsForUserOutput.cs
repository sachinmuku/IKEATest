﻿using Cmf.Foundation.BusinessOrchestration;
using Cmf.Foundation.Common.Base;
using Cmf.Foundation.Common.LocalizationService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
namespace Cmf.Custom.Lam.Orchestration.OutputObjects
{
    [DataContract(Name = "CustomGetProjectsForUserOutput")]
    public class CustomGetProjectsForUserOutput
    {
        //[DataMember(Name = "ProtocolInstanceDetails", Order = 1)]
        //public Dictionary<string, Dictionary<string, string>> ProtocolInstanceDetails{ get; set; }
        [DataMember(Name = "ProjectCode", Order = 1)]
        public string ProjectCode { get; set; }

        [DataMember(Name = "Description", Order = 2)]
        public string Description { get; set; }

        [DataMember(Name = "Status", Order = 3)]
        public string Status { get; set; }

        [DataMember(Name = "Priority", Order = 4)]
        public string Priority { get; set; }

        [DataMember(Name = "ClosureDate", Order = 5)]
        public string ClosureDate { get; set; }

        [DataMember(Name = "Group", Order = 6)]
        public string ProductGroup { get; set; }

        [DataMember(Name = "Application", Order = 7)]
        public string Application { get; set; }

        [DataMember(Name = "ProductLine", Order = 8)]
        public string ProductLine { get; set; }

        [DataMember(Name = "IONumber", Order = 9)]
        public string IO { get; set; }

        [DataMember(Name = "SubGroup", Order = 10)]
        public string SubGroup{ get; set; }

        [DataMember(Name = "Type", Order = 11)]
        public string Type { get; set; }

        [DataMember(Name = "BusinessUnit", Order = 12)]
        public string BusinessUnit { get; set; }
        
        [DataMember(Name = "Customer", Order = 13)]
        public string Customer { get; set; }

        [DataMember(Name = "ProjectTitle", Order = 14)]
        public string ProjectTitle { get; set; }

        [DataMember(Name = "UniversalState", Order = 15)]
        public string UniversalState { get; set; }

    }
}