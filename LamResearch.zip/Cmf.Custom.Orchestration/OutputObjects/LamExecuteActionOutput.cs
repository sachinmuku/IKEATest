﻿using Cmf.Foundation.BusinessOrchestration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.Lam.Orchestration.OutputObjects
{
    [DataContract(Name = "LamExecuteActionOutput")]
    public class LamExecuteActionOutput : BaseOutput
    {   
        [DataMember(Name = "Result", Order = 1)]
        public object Result { get; set; }
    }
}
