﻿using Cmf.Custom.Lam.Common.DataStructures;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessOrchestration;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.Lam.Orchestration.InputObjects
{
    [DataContract(Name = "CustomGetLookUpValuesOutput")]
    public class CustomGetLookUpValuesOutput : BaseOutput
    {
        [DataMember(Name = "ProcessGroupValues", Order = 1)]
        public List<string> ProcessGroupValues { get; set; }

        [DataMember(Name = "BusinessUnitValues", Order = 2)]
        public List<string> BusinessUnitValues { get; set; }

        [DataMember(Name = "SubGroupValues", Order = 3)]
        public List<string> SubGroupValues { get; set; }

        [DataMember(Name = "ProductLineValues", Order = 4)]
        public List<string> ProductLineValues { get; set; }

        [DataMember(Name = "ApplicationValues", Order = 5)]
        public List<string> ApplicationValues { get; set; }
    }
}
