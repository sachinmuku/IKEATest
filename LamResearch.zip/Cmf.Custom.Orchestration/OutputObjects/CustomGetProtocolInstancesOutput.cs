﻿using Cmf.Custom.Lam.BusinessObjects;
using Cmf.Custom.Lam.Common.DataStructures;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessOrchestration;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.Lam.Orchestration.InputObjects
{
    [DataContract(Name = "CustomGetProtocolInstancesOutput")]
    public class CustomGetProtocolInstancesOutput : BaseOutput
    {
        [DataMember(Name = "ProtocolInstanceParameters", Order = 1)]
        public ProtocolInstanceCollection ProtocolInstanceParameters { get; set; }

        [DataMember(Name = "PageSize", Order = 1)]
        public int PageSize { get; set; }

        [DataMember(Name = "PageNumer", Order = 2)]
        public int PageNumer { get; set; }
    }
}
