﻿using System.Runtime.Serialization;
using Cmf.Custom.Lam.BusinessObjects;
using Cmf.Foundation.BusinessOrchestration;

namespace Cmf.Custom.Lam.Orchestration.OutputObjects
{
    [DataContract(Name = "CustomProjectMetrologyEstimatesOutput")]
    public class CustomProjectMetrologyEstimatesOutput : BaseOutput
    {
        [DataMember(Name = "CustomProjectMetrologyEstimates", Order = 1)]
        public CustomProjectMetrologyEstimatesCollection CustomProjectMetrologyEstimates { get; set; }
    }
}
