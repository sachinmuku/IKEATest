﻿using Cmf.Custom.Lam.Common.DataStructures;
using Cmf.Foundation.BusinessOrchestration;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.Lam.Orchestration.InputObjects
{
    [DataContract(Name = "AssembleMaterialWithCustomQtyOutput")]
    public class AssembleMaterialWithCustomQtyOutput : BaseOutput
    {
        [DataMember(Name = "Material",Order = 0)]
        public Material Material { get; set; }

        [DataMember(Name = "AssembleQuantity", Order = 1)]
        public decimal AssembleQuantity { get; set; }

        [DataMember(Name = "QuantityMode", Order = 2)]
        public CustomBomQuantityMode QuantityMode { get; set; }
        
        [DataMember(Name = "SourceMaterials", Order = 4)]
        public AssembleMaterialCollection SourceMaterials { get; set; }
    }
}
