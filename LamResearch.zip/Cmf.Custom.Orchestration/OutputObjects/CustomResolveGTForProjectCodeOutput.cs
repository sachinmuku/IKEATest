﻿using Cmf.Custom.Lam.Common.DataStructures;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessOrchestration;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.OutputObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.Lam.Orchestration.InputObjects
{
    [DataContract(Name = "CustomResolveGTForProjectCodeOutput")]
    public class CustomResolveGTForProjectCodeOutput : BaseOutput
    {
        [DataMember(Name = "BusinessUnit", Order = 1)]
        public List<string> BusinessUnit { get; set; }

        [DataMember(Name = "CustomSubGroup", Order = 2)]
        public List<string> CustomSubGroup { get; set; }

        [DataMember(Name = "CustomProductLine", Order = 3)]
        public List<string> CustomProductLine { get; set; }

        [DataMember(Name = "CustomApplication", Order = 4)]
        public List<string> CustomApplication { get; set; }

        [DataMember(Name = "SelectedProcessGroup", Order = 5)]
        public string SelectedProcessGroup { get; set; }

        [DataMember(Name = "SelectedBusinessUnit", Order = 6)]
        public string SelectedBusinessUnit { get; set; }

        [DataMember(Name = "SelectedSubGroup", Order = 7)]
        public string SelectedSubGroup { get; set; }

        [DataMember(Name = "SelectedProductLine", Order = 8)]
        public string SelectedProductLine { get; set; }

        [DataMember(Name = "SelectedApplication", Order = 9)]
        public string SelectedApplication { get; set; }

        [DataMember(Name = "HasInformation", Order = 10)]
        public bool HasInformation { get; set; }
    }
}
