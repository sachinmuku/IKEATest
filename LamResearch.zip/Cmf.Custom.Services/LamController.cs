﻿using System.Collections.Generic;
using Cmf.Custom.Lam.Orchestration.InputObjects;
using Cmf.Custom.Lam.Orchestration.OutputObjects;
using Cmf.Foundation.Common;
using Microsoft.AspNetCore.Mvc;

namespace Cmf.Custom.Lam.Services
{
    /// <summary>
    /// Lam Services
    /// </summary>
    [ApiController]
    [Route("api/[controller]/[action]")]
    public class LamController : ControllerBase
    {
        private const string OBJECT_TYPE_NAME = "Cmf.Custom.Lam.Services.LamManagement";
        private readonly ILamOrchestration _lamOrchestration;

        [Microsoft.Extensions.DependencyInjection.ActivatorUtilitiesConstructor]
        public LamController(ILamOrchestration lamOrchestration) : base()
        {
            _lamOrchestration = lamOrchestration;
        }

        [HttpPost]
        public AssembleMaterialWithCustomQtyOutput AssembleMaterialWithCustomQty(AssembleMaterialWithCustomQtyIntput assembleMaterialsInput)
        {
            Utilities.ValidateNullInput(assembleMaterialsInput);
            Utilities.StartMethod(OBJECT_TYPE_NAME, "AssembleMaterialWithCustomQty",
                    new KeyValuePair<string, object>(nameof(AssembleMaterialWithCustomQtyIntput),
                        assembleMaterialsInput));
            AssembleMaterialWithCustomQtyOutput assembleMaterialOutput = null;
            try
            {
                assembleMaterialOutput = _lamOrchestration.AssembleMaterialWithCustomQty(assembleMaterialsInput);
                return assembleMaterialOutput;
            }
            catch (System.Exception e)
            {
                throw new CmfBaseException(e.Message, e);
            }
            finally
            {
                assembleMaterialOutput ??= new AssembleMaterialWithCustomQtyOutput();
                Utilities.EndMethod(-1, -1,
                        new KeyValuePair<string, object>("AssembleMaterialWithCustomQty", assembleMaterialsInput),
                        new KeyValuePair<string, object>("AssembleMaterialWithCustomQty", assembleMaterialOutput));
            }
        }

        [HttpPost]
        public CustomResolveGTForProjectCodeOutput CustomResolveGTForProjectCode(CustomResolveGTForProjectCodeInput customResolveGTForProjectCodeInput)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomResolveGTForProjectCode",
                    new KeyValuePair<string, object>("CustomResolveGTForProjectCodeInput",
                        customResolveGTForProjectCodeInput));
            CustomResolveGTForProjectCodeOutput customResolveGTForProjectCodeOutput = null;
            try
            {
                customResolveGTForProjectCodeOutput = _lamOrchestration.CustomResolveGTForProjectCode(customResolveGTForProjectCodeInput);
                return customResolveGTForProjectCodeOutput;
            }
            catch (System.Exception e)
            {
                throw new CmfBaseException(e.Message, e);
            }
            finally
            {
                customResolveGTForProjectCodeOutput ??= new CustomResolveGTForProjectCodeOutput();
                Utilities.EndMethod(-1, -1,
                        new KeyValuePair<string, object>("CustomResolveGTForProjectCodeInput", customResolveGTForProjectCodeInput),
                        new KeyValuePair<string, object>("CustomResolveGTForProjectCodeOutput", customResolveGTForProjectCodeOutput));
            }
        }

        [HttpPost]
        public CustomGetLookUpValuesOutput CustomResolveLTsForProjectCode(CustomGetLookUpValuesInput customGetLookUpValuesInput)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomResolveLTsForProjectCode",
                    new KeyValuePair<string, object>("CustomGetLookUpValuesInput",
                        customGetLookUpValuesInput));
            CustomGetLookUpValuesOutput customGetLookUpValuesOutput = null;
            try
            {
                customGetLookUpValuesOutput = _lamOrchestration.CustomResolveLTsForProjectCode(customGetLookUpValuesInput);
                return customGetLookUpValuesOutput;
            }
            catch (System.Exception e)
            {
                throw new CmfBaseException(e.Message, e);
            }
            finally
            {
                customGetLookUpValuesOutput ??= new CustomGetLookUpValuesOutput();
                Utilities.EndMethod(-1, -1,
                        new KeyValuePair<string, object>("CustomGetLookUpValuesInput", customGetLookUpValuesInput),
                        new KeyValuePair<string, object>("CustomGetLookUpValuesOutput", customGetLookUpValuesOutput));
            }
        }

        [HttpPost]
        public CustomCreateProjectCodeOutput CustomCreateProjectCode(CustomCreateProjectCodeInput customCreateProjectCodeInput)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomCreateProjectCode",
                    new KeyValuePair<string, object>("CustomCreateProjectCodeInput",
                        customCreateProjectCodeInput));
            CustomCreateProjectCodeOutput customCreateProjectCodeOutput = null;
            try
            {
                customCreateProjectCodeOutput = _lamOrchestration.CustomCreateProjectCode(customCreateProjectCodeInput);
                return customCreateProjectCodeOutput;
            }
            catch (System.Exception e)
            {
                throw new CmfBaseException(e.Message, e);
            }
            finally
            {
                customCreateProjectCodeOutput ??= new CustomCreateProjectCodeOutput();
                Utilities.EndMethod(-1, -1,
                        new KeyValuePair<string, object>("CustomCreateProjectCodeInput", customCreateProjectCodeInput),
                        new KeyValuePair<string, object>("CustomCreateProjectCodeOutput", customCreateProjectCodeOutput));
            }
        }

        [HttpPost]
        public CustomProjectMetrologyEstimatesOutput CustomProjectMetrologyEstimates(CustomProjectMetrologyEstimatesInput customProjectMetrologyEstimatesInput)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomProjectMetrologyEstimates",
                    new KeyValuePair<string, object>("CustomProjectMetrologyEstimatesInput",
                        customProjectMetrologyEstimatesInput));
            CustomProjectMetrologyEstimatesOutput customProjectMetrologyEstimatesOutput = null;
            try
            {
                customProjectMetrologyEstimatesOutput = _lamOrchestration.CustomProjectMetrologyEstimates(customProjectMetrologyEstimatesInput);
                return customProjectMetrologyEstimatesOutput;
            }
            catch (System.Exception e)
            {
                throw new CmfBaseException(e.Message, e);
            }
            finally
            {
                customProjectMetrologyEstimatesOutput ??= new CustomProjectMetrologyEstimatesOutput();
                Utilities.EndMethod(-1, -1,
                        new KeyValuePair<string, object>("CustomProjectMetrologyEstimatesInput", customProjectMetrologyEstimatesInput),
                        new KeyValuePair<string, object>("CustomProjectMetrologyEstimatesOutput", customProjectMetrologyEstimatesOutput));
            }
        }

        [HttpPost]
        public LamExecuteActionOutput ExecuteAction(LamExecuteActionInput input)
        {
            Utilities.ValidateNullInput(input);
            Utilities.StartMethod(OBJECT_TYPE_NAME, "ExecuteAction",
                    new KeyValuePair<string, object>(nameof(LamExecuteActionInput), input));

            var output = new LamExecuteActionOutput();
            try
            {
                output = _lamOrchestration.ExecuteAction(input);
            }
            finally
            {
                Utilities.EndMethod(-1, -1,
                        new KeyValuePair<string, object>("ExecuteAction", input),
                        new KeyValuePair<string, object>("ExecuteAction", output));
            }

            return output;
        }

        [HttpPost]
        public CustomGetProtocolInstancesOutput CustomGetProtocolInstances(CustomGetProtocolInstancesInput customGetProtocolInstancesInput)
        {
            Utilities.StartMethod(OBJECT_TYPE_NAME, "CustomGetProtocolInstances",
                    new KeyValuePair<string, object>("CustomGetProtocolInstancesInput",
                        customGetProtocolInstancesInput));
            CustomGetProtocolInstancesOutput customGetProtocolInstancesOutput = null;
            try
            {
                customGetProtocolInstancesOutput = _lamOrchestration.CustomGetProtocolInstances(customGetProtocolInstancesInput);
                return customGetProtocolInstancesOutput;
            }
            catch (System.Exception e)
            {
                throw new CmfBaseException(e.Message, e);
            }
            finally
            {
                customGetProtocolInstancesOutput ??= new CustomGetProtocolInstancesOutput();
                Utilities.EndMethod(-1, -1,
                        new KeyValuePair<string, object>("CustomGetProtocolInstancesInput", customGetProtocolInstancesInput),
                        new KeyValuePair<string, object>("CustomGetProtocolInstancesOutput", customGetProtocolInstancesOutput));
            }
        }
    }
}