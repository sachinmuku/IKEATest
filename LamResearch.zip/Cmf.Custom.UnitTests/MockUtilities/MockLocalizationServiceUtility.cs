﻿using Cmf.Foundation.Common.LocalizationService;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.Lam.UnitTests.MockUtilities
{
    public static class MockLocalizationServiceUtility
    {
        public static Mock<ILocalizationService>  PrepareLocalizationService(params (string MessageKey, string MessageValue)[] messageKeysAndValues)
        {
           return PrepareLocalizationService(Thread.CurrentThread.CurrentCulture.Name, messageKeysAndValues);
        }

        public static Mock<ILocalizationService> PrepareLocalizationService(string cultureName, params (string MessageKey, string MessageValue)[] messageKeysAndValues)
        {
            var localizationServiceMock = new Mock<ILocalizationService>();
            foreach (var (key, value) in messageKeysAndValues)
            {
                localizationServiceMock.Setup(e => e.Localize(cultureName, key)).Returns(value);
                localizationServiceMock.Setup(e => e.Localize(key)).Returns(value);
            }
            return localizationServiceMock;
        }
    }
}
