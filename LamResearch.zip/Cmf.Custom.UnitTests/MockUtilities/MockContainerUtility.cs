﻿using Cmf.Navigo.BusinessObjects.Abstractions;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.Lam.UnitTests.MockUtilities
{
    public static class MockContainerUtility
    {

        public static IContainer CreateContainer(string name, string type)
        {
            IContainer container = Mock.Of<IContainer>();
container.Name = name;
            container.Type = type;
            return container;
        }

        public static  Mock<IContainerCollection> PrepareContainerCollection(IList<IContainer> containerList)
        {
            var mockContainerCollection = new Mock<IContainerCollection>();
            mockContainerCollection.Setup(collection => collection.Count).Returns(containerList.Count);
            mockContainerCollection.Setup(collection => collection.GetEnumerator()).Returns(containerList.GetEnumerator);
            return mockContainerCollection;
        }
    }
}
