﻿using Cmf.Custom.Lam.Common.Interfaces;
using Moq;
using RestSharp.Authenticators;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.Lam.UnitTests.MockUtilities
{
    public static class MockExternalConnectionUtility
    {
        public const string IExpternalConnectionResponeMockedContentValue = "Mocked Error happended";
        public const string IExpternalConnectionResponeMockedErrorMessageValue = "Mocked Error Message";
        public static Mock<IExternalConnection> PrepareExtenalConnection<TResponse>(bool successRespone, TResponse data) where TResponse : class
        {
            var mockExternalConnection = new Mock<IExternalConnection>();
            var responseGeneric = new Mock<IRestResponse<TResponse>>();
            responseGeneric.SetupGet(s => s.IsSuccessful).Returns(successRespone);
            responseGeneric.SetupGet(s => s.Data).Returns(data);
            responseGeneric.SetupGet(s => s.Content).Returns(IExpternalConnectionResponeMockedContentValue);
            responseGeneric.SetupGet(s => s.ErrorMessage).Returns(IExpternalConnectionResponeMockedErrorMessageValue);
            responseGeneric.SetupGet(s => s.ErrorException).Returns(new Exception(IExpternalConnectionResponeMockedErrorMessageValue));
            mockExternalConnection.SetReturnsDefault((IRestResponse)responseGeneric.Object);
            mockExternalConnection.SetReturnsDefault(responseGeneric.Object);
            var mockAuthenticator = new Mock<IAuthenticator>();
            mockAuthenticator.Setup(s => s.Authenticate(It.IsAny<IRestClient>(), It.IsAny<IRestRequest>()));
            mockExternalConnection.SetReturnsDefault(mockAuthenticator.Object);
            return mockExternalConnection;
        }
         public static Mock<IExternalConnection> PrepareExtenalConnection(bool successRespone)
        {
            return PrepareExtenalConnection(successRespone, string.Empty);
        }
    }
}
