﻿using Cmf.Custom.Lam.Common.DataStructures.DatabaseEntities;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Schema;
using System.Xml;
using System.Xml.Serialization;
using Cmf.Foundation.BaseTestsUtils.Extensions;
using Cmf.Navigo.BusinessObjects;

namespace Cmf.Custom.Lam.UnitTests.MockUtilities
{
    public static class MockTableUtility
    {
        public static Mock<IGenericTable> PrepareGenericTableValues<T>(T value) where T : class
        {
            var mockGenericTable = new Mock<IGenericTable>();
            mockGenericTable.Setup(s => s.HasData).Returns(true);
            var mockNgpDataSet = PrepareNgpDataSet(value);
            mockGenericTable.Setup(s => s.Data).Returns(mockNgpDataSet.Object); 
            return mockGenericTable;
        }

        public static Mock<IGenericTable> WhenDataSet<T>(this Mock<IGenericTable> mockGenericTable, T value, Func<bool> whenCondition) where T : class
        {
            mockGenericTable.When(whenCondition).Setup((s) => s.Data).Returns(PrepareNgpDataSet(value).Object);
            return mockGenericTable;
        }
        public static Mock<INgpDataSet> PrepareNgpDataSet<T>(T value) 
        {
            var mockNgpDataSet = new Mock<INgpDataSet>();
            XmlSerializer xmlSerializer = new(typeof(T));
            using var stringWriter = new Utf8StringWriter();

            xmlSerializer.Serialize(stringWriter, value);
            var newxml = stringWriter.GetStringBuilder().ToString();
            mockNgpDataSet.Setup(s => s.DataXML).Returns(newxml);
            using var stringReader = new StringReader(newxml);
            using var xmlReader = XmlReader.Create(stringReader);
            // Create the XmlSchemaSet to hold the inferred schema
            XmlSchemaSet schemaSet = new XmlSchemaSet();

            // Enable automatic XML Schema inference
            XmlSchemaInference schemaInference = new XmlSchemaInference();
            schemaInference.InferSchema(xmlReader, schemaSet);

            // Create a StringWriter to hold the XSD schema
            using StringWriter xsdScheamWriter = new();
            // Create an XmlWriter with settings to write to the StringWriter
            XmlWriterSettings writerSettings = new XmlWriterSettings();
            writerSettings.Indent = true; // Optional: Set indentation
            writerSettings.Encoding = Encoding.UTF8; // Specify the desired encoding
            using var xmlWriter = XmlWriter.Create(xsdScheamWriter, writerSettings);
            foreach (XmlSchema schema in schemaSet.Schemas())
            {
                schema.Write(xmlWriter);
            }

            // Flush the XmlWriter
            xmlWriter.Flush();

            mockNgpDataSet.Setup(s => s.XMLSchema).Returns(xsdScheamWriter.ToString);
            return mockNgpDataSet;
        }
    }
}
