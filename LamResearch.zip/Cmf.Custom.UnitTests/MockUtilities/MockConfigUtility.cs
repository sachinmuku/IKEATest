﻿using Cmf.Foundation.Configuration;
using Cmf.Foundation.Configuration.Abstractions;
using FluentAssertions;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.Lam.UnitTests.MockUtilities
{
    public static class MockConfigUtility
    {

        public static Mock<IConfig> CreateConfig(string name)
        {
            return MockConfigUtility.CreateConfig(name, new ConfigCollection());
        }

        public static Mock<IConfig> CreateConfig(string name, IConfigCollection childConfigs)
        {
            Mock<IConfig> config = new Mock<IConfig>();
            config.SetupProperty((conf) => conf.Name)
                .SetReturnsDefault (name);
            config.SetupProperty((conf) => conf.Path)
                .SetReturnsDefault(name);
            if (childConfigs.Count > 0)
            {
                config.SetupProperty((conf) => conf.ChildConfigs)
                    .SetReturnsDefault(childConfigs);
            }
            return config;
        }
    }
}
