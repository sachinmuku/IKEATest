﻿using Cmf.Custom.Lam.Actions.Containers;
using Cmf.Custom.Lam.Common.DataRepositories;
using Cmf.Custom.Lam.Common.DataStructures.DatabaseEntities;
using Cmf.Foundation.BaseTestsUtils;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessObjects.QueryObject;
using Cmf.Foundation.BusinessOrchestration.GenericServiceManagement.InputObjects;
using Cmf.Foundation.BusinessOrchestration.QueryManagement.InputObjects;
using Cmf.Foundation.BusinessOrchestration.QueryManagement.OutputObjects;
using FluentAssertions;
using Microsoft.AspNetCore.JsonPatch.Operations;
using Moq;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.Lam.UnitTests.Actions.Containers
{
    [TestClass]
    public class OverrideGlobalSearchTests : ActionBaseTests
    {
        [TestInitialize]
        public void Initialize()
        {

        }


        [TestMethod]
        public void DeeTestCondition_ExecutionFromSearchUIWithNoPreviousResults_ReturnsTrue()
        {
            var queryObjectMock = new Mock<IQueryObject>();
            queryObjectMock.Setup(q => q.EntityTypeName).Returns("Container");

            var queryMock = new Mock<IQuery>();
            var input = new ExecuteQueryInput
            {
                QueryObject =  queryObjectMock.Object,
                OperationAttributes = new OperationAttributeCollection
                {
                    { new OperationAttribute{ Name = "fromBarcodeSearch", OperationName = "BarcodeSearch"} }
                }
            };
            ActionInput.Add("ExecuteQueryInput", input);

            var output = new ExecuteQueryOutput { TotalRows = 0 };
            ActionInput.Add("ExecuteQueryOutput", output);

            var dee = new CustomOverrideGlobalSearch();
            var result = dee.DeeTestCondition(ActionInput);

            result.Should().BeTrue();
        }

        [TestMethod]
        public void DeeTestCondition_ExecutionFromSearchUIWithPreviousResults_ReturnsFalse()
        {
            var queryObjectMock = new Mock<IQueryObject>();
            queryObjectMock.Setup(q => q.EntityTypeName).Returns("Container");

            var queryMock = new Mock<IQuery>();
            var input = new ExecuteQueryInput
            {
                QueryObject = queryObjectMock.Object,
                OperationAttributes = new OperationAttributeCollection
                {
                    { new OperationAttribute{ Name = "fromBarcodeSearch", OperationName = "BarcodeSearch"} }
                }
            };
            ActionInput.Add("ExecuteQueryInput", input);

            var output = new ExecuteQueryOutput { TotalRows = 10 };
            ActionInput.Add("ExecuteQueryOutput", output);

            var dee = new CustomOverrideGlobalSearch();
            var result = dee.DeeTestCondition(ActionInput);

            result.Should().BeFalse();
        }

        [TestMethod]
        public void DeeTestCondition_ExecutionFromSearchUIButNotTheContainerQuery_ReturnsFalse()
        {
            var queryObjectMock = new Mock<IQueryObject>();
            queryObjectMock.Setup(q => q.EntityTypeName).Returns("Material");

            var queryMock = new Mock<IQuery>();
            var input = new ExecuteQueryInput
            {
                QueryObject = queryObjectMock.Object,
                OperationAttributes = new OperationAttributeCollection
                {
                    { new OperationAttribute{ Name = "fromBarcodeSearch", OperationName = "BarcodeSearch"} }
                }
            };
            ActionInput.Add("ExecuteQueryInput", input);

            var output = new ExecuteQueryOutput { TotalRows = 20 };
            ActionInput.Add("ExecuteQueryOutput", output);

            var dee = new CustomOverrideGlobalSearch();
            var result = dee.DeeTestCondition(ActionInput);

            result.Should().BeFalse();
        }

        [TestMethod]
        public void DeeTestCondition_ExecutionFromAnotherUI_ReturnsFalse()
        {
            var queryObjectMock = new Mock<IQueryObject>();
            queryObjectMock.Setup(q => q.EntityTypeName).Returns("Container");

            var queryMock = new Mock<IQuery>();
            var input = new ExecuteQueryInput { QueryObject = queryObjectMock.Object };
            ActionInput.Add("ExecuteQueryInput", input);

            var output = new ExecuteQueryOutput { TotalRows = 1 };
            ActionInput.Add("ExecuteQueryOutput", output);

            var dee = new CustomOverrideGlobalSearch();
            var result = dee.DeeTestCondition(ActionInput);

            result.Should().BeFalse();
        }        

        [TestMethod]
        public void DeeActionCode_FilterByValidTag_CallQueryExecute()
        {
            var queryObjectMock = new Mock<IQueryObject>();
            queryObjectMock.Setup(q => q.EntityTypeName).Returns("Container");

            var queryMock = new Mock<IQuery>();
            queryMock.Setup(q => q.Filters).Returns(new FilterCollection { new Filter { Name = "Name", Value = "1234" } });

            queryObjectMock.Setup(q => q.Query).Returns( queryMock.Object);
            var executeQueryInput = new ExecuteQueryInput
            {
                QueryObject = queryObjectMock.Object
            };            
            var output = new ExecuteQueryOutput { TotalRows = 0 };

            var entityTag = new EntityTagDbo { Entries = new List<EntityTag> { new EntityTag { EntityName = "ContainerTest" } } };
            var tagRepo = new Mock<IEntityTagRepository>();
            tagRepo.Setup(t => t.GetByTagName("1234")).Returns(entityTag);

            AddMockToActionInput(tagRepo);
            ActionInput.Add("ExecuteQueryInput", executeQueryInput);
            ActionInput.Add("ExecuteQueryOutput", output);
            var dee = new CustomOverrideGlobalSearch();
            dee.DeeActionCode(ActionInput);
            
            queryObjectMock.Verify(q => q.Execute(false, null), Times.Once());
        }

        [TestMethod]
        public void DeeActionCode_FilterByInvalidTag_DoNotCallQueryExecute()
        {
            var queryObjectMock = new Mock<IQueryObject>();
            queryObjectMock.Setup(q => q.EntityTypeName).Returns("Container");

            var queryMock = new Mock<IQuery>();
            queryMock.Setup(q => q.Filters).Returns(new FilterCollection { new Filter { Name = "Name", Value = "1234" } });

            queryObjectMock.Setup(q => q.Query).Returns(queryMock.Object);
            var executeQueryInput = new ExecuteQueryInput
            {
                QueryObject = queryObjectMock.Object
            };
            var output = new ExecuteQueryOutput { TotalRows = 0 };

            var entityTag = new EntityTagDbo { Entries = new List<EntityTag> { new EntityTag { EntityName = null } } };
            var tagRepo = new Mock<IEntityTagRepository>();
            tagRepo.Setup(t => t.GetByTagName("1234")).Returns(entityTag);

            AddMockToActionInput(tagRepo);
            ActionInput.Add("ExecuteQueryInput", executeQueryInput);
            ActionInput.Add("ExecuteQueryOutput", output);
            var dee = new CustomOverrideGlobalSearch();
            dee.DeeActionCode(ActionInput);

            queryObjectMock.Verify(q => q.Execute(false, null), Times.Never());
        }
    }
}
