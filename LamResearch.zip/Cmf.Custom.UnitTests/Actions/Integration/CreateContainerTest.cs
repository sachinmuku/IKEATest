﻿using Cmf.Custom.Lam.Actions.Containers;
using Cmf.Custom.Lam.Actions.TagVue;
using Cmf.Custom.Lam.Common.DataStructures.DatabaseEntities;
using Cmf.Custom.Lam.Common.Interfaces.Inbound;
using Cmf.Custom.Lam.UnitTests.MockUtilities;
using Cmf.Foundation.BaseTestsUtils;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common.LocalizationService;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using FluentAssertions;
using Microsoft.AspNetCore.ResponseCaching;
using Microsoft.Extensions.DependencyInjection;
using Moq;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cmf.Custom.Lam.UnitTests.Actions.Integration
{
    [TestClass]
    public class CreateContainerTest : ActionBaseTests
    {

        [TestInitialize]
        public void InitialTest () {
            AddMockToActionInput(new Mock<ILocalizationService>());
        }  

        [TestMethod]
        [DataRow("FOUP")]
        public void CreateContainerWithSuccessResult(string containerType)
        {
            //Arrange 
            IContainer container = Mock.Of<IContainer>();
            container.Type = containerType;
            var mockContainerCollection = AddMockToActionInput(MockContainerUtility.PrepareContainerCollection(new IContainer[] { container }));
            var mockGenericTable = AddMockToActionInput(MockTableUtility.PrepareGenericTableValues(new TagVueContainerConfigurationDbo
            {
                Entries = new List<TagVueContainerConfiguration> {
                    new TagVueContainerConfiguration {
                    CategoryName = containerType,
                    EntityID = "12345"
                    }
                }
            }));
            ActionInput.Add("Containers", mockContainerCollection.Object);
            ActionInput.Add("GenericTable", mockGenericTable.Object);

            AddMockToActionInput(MockExternalConnectionUtility.PrepareExtenalConnection(true));
            //Act
            var dee = new CustomSendInformationToTagVueOnContainerCreation();
            dee.DeeActionCode(ActionInput);
        }
    }
}
