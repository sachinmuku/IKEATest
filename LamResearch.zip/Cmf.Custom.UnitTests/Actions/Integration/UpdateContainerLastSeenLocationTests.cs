using Cmf.Custom.Lam.Actions.TagVue;
using Cmf.Custom.Lam.Common.Interfaces.Inbound;
using Cmf.Foundation.BaseTestsUtils.Extensions;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common.Abstractions;
using Moq;
using Newtonsoft.Json;
using System.Text;
using Cmf.Foundation.BaseTestsUtils;
using Autofac.Core;
using Cmf.Navigo.BusinessObjects.Abstractions;
using FluentAssertions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.Common.LocalizationService;
using Cmf.Custom.Lam.Common.Constants;

namespace Cmf.Custom.Lam.UnitTests.Actions.Integration
{
    [TestClass]
    public class UpdateContainerLastSeenLocationTests : ActionBaseTests
    {
        private Mock<IIntegrationEntry> IntegrationEntryMock { get; set; } = new Mock<IIntegrationEntry>();

        private Mock<IContainer> ContainerMock { get; set; } = new Mock<IContainer>();

        private Mock<IEntityFactory> EntityFactoryMock { get; set; }

        private Mock<ILocalizationService> LocalizationServiceMock { get; set; }

        private string missingIntegrationEntryMessage = "Integration Entry missing Integration Message";

        private string containerNotFoundMessage = "Container {0} not found.";

        private string mandatoryFieldsMessage = "Mandatory field(s) missing";

        [TestMethod]
        public void DeeActionCode_ValidMessage_NoError()
        {
            //Arrange
            var lastSeenLocationInfo = new LastSeenLocationMessage
            {
                EventTimeStamp = DateTime.Now.ToString(),
                ItemName = "itemX",
                NewLocationName = "newLocation",
                PreviousLocationName = "oldLocation"                
            };

            MockIntegrationEntry(lastSeenLocationInfo);
            MockExistingContainer();
            MockEntityFactory();

            //Act
            ActionInput.Add("IntegrationEntry", IntegrationEntryMock.Object);
            var dee = new CustomUpdateLastSeenLocation();
            dee.DeeActionCode(ActionInput);

            //Assert
            ContainerMock.VerifySet(c => c.Name = lastSeenLocationInfo.ItemName);
        }

        [TestMethod]
        public void DeeActionCode_ContainerDoesNotExist_ReturnsError()
        {
            var lastSeenLocationInfo = new LastSeenLocationMessage
            {
                EventTimeStamp = DateTime.Now.ToString(),
                ItemName = "Container X",
                NewLocationName = "newLocation",
                PreviousLocationName = "oldLocation"
            };

            MockIntegrationEntry(lastSeenLocationInfo);
            ContainerMock.Setup(c => c.ObjectExists()).Returns(false);
            MockEntityFactory();
            MockLocalizationService();
            
            ActionInput.Add("IntegrationEntry", IntegrationEntryMock.Object);
            var dee = new CustomUpdateLastSeenLocation();
            
            Action deeAction = () => dee.DeeActionCode(ActionInput);
            deeAction.Should().Throw<Exception>().WithMessage(string.Format(containerNotFoundMessage, lastSeenLocationInfo.ItemName));
        }


        [TestMethod]
        public void DeeActionCode_MessageMissingItemName_ReturnsError()
        {
            var lastSeenLocationInfo = new LastSeenLocationMessage
            {
                EventTimeStamp = DateTime.Now.ToString(),
                ItemName = null,
                NewLocationName = "newLocation",
                PreviousLocationName = "oldLocation"
            };

            MockIntegrationEntry(lastSeenLocationInfo);
            MockExistingContainer();
            MockEntityFactory();

            ActionInput.Add("IntegrationEntry", IntegrationEntryMock.Object);
            var dee = new CustomUpdateLastSeenLocation();
            
            Action deeAction = () => dee.DeeActionCode(ActionInput);
            deeAction.Should().Throw<Exception>().WithMessage($"{mandatoryFieldsMessage}*ItemName");
        }

        [TestMethod]
        public void DeeActionCode_MessageMissingNewLocationName_ReturnsError()
        {
            //Arrange
            var lastSeenLocationInfo = new LastSeenLocationMessage
            {
                EventTimeStamp = DateTime.Now.ToString(),
                ItemName = "ItemX",
                NewLocationName = "",
                PreviousLocationName = "oldLocation"
            };

            MockIntegrationEntry(lastSeenLocationInfo);
            MockExistingContainer();
            MockEntityFactory();

            //Act
            ActionInput.Add("IntegrationEntry", IntegrationEntryMock.Object);
            var dee = new CustomUpdateLastSeenLocation();
            Action deeAction = () => dee.DeeActionCode(ActionInput);
            deeAction.Should().Throw<Exception>().WithMessage($"{mandatoryFieldsMessage}*NewLocationName");
        }

        [TestMethod]
        public void DeeActionCode_MessageMissingNewLocationNameAndItemName_ReturnsError()
        {
            //Arrange
            var lastSeenLocationInfo = new LastSeenLocationMessage
            {
                EventTimeStamp = DateTime.Now.ToString(),
                ItemName = "",
                NewLocationName = "",
                PreviousLocationName = "oldLocation"
            };

            MockIntegrationEntry(lastSeenLocationInfo);
            MockExistingContainer();
            MockEntityFactory();

            //Act
            ActionInput.Add("IntegrationEntry", IntegrationEntryMock.Object);
            var dee = new CustomUpdateLastSeenLocation();
            Action deeAction = () => dee.DeeActionCode(ActionInput);
            deeAction.Should().Throw<Exception>().WithMessage($"{mandatoryFieldsMessage}*ItemName*NewLocationName");
        }

        private void MockIntegrationEntry(LastSeenLocationMessage lastSeenLocationInfo)
        {
            var message = JsonConvert.SerializeObject(lastSeenLocationInfo);
            var integrationMessage = new Mock<IIntegrationMessage>();
            integrationMessage.Setup(i => i.Message).Returns(Encoding.Default.GetBytes(message));

            IntegrationEntryMock = new Mock<IIntegrationEntry>();
            IntegrationEntryMock.Setup(i => i.IntegrationMessage).Returns(integrationMessage.Object);
        }

        private void MockExistingContainer()
        {
            ContainerMock = new Mock<IContainer>();
            ContainerMock.Setup(c => c.ObjectExists()).Returns(true);
        }

        private void MockEntityFactory()
        {
            EntityFactoryMock = AddMockToActionInput<IEntityFactory>();
            EntityFactoryMock.Setup(e => e.Create<IContainer>()).Returns(ContainerMock.Object);
        }

        private void MockLocalizationService()
        {
            LocalizationServiceMock = AddMockToActionInput<ILocalizationService>();
            LocalizationServiceMock.Setup(e => e.Localize(LamResearchConstants.LocalizedMessages.MissingIntegrationMessage)).Returns(missingIntegrationEntryMessage);
            LocalizationServiceMock.Setup(e => e.Localize(LamResearchConstants.LocalizedMessages.ContainerNotFound)).Returns(containerNotFoundMessage);
        }
    }
}