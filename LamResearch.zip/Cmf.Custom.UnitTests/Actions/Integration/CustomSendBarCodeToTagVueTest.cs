﻿using Cmf.Custom.Lam.Actions.Containers;
using Cmf.Custom.Lam.Common.Constants;
using Cmf.Custom.Lam.Common.DataStructures.DatabaseEntities;
using Cmf.Custom.Lam.Common.DataStructures.TagVue;
using Cmf.Custom.Lam.UnitTests.MockUtilities;
using Cmf.Foundation.BaseTestsUtils;
using Cmf.Foundation.BusinessObjects;
using FluentAssertions;
using Moq;
using static Cmf.Custom.Lam.UnitTests.MockUtilities.MockExternalConnectionUtility;
using static Cmf.Custom.Lam.UnitTests.MockUtilities.MockTableUtility;
using static Cmf.Custom.Lam.UnitTests.MockUtilities.MockLocalizationServiceUtility;

namespace Cmf.Custom.Lam.UnitTests.Actions.Integration
{
    [TestClass]
    public class CustomSendBarCodeToTagVueTest : ActionBaseTests
    {
        /// <summary>
        /// When new entry is inserted to EntityTag table, and create in in TagVue system
        /// </summary>
        [TestMethod]
        public void SendBarcodeTagVueOnInsertCreateInTagVue()
        {
            //Arrange
            ActionInput.Add("ActionGroupName", "InsertOrUpdateRow");
            var externalConnection = AddMockToActionInput(MockExternalConnectionUtility.PrepareExtenalConnection(true));
            ActionInput.Add("GDataset", AddMockToActionInput(PrepareNgpDataSet(new EntityTagDbo { Entries = new List<EntityTag> { new EntityTag { Scope = EntityTagScopeDbo.BarcodeId, EntityType = "Container", EntityTagId = long.MaxValue, EntityId = 111, Tag = "Tag" } } })).Object);
            AddMockToActionInput(PrepareLocalizationService());
            Action result = () => new CustomSendBarCodeToTagVue().DeeActionCode(ActionInput);
            result.Should().NotThrow();
            externalConnection.Verify(s => s.ExecuteHttpRequest<TagVueAddBarcodeRequest, string>(
                CustomExternalSystemOperations.AddBarCode,
                It.IsAny<TagVueAddBarcodeRequest>(),
                new Dictionary<string, string>() { { "entityid", "111" } }));

        }

        /// <summary>
        /// When new entry is inserted to EntityTag table, and create in in TagVue system but TagVue is not available
        /// </summary>
        /// <param name="actionGroupName"></param>
        [TestMethod]
        public void SendBarcodeOnInsertWhenTagVueNotAvailable()
        {
            //Arrange
            ActionInput.Add("ActionGroupName", "InsertOrUpdateRow");
            var externalConnection = AddMockToActionInput(PrepareExtenalConnection(false));
            ActionInput.Add("GDataset", AddMockToActionInput(PrepareNgpDataSet(new EntityTagDbo { Entries = new List<EntityTag> { new EntityTag { Scope = EntityTagScopeDbo.BarcodeId, EntityType = "Container", EntityTagId = long.MaxValue, EntityId = 111, Tag = "Tag" } } })).Object);
            AddMockToActionInput(PrepareLocalizationService());
            Action result = () => new CustomSendBarCodeToTagVue().DeeActionCode(ActionInput);
            result.Should().Throw<Exception>("TagVue System is not available");
            externalConnection.Verify(s => s.ExecuteHttpRequest<TagVueAddBarcodeRequest, string>(
                CustomExternalSystemOperations.AddBarCode,
                It.IsAny<TagVueAddBarcodeRequest>(),
                new Dictionary<string, string>() { { "entityid", "111" } }));

        }
        /// <summary>
        /// When new entry is inserted to EntityTag table, and create in in TagVue system but TagVue send exception as response
        /// </summary>
        [TestMethod]
        public void SendBarcodeOnInsertGotErrorMessageFromTagVue()
        {
            //Arrange
            ActionInput.Add("ActionGroupName", "InsertOrUpdateRow");
            var externalConnection = AddMockToActionInput(PrepareExtenalConnection(false, IExpternalConnectionResponeMockedErrorMessageValue));
            ActionInput.Add("GDataset", AddMockToActionInput(PrepareNgpDataSet(new EntityTagDbo { Entries = new List<EntityTag> { new EntityTag { Scope = EntityTagScopeDbo.BarcodeId, EntityType = "Container", EntityTagId = long.MaxValue, EntityId = 111, Tag = "Tag" } } })).Object);
            AddMockToActionInput(PrepareLocalizationService());
            Action result = () => new CustomSendBarCodeToTagVue().DeeActionCode(ActionInput);
            result.Should().Throw<Exception>($"TagVueBarcodeCreation request failed with {IExpternalConnectionResponeMockedContentValue} body and error message: {IExpternalConnectionResponeMockedErrorMessageValue}");  
           
                externalConnection.Verify(s => s.ExecuteHttpRequest<TagVueAddBarcodeRequest, string>(
               CustomExternalSystemOperations.AddBarCode,
               It.IsAny<TagVueAddBarcodeRequest>(),
               new Dictionary<string, string>() { { "entityid", "111" } }));
        }

        [TestMethod]
        public void SendBarcodeOnOnRemoveGotErrorMessageFromTagVue()
        {
            //Arrange
            ActionInput.Add("ActionGroupName", "RemoveRows");
            var tagVueResponse = new TagVueRemoveResponse()
            {
                EntityId = 111,
                Epc = 0,
                Info = 1
            };
            var externalConnection = AddMockToActionInput(PrepareExtenalConnection(false, tagVueResponse));
            ActionInput.Add("GDataset", AddMockToActionInput(PrepareNgpDataSet(new EntityTagDbo { Entries = new List<EntityTag> { new EntityTag { Scope = EntityTagScopeDbo.BarcodeId, EntityType = "Container", EntityId = 111, Tag = "Tag" } } })).Object);
            var exceptionMessage = $"The EntityId: 111, with Epc: Tag is failed with following: {tagVueResponse.Info}";
            AddMockToActionInput(PrepareLocalizationService((LamResearchConstants.LocalizedMessages.TagVueBarcodeRemoveFailed, exceptionMessage)));
            Action result = () => new CustomSendBarCodeToTagVue().DeeActionCode(ActionInput);
            result.Should().Throw<Exception>(exceptionMessage);

            externalConnection.Verify(s => s.ExecuteHttpRequest<TagVueRemoveResponse>(
            CustomExternalSystemOperations.RemoveBarCode,
            new Dictionary<string, string>() { { "entityid", tagVueResponse.EntityId.ToString() }, { "epc", "Tag" } }));
        }

        [TestMethod]
        public void SendBarcodeOnOnRemoveAndRemovedFromTagVue()
        {
            //Arrange
            ActionInput.Add("ActionGroupName", "RemoveRows");
            var tagVueResponse = new TagVueRemoveResponse()
            {
                EntityId = 111,
                Epc = 0,
                Info = 1
            };
            var externalConnection = AddMockToActionInput(PrepareExtenalConnection(true, tagVueResponse));
            ActionInput.Add("GDataset", AddMockToActionInput(PrepareNgpDataSet(new EntityTagDbo { Entries = new List<EntityTag> { new EntityTag { Scope = EntityTagScopeDbo.BarcodeId, EntityType = "Container", EntityId = 111, Tag = "Tag" } } })).Object);
            AddMockToActionInput(PrepareLocalizationService());
            Action result = () => new CustomSendBarCodeToTagVue().DeeActionCode(ActionInput);
            result.Should().NotThrow();

            externalConnection.Verify(s => s.ExecuteHttpRequest<TagVueRemoveResponse>(
            CustomExternalSystemOperations.RemoveBarCode,
            new Dictionary<string, string>() { { "entityid", tagVueResponse.EntityId.ToString() }, { "epc", "Tag" } }));
        }

        [TestMethod]
        public void SendBarcodeOnOnRemoveAndTagVueNotAvailable()
        {
            //Arrange
            ActionInput.Add("ActionGroupName", "RemoveRows");
            
            var externalConnection = AddMockToActionInput(PrepareExtenalConnection(false));
            ActionInput.Add("GDataset", PrepareNgpDataSet(new EntityTagDbo
            {
                Entries = new List<EntityTag> {
                    new EntityTag {
                        Scope = EntityTagScopeDbo.BarcodeId,
                        EntityType = "Container",
                        EntityId = 111,
                        Tag = "Tag"
                    } }
            }).Object);
            AddMockToActionInput(PrepareLocalizationService());
            Action result = () => new CustomSendBarCodeToTagVue().DeeActionCode(ActionInput);
            result.Should().Throw<Exception>();

            externalConnection.Verify(s => s.ExecuteHttpRequest<TagVueRemoveResponse>(
            CustomExternalSystemOperations.RemoveBarCode,
            new Dictionary<string, string>() { { "entityid", "111"}, { "epc", "Tag" } }));
        }
    }
}
