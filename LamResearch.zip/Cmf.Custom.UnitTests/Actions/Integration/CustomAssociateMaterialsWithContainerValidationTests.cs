﻿using Autofac;
using Cmf.Custom.Lam.Actions.Containers;
using Cmf.Custom.Lam.Common.Constants;
using Cmf.Custom.Lam.Common.DataStructures;
using Cmf.Custom.Lam.Common.DataStructures.DatabaseEntities;
using Cmf.Custom.Lam.Common.Extensions;
using Cmf.Custom.Lam.UnitTests.MockUtilities;
using Cmf.Foundation.BaseTestsUtils;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessObjects.GenericTables;
using Cmf.Foundation.BusinessObjects.QueryObject;
using Cmf.Foundation.Configuration.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessOrchestration.ContainerManagement.InputObjects;
using Cmf.Navigo.BusinessOrchestration.LaborManagement.InputObjects;
using Cmf.Navigo.Common;
using DocumentFormat.OpenXml.Spreadsheet;
using FluentAssertions;
using Microsoft.Extensions.DependencyInjection;
using Moq;
using Namotion.Reflection;
using Stimulsoft.Svg;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.Lam.UnitTests.Actions.Integration;

[TestClass]
public class CustomAssociateMaterialsWithContainerValidationTests : ActionBaseTests
{
    private const string containerName = "TestContainer";
    private const string containerType = "Customer Wafer";

    [TestInitialize]
    public void TestInit()
    {
        const int containerId = 1111;
        var tagVueConfigurationTable = MockTableUtility.PrepareNgpDataSet(new TagVueContainerConfigurationDbo
        {
            Entries = new List<TagVueContainerConfiguration> {
                    new TagVueContainerConfiguration {
                    CategoryName = containerType,
                    EntityID = containerId.ToString(),
                    NumberOfBarcodes = 2
                    }
                }
        });
        var entityTagTable = MockTableUtility.PrepareNgpDataSet(new EntityTagDbo
        {
            Entries = new List<EntityTag> {
            new EntityTag { Scope = EntityTagScopeDbo .BarcodeId,
                EntityType = "Container",
                EntityTagId = 123123,
                EntityId = containerId,
                Tag = "Tag"
            }}
        });
        Mock<IGenericTable> genericTable = new Mock<IGenericTable>();
        genericTable.SetupProperty(gt => gt.Name);
        genericTable.Setup((gt) => gt.Load())
            .Callback(() =>
            {
                genericTable.When(() => genericTable.Object.Name == EntityTagTableConstants.TableName)
                .Setup((gt) => gt.Data)
                .Returns(entityTagTable.Object);
                genericTable.When(() => genericTable.Object.Name == TagVueGenericTableContants.GenericTableName)
                    .Setup((gt) => gt.Data)
                    .Returns(tagVueConfigurationTable.Object);
            });
        var config = new Mock<IConfig>();
        AddMockToActionInput(config);
        AddMockToActionInput(genericTable);

        ActionInput.Add(nameof(Container), MockContainerUtility.CreateContainer(containerName, containerType));
        ActionInput.Add("MaterialRelations", Mock.Of<IRelationCollection>());
        ActionInput.Add("ActionGroupName", "BusinessObjects.Container.AssociateMaterials.Pre");
    }

    [TestMethod]
    public void CustomAssociateMaterialsWithContainerValidationTestsHappyPath()
    {

        Action result = () => new CustomAssociateMaterialsWithContainerValidation().DeeActionCode(ActionInput);
        result.Should().NotThrow();
    }

    [TestCleanup]
    public void TestCleanup()
    {
        ActionInput.Clear();
    }
}
