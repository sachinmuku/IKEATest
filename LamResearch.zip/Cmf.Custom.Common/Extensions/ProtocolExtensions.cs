﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Custom.Lam.BusinessObjects.Abstractions;
using Cmf.Custom.Lam.Common.Queries;
using Cmf.Foundation.Common;
using Cmf.Navigo.BusinessObjects.Abstractions;
using System.Linq;
using Cmf.Custom.Lam.Common.DataStructures;

namespace Cmf.Custom.Lam.Common.Extensions
{
    // <summary>
    // Extensions to extend protocol functionality
    // </summary>
	public static class ProtocolExtensions
	{
        public static ICustomProjectCode GetProjectCode(this IProtocolInstance instance)
        {
            instance.Load();
            ICustomProjectCodeProtocolInstance relation = null;
            bool throwError = false;

            if (instance.HasRelations("CustomProjectCodeProtocolInstance", true))
            {
                relation = (ICustomProjectCodeProtocolInstance)instance.RelationCollection["CustomProjectCodeProtocolInstance"].FirstOrDefault();
                if (relation.TargetEntity == null)
                {
                    throwError = true;
                }
            }
            else
            {
                throwError = true;
            }

            if (throwError)
            {
                LamUtilities.ThrowLocalizedException(LamConstants.LMCustomProjectCodeProtocolInstanceRelationNotFound, instance.Name);
            }

            ICustomProjectCode projectCode = relation.TargetEntity;
            projectCode.Load();

            return projectCode;
        }
        public static IProtocolPathParameter GetProtocolInstanceParameters(this IProtocolInstance protocolInstance,string parameterName)
        {
            var tableFilter = new TableFilterBuilder()
                    .AddFilter("Name", protocolInstance.Name, "ProtocolInstance", "ProtocolPath_Parent_2", FieldOperator.Contains, LogicalOperator.Nothing)
                    .AddFieldCollection("Id", "Id", "ProtocolPath", "ProtocolPath_1", 0)
                    .AddFieldCollection("Name", "Name", "ProtocolPath", "ProtocolPath_1", 1)
                    .AddRelationCollection("ProtocolPath", "ProtocolPath_1", "ParentId", "ProtocolInstance", "ProtocolPath_Parent_2", "Id");

            var protocolPathCollection = ProtocolQueries.GetProtocolPathCollectionFromProtocolInstance(tableFilter);
            foreach (IProtocolPath protocolPath in protocolPathCollection)
            {
                protocolPath.LoadParameters();
                protocolPath.State.Load();
                return protocolPath.Parameters.FirstOrDefault(x => x.ParameterName.Equals(parameterName,System.StringComparison.InvariantCultureIgnoreCase));
            }
            return default;
        }
	}
}
