﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common;
using Cmf.Navigo.BusinessObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;

namespace Cmf.Custom.Lam.Common.Extensions
{
    // <summary>
    // Extensions to extend entity functionality
    // </summary>
	public static class EntityExtensions
	{
        // <summary>
        // Creates an entity with just the Id and Name filled
        // </summary>
        // <typeparam name="T"></typeparam>
        // <param name="original"></param>
        // <returns></returns>
		public static T GenerateLightEntity<T>(this T original) where T: Entity, new()
		{
			T lightEntity = new T();
			PropertyInfo propertyInfo = lightEntity.GetType().GetProperty("Id");
			propertyInfo.SetValue(lightEntity, Convert.ChangeType(original.Id, propertyInfo.PropertyType), null);
			lightEntity.Name = original.Name;

			return lightEntity;			
		}

        // <summary>
        // Get state model transitions from the EntityInstance current state to the given state
        // </summary>
        // <param name="entityInstance"></param>
        // <param name="toStateName"></param>
        // <returns>bool</returns>
        public static IStateModelTransition GetStateModelTransitionForState(this IEntityInstance entityInstance, string toStateName)
        {
            IStateModelTransition transition = null;

            if (entityInstance?.CurrentMainState != null)
            {
                entityInstance.CurrentMainState.StateModel.Load();

                IStateModelTransitionCollection transitionsForState = entityInstance.CurrentMainState.StateModel.GetPossibleTransitionsForState(entityInstance.CurrentMainState.CurrentState);

                transition = transitionsForState.FirstOrDefault(t => t.ToState.Name.Equals(toStateName, StringComparison.InvariantCultureIgnoreCase));
            }

            return transition;
        }
        public static bool TryGetRelations<T>(this IEntity entity,string name,out List<T> relationEntityList,int relationlevelToLoad=4) where T : IEntity
        {
            relationEntityList = Enumerable.Empty<T>().ToList();
            entity.LoadRelations(name, relationlevelToLoad);
            if (entity.RelationCollection.TryGetValue(name,out var entityRelations)){

                relationEntityList.AddRange(entityRelations.Where(er=>er.SourceEntity is T)?.Select(er => er.SourceEntity).Cast<T>());
            }
            return relationEntityList.Any();
        }

        // <summary>
        // Get state model next transition to the EntityInstance current state from the given state
        // </summary>
        // <param name="entityInstance"></param>
        // <param name="toStateName"></param>
        // <returns>bool</returns>
        public static IStateModelTransition GetStateModelNextTransitionForState(ProtocolInstance instance)
        {
            IStateModelTransition transition = null;

            if (instance?.CurrentMainState != null)
            {
                instance.CurrentMainState.StateModel.Load();

                IStateModelTransitionCollection transitionsForState = instance.CurrentMainState.StateModel.GetPossibleTransitionsForState(instance.CurrentMainState.CurrentState);

                transition = transitionsForState.FirstOrDefault();
            }

            return transition;
        }
    }
}
