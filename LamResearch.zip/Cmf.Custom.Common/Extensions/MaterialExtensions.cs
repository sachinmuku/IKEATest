﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.Abstractions;
using Cmf.Navigo.BusinessOrchestration.MappingManagement;
using Cmf.Navigo.BusinessOrchestration.MappingManagement.InputObjects;
using Cmf.Navigo.BusinessOrchestration.MappingManagement.OutputObjects;

namespace Cmf.Custom.Lam.Common.Extensions
{
    // <summary>
    // Extensions to extend material functionality
    // </summary>
    public static class MaterialExtensions
    {
        /// <summary>
        /// Returns all the Sub-Materials, recursively, for a specific Material
        /// </summary>
        /// <param name="material"></param>
        /// <returns></returns>
        public static IMaterialCollection GetMaterialTree(this IMaterial material)
        {
            IMaterialCollection materials = new MaterialCollection();

            GetMaterialTree(material, materials);

            return materials;
        }

        /// <summary>
        /// Private method to reach every Sub-Material, recursively
        /// </summary>
        /// <param name="material"></param>
        /// <param name="materials"></param>
        private static void GetMaterialTree(IMaterial material, IMaterialCollection materials)
        {
            material.LoadChildren();
            materials.Add(material);

            foreach (IMaterial subMaterial in material.SubMaterials)
            {
                GetMaterialTree(subMaterial, materials);
            }
        }
        public static IEnumerable<IMaterial> GetSubMaterials(this IMaterial material) 
        {
            material.LoadChildren();
            if (material.SubMaterialCount > 0)
            {
                foreach (var subMaterial in material.SubMaterials)
                {
                    foreach (var currentSubMaterial in subMaterial.GetSubMaterials())
                    {
                        yield return currentSubMaterial;
                    }
                }
                
            }
            else
            {
                yield break;
            }
        }
        /// <summary>
        /// Returns the maps associated to a Material
        /// </summary>
        /// <param name="material"></param>
        /// <param name="masterMap"></param>
        /// <returns></returns>
        public static IMapCollection GetMaterialMaps(this IMaterial material, bool masterMap = true)
        {
            IMappingOrchestration mappingOrchestration = new MappingOrchestration();

            IMapCollection maps = new MapCollection();

            GetMapsForMaterialOutput mapsLinkedToMaterial = mappingOrchestration.GetMapsForMaterial(
                new GetMapsForMaterialInput
                {
                    Material = material,
                });

            if (mapsLinkedToMaterial != null && mapsLinkedToMaterial.Maps != null && mapsLinkedToMaterial.Maps.Count > 0)
            {
                maps = mapsLinkedToMaterial.Maps;

                if (!masterMap) maps.Remove(maps.FirstOrDefault(x => x.IsMaster));
            }

            return maps;
        }

        public static IMaterial GetParentMaterial(this IMaterial material) => material.ParentMaterial ?? material;

    }
}
