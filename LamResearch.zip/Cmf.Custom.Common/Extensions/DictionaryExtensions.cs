﻿using Cmf.Foundation.BusinessObjects.QueryObject.Clauses;
using Cmf.Foundation.BusinessOrchestration;
﻿
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.ContainerManagement.InputObjects;
using Cmf.Navigo.BusinessOrchestration.MaterialManagement.InputObjects;
using DocumentFormat.OpenXml.Bibliography;
using DocumentFormat.OpenXml.Spreadsheet;
using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using Cmf.Foundation.BusinessOrchestration.DynamicExecutionEngineManagement.InputObjects;

namespace Cmf.Custom.Lam.Common.Extensions
{
    // <summary>
    // Extensions to extend dictionary functionality
    // </summary>
	public static class DictionaryExtensions
	{
        // <summary>
        // Try to get some value from a dictionary and return the default for the given type
        // </summary>
        // <typeparam name="Key"></typeparam>
        // <typeparam name="Value"></typeparam>
        // <typeparam name="ValueAs"></typeparam>
        // <param name="dictionary"></param>
        // <param name="key"></param>
        // <param name="valueAs"></param>
        // <returns></returns>
        public static bool TryGetValueAs<Key, Value, ValueAs>(this IDictionary<Key, Value> dictionary, Key key, out ValueAs valueAs) where ValueAs : Value
        {
            if (dictionary.TryGetValue(key, out Value value))
            {
                valueAs = value == null ? default : (ValueAs)value;
                return true;
            }

            valueAs = default;
            return false;

        }
        public static IServiceProvider GetServiceProviderService(this Dictionary<string,object> input) => input["ServiceProvider"] as IServiceProvider;

        public static bool IsPostActionGroup(this Dictionary<string,object> input)
        {
            return input.TryGetValue("ActionGroupName", out var actionGroupObject) && actionGroupObject is string actionGroup && actionGroup.EndsWith("Post");
        }

        public static IMaterial GetMaterial(this Dictionary<string,object> input)
        {
            if (input.TryGetValue(Navigo.Common.Constants.Material, out var materialObject) && materialObject is IMaterial material)
            {
                return material;
            }
            if (input.TryGetValue(Navigo.Common.Constants.MaterialCollection, out var materialCollectionObject) && materialCollectionObject is IMaterialCollection materialCollection)
            {
                return materialCollection.FirstOrDefault();
            }
            return default;
        }
        public static IList<IMaterial> GetSplitMaterials(this Dictionary<string, object> input)
        {
            if (input.TryGetValue("ChildMaterialsInformation", out var splitMaterialColletionObject) && splitMaterialColletionObject is IDictionary<IMaterial, ISplitInputParametersCollection> materialCollection )
            {
                return materialCollection.Keys.ToList();
            }
           

            return Array.Empty<IMaterial>().ToList();
        }
        public static IList<IMaterial> GetSubMaterials(this Dictionary<string, object> input)
        {
           if ( input.TryGetValue(Navigo.Common.Constants.SubMaterials,out var subMaterialObject) && subMaterialObject is IMaterialCollection materialCollection)
           {
                return materialCollection;
           }
           return Array.Empty<IMaterial>().ToList();
        }
        public static IList<(IMaterial Material,IProductionOrder ProductionOrder)> GetMaterialOrders(this Dictionary<string, object> input)
        {
            if (input.TryGetValue("MaterialOrders",out var materialOrdersObject) && materialOrdersObject is Dictionary<IMaterial,IProductionOrder> materialOrders)
            {
                return materialOrders.Select(s=>(s.Key,s.Value)).ToList();
            }
            return Array.Empty<(IMaterial Material, IProductionOrder ProductionOrder)>().ToList();
        }
        public static (string Name,string Prefix,string Operation,string Suffix) GetActionGroupSplittedBy(this Dictionary<string, object> input,string splitBy=".")
        {
            var actionGroup = GetActionGroupName(input);
                var splitedActionGroup = actionGroup.Split(splitBy);
                return (actionGroup,
                       $"{splitedActionGroup[0]}.{splitedActionGroup[1]}",
                        splitedActionGroup[2],
                      splitedActionGroup[3]);
        }
        public static string GetActionGroupName(this Dictionary<string, object> input) => input["ActionGroupName"] as string;
       

        public static string GetCurrentStepName(this Dictionary<string, object> input)
        {
            var filterInput = input.Where(i => i.Key.Contains("Material", StringComparison.InvariantCultureIgnoreCase) || i.Key.Contains("Container", StringComparison.InvariantCultureIgnoreCase));
            foreach (var objectInput in filterInput)
            {
             var currentProperty = objectInput.Value.GetType().GetProperties().FirstOrDefault(prop => prop.Name.Contains("Material") || prop.Name.Contains("Container"));
                if (currentProperty != null)
                {
                    var currentValue = currentProperty.GetValue(objectInput.Value, null);

                    if (currentValue is Dictionary<IMaterial, string> complexMaterials)
                    {
                        IMaterial firstMaterial = complexMaterials.Keys.First() as IMaterial;
                        string currentStep = firstMaterial.Step.Name;
                        if (complexMaterials.Keys.All<IMaterial>(s => s.Step.Name == currentStep) is false)
                        {
                            throw new Exception("Different steps were found for materials in same ComplexMoveNext Operation");
                        }

                        return currentStep;
                    }

                    //TrackIn, DispatchMaterial
                    if (currentValue is IMaterial material)
                    {
                        return material.Step.Name;

                    }
                    
                    if (currentValue is IMaterialCollection materialCollection)
                    {
                        return materialCollection.FirstOrDefault()?.Step.Name;
                    }

                    //DispacthMaterials
                    if (currentValue is Dictionary<IMaterial, IDispatchMaterialParameters> materials)
                    {
                        return materials.Keys.FirstOrDefault()?.Step.Name;
                    }
                    if (currentValue is IContainer container)
                    {
                        container.LoadRelations();
                        return container.RelationCollection.FirstOrDefault().Value.FirstOrDefault().TargetEntity.GetPropertyObject<Step>("Step").Name;
                    }
                    if (currentValue is IContainerCollection containerCollection)
                    {
                        containerCollection.LoadRelations();
                        return containerCollection.FirstOrDefault().RelationCollection.FirstOrDefault().Value.FirstOrDefault().TargetEntity.GetPropertyObject<Step>("Step").Name;
                    }

                }    
            }
            return string.Empty;
        }

        public static T GetValueOrDefault<T>(this Dictionary<string, object> input, string name = null) where T : class
        {
            if (input.TryGetValue(typeof(T)?.Name, out var value))
            {
                return value as T;
            }
            if (input.TryGetValue(name ?? string.Empty, out value))
            {
                return value as T;
            }else
            {
               return default;
            }
        }
    }
}
