﻿
using Cmf.Common.CustomActionUtilities;

namespace Cmf.Custom.Lam.Common.Extensions
{
    public static class CustomDeeContextHelper
    {
        public static T GetContextParameter<T>(string key) where T : class 
        {
            return (T)DeeContextHelper.GetContextParameter(key);
        }

        public static void SetContextParameter<T>(string key, T value) where T : class
        {
            DeeContextHelper.SetContextParameter(key,value);
        }
    }
}
