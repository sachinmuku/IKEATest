﻿using Cmf.Foundation.Common.LocalizationService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.Lam.Common.Exceptions
{
    public class LamBusinessException : Exception
    {
        public string Title { get; protected set; }
        
        public LamBusinessException(string message) : base(message)
        {
            Title = "MES Business Exception";
        }        
    }
}
