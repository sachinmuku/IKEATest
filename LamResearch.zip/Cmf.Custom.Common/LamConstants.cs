﻿namespace Cmf.Custom.Lam.Common
{
    /// <summary>
    /// Support class that represents the constants to be used on the business layer
    /// </summary>
    public static class LamConstants
    {
        #region EntityTypes

        public class EntityTypes
        {
            /// <summary>
            /// Product
            /// </summary>
            public const string Product = "Product";

            /// <summary>
            /// Integration Entry
            /// </summary>
            public const string IntegrationEntry = "IntegrationEntry";
        }

        #endregion

        #region Custom Entity Types

        /// <summary>
        /// Custom CustomProjectCode Entity Type
        /// </summary>
        public const string EntityTypeCustomProjectCode = "CustomProjectCode";

        /// <summary>
        /// Custom CustomPoProjectCode Relation Entity between Production Order and CustomProjectCode
        /// </summary>
        public const string EntityTypeCustomPoProjectCode = "CustomPoProjectCode";

        /// <summary>
        /// Custom CustomPoEngineeringOwner Relation Entity between Production Order and Employee
        /// </summary>
        public static string EntityTypeCustomPoEngineeringOwner = "CustomPoEngineeringOwner";

        /// <summary>
        /// Custom CustomProjectCodeProtocolInstance Relation Entity between Project Code and Protocol Instance
        /// </summary>
        public static string EntityTypeCustomProjectCodeProtocolInstance = "CustomProjectCodeProtocolInstance";

        #endregion

        #region Properties

        /// <summary>
        /// CustomProjectCode SubGroup Property
        /// </summary>
        public const string PropertySubGroup = "SubGroup";

        /// <summary>
        /// CustomProjectCode ProjectProtocol Property
        /// </summary>
        public static string PropertyProjectProtocol = "ProjectProtocol";

        /// <summary>
        /// CustomProjectCode ProcessGroup Property
        /// </summary>
        public const string ProcessGroup = "ProcessGroup";

        /// <summary>
        /// CustomProjectCode BusinessUnit Property
        /// </summary>
        public const string BusinessUnit = "BusinessUnit";

        /// <summary>
        /// CustomProjectCode ProductLine Property
        /// </summary>
        public const string ProductLine = "ProductLine";

        /// <summary>
        /// CustomProjectCode Application Property
        /// </summary>
        public const string Application = "Application";

        #endregion

        #region Protocols

        /// <summary>
        /// Protocol of Project type
        /// </summary>
        public static string TypeProjectProtocol = "Project";

        public struct Protocols
        {
            public struct ProtocolInstance
            {
                public struct Parameters
                {
                    public struct ProjectPriority
                    {
                        public static string Name = "ProjectPriority";
                        public static string Standard = "4 - Standard";
                    }
                }
            }
        }

        #endregion

        #region Automation

        /// <summary>
        /// Automation TrackIn Timeout Configuration Path
        /// </summary>
        public static string AutomationTrackInTimeoutConfigurationPath = "/Cmf/Custom/Automation/TrackInTimeout";

        /// <summary>
        /// Integration Inbound Event Name
        /// </summary>
        public static string AutomationGenericRequestTimeoutConfigurationPath = "/Cmf/Custom/Automation/GenericRequestTimeout";

        /// <summary>
        /// Automation Generic Nice Label Print Resource Path
        /// </summary>
        public static string AutomationGenericNiceLabelPrintResourcePath = "/Cmf/Custom/Automation/NiceLabelPrintResource";

        /// <summary>
        /// Automation RequestType TrackIn
        /// </summary>
        public static string AutomationRequestTypeTrackIn = "TrackIn";

        /// <summary>
        /// Automation RequestType TrackIn
        /// </summary>
        public static string AutomationRequestTypeTrackOut = "TrackOut";

        /// <summary>
        /// Automation RequestType Abort
        /// </summary>
        public static string AutomationRequestTypeAbort = "Abort";


        /// <summary>
        /// Automation RequestType Abort
        /// </summary>
        public static string AutomationRequestTypeRequestAbort = "RequestAbort";


        /// <summary>
        /// Automation RequestType SendAdHocRequest
        /// </summary>
        public static string AutomationRequestSendAdHocRequest = "SendAdHocRequest";

        /// <summary>
        /// Adhoc Abort Job
        /// </summary>
        public static string AdhocAbortJob = "AdhocAbortJob";

        // <summary>
        // Automation PublishType Dock
        // </summary>
        public static string AutomationPublishTypeDock = "Dock";

        // <summary>
        // Automation PublishType Dock
        // </summary>
        public static string AutomationPublishTypeStore = "Store";

        // <summary>
        // Automation PublishType Dock
        // </summary>
        public static string AutomationPublishTypeUndispatch = "Undispatch";

        // <summary>
        // Smart Table Custom Automation Job Id Logic
        // </summary>
        public static string CustomSmartTableCustomAutomationJobIdLogic = "CustomAutomationJobIdLogic";

        // <summary>
        // Smart Table Custom Automation Job Id Logic
        // </summary>
        public static string CustomSmartTableCustomAutomationJobIdLogicProcessJobIdColumn = "ProcessJobId";

        // <summary>
        // Smart Table Custom Automation Job Id Logic
        // </summary>
        public static string CustomSmartTableCustomAutomationJobIdLogicControlJobIdColumn = "ControlJobId";

        // <summary>
        // Custom Error Handling Smart Table
        // </summary>
        public static string CustomErrorHandlingSmartTable = "CustomErrorHandling";

        // <summary>
        // Smart Table Custom Error Handling Column Custom Notification
        // </summary>
        public static string CustomErrorHandlingSmartTableNotification = "Notification";

        // <summary>
        // Smart Table Custom Error Handling Column Custom Notification
        // </summary>
        public static string CustomErrorHandlingSmartTableProtocol = "Protocol";

        // <summary>
        // Custom Alarm Management Smart Table
        // </summary>
        public static string CustomAlarmManagementSmartTable = "CustomAlarmManagement";

        // <summary>
        // Smart Table Custom Alarm Management Column Custom Store Data Collection
        // </summary>
        public static string CustomAlarmManagmentTableStoreDataCollection = "StoreDataCollection";

        // <summary>
        // Smart Table Custom Alarm Management Column Custom Error Type
        // </summary>
        public static string CustomAlarmManagementSmartTableErrorType = "ErrorType";

        // <summary>
        // Smart Table Custom Alarm Management Column Custom Include Materials In Process
        // </summary>
        public static string CustomAlarmManagementSmartTableIncludeMaterialsInProcess = "IncludeMaterialsInProcess";

        // <summary>
        // Smart Table Custom Alarm Management Column Custom Context
        // </summary>
        public static string CustomAlarmManagementSmartTableContext = "Context";
        #endregion

        #region Defaults

        /// <summary>
        /// Default operation for incoming lot creation
        /// </summary>
        public const string CustomIncomingLotCreationOperation = "Certificate";

        #endregion

        #region Attributes

        /// <summary>
        /// Container Attribute Lot
        /// </summary>
        public static string ContainerAttributeLot = "Lot";

        /// <summary>
        /// Material Attribute Current ControlJobID
        /// </summary>
        public static string CurrentControlJobID = "CurrentControlJobID";
        /// <summary>
        /// Material Attribute Current ProcessJobID
        /// </summary>
        public static string CurrentProcessJobID = "CurrentProcessJobID";

        public static string ContainerAttributeLastSeenLocation = "LastSeenLocation";

        /// <summary>
        /// Resource Is Sorter
        /// </summary>
        public static string ResourceAttributeIsSorter = "IsSorter";

        /// <summary>
        /// Resource Is Load Port In Use
        /// </summary>
        public static string ResourceAttributeIsLoadPortInUse = "IsLoadPortInUse";

        /// <summary>
        /// Resource Allow Download Recipe At TrackIn
        /// </summary>
        public static string ResourceAttributeAllowDownloadRecipeAtTrackIn = "AllowDownloadRecipeAtTrackIn";

        /// <summary>
        /// Container Attribute Map Container Needed for sorter
        /// </summary>
        public static string ContainerAttributeMapContainerNeeded = "MapContainerNeeded";

        /// <summary>
        /// Container Attribute Product
        /// </summary>
        public static string ContainerAttributeProduct = "Product";

        /// <summary>
        /// Product Attribute IsTestWaferMeasurementStep
        /// </summary>
        public static string ProductAttributeCanCreateInventory = "CanCreateInventory";

        /// <summary>
        /// Step Attribute IsLotStart
        /// </summary>
        public static string StepAttributeIsLotStart = "IsLotStart";

        /// <summary>
        /// Data Collection Attribute Data Collection Plan
        /// </summary>
        public static string DataCollectionAttributeDataCollectionPlan = "DataCollectionPlan";

        /// <summary>
        /// Recipe Attribute Recipe Body Validation Behavior
        /// </summary>
        public static string RecipeAttributeRecipeBodyValidationBehavior = "RecipeBodyValidationBehavior";

        /// <summary>
        /// Recipe Attribute Recipe Body Validation Behavior
        /// </summary>
        public static string ContainerAttributeCassetteNotPresent = "CassetteNotPresent";

        /// <summary>
        /// MAterial Attribute for custom assmeble
        /// </summary>
        public const string MaterialAttachmentBOMQuantityMode = "AttachmentBOMQuantityMode";

        /// <summary>
        /// MAterial Attribute for custom assmeble
        /// </summary>
        public const string MaterialAttachmentBOMCurrent = "AttachmentBOMCurrent";

        /// <summary>
        /// MAterial Attribute for custom assmeble
        /// </summary>
        public const string MaterialAttachmentBOMIsComplete = "AttachmentBOMIsComplete";

        #endregion

        #region GenericTables

        /// <summary>
        /// Custom Reclaim Container Type table name
        /// </summary>
        public static string GenericTableCustomReclaimContainerType = "CustomReclaimContainerType";

        /// <summary>
        /// Custom External System EndPoint table name
        /// </summary>
        public static string GenericTableCustomExternalSysEndPointProperty = "EndPoint";

        /// <summary>
        /// Custom External System EndPoint table name
        /// </summary>
        public static string GenericTableCustomExternalSysHttpVerbProperty = "HttpVerb";

        /// <summary>
        /// Custom Reclaim Container Type table SourceContainerType Property 
        /// </summary>
        public static string GenericTableCustomReclaimContainerTypeSourceContainerTypeProperty = "SourceContainerType";

        /// <summary>
        /// CustomReclaimContainerType table ReclaimContainerType Property 
        /// </summary>
        public static string GenericTableCustomReclaimContainerTypeReclaimContainerTypeProperty = "ReclaimContainerType";

        /// <summary>
        /// Custom Map Type Config table name
        /// </summary>
        public static string GenericTableCustomMapTypeConfig = "CustomMapTypeConfig";

        /// <summary>
        /// Custom Map Type Config table MapType Property
        /// </summary>
        public static string GenericTableCustomMapTypeConfigMapTypeProperty = "MapType";

        /// <summary>
        /// Custom Map Type Config table Units Property
        /// </summary>
        public static string GenericTableCustomMapConfigTypeUnitsProperty = "Units";

        /// <summary>
        /// Custom Map Type Config table Quantity Property
        /// </summary>
        public static string GenericTableCustomMapTypeConfigQuantityProperty = "QuantityPerCell";

        /// <summary>
        /// Custom Map Type Config table SubMaterialForm Property
        /// </summary>
        public static string GenericTableCustomMapTypeConfigSubMaterialFormProperty = "SubMaterialForm";

        /// <summary>
        /// Generic Table name
        /// </summary>
        public static string GenericTableGeneric = "Generic";

        /// <summary>
        /// Generic Table to manage the Relation for Group, BusinessUnit and SubGroup
        /// </summary>
        public static string CustomGroupDependencies = "CustomGroupDependencies";
        #endregion

        #region LookupTables

        /// <summary>
        /// Custom Sorter Logistical Process
        /// </summary>
        public static string LookupTableCustomSorterLogisticalProcess = "CustomSorterLogisticalProcess";

        /// <summary>
        /// Custom Sorter Logistical Process for MapCarrier
        /// </summary>
        public static string LookupTableCustomSorterLogisticalProcessMapCarrier = "MapCarrier";

        /// <summary>
        /// Custom Sorter Logistical Process for TransferWafers
        /// </summary>
        public static string LookupTableCustomSorterLogisticalProcessTransferWafers = "TransferWafers";

        /// <summary>
        /// Custom Sorter Logistical Process for Compose
        /// </summary>
        public static string LookupTableCustomSorterLogisticalProcessCompose = "Compose";
        public static string LookupTableCustomSorterAdhocProcessValueAbort = "Abort";

        /// <summary>
        /// Possible types for Container
        /// </summary>
        public static string LookupTableContainerType = "ContainerType";

        /// <summary>
        /// Material Form Lot
        /// </summary>
        public static string MaterialFormLot = "Lot";

        /// <summary>
        /// SubGroup
        /// </summary>
        public static string LookupTableCustomSubGroup = "CustomSubGroup";

        /// <summary>
        /// Production Order Type
        /// </summary>
        public static string LookupTableProductionOrderType = "ProductionOrderType";

        /// <summary>
        /// Fab
        /// </summary>
        public static string LookupTableCustomFab = "CustomFab";

        /// <summary>
        /// Units
        /// </summary>
        public static string LookupTableUnits = "Units";

        /// <summary>
        /// Name of CustomProjectPriority Lookuptable
        /// </summary>
        public const string CustomProjectPriorityLookupTableName = "CustomProjectPriority";

        #endregion

        #region SmartTables

        #region CustomSorterJobDefinitionContext

        /// <summary>
        /// SmartTable CustomSorterJobDefinitionContext Name
        /// </summary>
        public static string CustomSorterJobDefinitionContextName = "CustomSorterJobDefinitionContext";

        /// <summary>
        /// SmartTable Step Property
        /// </summary>
        public static string CustomSorterJobDefinitionContextColumnStep = "Step";

        /// <summary>
        /// SmartTable Product Property
        /// </summary>
        public static string CustomSorterJobDefinitionContextColumnProduct = "Product";

        /// <summary>
        /// SmartTable ProductGroup Property
        /// </summary>
        public static string CustomSorterJobDefinitionContextColumnProductGroup = "ProductGroup";

        /// <summary>
        /// SmartTable Flow Property
        /// </summary>
        public static string CustomSorterJobDefinitionContextColumnFlow = "Flow";

        /// <summary>
        /// SmartTable Material Property
        /// </summary>
        public static string CustomSorterJobDefinitionContextColumnMaterial = "Material";

        /// <summary>
        /// SmartTable MaterialType Property
        /// </summary>
        public static string CustomSorterJobDefinitionContextColumnMaterialType = "MaterialType";

        /// <summary>
        /// SmartTable MaterialType Property
        /// </summary>
        public static string CustomSorterJobDefinitionContextColumnCustomSorterJobDefinition = "CustomSorterJobDefinition";

        #endregion

        /// <summary>
        /// smartTable NotificationTitleMessage Property
        /// </summary>
        public static string smartTablePropertyNotificationTitleMessage = "NotificationTitleMessage";

        /// <summary>
        /// smartTable NotificationTitleMessageWarning Property
        /// </summary>
        public static string smartTablePropertyNotificationTitleMessageWarning = "NotificationTitleMessageWarning";

        /// <summary>
        /// smartTable NotificationTitleMessageCritical Property
        /// </summary>
        public static string smartTablePropertyNotificationTitleMessageCritical = "NotificationTitleMessageCritical";
        /// <summary>
        /// smartTable NotificationBodyMessage Property
        /// </summary>
        public static string smartTablePropertyNotificationBodyMessage = "NotificationBodyMessage";

        /// <summary>
        /// SmartTable CustomConfigResourceNotification Action Value Notification
        /// </summary>
        public static string smartTableResultActionNotification = "Notification";

        /// <summary>
        /// SmartTable CustomConfigResourceNotification Action Value Email
        /// </summary>
        public static string smartTableResultActionEmail = "Email";
        /// <summary>
        /// smartTable ToState Property
        /// </summary>
        public static string smartTablePropertyToState = "ToState";

        /// <summary>
        /// smartTable NotificationAction Property
        /// </summary>
        public static string smartTablePropertyNotificationAction = "NotificationAction";

        /// <summary>
        /// smartTable TargetRole Property
        /// </summary>
        public static string smartTablePropertyTargetRole = "TargetRole";

        /// <summary>
        /// smartTable TargetDistributionList Property
        /// </summary>
        public static string smartTablePropertyTargetDistributionList = "TargetDistributionList";

        /// <summary>
        /// smartTable StateName Property
        /// </summary>
        public static string smartTablePropertyStateName = "StateName";

        /// <summary>
        /// smartTable NotificationTrigger Property
        /// </summary>
        public static string smartTablePropertyNotificationTrigger = "NotificationTrigger";

        /// <summary>
        /// SmartTable CustomConfigResourceNotification Name
        /// </summary>
        public static string CustomResourceNotificationSTName = "CustomResourceActionNotifications";

        /// <summary>
        /// smartTable FromState Property
        /// </summary>
        public static string smartTablePropertyFromState = "FromState";

        /// <summary>
        /// smartTable IsEnable Property
        /// </summary>
        public static string smartTablePropertyIsEnable = "IsEnable";

        /// <summary>
        /// SmartTable Severity Property
        /// </summary>
        public static string smartTablePropertySeverity = "Severity";

        /// <summary>
        /// smartTable NotificationType Property
        /// </summary>
        public static string smartTablePropertyNotificationType = "NotificationType";

        /// <summary>
        /// smartTable CustomGrantNonAdministratorAccessToManageAssignments
        /// </summary>
        public static string smartTableCustomGrantNonAdministratorAccessToManageAssignments = "CustomGrantNonAdministratorAccessToManageAssignments";

        #region CustomProtocolParameterValidation

        /// <summary>
        /// Smart Table CustomProtocolParameterValidation Name
        /// </summary>
        public static string smartTableProtocolParameterValidationName = "CustomProtocolParameterValidation";

        /// <summary>
        /// Smart Table ParameterName Property
        /// </summary>
        public static string smartTablePropertyParameterName = "ParameterName";

        /// <summary>
        /// Smart Table ValidationExpression Property
        /// </summary>
        public static string smartTablePropertyValidationExpression = "ValidationExpression";

        /// <summary>
        /// Smart Table ValidationErrorMessage Property
        /// </summary>
        public static string smartTablePropertyValidationErrorMessage = "ValidationErrorMessage";

        #endregion

        public struct SmartTables
        {
            public struct CustomProtocolSpecificNotifications
            {
                public const string TableName = "CustomProtocolSpecificNotif";
                public const string Protocol = "Protocol";
                public const string FromState = "FromState";
                public const string ToState = "ToState";
                public const string IsMainRecipient = "IsMainRecipient";
                public const string RecipientSource = "RecipientSource";
                public const string SourceName = "SourceName";
                public const string NotificationTemplate = "NotificationTemplate";
            }

            public struct ProjectMaxDuration
            {
                /// <summary>
                /// Smart Table CustomProjectMaxDuration Name
                /// </summary>
                public const string TableName = "CustomProjectMaxDuration";

                /// <summary>
                /// SmartTable ProjectType Property
                /// </summary>
                public const string ProjectType = "ProjectType";

                /// <summary>
                /// SmartTable Project Property
                /// </summary>
                public const string Project = "Project";

                /// <summary>
                /// SmartTable ProjectMaxYears Property
                /// </summary>
                public const string ProjectMaxYears = "ProjectMaxYears";

                public const string ProjectIdleMonths = "ProjectIdleMonths";
            }

            public struct CustomProtocolStateActions
            {
                public const string TableName = "CustomProtocolStateActions";
                public const string Protocol = "Protocol";
                public const string FromState = "FromState";
                public const string ToState = "ToState";
                public const string DEEAction = "DEEAction";

            }
        }


        #endregion

        #region JSON Schemas

        /// <summary>
        /// JSON Schema for Custom Sorter Job Definition for Map Carrier Logistical Process
        /// </summary>
        public static string CustomSorterJobDefinitionMapCarrierSchema =
            @"{
                'description': 'JSON Schema for Custom Sorter Job Definition for Map Carrier Logistical Process.',
                'properties': {
                    'FutureActionType': {
                        'type': 'string',
                        'required': true
                    },
                    'Moves': {
                        'type': 'array',
                        'items': {
				            'type': 'object',
				            'properties': {
					            'MaterialName': {
						            'type': 'string'
					            },
					            'SourceContainer': {
						            'type': 'string'
					            },
					            'SourcePosition': {
						            'type': 'integer'
					            },
					            'DestinationContainer': {
						            'type': 'string'
					            },
					            'DestinationPosition': {
						            'type': 'integer'
					            }
				            }              
                        },
                        'required': true
                    },
                    'DeleteOnCompletion': {
                        'type': 'boolean'
                    }
                }
            }";

        /// <summary>
        /// JSON Schema for Custom Sorter Job Definition for Map Carrier Logistical Process
        /// </summary>
        public static string CustomSorterJobDefinitionTransferWafersSchema =
            @"{
                'description': 'JSON Schema for Custom Sorter Job Definition for Transfer Wafers Logistical Process.',
                'properties': {
                    'FutureActionType': {
                        'type': 'string',
                        'required': true
                    },
                    'Moves': {
                        'type': 'array',
                        'items': {
				            'type': 'object',
				            'properties': {
					            'MaterialName': {
						            'type': 'string',
                                    'required': true
					            },
					            'SourceContainer': {
						            'type': 'string',
                                    'required': true
					            },
					            'SourcePosition': {
						            'type': 'integer',
                                    'required': true
					            },
					            'DestinationContainer': {
						            'type': 'string',
                                    'required': true
					            },
					            'DestinationPosition': {
						            'type': 'integer',
                                    'required': true
					            }
				            }              
                        },
                        'required': true,
                        'minItems': 0
                    },
                    'DeleteOnCompletion': {
                        'type': 'boolean'
                    }
                }
            }";

        /// <summary>
        /// JSON Schema for Custom Sorter Job Definition for Map Carrier Logistical Process
        /// </summary>
        public static string CustomSorterJobDefinitionComposeSchema =
            @"{
                'description': 'JSON Schema for Custom Sorter Job Definition for Compose Logistical Process.',
                'properties': {
                    'FutureActionType': {
                        'type': 'string',
                        'required': true
                    },
                    'Moves': {
                        'type': 'array',
                        'items': {
				            'type': 'object',
				            'properties': {
                                'Product': {
                                    'type': 'string',
                                    'required': true
                                },
                                'Substitutes': {
                                    'type': 'array',
                                    'items': {
				                        'type': 'object',
				                        'properties': {
                                            'Substitute': {
                                                'type': 'string',
                                                'required': true
                                            },
                                            'Priority': {
                                                'type': 'integer',
                                                'required': true
                                            },
                                        }
                                    },
                                    'required': true
                                },
					            'MaterialName': {
						            'type': 'string'
					            },
					            'SourceContainer': {
						            'type': 'string'
					            },
					            'SourcePosition': {
						            'type': 'integer'
					            },
					            'DestinationContainer': {
						            'type': 'string'
					            },
					            'DestinationPosition': {
						            'type': 'integer'
					            }
				            }              
                        },
                        'required': true,
                        'minItems': 1,
                    },
                    'DeleteOnCompletion': {
                        'type': 'boolean'
                    }
                }
            }";

        #endregion

        #region Localized Messages

        public struct LocalizedExceptions
        {
            /// <summary>
            /// Recipient with value {SourceName} of type {SourceType} cannot be found 
            /// on performing protocol instance {ProtocolInstanceName} state transition from {FromStateName} to {ToStateName}
            /// </summary>
            public const string MissingMainRecipient = "MissingMainRecipient";

            /// <summary>
            /// The material {MaterialName} has quantity {MaterialQuantity} bigger then the quantity {BomQuantity} required by the Bom {BomName}
            /// </summary>
            public const string MaterialQuantityBiggerThenBomQuantity = "MaterialQuantityBiggerThenBomQuantity";

            /// <summary>
            /// When Priority End Date is less than the current Date Time
            /// </summary>
            public const string UpgradeProjectPriorityEndDate = "CustomUpgradeProjectPriorityEndDate";

            /// <summary>
            /// When Priority Start Date is greater than the current Date Time
            /// </summary>
            public const string DowngradeProjectPriorityStartDate = "CustomDowngradeProjectPriorityStartDate";
            
            /// <summary>
            /// When Priority Start Date is greater than the current Date Time
            /// </summary>
            public const string UpdateProjectPriorityStateModelNotFound = "CustomUpdateProjectPriorityStateModelNotFound";
        }

        /// <summary>
        /// Received message is empty
        /// </summary>
        public const string CustomReceiveEmptyMessage = "CustomReceiveEmptyMessage";

        /// <summary>
        /// Localized Message: ConfigNotFound (config name)
        /// </summary>
        public static string LocalizedMessageConfigNotFound = "CustomLocalizedMessageConfigNotFound";

        /// <summary>
        /// Localized Message: CustomLocalizedMessageCustomSorterJobDefinitionInvalidMovementList
        /// </summary>
        public static string LocalizedMessageCustomSorterJobDefinitionInvalidMovementList = "CustomLocalizedMessageCustomSorterJobDefinitionInvalidMovementList";

        /// <summary>
        /// Localized Message: IoT Connection Timeout
        /// </summary>
        public static string LocalizedMessageIoTConnectionTimeout = "CustomLocalizedMessageIoTConnectionTimeout";

        /// <summary>
        /// Localized Message: CustomLocalizedMessageNoHoldReasonsAvailableErrorMessage
        /// </summary>
        public static string LocalizedMessageNoHoldReasonAvailableErrorMessage = "CustomLocalizedMessageNoHoldReasonAvailableErrorMessage";

        /// <summary> 
        /// Localized Message: Custom Localized Message Recipe Body Empty
        /// </summary>
        public static string LocalizedMessageRecipeBodyEmpty = "CustomLocalizedMessageRecipeBodyEmpty";

        /// <summary> 
        /// Localized Message: Custom Localized Message Recipe Without Body
        /// </summary>
        public static string LocalizedMessageRecipeWithoutBody = "CustomLocalizedMessageRecipeWithoutBody";

        /// <summary>
        /// Localized Message: StateModelStateDoesNotExistException
        /// </summary>
        public static string LocalizedMessageStateModelStateDoesNotExistException = "StateModelStateDoesNotExistException";

        /// <summary>
        /// Localized Message: StateModelDoesNotExistException
        /// </summary>
        public static string LocalizedMessageStateModelDoesNotExistException = "StateModelDoesNotExistException";

        /// <summary>
        /// Localized Message: CustomUpdateMaterialOnDifferentFlowStep
        /// </summary>
        public static string LocalizedMessageCustomUpdateMaterialOnDifferentFlowStep = "CustomUpdateMaterialOnDifferentFlowStep";

        /// <summary>
        /// Localized Message: CustomUpdateMaterialDifferentWaferData
        /// </summary>
        public static string LocalizedMessageCustomUpdateMaterialDifferentWaferData = "CustomUpdateMaterialDifferentWaferData";

        /// <summary>
        /// Localized Message: CustomWrongCertificateConfiguration
        /// </summary>
        public static string LocalizedMessageCustomWrongCertificateConfiguration = "CustomWrongCertificateConfiguration";

        /// <summary>
        /// Localized Message: CustomUpdateMaterialDifferentProduct
        /// </summary>
        public static string LocalizedMessageCustomUpdateMaterialDifferentProduct = "CustomUpdateMaterialDifferentProduct";

        /// <summary>
        /// Localized Message: CustomUpdateMaterialDifferentFlow
        /// </summary>
        public static string LocalizedMessageCustomUpdateMaterialDifferentFlow = "CustomUpdateMaterialDifferentFlow";

        /// <summary>
        /// Localized Message: CustomUpdateMaterialDifferentStep
        /// </summary>
        public static string LocalizedMessageCustomUpdateMaterialDifferentStep = "CustomUpdateMaterialDifferentStep";

        /// <summary>
        /// Localized Message: CustomUpdateMaterialDifferentType
        /// </summary>
        public static string LocalizedMessageCustomUpdateMaterialDifferentType = "CustomUpdateMaterialDifferentType";

        /// <summary>
        /// Localized Message: CustomUpdateMaterialDifferentWafers
        /// </summary>
        public static string LocalizedMessageCustomUpdateMaterialDifferentWafers = "CustomUpdateMaterialDifferentWafers";

        /// <summary>
        /// Localized Message: CustomUpdateMaterialProductWaferSizeMissing
        /// </summary>
        public static string LocalizedMessageCustomUpdateMaterialProductWaferSizeMissing = "CustomUpdateMaterialProductWaferSizeMissing";

        /// <summary>
        /// Localized Message: CustomParameterProjectProtocolSubGroupWrongValue
        /// </summary>
        public static string LocalizedMessageCustomParameterLookupTableProjectProtocolWrongValue =
            "CustomParameterLookupTableProjectProtocolWrongValue";

        /// <summary>
        /// Localized Message: CustomObjectWasCreated
        /// </summary>
        public static string LocalizedMessageObjectWasCreated = "CustomObjectWasCreated";

        /// <summary>
        /// Localized Message: CustomProjectCodeChangeSetDescription
        /// </summary>
        public static string LocalizedMessageCustomProjectCodeChangeSetDescription =
            "CustomProjectCodeChangeSetDescription";

        /// <summary>
        /// Localized Message: CustomProjectCodeObjectNotSet
        /// </summary>
        public static string LocalizedMessageCustomProjectCodeObjectNotSet =
            "CustomProjectCodeObjectNotSet";

        /// <summary>
        /// Localized Message: CustomProjectCodeFlowFirstStepNotSet
        /// </summary>
        public static string LocalizedMessageCustomProjectCodeFlowFirstStepNotSet =
            "CustomProjectCodeFlowFirstStepNotSet";

        /// <summary>
        /// Localized Message: CustomParameterProjectCodeNotFound
        /// </summary>
        public static string LocalizedMessageCustomParameterProjectCodeNotFound =
            "CustomParameterProjectCodeNotFound";

        /// <summary>
        /// Localized Message: Cmf.Custom.Lam.BusinessObjects.CustomProjectCode
        /// </summary>
        public static string LocalizedMessageCustomProjectCode =
            "Cmf.Custom.Lam.BusinessObjects.CustomProjectCode";

        /// <summary>
        /// Localized Message: CustomProjectCodeProtocolInstanceRelationNotFound
        /// </summary>
        public const string LMCustomProjectCodeProtocolInstanceRelationNotFound = "CustomProjectCodeProtocolInstanceRelationNotFound";

        /// <summary>
        /// /// Localized Message: StateModelTransitionDoesNotExistException
        /// </summary>
        public static string LocalizedMessageStateModelTransitionDoesNotExistException = "StateModelTransitionDoesNotExistException";

        /// <summary>
        /// Localized Message: CustomLocalizedMessageContainerShipmentNumberAndShipmentDateRequired
        /// </summary>
        public static string LocalizedMessageWaferMaterialContainerNotDockedOnCurrentResource = "CustomLocalizedMessageWaferMaterialContainerNotDockedOnCurrentResource";

        /// <summary>
        /// Localized Message: CustomProtocolInstanceCreatedSuccessfully
        /// </summary>
        public static string LocalizedMessageProtocolInstanceCreatedSuccessfully = "CustomProtocolInstanceCreatedSuccessfully";

        /// <summary>
        /// Localized Message: CustomTableNoData
        /// </summary>
        public static string LocalizedMessageTableNoData = "CustomTableNoData";

        /// <summary>
        /// Localized Message: CustomTableColumnNotDefined
        /// </summary>
        public static string LocalizedMessageTableColumnNotDefined = "CustomTableColumnNotDefined";

        /// <summary>
        /// Localized Message: CustomLotUnitsNotMatchGenericTable
        /// </summary>
        public static string LocalizedMessageLotUnitsNotMatchGenericTable = "CustomLotUnitsNotMatchGenericTable";

        /// <summary>
        /// Localized Message: CustomLotTotalNumberSubMaterialsExpanded
        /// </summary>
        public static string LocalizedMessageLotTotalNumberSubMaterialsExpanded = "CustomLotTotalNumberSubMaterialsExpanded";

        /// <summary>
        /// Create Project Code request failed with {0} body and error message : {1}
        /// </summary>
        public const string LocalizedMessageTagVueCreateProjectCodeException = "TagVueCreateProjectCodeException";

        /// <summary>
        /// Delete Project Code request failed with {0} body and error message : {1}
        /// </summary>
        public const string LocalizedMessageTagVueDeleteProjectCodeException = "TagVueDeleteProjectCodeException";

        /// <summary>
        /// When the Validation Expression fails on Protocol Parameters
        /// </summary>
        public const string LocalizedMessageProtocolParameterFailedValidationExpression = "ProtocolParameterFailedValidationExpression";

        /// <summary>
        /// When Project Protocol's Production Order has Active Materials
        /// </summary>
        public const string LocalizedMessageActiveMaterialsOnProjectProtocolProductionOrder = "ActiveMaterialsOnProjectProtocolProductionOrder";

        /// <summary>
        /// When End Date Protocol Parameter exceeds Project Code maximum duration
        /// </summary>
        public const string LocalizedMessageEndDateProtocolParameterExceedsMaxDuration = "EndDateProtocolParameterExceedsMaxDuration";

        #endregion

        #region State Model

        /// <summary>
        /// Custom Material State Model
        /// </summary>
        public static string MaterialStateModel = "CustomMaterialStateModel";

        /// <summary>
        /// Custom Load Port State Model
        /// </summary>
        public static string CustomLoadPortStateModel = "CustomLoadPortStateModel";

        /// <summary>
        /// CustomLoadPortStateModelState Created State Model State
        /// </summary>
        public static string CustomLoadPortStateModelStateReadyToLoadStateModelState = "ReadyToLoad";

        /// <summary>
        /// CustomLoadPortStateModelState TransportReserved State Model State
        /// </summary>
        public static string CustomLoadPortStateModelStateReservedStateModelState = "Reserved";

        /// <summary>
        /// CustomLoadPortStateModelState In Progress State Model State
        /// </summary>
        public static string CustomLoadPortStateModelStateTransferBlockedStateModelState = "TransferBlocked";

        /// <summary>
        /// CustomLoadPortStateModelState Delivered State Model State
        /// </summary>
        public static string CustomLoadPortStateModelStateReadyToUnloadStateModelState = "ReadyToUnload";

        /// <summary>
        /// Custom Material State Model State - Setup
        /// </summary>
        public static string MaterialStateModelStateSetup = "Setup";

        #endregion

        #region Configuration

        /// <summary>
        /// Hold Step reason when an abort process is performed at the lot
        /// </summary>
        public static string DefaultAbortProcessHoldReasonConfig = "/Lam/AbortProcess/HoldReason/";

        /// <summary>
        /// Hold Step reason for lot incoming 
        /// </summary>
        public static string DefaultLotIncomingHoldReasonConfig = "/Cmf/Guis/Configuration/Material/IncomingLotAutoHoldReason";

        /// <summary>
        /// Project Protocol SubGroup parameter
        /// </summary>
        public static string ParameterProjectProtocolSubGroupConfig = "/LamResearch/Business/ProjectCreation/ProtocolParameterNames/SubGroup/";
        #region Project Protocol Parameters

        /// <summary>
        /// Project Protocol Application parameter
        /// </summary>
        public static string ParameterProjectProtocolProjectCodeConfig = "/LamResearch/Business/ProjectCreation/ProtocolParameterNames/ProjectCode/";

        /// <summary>
        /// Project Protocol ProductLine parameter
        /// </summary>
        public static string ParameterProjectProtocolProductLineConfig = "/LamResearch/Business/ProjectCreation/ProtocolParameterNames/ProductLine/";

        public static string ParameterProjectProtocolApplicationConfig = "/LamResearch/Business/ProjectCreation/ProtocolParameterNames/Application";

        /// <summary>
        /// Project Protocol Business Partner parameter
        /// </summary>
        public static string ParameterProjectProtocolBusinessPartnerConfig = "/LamResearch/Business/ProjectCreation/ProtocolParameterNames/BusinessPartner/";

        /// <summary>
        /// Project Protocol BusinessUnit parameter
        /// </summary>
        public static string ParameterProjectProtocolFabConfig = "/LamResearch/Business/ProjectCreation/ProtocolParameterNames/Fab/";

        public static string ParameterProjectProtocolBusinessUnitConfig = "/LamResearch/Business/ProjectCreation/ProtocolParameterNames/BusinessUnit/";

        /// <summary>
        /// Project Protocol Customer parameter
        /// </summary>
        public static string ParameterProjectProtocolCustomerConfig = "/LamResearch/Business/ProjectCreation/ProtocolParameterNames/Customer/";

        /// <summary>
        /// Project Protocol Customer parameter
        /// </summary>
        public static string ParameterProjectProtocolProductionOrderUnitsConfig = "/LamResearch/Business/ProjectCreation/ProtocolParameterNames/DefaultProjectProductionOrderUnits/";

        /// <summary>
        /// Project Protocol Demo Date parameter
        /// </summary>
        public static string ParameterProjectProtocolDemoDateConfig = "/LamResearch/Business/ProjectCreation/ProtocolParameterNames/DemoDate/";

        /// <summary>
        /// Project Protocol Order Number parameter
        /// </summary>
        public static string ParameterProjectProtocolOrderNumberConfig = "/LamResearch/Business/ProjectCreation/ProtocolParameterNames/OrderNumber/";

        /// <summary>
        /// Project Protocol Production Order Type parameter
        /// </summary>
        public static string ParameterProjectProtocolProductionOrderTypeConfig = "/LamResearch/Business/ProjectCreation/ProtocolParameterNames/ProductionOrderType/";

        /// <summary>
        /// Project Protocol Project Start Date parameter
        /// </summary>
        public static string ParameterProjectProtocolProjectStartDateConfig = "/LamResearch/Business/ProjectCreation/ProtocolParameterNames/ProjectStartDate/";

        /// <summary>
        /// Project Protocol Project End Date parameter
        /// </summary>
        public static string ParameterProjectProtocolProjectEndDateConfig = "/LamResearch/Business/ProjectCreation/ProtocolParameterNames/ProjectEndDate/";

        /// <summary>
        /// Project Protocol Project End Date parameter
        /// </summary>
        public static string ParameterProjectProtocolProjectTypeConfig = "/LamResearch/Business/ProjectCreation/ProtocolParameterNames/ProjectType/";

        /// <summary>
        /// Project Protocol Quantity parameter
        /// </summary>
        public static string ParameterProjectProtocolQuantityConfig = "/LamResearch/Business/ProjectCreation/ProtocolParameterNames/Quantity/";

        /// <summary>
        /// Project Protocol Units parameter
        /// </summary>
        public static string ParameterProjectProtocolUnitsConfig = "/LamResearch/Business/ProjectCreation/ProtocolParameterNames/Units/";

        /// <summary>
        /// Project Protocol Flow type
        /// </summary>
        public static string ParameterProjectProtocolFlowTypeConfig = "/LamResearch/Business/ProjectCreation/ProtocolParameterNames/DefaultProjectFlowType/";

        /// <summary>
        /// Project Protocol Product type
        /// </summary>
        public static string ParameterProjectProtocolProductTypeConfig = "/LamResearch/Business/ProjectCreation/ProtocolParameterNames/DefaultProjectProductType/";


        /// <summary>
        /// Project Protocol Engineer parameter
        /// </summary>
        public static string ParameterProjectProtocolEngineerConfig = "/LamResearch/Business/ProjectCreation/ProtocolParameterNames/Engineer/";

        /// <summary>
        /// Project Protocol IONumber parameter
        /// </summary>
        public static string ParameterProjectProtocolIONumberConfig = "/LamResearch/Business/ProjectCreation/ProtocolParameterNames/IONumber/";

        /// <summary>
        /// Project Protocol ProductGroup parameter
        /// </summary>
        public static string ParameterProjectProtocolProductGroupConfig = "/LamResearch/Business/ProjectCreation/ProtocolParameterNames/ProductGroup/";

        /// <summary>
        /// Project Protocol Project Priority parameter
        /// </summary>
        public static string ParameterProjectProtocolProjectPriorityConfig = "/LamResearch/Business/ProjectCreation/ProtocolParameterNames/ProjectPriority/";

        /// <summary>
        /// Project Protocol Project Title parameter
        /// </summary>
        public static string ParameterProjectProtocolProjectTitleConfig = "/LamResearch/Business/ProjectCreation/ProtocolParameterNames/ProjectTitle/";

        /// <summary>
        /// Project Protocol Quantity parameter
        /// </summary>
        public static string ParameterProjectProtocolProjectRegionConfig = "/LamResearch/Business/ProjectCreation/ProtocolParameterNames/Region/";

        #endregion

        /// <summary>
        /// Recipe Types to Enforce Content Validation
        /// </summary>
        public static string RecipeTypesToEnforceContentValidationConfig = "/LamResearch/Business/Recipe/RecipeTypesToEnforceContentValidation";

        /// <summary>
        /// Configuration of Expand Sub-Materials Cleaving Step Type
        /// </summary>
        public static string ConfigExpandSubMaterialsCleavingStepType = "/LamResearch/Business/ExpandSubMaterialsCleaving/Step/StepType";

        /// <summary>
        /// Configuration of Expand Sub-Materials Cleaving Map Layer Material ID
        /// </summary>
        public static string ConfigExpandSubMaterialsCleavingMapLayerMaterialId = "/LamResearch/Business/ExpandSubMaterialsCleaving/Map/LayerMaterialId";

        /// <summary>
        /// Configuration of Expand Sub-Materials Cleaving Map Layer Cleaving Status
        /// </summary>
        public static string ConfigExpandSubMaterialsCleavingMapLayerCleavingStatus = "/LamResearch/Business/ExpandSubMaterialsCleaving/Map/LayerCleavingStatus";

        /// <summary>
        /// Configuration of Expand Sub-Materials Cleaving Map Layer Cleaving Status
        /// </summary>
        public static string ConfigExpandSubMaterialsCleavingMapLayerQuantity = "/LamResearch/Business/ExpandSubMaterialsCleaving/Map/LayerQuantity";

        /// <summary>
        /// Configuration of Expand Sub-Materials Cleaving Map Layer Cleaving Status Value None
        /// </summary>
        public static string ConfigExpandSubMaterialsCleavingMapLayerCleavingStatusNone = "/LamResearch/Business/ExpandSubMaterialsCleaving/Map/LayerCleavingStatus/None";

        /// <summary>
        /// Configuration of Expand Sub-Materials Cleaving Map Layer Cleaving Status Value Cleaved
        /// </summary>
        public static string ConfigExpandSubMaterialsCleavingMapLayerCleavingStatusCleaved = "/LamResearch/Business/ExpandSubMaterialsCleaving/Map/LayerCleavingStatus/Cleaved";

        /// <summary>
        /// Configuration of Expand Sub-Materials Cleaving Map Layer Cleaving Status Value Cleaved and Split
        /// </summary>
        public static string ConfigExpandSubMaterialsCleavingMapLayerCleavingStatusCleavedAndSplit = "/LamResearch/Business/ExpandSubMaterialsCleaving/Map/LayerCleavingStatus/CleavedAndSplit";

        /// <summary>
        /// Configuration of Expand Sub-Materials Cleaving Map Layer Material ID Default Value
        /// </summary>
        public static string ConfigExpandSubMaterialsCleavingMapLayerMaterialIdDefaultValue = "/LamResearch/Business/ExpandSubMaterialsCleaving/Map/LayerMaterialId/DefaultValue";

        /// <summary>
        /// Configuration of Expand Sub-Materials Cleaving Map Layer Quantity Default Value
        /// </summary>
        public static string ConfigExpandSubMaterialsCleavingMapLayerQuantityDefaultValue = "/LamResearch/Business/ExpandSubMaterialsCleaving/Map/LayerQuantity/DefaultValue";

        /// <summary>
        /// Configuration of Map Definition Attribute Auto Flatten Sub-Materials
        /// </summary>
        public static string ConfigMapDefinitionAttributeFlattenMaterialHierarchy = "/LamResearch/Business/ExpandSubMaterialsCleaving/MapDefinition/Attributes/FlattenMaterialHierarchy";

        /// <summary>
        /// Configuration of Map Definition Attribute Auto Split By Form
        /// </summary>
        public static string ConfigMapDefinitionAttributeSplitByForm = "/LamResearch/Business/ExpandSubMaterialsCleaving/MapDefinition/Attributes/SplitByForm";

        /// <summary>
        /// Configuration of DEE CustomFlattenMaterialHierarchy
        /// </summary>
        public static string ConfigDeeFlattenMaterialHierarchy = "/LamResearch/Business/ExpandSubMaterialsCleaving/Map/DEEs/FlattenMaterialHierarchy";

        /// <summary>
        /// Configuration of DEE CustomSplitByForm
        /// </summary>
        public static string ConfigDeeSplitByForm = "/LamResearch/Business/ExpandSubMaterialsCleaving/Map/DEEs/SplitByForm";


        /// <summary>
        /// Configuration of InternalWaferTypes
        /// </summary>InternalWaferType
        public const string EnabledWaferTypesPath = "/LamResearch/Business/EnabledWaferTypes/";

        /// <summary>
        /// Configuration of InternalWaferTypes
        /// </summary>
        public const string InternalWaferType = "InternalWaferType";

        public struct Configs
        {
            public struct ProjectMaxDuration
            {
                public const string EndDateApproaching = "/LamResearch/Business/ProjectMaxDuration/EndDateApproachingStateName/";
                public const string EndDateReached = "/LamResearch/Business/ProjectMaxDuration/EndDateReachedStateName/";
                public const string EndDateExceeded = "/LamResearch/Business/ProjectMaxDuration/EndDateExceededStateName/";
                public const string IdleDateApproaching = "/LamResearch/Business/ProjectMaxDuration/IdleDateApproaching/";
                public const string IdleDateReached = "/LamResearch/Business/ProjectMaxDuration/IdleDateReached/";
                public const string IdleDateExceeded = "/LamResearch/Business/ProjectMaxDuration/IdleDateExceeded/";
            }

            public struct ProtocolParameterNames
            {
                public const string ParentPath = "/LamResearch/Business/ProjectCreation/ProtocolParameterNames/";
                public const string EndDate = "ProjectEndDate";
                public const string ProjectOwner = "ProjectOwner";
                public const string ProjectPriority = "ProjectPriority";
                public const string ProjectTitle = "ProjectTitle";
                public const string RequestedProjectPriority = "RequestedProjectPriority";
                public const string PriorityStartDate = "PriorityStartDate";
                public const string PriorityEndDate = "PriorityEndDate";
            }

            public struct ProjectStates
            {
                public const string ParentPath = "/LamResearch/Business/ProjectStates/";
                public const string SetupState = "SetupState";
            }
        }

        /// <summary>
        /// Project Priority States ParentPath
        /// </summary>
        public const string ProjectPriorityStateConfig = "/LamResearch/Business/ProjectCreation/ProjectPriorityStates";

        #endregion

        #region Parameters

        /// <summary>
        /// Product Parameter with wafer quantity
        /// </summary>
        public const string CustomParameterWaferQuantity = "Wafer Size";

        #endregion

        #region Queries

        /// <summary>
        /// Query CustomGetContainersDockedOnResourceLoadPorts Name
        /// </summary>
        public static string QueryCustomGetContainersDockedOnResourceLoadPorts = "CustomGetResourceLoadPortsData";

        /// <summary>
        /// Query CustomGetContainersDockedOnResourceLoadPorts Parent Resource parameter
        /// </summary>
        public static string QueryCustomGetContainersDockedOnResourceLoadPortsParentResourceParameter = "ParentResource";

        /// <summary>
        /// Query CustomGetContainersDockedOnResourceLoadPorts Resource Association Type parameter
        /// </summary>
        public static string QueryCustomGetContainersDockedOnResourceLoadPortsContainerResourceAssociationTypeParameter = "ContainerResourceAssociationType";

        /// <summary>
        /// Query CustomGetContainersDockedOnResourceLoadPorts Parent Resource Id Column
        /// </summary>
        public static string QueryCustomGetContainersDockedOnResourceLoadPortsParentResourceIdColumn = "SourceEntityId";

        /// <summary>
        /// Query CustomGetContainersDockedOnResourceLoadPorts Load Port Id Column
        /// </summary>
        public static string QueryCustomGetContainersDockedOnResourceLoadPortsLoadPortIdColumn = "TargetEntityId";

        /// <summary>
        /// Query CustomGetContainersDockedOnResourceLoadPorts Load Port Name Column
        /// </summary>
        public static string QueryCustomGetContainersDockedOnResourceLoadPortsLoadPortNameColumn = "TargetEntityName";

        /// <summary>
        /// Query CustomGetContainersDockedOnResourceLoadPorts Is Load Port In Use Column
        /// </summary>
        public static string QueryCustomGetContainersDockedOnResourceLoadPortsIsLoadPortInUseColumn = "TargetEntityIsLoadPortInUse";

        /// <summary>
        /// Query CustomGetContainersDockedOnResourceLoadPorts Load Port Type Column
        /// </summary>
        public static string QueryCustomGetContainersDockedOnResourceLoadPortsLoadPortTypeColumn = "TargetEntityLoadPortType";

        /// <summary>
        /// Query CustomGetContainersDockedOnResourceLoadPorts Load Port Modified On Column
        /// </summary>
        public static string QueryCustomGetContainersDockedOnResourceLoadPortsLoadPortModifiedOnColumn = "TargetEntityModifiedOn";

        /// <summary>
        /// Query CustomGetContainersDockedOnResourceLoadPorts Container Id Column
        /// </summary>
        public static string QueryCustomGetContainersDockedOnResourceLoadPortsContainerIdColumn = "TargetEntityContainerResourceSourceEntityId";

        /// <summary>
        /// Query CustomGetContainersDockedOnResourceLoadPorts Container Name Column
        /// </summary>
        public static string QueryCustomGetContainersDockedOnResourceLoadPortsContainerNameColumn = "TargetEntityContainerResourceSourceEntityName";

        /// <summary>
        /// Query CustomGetContainersDockedOnResourceLoadPorts Container Type Column
        /// </summary>
        public static string QueryCustomGetContainersDockedOnResourceLoadPortsContainerTypeColumn = "TargetEntityContainerResourceSourceEntityType";

        /// <summary>
        /// Query CustomGetContainersDockedOnResourceLoadPorts Container Total Positions Column
        /// </summary>
        public static string QueryCustomGetContainersDockedOnResourceLoadPortsContainerTotalPositionsColumn = "TargetEntityContainerResourceSourceEntityTotalPositions";

        /// <summary>
        /// Query CustomGetResourceLoadPortsData Load Port State Model State Id Column
        /// </summary>
        public static string QueryCustomGetContainersDockedOnResourceLoadPortsLoadPortStateModelStateIdColumn = "TargetEntityMainStateModelStateId";

        /// <summary>
        /// Query CustomGetContainersDockedOnResourceLoadPorts Container Used Positions Column
        /// </summary>
        public static string QueryCustomGetContainersDockedOnResourceLoadPortsContainerUsedPositionsColumn = "TargetEntityContainerResourceSourceEntityUsedPositions";

        /// <summary>
        /// Query CustomGetContainersDockedOnResourceLoadPorts Container Lot Attribute Column
        /// </summary>
        public static string QueryCustomGetContainersDockedOnResourceLoadPortsContainerLotAttributeColumn = "TargetEntityContainerResourceSourceEntityLot";

        /// <summary>
        /// Query CustomGetContainersDockedOnResourceLoadPorts Container Product Attribute Column
        /// </summary>
        public static string QueryCustomGetContainersDockedOnResourceLoadPortsContainerProductAttributeColumn = "TargetEntityContainerResourceSourceEntityProduct";

        /// <summary>
        /// Query CustomGetContainersDockedOnResourceLoadPorts Container Parent Material Id Column
        /// </summary>
        public static string QueryCustomGetContainersDockedOnResourceLoadPortsContainerParentMaterialIdColumn = "TargetEntityContainerResourceSourceEntityMaterialContainerSourceEntityParentMaterialId";

        /// <summary>
        /// Query CustomGetContainersDockedOnResourceLoadPorts Container Parent Material Name Column
        /// </summary>
        public static string QueryCustomGetContainersDockedOnResourceLoadPortsContainerParentMaterialNameColumn = "TargetEntityContainerResourceSourceEntityMaterialContainerSourceEntityParentMaterialName";

        /// <summary>
        /// Query CustomGetContainersDockedOnResourceLoadPorts Container Resource Association Type Column
        /// </summary>
        public static string QueryCustomGetContainersDockedOnResourceLoadPortsContainerResourceAssociationTypeColumn = "TargetEntityContainerResourceSourceEntityResourceAssociationType";

        /// <summary>
        /// Query CustomGetContainersDockedOnResourceLoadPorts Container MapContainerNeeded Attribute Column
        /// </summary>
        public static string QueryCustomGetContainersDockedOnResourceLoadPortsContainerMapContainerNeededAttributeColumn = "TargetEntityContainerResourceSourceEntityMapContainerNeeded";

        /// <summary>
        /// Query CustomGetContainersDockedOnResourceLoadPorts Container Transport Requested Attribute Column
        /// </summary>
        public static string QueryCustomGetContainersDockedOnResourceLoadPortsContainerTransportRequestedAttributeColumn = "TargetEntityContainerResourceSourceEntityTransportRequested";

        #endregion

        #region Custom Sorter Job Definition Movement List Properties

        /// <summary>
        /// Custom Sorter Job Json Moves Material Name Property
        /// </summary>
        public static string CustomSorterJobDefinitionJsonMovesPropertyMaterialName = "MaterialName";

        /// <summary>
        /// Custom Sorter Job Json Moves Source Container Property
        /// </summary>
        public static string CustomSorterJobDefinitionJsonMovesPropertySourceContainer = "SourceContainer";

        /// <summary>
        /// Custom Sorter Job Json Moves Source Position Property
        /// </summary>
        public static string CustomSorterJobDefinitionJsonMovesPropertySourcePosition = "SourcePosition";

        /// <summary>
        /// Custom Sorter Job Json Moves Source Load Port Number Property
        /// </summary>
        public static string CustomSorterJobDefinitionJsonMovesPropertySourceLoadPortNumber = "SourceLoadPortNumber";

        /// <summary>
        /// Custom Sorter Job Json Moves Destination Container Property
        /// </summary>
        public static string CustomSorterJobDefinitionJsonMovesPropertyDestinationContainer = "DestinationContainer";

        /// <summary>
        /// Custom Sorter Job Json Moves Destination Position Property
        /// </summary>
        public static string CustomSorterJobDefinitionJsonMovesPropertyDestinationPosition = "DestinationPosition";

        /// <summary>
        /// Custom Sorter Job Json Moves Destination Load Port Number Property
        /// </summary>
        public static string CustomSorterJobDefinitionJsonMovesPropertyDestinationLoadPortNumber = "DestinationLoadPortNumber";

        /// <summary>
        /// Custom Sorter Job Json Future Action Type Property
        /// </summary>
        public static string CustomSorterJobDefinitionJsonPropertyFutureActionType = "FutureActionType";

        /// <summary>
        /// Custom Sorter Job Json Moves Property
        /// </summary>
        public static string CustomSorterJobDefinitionJsonPropertyMoves = "Moves";

        /// <summary>
        /// Custom Sorter Job Json Delete On Completion Property
        /// </summary>
        public static string CustomSorterJobDefinitionJsonPropertyDeleteOnCompletion = "DeleteOnCompletion";

        /// <summary>
        /// Custom Sorter Job Json Moves Product Name Property
        /// </summary>
        public static string CustomSorterJobDefinitionJsonMovesPropertyProductName = "Product";

        /// <summary>
        /// Custom Sorter Job Json Moves Substitutes Array Property
        /// </summary>
        public static string CustomSorterJobDefinitionJsonMovesPropertySubstitutes = "Substitutes";

        /// <summary>
        /// Custom Sorter Job Json Moves Substitute Property
        /// </summary>
        public static string CustomSorterJobDefinitionJsonMovesPropertySubstitute = "Substitute";

        /// <summary>
        /// Custom Sorter Job Json Reclaim Product Property
        /// </summary>
        public static string CustomSorterJobDefinitionJsonPropertyReclaimProduct = "ReclaimProduct";

        /// <summary>
        /// Custom Sorter Job Json Grading Future Action Type Property
        /// </summary>
        public static string CustomSorterJobDefinitionJsonPropertyGradingFutureActionType = "Grading";

        /// <summary>
        /// Custom Sorter Job Json Split Future Action Type Property
        /// </summary>
        public static string CustomSorterJobDefinitionJsonPropertySplitFutureActionType = "Split";

        /// <summary>
        /// Custom Sorter Job Json Merge Future Action Type Property
        /// </summary>
        public static string CustomSorterJobDefinitionJsonPropertyMergeFutureActionType = "Merge";

        /// <summary>
        /// Custom Sorter Job Json Scrap Future Action Type Property
        /// </summary>
        public static string CustomSorterJobDefinitionJsonPropertyScrapFutureActionType = "Scrap";

        #endregion

        #region Integration Entries

        /// <summary>
        /// System ERP
        /// </summary>
        public const string CustomERPSystem = "ERP";

        /// <summary>
        /// Stibo System
        /// </summary>
        public const string CustomStiboSystem = "Stibo";

        /// <summary>
        /// Integration Inbound Event Name
        /// </summary>
        public const string CustomIntegrationInboundEventName = "Inbound";

        #endregion

        #region Name Generators

        /// <summary>
        /// Split Lot Name Generator
        /// </summary>
        public const string CustomGenerateSplitLotNames = "CustomGenerateSplitLotNames";

        /// <summary>
        /// Production lot Name Generator
        /// </summary>
        public const string CustomGenerateProductionLotNames = "CustomProductionLotNameGenerator";

        /// <summary>
        /// Expand Material Name Generator
        /// </summary>
        public const string CustomGenerateExpandMaterialNameGenerator = "ExpandMaterialNameGenerator";

        /// <summary>
        /// Production lot Name Generator
        /// </summary>
        public const string CustomGenerateProtocolInstanceNamesForProjectCodes = "CustomProtocolInstanceForProjectCodeNameGenerator";

        #endregion

        #region Containers

        /// <summary>
        /// ContainerTypeFEOL
        /// </summary>
        public static string ContainerTypeFEOL = "FEOL";

        /// <summary>
        /// Container Type: BEOL
        /// </summary>
        public const string ContainerTypeBEOL = "BEOL";
        public const string TagVueMesManualOperationException = "TagVueMesManualOperationException";
        public const string OperationNotAllowedContainerException = "OperationNotAllowedContainerException";
        public const string ContainerNotFound = "ContainerNotFound";
        #endregion

        #region Reasons

        /// <summary>
        /// InvalidWaferForSlot Hold Reason
        /// </summary>
        public static string InvalidWaferForSlotReason = "InvalidWaferForSlot";

        #endregion

        #region Changes Set

        /// <summary>
        /// Change Set Default type
        /// </summary>
        public static string ChangeSetDefaultType = "General";

        public static string ChangeSetNameGenerator = "ChangeSetNameGenerator";

        #endregion

        #region Recipes

        /// <summary>
        /// Recipe Body Validation Behavior Default value
        /// </summary>
        public static string RecipeBodyValidationBehaviorDefault = "Default";

        /// <summary>
        /// Recipe Body Validation Behavior Validate value
        /// </summary>
        public static string RecipeBodyValidationBehaviorValidate = "Validate";

        #endregion

        #region Material

        /// <summary>
        /// Material First Level Sub-Material Form
        /// </summary>
        public static string MaterialFirstLevelSubMaterialForm = "Wafer";


        #endregion

        #region Map

        /// <summary>
        /// Map Separator for Irregular Maps
        /// </summary>
        public static string MapSeparatorIrregularMaps = ";";

        #endregion

        #region DEE Context Parameters

        /// <summary>
        /// DEE context to show a feedback message on CustomProjectCode
        /// </summary>
        public static string DeeContextParameterCustomProjectCode = "CustomProjectCodeFeedbackMessage";

        /// <summary>
        /// DEE context to show a feedback message when a Flow is created on Perform Protocol Instance
        /// </summary>
        public static string DeeContextParameterFlow = "FlowFeedbackMessage";

        /// <summary>
        /// DEE context to show a feedback message when a Product is created on Perform Protocol Instance
        /// </summary>
        public static string DeeContextParameterProduct = "ProductFeedbackMessage";

        /// <summary>
        /// DEE context to show a feedback message when a Production Order is created on Perform Protocol Instance
        /// </summary>
        public static string DeeContextParameterProductionOrder = "ProductionOrderFeedbackMessage";

        /// <summary>
        /// DEE context to set the list of Main Materials after Split By Form
        /// </summary>
        public static string DeeContextParameterMainMaterialsSplit = "MainMaterialsSplit";

        /// <summary>
        /// DEE context to set the list of Expanded Materials after Material Track-Out
        /// </summary>
        public static string DeeContextParameterExpandedMaterials = "ExpandedMaterials";
        public const string PropertyCustomer = "Customer";
        public const string ProtocolMaterialRelationName = "ProtocolMaterial";
        public const string NotValidCustomPriorityValue = "NotValidCustomPriorityValue";


        /// <summary>
        /// DEE context to set the Data Set result on Protocol Parameters dependencies validation
        /// </summary>
        public static string DeeContextProtocolParameterValidationResult = "ProtocolParameterValidationResult";

        /// <summary>
        /// DEE context to set the Protocol Instance on Protocol Parameters dependencies validation
        /// </summary>
        public static string DeeContextProtocolParameterValidationProtocolInstance = "ProtocolParameterValidationProtocolInstance";

        /// <summary>
        /// DEE context to set the Data Collection Instances on Propagate Data Group to Data Collection Instances
        /// </summary>
        public static string DeeContextPropagateDataGroupToDataCollectionInstance = "PropagateDataGroupToDataCollectionInstance";

        /// <summary>
        /// DEE CustomProtocolSpecificNotifications
        /// </summary>
        public static string DeeCustomProtocolSpecificNotifications = "CustomProtocolSpecificNotifications";

        /// <summary>
        /// DEE Context to grant access to manage either Roles or DataGroups
        /// </summary>
        public static string DeeContextGrantAccessToManage = "GrantAccessToManage";
        public const string Roles = "Role(s)";
        public const string DataGroups = "DataGroup(s)";
        public const string Role = "Role";
        public const string UserName = "UserName";
        public const string GrantAccessToManageRole = "GrantAccessToManageRole";
        public const string GrantAccessToManageDataGroup = "GrantAccessToManageDataGroup";

        #endregion

        #region DEE Actions

        public struct DEEs
        {
            public struct Protocol
            {
                public struct CustomUpdateProjectPriorityOnElevatedPriority
                {
                    public const string Name = "CustomUpdateProjectPriorityOnElevatedPriority";
                }
            }
        }

        #endregion

        #region Rules

        public struct Rules
        {
            public struct CustomUpdateProjectPriorityOnElevatedPriority
            {
                public const string Name = "CustomUpdateProjectPriorityOnElevatedPriorityRule";
            }
        }

        #endregion
    }
}
