﻿using Cmf.Custom.Lam.Common.DataRepositories;
using Cmf.Foundation.Services.HostStartup;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;

namespace Cmf.Custom.Lam.Common
{
    public class CommonStartupModule : IStartupModule
    {
        public MiddlewarePositioning MiddlewarePositioning => MiddlewarePositioning.None;

        public int ServiceRegistrationOrder => 0;

        public void Configure(IApplicationBuilder app, ConfigureMiddlewareContext context)
        {

        }

        public void ConfigureRootServices(IServiceCollection services)
        {
        }

        public void ConfigureServices(IServiceCollection services, ConfigureServicesContext context)
        {
            services.AddScoped<IEntityTagRepository, EntityTagRepository>();
        }
    }
}
