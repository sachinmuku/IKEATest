﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Custom.Lam.Common.Interfaces;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common;
using Cmf.Foundation.Configuration.Abstractions;
using Cmf.Foundation.Security;
using Cmf.Foundation.Security.Abstractions;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Namotion.Reflection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;

namespace Cmf.Custom.Lam.Common.Services
{
    public class CustomProjectDefaultAccessRolesService : ICustomProjectDefaultAccessRoles
    {
        private readonly IDataGroup dataGroup;
        private readonly IConfig config;
        private readonly string baseConfigTemplatePath;
        private readonly Dictionary<string, string> properties;

        public CustomProjectDefaultAccessRolesService(IDataGroup dataGroup,IConfig config)
        {
            this.dataGroup = dataGroup;
            this.config = config;
            baseConfigTemplatePath = @"/LamResearch/Business/CustomCreateDataGroupNameTemplates/";
            properties = new Dictionary<string, string>();
        }

        public void AssignTo(IEntity entity,bool isSaveToDb,long? predefinedDataGroupId)
        {
            if (entity == null) return;
            entity.Load();
            entity.DataGroupId = predefinedDataGroupId ?? dataGroup.Id;
            if (isSaveToDb)
            {
                if (entity.Name is not null)
                {
                    try
                    {
                        entity.Save();
                    }
                    catch (CmfBaseException)
                    {
                        //object does not exist
                    }
                   
                }
                
            }           
        }

        public void AssignTo(IEntity entity, bool isSaveToDb)
        {
            AssignTo(entity, isSaveToDb, null);
        }

        public void AssignTo(IEntity entity)
        {
            AssignTo(entity, true, null);
        }

        public void AssignTo(IEntity entity, long? predefinedDataGroupId)
        {
            AssignTo(entity, true, predefinedDataGroupId);
        }

        public void LoadDataGroupFromRelations(IEntity entity, params string[] relationNames)
        {
            if (entity == null) return;
            if (entity is IMaterial material && material.ParentMaterial?.DataGroupId == 0)
            {
                return;
            }
            foreach (var relationName in relationNames)
            {
                if (entity.HasRelations(relationName, true))
                {   
                    foreach (var relationCollection in entity.RelationCollection)
                    {
                        foreach (IEntityRelation relation in relationCollection.Value)
                        {
                            var subGroup = relation.TargetEntity.TryGetPropertyValue(LamConstants.PropertySubGroup, string.Empty);
                            if(subGroup != null)
                            {
                                properties.TryAdd(LamConstants.PropertySubGroup, subGroup);
                            }
                            var customer = relation.TargetEntity.TryGetPropertyValue<IBusinessPartner>(LamConstants.PropertyCustomer);
                            if (customer != null)
                            {
                                properties.TryAdd(LamConstants.PropertyCustomer, customer.Name);
                            }
                        }
                    }
                }
                else
                {
                    continue;
                }
            }
            
        }

        public void Create(IEntity entity)
        {
            Create(entity, null);
        }

        public void Create(IEntity entity,string dataGroupName)
        {
           if (string.IsNullOrEmpty(dataGroupName) is false)
           {
                dataGroup.Name = dataGroupName;
                dataGroup.Load();
                return;
           }
            static string GetValueAsString(object value)
            {
                if (value == null) return string.Empty;
                if (value is IEntity entityValue)
                {
                    entityValue.Load();
                    return entityValue.TryGetPropertyValue("Name", string.Empty);
                }
                else
                {
                    return value.ToString();
                }
            }
            foreach (var prop in entity.EntityType.Properties)
            {
                var entityProperty = entity.GetType().GetRuntimeProperties().FirstOrDefault(rp => rp.Name == prop.Name)?.GetValue(entity);
                if (entityProperty != null)
                {
                    var valueString = GetValueAsString(entityProperty);
                    if (string.IsNullOrEmpty(valueString) is false)
                    {
                        properties.Add(prop.Name, GetValueAsString(entityProperty));
                    }
                }
                else
                {
                    continue;
                }
               
            }
            var entityTypeNameSpace = entity.EntityType.EntityTypeTypeName;
            var entityTypeName = entityTypeNameSpace?[(entityTypeNameSpace.LastIndexOf(".") + 1)..];
            config.Load(baseConfigTemplatePath, 1);
            string template = config.GetChildConfigByPath(entityTypeName).GetConfigValue<string>();

            if (string.IsNullOrWhiteSpace(template)) return;

            if ((properties.TryGetValue("Customer", out string value) is false || value is null) && template.Contains("{Customer}", StringComparison.InvariantCultureIgnoreCase))
            {
                LamUtilities.ThrowLocalizedException("NoCustomerTemplateFoundException", template);
            }
               
            dataGroup.Name = Regex.Replace(template, @"\{(.*?)\}", match => properties.GetValueOrDefault(match.Groups[1].Value.Trim()) ?? string.Empty);
            if (dataGroup.ObjectExists())
            {
                dataGroup.Load();
            }
            else
            {
                dataGroup.Create();
                Invalidate.SecurityCache();
            }
        }
    }
}
