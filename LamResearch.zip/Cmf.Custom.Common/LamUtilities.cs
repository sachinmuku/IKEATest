﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Threading;
using Cmf.Common.CustomActionUtilities;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessObjects.Cultures;
using Cmf.Foundation.BusinessObjects.SmartTables;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.LocalizationService;
using Cmf.Foundation.Configuration;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Microsoft.Extensions.DependencyInjection;

namespace Cmf.Custom.Lam.Common
{
    public static class LamUtilities
    {
        #region Generic

        /// <summary>
        /// Get Value as nullable decimal.
        /// </summary>
        /// <param name="value">Value to be converted.</param>
        /// <returns></returns>
        public static decimal? GetValueAsNullableDecimal(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return null;
            }

            return decimal.Parse(value.Replace(",", CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator).Replace(".", CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator), NumberStyles.Number | NumberStyles.AllowExponent);
        }

        /// <summary>
        /// Get Value as nullable boolean
        /// </summary>
        /// <param name="value">Value to be converted.</param>
        /// <returns></returns>
        public static bool? GetValueAsNullableBoolean(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return null;
            }

            // True: Possible values 
            string[] positiveValues = { "y", "true", "yes", "1" };

            if (positiveValues.Contains(value.Trim(), StringComparer.InvariantCultureIgnoreCase))
            {
                return true;
            }

            // False: Possible values
            string[] negativeValues = { "n", "false", "no", "0" };

            if (negativeValues.Contains(value.Trim(), StringComparer.InvariantCultureIgnoreCase))
            {
                return false;
            }

            return default(bool?);
        }

        /// <summary>
        /// Get Value as decimal.
        /// </summary>
        /// <param name="value">Value to be converted.</param>
        /// <returns></returns>
        public static decimal GetValueAsDecimal(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return default(decimal);
            }

            return decimal.Parse(value.Replace(",", CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator).Replace(".", CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator), NumberStyles.Number | NumberStyles.AllowExponent);
        }

        /// <summary>
        /// Get Value as boolean.
        /// </summary>
        /// <param name="value">Value to be converted.</param>
        /// <returns></returns>
        public static bool GetValueAsBoolean(string value)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return false;
            }

            string[] booleanValues = { "y", "true", "yes", "1" };

            if (booleanValues.Contains(value.Trim(), StringComparer.InvariantCultureIgnoreCase))
            {
                return true;
            }

            return default(bool);
        }

        /// <summary>
        /// Gets the value as enum.
        /// </summary>
        /// <typeparam name="T">Type of the enum.</typeparam>
        /// <param name="value">Value to be converted.</param>
        /// <returns>Return the value as enum value.</returns>
        public static T GetValueAsEnum<T>(string value) where T : struct
        {
            T result;

            if (Enum.TryParse<T>(value, out result))
            {
                return result;
            }

            return default(T);
        }

        /// <summary>
        /// Get Value as dynamic DataType.
        /// </summary>
        /// <param name="parameterDataType">Parameter Data Type.</param>
        /// <param name="value">Value to be converted.</param>
        /// <returns></returns>
        public static dynamic GetParameterValueAsDataType(ParameterDataType parameterDataType, string value)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return default(dynamic);
            }

            switch (parameterDataType)
            {
                case ParameterDataType.Decimal:
                    return GetValueAsNullableDecimal(value);

                case ParameterDataType.Boolean:
                    return GetValueAsNullableBoolean(value);

                default:
                    return value;
            }
        }

        /// <summary>
        /// Get Value as dynamic DataType.
        /// </summary>
        /// <param name="scalarType">Scalar Type.</param>
        /// <param name="value">Value to be converted.</param>
        /// <returns></returns>
        public static dynamic GetAttributeValueAsDataType(ScalarType scalarType, string value)
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                return default(dynamic);
            }

            switch (scalarType.NativeType)
            {
                case "System.Decimal":
                    return GetValueAsNullableDecimal(value);

                case "System.Boolean":
                    return GetValueAsNullableBoolean(value);

                default:
                    return value;
            }
        }

        /// <summary>
        /// Check if object value is Null or empty
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static bool ObjectIsNullOrEmpty(object value)
        {
            return value == null || (value?.ToString() ?? string.Empty) == string.Empty ;
        }

        #endregion

        #region Configs

        /// <summary>
        /// Retrieves the config value for the input key
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="configName"></param>
        /// <returns></returns>
        public static T GetConfig<T>(string configName)
        {
            Config config = (Config)Config.GetConfig(configName);
            if (config != null && config.Value != null)
            {
                return (T)config.Value;
            }
            else
            {
                throw new Exception(string.Format(LocalizedMessage.GetLocalizedMessage(Thread.CurrentThread.CurrentCulture.Name, LamConstants.LocalizedMessageConfigNotFound).MessageText, configName));
            }
        }

        #endregion Configs

        #region SmartTables

        /// <summary>
        /// Method to resolve Material Data Collection Context 
        /// </summary>
        /// <param name="step"></param>
        /// <param name="logicalFlowPath"></param>
        /// <param name="product"></param>
        /// <param name="productGroup"></param>
        /// <param name="flow"></param>
        /// <param name="material"></param>
        /// <param name="materialType"></param>
        /// <param name="resource"></param>
        /// <param name="resourceType"></param>
        /// <param name="model"></param>
        /// <param name="operation"></param>
        /// <returns></returns>
        public static INgpDataSet CustomResolveMaterialDataCollectionContext(string step = null,
                                                                            string logicalFlowPath = null,
                                                                            string product = null,
                                                                            string productGroup = null,
                                                                            string flow = null,
                                                                            string material = null,
                                                                            string materialType = null,
                                                                            string resource = null,
                                                                            string resourceType = null,
                                                                            string model = null,
                                                                            string operation = null)
        {
            Dictionary<string, string> result = new Dictionary<string, string>();
            ISmartTable materialDatacollectionContext = new SmartTable();
            materialDatacollectionContext.Load(Navigo.Common.Constants.MaterialDataCollectionContext);

            INgpDataRow values = new NgpDataRow();

            // If step name is filled apply it as a filter
            if (!string.IsNullOrWhiteSpace(step))
            {
                values.Add(Navigo.Common.Constants.Step, step);
            }

            // If logical flow path is filled apply it as a filter
            if (!string.IsNullOrWhiteSpace(logicalFlowPath))
            {
                values.Add("LogicalFlowPath", logicalFlowPath);
            }

            // If product name is filled apply it as a filter
            if (!string.IsNullOrWhiteSpace(product))
            {
                values.Add(Navigo.Common.Constants.Product, product);
            }

            // If product group is filled apply it as a filter
            if (!string.IsNullOrWhiteSpace(productGroup))
            {
                values.Add(Navigo.Common.Constants.ProductGroup, productGroup);
            }

            // If flow name is filled apply it as a filter
            if (!string.IsNullOrWhiteSpace(flow))
            {
                values.Add(Navigo.Common.Constants.Flow, flow);
            }

            // If lot name is filled apply it as a filter
            if (!string.IsNullOrWhiteSpace(material))
            {
                values.Add(Navigo.Common.Constants.Material, material);
            }

            // If lot type is filled apply it as a filter
            if (!string.IsNullOrWhiteSpace(materialType))
            {
                values.Add(Navigo.Common.Constants.MaterialType, materialType);
            }

            // If resource name is filled apply it as a filter
            if (!string.IsNullOrWhiteSpace(resource))
            {
                values.Add(Navigo.Common.Constants.Resource, resource);
            }

            // If resource type is filled apply it as a filter
            if (!string.IsNullOrWhiteSpace(resourceType))
            {
                values.Add(Navigo.Common.Constants.ResourceType, resourceType);
            }

            // If model is filled apply it as a filter
            if (!string.IsNullOrWhiteSpace(model))
            {
                values.Add(Navigo.Common.Constants.Model, model);
            }

            // If operation name is filled apply it as a filter
            if (!string.IsNullOrWhiteSpace(operation))
            {
                values.Add(Navigo.Common.Constants.Operation, operation);
            }

            INgpDataSet materialDCContextNgpDataSet = materialDatacollectionContext.Resolve(values, true);

            return materialDCContextNgpDataSet;
        }

        /// <summary>
        /// Attempts to resolve a smart table based on the parameters sent
        /// </summary>
        /// <param name="smartTableName"></param>
        /// <param name="values"></param>
        /// <param name="onlyFirstRow">Indicates if only first matched entry is to be returned</param>
        /// <param name="firstPrecedenceMatch">Indicates if only records found in the first matchable precedence key are to be returned</param>
        /// <param name="throwException"></param>
        /// <returns></returns>
        public static DataSet ResolveSmartTable(string smartTableName, NgpDataRow values, bool onlyFirstRow = true, bool firstPrecedenceMatch = false, bool throwException = false)
        {
            SmartTable smartTable = GetSmartTable(smartTableName);

            if (smartTable != null)
            {
                INgpDataSet ngpDataSet;

                if (firstPrecedenceMatch) ngpDataSet = ResolveSmartTableOnlyFirstPrecedenceKeyMatch(smartTable, values);
                else ngpDataSet = smartTable.Resolve(values, onlyFirstRow);

                if (ngpDataSet != null && ngpDataSet.Tables != null) return NgpDataSet.ToDataSet(ngpDataSet);
            }

            if (throwException)
            {
                throw new NoDataFoundCmfException(smartTableName);
            }

            return null;
        }

        /// <summary>
        /// Resolves a smart table by retrieving only the values for the first matched precedence key
        /// </summary>
        /// <param name="smartTable">Name of the smart table to be used</param>
        /// <param name="resolveParameters">Filters to apply to the resolve</param>
        /// <returns></returns>
        public static INgpDataSet ResolveSmartTableOnlyFirstPrecedenceKeyMatch(SmartTable smartTable, NgpDataRow resolveParameters)
        {
            INgpDataSet returnSet = null;

            if (smartTable != null && smartTable.Id > 0 && resolveParameters != null)
            {
                // Resolve the data
                INgpDataSet resultSet = smartTable.Resolve(resolveParameters, false);
                DataSet resultDataSet = NgpDataSet.ToDataSet(resultSet);

                if (resultDataSet != null && resultDataSet.Tables.Count > 0 && resultDataSet.Tables[0].Rows.Count > 0)
                {
                    DataTable resultsTable = resultDataSet.Tables[0];

                    // Check which values apply
                    smartTable.LoadPrecedenceKeys();
                    smartTable.LoadProperties();

                    Collection<string> smartTableKeys = new(smartTable.SmartTableProperties.Where(e => e.IsKey).Select(e => e.Name).ToList());

                    foreach (var precedenceKey1 in smartTable.PrecedenceKeys.OrderBy(e => e.RuleOrder))
                    {
                        var precedenceKey = (PrecedenceKey)precedenceKey1;
                        DataTable eligibleData = resultsTable.Copy();

                        // Get precedence key columns
                        string[] precedenceKeyColumns = precedenceKey.RuleString.Split('+');
                        List<string> preparedFilters = precedenceKeyColumns.Select(e => string.Format($"{e} IS NOT NULL")).ToList();

                        // Get excluded precedence key columns
                        preparedFilters.AddRange(smartTableKeys.Where(e => !precedenceKeyColumns.Contains(e)).Select(e =>
                            $"{e} IS NULL"));

                        string filterToApply = string.Join(" AND ", preparedFilters.ToArray());

                        DataRow[] resultingRows = eligibleData.Select(filterToApply);

                        if (resultingRows.Length > 0)
                        {
                            // This precedence key returns data and is the one to be returned...
                            DataSet returnDataSet = resultDataSet.Clone();
                            returnDataSet.Tables.Clear();
                            returnDataSet.Tables.Add(resultingRows.CopyToDataTable());

                            returnSet = NgpDataSet.FromDataSet(returnDataSet);
                            break;
                        }
                    }
                }
            }

            return returnSet;
        }

        /// <summary>
        /// Tries to load a SmartTable
        /// </summary>
        /// <param name="smartTableName"></param>
        /// <returns></returns>
        public static SmartTable GetSmartTable(string smartTableName)
        {
            var st = new SmartTable();
            st.Load(smartTableName);

            return st.Id > 0 ? st : null;
        }

        private static DataSet getSmartTableData(ISmartTable smartTable, string smartTableName, IFilterCollection filter)
        {
            smartTable.Load(smartTableName);
            smartTable.LoadData(filter);

            DataSet dataSet = NgpDataSet.ToDataSet(smartTable.Data);
            return dataSet;
        }

        /// <summary>
        /// Attempts to resolve a smart table based on the parameters sent
        /// </summary>
        /// <param name="smartTableName"></param>
        /// <param name="values"></param>
        /// <param name="onlyFirstRow">Indicates if only first matched entry is to be returned</param>
        /// <param name="firstPrecedenceMatch">Indicates if only records found in the first matchable precedence key are to be returned</param>
        /// <param name="throwException"></param>
        /// <returns></returns>
        public static DataSet ResolveAutomationJobIdLogic(IResource resource)
        {
            SmartTable automationJobNameGeneratorSmartTable = new SmartTable() { Name = LamConstants.CustomSmartTableCustomAutomationJobIdLogic };
            automationJobNameGeneratorSmartTable.Load();

            INgpDataRow resolveKeys = new NgpDataRow()
            {
                { "ProcessingType", resource.ProcessingType },
                { "Resource",  resource.Name },
                { "ResourceType", resource.ResourceType },
                { "Model", resource.Model },
            };

            var resolvedData = automationJobNameGeneratorSmartTable.Resolve(resolveKeys, true);

            var dataset = NgpDataSet.ToDataSet(resolvedData);

            return dataset;
        }

        #endregion

        #region Sorter

        /// <summary>
        /// Retrives a BOM from BOM context for a specific lot.
        /// </summary>
        /// <param name="material"></param>
        /// <returns>The resolved BOM</returns>
        public static BOM ResolveBOMContext(IMaterial material)
        {
            string stepName = material.Step.Name;
            string materialName = material.Name;
            string productName = material.Product.Name;
            string logicalFlowPath = material.LogicalFlowPath;
            // Product group isn't mandatory, we have to null check it
            string productGroupName = material.Product.ProductGroup?.Name ?? null;

            //Load SmartTable
            ISmartTable productTypeRoleSmartTable = new SmartTable() { Name = "BOMContext" };

            productTypeRoleSmartTable.Load();

            INgpDataRow resolveKeys = new NgpDataRow
            {
                { "Step", stepName },
                { "LogicalFlowPath",  logicalFlowPath },
                { "Product", productName },
                { "ProductGroup", productGroupName },
                { "Material", materialName },
            };

            INgpDataSet resolvedData = productTypeRoleSmartTable.Resolve(resolveKeys, true);

            DataSet dataset = NgpDataSet.ToDataSet(resolvedData);

            if (dataset != null && dataset.Tables != null && dataset.Tables.Count != 0 && dataset.Tables[0].Rows.Count > 0)
            {
                BOM bom = new BOM();
                bom.Load(dataset.Tables[0].Rows[0]["BOM"].ToString());
                return bom;
            }
            else
            {
                return null;
            }
        }

        #endregion Sorter

        #region Data Collection

        /// <summary>
        /// Method to validate if one of the posted points do not respect the configured limit set 
        /// </summary>
        /// <param name="dataCollectionInstance"></param>
        /// <returns></returns>
        public static bool IsDataCollectionLimiSetViolated(DataCollectionInstance dataCollectionInstance)
        {
            dataCollectionInstance.LoadRelations("DataCollectionPoint");

            IDataCollectionLimitSet dataCollectionLimitSet = dataCollectionInstance.DataCollectionLimitSet;

            IDataCollectionPointCollection dataCollectionPoints = dataCollectionInstance.DataCollectionPoints;



            foreach (IDataCollectionParameterLimit parameterLimit in dataCollectionLimitSet.DataCollectionParameterLimits)
            {
                IDataCollectionPoint dcPoint = dataCollectionPoints.FirstOrDefault(dcp => dcp.GetNativeValue<long>(Cmf.Foundation.Common.Constants.TargetEntity).Equals(parameterLimit.GetNativeValue<long>(Cmf.Foundation.Common.Constants.TargetEntity)));

                decimal value = Convert.ToDecimal(dcPoint.Value);

                if ((parameterLimit.UpperErrorLimit != null && value > parameterLimit.UpperErrorLimit) || (parameterLimit.LowerErrorLimit != null && value < parameterLimit.LowerErrorLimit))
                {
                    return true;
                }
            }

            return false;
        }

        #endregion

        #region DEEActionUtilities

        /// <summary>
        /// Checks if current action group (present in Input dicionary) is valid based on list of given action groups
        /// </summary>
        /// <param name="Input">Dictionary where in theory action group is defined</param>
        /// <param name="ValidActionGroups">List of valid action groups</param>
        /// <param name="defaultBehavior">default behavior of method. Defaults to false but can be changed by invoker</param>
        /// <returns></returns>
        public static bool IsActionGroupValid(Dictionary<string, object> Input, Collection<string> ValidActionGroups, bool defaultBehavior = false)
        {
            // by default action group is not valid unless explicitly defined otherwise
            bool isValid = defaultBehavior;

            // proceed if Action group name can be extracted from Input
            string actionGroupName = GetActionGroup(Input);
            if (!String.IsNullOrWhiteSpace(actionGroupName) && ValidActionGroups != null && ValidActionGroups.Any())
            {
                isValid = ValidActionGroups.Any(E => String.Equals(E, actionGroupName, StringComparison.InvariantCultureIgnoreCase));
            }

            return isValid;
        }

        /// <summary>
        /// Retrieves the action group
        /// </summary>
        /// <param name="Input"></param>
        /// <returns></returns>
        public static string GetActionGroup(Dictionary<string, object> Input)
        {
            string returnValue = GetInputItem<string>(Input, "ActionGroupName", String.Empty);

            return returnValue;
        }

        /// <summary>
        /// Tries to retrieve a given item from the Input dictionary, based on the item name and passed type
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="Input"></param>
        /// <param name="inputEntryName"></param>
        /// <param name="defaultValue"></param>
        /// <returns></returns>
        public static T GetInputItem<T>(Dictionary<string, object> Input, string inputEntryName, T defaultValue = default(T))
        {
            // define return value
            T returnObject = defaultValue;

            // try to extract the element
            object oExtractedItem = null;
            if (Input.TryGetValue(inputEntryName, out oExtractedItem) && oExtractedItem is T)
            {
                returnObject = (T)oExtractedItem;
            }

            return returnObject;
        }

        public static void SetMaterialStateModel(Material material, string stateModelName, string state)
        {
            if (material.CurrentMainState == null
                || !material.CurrentMainState.CurrentState.Name.Equals(state))
            {
                StateModel stateModel = new StateModel()
                {
                    Name = stateModelName
                };

                stateModel.Load();
                StateModelState stateModelState = new StateModelState();
                stateModelState.Load(state, stateModel);

                CurrentEntityState currentEntityState = new CurrentEntityState(material, stateModel, stateModelState);
                material.SetMainStateModel(currentEntityState);
            }
        }

        /// <summary>
        /// Gets the Entity Attributes Definition (Name; Type)
        /// </summary>
        /// <param name="entityName">The Entity Name.</param>
        /// <returns>A Dictionary of the Attributes Definition.</returns>
        public static Dictionary<string, object> GetEntityAttributesDefinition(string entityName)
        {
            Dictionary<string, object> attributes = new Dictionary<string, object>();

            EntityType entityType = new EntityType();

            entityType.Load(entityName);

            entityType.LoadProperties();

            if (entityType.Properties != null && entityType.Properties.Any())
            {
                IEnumerable<IEntityTypeProperty> attributesDefinition = entityType.Properties.Where(w => w.PropertyType == EntityTypePropertyType.Attribute);

                if (attributesDefinition != null && attributesDefinition.Any())
                {
                    attributes = attributesDefinition.Select(s => new KeyValuePair<string, object>(s.Name, s.ScalarType)).ToDictionary(d => d.Key, d => d.Value);
                }
            }

            return attributes;
        }

        #endregion

        #region Localized Messages

        /// <summary>
        /// Constructs a new Message, using Localized Messages
        /// </summary>
        /// <param name="key"></param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public static string GetLocalizedMessage(string key, params string[] parameters)
        {
            ILocalizedMessage localizedMessageObj = LocalizedMessage.GetLocalizedMessage(Thread.CurrentThread.CurrentCulture.Name, key);
            return string.Format(localizedMessageObj.MessageText, parameters);
        }

        /// <summary>
        /// Constructs a new Exception Message, using Localized Messages
        /// </summary>
        /// <param name="key"></param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        [Obsolete("Use ThrowLocalizedException with IServiceProvider parameter")]
        public static void ThrowLocalizedException(string key, params string[] parameters)
        {
            string exceptionMessage = GeneralUtilities.GetLocalizedMessage(key, parameters);

            throw new Exception(exceptionMessage);
        }

        /// <summary>
        /// Constructs a formated string of a list of elements
        /// </summary>
        /// <param name="entityTypeList">A KeyValuePair where the key is the EntityType and the value is the List of elements</param>
        /// <returns>A formated string</returns>
        public static string GenerateEntityTypeListMessage(KeyValuePair<string, string[]> entityTypeList)
        {
            return $"{entityTypeList.Key}\n\t{string.Join("\n\t", entityTypeList.Value)}\n";
        }

        /// <summary>
        /// Constructs a new Exception Message, using Localized Messages
        /// </summary>
        /// <param name="key"></param>
        /// <param name="parameters"></param>
        /// <returns></returns>
        public static void ThrowLocalizedException(ILocalizationService localizationService, string key, params string[] parameters)
        {
            throw new Exception(string.Format(
                    localizationService.Localize(Thread.CurrentThread.CurrentCulture.Name, key),
                    parameters
                    )
                );
        }
        #endregion Localized Messages
    }
}
