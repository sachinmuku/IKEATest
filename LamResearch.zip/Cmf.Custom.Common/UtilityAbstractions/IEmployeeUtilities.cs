﻿using Cmf.Foundation.Security.Abstractions;
using Cmf.Navigo.BusinessObjects.Abstractions;
using System.Collections;
using System.Collections.Generic;

namespace Cmf.Custom.Lam.Common.UtilityAbstractions;

public interface IEmployeeUtilities
{
    IEmployee GetEmployeeByUserAccount(string userAccount);
    IEmployee GetEmployeeByUser(IUser user);
    IEmployeeCollection GetEmployeesByUserAccounts(IEnumerable<string> userAccounts);
    IEmployeeCollection GetEmployeesByUsers(IEnumerable<IUser> users);
}
