﻿using Cmf.Foundation.Security.Abstractions;
using Cmf.Navigo.BusinessObjects.Abstractions;
using System.Collections.Generic;

namespace Cmf.Custom.Lam.Common.UtilityAbstractions;

public interface INotificationUtilities
{
    INotification CreateNotificationFromTemplate(INotification notification, IEmployee employee = null, IRole role = null, Dictionary<string, string> tokens = null);
    void ReplaceDetailsTokens(INotification notification, Dictionary<string, string> tokens);
    void ReplaceTitleTokens(INotification notification, Dictionary<string, string> tokens);
    string ReplaceTokensByValues(Dictionary<string, string> tokens, string value);
}
