﻿using Cmf.Navigo.BusinessObjects.Abstractions;
using System.Collections.Generic;

namespace Cmf.Custom.Lam.Common.UtilityAbstractions;

public interface IProtocolInstanceUtilities
{
    object GetProtocolParameterValueByConfigName(IProtocolInstance protocolInstance, string configName);
    object GetProtocolParameterValueByConfigPath(IProtocolInstance protocolInstance, string configName);
    Dictionary<string, object> GetProtocolParameterValuesByConfigName(IProtocolInstance protocolInstance, List<string> parametersToGet);
    Dictionary<string, object> GetProtocolParameterValuesByConfigPath(IProtocolInstance protocolInstance, List<string> parametersToGet);
}
