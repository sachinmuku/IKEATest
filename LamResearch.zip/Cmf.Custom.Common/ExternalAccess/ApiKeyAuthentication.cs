﻿using RestSharp;
using RestSharp.Authenticators;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.Lam.Common.ExternalAccess
{
    public class ApiKeyAuthentication : AuthenticatorBase
    {
        private readonly string apiKey;

        public ApiKeyAuthentication(string apiKey,string token) : base(token)
        {
            this.apiKey = apiKey;
        }

        protected override Parameter GetAuthenticationParameter(string accessToken)
        {
           return new Parameter("Authorization", $"{apiKey}:{accessToken}", ParameterType.HttpHeader);
        }
    }
}
