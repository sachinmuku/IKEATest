﻿using Cmf.Custom.Lam.Common.Constants;
using Cmf.Custom.Lam.Common.Interfaces;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.GenericTables;
using Cmf.Foundation.BusinessObjects.QueryObject;
using Cmf.Foundation.Common;
using Cmf.Foundation.Common.LocalizationService;
using Cmf.Foundation.Configuration;
using Newtonsoft.Json;
using RestSharp;
using RestSharp.Authenticators;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading;
using static Cmf.Custom.Lam.Common.Constants.LamResearchConstants;


namespace Cmf.Custom.Lam.Common.ExternalAccess
{
    [Serializable]
    public class ExternalConnection : IExternalConnection
    {
        private readonly ILocalizationService _localizationService;

        private readonly string _apiKey = string.Empty;
        private readonly string _apiSecret = string.Empty;
        private readonly RestClient restClient = null;
        private AuthenticatorBase authenticator;
        public string ExternalSystemDomain { get; private set; } = string.Empty;
        public AuthenticatorBase Authenticator { get => authenticator; set => authenticator = value; }
        private readonly bool UseMockConnectionForTagVue = true;
        public ExternalConnection(
            ILocalizationService LocalizationService
        )
        {
           
            _localizationService = LocalizationService;
            _apiKey = Config.GetConfig(Configs.ApiKey).Value?.ToString();
            if (string.IsNullOrEmpty(_apiKey) )
            {
                throw new CmfBaseException(string.Format(_localizationService.Localize( Thread.CurrentThread.CurrentCulture.Name,
                                LocalizedMessages.ApiKeyNotFound
                            )
                        ));
            }
            _apiSecret = Config.GetConfig(Configs.SecurityToken).Value?.ToString();
            if (string.IsNullOrEmpty(_apiSecret))
            {
                throw new CmfBaseException( string.Format( _localizationService.Localize(Thread.CurrentThread.CurrentCulture.Name,
                                LocalizedMessages.SecurityTokenNotFound
                            )
                        ));
            }
            var extetnalDomain = Config.GetConfig(Configs.ExternalSystemDomain)?.Value.ToString();
            if (string.IsNullOrEmpty(_apiKey) )
            {
                throw new CmfBaseException(string.Format(_localizationService.Localize(Thread.CurrentThread.CurrentCulture.Name,
                                LocalizedMessages.CustomNoExternalEndpointFound
                            )
                        ));
            }
            var useMockConnectionForTagVueConfigValue = Config.GetConfig(Configs.UseMockConnectionForTagVue)?.Value.ToString();
            if (!bool.TryParse(useMockConnectionForTagVueConfigValue, out UseMockConnectionForTagVue))
            {
                UseMockConnectionForTagVue = true;
            }
            authenticator = new ApiKeyAuthentication(_apiKey, _apiSecret);
            restClient = new RestClient(extetnalDomain);
        }

        public IRestResponse ExecuteHttpRequest<TBody>(CustomExternalSystemOperations operation, TBody body)
        {
            return ExecuteHttpRequest<TBody, string>(operation, body, new Dictionary<string, string>());
        }

        public IRestResponse<TResponse> ExecuteHttpRequest<TBody,TResponse>(CustomExternalSystemOperations operation, TBody body) where TResponse : class
        {
            return ExecuteHttpRequest<TBody, TResponse>(operation, body, new Dictionary<string, string>());
        }

        public IRestResponse<TResponse> ExecuteHttpRequest<TResponse>(CustomExternalSystemOperations operation, Dictionary<string, string> endpontParams) where TResponse : class
        {
            return ExecuteHttpRequest<object, TResponse>(operation, new JsonObject(),endpontParams);
        }

        public IRestResponse<TResponse> ExecuteHttpRequest<TBody,TResponse>(CustomExternalSystemOperations operation, TBody body, Dictionary<string, string> endpontParams) where TResponse : class
        {
            if (UseMockConnectionForTagVue)
            {
                IRestResponse<TResponse> response = new RestResponse<TResponse>();
                response.StatusCode = System.Net.HttpStatusCode.OK;
                response.ResponseStatus = ResponseStatus.Completed;
                response.Content = JsonConvert.SerializeObject(body).ToString();
                response.ErrorMessage = string.Empty;
                if (typeof(TResponse) == typeof(string))
                {
                    response.Data = (TResponse)(object)string.Empty;
                }else if (typeof(TResponse).IsInterface || typeof(TResponse).IsAbstract)
                {
                    response.Data = default;
                }
                else
                {
                    response.Data = default(TResponse) ?? Activator.CreateInstance<TResponse>(); 
                }
               
                return response;
            }
            GenericTable genericTable = new();
            genericTable.Load("CustomExternalSystemEndpoints");
            
                genericTable.LoadData(new FilterCollection()
                {
                    new Foundation.BusinessObjects.QueryObject.Filter ()
                    {
                        Name = "Operation",
                        Value = operation.ToString(),
                        Operator  = FieldOperator.IsEqualTo

                    }
                });
            if (genericTable.HasData)
            {
                DataSet customExternalSystemDataSet = NgpDataSet.ToDataSet(genericTable.Data);
                string endPoint = string.Empty;
                string httpVerb = string.Empty;
                if (customExternalSystemDataSet.Tables != null && customExternalSystemDataSet.Tables.Count > 0 &&
                  customExternalSystemDataSet.Tables[0].Rows != null && customExternalSystemDataSet.Tables[0].Rows.Count > 0)
                {
                    DataRow row = customExternalSystemDataSet.Tables[0].Rows[0];
                    if (row[LamConstants.GenericTableCustomExternalSysEndPointProperty] != DBNull.Value &&
                            row[LamConstants.GenericTableCustomExternalSysEndPointProperty] != null)
                    {
                        endPoint = row[LamConstants.GenericTableCustomExternalSysEndPointProperty].ToString();
                    }
                    if (row[LamConstants.GenericTableCustomExternalSysHttpVerbProperty] != DBNull.Value &&
                       row[LamConstants.GenericTableCustomExternalSysHttpVerbProperty] != null)
                    {
                        httpVerb = row[LamConstants.GenericTableCustomExternalSysHttpVerbProperty].ToString();
                    }
                }
                foreach (var @params in endpontParams)
                {
                    endPoint = endPoint.Replace("{"+@params.Key+"}", @params.Value);
                }
                var request = new RestRequest(endPoint, Enum.Parse<Method>(httpVerb)).AddJsonBody(JsonConvert.SerializeObject(body));
                request.AddHeader("Content-Type", "application/json");
                restClient.Authenticator = authenticator;
                var response = restClient.Execute<TResponse>(request);
                response.ErrorMessage = response.Headers.FirstOrDefault(header => "X-Status-Description".Equals(header.Name, StringComparison.Ordinal))?.Value?.ToString();
                return response;
            }
            throw new CmfBaseException(
                        string.Format(
                            _localizationService.Localize(
                                Thread.CurrentThread.CurrentCulture.Name,
                                LocalizedMessages.CustomNoExternalEndpointFound
                            )
                        ));
        }

        
    }
}
