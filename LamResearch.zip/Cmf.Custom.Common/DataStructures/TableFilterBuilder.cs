﻿using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessObjects.QueryObject;
using Cmf.Foundation.BusinessObjects.QueryObject.Enums;
using Cmf.Foundation.Common;
using DocumentFormat.OpenXml.InkML;
using DocumentFormat.OpenXml.Spreadsheet;
using Stimulsoft.Report.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;
using Field = Cmf.Foundation.BusinessObjects.QueryObject.Field;

namespace Cmf.Custom.Lam.Common.DataStructures
{
    public class TableFilterBuilder
    {
        private readonly FilterCollection filterCollection;
        private readonly FieldCollection fieldCollection;
        private readonly RelationCollection relationCollection;
        public TableFilterBuilder()
        {
            filterCollection= new FilterCollection();
            fieldCollection = new FieldCollection();
            relationCollection = new RelationCollection();
        }
        /// <summary>
        /// Add Filter condition to FilterCollection
        /// </summary>
        /// <typeparam name="TValue">type of the filter by value</typeparam>
        /// <param name="name">column name</param>
        /// <param name="value">filter based on this value</param>
        /// <param name="fieldOperator">define how to compare values, default is IsEqualTo</param>
        /// <param name="logicalOperator">define logical connection between filter elements, default value is AND</param>
        /// <returns></returns>
        public TableFilterBuilder AddFilter<TValue>(string name,TValue value,FieldOperator fieldOperator = FieldOperator.IsEqualTo, LogicalOperator logicalOperator=LogicalOperator.AND,FilterType filterType=FilterType.Normal)
        {
            return AddFilter(name, value, null, null, fieldOperator, logicalOperator, filterType);
        }
        public TableFilterBuilder AddFilter<TValue>(string name, TValue value, string objectName, FieldOperator fieldOperator = FieldOperator.IsEqualTo, LogicalOperator logicalOperator = LogicalOperator.AND, FilterType filterType = FilterType.Normal)
        {
            return AddFilter(name,value, objectName, null,fieldOperator, logicalOperator, filterType);
        }
        public TableFilterBuilder AddFilter<TValue>(string name, TValue value, string objectName, string objectAlias, FieldOperator fieldOperator = FieldOperator.IsEqualTo, LogicalOperator logicalOperator = LogicalOperator.AND, FilterType filterType = FilterType.Normal)
        {
            var filter = new Foundation.BusinessObjects.QueryObject.Filter
            {
                Name = name,
                ObjectName = objectName,
                ObjectAlias = objectAlias,
                Value = value,
                Operator = fieldOperator,
                LogicalOperator = logicalOperator,
                FilterType = filterType
            };
            filterCollection.Add(filter);
            return this;
        }
        public FilterCollection BuildFilter()
        {
            return filterCollection;
        }

        public TableFilterBuilder AddFieldCollection(string alias,string name, string objectName, string objectAlias, int position=0, bool IsUserAttribute=false, FieldSort fieldSort = FieldSort.NoSort)
        {
            var field = new Field()
            {
                Alias = alias,
                ObjectName = objectName,
                ObjectAlias = objectAlias,
                IsUserAttribute = IsUserAttribute,
                Name = name,
                Position = position,
                Sort = fieldSort
            };
            fieldCollection.Add(field);
            return this;
        }       

        public TableFilterBuilder AddRelationCollection(string sourceEntity, string sourceEntityAlias, string sourceProperty, string targetEntity, string targetEntityAlias, string targetProperty, JoinType targetJoinType=JoinType.InnerJoin, JoinType sourceJoinType=JoinType.InnerJoin, string alias="", string name="",bool isRealation=false)
        {
            var realtion = new Relation()
            {
                Alias = alias,
                IsRelation = isRealation,
                Name = name,
                SourceEntity = sourceEntity,
                SourceEntityAlias = sourceEntityAlias,
                SourceJoinType = sourceJoinType,
                SourceProperty = sourceProperty,
                TargetEntity = targetEntity,
                TargetEntityAlias = targetEntityAlias,
                TargetJoinType = targetJoinType,
                TargetProperty = targetProperty
            };
            relationCollection.Add(realtion);
            return this;
        }

        public IFieldCollection BuildFields()
        {
           return fieldCollection;
        }

        internal IRelationCollection BuildRelations()
        {
            return relationCollection;
        }
    }
}
