﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cmf.Custom.Lam.Common.DataStructures.DatabaseEntities
{
    [XmlRoot(ElementName = "T_GT_TagVueContainerConfiguration")]
    [Serializable]
    public class TagVueContainerConfiguration
    {
        [XmlElement(ElementName = "TagVueContainerConfigurationId")]
        public int TagVueContainerConfigurationId { get; init; }

        [XmlElement(ElementName = "CategoryName")]
        public string CategoryName { get; init; }
        
        [XmlElement(ElementName = "EntityID")]
        public string EntityID { get; init; }

        [XmlElement(ElementName = "NumberOfBarcodes")]
        public int NumberOfBarcodes { get; init; }
    }

    [XmlRoot(ElementName = "NewDataSet")]
    [Serializable]
    public class TagVueContainerConfigurationDbo
    {
        [XmlElement(ElementName = "T_GT_TagVueContainerConfiguration")]
        public List<TagVueContainerConfiguration> Entries { get; init; }
    }
}
