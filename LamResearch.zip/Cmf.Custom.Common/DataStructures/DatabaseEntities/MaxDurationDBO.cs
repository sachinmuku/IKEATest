﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace Cmf.Custom.Lam.Common.DataStructures.DatabaseEntities;
    [XmlRoot(ElementName = "T_ST_CustomProjectMaxDuration")]
    public class ProjectMaxDurationDBO
    {
        [XmlElement(ElementName = "ProjectType")]
        public string ProjectType { get; init; }

        [XmlElement(ElementName = "Project")]
        public string Project { get; init; }

        [XmlElement(ElementName = "ProjectMaxYears")]
        public double ProjectMaxYears { get; init; }

        [XmlElement(ElementName = "ProjectIdleMonths")]
        public double ProjectIdleMonths { get; init; }
    }

    [XmlRoot(ElementName = "NewDataSet")]
    public class ProjectMaxDurationDBOList
    {
        [XmlElement(ElementName = "T_ST_CustomProjectMaxDuration")]
        public List<ProjectMaxDurationDBO> Entries { get; init; }
    }
