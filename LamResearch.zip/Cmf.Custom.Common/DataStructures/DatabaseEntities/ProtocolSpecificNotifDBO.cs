using System.Collections.Generic;
using System.Xml.Serialization;
using Cmf.Custom.Lam.Common.DataStructures.Protocol;

namespace Cmf.Custom.Lam.Common.DataStructures.DatabaseEntities;

[XmlRoot(ElementName = "T_ST_CustomProtocolSpecificNotif")]
public class ProtocolSpecificNotifDBO
{
    [XmlElement(ElementName = "Protocol")]
    public string Protocol { get; init; }

    [XmlElement(ElementName = "FromState")]
    public string FromState { get; init; }

    [XmlElement(ElementName = "ToState")]
    public  string ToState { get; init; }

    [XmlElement(ElementName = "IsMainRecipient")]
    public bool IsMainRecipient { get; init; }

        [XmlElement(ElementName = "RecipientSource")]
    public CustomNotificationRecipientSources RecipientSource { get; init; }

    [XmlElement(ElementName = "SourceName")]
    public string SourceName { get; init; }

    [XmlElement(ElementName = "NotificationTemplate")]
    public string NotificationTemplate { get; init; }
}

[XmlRoot(ElementName = "NewDataSet")]
public class ProtocolSpecificNotifDBOList
{
    [XmlElement(ElementName = "T_ST_CustomProtocolSpecificNotif")]
    public List<ProtocolSpecificNotifDBO> Entries { get; init; }
}