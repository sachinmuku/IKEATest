﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cmf.Custom.Lam.Common.DataStructures.DatabaseEntities
{
    [XmlRoot(ElementName = "T_ST_CustomStepTagVueStationMap")]
    public class EnforceTagVueStationMappingDbo
    {
        [XmlElement(ElementName = "Step")]
        public string Step { get; init; }

        [XmlElement(ElementName = "TagVueStationName")]
        public string TagVueStationName { get; init; }

        [XmlElement(ElementName = "TagVueOperation")]
        public string TagVueOperation { get; init; }

        [XmlElement(ElementName = "MesOperation")]
        public string MesOperation { get; init; }
    }

    [XmlRoot(ElementName = "NewDataSet")]
    public class EnforceTagVueStationMappingDboList
    {
        [XmlElement(ElementName = "T_ST_CustomStepTagVueStationMap")]
        public List<EnforceTagVueStationMappingDbo> Entries { get; init; }
    }
}
