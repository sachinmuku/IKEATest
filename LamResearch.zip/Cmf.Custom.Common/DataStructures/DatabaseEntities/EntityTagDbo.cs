
using Cmf.Foundation.BusinessObjects;
using System;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace Cmf.Custom.Lam.Common.DataStructures.DatabaseEntities
{
    [XmlRoot(ElementName = "T_GT_EntityTag")]
    public class EntityTag
    {
        [XmlElement(ElementName = "EntityId", DataType = "long")]
        public long EntityId { get; init; }

        [XmlElement(ElementName = "EntityTagId",DataType ="long")]
        public long EntityTagId { get; init; }

        [XmlElement(ElementName = "Tag")]
        public string Tag { get; init; }

        [XmlElement(ElementName = "EntityType")]
        public string EntityType { get; init; }

        [XmlElement(ElementName = "EntityName")]
        public string EntityName { get; init; }

        [XmlElement(ElementName = "Scope")]
        public EntityTagScopeDbo Scope { get; init; }

        [XmlElement(ElementName = "ROWID")]
        public int ROWID { get; init; }

        [XmlElement(ElementName = "CreatedBy")]
        public string CreatedBy { get; init; }

        [XmlElement(ElementName = "CreatedOn")]
        public DateTime CreatedOn { get; init; }

        [XmlElement(ElementName = "ModifiedBy")]
        public string ModifiedBy { get; init; }

        [XmlElement(ElementName = "ModifiedOn")]
        public DateTime ModifiedOn { get; init; }

        [XmlElement(ElementName = "LastServiceHistoryId")]
        public long LastServiceHistoryId { get; init; }

        [XmlElement(ElementName = "LastOperationHistorySeq")]
        public int LastOperationHistorySeq { get; init; }
    }

    [XmlRoot(ElementName = "NewDataSet")]
    public class EntityTagDbo
    {
        [XmlElement(ElementName = "T_GT_EntityTag")]
        public List<EntityTag> Entries { get; init; }
    }
}
