﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Cmf.Custom.Lam.Common.DataStructures.DatabaseEntities
{
    [Serializable]
    public enum EntityTagScopeDbo
    {
        [XmlEnum("0")]
        AugmentedReality,
        
        [XmlEnum("1")]
        BarcodeId
    }
}
