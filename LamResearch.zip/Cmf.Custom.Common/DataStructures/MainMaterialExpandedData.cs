﻿using System.Collections.Generic;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.Lam.Common.DataStructures
{
    // <summary>
    // Support class to Materials created by the Expand
    // </summary>
    public class MainMaterialExpandedData
    {
        public IMaterial ParentMaterial { get; set; }
        public IMaterial MaterialMap { get; set; }
        public List<SubMaterialExpandedData> SubMaterials { get; set; }
    }
}
