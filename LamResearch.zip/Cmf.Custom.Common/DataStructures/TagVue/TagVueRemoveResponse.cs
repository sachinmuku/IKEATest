﻿using Newtonsoft.Json;

namespace Cmf.Custom.Lam.Common.DataStructures.TagVue
{
    public class TagVueRemoveResponse
    {
        [JsonProperty("entityid")]
        public int EntityId { get; set; }

        [JsonProperty("epc")]
        public int Epc { get; set; }

        [JsonProperty("info")]
        public int Info { get; set; }
    }
}
