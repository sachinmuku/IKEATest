﻿using Newtonsoft.Json;

namespace Cmf.Custom.Lam.Common.DataStructures.TagVue
{
    public class TagVueAddBarcodeRequest
    {
        [JsonProperty("epc")]
        public string Epc { get; set; }
    }
}
