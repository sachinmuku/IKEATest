﻿using Newtonsoft.Json;

namespace Cmf.Custom.Lam.Common.DataStructures.TagVue
{
    public class TagVueCreateProjectCodeRequest
    {
        [JsonProperty("description", Required = Required.AllowNull)]
        public string Description { get; set; }

        // Project Code Name
        [JsonProperty("name", Required = Required.Always)]
        public string Name { get; set; }

        [JsonProperty("code")]
        public string Code { get; set; }

        [JsonProperty("manager")]
        public TagVueManagerData Manager { get; set; }

        // Project Code Name
        [JsonProperty("entity-id")]
        public string EntityId { get; set; }
    }
}
