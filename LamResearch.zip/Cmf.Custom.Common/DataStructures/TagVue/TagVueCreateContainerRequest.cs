﻿using Newtonsoft.Json;

namespace Cmf.Custom.Lam.Common.DataStructures.TagVue
{

    public class TagVueCreateContainerRequest
    {
        [JsonProperty("class-entity-id", Required = Required.Always)]
        public string ClassEntityId { get; set; }
        [JsonProperty("description", Required = Required.AllowNull)]
        public string Description { get; set; }
        [JsonProperty("group")]
        public string Group { get; set; }
        [JsonProperty("name", Required = Required.Always)]
        public string Name { get; set; }
        [JsonProperty("entity-id")]
        public string EntityId { get; set; }
    }
}
