﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.Lam.Common.DataStructures.TagVue
{
    public class TagVueUpdateCustodian
    {
        [JsonProperty("remove", NullValueHandling = NullValueHandling.Ignore)]
        public bool Remove { get; set; } = false;

        [JsonProperty("username",NullValueHandling = NullValueHandling.Ignore)]
        public string UserName { get; set; }

        [JsonProperty("email", NullValueHandling = NullValueHandling.Ignore)]
        public string Email { get; set; }

        [JsonProperty("employee-id", NullValueHandling = NullValueHandling.Ignore)]
        public string EmployeeId { get; set; }

        [JsonProperty("entity-id", NullValueHandling = NullValueHandling.Ignore)]
        public string EntityId { get; set; }

        [JsonProperty("tv-id", NullValueHandling = NullValueHandling.Ignore)]
        public uint? TvId { get; set; }
    }
}
