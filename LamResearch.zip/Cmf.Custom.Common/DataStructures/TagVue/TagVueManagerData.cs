﻿using Newtonsoft.Json;

namespace Cmf.Custom.Lam.Common.DataStructures.TagVue
{
    public class TagVueManagerData
    {
        [JsonProperty("name")]
        public string Name { get; set; }

        [JsonProperty("username")]
        public string Username { get; set; }

        [JsonProperty("email")]
        public string Email { get; set; }

        [JsonProperty("employee-id")]
        public string EmployeeId { get; set; }

        [JsonProperty("entity-id")]
        public string EntityId { get; set; }

        [JsonProperty("tv-id")]
        public string TvId { get; set; }
    }
}
