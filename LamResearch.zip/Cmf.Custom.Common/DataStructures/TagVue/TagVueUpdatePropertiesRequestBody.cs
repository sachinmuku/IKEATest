﻿using Newtonsoft.Json;

namespace Cmf.Custom.Lam.Common.DataStructures.TagVue
{
    public class TagVueUpdatePropertiesRequestBody
    {
        [JsonProperty("op")]
        public object Op { get; set; }

        [JsonProperty("value")]
        public TagVueUpdatePropertiesRequestBodyValue Value { get; set; }

        [JsonProperty("path")]
        public string Path { get; set; }
    }

    public class TagVueUpdatePropertiesRequestBodyValue
    {
        [JsonProperty("entity-id")]
        public string EntityId { get; set; }
    }
}
