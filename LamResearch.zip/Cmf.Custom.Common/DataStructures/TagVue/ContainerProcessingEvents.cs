﻿
namespace Cmf.Custom.Lam.Common.DataStructures.TagVue
{
    public enum ContainerProcessingEvents
    {
        Processed,
        PickedUp
    }
}
