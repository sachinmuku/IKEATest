﻿namespace Cmf.Custom.Lam.Common.DataStructures.Protocol;

public enum CustomNotificationRecipientSources
{
    ProtocolParameter,
    Requester,
    RequesterManager,
    Role,
    Employee
}
