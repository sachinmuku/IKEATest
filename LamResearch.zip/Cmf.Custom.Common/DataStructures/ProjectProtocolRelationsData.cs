﻿using Cmf.Custom.Lam.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.Lam.Common.DataStructures
{
    public class ProjectProtocolRelationsData
    {
        public ICustomProjectCodeCollection ProjectCodes { get; set; }
        public IProductionOrderCollection ProductionOrders { get; set; }
        public IProductCollection Products { get; set; }
        public IMaterialCollection Materials { get; set; }
    }
}