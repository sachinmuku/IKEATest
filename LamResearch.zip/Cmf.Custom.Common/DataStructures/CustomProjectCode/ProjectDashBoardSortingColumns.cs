﻿
namespace Cmf.Custom.Lam.Common.DataStructures
{
    public enum SortingColumns
    {
        ProjectId = 0,
        ProductLine = 2,
        Application = 4,
        DemoDate = 6,
        DemoCompletionDate = 8,
        ProjectPriority = 10,
        BusinessUnit = 12,
        ProjectTitle = 14,
        Region = 16,
        SubGroup = 18,
        ProductGroup = 20,
        Description = 22,
        IONumber = 24,
        Requester = 26,
        DemoType = 28,
        Engineer = 30,
        Resources = 32,
        ProjectCompletionDate = 34,
        Customer = 36,
        Fab = 38,
        DataLocation = 40,
    }
}
