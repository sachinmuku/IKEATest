﻿using System.Collections.Generic;

namespace Cmf.Custom.Lam.Common.DataStructures
{
    // <summary>
    // Support class to Materials created by the Expand
    // </summary>
    public class SubMaterialExpandedData
    {
        public string Suffix { get; set; }
        public List<SubMaterialPositionQuantityData> PositionsQuantities { get; set; }
        public bool IsPrimaryQuantity { get; set; }
        public bool IsSecondaryQuantity { get; set; }
        public string Form { get; set; }
    }
}
