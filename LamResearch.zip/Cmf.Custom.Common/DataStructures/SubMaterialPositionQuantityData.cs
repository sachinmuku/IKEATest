﻿namespace Cmf.Custom.Lam.Common.DataStructures
{
    // <summary>
    // Support class to information for each Material created by the Expand
    // </summary>
    public class SubMaterialPositionQuantityData
    {
        public int Position { get; set; }
        public string UnitId { get; set; }
        public decimal Quantity { get; set; }
        public bool IsMarked { get; set; }
    }
}
