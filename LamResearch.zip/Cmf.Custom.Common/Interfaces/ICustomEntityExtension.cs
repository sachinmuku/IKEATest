﻿using Cmf.Foundation.BusinessObjects.Abstractions;

namespace Cmf.Custom.Lam.Common.Interfaces
{
    public interface ICustomEntityExtension<T>
    {
        IStateModel GetDefaultStateModel();

        void SetName(ref T entity);
    }
}
