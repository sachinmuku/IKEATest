﻿using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Foundation.Security;
using Cmf.Foundation.Security.Abstractions;
using Cmf.Navigo.BusinessObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.Lam.Common.Interfaces
{
    public interface ICustomProjectDefaultAccessRolesAssignment
    {
        /// <summary>
        /// Assign datagroup to entity with save to database
        /// </summary>
        /// <param name="entity"></param>
        public void AssignTo(IEntity entity);
        /// <summary>
        /// Assign datagroup to entity based on isSaveToDb parameter save to database
        /// </summary>
        /// <param name="entity"></param>
        /// <param name="isSaveToDb"></param>
        public void AssignTo(IEntity entity,bool isSaveToDb);
    }
}
