﻿using Cmf.Custom.Lam.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Security;
using Cmf.Foundation.Security.Abstractions;
using Cmf.Navigo.BusinessObjects.Abstractions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.Lam.Common.Interfaces
{
    public interface ICustomProjectDefaultAccessRoles : ICustomProjectDefaultAccessRolesAssignment
    {
        /// <summary>
        /// Create DataGroup based on an entity from configuration
        /// </summary>
        /// <param name="entity"></param>
        public void Create(IEntity entity);

        /// <summary>
        /// Create or load datagroup on entity based on dataGroupName
        /// </summary>
        /// <param name="entity"></param>
        /// <param name="dataGroupName"></param>
        public void Create(IEntity entity,string dataGroupName);
        /// <summary>
        /// Load relation for entity by relationName
        /// </summary>
        /// <param name="entity"></param>
        /// <param name="relationName"></param>
        public void LoadDataGroupFromRelations(IEntity entity,params string[] relationNames);

        /// <summary>
        /// Assign datagroup to entity with predefinedDatagroupId
        /// </summary>
        /// <param name="entity"></param>
        /// <param name="predefinedDataGroupId"></param>
        public void AssignTo(IEntity entity, long? predefinedDataGroupId);
    }
}
