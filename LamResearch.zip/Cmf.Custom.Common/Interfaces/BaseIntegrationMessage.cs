﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.Lam.Common.Interfaces.Inbound
{
    public abstract class BaseIntegrationMessage
    {
        // Look for private and public variables
        private BindingFlags propertyFlags = BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance;

        protected SortedSet<string> MandatoryFields = new SortedSet<string>();

        public virtual void SetMandatoryFields() { }

        public BaseIntegrationMessage()
        {
            
        }

        public void ValidateMissingFields()
        {
            MandatoryFields.Clear();
            SetMandatoryFields();
            if (IsMandatoryFieldMissing())
            {
                throw new Exception($"Mandatory field(s) missing: {string.Join(",", MandatoryFieldsMissing().Select(p => p.Name))}");
            }
        }

        public virtual bool IsMandatoryFieldMissing()
        {
            bool isAnyPropEmpty = false;

            isAnyPropEmpty = GetType().GetProperties(propertyFlags)
             .Where(p => MandatoryFields.Contains(p.Name))
             .Any(p => ObjectIsNull(p));

            return isAnyPropEmpty;
        }

        public virtual IEnumerable<PropertyInfo> MandatoryFieldsMissing()
        {
            var mandatoryFieldsMissing = GetType().GetProperties(propertyFlags)
             .Where(p => MandatoryFields.Contains(p.Name) && ObjectIsNull(p));

            return mandatoryFieldsMissing;
        }

        protected bool ObjectIsNull(PropertyInfo property)
        {
            object value = property.GetValue(this);

            // Check for Null or Empty on String
            if (property.PropertyType == typeof(string))
                return string.IsNullOrWhiteSpace((string)value);

            return Equals(property.GetValue(this), GetDefaultValue(property.PropertyType));
        }

        protected static object GetDefaultValue(Type type)
        {
            return type.IsValueType ? Activator.CreateInstance(type) : null;
        }
    }
}
