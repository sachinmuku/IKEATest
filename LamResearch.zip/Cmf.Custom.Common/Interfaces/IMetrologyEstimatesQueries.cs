﻿using Cmf.Custom.Lam.BusinessObjects.Abstractions;

namespace Cmf.Custom.Lam.Common.Interfaces
{
    public interface IMetrologyEstimatesQueries
    {
        ICustomProjectMetrologyEstimatesCollection GetMetrologyEstimatesByProtocolInstance(long protocolInstanceId);
    }
}
