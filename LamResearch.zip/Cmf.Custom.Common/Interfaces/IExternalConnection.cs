﻿
using Cmf.Custom.Lam.Common.Constants;
using RestSharp;
using RestSharp.Authenticators;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.Lam.Common.Interfaces
{
    public interface IExternalConnection
    {
        IRestResponse<TResponse> ExecuteHttpRequest<TBody, TResponse>(CustomExternalSystemOperations operation, TBody body) where TResponse : class;
        IRestResponse<TResponse> ExecuteHttpRequest<TBody, TResponse>(CustomExternalSystemOperations operation, TBody body, Dictionary<string, string> endpontParams) where TResponse : class;
        IRestResponse<TResponse> ExecuteHttpRequest<TResponse>(CustomExternalSystemOperations operation, Dictionary<string, string> endpontParams) where TResponse : class;
        IRestResponse ExecuteHttpRequest<TBody>(CustomExternalSystemOperations operation, TBody body);
        public AuthenticatorBase Authenticator { get; set; }
    }
}
