﻿using Cmf.Foundation.Common.LocalizationService;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.Lam.Common.Interfaces.Inbound
{
    public class LastSeenLocationMessage : BaseIntegrationMessage
    {
        public string EventTimeStamp { get; set; }
        public string ItemName { get; set; }
        public string NewLocationName { get; set; }
        public string PreviousLocationName { get; set; }

        public static LastSeenLocationMessage CreateFromJson(string json)
        {
            return JsonConvert.DeserializeObject<LastSeenLocationMessage>(json);
        }

        public override void SetMandatoryFields()
        {
            MandatoryFields.Add(nameof(ItemName));
            MandatoryFields.Add(nameof(NewLocationName));
        }

    }


}
