﻿using Newtonsoft.Json;
using Stimulsoft.System.Windows.Forms;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.Lam.Common.Interfaces.Inbound
{
    public abstract class InboundMessage : BaseIntegrationMessage
    {
        protected InboundMessage CreateFromJson(string json) 
        {
            return JsonConvert.DeserializeObject<InboundMessage>(json);
        }
    }
}
