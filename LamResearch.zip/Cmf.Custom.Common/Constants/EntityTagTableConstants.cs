﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.Lam.Common.Constants
{
    public class EntityTagTableConstants
    {
        public const string TableName = "EntityTag";
        public const string ScopeColumnName = "Scope";
        public const string EntityNameColumnName = "EntityName";
        public const string EntityTypeColumnName = "EntityType";
        public const string TagColumnName = "Tag";
    }
}
