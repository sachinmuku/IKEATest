﻿namespace Cmf.Custom.Lam.Common.Constants
{
    public static partial class LamResearchConstants
    {
        public struct LocalizedMessages
        {
            /// <summary>
            /// The authentication in {0} failed. Please validate if the system is available, and if the MES connection configs are accordingly.
            /// </summary>
            public const string CustomAuthenticationFailed = "CustomAuthenticationFailed";

            /// <summary>
            /// No external endpoint found.
            /// </summary>
            public const string CustomNoExternalEndpointFound = "CustomNoExternalEndpointFound";
            public const string TagVueCreateContainerException = "TagVueCreateContainerException";
            public const string ApiKeyNotFound = "ApiKeyNotFound";
            public const string SecurityTokenNotFound = "SecurityTokenNotFound";
            public const string ErrorInCreateContainersTagVue = "ErrorInCreateContainersTagVue";
            public const string TagVueBarcodeCreationFailed = "TagVueBarcodeCreationFailed";
            public const string TagVueBarcodeRemoveFailed = "TagVueBarcodeRemoveFailed";
            public const string UseMockConnectionForTagVue = "UseMockConnectionForTagVue";
            public const string TagVueSystemNotAvailable = "TagVueSystemNotAvailable";
            public const string TagVueUpdatePropertiesRequestFailed = "TagVueUpdatePropertiesRequestFailed";
            public const string TagVueUpdateCustodianRequestFailed = "TagVueUpdateCustodianRequestFailed";
            public const string MissingIntegrationMessage = "MissingIntegrationMessage";
            public const string ContainerNotFound = "ContainerNotFound";
            public const string ContainerNotFoundInMES = "ContainerNotFoundInMES";
            public const string ContainerIsEmpty = "ContainerIsEmpty";
            public const string ContainerIsNotAtStation = "ContainerIsNotAtStation";
            public const string OperationNotAllowedForCoantainer = "OperationNotAllowedForCoantainer";
            public const string CannotDispatchMultipleResources = "CannotDispatchMultipleResources";
            public const string CannotStoreMultipleResources = "CannotStoreMultipleResources";
            public const string TagVueBarcodeUpdateNotSupported = "TagVueBarcodeUpdateNotSupported";
            public const string UserIsNotInAdministratorsRole = "UserIsNotInAdministratorsRole";
            public const string UserIsNotAllowedToAssign = "UserIsNotAllowedToAssign";
            public const string ProductionOrderNotFound = "ProductionOrderNotFound";
            public const string TagVueMesManualOperationException = "TagVueMesManualOperationException";
        }
    }
}
