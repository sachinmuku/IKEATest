﻿
namespace Cmf.Custom.Lam.Common.Constants
{
    public enum CustomExternalSystemOperations
    {
        None,
        CreateContainer,
        AssociateTags,
        AssignCustodian,
        AddBarCode,
        RemoveBarCode,
        CreateProjectCode,
        DeleteProjectCode,
        UpdateProperties,
        UpdateCustodian,
        UpdateAttributes
    }
}
