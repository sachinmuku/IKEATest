﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.Lam.Common.Constants
{
    public static class TagVueGenericTableContants
    {
        public const string GenericTableName = "TagVueContainerConfiguration";
        public const string CatergoryColumnName = "CategoryName";
        public const string EntityIdColumnName  = "EntityID";
        public const string NumberOfBarcodes  = "NumberOfBarcodes";
    }
}
