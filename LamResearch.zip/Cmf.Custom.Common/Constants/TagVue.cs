﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.Lam.Common.Constants
{
    public struct TagVue
    {


        public struct GenericTables
        {
            public const string Name = "TagVueContainerConfiguration";
            public const string CatergoryColumnName = "CategoryName";
            public const string EntityIdColumnName = "EntityID";
            public const string NumberOfBarcodes = "NumberOfBarcodes";
        }

        public struct SmartTables
        {
            public struct Name
            {
                public const string CustomStepTagVueStationMap = "CustomStepTagVueStationMap";
            }

            public struct Columns
            {
                public const string StationName = "TagVueStationName";
                public const string Operation = "TagVueOperation";
                public const string MESOperation = "MesOperation";
            }

        }
    }
}
