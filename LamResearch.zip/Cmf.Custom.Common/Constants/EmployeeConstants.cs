﻿

namespace Cmf.Custom.Lam.Common.Constants
{
    public static class EmployeeConstants
    {
        public static class Attributes
        {
            public const string AssignedRolesName = "AssignedRoles";
        }
    }
}
