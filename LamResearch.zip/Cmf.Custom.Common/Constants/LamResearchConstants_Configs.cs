﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.Lam.Common.Constants
{
    public static partial class LamResearchConstants
    {
        public struct Configs
        {
            public static string ExternalSystemDomain = "/LamResearch/ExternalSystems/TagVue/Domain";
            public static string SecurityToken = "/LamResearch/ExternalSystems/TagVue/SecurityToken";
            public static string ApiKey = "/LamResearch/ExternalSystems/TagVue/ApiKey";
            public static string UseMockConnectionForTagVue = "/LamResearch/ExternalSystems/TagVue/UseMockConnectionForTagVue";
        }
    }
}
