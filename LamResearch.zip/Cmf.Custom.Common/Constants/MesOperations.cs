﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.Lam.Common.Constants
{
    public struct MesOperations
    {
        public const string Dispatch = "Dispatch";
        public const string TrackIn = "TrackIn";
        public const string TrackOut = "TrackOut";
        public const string MoveNext = "MoveNext";
        public const string Store = "Store";
        public const string Retrieve= "Retrieve";

    }
}
