﻿using Cmf.Foundation.BusinessObjects;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.Lam.Common.Constants
{
    public static class CustomBOMAttachContextSmartTable
    {
        private const string MaterialColumn = "Material";
        public const string CustomBOMAttachContextName = "CustomBOMAttachContext";
        private const string StepColumn = "Step";
        private const string LogicalFlowPathColumn = "LogicalFlowPath";
        private const string ProductColumn = "Product";
        private const string ProductGroupColumn = "ProductGroup";
        private const string FlowColumn = "Flow";
        public const string BOMColumn = "BOM";
        public const string QuantityModeColumn = "QuantityMode";

        public static NgpDataRow ResolveInputs(IMaterialCollection materials)
        {
            NgpDataRow smartTableInput = new();
            foreach (var material in materials)
            {
                if (material.Step.Name != null && material.Step.Name.Any())
                    {
                        smartTableInput.TryAdd(StepColumn, material.Step.Name);
                    }
                
                 if (material.LogicalFlowPath != null && material.LogicalFlowPath.Any())
                    {
                        smartTableInput.TryAdd(LogicalFlowPathColumn, material.LogicalFlowPath);
                    }
                
                 if (material.Product.Name != null && material.Product.Name.Any())
                    {
                        smartTableInput.TryAdd(ProductColumn, material.Product.Name);
                    }
                
                 if (material.Product.ProductGroup?.Name != null && material.Product.ProductGroup?.Name.Length > 0)
                    {
                        smartTableInput.TryAdd(ProductGroupColumn, material.Product.ProductGroup?.Name);
                    }
                
                if (material.Flow.Name != null && material.Flow.Name.Any())
                    {
                        smartTableInput.TryAdd(FlowColumn, material.Flow.Name);
                    }
                if (material.Name != null && material.Name.Any())
                    {
                        smartTableInput.TryAdd(MaterialColumn, material.Name);
                    }
            }
            return smartTableInput;
        }
        public static NgpDataRow ResolveInputs(IMaterial material)
        {
            NgpDataRow smartTableInput = new();
            if (material.Step.Name != null)
            {
                smartTableInput.Add(StepColumn, material.Step.Name);
            }

            if (material.LogicalFlowPath != null)
            {
                smartTableInput.Add(LogicalFlowPathColumn, material.LogicalFlowPath);
            }
            
            if (material.Product.Name != null)
            {
                smartTableInput.Add(ProductColumn, material.Product.Name);
            }
            
            if (material.Product.ProductGroup?.Name != null)
            {
                smartTableInput.Add(ProductGroupColumn, material.Product.ProductGroup?.Name);
            }
            
            if (material.Flow.Name != null)
            {
                smartTableInput.Add(FlowColumn, material.Flow.Name);
            }
            
            if (material.Name != null)
            {
                smartTableInput.Add(MaterialColumn, material.Name);
            }

            return smartTableInput;
        }
    }
}
