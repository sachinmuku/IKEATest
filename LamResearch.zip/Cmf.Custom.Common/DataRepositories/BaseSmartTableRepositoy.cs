﻿using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common.Base;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Serialization;

namespace Cmf.Custom.Lam.Common.DataRepositories
{
    public abstract class BaseSmartTableRepository
    {
        protected BaseSmartTableRepository(ISmartTable smartTable)
        {
            SmartTable = smartTable;
        }

        public ISmartTable SmartTable { get; }

        protected void LoadTable(string smartTableName) 
        {
            if (string.IsNullOrEmpty(SmartTable.Name))
            {
                SmartTable.Name = smartTableName;
                SmartTable.Load();
            }
        }
        protected T ResolveData<T>(NgpDataRow resolveValuePairs)
        {
            SmartTable.Load();
            SmartTable.LoadProperties();
            var keyColumns = SmartTable.SmartTableProperties.Where(prop=>prop.IsKey && prop.UniversalState == UniversalState.Active).
                Select(prop=>prop.Name).ToList();
            var resolveValues = resolveValuePairs.Where(vp => keyColumns.Contains(vp.Key));
            INgpDataRow ngpDataRow = new NgpDataRow();
            foreach (KeyValuePair<string, object> item in resolveValues)
            {
                ngpDataRow.Add(item);
            }
            var ngpDataSet = SmartTable.Resolve(ngpDataRow, false);
            XmlSerializer serializer = new(typeof(T));
            using StringReader reader = new(ngpDataSet.DataXML);
            return (T)serializer.Deserialize(reader);
        }

        protected T LoadData<T>(IFilterCollection filters)
        {
            SmartTable.Load();
            SmartTable.LoadProperties();
            SmartTable.LoadData(filters);
            XmlSerializer serializer = new(typeof(T));
            using StringReader reader = new(SmartTable.Data.DataXML);
            return (T)serializer.Deserialize(reader);
        }
    }
}