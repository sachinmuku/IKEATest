﻿using Cmf.Custom.Lam.Common.DataStructures.DatabaseEntities;
using System.Collections.Generic;

namespace Cmf.Custom.Lam.Common.DataRepositories
{
    public interface IProjectMaxDurationRepository
    {
        ProjectMaxDurationDBOList GetAllProjects();
        ProjectMaxDurationDBOList GetAllProjectTypes();
        void DeleteRow(string project);
    }
}