﻿using Cmf.Custom.Lam.Common.DataStructures.DatabaseEntities;
using Cmf.Custom.Lam.Common.Extensions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessObjects.QueryObject;
using Microsoft.CodeAnalysis;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Cmf.Custom.Lam.Common.DataRepositories;

    public class ProjectMaxDurationRepository : BaseSmartTableRepository, IProjectMaxDurationRepository
    {
        public ProjectMaxDurationRepository(ISmartTable smartTable) : base(smartTable)
        {
            SmartTable.Name = LamConstants.SmartTables.ProjectMaxDuration.TableName;
        }

    public void DeleteRow(string project)
    {
        SmartTable.Load();
                        SmartTable.LoadData(new FilterCollection()
            {
                    new Filter() {
                        Name = nameof(ProjectMaxDurationDBO.Project),
                        Operator = Foundation.Common.FieldOperator.IsEqualTo,
                        Value = project,
                    },
            });
        SmartTable.RemoveRows(SmartTable.Data);
    }

    public ProjectMaxDurationDBOList GetAllProjects()
        {
            SmartTable.Load();
            SmartTable.LoadData(new FilterCollection()
            {
                    new Filter() {
                        Name = nameof(ProjectMaxDurationDBO.ProjectType),
                        Operator = Foundation.Common.FieldOperator.IsNull,
LogicalOperator = Foundation.Common.LogicalOperator.AND
                    },
                                        new Filter() {
                        Name = nameof(ProjectMaxDurationDBO.Project),
                        Operator = Foundation.Common.FieldOperator.IsNotNull
                    },
            });
            return SmartTable.Data.Serialize<ProjectMaxDurationDBOList>();
    }

        public ProjectMaxDurationDBOList GetAllProjectTypes()
        {
            SmartTable.Load();
            SmartTable.LoadData(new FilterCollection()
            {
                    new Filter() {
                        Name = nameof(ProjectMaxDurationDBO.ProjectType),
                        Operator = Foundation.Common.FieldOperator.IsNotNull,
LogicalOperator = Foundation.Common.LogicalOperator.AND
                    },
                                        new Filter() {
                        Name = nameof(ProjectMaxDurationDBO.Project),
                        Operator = Foundation.Common.FieldOperator.IsNull
                    },
            });
            return SmartTable.Data.Serialize<ProjectMaxDurationDBOList>();
        }
    }
