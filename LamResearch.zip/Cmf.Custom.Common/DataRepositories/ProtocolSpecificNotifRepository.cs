using Cmf.Custom.Lam.Common.DataStructures.DatabaseEntities;
using Cmf.Custom.Lam.Common.Extensions;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessObjects.QueryObject;
using Cmf.Foundation.Common.Helpers;

namespace Cmf.Custom.Lam.Common.DataRepositories;

public class ProtocolSpecificNotifRepository : BaseSmartTableRepository, IProtocolSpecificNotifRepository
{
    public ProtocolSpecificNotifRepository(ISmartTable smartTable) : base(smartTable)
    {
        SmartTable.Name = LamConstants.SmartTables.CustomProtocolSpecificNotifications.TableName;
    }

    public ProtocolSpecificNotifDBOList GetAllRecipientsSortedByMainRecipient(string protocol, string fromState, string toState)
    {
        SmartTable.Load();
        FilterCollection filters = new FilterCollection()
            {
                    new Filter() {
                        Name = nameof(ProtocolSpecificNotifDBO.Protocol),
                        Operator = Foundation.Common.FieldOperator.IsEqualTo,
                        Value = protocol,
LogicalOperator = Foundation.Common.LogicalOperator.AND
                    },
            };
            if(!string.IsNullOrEmpty(fromState))
            {
                filters.Add(new Filter() {
                        Name = nameof(ProtocolSpecificNotifDBO.FromState),
                        Operator = Foundation.Common.FieldOperator.IsEqualTo,
                        Value = fromState,
LogicalOperator = Foundation.Common.LogicalOperator.AND
                    });
            }
            if(!string.IsNullOrEmpty(toState))
            {
                                                            filters.Add(new Filter() {
                        Name = nameof(ProtocolSpecificNotifDBO.ToState),
                        Operator = Foundation.Common.FieldOperator.IsEqualTo,
                        Value = toState,
LogicalOperator = Foundation.Common.LogicalOperator.AND
                    });
            }
        SmartTable.LoadData(new SortingObjectCollection() {
                new SortingObject()
                {
                        Name = nameof(ProtocolSpecificNotifDBO.IsMainRecipient),
                    Sort = Foundation.Common.FieldSort.Descending
                }
            }, filters);
        return SmartTable.Data.Serialize<ProtocolSpecificNotifDBOList>();
    }

    public ProtocolSpecificNotifDBOList GetMainRecipients(string protocol, string fromState, string toState)
    {
        throw new System.NotImplementedException();
    }

    public ProtocolSpecificNotifDBOList GetSecondaryRecipients(string protocol, string fromState, string toState)
    {
        throw new System.NotImplementedException();
    }
}
