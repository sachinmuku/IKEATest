using Cmf.Custom.Lam.Common.DataStructures.DatabaseEntities;

namespace Cmf.Custom.Lam.Common.DataRepositories;

public interface IProtocolSpecificNotifRepository
{
    ProtocolSpecificNotifDBOList GetMainRecipients(string protocol, string fromState, string toState);
    ProtocolSpecificNotifDBOList GetSecondaryRecipients(string protocol, string fromState, string toState);
    ProtocolSpecificNotifDBOList GetAllRecipientsSortedByMainRecipient(string protocol, string fromState, string toState);
}