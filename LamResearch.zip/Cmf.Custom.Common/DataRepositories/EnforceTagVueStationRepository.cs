﻿using Cmf.Custom.Lam.Common.DataStructures.DatabaseEntities;
using Cmf.Custom.Lam.Common.Extensions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessObjects.QueryObject;
using System.Collections.Generic;
using System.Linq;

namespace Cmf.Custom.Lam.Common.DataRepositories
{
    public class EnforceTagVueStationMappingRepository : BaseSmartTableRepository, IEnforceTagVueStationMappingRepository
    {
        public EnforceTagVueStationMappingRepository(ISmartTable smartTable) : base(smartTable)
        {
            SmartTable.Name = "CustomStepTagVueStationMap";
        }

        public IReadOnlyList<EnforceTagVueStationMappingDbo> GetBy(string step)
        {
            SmartTable.Load();
            SmartTable.LoadData(new FilterCollection()
            {
                    new Filter() {
                        Name = nameof(EnforceTagVueStationMappingDbo.Step),
                        Value = step,
                        Operator = Foundation.Common.FieldOperator.IsEqualTo
                    },
            });
            return SmartTable.Data.Serialize<EnforceTagVueStationMappingDboList>().Entries;
        }

        public IReadOnlyList<EnforceTagVueStationMappingDbo> GetBy(string step, string stationName, string tagVueOperationName)
        {
            NgpDataRow resolveValuePairs = new()
            {
                { nameof(EnforceTagVueStationMappingDbo.Step), step },
                { nameof(EnforceTagVueStationMappingDbo.TagVueStationName), stationName },
                { nameof(EnforceTagVueStationMappingDbo.TagVueOperation), tagVueOperationName }
            };
            return ResolveData<EnforceTagVueStationMappingDboList>(resolveValuePairs).Entries;
        }

        public EnforceTagVueStationMappingDbo GetByStepAndTagVueStation(string Step, string TagVueStation)
        {
            SmartTable.Load();
            IReadOnlyList<EnforceTagVueStationMappingDbo> test = SmartTable.PartialResolve(new NgpDataRow {
                { nameof(EnforceTagVueStationMappingDbo.Step), Step },
                { nameof(EnforceTagVueStationMappingDbo.TagVueStationName), TagVueStation }
            }, true).Serialize<EnforceTagVueStationMappingDboList>().Entries;
            return test.FirstOrDefault();
        }
    }
}
