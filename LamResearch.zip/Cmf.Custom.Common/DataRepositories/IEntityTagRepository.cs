﻿using Cmf.Custom.Lam.Common.DataStructures.DatabaseEntities;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.QueryObject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.Lam.Common.DataRepositories
{
    public interface IEntityTagRepository
    {
        EntityTagDbo Get(FilterCollection filterData);

        EntityTagDbo GetByTagName(string tag);

        EntityTagDbo GetByContainerName(string containerName);
    }
}
