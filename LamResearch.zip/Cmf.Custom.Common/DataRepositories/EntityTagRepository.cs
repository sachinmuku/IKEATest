﻿using Cmf.Custom.Lam.Common.Constants;
using Cmf.Custom.Lam.Common.DataStructures;
using Cmf.Custom.Lam.Common.DataStructures.DatabaseEntities;
using Cmf.Custom.Lam.Common.Extensions;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessObjects.GenericTables;
using Cmf.Foundation.BusinessObjects.QueryObject;
using Cmf.Foundation.BusinessOrchestration.Abstractions;
using Cmf.Navigo.Common;
using DocumentFormat.OpenXml.Spreadsheet;
using Stimulsoft.Base.Gauge.GaugeGeoms;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.Lam.Common.DataRepositories
{
    public class EntityTagRepository : IEntityTagRepository
    {
        IGenericTable _genericTable;

        public EntityTagRepository(IGenericTable genericTable) 
        { 
            _genericTable = genericTable;
        }

        public EntityTagDbo Get(FilterCollection filters)
        {
            LoadTable();
            var result = _genericTable.Filter<EntityTagDbo>(filters);
            return result;
        }

        public EntityTagDbo GetByTagName(string tag)
        {
            var filters = new TableFilterBuilder()
                .AddFilter(EntityTagTableConstants.TagColumnName, tag)
                .AddFilter(EntityTagTableConstants.EntityTypeColumnName, "Container")
                .AddFilter(EntityTagTableConstants.ScopeColumnName, (int)EntityTagScope.BarcodeId).BuildFilter();

            return Get(filters);
        }

        public EntityTagDbo GetByContainerName(string containerName)
        {
            var filters = new TableFilterBuilder()
                .AddFilter(EntityTagTableConstants.EntityNameColumnName, containerName)
                .AddFilter(EntityTagTableConstants.EntityTypeColumnName, "Container")
                .AddFilter(EntityTagTableConstants.ScopeColumnName, (int)EntityTagScope.BarcodeId).BuildFilter();

            return Get(filters);
        }

        private void LoadTable()
        {
            _genericTable.Name = EntityTagTableConstants.TableName;
            _genericTable.Load();
        }
    }

}
