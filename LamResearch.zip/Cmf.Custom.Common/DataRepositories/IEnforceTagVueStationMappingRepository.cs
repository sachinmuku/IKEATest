﻿using Cmf.Custom.Lam.Common.DataStructures.DatabaseEntities;
using System.Collections.Generic;

namespace Cmf.Custom.Lam.Common.DataRepositories
{
    public interface IEnforceTagVueStationMappingRepository
    {
        public IReadOnlyList<EnforceTagVueStationMappingDbo> GetBy(string Step);
        public EnforceTagVueStationMappingDbo GetByStepAndTagVueStation(string Step, string TagVueStation);
        public IReadOnlyList<EnforceTagVueStationMappingDbo> GetBy(string step, string stationName, string operationName);
    }

}