﻿using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessObjects;
using System.Data;
using System.Linq;
using Cmf.Custom.Lam.Common.DataStructures;
using Cmf.Common.CustomActionUtilities;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.Common.Base;
using Cmf.Foundation.Common;
using System.Collections.Generic;
using System;
using Cmf.Foundation.BusinessObjects.QueryObject;
using Cmf.Foundation.Configuration.Abstractions;

namespace Cmf.Custom.Lam.Common.Queries
{
    public class ProtocolQueries
    {
        /// <summary>
        /// Gets the Protocol Path Collection associated to a Protocol Instance
        /// </summary>
        /// <param name="protocolInstance"></param>
        /// <returns>A IProtocolPath Collection</returns>
        public static IProtocolPathCollection GetProtocolPathCollectionFromProtocolInstance(TableFilterBuilder tableFilterBuilder)
        {
            IProtocolPathCollection protocolPathCollection = new ProtocolPathCollection();
            QueryObject query = new()
            {
                Description = "",
                EntityTypeName = "ProtocolPath",
                Name = "GetProtocolPathCollectionFromProtocolInstance",
                Query = new Query
                {
                    Distinct = false,
                    Filters = tableFilterBuilder.BuildFilter(),
                    Fields = tableFilterBuilder.BuildFields(),
                    Relations = tableFilterBuilder.BuildRelations()
                }
            };

            DataSet queryDataSet = query.Execute(false, new QueryParameterCollection());

            if (queryDataSet.HasData())

                protocolPathCollection.AddRange(queryDataSet.Tables[0].Rows.Cast<DataRow>().Select(x =>
                    new ProtocolPath()
                    {
                        Name = x["Name"].ToString()
                    }
                ));

            protocolPathCollection.Load();
            return protocolPathCollection;
        }

        /// <summary>
        /// Gets all the Protocol Path Parameters for each Protocol Instance
        /// </summary>
        /// <param name="parameterNames"></param>
        /// <param name="protocolInstanceUniversalState"></param>
        /// <returns></returns>
        public static IProtocolPathParameterCollection GetProtocolPathParameters(string parameterName,
            UniversalState protocolInstanceUniversalState = UniversalState.Active, KeyValuePair<FieldOperator, object> parameterValue = default)
        {
            IQueryObject query = new QueryObject();
            query.Description = "";
            query.EntityTypeName = "ProtocolPathParameter";
            query.Name = "GetProtocolPathParameters";
            query.Query = new Query
            {
                Distinct = false,
                Filters = new FilterCollection() {
                    new Filter()
                    {
                        ObjectName = "ProtocolPath",
                        ObjectAlias = "ProtocolPathParameter_SourceEntity_2",
                        Value = null,
                        LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND,
                        FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.AlwaysTrue,
                    },
                    new Filter()
                    {
                        Name = "UniversalState",
                        ObjectName = "ProtocolInstance",
                        ObjectAlias = "ProtocolPathParameter_SourceEntity_Parent_3",
                        Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                        Value = protocolInstanceUniversalState,
                        LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND,
                        FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                    },
                new Filter()
                {
                    Name = "ParameterName",
                    ObjectName = "ProtocolPathParameter",
                    ObjectAlias = "ProtocolPathParameter_1",
                    Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                    Value = parameterName,
                    LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND,
                    FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                },
                new Filter
                    {
                        Name = "ParameterValue",
                        ObjectName = "ProtocolPathParameter",
                        ObjectAlias = "ProtocolPathParameter_1",
                        Operator = parameterValue.Key,
                        Value = parameterValue.Value,
                        LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND,
                        FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                },
                },
                Fields = new FieldCollection() {
                    new Field()
                    {
                        Alias = "Id",
                        ObjectName = "ProtocolPathParameter",
                        ObjectAlias = "ProtocolPathParameter_1",
                        IsUserAttribute = false,
                        Name = "Id",
                        Position = 0,
                        Sort = Cmf.Foundation.Common.FieldSort.NoSort
                    },
                    new Field()
                    {
                        Alias = "Name",
                        ObjectName = "ProtocolPathParameter",
                        ObjectAlias = "ProtocolPathParameter_1",
                        IsUserAttribute = false,
                        Name = "Name",
                        Position = 1,
                        Sort = Cmf.Foundation.Common.FieldSort.NoSort
                    }
                },
                Relations = new RelationCollection() {
                    new Relation()
                    {
                        Alias = "",
                        IsRelation = false,
                        Name = "",
                        SourceEntity = "ProtocolPathParameter",
                        SourceEntityAlias = "ProtocolPathParameter_1",
                        SourceJoinType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.JoinType.InnerJoin,
                        SourceProperty = "SourceEntityId",
                        TargetEntity = "ProtocolPath",
                        TargetEntityAlias = "ProtocolPathParameter_SourceEntity_2",
                        TargetJoinType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.JoinType.InnerJoin,
                        TargetProperty = "Id"
                    },
                    new Relation()
                    {
                        Alias = "",
                        IsRelation = false,
                        Name = "",
                        SourceEntity = "ProtocolPath",
                        SourceEntityAlias = "ProtocolPathParameter_SourceEntity_2",
                        SourceJoinType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.JoinType.InnerJoin,
                        SourceProperty = "ParentId",
                        TargetEntity = "ProtocolInstance",
                        TargetEntityAlias = "ProtocolPathParameter_SourceEntity_Parent_3",
                        TargetJoinType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.JoinType.InnerJoin,
                        TargetProperty = "Id"
                    }
                }
            };

            DataSet queryDataSet = query.Execute(false, new QueryParameterCollection());
            IProtocolPathParameterCollection protocolPathParameters = new ProtocolPathParameterCollection();

            if (!queryDataSet.HasData()) return protocolPathParameters;

            protocolPathParameters.AddRange(queryDataSet.Tables[0].Rows.Cast<DataRow>()
                .Select(row =>
                {
                    IProtocolPathParameter protocolPathParameter = new ProtocolPathParameter();
                    protocolPathParameter.Name = row["Name"].ToString();

                    return protocolPathParameter;
                }
                ));

            protocolPathParameters.Load();

            return protocolPathParameters;
        }

                public static IProtocolPathParameterCollection GetProtocolPathParametersWithModifiedOn(string parameterName,            KeyValuePair<FieldOperator, object> parameterValue, KeyValuePair<FieldOperator, DateTime> modifiedOn)
        {
            IQueryObject query = new QueryObject();
            query.Description = "";
            query.EntityTypeName = "ProtocolPathParameter";
            query.Name = "GetProtocolPathParametersWithModifiedOn";
            query.Query = new Query
            {
                Distinct = false,
                Filters = new FilterCollection() {
                    new Filter()
                    {
                        ObjectName = "ProtocolPath",
                        ObjectAlias = "ProtocolPathParameter_SourceEntity_2",
                        Value = null,
                        LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND,
                        FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.AlwaysTrue,
                    },
                    new Filter()
                    {
                        Name = "UniversalState",
                        ObjectName = "ProtocolInstance",
                        ObjectAlias = "ProtocolPathParameter_SourceEntity_Parent_3",
                        Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                        Value = UniversalState.Active,
                        LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND,
                        FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                    },
                new Filter()
                {
                    Name = "ParameterName",
                    ObjectName = "ProtocolPathParameter",
                    ObjectAlias = "ProtocolPathParameter_1",
                    Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                    Value = parameterName,
                    LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND,
                    FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                },
                new Filter
                    {
                        Name = "ParameterValue",
                        ObjectName = "ProtocolPathParameter",
                        ObjectAlias = "ProtocolPathParameter_1",
                        Operator = parameterValue.Key,
                        Value = parameterValue.Value,
                        LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND,
                        FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                },
                new Filter
                    {
                        Name = "ModifiedOn",
                        ObjectName = "ProtocolInstance",
                        ObjectAlias = "ProtocolPathParameter_SourceEntity_Parent_3",
                        Operator = modifiedOn.Key,
                        Value = modifiedOn.Value,
                        LogicalOperator = Cmf.Foundation.Common.LogicalOperator.AND,
                        FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal,
                },
                },
                Fields = new FieldCollection() {
                    new Field()
                    {
                        Alias = "Id",
                        ObjectName = "ProtocolPathParameter",
                        ObjectAlias = "ProtocolPathParameter_1",
                        IsUserAttribute = false,
                        Name = "Id",
                        Position = 0,
                        Sort = Cmf.Foundation.Common.FieldSort.NoSort
                    },
                    new Field()
                    {
                        Alias = "Name",
                        ObjectName = "ProtocolPathParameter",
                        ObjectAlias = "ProtocolPathParameter_1",
                        IsUserAttribute = false,
                        Name = "Name",
                        Position = 1,
                        Sort = Cmf.Foundation.Common.FieldSort.NoSort
                    }
                },
                Relations = new RelationCollection() {
                    new Relation()
                    {
                        Alias = "",
                        IsRelation = false,
                        Name = "",
                        SourceEntity = "ProtocolPathParameter",
                        SourceEntityAlias = "ProtocolPathParameter_1",
                        SourceJoinType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.JoinType.InnerJoin,
                        SourceProperty = "SourceEntityId",
                        TargetEntity = "ProtocolPath",
                        TargetEntityAlias = "ProtocolPathParameter_SourceEntity_2",
                        TargetJoinType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.JoinType.InnerJoin,
                        TargetProperty = "Id"
                    },
                    new Relation()
                    {
                        Alias = "",
                        IsRelation = false,
                        Name = "",
                        SourceEntity = "ProtocolPath",
                        SourceEntityAlias = "ProtocolPathParameter_SourceEntity_2",
                        SourceJoinType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.JoinType.InnerJoin,
                        SourceProperty = "ParentId",
                        TargetEntity = "ProtocolInstance",
                        TargetEntityAlias = "ProtocolPathParameter_SourceEntity_Parent_3",
                        TargetJoinType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.JoinType.InnerJoin,
                        TargetProperty = "Id"
                    }
                }
            };

            DataSet queryDataSet = query.Execute(false, new QueryParameterCollection());
            IProtocolPathParameterCollection protocolPathParameters = new ProtocolPathParameterCollection();

            if (!queryDataSet.HasData()) return protocolPathParameters;

            protocolPathParameters.AddRange(queryDataSet.Tables[0].Rows.Cast<DataRow>()
                .Select(row =>
                {
                    IProtocolPathParameter protocolPathParameter = new ProtocolPathParameter();
                    protocolPathParameter.Name = row["Name"].ToString();

                    return protocolPathParameter;
                }
                ));

            protocolPathParameters.Load();

            return protocolPathParameters;
        }
    }
}
