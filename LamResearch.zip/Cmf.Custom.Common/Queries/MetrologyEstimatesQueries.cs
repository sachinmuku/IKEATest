﻿using System.Data;
using System.Linq;
using Cmf.Common.CustomActionUtilities;
using Cmf.Custom.Lam.BusinessObjects.Abstractions;
using Cmf.Custom.Lam.Common.Interfaces;
using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessObjects.QueryObject;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Foundation.Common.Base;

namespace Cmf.Custom.Lam.Common.Queries
{
    public class MetrologyEstimatesQueries : IMetrologyEstimatesQueries
    {
        private readonly IEntityFactory entityFactory;

        public MetrologyEstimatesQueries(IEntityFactory entityFactory)
        {
            this.entityFactory = entityFactory;
        }

        public ICustomProjectMetrologyEstimatesCollection GetMetrologyEstimatesByProtocolInstance(long protocolInstanceId)
        {
            IQueryObject query = new QueryObject
            {
                Description = "",
                EntityTypeName = "CustomProjectMetrologyEstimates",
                Name = "GetCustomProjectMetrologyEstimatesCollection",
                Query = new Query
                {
                    Distinct = false,
                    Filters = new FilterCollection() {
                        new Cmf.Foundation.BusinessObjects.QueryObject.Filter()
                        {
                            Name = "Id",
                            ObjectName = "ProtocolInstance",
                            ObjectAlias = "CustomProjectMetrologyEstimates_ProtocolInstance_2",
                            Operator = Cmf.Foundation.Common.FieldOperator.IsEqualTo,
                            Value = protocolInstanceId,
                            LogicalOperator = Cmf.Foundation.Common.LogicalOperator.Nothing,
                            FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal
                        },
                        new Cmf.Foundation.BusinessObjects.QueryObject.Filter()
                        {
                            Name = "UniversalState",
                            ObjectName = "CustomProjectMetrologyEstimates",
                            ObjectAlias = "CustomProjectMetrologyEstimates_1",
                            Operator = Cmf.Foundation.Common.FieldOperator.IsNotEqualTo,
                            Value = UniversalState.Terminated,
                            LogicalOperator = Cmf.Foundation.Common.LogicalOperator.Nothing,
                            FilterType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.FilterType.Normal
                        }
                    },
                    Fields = new FieldCollection() {
                        new Field()
                        {
                            Alias = "Name",
                            ObjectName = "CustomProjectMetrologyEstimates",
                            ObjectAlias = "CustomProjectMetrologyEstimates_1",
                            IsUserAttribute = false,
                            Name = "Name",
                            Position = 0,
                            Sort = Cmf.Foundation.Common.FieldSort.NoSort
                        }
                    },
                    Relations = new RelationCollection() {
                        new Relation()
                        {
                            Alias = "",
                            IsRelation = false,
                            Name = "",
                            SourceEntity = "CustomProjectMetrologyEstimates",
                            SourceEntityAlias = "CustomProjectMetrologyEstimates_1",
                            SourceJoinType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.JoinType.InnerJoin,
                            SourceProperty = "ProtocolInstanceId",
                            TargetEntity = "ProtocolInstance",
                            TargetEntityAlias = "CustomProjectMetrologyEstimates_ProtocolInstance_2",
                            TargetJoinType = Cmf.Foundation.BusinessObjects.QueryObject.Enums.JoinType.InnerJoin,
                            TargetProperty = "Id"
                        }
                    }
                }
            };

            DataSet queryDataSet = query.Execute(false, new QueryParameterCollection());

            ICustomProjectMetrologyEstimatesCollection estimatesCollection = entityFactory.CreateCollection<ICustomProjectMetrologyEstimatesCollection>();
            if (queryDataSet.HasData())
            {
                estimatesCollection.AddRange(queryDataSet.Tables[0].Rows.Cast<DataRow>()
                .Select(row =>
                {
                    ICustomProjectMetrologyEstimates estimate = entityFactory.Create<ICustomProjectMetrologyEstimates>();
                    estimate.Name = row["Name"].ToString();
                    return estimate;
                }));

                estimatesCollection.Load();
            }

            return estimatesCollection;
        }
    }
}
