﻿using Cmf.Common.CustomActionUtilities;
using Cmf.Custom.Lam.BusinessObjects.Abstractions;
using Cmf.Custom.Lam.Common.DataStructures;
using Cmf.Foundation.BusinessObjects;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Foundation.Common.Base;
using Cmf.Navigo.BusinessObjects.Abstractions;
using System.Linq;

namespace Cmf.Custom.Lam.Common.Utilities
{
    public class ProtocolUtilities : IProtocolUtilities
    {
        readonly IEntityFactory _entityFactory;

        public ProtocolUtilities(IEntityFactory entityFactory)
        {
            _entityFactory = entityFactory;
        }

        /// <summary>
        /// Get Project Protocol objects references
        /// </summary>
        /// <param name="protocolInstances"></param>
        /// <returns></returns>
        public ProjectProtocolRelationsData GetProtocolProjectObjects(IProtocolInstanceCollection protocolInstances)
        {
            var projectCodes = _entityFactory.CreateCollection<ICustomProjectCodeCollection>();
            var productionOrders = _entityFactory.CreateCollection<IProductionOrderCollection>();
            var products = _entityFactory.CreateCollection<IProductCollection>();
            var materials = _entityFactory.CreateCollection<IMaterialCollection>();

            protocolInstances.LoadRelations(LamConstants.EntityTypeCustomProjectCodeProtocolInstance);
            foreach (var protocolInstance in protocolInstances)
            {
                if (!protocolInstance.HasRelations(LamConstants.EntityTypeCustomProjectCodeProtocolInstance)) continue;

                var relation = (ICustomProjectCodeProtocolInstance)
                    protocolInstance.RelationCollection[LamConstants.EntityTypeCustomProjectCodeProtocolInstance].FirstOrDefault();

                if (relation != null && relation.TargetEntity != null) projectCodes.Add(relation.TargetEntity);
            }

            projectCodes.LoadRelations(LamConstants.EntityTypeCustomPoProjectCode);
            foreach (var projectCode in projectCodes)
            {
                if (projectCode.Product != null &&
                    projectCode.Product.Name == projectCode.Name) products.Add(projectCode.Product);

                if (!projectCode.HasRelations(LamConstants.EntityTypeCustomPoProjectCode)) continue;

                var relation = (ICustomPoProjectCode)projectCode.RelationCollection[LamConstants.EntityTypeCustomPoProjectCode].FirstOrDefault();

                if (relation != null && relation.SourceEntity != null) productionOrders.Add(relation.SourceEntity);
            }

            productionOrders.LoadMaterials(1, new OperationAttributeCollection());
            materials.AddRange(productionOrders.Where(p => p.Materials.Count > 0)
                .SelectMany(p => p.Materials)
                .Where(m => m.UniversalState.Equals(UniversalState.Active)));

            return new ProjectProtocolRelationsData
            {
                ProjectCodes = projectCodes,
                ProductionOrders = productionOrders,
                Products = products,
                Materials = materials
            };
        }
    }
}
