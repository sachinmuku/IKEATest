﻿using Cmf.Foundation.BusinessObjects.Abstractions;
using Cmf.Foundation.BusinessObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Runtime.Serialization.Formatters;
using Cmf.Foundation.Common;
using Cmf.Navigo.BusinessObjects;
using Microsoft.Extensions.DependencyInjection;
using Cmf.Foundation.BusinessObjects.SmartTables;
using static Cmf.Custom.Lam.Common.Constants.TagVue;

namespace Cmf.Custom.Lam.Common.Utilities
{
    
    public class SmartTables
    {
        public static DataSet getData(ISmartTable smartTable, string smartTableName, IFilterCollection filter)
        {
            smartTable.Load(smartTableName);
            smartTable.LoadData(filter);

            DataSet dataSet = NgpDataSet.ToDataSet(smartTable.Data);
            return dataSet;
        }
    }
}
