﻿using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cmf.Custom.Lam.Common.Utilities
{
    public class Materials
    {
        public static IMaterial FindTopMostMaterial(IMaterial material)
        {
            if (material.ParentMaterial == null)
            {
                return material; // Top most material
            }
            else
            {
                return FindTopMostMaterial(material.ParentMaterial);
            }
        }
    }
}
