﻿using Cmf.Custom.Lam.Common.DataStructures;
using Cmf.Navigo.BusinessObjects.Abstractions;

namespace Cmf.Custom.Lam.Common.Utilities
{
    public interface IProtocolUtilities
    {
        ProjectProtocolRelationsData GetProtocolProjectObjects(IProtocolInstanceCollection protocolInstances);
    }
}
