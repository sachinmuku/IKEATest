﻿using Cmf.Custom.Lam.Common.UtilityAbstractions;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Foundation.Common.LocalizationService;
using Cmf.Foundation.Configuration;
using Cmf.Foundation.Configuration.Abstractions;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.Abstractions;
using Cmf.Navigo.BusinessOrchestration.ExceptionManagement.InputObjects;
using Org.BouncyCastle.Crypto.Fpe;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Cmf.Custom.Lam.Common.Utilities;

public class ProtocolInstanceUtilities : IProtocolInstanceUtilities
{
    private readonly IExceptionOrchestration _exceptionOrchestration;
    private readonly IEntityFactory _entityFactory;
    private readonly ILocalizationService _localizationService;
    public IConfig ParentConfig;

    public ProtocolInstanceUtilities(IExceptionOrchestration exceptionOrchestration, IEntityFactory entityFactory, ILocalizationService localizationService)
    {
        _exceptionOrchestration = exceptionOrchestration;
        _entityFactory = entityFactory;
        _localizationService = localizationService;
        LoadParentOfProtocolParameters();
    }

    public object GetProtocolParameterValueByConfigPath(IProtocolInstance protocolInstance, string configPath)
    {
        protocolInstance = EnsureProtocolInstanceIsLoaded(protocolInstance);
        string configValue = (string)ParentConfig.ChildConfigs.FirstOrDefault(cfg => cfg.Path == configPath)?.Value ?? null;
        if (configValue is not null)
        {
            return protocolInstance.CurrentPath.Parameters.FirstOrDefault(param => param.ParameterName == configValue)?.ParameterValue ?? null;
        }

        LamUtilities.ThrowLocalizedException(_localizationService,
                                    "CustomParameterProjectProtocolNotFound",
                                    configValue,
                                    protocolInstance.ParentEntity.Name);

        return null;
    }

    public object GetProtocolParameterValueByConfigName(IProtocolInstance protocolInstance, string configName)
    {
        protocolInstance = EnsureProtocolInstanceIsLoaded(protocolInstance);
        string configValue = (string)ParentConfig.ChildConfigs.FirstOrDefault(cfg => cfg.Name == configName)?.Value ?? null;
        if (configValue is not null)
        {
            return protocolInstance.CurrentPath.Parameters.FirstOrDefault(param => param.ParameterName == configValue)?.ParameterValue ?? null;
        }

        LamUtilities.ThrowLocalizedException(_localizationService,
                                            "CustomParameterProjectProtocolNotFound",
                                            configName,
                                            protocolInstance.ParentEntity.Name);

        return null; 

    }

    public Dictionary<string, object> GetProtocolParameterValuesByConfigName(IProtocolInstance protocolInstance, List<string> parametersToGet)
    {
        Dictionary<string, object> output = new();
        foreach (string parameter in parametersToGet)
        {
            output.Add(parameter, GetProtocolParameterValueByConfigName(protocolInstance, parameter));
        }
        return output;
    }

    public Dictionary<string, object> GetProtocolParameterValuesByConfigPath(IProtocolInstance protocolInstance, List<string> parametersToGet)
    {
        Dictionary<string, object> output = new();
        foreach (string parameter in parametersToGet)
        {
             output.Add(parameter, GetProtocolParameterValueByConfigPath(protocolInstance, parameter));
        }
        return output;
    }

    private IProtocolInstance EnsureProtocolInstanceIsLoaded(IProtocolInstance protocolInstance)
    {
        if (protocolInstance.CurrentPath is null
            || protocolInstance.CurrentPath.Parameters is null)
        {
            protocolInstance.Load(1);
            IProtocolInstanceCollection instances = _entityFactory.CreateCollection<IProtocolInstanceCollection>();
            instances.Add(protocolInstance);
            protocolInstance = _exceptionOrchestration.LoadProtocolCurrentPath(
                new LoadProtocolCurrentPathInput
                { ProtocolInstanceCollection = instances })
                .ProtocolInstanceCollection.First();
            protocolInstance.CurrentPath.Load(1);
            protocolInstance.CurrentPath.Parameters?.Load(1);
        }
        return protocolInstance;
    }

    private void LoadParentOfProtocolParameters()
    {
        IConfig config = Config.GetConfig(LamConstants.Configs.ProtocolParameterNames.ParentPath);
        config.LoadChildConfigs(1);
        ParentConfig = config;
    }
}
