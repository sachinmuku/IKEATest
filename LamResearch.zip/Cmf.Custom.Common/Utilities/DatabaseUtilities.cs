﻿using System.Data.SqlClient;
using System.Data;
using System;
using System.Configuration;
using System.Linq;
using System.Collections.Generic;

namespace Cmf.Custom.Lam.Common.Utilities;

public class DatabaseUtilities
{
    /// <summary>
            /// Creates a SqlParameter and adds it to the command
            /// </summary>
            /// <param name="parameterName">Parameter name</param>
            /// <param name="value">Parameter value</param>
            /// <param name="direction">Parameter direction (input, output, etc)</param>
            /// <returns>Created SQL Parameter</returns>
    public static SqlParameter InsertParameter(string parameterName, object value, ParameterDirection direction)
    {
        return InsertParameter(parameterName, value, direction, null, null);
    }

    /// <summary>
            /// Inserts the parameter.
            /// </summary>
            /// <param name="parameterName">Name of the parameter.</param>
            /// <param name="value">The value.</param>
            /// <param name="direction">The direction.</param>
            /// <param name="sqlType">Type of the SQL.</param>
            /// <param name="size">The size.</param>
            /// <returns>Created SQL Parameter</returns>
    public static SqlParameter InsertParameter(string parameterName, object value, ParameterDirection direction, SqlDbType? sqlType, int? size)
    {
        if (value == null)
        {
            value = DBNull.Value;
        }
        else if (value is string && string.IsNullOrWhiteSpace(value.ToString()))
        {
            value = DBNull.Value;
        }
        SqlParameter parameter = null;
        if (sqlType.HasValue && size.HasValue)
        {
            parameter = new SqlParameter(parameterName, sqlType.Value, size.Value);
            parameter.Value = value;
        }
        else
        {
            parameter = new SqlParameter(parameterName, value);
        }
        parameter.Direction = direction;
        return parameter;
    }

    /// <summary>
            /// Gets the connection string from entity framework and converts it to a regular connection string
            /// </summary>
            /// <param name="connectionStringName">Name of the connection string.</param>
            /// <returns>Regular connection string to be used on SqlConnection</returns>
    internal static string GetConnectionStringFromEntityFramework(string connectionStringName)
    {
        string efConnectionString = ConfigurationManager.ConnectionStrings[connectionStringName].ConnectionString;
        int startIndex = efConnectionString.IndexOf("connection string=", StringComparison.InvariantCultureIgnoreCase) + "connection string=".Length + 1;
        int endIndex = efConnectionString.Length - 1;
        return efConnectionString.Substring(startIndex, endIndex - startIndex);
    }

    /// <summary>
            /// Executes a SQL command and reads its content into a dataset
            /// </summary>
            /// <param name="commandText"></param>
          /// <param name="commandType"></param>
            /// <param name="parameters"></param>
            /// <returns></returns>
    public static DataSet ExecuteReader(String commandText, CommandType commandType, params SqlParameter[] parameters)
    {
        DataSet dataSet = null;
        using (SqlConnection conn = new SqlConnection(GetConnectionStringFromEntityFramework("CmfEntities")))
        {
            dataSet = new DataSet();
            SqlDataAdapter adapter = new SqlDataAdapter
            {
                SelectCommand = new SqlCommand(commandText, conn)
                {
                    CommandType = commandType
                }
            };
            if (parameters != null)
            {
                foreach (SqlParameter parameter in parameters)
                {
                    if (parameter != null)
                    {
                        adapter.SelectCommand.Parameters.Add(parameter);
                    }
                }
            }

            adapter.SelectCommand.CommandTimeout = 600;
            adapter.Fill(dataSet);
        }
        return dataSet;
    }

    public static DataSet GetDee(Dictionary<string, object> Input = null)
    {
        var deeActionToRun = new Foundation.Common.DynamicExecutionEngine.Action();
        deeActionToRun.Load("CustomProjectCodeListDashboard");

        if (Input == null)
        {
            Input = new Dictionary<string, object>();
            Input.Add("ProjectId", null);
            Input.Add("Type", null);
            Input.Add("StateModel", "ProjectProtocol-A-1");
            Input.Add("ModelState", null);
            Input.Add("ProjectOwner", null);
            Input.Add("Customer", null);
            Input.Add("CreationDateFrom", DateTime.UnixEpoch);
            Input.Add("CreationDateUntil", DateTime.MaxValue);
        }

        var output = deeActionToRun.ExecuteAction(Input);

        return output["Result"] as DataSet;
    }
}
