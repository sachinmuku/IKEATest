﻿using Cmf.Custom.Lam.Common.UtilityAbstractions;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Foundation.Security.Abstractions;
using Cmf.Navigo.BusinessObjects;
using Cmf.Navigo.BusinessObjects.Abstractions;
using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace Cmf.Custom.Lam.Common.Utilities;

public  class NotificationUtilities : INotificationUtilities
{
    private readonly IEntityFactory _entityFactory;

    public NotificationUtilities(IEntityFactory entityFactory)
    {
        _entityFactory = entityFactory;
    }

    /// <summary>
    /// Create new Notification from template
    /// </summary>
    /// <param name="template">The Notification template</param>
    /// <param name="employee">Employee to assign the notification</param>
    /// <param name="role">Role to assign the notification</param>
    /// <param name="tokens">Role to assign the notification</param>
    /// <returns></returns>
    public INotification CreateNotificationFromTemplate(INotification template, IEmployee employee = null, IRole role = null, Dictionary<string, string> tokens = null)
    {
        INotification notification = _entityFactory.Create<INotification>();
        notification.ClearanceDate = template.ClearanceDate;
        notification.ClearedBy = template.ClearedBy;
        notification.Severity = template.Severity;
        notification.SourceName = template.SourceName;
        notification.Step = template.Step;
        notification.Title = template.Title;
        notification.Type = template.Type;
        notification.ValidTo = template.ValidTo ?? DateTime.Now;
        notification.ClearanceMode = template.ClearanceMode;
        notification.NotificationEmployeeTrackingCollection = template.NotificationEmployeeTrackingCollection;
        notification.NotificationParameterCollection = template.NotificationParameterCollection;
        notification.SourceType = template.SourceType;
        notification.SystemState = template.SystemState;
        notification.VisibilityFilter = template.VisibilityFilter;
        notification.SendEmailToAssignedParty = template.SendEmailToAssignedParty;
        notification.Area = template.Area;
        notification.EmailDistributionList = template.EmailDistributionList;
        notification.Details = template.Details;

        if (employee != null)
        {
            notification.AssignedToEmployee = employee;
            notification.AssignmentType = AssignmentType.Employee;
        }
        else if (role != null)
        {
            notification.AssignedToRole = role;
            notification.AssignmentType = AssignmentType.Role;
        }
        else
        {
            notification.AssignmentType = AssignmentType.Everyone;
        }

        // Replace tokens with correspondent values               
        ReplaceTitleTokens(notification, tokens);
        ReplaceDetailsTokens(notification, tokens);

        return notification;
    }

    /// <summary>
    /// Replace tokens from Notification instance Details
    /// </summary>
    /// <param name="instance">The Notification instance</param>
    /// <param name="tokens">The tokens and respective values to be replaced</param>
    /// <returns></returns>
    public void ReplaceDetailsTokens(INotification instance, Dictionary<string, string> tokens)
    {
        instance.Details = ReplaceTokensByValues(tokens, instance.Details);
    }

    /// <summary>
    /// Replace tokens from Notification instance Title
    /// </summary>
    /// <param name="instance">The Notification instance</param>
    /// <param name="tokens">The tokens and respective values to be replaced</param>
    /// <returns></returns>
    public void ReplaceTitleTokens(INotification instance, Dictionary<string, string> tokens)
    {
        instance.Title = ReplaceTokensByValues(tokens, instance.Title);
    }

    /// <summary>
    /// Replace tokens into values
    /// </summary>
    /// <param name="tokens">The Notification instance</param>
    /// <param name="tokenString">The tokens and respective values to be replaced</param>
    /// <returns></returns>
    public string ReplaceTokensByValues(Dictionary<string, string> tokens, string tokenString)
    {
        foreach (string token in tokens.Keys)
        {
            if (!string.IsNullOrWhiteSpace(token))
            {
                tokenString = Regex.Replace(
                    $"{tokenString} ",
                    $"(?<=){{{{{token}}}}}(?=)",
                    $"{tokens[token]}");
            }
        }

        return tokenString.Trim();
    }
}
