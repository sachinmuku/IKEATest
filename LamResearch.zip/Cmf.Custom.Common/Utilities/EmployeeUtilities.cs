﻿using Cmf.Custom.Lam.Common.UtilityAbstractions;
using Cmf.Foundation.Common.Abstractions;
using Cmf.Foundation.Security.Abstractions;
using Cmf.Navigo.BusinessObjects.Abstractions;
using Cmf.Navigo.BusinessOrchestration.Abstractions;
using Cmf.Navigo.BusinessOrchestration.LaborManagement.InputObjects;
using System.Collections.Generic;

namespace Cmf.Custom.Lam.Common.Utilities;

public class EmployeeUtilities : IEmployeeUtilities
{
    private readonly ILaborOrchestration _laborOrchestration;
    private readonly IEntityFactory _entityFactory;

    public EmployeeUtilities(ILaborOrchestration laborOrchestration, IEntityFactory entityFactory)
    {
        _laborOrchestration = laborOrchestration;
        _entityFactory = entityFactory;
    }

    public IEmployee GetEmployeeByUserAccount(string userAccount)
    {
        return _laborOrchestration.GetEmployeeByUserAccount(
            new GetEmployeeByUserAccountInput()
        {
            UserAccount = userAccount
        }).Employee;
    }

    public IEmployee GetEmployeeByUser(IUser user)
    {
        return _laborOrchestration.GetEmployeeByUserAccount(
            new GetEmployeeByUserAccountInput()
            {
                UserAccount = user.UserAccount
            }).Employee;
    }

    public IEmployeeCollection GetEmployeesByUserAccounts(IEnumerable<string> userAccounts)
    {
        IEmployeeCollection employeeCollection = _entityFactory.CreateCollection<IEmployeeCollection>();
        foreach (string userAccount in userAccounts)
        {
        employeeCollection.Add(GetEmployeeByUserAccount(userAccount));
        }
        return employeeCollection;
    }

    public IEmployeeCollection GetEmployeesByUsers(IEnumerable<IUser> users)
    {
        IEmployeeCollection employeeCollection = _entityFactory.CreateCollection<IEmployeeCollection>();
        foreach (IUser user in users)
        {
            employeeCollection.Add(GetEmployeeByUser(user));
        }
        return employeeCollection;
    }

}
