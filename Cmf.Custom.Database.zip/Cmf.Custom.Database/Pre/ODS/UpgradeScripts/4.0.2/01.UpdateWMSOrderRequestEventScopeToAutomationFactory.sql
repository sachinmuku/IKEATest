Declare @IoTEventName Varchar(50) = 'WMSOrderRequestEvent'
Declare @IoTEventDefinitionId bigInt
Declare @LastServiceHistoryId bigInt 
Declare @LastOperationHistorySeq bigInt
Declare @Scope Int

Select @IoTEventDefinitionId = IoTEventDefinitionId, @LastServiceHistoryId = LastServiceHistoryId, @LastOperationHistorySeq = LastOperationHistorySeq, @Scope = Scope FROM CoreDataModel.T_IoTEventDefinition Where Name=@IoTEventName
 
IF(@Scope <> 1) --Scope:0 - General, 1 - Automation Factory
BEGIN
	Delete FROM CoreDataModel.T_IoTEventDefinitionHistory Where IoTEventDefinitionId=@IoTEventDefinitionId and ServiceHistoryId=@LastServiceHistoryId and OperationHistorySeq = @LastOperationHistorySeq
	Update CoreDataModel.T_IoTEventDefinition SET Scope=1 Where Name=@IoTEventName
END