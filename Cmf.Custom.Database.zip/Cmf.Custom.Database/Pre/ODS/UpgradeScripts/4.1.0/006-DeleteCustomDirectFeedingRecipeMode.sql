IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'UserDataModel' AND TABLE_NAME = 'T_ST_CustomDirectFeedingRecipeMode')
BEGIN
	DROP TABLE [UserDataModel].[T_ST_CustomDirectFeedingRecipeMode];
	DROP TABLE [UserDataModel].[T_ST_CustomDirectFeedingRecipeModeHistory];
	DELETE FROM [dbo].[T_SmartTable] WHERE NAME = 'CustomDirectFeedingRecipeMode';
	DELETE FROM [dbo].[T_SmartTable] WHERE NAME = 'CustomDirectFeedingRecipeModeHistory';
	DELETE FROM [Control].[T_ReplicationTables] WHERE SchemaName = 'UserDataModel' AND TableName = 'T_ST_CustomDirectFeedingRecipeMode';
	DELETE FROM [Control].[T_ReplicationTables] WHERE SchemaName = 'UserDataModel' AND TableName = 'T_ST_CustomDirectFeedingRecipeModeHistory';
	
END

