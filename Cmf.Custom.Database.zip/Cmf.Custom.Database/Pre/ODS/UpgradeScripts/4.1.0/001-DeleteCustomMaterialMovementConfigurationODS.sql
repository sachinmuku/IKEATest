IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'UserDataModel' AND TABLE_NAME = 'T_ST_CustomMaterialMovementConfiguration')
BEGIN
	DROP TABLE [UserDataModel].[T_ST_CustomMaterialMovementConfiguration];
	DROP TABLE [UserDataModel].[T_ST_CustomMaterialMovementConfigurationHistory];
	DELETE FROM [dbo].[T_SmartTable] WHERE NAME = 'CustomMaterialMovementConfiguration';
	DELETE FROM [dbo].[T_SmartTable] WHERE NAME = 'CustomMaterialMovementConfigurationHistory';
	DELETE FROM [Control].[T_ReplicationTables] WHERE SchemaName = 'UserDataModel' AND TableName = 'T_ST_CustomMaterialMovementConfiguration';
	DELETE FROM [Control].[T_ReplicationTables] WHERE SchemaName = 'UserDataModel' AND TableName = 'T_ST_CustomMaterialMovementConfigurationHistory';
	
END

