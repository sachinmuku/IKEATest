IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'UserDataModel' AND TABLE_NAME = 'T_ST_CustomAdHocMAOResourceLevel')
BEGIN
	DROP TABLE [UserDataModel].[T_ST_CustomAdHocMAOResourceLevel];
	DROP TABLE [UserDataModel].[T_ST_CustomAdHocMAOResourceLevelHistory];
	DELETE FROM [dbo].[T_SmartTable] WHERE NAME = 'CustomAdHocMAOResourceLevel';
	DELETE FROM [dbo].[T_SmartTable] WHERE NAME = 'CustomAdHocMAOResourceLevelHistory';
	DELETE FROM [Control].[T_ReplicationTables] WHERE SchemaName = 'UserDataModel' AND TableName = 'T_ST_CustomAdHocMAOResourceLevel';
	DELETE FROM [Control].[T_ReplicationTables] WHERE SchemaName = 'UserDataModel' AND TableName = 'T_ST_CustomAdHocMAOResourceLevelHistory';
	
END

