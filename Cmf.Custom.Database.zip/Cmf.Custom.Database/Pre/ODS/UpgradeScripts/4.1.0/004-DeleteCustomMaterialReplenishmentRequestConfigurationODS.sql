IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'UserDataModel' AND TABLE_NAME = 'T_ST_CustomMaterialReplenishmentRequestConfiguration')
BEGIN
	DROP TABLE [UserDataModel].[T_ST_CustomMaterialReplenishmentRequestConfiguration];
	DROP TABLE [UserDataModel].[T_ST_CustomMaterialReplenishmentRequestConfigurationHistory];
	DELETE FROM [dbo].[T_SmartTable] WHERE NAME = 'CustomMaterialReplenishmentRequestConfiguration';
	DELETE FROM [dbo].[T_SmartTable] WHERE NAME = 'CustomMaterialReplenishmentRequestConfigurationHistory';
	DELETE FROM [Control].[T_ReplicationTables] WHERE SchemaName = 'UserDataModel' AND TableName = 'T_ST_CustomMaterialReplenishmentRequestConfiguration';
	DELETE FROM [Control].[T_ReplicationTables] WHERE SchemaName = 'UserDataModel' AND TableName = 'T_ST_CustomMaterialReplenishmentRequestConfigurationHistory';
	
END

