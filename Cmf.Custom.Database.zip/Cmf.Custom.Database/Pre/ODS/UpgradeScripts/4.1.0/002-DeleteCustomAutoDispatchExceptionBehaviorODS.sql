IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'UserDataModel' AND TABLE_NAME = 'T_ST_CustomAutoDispatchExceptionBehavior')
BEGIN
	DROP TABLE [UserDataModel].[T_ST_CustomAutoDispatchExceptionBehavior];
	DROP TABLE [UserDataModel].[T_ST_CustomAutoDispatchExceptionBehaviorHistory];
	DELETE FROM [dbo].[T_SmartTable] WHERE NAME = 'CustomAutoDispatchExceptionBehavior';
	DELETE FROM [dbo].[T_SmartTable] WHERE NAME = 'CustomAutoDispatchExceptionBehaviorHistory';
	DELETE FROM [Control].[T_ReplicationTables] WHERE SchemaName = 'UserDataModel' AND TableName = 'T_ST_CustomAutoDispatchExceptionBehavior';
	DELETE FROM [Control].[T_ReplicationTables] WHERE SchemaName = 'UserDataModel' AND TableName = 'T_ST_CustomAutoDispatchExceptionBehaviorHistory';
	
END

