IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'UserDataModel' AND TABLE_NAME = 'T_ST_CustomAutomaticPrintableDocumentContext')
BEGIN
	DROP TABLE [UserDataModel].[T_ST_CustomAutomaticPrintableDocumentContext];
	DROP TABLE [UserDataModel].[T_ST_CustomAutomaticPrintableDocumentContextHistory];
	DELETE FROM [dbo].[T_SmartTable] WHERE NAME = 'CustomAutomaticPrintableDocumentContext';
	DELETE FROM [dbo].[T_SmartTable] WHERE NAME = 'CustomAutomaticPrintableDocumentContextHistory';
	DELETE FROM [Control].[T_ReplicationTables] WHERE SchemaName = 'UserDataModel' AND TableName = 'T_ST_CustomAutomaticPrintableDocumentContextBehavior';
	DELETE FROM [Control].[T_ReplicationTables] WHERE SchemaName = 'UserDataModel' AND TableName = 'T_ST_CustomAutomaticPrintableDocumentContextHistory';
	
END

