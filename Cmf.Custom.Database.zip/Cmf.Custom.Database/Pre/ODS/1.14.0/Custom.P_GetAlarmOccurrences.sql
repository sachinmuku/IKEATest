﻿
if not exists (select * from sys.schemas where name = 'Custom')
begin
exec('create schema Custom')
end
go
if exists ( select * 
            from   sysobjects 
            where  id = object_id(N'[Custom].[P_GetAlarmOccurrences]') 
                   and objectproperty(id, N'IsProcedure') = 1 )
begin
    drop procedure [Custom].[P_GetAlarmOccurrences]
end
go

create procedure [Custom].[P_GetAlarmOccurrences]
	@Start datetime,
	@End datetime,	
	@FacilityName nvarchar(max),
	@AreaName nvarchar(max),
	@ResourceName nvarchar(max),
	@ProductName nvarchar(512) = null,
	@ManufacturingOrder nvarchar(512) = null,
	@AlarmCategory nvarchar(max)
as

set nocount on;

	
declare @StartDate datetime =  dbo.F_TimeLocalTimeToUTC(@Start)
declare @EndDate datetime = dateadd(day, 1, dbo.F_TimeLocalTimeToUTC(@End))

/* Delete temporary tables. They should not exist at this point but helps on debugging.. */
if(object_id('tempdb..#FacilityTempTable') is not null)	drop table #FacilityTempTable
if(object_id('tempdb..#AreaTempTable') is not null)	drop table #AreaTempTable
if(object_id('tempdb..#ResourceTempTable') is not null)	drop table #ResourceTempTable
if(object_id('tempdb..#AlarmCategoryTempTable') is not null) drop table #AlarmCategoryTempTable

/* Create temporary tables */
create table #FacilityTempTable (Name nvarchar(512))
create table #ResourceTempTable (Name nvarchar(512))
create table #AreaTempTable (Name nvarchar(512))
create table #AlarmCategoryTempTable(Name nvarchar(512))


/* Temp table with Facilities */
if(@FacilityName is not null)
	begin
	  insert into #FacilityTempTable 
		select [Value] 
		from [dbo].[F_Split2](@FacilityName, ';');
	end

/* Temp table with Areas */
if(@AreaName is not null)
	begin
		insert into #AreaTempTable
		select [Value] 
		from dbo.F_Split2(@AreaName, ';');
	end

/* Temp table with Resources */
if(@ResourceName is not null)
	begin
		insert into #ResourceTempTable
		select [Value] 
		from [dbo].[F_Split2](@ResourceName, ';');
	end

/* Temp table with alarm categories */
if(@AlarmCategory is not null)
	begin
		insert into #AlarmCategoryTempTable
		select [Value] 
		from [dbo].[F_Split2](@AlarmCategory, ';');
	end


select f.Name as 'Facility'
	,a.Name as 'Area'
	,r.Name as 'Line'
	,p.Name as 'Product'
	,coalesce(ma.Value, po.Name, m.Name) as 'ManufacturingOrder' /* check for base material, if null shows POName, if no PO, shows mName */
	,dbo.F_TimeUTCToLocalTime(cao.AlarmStart) as 'AlarmStart'
	,dbo.F_TimeUTCToLocalTime(cao.AlarmEnd) as 'AlarmEnd'
	,datediff(second, cao.AlarmStart, isnull(cao.AlarmEnd, getutcdate())) as 'Duration'
	,cao.AlarmCode as 'AlarmCode'
	,cao.AlarmCategory as 'AlarmCategory'

from UserDataModel.T_CustomAlarmOccurrence cao
inner join CoreDataModel.T_Facility f on cao.FacilityId = f.FacilityId
inner join CoreDataModel.T_Resource r on r.ResourceId = cao.ResourceId
inner join CoreDataModel.T_Area a on a.AreaId = cao.AreaId
left join CoreDataModel.T_Material m on m.Name = cao.Material
left join CoreDataModel.T_Product p on p.ProductId = m.ProductId
left join CoreDataModel.T_ProductionOrder po on po.ProductionOrderId = m.ProductionOrderId
left join coredatamodel.T_MaterialAttribute ma on (ma.Value = cao.Material and ma.Name = 'BaseMaterial')
left join #FacilityTempTable filt_f on (f.Name = filt_f.Name)
left join #AreaTempTable filt_a on (a.Name = filt_a.Name)
left join #ResourceTempTable filt_r on (r.Name = filt_r.Name)
left join #AlarmCategoryTempTable alCat_r on (cao.AlarmCategory = alCat_r.Name)

where ((cao.AlarmStart between @StartDate and @EndDate or isnull(cao.AlarmEnd, getutcdate()) between @StartDate and @EndDate) or (cao.AlarmStart < @StartDate and cao.AlarmEnd > @EndDate))
	and ((@FacilityName is not null and filt_f.Name is not null) or @FacilityName is null)
	and ((@AreaName is not null and filt_a.Name is not null) or @AreaName is null)
	and ((@ResourceName is not null and filt_r.Name is not null) or @ResourceName is null)
	and ((@AlarmCategory is not null and alCat_r.Name is not null) or @AlarmCategory is null)
	and (@ManufacturingOrder is null or po.Name like @ManufacturingOrder + '%')
	and (@ProductName is null or p.Name like @ProductName + '%')
order by f.Name
		,a.Name
		,r.Name
		,p.Name
		,po.Name
		,cao.AlarmStart
		,cao.AlarmEnd

