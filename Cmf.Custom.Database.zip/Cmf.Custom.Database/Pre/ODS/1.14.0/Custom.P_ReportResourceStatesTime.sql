﻿

if not exists (select * from sys.schemas where name = 'Custom')
begin
exec('create schema Custom')
end
go

if exists ( select * 
            from   sysobjects 
            where  id = object_id(N'[Custom].[P_ReportResourceStatesTime]') 
                   and objectproperty(id, N'IsProcedure') = 1 )
begin
    drop procedure [Custom].[P_ReportResourceStatesTime]
end
go

create procedure [Custom].[P_ReportResourceStatesTime]
	@Start datetime,
	@End datetime,
	@FacilityName nvarchar(max),
	@AreaName nvarchar(max),
	@ResourceName nvarchar(max)
as


/* declare vars */
declare @fst_srvhistory_id bigint = null
declare @lst_srvhistory_id bigint = null
declare @StartDate datetime = dbo.F_TimeLocalTimeToUTC(@Start)
declare @EndDate datetime = dateadd(day, 1, dbo.F_TimeLocalTimeToUTC(@End))
declare @ShowNullEndDate datetime = case when @EndDate > getutcdate() then getutcdate() else @EndDate end


/* Delete temporary tables. They should not exist at this point but helps on debugging.. */
if(object_id('tempdb..#FacilityTempTable') is not null) drop table #FacilityTempTable
if(object_id('tempdb..#AreaTempTable') is not null) drop table #AreaTempTable
if(object_id('tempdb..#ResourceTempTable') is not null) drop table #ResourceTempTable

/* Create temporary tables */
create table #FacilityTempTable (Name nvarchar(512))
create table #ResourceTempTable (Name nvarchar(512))
create table #AreaTempTable(Name nvarchar(512))

declare @MainData table
(
ResourceId bigint,
Facility nvarchar(50),
Area nvarchar(50),
Line nvarchar(50),
PreviousStateModel nvarchar(50),
PreviousStateModelReason nvarchar(50),
CurrentStateModel nvarchar(50),
CurrentStateModelReason nvarchar(50),
NextStateModel nvarchar(50),
NextStateModelReason nvarchar(50),
OldStartService datetime,
StartService datetime,
EndService datetime,
EventStillOpen bit
)
declare @ResultData table
(
ResourceId bigint,
Facility nvarchar(50),
Area nvarchar(50),
Line nvarchar(50),
CurrentStateModel nvarchar(50),
CurrentStateModelReason nvarchar(50),
NextStateModel nvarchar(50),
NextStateModelReason nvarchar(50),
StartEvent datetime,
EndEvent datetime,
TimeDuration decimal(38, 8),
EventStillOpenAfterTimeStamp bit,
EventStartedBeforeTimeStamp bit
)

declare @ElegibleResources table
(
ResourceId bigint,
ResourceName nvarchar(50),
AreaName nvarchar(50),
FacilityName nvarchar(50)
)

/* Check date values */
if(@StartDate >= getutcdate()) return 0
if(@StartDate >= @EndDate) return 0


/* Temp Table with Facilities */
if(len(@FacilityName) > 0)
begin
  insert into #FacilityTempTable 
  select [Value] from dbo.F_Split2(@FacilityName, ';');
end

/* Temp Table with Areas */
if(len(@AreaName) > 0)
begin
	insert into #AreaTempTable
	select [Value] from dbo.F_Split2(@AreaName, ';');
end

/* Temp Table with Resources */
if(len(@ResourceName) > 0)
begin
  insert into #ResourceTempTable
  select [Value] from dbo.F_Split2(@ResourceName, ';');
end


/*
 Get first and last service history ids by supplied date.
 For the first ServicehistoryId, go 10 days back to ensure we get all the resources.
 (For this, we must assume that all the resources have at least one state change within 10 days, or else it may not appear in the list)
*/
set @fst_srvhistory_id = [dbo].[F_Part_GetMinServiceHistoryIdForDate](dateadd(day, -10, @StartDate))
set @lst_srvhistory_id = [dbo].[F_Part_GetMaxServiceHistoryIdForDate](dateadd(day, 1, @EndDate))


/* Get list of elegible top most resources according to report filters */
insert into @ElegibleResources
select r.ResourceId, r.Name, a.Name, f.Name
from CoreDataModel.T_Resource r 
inner join CoreDataModel.T_Area a on r.AreaId = a.AreaId
inner join CoreDataModel.T_Facility f on a.FacilityId = f.FacilityId
left join #FacilityTempTable filt_f ON (f.Name = filt_f.Name)
left join #AreaTempTable filt_a ON (a.Name = filt_a.Name)
left join #ResourceTempTable filt_r ON (r.Name = filt_r.Name)
where r.ParentResourcesCount = 0
  and ((len(@FacilityName) > 0 and filt_f.Name is not null) or len(@FacilityName) = 0)
  and ((len(@AreaName) > 0 and filt_a.Name is not null) or len(@AreaName) = 0)
  and ((len(@ResourceName) > 0 and filt_r.Name is not null) or len(@ResourceName) = 0)


/* 
------------------------
Collect resource history
------------------------
Step 1 (base_data): Feth resource history and include previous states on each event
Step 2 (change_points): get only events that have changes on StateModelSate or StateModelStateReason from previous state
Step 3 (lead_points): Include the next ServiceId on each event
*/
;with base_data as
(
select r.FacilityName, r.AreaName, r.ResourceName, r.ResourceId, rh.MainStateModelId, rh.MainStateModelStateId, rh.MainStateModelStateReason, rh.ServiceHistoryId--, rh.OldServiceHistoryId
			,lag(rh.MainStateModelStateId) over (partition by rh.ResourceId order by rh.ServiceHistoryId, rh.ModifiedOn) PreviousSMS
			,lag(rh.OldServiceHistoryId) over (partition by rh.ResourceId order by rh.ServiceHistoryId, rh.ModifiedOn) OldServiceHistoryId
			,lag(rh.MainStateModelStateReason) over (partition by rh.ResourceId order by rh.ServiceHistoryId, rh.ModifiedOn) PreviousSMSR
from @ElegibleResources r
inner join CoreDataModel.T_ResourceHistory rh on rh.ResourceId = r.ResourceId
where rh.ServiceHistoryId between @fst_srvhistory_id and @lst_srvhistory_id
),
change_points as
(
    select bd.*
    from base_data bd
    where bd.MainStateModelStateId is not null and ( bd.MainStateModelStateId <> bd.PreviousSMS OR bd.MainStateModelStateReason <> isnull(bd.[PreviousSMSR], '') or bd.PreviousSMS is null)
),
lead_points as
(
select cp.*
			,lead(CP.ServiceHistoryId) over(partition by cp.ResourceId order by cp.ServiceHistoryId) NextServiceHistoryId
			,lead(CP.MainStateModelStateId) over(partition by cp.ResourceId order by cp.ServiceHistoryId) NextStateModelStateChange
			,lead(CP.MainStateModelStateReason) over(partition by cp.ResourceId order by cp.ServiceHistoryId) NextStateModelStateReason
from change_points cp
)

/* Cross events with service history to get result data */
insert into @MainData
select lp.ResourceId
			,lp.FacilityName
			,lp.AreaName
			,lp.ResourceName
			,stsPrev.Name
			,lp.PreviousSMSR
			,stsCurrent.Name
			,lp.MainStateModelStateReason
			,stsNext.Name
			,lp.NextStateModelStateReason			
			,shOld.ServiceStartTime
			,isnull(shStart.ServiceStartTime, @StartDate)
			,shEnd.ServiceStartTime
			,cast(case when (isnull(shEnd.ServiceStartTime, @EndDate) >= @EndDate) then 1 else 0 end as bit) as EventStillOpen
from lead_points lp
left join dbo.T_ServiceHistory shStart on shStart.ServiceHistoryId = lp.ServiceHistoryId
left join dbo.T_StateModelState stsCurrent on stsCurrent.StateModelStateId = lp.MainStateModelStateId 
left join dbo.T_ServiceHistory shEnd on shEnd.ServiceHistoryId = lp.NextServiceHistoryId
left join dbo.T_StateModelState stsNext on stsNext.StateModelStateId = lp.NextStateModelStateChange 
left join dbo.T_ServiceHistory shOld on shOld.ServiceHistoryId = lp.OldServiceHistoryId
left join dbo.T_StateModelState stsPrev on stsPrev.StateModelStateId = lp.PreviousSMS 
where shStart.ServiceStartTime <= @EndDate and isnull(shEnd.ServiceStartTime, @startDate) >= @StartDate


insert into @ResultData
select md.ResourceId
      ,md.Facility
			,md.Area
			,md.line
			,md.CurrentStateModel
			,md.CurrentStateModelReason
			,md.NextStateModel
			,md.NextStateModelReason
			,dbo.F_TimeUTCToLocalTime(md.StartService) as StartEvent
			,dbo.F_TimeUTCToLocalTime(isnull(md.EndService, @ShowNullEndDate)) as EndEvent
			,cast(datediff(second, case when md.StartService < @StartDate then @StartDate else md.StartService end, isnull(md.EndService, @ShowNullEndDate)) as decimal) / 3600  as 'hours'
			,md.EventStillOpen
			,cast(case when md.StartService < @StartDate then 1 else 0 end as bit)
from @MainData md

select * from @ResultData