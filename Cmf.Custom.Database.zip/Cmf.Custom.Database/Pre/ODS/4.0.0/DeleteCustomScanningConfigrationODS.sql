IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'UserDataModel' AND TABLE_NAME = 'T_GT_CustomScanningConfiguration')
BEGIN
	DROP TABLE [UserDataModel].[T_GT_CustomScanningConfiguration];
	DROP TABLE [UserDataModel].[T_GT_CustomScanningConfigurationHistory];
	DELETE FROM [dbo].[T_GenericTable] WHERE NAME = 'CustomScanningConfiguration';
	DELETE FROM [dbo].[T_GenericTable] WHERE NAME = 'CustomScanningConfigurationHistory';
	DELETE FROM [Control].[T_ReplicationTables] WHERE SchemaName = 'UserDataModel' AND TableName = 'T_GT_CustomScanningConfiguration';
	DELETE FROM [Control].[T_ReplicationTables] WHERE SchemaName = 'UserDataModel' AND TableName = 'T_GT_CustomScanningConfigurationHistory';
	
END

