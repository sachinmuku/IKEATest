SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = 'Custom')
BEGIN
EXEC('CREATE SCHEMA Custom')
END
GO

IF EXISTS ( SELECT * 
            FROM   sysobjects 
            WHERE  id = object_id(N'[Custom].[P_ReportMaterialDueDateDeviations]') 
                   and OBJECTPROPERTY(id, N'IsProcedure') = 1 )
BEGIN
    DROP PROCEDURE [Custom].[P_ReportMaterialDueDateDeviations]
END
GO


CREATE PROCEDURE [Custom].[P_ReportMaterialDueDateDeviations]
	@StartDate DATETIME,
	@EndDate DATETIME,
	@FacilityName NVARCHAR(MAX),
	@AreaName NVARCHAR(MAX)
AS
BEGIN

	DECLARE 
	@min BIGINT,
	@max BIGINT,
	@DateStartHost DATETIME = dbo.F_TimeLocalTimeToUTC(@StartDate),
	@DateEndHost DATETIME = DATEADD(DAY, 1, dbo.F_TimeLocalTimeToUTC(@EndDate))


	-- Temp Table with Facilities
	DECLARE @FacilityTempTable TABLE (FacilityName NVARCHAR(512));
	INSERT INTO @FacilityTempTable(FacilityName) 
	SELECT [Value] AS FacilityName 
	FROM [dbo].[F_Split2](@FacilityName, ';');

	-- Temp Table with Area
	DECLARE @AreaTempTable TABLE (AreaName NVARCHAR(512));
	INSERT INTO @AreaTempTable(AreaName) 
	SELECT [Value] AS AreaName 
	FROM [dbo].[F_Split2](@AreaName, ';');


	-- Temp Table with ServiceId
	DECLARE @ServiceTempTable TABLE ([ServiceId] BIGINT, [Name] NVARCHAR(512) );
	INSERT INTO @ServiceTempTable([ServiceId], [Name])
	SELECT [ServiceId], [Name] 
	FROM [Security].T_Service 
	WHERE [Name] IN 
	(
		'CloseProductionOrders',
		'TerminateObjects',
		'TerminateObject'
	);

	DECLARE @ProductionOrder TABLE (ProductionOrderId BIGINT)


	INSERT INTO @ProductionOrder
	SELECT PO.ProductionOrderId
	FROM CoreDataModel.T_ProductionOrder AS PO
	INNER JOIN CoreDataModel.T_Facility F ON F.FacilityId = PO.FacilityId
	INNER JOIN @FacilityTempTable AS FT	ON FT.FacilityName = F.Name
	INNER JOIN CoreDataModel.T_Area AS A ON A.FacilityId = F.FacilityId
	INNER JOIN @AreaTempTable AS AT ON AT.AreaName = A.Name
	WHERE (PO.PlannedStartDate BETWEEN @DateStartHost AND @DateEndHost	
				OR PO.PlannedEndDate BETWEEN @DateStartHost AND @DateEndHost
				OR PO.DueDate BETWEEN @DateStartHost AND @DateEndHost)

	-- Get mininum and maximum ServiceHistoryId from the filtered POs
	SELECT @min = MIN(SH.ServiceHistoryId)
				,@max = MAX(SH.ServiceHistoryId)
	FROM @ProductionOrder AS PO
	INNER JOIN CoreDataModel.T_ProductionOrderHistory AS POH ON POH.ProductionOrderId = PO.ProductionOrderId	
	INNER JOIN dbo.T_ServiceHistory SH ON POH.ServiceHistoryId = SH.ServiceHistoryId;

	DECLARE @ProductionOrderMaterials TABLE (ProductionOrderId BIGINT, AreaId BIGINT, MinTrackInDate DATETIME, MaxModifiedOn DATETIME);
		

	-- Get the mininum track in date and maximum modified on date from the materials of the PO
	INSERT @ProductionOrderMaterials
	SELECT PO.ProductionOrderId

				,SA.TargetEntityId AS AreaId
				,MIN(MH.TrackInDate) AS MinTrackInDate
				,MAX(MH.ModifiedOn) AS MaxModifiedOn
	FROM @ProductionOrder AS PO
	INNER JOIN CoreDataModel.T_MaterialHistory AS MH ON MH.ProductionOrderId = PO.ProductionOrderId	AND MH.ServiceHistoryId BETWEEN @min AND @max
	INNER JOIN CoreDataModel.T_Step AS S ON S.StepId = MH.StepId
	INNER JOIN CoreDataModel.T_StepArea AS SA	ON SA.SourceEntityId = S.StepId
	INNER JOIN CoreDataModel.T_Area AS A ON A.AreaId = SA.TargetEntityId
	INNER JOIN @AreaTempTable AS AT ON AT.AreaName = A.Name
	GROUP BY PO.ProductionOrderId
					,SA.TargetEntityId;

	DECLARE @ClosedPOs TABLE (ProductionOrderId bigint, EndDate datetime);
		
	-- Get all the closed POs in the given timeframe
	INSERT INTO @ClosedPOs
	SELECT PO.ProductionOrderId
				,MAX(sh.ServiceStartTime) AS EndDate
	FROM @ProductionOrder AS PO
	INNER JOIN CoreDataModel.T_ProductionOrderHistory AS POH ON POH.ProductionOrderId = PO.ProductionOrderId
	INNER JOIN dbo.T_ServiceHistory AS SH	ON POH.ServiceHistoryId = sh.ServiceHistoryId
	INNER JOIN @ServiceTempTable AS ASRV ON ASRV.ServiceId = sh.ServiceId
	GROUP BY PO.ProductionOrderId;


	SELECT DISTINCT	dbo.F_TimeUTCToLocalTime(M.MaxModifiedOn) as 'StartDate',
					dbo.F_TimeUTCToLocalTime(CPO.EndDate) as 'EndDate',
					dbo.F_TimeUTCToLocalTime(M.MaxModifiedOn) AS 'MaxModifiedOn',
					F.NAME AS Facility,
					A.NAME AS Area,
					PO.NAME AS POName,
					P.NAME AS Product,
					PO.Quantity AS POPlannedQuantity,
					dbo.F_TimeUTCToLocalTime(PO.PlannedStartDate) AS 'PlannedStartDate',
					dbo.F_TimeUTCToLocalTime(PO.PlannedEndDate) AS 'PlannedEndDate',
					dbo.F_TimeUTCToLocalTime(PO.DueDate) AS 'DueDate'
	FROM @ProductionOrder AS POID
	INNER JOIN CoreDataModel.T_ProductionOrder AS PO ON PO.ProductionOrderId = POID.ProductionOrderId
	INNER JOIN CoreDataModel.T_Facility F ON F.FacilityId = PO.FacilityId
	INNER JOIN CoreDataModel.T_Product AS P	ON P.ProductId = PO.ProductId
	INNER JOIN @ProductionOrderMaterials AS M	ON M.ProductionOrderId = PO.ProductionOrderId
	INNER JOIN CoreDataModel.T_Area AS A	ON A.FacilityId = F.FacilityId AND A.AreaId = M.AreaId
	LEFT JOIN @ClosedPOs AS CPO	ON CPO.ProductionOrderId = PO.ProductionOrderId;

END
