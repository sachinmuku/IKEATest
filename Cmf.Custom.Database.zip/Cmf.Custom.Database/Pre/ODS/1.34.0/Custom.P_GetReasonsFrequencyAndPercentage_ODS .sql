IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = 'Custom')
BEGIN
EXEC('CREATE SCHEMA Custom')
END
GO

IF EXISTS ( SELECT * 
            FROM   sysobjects 
            WHERE  id = object_id(N'[Custom].[P_GetReasonsFrequencyAndPercentage_ODS]') 
                   and OBJECTPROPERTY(id, N'IsProcedure') = 1 )
BEGIN
    DROP PROCEDURE [Custom].[P_GetReasonsFrequencyAndPercentage_ODS]
END
GO

CREATE PROCEDURE [Custom].[P_GetReasonsFrequencyAndPercentage_ODS] 
(
	@TimeFrame NVARCHAR(28), --Day, Week, Month 
	@GetActual BIT = 0, -- 0: yesterday, 1: today
	@ShowDecimals BIT = 0, -- 0: round to 0, 1: round to 1 decimal digits
	@Facility NVARCHAR(512),  -- Facility name
	@Area NVARCHAR(512),  -- Area name,
	@ProductType NVARCHAR(512),  -- Product type (Product ProductType)
	@ProductGroup NVARCHAR(512), -- Product Group
	@Resources  NVARCHAR(4000), -- One or more resources (only key will be set)
	@Steps NVARCHAR(4000), -- One or more steps (only key will be set)
	@Products NVARCHAR(4000), -- One or more products (only key will be set)
	@StepTypes NVARCHAR(4000), -- One or more step types (only key will be set)
	@ResourceTypes NVARCHAR(4000), -- One or more resource types (only key will be set)
	@ResourceResourceTypes NVARCHAR(4000), -- One or more resource resource types (only key will be set)
	@ShiftDefinition NVARCHAR(4000), -- Only Works with one ShiftDefinition
	@ShiftName NVARCHAR(4000), -- Requires the ShiftDefinition to be defined
	@PrintScript BIT=1 -- One or more products (only key will be set)
)
AS
BEGIN
	DECLARE @OPENQUERY nvarchar(4000), @TSQL nvarchar(4000), @LinkedServer nvarchar(4000);
	SET @LinkedServer = N'cm'+[dbo].[F_GetSystemName]()+N'ASLink';
	
	DECLARE 
		@ResourceFilter nvarchar(1000),
		@ResourceTypesFilter nvarchar(1000),
		@ResourceResourceTypesFilter nvarchar(1000),  
		@ResourceMatFilter nvarchar(1000) = '', 
		@FacilityFilter nvarchar(1000), 
		@AreaFilter nvarchar(1000), 
		@ProductsFilter nvarchar(1000), 
		@ProductTypeFilter nvarchar(1000), 
		@ProductGroupFilter nvarchar(1000), 
		@StepsFilter nvarchar(1000),
		@StepTypesFilter nvarchar(1000),
		@ClosureCommas nvarchar(20) = '',
		@TimeFilter nvarchar(1000), 
		@TimeSelectCols nvarchar(1000),
		@ShiftDefinitionFilter nvarchar(1000),
		@ShiftFilter nvarchar(1000);
			

	BEGIN /* Filters Instantiation */
		IF (len(@Resources) > 0)
		BEGIN
			SET @ResourceFilter = 'FROM ( SELECT ( {[Resource].[Resource Name].&[' + replace(@Resources, ',', '], [Resource].[Resource Name].&[') + '] } ) ON COLUMNS';
			SET @ClosureCommas += ')';
		END
		ELSE
		BEGIN
			SET @ResourceFilter = '';
		END;

		-- resource types
		IF (len(@ResourceTypes) > 0)
		BEGIN
			SET @ResourceTypesFilter = 'FROM ( SELECT ( {[Resource].[Type].&[' + replace(@ResourceTypes, ',', '], [Resource].[Type].&[') + '] } ) ON COLUMNS';
			SET @ClosureCommas += ')';
		END
		ELSE
		BEGIN
			SET @ResourceTypesFilter = '';
		END;

		-- resource resource types
		IF (len(@ResourceResourceTypes) > 0)
		BEGIN
			SET @ResourceResourceTypesFilter = 'FROM ( SELECT ( {[Resource].[Resource Type].&[' + replace(@ResourceResourceTypes, ',', '], [Resource].[Resource Type].&[') + '] } ) ON COLUMNS';
			SET @ClosureCommas += ')';
		END
		ELSE
		BEGIN
			SET @ResourceResourceTypesFilter = '';
		END;
	
		--facility
		IF (len(@Facility) > 0)
		BEGIN
			SET @FacilityFilter = 'FROM ( SELECT ( {[Facility].[Facility Name].&[' + replace(@Facility, ',', '], [Facility].[Facility Name].&[') + '] } ) ON COLUMNS';
			SET @ClosureCommas += ')';
		END
		ELSE
		BEGIN
			SET @FacilityFilter = '';
		END;

		--area
		IF (len(@Area) > 0)
		BEGIN
			SET @AreaFilter = 'FROM ( SELECT ( {[Area].[Area Name].&[' + replace(@Area, ',', '], [Area].[Area Name].&[') + '] } ) ON COLUMNS';
			SET @ClosureCommas += ')';
		END
		ELSE
		BEGIN
			SET @AreaFilter = '';
		END;

		--product
		IF (len(@Products) > 0)
		BEGIN
			SET @ProductsFilter = 'FROM ( SELECT ( {[Product].[Product Name].[' + replace(@Products, ',', '], [Product].[Product Name].[') + '] } ) ON COLUMNS';
			SET @ClosureCommas += ')';
		END
		ELSE
		BEGIN
			SET @ProductsFilter = '';
		END;

		--product type
		IF (len(@ProductType) > 0)
		BEGIN
			SET @ProductTypeFilter= 'FROM ( SELECT ( {[Product].[Product Type].&[' + replace(@ProductType, ',', '], [Product].[Product Type].&[') + '] } ) ON COLUMNS';
			SET @ClosureCommas += ')';
		END
		ELSE
		BEGIN
			SET @ProductTypeFilter = '';
		END;

		--product group 
		IF (len(@ProductGroup) > 0)
		BEGIN
			SET @ProductGroupFilter = 'FROM ( SELECT ( {[Product Group].[Product Group Name].&[' + replace(@ProductGroup, ',', '], [Product Group].[Product Group Name].&[') + '] } ) ON COLUMNS';
			SET @ClosureCommas += ')';
		END
		ELSE
		BEGIN
			SET @ProductGroupFilter = '';
		END;

		--steps filter
		IF (len(@Steps) > 0)
		BEGIN
			SET @StepsFilter = 'FROM ( SELECT ( {[Step].[Step Name].&[' + replace(@Steps, ',', '], [Step].[Step Name].&[') + '] } ) ON COLUMNS';
			SET @ClosureCommas += ')';
		END
		ELSE
		BEGIN
			SET @StepsFilter = '';
		END;

		--step types filter
		IF (len(@StepTypes) > 0)
		BEGIN
			SET @StepTypesFilter = 'FROM ( SELECT ( {[Step].[Step Type].&[' + replace(@StepTypes, ',', '], [Step].[Step Type].&[') + '] } ) ON COLUMNS';
			SET @ClosureCommas += ')';
		END
		ELSE
		BEGIN
			SET @StepTypesFilter = '';
		END;

		IF(@TimeFrame = 'Day')
		BEGIN
-- get actual influences start and end search
			SET @TimeFilter = 
'FROM ( SELECT ( StrToMember(''''[Date].[Calendar Day].[Calendar Day].&['''' + FORMAT(Now(), "yyyy-MM-dd") + '''']'''').Lag('				
						+ case when @GetActual = 0 then '8' else '7' end +')  : StrToMember(''''[Date].[Calendar Day].[Calendar Day].&['''' + FORMAT(Now(), "yyyy-MM-dd") + '''']'''')'+ case when @GetActual = 0 then '.Lag(1)' else '' end +' ) ON COLUMNS';			
			SET @ClosureCommas += ')';
		END
		ELSE IF(@TimeFrame = 'Week')
		BEGIN
-- get actual influences start and end search
			SET @TimeFilter = 
'FROM ( SELECT ( StrToMember(''''[Date].[Calendar Weeks].[Calendar Week].&['				 + Format(datepart(week, getutcdate()), '00')+']&['+Format(datepart(year, getutcdate()), '0000')+']'''').Lag('
						+ case when @GetActual = 0 then '8' else '7' end +')  : StrToMember(''''[Date].[Calendar Weeks].[Calendar Week].&[' + Format(datepart(week, getutcdate()), '00')+']&['+Format(datepart(year, getutcdate()), '0000')+']'''')'+ case when @GetActual = 0 then '.Lag(1)' else '' end +' ) ON COLUMNS';			
			SET @ClosureCommas += ')';
		END
		ELSE IF(@TimeFrame = 'Month')
		BEGIN
-- get actual influences start and end search
			SET @TimeFilter = 
'FROM ( SELECT ( StrToMember(''''[Date].[Calendar Months].[Calendar Month].&['''' + FORMAT(Now(), "\MMM \C\Y yyyy") + '''']'''').Lag('				
						+ case when @GetActual = 0 then '8' else '7' end +')  : StrToMember(''''[Date].[Calendar Months].[Calendar Month].&['''' + FORMAT(Now(), "\MMM \C\Y yyyy") + '''']'''')'+ case when @GetActual = 0 then '.Lag(1)' else '' end +' ) ON COLUMNS';			
				SET @ClosureCommas += ')';
			end;
		END;
		
		-- Shift filter
		IF (LEN(@ShiftName) > 0 AND LEN(@ShiftDefinition) > 0)
		BEGIN
			SET @ShiftFilter = 'FROM ( SELECT ( {[Shift].[Shift Hierarchy].[Shift Description].&[' + @ShiftDefinition + ' (' + @ShiftDefinition + ' - ' + replace(@ShiftName, ',', ')], [Shift].[Shift Hierarchy].[Shift Description].&[' + @ShiftDefinition + ' (' + @ShiftDefinition + ' - ') + ')] } ) ON COLUMNS';
			SET @ClosureCommas += ')';
		END
		ELSE
		BEGIN
			SET @ShiftFilter = '';
		END;



	IF (exists(select * from sys.servers where name = @LinkedServer))
	BEGIN
	  BEGIN TRY
		declare @MDXQuery nvarchar(4000) = N'
		select Reason, Frequency, 
			ROUND(convert(decimal(18,2), sum(Frequency) over (order by Frequency desc ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) * 100
				/ sum(Frequency) over (order by Frequency desc ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING)), ${ShowDecimals}) RunningTotal
		from (
			select convert(nvarchar(256),"[Loss Reason].[Reason Hierarchy].[Reason Name].[MEMBER_CAPTION]") as Reason,
				   convert(decimal(18,8),"[Measures].[Material Loss Bonus Count]") as Frequency
			 from OPENQUERY('+ @LinkedServer + N',''
				SELECT NON EMPTY { [Measures].[Material Loss Bonus Count] } ON COLUMNS
					 , NON EMPTY { ORDER([Loss Reason].[Reason Hierarchy].[Reason Name], [Measures].[Material Loss Bonus Count], bdesc) } ON ROWS
					  FROM ( SELECT ( { [Loss Reason].[Reason Hierarchy].[Reason Type].&[Loss] } ) ON COLUMNS
						  ${ResourceFilter}
						  ${ResourceTypeFilter}
						  ${ResourceResourceTypeFilter}
						  ${FacilityFilter}
						  ${AreaFilter}		
						  ${TimeFilter}
						  ${Products}
						  ${ProductType}
						  ${ProductGroup}
						  ${Steps}
						  ${StepTypes}
						  ${ShiftFilter}
					from [Material] ${ClosureCommas} )'')
			) dat
		 where dat.Reason not in (''-'', '''')
		 order by dat.Frequency desc
		 ';
		
		SET @MDXQuery = REPLACE(@MDXQuery, '${ResourceFilter}',		@ResourceFilter);
		SET @MDXQuery = REPLACE(@MDXQuery, '${ResourceTypeFilter}',	 @ResourceTypesFilter);
		SET @MDXQuery = REPLACE(@MDXQuery, '${ResourceResourceTypeFilter}',@ResourceResourceTypesFilter);
		SET @MDXQuery = REPLACE(@MDXQuery, '${ResourceMatFilter}',	@ResourceMatFilter);
		SET @MDXQuery = REPLACE(@MDXQuery, '${FacilityFilter}',		@FacilityFilter);
		SET @MDXQuery = REPLACE(@MDXQuery, '${AreaFilter}',			@AreaFilter);
		SET @MDXQuery = REPLACE(@MDXQuery, '${Products}',			@ProductsFilter);
		SET @MDXQuery = REPLACE(@MDXQuery, '${ProductType}',		@ProductTypeFilter);
		SET @MDXQuery = REPLACE(@MDXQuery, '${ProductGroup}',		@ProductGroupFilter);
		SET @MDXQuery = REPLACE(@MDXQuery, '${Steps}',				@StepsFilter);
		SET @MDXQuery = REPLACE(@MDXQuery, '${StepTypes}',			@StepTypesFilter);
		SET @MDXQuery = REPLACE(@MDXQuery, '${ClosureCommas}',		@ClosureCommas);
		SET @MDXQuery = REPLACE(@MDXQuery, '${TimeFilter}',			@TimeFilter);
		SET @MDXQuery = REPLACE(@MDXQuery, '${ShowDecimals}',		@ShowDecimals);		
		SET @MDXQuery = REPLACE(@MDXQuery, '${ShiftFilter}',		@ShiftFilter);		
	
		IF(@PrintScript = 1) 
		BEGIN
			PRINT substring(@MDXQuery, 1, 3000)
			if(len(@MDXQuery) > 3000)
				PRINT substring(@MDXQuery, 3001, len(@MDXQuery));
		END;

		exec sp_executesql @MDXQuery;

	  END TRY
	  BEGIN CATCH						
			DECLARE @ErrorMessage NVARCHAR(4000);
			DECLARE @ErrorSeverity INT;
			DECLARE @ErrorState INT;
							
			SELECT  @ErrorMessage = ERROR_MESSAGE(),
					@ErrorSeverity = 0,
					@ErrorState = 0;

			PRINT @ErrorMessage;
			select '' as Reason, 0 as Frequency, 0 as RunningTotal where 1 = 0;
	  END CATCH;
		
	END
	ELSE
	BEGIN
		DECLARE @Msg nvarchar(512) = 'Missing Linked Server. Assuming no SSAS services were configured.';
		RAISERROR ( @Msg, 0, 1) WITH NOWAIT
	END;
END;
GO