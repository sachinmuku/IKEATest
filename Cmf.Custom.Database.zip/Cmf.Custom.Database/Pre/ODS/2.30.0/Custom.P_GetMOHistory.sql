IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = 'Custom')
BEGIN
EXEC('CREATE SCHEMA Custom')
END
GO

IF EXISTS ( SELECT * 
            FROM   sysobjects 
            WHERE  id = object_id(N'[Custom].[P_GetMOHistory]') 
                   and OBJECTPROPERTY(id, N'IsProcedure') = 1 )
BEGIN
    DROP PROCEDURE [Custom].[P_GetMOHistory]
END
GO

CREATE PROCEDURE [Custom].[P_GetMOHistory]
(
	@Start datetime = NULL,
	@End datetime = NULL,  
	@FacilityName nvarchar(MAX) = NULL,
	@AreaName nvarchar(MAX) = NULL,
	@StepName nvarchar(MAX) = NULL,
	@ResourceName nvarchar(MAX) = NULL,
	@OrderStatus nvarchar(MAX) = NULL,
	@MaterialName nvarchar(MAX) = NULL
)
AS
BEGIN

	SET NOCOUNT ON;
	
	/* declare vars */
	DECLARE 
		@FirstServiceHistoryId bigint = NULL,
		@LastServiceHistoryId bigint = NULL,
		@OrderMaterialForm nvarchar(30),
		@StartDate datetime = dbo.F_TimeLocalTimeToUTC(@Start),
		@FinalDate datetime = DATEADD(DAY, 1, dbo.F_TimeLocalTimeToUTC(@End));

	/* Get first AND last service history ids by date */
	SET @FirstServiceHistoryId = [dbo].[F_Part_GetMinServiceHistoryIdForDate](DATEADD(DAY, -1, @StartDate))
	SET @LastServiceHistoryId = [dbo].[F_Part_GetMaxServiceHistoryIdForDate](DATEADD(DAY, 1, @FinalDate))

	/* Create temporary tables. They should NOT exist, but just in CASE drop them IF they do.. */
	IF(OBJECT_ID('tempdb..#OrderSystemStates') IS NOT NULL) 
		DROP TABLE #OrderSystemStates;
		
	IF(OBJECT_ID('tempdb..#MaterialTrackings') IS NOT NULL) 
		DROP TABLE #MaterialTrackings;

	IF(OBJECT_ID('tempdb..#FacilityTempTable') IS NOT NULL) 
		DROP TABLE #FacilityTempTable;

	IF(OBJECT_ID('tempdb..#AreaTempTable') IS NOT NULL) 
		DROP TABLE #AreaTempTable;

	IF(OBJECT_ID('tempdb..#StepTempTable') IS NOT NULL) 
		DROP TABLE #StepTempTable;

	IF(OBJECT_ID('tempdb..#ResourceTempTable') IS NOT NULL) 
		DROP TABLE #ResourceTempTable;

	IF(OBJECT_ID('tempdb..#OrderStatusTempTable') IS NOT NULL) 
		DROP TABLE #OrderStatusTempTable;

	IF(OBJECT_ID('tempdb..#MOGeneratedMaterials') IS NOT NULL) 
		DROP TABLE #MOGeneratedMaterials;

	CREATE TABLE #OrderSystemStates 
	(
		SystemState int, 
		[Name] nvarchar(512), 
		[Status] nvarchar(512)
	);

	CREATE TABLE #FacilityTempTable 
	(
		[Name] nvarchar(512)
	);

	CREATE TABLE #StepTempTable 
	(
		[Name] nvarchar(512)
	);

	CREATE TABLE #ResourceTempTable 
	(
		[Name] nvarchar(512)
	);
	
	CREATE TABLE #AreaTempTable 
	(
		[Name] nvarchar(512)
	);

	CREATE TABLE #OrderStatusTempTable 
	(
		[Name] nvarchar(512)
	);

	CREATE TABLE #MOGeneratedMaterials
	(
		MOId bigint,
		PalletId bigint,
		PalletName nvarchar(512),
		PalletPrimaryQuantity decimal,
		ModifiedOn datetime,
		PalletType nvarchar(512),
		MORunNumber int
	);

	/* Set data for production order system states */
	INSERT INTO #OrderSystemStates
	VALUES
	(0, 'Created', 'Open'),
	(1, 'Released', 'Open'),
	(2, 'InProgress', 'Open'),
	(3, 'Completed', 'Closed'),
	(4, 'Closed', 'Closed'),
	(5, 'Canceled', 'Closed');

	/* Temp Table WITH Facilities */
	IF(@FacilityName IS NOT NULL)
	BEGIN
	  INSERT INTO #FacilityTempTable 
	  SELECT [Value] FROM [dbo].[F_Split2](@FacilityName, ';');
	END
	
	/* Temp Table WITH Areas */
	IF(@AreaName IS NOT NULL)
	BEGIN
	  INSERT INTO #AreaTempTable 
	  SELECT [Value] FROM [dbo].[F_Split2](@AreaName, ';');
	END

	/* Temp Table WITH Steps */
	IF(@StepName IS NOT NULL)
	BEGIN
	  INSERT INTO #StepTempTable
	  SELECT [Value] FROM [dbo].[F_Split2](@StepName, ';');
	END

	/* Temp Table WITH Resources */
	IF(@ResourceName IS NOT NULL)
	BEGIN
	  INSERT INTO #ResourceTempTable
	  SELECT [Value] FROM [dbo].[F_Split2](@ResourceName, ';');
	END

	/* Temp Table WITH OrderStatus */
	IF(@OrderStatus IS NOT NULL)
	BEGIN
		INSERT INTO #OrderStatusTempTable
		SELECT [Value] FROM [dbo].[F_Split2](@OrderStatus, ';');
	END

	CREATE TABLE #MaterialTrackings
	(
		OrderRunNumber int,
		OrderName nvarchar(512),
		OrderOperationStart datetime,
		OrderOperationEnd datetime
	);

	-- Get Order Information
	INSERT INTO #MaterialTrackings
	SELECT
		EOT.OrderRunNumber, 
		EOT.OrderMateriaL, 
		MIN(EOT.OrderOperationStart) OrderOperationStart,
		MAX(EOT.OrderOperationEnd) OrderOperationEnd 
	FROM UserDataModel.T_CustomERPOperationTracking AS EOT
	WHERE EOT.LastServiceHistoryId BETWEEN @FirstServiceHistoryId AND @LastServiceHistoryId
		AND EOT.OrderOperationStart BETWEEN @StartDate AND @FinalDate
		AND 
		(
			EOT.OrderOperationEnd IS NULL
			OR EOT.OrderOperationEnd BETWEEN @StartDate AND @FinalDate
		)
		AND 
		(
			@MaterialName IS NULL 
			OR OrderMaterial LIKE (@MaterialName + '%')
		)
	GROUP BY OrderRunNumber, OrderMaterial; 
	
	-- Get Pallet Information
	INSERT INTO #MOGeneratedMaterials
	(
		MOId,
		PalletId,
		PalletName,
		PalletPrimaryQuantity ,
		ModifiedOn,
		PalletType,
		MORunNumber
	)
	SELECT 
		M.MaterialId,
		MP.MaterialId,
		MP.Name,
		MP.PrimaryQuantity,
		dbo.F_TimeUTCToLocalTime(MP.ModifiedOn) AS ModifiedOn,
		MP.Type,
        MA.Value
	FROM (SELECT DISTINCT OrderName FROM #MaterialTrackings) AS MT
	INNER JOIN CoreDataModel.T_Material AS M
		ON M.Name = MT.OrderName
	LEFT JOIN UserDataModel.T_CustomMaterialBatch AS MB
		ON MB.TargetEntityId = M.MaterialId
	LEFT JOIN CoreDataModel.T_Material AS MP
		ON MP.MaterialId = MB.SourceEntityId
	LEFT JOIN CoreDataModel.T_MaterialAttribute MA
		ON MP.MaterialId = MA.MaterialId 
		AND MA.[Name] = 'OrderRunNumber';

	SELECT 
		MT.OrderOperationStart AS Start_ServiceDate,
		MT.OrderOperationEnd AS End_ServiceDate,
		PO.Name AS OrderNumber,
		F.Name AS Facility,
		S.Name AS Step,
		PD.Name AS ProductName,
		PD.Description AS ProductDescription,
		MT.OrderName AS MO_MaterialName,
		R.Name AS LastResource,
		MA.Value AS M_Attributte_Manufactured_Quantity,
		PO.Quantity AS PO_Planned_Quantity,
		SSO.[Status] AS PO_Status,
		MGM.PalletName AS Pallet_MaterialName,
		MGM.PalletPrimaryQuantity AS Pallet_PrimaryQuantity,
		MGM.ModifiedOn,
		MGM.PalletType AS Type
	FROM #MaterialTrackings AS MT
	INNER JOIN CoreDataModel.T_Material AS M
		ON M.Name = MT.OrderName
	LEFT JOIN CoreDataModel.T_MaterialAttribute MA
		ON M.MaterialId = MA.MaterialId 
		AND MA.[Name] = 'CompletedQuantity'
	INNER JOIN CoreDataModel.T_ProductionOrder PO 
		ON PO.ProductionOrderId = M.ProductionOrderId		
	INNER JOIN #OrderSystemStates SSO 
		ON PO.SystemState = SSO.SystemState
	INNER JOIN CoreDataModel.T_Facility AS F
		ON F.FacilityId = M.FacilityId
	LEFT JOIN #FacilityTempTable AS FT
		ON FT.Name = F.Name
	INNER JOIN CoreDataModel.T_Step AS S
		ON S.StepId = M.StepId
	LEFT JOIN #StepTempTable AS ST
		ON ST.Name = S.Name
	INNER JOIN CoreDataModel.T_Product AS P
		ON P.ProductId = M.ProductId
	INNER JOIN CoreDataModel.T_Product AS PD
		ON PD.ProductId = P.DefinitionId
	INNER JOIN CoreDataModel.T_Resource AS R
		ON R.ResourceId = M.LastProcessedResourceId
	LEFT JOIN #ResourceTempTable AS RT
		ON RT.Name = R.Name
	INNER JOIN CoreDataModel.T_Area AS A
		ON A.AreaId = R.AreaId
	LEFT JOIN #AreaTempTable AS AT
		ON AT.Name = A.Name
	LEFT JOIN #MOGeneratedMaterials AS MGM 
		ON MGM.MOId = M.MaterialId AND MGM.MORunNumber = MT.OrderRunNumber
	LEFT JOIN #OrderStatusTempTable AS OST
		ON OST.[Name] = SSO.[Status]
	WHERE 
		(
			(
				@FacilityName IS NOT NULL 
				AND FT.[Name] IS NOT NULL
			) 
			OR @FacilityName IS NULL
		)
		AND 
		(
			(
				@StepName IS NOT NULL 
				AND ST.[Name] IS NOT NULL
			) 
			OR @StepName IS NULL
		)
		AND 
		(
			(
				@ResourceName IS NOT NULL 
				AND RT.[Name] IS NOT NULL
			) 
			OR @ResourceName IS NULL
		)
		AND 
		(
			(
				@AreaName IS NOT NULL 
				AND AT.[Name] IS NOT NULL
			) 
			OR @AreaName IS NULL
		)
		AND 
		(
			(
				@OrderStatus IS NOT NULL 
				AND OST.[Name] IS NOT NULL
			) 
			OR @OrderStatus IS NULL
		);
END;
