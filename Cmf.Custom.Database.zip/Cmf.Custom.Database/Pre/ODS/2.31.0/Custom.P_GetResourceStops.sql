IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = 'Custom')
BEGIN
EXEC('CREATE SCHEMA Custom')
END
GO

IF EXISTS ( SELECT * 
            FROM   sysobjects 
            WHERE  id = object_id(N'[Custom].[P_GetResourceStops]') 
                   and OBJECTPROPERTY(id, N'IsProcedure') = 1 )
BEGIN
    DROP PROCEDURE [Custom].[P_GetResourceStops]
END
GO

CREATE PROCEDURE [Custom].[P_GetResourceStops]
(
    @StartDate datetime = null,
    @EndDate datetime = null,
    @FacilityNames nvarchar(max) = null,
    @AreaNames nvarchar(max) = null,
	@ShiftDefinitions nvarchar(max) = null,
	@ShiftNames nvarchar(max) = null,
	@ResourceTypes nvarchar(max) = null,
    @ResourceNames nvarchar(max) = null,
	@StateModels nvarchar(max) = null,
    @StateModelStates nvarchar(max) = null,
    @Reasons nvarchar(max) = null,
	@StopType nvarchar(max) = null
)
AS
BEGIN


	DECLARE 
		@WorkUnitStateModelId BIGINT,
		@WorkUnitStateModelStateId BIGINT;

	DECLARE @DateStartHost DATETIME = dbo.F_TimeLocalTimeToUTC(@StartDate);
    DECLARE @DateEndHost DATETIME = dateadd(day, 1, dbo.F_TimeLocalTimeToUTC(@EndDate));

	DECLARE 
		@FirstServiceHistoryId BIGINT = (SELECT [dbo].[F_Part_GetMinServiceHistoryIdForDate] (dateadd(day, -1, @DateStartHost))),
		@LastServiceHistoryId BIGINT = (SELECT [dbo].[F_Part_GetMaxServiceHistoryIdForDate] (@DateEndHost));
		
	DECLARE 
		@WorkUnitStateModel nvarchar(512) = [dbo].[F_GetConfigStringValue](N'/Cmf/Custom/Resources/StateReclassifications/WorkUnit/UnplannedStateModel/', N'PackML'),
		@WorkUnitStateModelState nvarchar(512) = [dbo].[F_GetConfigStringValue](N'/Cmf/Custom/Resources/StateReclassifications/WorkUnit/UnplannedStateModelState/', N'Stopped');

	DECLARE
		@Microstops bit,
		@Justified bit,
		@NotJustified bit;
		
	-- Check if should apply the microstop filter
	SET @Microstops = 
	(
		SELECT 
			CASE WHEN [Value] IS NULL
				THEN 0
				ELSE 1
			END
		FROM [dbo].[F_Split2](@StopType, ';') AS FF
		WHERE [Value] = 'Microstops'
	);

	-- Check if should apply the justified filter
	SET @Justified = 
	(
		SELECT 
			CASE WHEN [Value] IS NULL
				THEN 0
				ELSE 1
			END
		FROM [dbo].[F_Split2](@StopType, ';') AS FF
		WHERE [Value] = 'Justified'
	);

	-- Check if should apply the not justified filter
	SET @NotJustified = 
	(
		SELECT 
			CASE WHEN [Value] IS NULL
				THEN 0
				ELSE 1
			END
		FROM [dbo].[F_Split2](@StopType, ';') AS FF
		WHERE [Value] = 'NotJustified'
	);

	-- Get State Model Id
	SET @WorkUnitStateModelId =
	(
		SELECT SM.StateModelId
		FROM dbo.T_StateModel AS SM
		WHERE SM.[Name] = @WorkUnitStateModel
	)

	-- Get State Model State Id
	SET @WorkUnitStateModelStateId =
	(
		SELECT SMS.StateModelStateId
		FROM dbo.T_StateModelState AS SMS
		WHERE SMS.StateModelId = @WorkUnitStateModelId
			AND SMS.[Name] = @WorkUnitStateModelState
	)

	/* Create temporary tables. They should not exist, but just in case drop them if they do.. */
	IF(OBJECT_ID('tempdb..#FacilityFilter') IS NOT NULL) 
		DROP TABLE #FacilityFilter;
		
	IF(OBJECT_ID('tempdb..#AreaFilter') IS NOT NULL) 
		DROP TABLE #AreaFilter;
		
	IF(OBJECT_ID('tempdb..#ShiftDefinitionFilter') IS NOT NULL) 
		DROP TABLE #ShiftDefinitionFilter;

	IF(OBJECT_ID('tempdb..#ShiftFilter') IS NOT NULL) 
		DROP TABLE #ShiftFilter;
		
	IF(OBJECT_ID('tempdb..#ResourceTypeFilter') IS NOT NULL) 
		DROP TABLE #ResourceTypeFilter;

	IF(OBJECT_ID('tempdb..#ResourceFilter') IS NOT NULL) 
		DROP TABLE #ResourceFilter;
		
	IF(OBJECT_ID('tempdb..#StateModelFilter') IS NOT NULL) 
		DROP TABLE #StateModelFilter;
		
	IF(OBJECT_ID('tempdb..#StateModelStateFilter') IS NOT NULL) 
		DROP TABLE #StateModelStateFilter;

	IF(OBJECT_ID('tempdb..#ReasonFilter') IS NOT NULL) 
		DROP TABLE #ReasonFilter;

	IF(OBJECT_ID('tempdb..#ElegibleResources') IS NOT NULL) 
		DROP TABLE #ElegibleResources;

	IF(OBJECT_ID('tempdb..#ResourceStateTransitions') IS NOT NULL) 
		DROP TABLE #ResourceStateTransitions;

	CREATE TABLE #FacilityFilter
	(
		FacilityId bigint,
		FacilityName nvarchar(512)
	);
	
	CREATE TABLE #AreaFilter
	(
		AreaId bigint,
		AreaName nvarchar(512)
	);

	CREATE TABLE #ShiftDefinitionFilter
	(
		ShiftDefinitionId bigint,
		ShiftDefinitionName nvarchar(512)
	);
	
	CREATE TABLE #ShiftFilter
	(
		ShiftId bigint,
		ShiftName nvarchar(512)
	);
	
	CREATE TABLE #ResourceTypeFilter
	(
		ResourceType nvarchar(512)
	);
	
	CREATE TABLE #ResourceFilter
	(
		ResourceId bigint,
		ResourceName nvarchar(512)
	);
	
	CREATE TABLE #StateModelFilter
	(
		StateModelId bigint,
		StateModelName nvarchar(512)
	);
	
	CREATE TABLE #StateModelStateFilter
	(
		StateModelStateId bigint,
		StateModelStateName nvarchar(512)
	);

	CREATE TABLE #ReasonFilter
	(
		ReasonName nvarchar(512)
	);

	CREATE TABLE #ElegibleResources
	(
		ResourceId bigint,
		ResourceName nvarchar(512),
		AreaId bigint,
		AreaName nvarchar(512),
		FacilityId bigint,
		FacilityName nvarchar(512),
		ResourceType nvarchar(512)
	);

	CREATE TABLE #ResourceStateTransitions
	(
		ResourceId bigint,
		ResourceName nvarchar(512),
		FacilityId bigint,
		Facility nvarchar(50),
		AreaId bigint,
		Area nvarchar(50),
		Line nvarchar(50),
		PreviousStateModel nvarchar(50),
		PreviousStateModelState nvarchar(50),
		PreviousStateModelReason nvarchar(50),
		CurrentStateModel nvarchar(50),
		CurrentStateModelState nvarchar(50),
		CurrentStateModelReason nvarchar(50),
		NextStateModel nvarchar(50),
		NextStateModelState nvarchar(50),
		NextStateModelReason nvarchar(50),
		OldStartService datetime,
		StartService datetime,
		EndService datetime,
		EventStillOpen bit,
		ResourceType nvarchar(512),
	);

	/* Temp Table with Facilities */
	IF(@FacilityNames IS NOT NULL)
	BEGIN
	  INSERT INTO #FacilityFilter
	  SELECT 
		F.FacilityId, 
		FF.[Value] 
	  FROM [dbo].[F_Split2](@FacilityNames, ';') AS FF
	  INNER JOIN CoreDataModel.T_Facility AS F
		ON F.[Name] = FF.[Value];
	END;

	/* Temp Table with Areas */
	IF(@AreaNames IS NOT NULL)
	BEGIN
		INSERT INTO #AreaFilter
		SELECT 
			A.AreaId, 
			AF.[Value] 
		FROM [dbo].[F_Split2](@AreaNames, ';') AS AF
		INNER JOIN CoreDataModel.T_Area AS A
			ON A.[Name] = AF.[Value];
	END;

	/* Temp Table with Shift Definitions */
	IF(@ShiftDefinitions IS NOT NULL)
	BEGIN
		INSERT INTO #ShiftDefinitionFilter
		SELECT 
			SD.ShiftDefinitionId, 
			SDF.[Value] 
		FROM [dbo].[F_Split2](@ShiftDefinitions, ';') AS SDF
		INNER JOIN CoreDataModel.T_ShiftDefinition AS SD
			ON SD.[Name] = SDF.[Value];
	END;
	
	/* Temp Table with Shifts */
	IF(@ShiftNames IS NOT NULL)
	BEGIN
		INSERT INTO #ShiftFilter
		SELECT
			SDS.ShiftDefinitionShiftId,
			SDSF.[Value]
		FROM [dbo].[F_Split2](@ShiftNames, ';') AS SDSF
		INNER JOIN CoreDataModel.T_ShiftDefinitionShift AS SDS
			ON SDS.[Name] = SDSF.[Value]
		INNER JOIN #ShiftDefinitionFilter AS SDF
			ON SDF.ShiftDefinitionId = SDS.ShiftDefinitionId;
	END;
	
	/* Temp Table with Resource Types */
	IF(@ResourceTypes IS NOT NULL)
	BEGIN
		INSERT INTO #ResourceTypeFilter
		SELECT
			RTF.[Value]
		FROM [dbo].[F_Split2](@ResourceTypes, ';') AS RTF;
	END;
	
	/* Temp Table with Resources */
	IF(@ResourceNames IS NOT NULL)
	BEGIN
	  INSERT INTO #ResourceFilter
	  SELECT 
		R.ResourceId,
		RF.[Value] 
	  FROM [dbo].[F_Split2](@ResourceNames, ';') AS RF
	  INNER JOIN CoreDataModel.T_Resource AS R
		ON R.[Name] = RF.[Value];
	END;

	/* Temp Table with State Models */
	IF(@StateModels IS NOT NULL)
	BEGIN
	  INSERT INTO #StateModelFilter
	  SELECT 
		SM.StateModelId, 
		SMF.[Value] 
	  FROM [dbo].[F_Split2](@StateModels, ';') AS SMF
	  INNER JOIN dbo.T_StateModel AS SM
		ON SM.[Name] = SMF.[Value];
	END;

	/* Temp Table with State Model States */
	IF(@StateModelStates IS NOT NULL)
	BEGIN
	  INSERT INTO #StateModelStateFilter
	  SELECT 
		SMS.StateModelStateId, 
		SMSF.[Value] 
	  FROM [dbo].[F_Split2](@StateModelStates, ';') AS SMSF
	  INNER JOIN dbo.T_StateModelState AS SMS
		ON SMS.[Name] = SMSF.[Value];
	END;

	/* Temp Table with Reasons */
	IF(@StateModelStates IS NOT NULL)
	BEGIN
	  INSERT INTO #ReasonFilter
	  SELECT 
		RF.[Value] 
	  FROM [dbo].[F_Split2](@Reasons, ';') AS RF;
	END;

	/* Get list of elegible top most resources according to report filters */
	INSERT INTO #ElegibleResources
	SELECT 
		R.ResourceId, 
		R.[Name],
		A.AreaId,
		A.[Name], 
		F.FacilityId,
		F.[Name],
		R.Type
	FROM CoreDataModel.T_Resource AS R 
	INNER JOIN CoreDataModel.T_Area AS A 
		ON R.AreaId = A.AreaId
	INNER JOIN CoreDataModel.T_Facility AS F 
		ON A.FacilityId = F.FacilityId
	LEFT JOIN #FacilityFilter AS FF 
		ON FF.[FacilityId] = F.[FacilityId]
	LEFT JOIN #AreaFilter AS AF 
		ON AF.[AreaId] = A.[AreaId]
	LEFT JOIN #ResourceFilter AS RF
		ON RF.[ResourceId] = R.[ResourceId]
	LEFT JOIN #ResourceTypeFilter AS RTF
		ON RTF.[ResourceType] = R.[Type]
	WHERE R.ParentResourcesCount = 0
		AND 
		(
			(
				@FacilityNames IS NOT NULL
				AND FF.FacilityName IS NOT NULL
			) 
			OR @FacilityNames IS NULL
		)
		AND
		(
			(
				@AreaNames IS NOT NULL
				AND AF.AreaName IS NOT NULL
			) 
			OR @AreaNames IS NULL
		)
		AND 
		(
			(
				@ResourceNames IS NOT NULL
				AND RF.ResourceName IS NOT NULL
			) 
			OR @ResourceNames IS NULL
		)
		AND 
		(
			(
				@ResourceTypes IS NOT NULL
				AND RTF.ResourceType IS NOT NULL
			) 
			OR @ResourceTypes IS NULL
		);
		

	/* Get resources transitions states */
	;WITH FilteredResourceStateReclassifications
	AS
	(
		SELECT REC.* 
		FROM UserDataModel.T_CustomResourceStateReclassification REC
		INNER JOIN #ElegibleResources R
			ON REC.ResourceId = R.ResourceId
		WHERE ServiceHistoryIdStart BETWEEN @FirstServiceHistoryId AND @LastServiceHistoryId
	),
	ResourceStates
	AS
	(	
		SELECT 
			R.FacilityId, 
			R.FacilityName, 
			R.AreaId,
			R.AreaName, 
			R.ResourceName, 
			R.ResourceId,
			R.ResourceType,
			ISNULL(RSR.StateModelId, RH.MainStateModelId) AS MainStateModelId, 
			ISNULL(RSR.StateModelStateId, RH.MainStateModelStateId) AS MainStateModelStateId, 
			ISNULL(RSR.StateModelStateReason, RH.MainStateModelStateReason) AS MainStateModelStateReason, 
			RH.ServiceHistoryId,
			LAG(ISNULL(RSR.StateModelId, RH.MainStateModelId)) OVER (PARTITION BY RH.ResourceId ORDER BY RH.ServiceHistoryId, RH.ModifiedOn) AS PreviousSM,
			LAG(ISNULL(RSR.StateModelStateId, RH.MainStateModelStateId)) OVER (PARTITION BY RH.ResourceId ORDER BY RH.ServiceHistoryId, RH.ModifiedOn) AS PreviousSMS,
			LAG(RH.OldServiceHistoryId) OVER (PARTITION BY RH.ResourceId ORDER BY RH.ServiceHistoryId, RH.ModifiedOn) AS OldServiceHistoryId,
			LAG(ISNULL(RSR.StateModelStateReason, RH.MainStateModelStateReason)) OVER (PARTITION BY RH.ResourceId ORDER BY RH.ServiceHistoryId, RH.ModifiedOn) AS PreviousSMSR
		FROM #ElegibleResources AS R
		INNER JOIN CoreDataModel.T_ResourceHistory AS RH 
			ON RH.ResourceId = R.ResourceId
		LEFT JOIN FilteredResourceStateReclassifications AS RSR
			ON RSR.ResourceId = RH.ResourceId
			AND 
			(
				RSR.ServiceHistoryIdStart > RH.ServiceHistoryId
				OR 
				(
					RSR.ServiceHistoryIdStart = RH.ServiceHistoryId
					AND RSR.OperationHistorySequenceStart >= RH.OperationHistorySeq
				)
			)
			AND 
			(
				RSR.ServiceHistoryIdEnd < RH.ServiceHistoryId
				OR
				(
					RSR.ServiceHistoryIdEnd = RH.ServiceHistoryId
					AND RSR.OperationHistorySequenceEnd <= RH.OperationHistorySeq
				)
			)
		WHERE RH.ServiceHistoryId BETWEEN @FirstServiceHistoryId AND @LastServiceHistoryId
	),
	ChangeStates
	AS
	(
		SELECT RS.*
		FROM ResourceStates AS RS
		WHERE RS.MainStateModelStateId IS NOT NULL 
			AND 
			( 
				RS.MainStateModelId <> RS.PreviousSM
				OR RS.MainStateModelStateId <> RS.PreviousSMS 
				OR RS.MainStateModelStateReason <> ISNULL(RS.[PreviousSMSR], '') 
				OR RS.PreviousSMS IS NULL
			)
	),
	LeadStates 
	AS
	(
		SELECT 
			CS.*,
			LEAD(CS.ServiceHistoryId) OVER (PARTITION BY CS.ResourceId ORDER BY CS.ServiceHistoryId) AS NextServiceHistoryId,
			LEAD(CS.MainStateModelId) OVER (PARTITION BY CS.ResourceId ORDER BY CS.ServiceHistoryId) AS NextStateModelChange,
			LEAD(CS.MainStateModelStateId) OVER (PARTITION BY CS.ResourceId ORDER BY CS.ServiceHistoryId) AS NextStateModelStateChange,
			LEAD(CS.MainStateModelStateReason) OVER (PARTITION BY CS.ResourceId ORDER BY CS.ServiceHistoryId) AS NextStateModelStateReason
		FROM ChangeStates AS CS
	)

	INSERT INTO #ResourceStateTransitions
	SELECT 
		LS.ResourceId,
		LS.ResourceName,
		LS.FacilityId,
		LS.FacilityName,
		LS.AreaId,
		LS.AreaName,
		LS.ResourceName,
		LS.PreviousSM,
		PS.[Name],
		LS.PreviousSMSR,
		CSM.[Name],
		CS.[Name],
		LS.MainStateModelStateReason,
		NSM.[Name],
		NS.[Name],
		LS.NextStateModelStateReason,
		SHO.ServiceStartTime,
		ISNULL(SHS.ServiceStartTime, @StartDate),
		SHE.ServiceStartTime,
		CAST(CASE WHEN (ISNULL(SHE.ServiceStartTime, @EndDate) >= @EndDate) THEN 1 ELSE 0 END AS BIT) AS EventStillOpen,
		LS.ResourceType
	FROM LeadStates AS LS
	INNER JOIN #StateModelStateFilter SMSF ON SMSF.StateModelStateId = LS.MainStateModelStateId
	INNER JOIN #StateModelFilter SMF ON SMF.StateModelId = LS.MainStateModelId 
	INNER JOIN #ReasonFilter RF ON RF.ReasonName = LS.MainStateModelStateReason
	LEFT JOIN dbo.T_ServiceHistory AS SHS 
		ON SHS.ServiceHistoryId = LS.ServiceHistoryId
	LEFT JOIN dbo.T_StateModel AS CSM
		ON CSM.StateModelId = LS.MainStateModelId 
	LEFT JOIN dbo.T_StateModel AS NSM
		ON NSM.StateModelId = LS.NextStateModelChange
	LEFT JOIN dbo.T_StateModel AS PSM
		ON PSM.StateModelId = LS.PreviousSM
	LEFT JOIN dbo.T_StateModelState AS CS 
		ON CS.StateModelStateId = LS.MainStateModelStateId 
	LEFT JOIN dbo.T_ServiceHistory AS SHE 
		ON SHE.ServiceHistoryId = LS.NextServiceHistoryId
	LEFT JOIN dbo.T_StateModelState AS NS 
		ON NS.StateModelStateId = LS.NextStateModelStateChange 
	LEFT JOIN dbo.T_ServiceHistory AS SHO
		ON SHO.ServiceHistoryId = LS.OldServiceHistoryId
	LEFT JOIN dbo.T_StateModelState AS PS 
		ON PS.StateModelStateId = LS.PreviousSMS 
	WHERE SHS.ServiceStartTime <= @DateEndHost 
		AND ISNULL(SHE.ServiceStartTime, @DateStartHost) >= @DateStartHost;
	
	/* Get shifts history and work units */
	;WITH Shifts
	AS
	(
		SELECT 
			SDSH.ShiftDefinitionId, 
			SDSH.Name,
			SDSH.StartTime, 
			SDSH.EndTime, 
			SDSH.ServiceHistoryId,
			LAG(SDSH.StartTime) OVER (PARTITION BY SDSH.ShiftDefinitionId, SDSH.Name ORDER BY SDSH.ServiceHistoryId, SDSH.ModifiedOn) AS PreviousStartTime,
			LAG(SDSH.EndTime) OVER (PARTITION BY SDSH.ShiftDefinitionId, SDSH.Name ORDER BY SDSH.ServiceHistoryId, SDSH.ModifiedOn) AS PreviousEndTime,
			LEAD(SDSH.ServiceHistoryId) OVER (PARTITION BY SDSH.ShiftDefinitionId, SDSH.Name ORDER BY SDSH.ShiftDefinitionId, SDSH.Name, SDSH.ServiceHistoryId, SDSH.ModifiedOn) AS OldServiceHistoryId
		FROM CoreDataModel.T_ShiftDefinitionShiftHistory AS SDSH
		LEFT JOIN #ShiftFilter AS S
			ON S.ShiftId = SDSH.ShiftDefinitionShiftId
		LEFT JOIN #ShiftDefinitionFilter AS SDF
			ON SDF.ShiftDefinitionId = SDSH.ShiftDefinitionId
		WHERE 
		(
			@ShiftNames IS NULL
			OR S.ShiftId IS NOT NULL
		)
		AND
		(
			@ShiftDefinitions IS NULL
			OR SDF.ShiftDefinitionId IS NOT NULL
		)
	),
	ChangeShifts
	AS
	(
		SELECT S.*
		FROM Shifts AS S
		WHERE S.PreviousStartTime IS NULL
			OR S.StartTime <> S.PreviousStartTime
			OR S.EndTime <> S.PreviousEndTime
	),
	ShiftHistory
	AS
	(
		SELECT 
			CS.*,
			SH.ServiceStartTime AS ServiceStartTime,
			ISNULL(SHO.ServiceStartTime, GETUTCDATE()) AS ServiceEndTime
		FROM Shifts AS CS
		INNER JOIN dbo.T_ServiceHistory AS SH
			ON SH.ServiceHistoryId = CS.ServiceHistoryId
		LEFT JOIN dbo.T_ServiceHistory AS SHO
			ON SHO.ServiceHistoryId = CS.OldServiceHistoryId
	),
	WorkUnitsStates
	AS
	(
		SELECT
			RST.ResourceId,
			WU.[Name] AS WorkUnit,
			ROW_NUMBER() OVER (PARTITION BY RST.ResourceId ORDER BY SR.[Order]) AS [Order]
		FROM #ElegibleResources AS RST
		INNER JOIN CoreDataModel.T_SubResource AS SR
			ON SR.SourceEntityId = RST.ResourceId
		INNER JOIN CoreDataModel.T_ResourceHistory AS WU
			ON WU.ResourceId = SR.TargetEntityId
		WHERE WU.ServiceHistoryId BETWEEN @FirstServiceHistoryId AND @LastServiceHistoryId
			AND WU.ModifiedOn BETWEEN @DateStartHost AND @DateEndHost
			AND WU.MainStateModelId = @WorkUnitStateModelId
			AND WU.MainStateModelStateId = @WorkUnitStateModelStateId
	),
	WorkUnits
	AS
	(
		SELECT 
			ResourceId,
			WorkUnit		
		FROM WorkUnitsStates
		WHERE [Order] = 1
	)

	/* Get final result */
	SELECT 
		RST.Facility,
		RST.Area,
		RST.Line,
		WU.WorkUnit AS WorkUnit,
		RST.CurrentStateModel,
		RST.CurrentStateModelState,
		RST.CurrentStateModelReason,
		RST.StartService AS StopStartTime,
		RST.EndService AS StopEndTime,
		CAST(DATEADD(S, TD.TimeDifference, 0) AS TIME) AS StopDuration,
		TD.TimeDifference,
		SH.[Name] AS ShiftName,
		MS.Microstop,
		IR.IsReclassifiable
	FROM #ResourceStateTransitions AS RST
	INNER JOIN UserDataModel.T_GT_CustomResourceStopStates AS RSS
		ON RSS.StateModel = RST.CurrentStateModel
		AND RSS.StateModelState = RST.CurrentStateModelState
		AND RSS.Reason = RST.CurrentStateModelReason
	INNER JOIN CoreDataModel.T_Area AS A
		ON A.AreaId = RST.AreaId
	INNER JOIN CoreDataModel.T_ShiftDefinition AS SD
		ON SD.CalendarId = A.CalendarId
	INNER JOIN ShiftHistory AS SH
		ON SH.ShiftDefinitionId = SD.ShiftDefinitionId
		AND 
		(
			RST.StartService BETWEEN SH.ServiceStartTime AND SH.ServiceEndTime
			OR RST.EndService BETWEEN SH.ServiceStartTime AND SH.ServiceEndTime
		)
		AND 
		(
			CAST(RST.StartService AS time) BETWEEN SH.StartTime AND SH.EndTime
			OR CAST(RST.EndService  AS time) BETWEEN SH.StartTime AND SH.EndTime
		)
	INNER JOIN WorkUnits AS WU
		ON WU.ResourceId = RST.ResourceId
	CROSS APPLY
	(
		SELECT DATEDIFF(SECOND, RST.StartService, RST.EndService) AS TimeDifference
	) AS TD
	OUTER APPLY
	(
		SELECT ISNULL(Threshold, 0) Threshold
		FROM [UserDataModel].[F_ST_ResolveCustomMicrostopThreshold] 
		(
		   1
		  ,RST.Facility
		  ,RST.Area
		  ,RST.ResourceType
		  ,RST.ResourceName
		)
	) AS MST
	CROSS APPLY
	(
		SELECT 
			CASE WHEN TD.TimeDifference IS NOT NULL AND TD.TimeDifference < MST.Threshold
				THEN 'True'
				ELSE 'False'
			END Microstop
	) AS MS
	CROSS APPLY
	(
		SELECT
			CASE WHEN RSS.IsReclassifiable IS NULL OR RSS.IsReclassifiable = 0
				THEN 'False'
				ELSE 'True'
			END AS IsReclassifiable
	) AS IR
	WHERE 
	(
		@Microstops = 1
		OR MS.Microstop = 'False'
	)
	AND
	(
		(
			@Justified = 1 
			AND @NotJustified = 1
		)
		OR
		(
			@Justified = 1 
			OR IR.IsReclassifiable = 'True'
		)
		OR
		(
			@NotJustified = 1
			OR IR.IsReclassifiable = 'False'
		)
	);

END;
