DECLARE @SmartTableId BIGINT
DECLARE @SmartTable VARCHAR(256)
DECLARE @ColumnToUpdate VARCHAR(256) = 'StructureType'
DECLARE @BatchExecutionId UNIQUEIDENTIFIER
DECLARE @PrintScriptOnly BIT
DECLARE @WithTriggers BIT
DECLARE @UseCommandQueue BIT
DECLARE @LastServiceHistoryId BIGINT
DECLARE @NewServiceHistoryId BIGINT
DECLARE @NewOperationSequence BIGINT
DECLARE @ModifiedBy VARCHAR(64) = 'CMF\cmfsu'
DECLARE @ModifiedOn DATETIME = GETUTCDATE()

-- TRY TO UPDATE
BEGIN TRY
	-- CREATE TRANSACTION
	BEGIN TRANSACTION

	EXECUTE [dbo].[P_CreateServiceHistoryId] - 1
		,'Update SmartTable CustomERPOrderTypeStructureTypeMapping'
		,'CMF\cmfsu'
		,'CMF\cmfsu'
		,@NewServiceHistoryId OUTPUT

	-- UPDATE SMART TABLE BLOCK
	BEGIN
		SET @SmartTable = 'CustomERPOrderTypeStructureTypeMapping'

		SELECT @SmartTableId = SmartTableId
			,@LastServiceHistoryId = LastServiceHistoryId
			,@NewOperationSequence = LastOperationHistorySeq
		FROM [dbo].[T_SmartTable]
		WHERE name = @SmartTable

		UPDATE [dbo].[T_SmartTableProperty]
		SET IsKey = 1
			,LastServiceHistoryId = @NewServiceHistoryId
			,LastOperationHistorySeq = @NewOperationSequence
			,ModifiedBy = @ModifiedBy
			,ModifiedOn = @ModifiedOn
		WHERE SmartTableId = @SmartTableId
			AND Name = @ColumnToUpdate

		SET @NewOperationSequence = 1

		-- CREATE SERVICE HISTORY ID FOR THE UPDATE
		EXEC dbo.P_CreateServiceHistoryId - 1
			,'Update precedence keys for ST CustomERPOrderTypeStructureTypeMapping'
			,'CMF\cmfsu'
			,'CMF\cmfsu'
			,@NewServiceHistoryId OUTPUT

		-- DELETE ALL PRECEDENCE KEYS
		DELETE
		FROM dbo.T_SmartTablePrecedenceKey
		WHERE SmartTableId = @SmartTableId

		-- INSERT NEWS PRECEDENT KEYS
		INSERT INTO [dbo].[T_SmartTablePrecedenceKey] (SmartTableId ,RuleString ,RuleOrder ,LastServiceHistoryId ,LastOperationHistorySeq ,CreatedBy ,ModifiedBy)
		VALUES 
			(@SmartTableId, 'Product+Resource', 1, @NewServiceHistoryId, @NewOperationSequence, 'CMF\cmfsu', 'CMF\cmfsu'),
			(@SmartTableId, 'Product+' + @ColumnToUpdate, 2, @NewServiceHistoryId, @NewOperationSequence, 'CMF\cmfsu', 'CMF\cmfsu'),
			(@SmartTableId, 'Product', 3, @NewServiceHistoryId, @NewOperationSequence, 'CMF\cmfsu', 'CMF\cmfsu')			
			
		SET @PrintScriptOnly = 0
		SET @WithTriggers = 1
		SET @UseCommandQueue = 0

		--GENERATE SCHEMA
		EXECUTE [dbo].[P_GenerateSmartTable] @SmartTable
			,@BatchExecutionId OUTPUT
			,@PrintScriptOnly
			,@WithTriggers
			,@UseCommandQueue
			,@LastServiceHistoryId
			,@NewServiceHistoryId
			,@NewOperationSequence
			,@ModifiedBy
			,@ModifiedOn

		-- CLOSE SERVICE HISTORY ID
		UPDATE dbo.T_ServiceHistory
		SET ServiceEndTime = GETUTCDATE()
		WHERE ServiceHistoryId = @NewServiceHistoryId

		-- COMMIT TRANSACTION
		COMMIT
	END
END TRY

BEGIN CATCH
	ROLLBACK

	PRINT ERROR_MESSAGE()
END CATCH
