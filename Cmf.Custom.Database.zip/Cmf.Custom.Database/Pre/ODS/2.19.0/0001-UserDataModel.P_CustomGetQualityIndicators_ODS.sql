/**********************************************************************
** Name: UserDataMode].P_CustomGetQualityIndicators_ODS
** Description: Procedure to get the data for the quality report
** Author: Paulo Soares
** Date: 09-sep-2021
************************************************************************

** Version History

** Version        Date			       Author				  Description 
** -------                    
** Sprint 19				  1/Out/2021   Paulo S.     Get the get the data for the quality report
*/

CREATE OR ALTER   PROCEDURE [UserDataModel].[P_CustomGetQualityIndicators_ODS]	
		@ResourceName NVARCHAR(256), 
		@DateStart    DATETIME = NULL,
		@DateEnd      DATETIME = NULL,
  @FacilityId   NVARCHAR(MAX), 
		@AreaID       NVARCHAR(MAX)      

AS

BEGIN
	
	SET NOCOUNT ON

  /* Limit to one week maximum (3 days) */
  --DECLARE @FacilityId NVARCHAR(MAX) ='2001220000010000001,2001220000010000002'--,2001220000010000003,2001220000010000004'
  --DECLARE	@AreaID NVARCHAR(MAX) ='2001230000010000001,2001220000010000004,2001220000010000003,2001220000010000006,2001220000010000005,2001220000010000002,2001220000010000001,2001230000010000002'
  --DECLARE @ResourceName NVARCHAR(512) = N'R0011'
 
  --DECLARE @DateEnd DATETIME = GETDATE()--'2021-09-03 00:00:00'
  --DECLARE @DateStart DATETIME = DATEADD(DAY, -3, CONVERT(DATE, @DateEnd))
 
  DECLARE @StartDateUTC DATETIME = dbo.F_ConvertTimeToUTC(@DateStart)
  DECLARE @EndDateUTC DATETIME = dbo.F_ConvertTimeToUTC(@DateEnd)
  
  DECLARE @StartServiceHistoryId BIGINT = [dbo].[F_Part_GetMinServiceHistoryIdForDate](@StartDateUTC-1)
  DECLARE @EndServiceHistoryId BIGINT = [dbo].[F_Part_GetMaxServiceHistoryIdForDate](@EndDateUTC + 1)
  DECLARE @ResourceId BIGINT
  SELECT @ResourceId = [ResourceId] FROM [CoreDataModel].[T_Resource] WHERE [Name] = @ResourceName



  IF OBJECT_ID('tempdb..#FacilityTab') IS NOT NULL
  		  DROP TABLE #FacilityTab
  	CREATE TABLE #FacilityTab 
  	(	
  	 	FacilityID BIGINT,
  	 	UNIQUE CLUSTERED(FacilityID)
  	);
  
  INSERT INTO #FacilityTab(FacilityId) 
  						 SELECT [Value] AS FacilityId 
  							  FROM [dbo].[F_Split2](@FacilityId, ',');
  	
  -- Area Filter Handling
  	IF OBJECT_ID('tempdb..#AreaTab') IS NOT NULL
  		  DROP TABLE #AreaTab
  	CREATE TABLE #AreaTab
  	(	
  	 	AreaID BIGINT,
  	 	UNIQUE CLUSTERED (AreaID)
  	);
  
  	INSERT INTO #AreaTab(AreaID) 
  		 SELECT [Value] AS areaid 
  			  FROM [dbo].[F_Split2](@AreaID, ',');
    
  /* Main Data - Temporary tables declaration */
  BEGIN
   
  	IF(OBJECT_ID('tempdb..#TrackInOutServices') IS NOT NULL) DROP TABLE #TrackInOutServices 
  	CREATE TABLE #TrackInOutServices
  	(
  		MaterialId                 BIGINT,
  		TrackInServiceHistoryId    BIGINT,
  		TrackOutServiceHistoryId   BIGINT,
  	)
  	CREATE CLUSTERED INDEX IDX_TIOSERV ON  #TrackInOutServices (MaterialId, TrackInServiceHistoryId, TrackOutServiceHistoryId);
  
  
   	IF(OBJECT_ID('tempdb..#ResourceMOs') IS NOT NULL) DROP TABLE #ResourceMOs
  	CREATE TABLE #ResourceMOs
  	(
  		MaterialId               BIGINT,
  		MOName			                NVARCHAR(256),
  		ProductId                BIGINT, 
  		ProductName              NVARCHAR(256),        
  		ProductDescription       NVARCHAR(256),        
  		ResourceId               BIGINT,
  		ResourceName             NVARCHAR(256), 
  		ProductionOrderId        BIGINT,
  		ProductionOrderName      NVARCHAR(256),
  		TrackInServiceHistoryId  BIGINT,
  		TrackoutServiceHistoryId BIGINT,
  		StartTime							       	 DATETIME,
  		EndTime								        	 DATETIME
  	)
  	CREATE CLUSTERED INDEX IDX_Mpo ON #ResourceMOs (TrackInServiceHistoryId, TrackoutServiceHistoryId/*, MaterialId, ResourceId*/);
   
  
  	IF(OBJECT_ID('tempdb..#ElegibleAttachedMaterials') IS NOT NULL) DROP TABLE #ElegibleAttachedMaterials
  	CREATE TABLE #ElegibleAttachedMaterials
  	(
  		MaterialId BIGINT
  	)
  	CREATE CLUSTERED INDEX IDX_ElegibleAttachedMaterials ON  #ElegibleAttachedMaterials (MaterialId);
  
  
  	IF(OBJECT_ID('tempdb..#SubResourceMaterials') IS NOT NULL)	DROP TABLE #SubResourceMaterials
  	CREATE TABLE #SubResourceMaterials
  	(
  		SubResourceName		   		 NVARCHAR(256),
  		IsEdgeBand						       BIT,
  		IsGlue								         BIT,
  		ProductName						      NVARCHAR(256),
  		ProductDescription		   NVARCHAR(256),
  		MaterialBatch					     NVARCHAR(256),
  		AttachServiceHistoryId BIGINT,
  		DetachServiceHistoryId BIGINT
  	)
  	CREATE CLUSTERED INDEX IDX_SrProd ON  #SubResourceMaterials (AttachServiceHistoryId, DetachServiceHistoryId, IsEdgeBand, IsGlue);
  
  END
  
  /* Data Collection - Temporary tables declaration */
  BEGIN
  
  	IF(OBJECT_ID('tempdb..#Charts') IS NOT NULL)	DROP TABLE #Charts
  	CREATE TABLE #Charts
  	(
  		ChartId      BIGINT,
  		TypeId			 TINYINT
  	)
  	CREATE CLUSTERED INDEX IDX_Charts ON #Charts (ChartId, TypeId);
   
  
  	IF(OBJECT_ID('tempdb..#CheckLists') IS NOT NULL) DROP TABLE #CheckLists
  	CREATE TABLE #CheckLists
  	(
  		CheckListId BIGINT,
  		TypeId      TINYINT
  	)
  	CREATE CLUSTERED INDEX IDX_CheckList ON #CheckLists (CheckListId, TypeId);
   
  
  	IF(OBJECT_ID('tempdb..#MaintenanceActivityOrders') IS NOT NULL)	DROP TABLE #MaintenanceActivityOrders
  	CREATE TABLE #MaintenanceActivityOrders
  	(
  		MaintenancePlanInstanceId    BIGINT,
  		CheckListInstanceId          BIGINT,
  		MaoName                      NVARCHAR(256)
  	)
  	CREATE CLUSTERED INDEX IDX_Maos ON  #MaintenanceActivityOrders (MaintenancePlanInstanceId, CheckListInstanceId);
   
  	-- Charts
  	IF(OBJECT_ID('tempdb..#ProcessCharts') IS NOT NULL) DROP TABLE #ProcessCharts
  	CREATE TABLE #ProcessCharts
  	(
  		ObjectType             TINYINT,
  		ChartDataPointId       BIGINT,
  		DataPointName          NVARCHAR(256),
  		DataPointValue         NVARCHAR(256),
    Facility               NVARCHAR(256),
    Area                   NVARCHAR(256),
    Material               NVARCHAR(256),
    Product                NVARCHAR(256),
    ProductGroup           NVARCHAR(256),
    [Resource]             NVARCHAR(256),
    Flow                   NVARCHAR(256),
    FlowPath               NVARCHAR(MAX),
    Step                   NVARCHAR(256),
    ResourceState          NVARCHAR(256),
    ProcessSegment         NVARCHAR(256)
  	)
  	CREATE CLUSTERED INDEX IDX_GlueTemp ON #ProcessCharts (ChartDataPointId);
  
  
   	-- CheckLists
  	IF(OBJECT_ID('tempdb..#ProcessCheckLists') IS NOT NULL) DROP TABLE #ProcessCheckLists
  	CREATE TABLE #ProcessCheckLists
  	(
  		ObjectType                        TINYINT,
  		MPInstanceName                    NVARCHAR(256),
  		ChecklistId                       BIGINT,
  		ChecklistInstanceId               BIGINT,
  		ChecklistItemInstanceId           BIGINT,
  		ChecklistItemInstanceParameterId  BIGINT,
  		CheckListParameterName            NVARCHAR(256),
  		CheckListParameterValue           NVARCHAR(256)
  	)
  	CREATE CLUSTERED INDEX IDX_PressRoll ON  #ProcessCheckLists (CheckListItemInstanceParameterId);
  
  END 
  
  
  /* Load Main Temporary tables (Resources, MOs and attached materials) */
  BEGIN
  
  	/* Track in and Trackout dates */
  	INSERT #TrackInOutServices
  	SELECT MH.MaterialId,
  			    	MAX(CASE WHEN OH.OperationName = 'Trackin' THEN MH.ServiceHistoryId END) AS TrackInServiceHistoryId,
  				    ISNULL(MAX(CASE WHEN OH.OperationName <> 'Trackin' THEN MH.ServiceHistoryId END), @EndServiceHistoryId) AS TrackOutServiceHistoryId
  	  FROM CoreDataModel.T_MaterialHistory MH
  	  JOIN dbo.T_OperationHistory OH ON MH.ServiceHistoryId = OH.ServiceHistoryId AND MH.OperationHistorySeq = OH.OperationHistorySeq 
  	 WHERE OH.EntityId = @ResourceId AND MH.ServiceHistoryId BETWEEN @StartServiceHistoryId AND @EndServiceHistoryId
  	   AND OH.operationName IN ('Trackin', 'Terminate', 'AbortProcess')
  	GROUP BY MH.MaterialId;
  
  	 
  	/* Main Material in POS data loading */      
  	INSERT #ResourceMOs
  	SELECT DISTINCT M.MaterialId,
  			   	 M.Name as MaterialName,
  			   	 M.ProductId, 
  			   	 P.Name as ProductName,
  			   	 PD.Description as ProductDescription,
  			   	 @ResourceId as ResourceId,
  			   	 @ResourceName as ResourceName,
  			   	 MH.ProductionOrderId,
  			   	 PO.Name as ProductionOrderName,
  			   	 TIO.TrackInServiceHistoryId,
  			   	 TIO.TrackoutServiceHistoryId,
  			   	 MIN(SH1.ServiceStartTime) AS StartTime,
  			   	 MAX(SH2.ServiceEndTime) AS EndTime
  		 FROM CoreDataModel.T_MaterialHistory MH 
  	 	JOIN CoreDataModel.T_Material M ON MH.MaterialId = M.MaterialId AND M.Form IN ('MO', 'Batch')   
  	 	JOIN dbo.T_OperationHistory OH ON (MH.ServiceHistoryId = OH.ServiceHistoryId AND MH.OperationHistorySeq = OH.OperationHistorySeq) 
  	 	JOIN CoreDataModel.T_Product P ON MH.ProductId = P.ProductId
     LEFT JOIN CoreDataModel.T_Product PD ON P.DefinitionId = PD.ProductId
  	 	JOIN CoreDataModel.T_ProductionOrder PO ON MH.ProductionOrderId = PO.ProductionOrderId
  	 	JOIN #TrackInOutServices TIO ON TIO.MaterialId = MH.MaterialId
  	 	JOIN dbo.T_ServiceHistory SH1 ON TIO.TrackInServiceHistoryId = SH1.ServiceHistoryId
  	 	LEFT JOIN dbo.T_ServiceHistory SH2 ON TIO.TrackoutServiceHistoryId = SH2.ServiceHistoryId
     JOIN CoreDataModel.T_Resource                         TR   ON MH.LastProcessedResourceId= TR.ResourceId
     LEFT JOIN #AreaTab                                    AT	  ON AT.AreaID = TR.AreaId
     LEFT JOIN #FacilityTab                                FT   ON FT.FacilityID = MH.FacilityId            
   	WHERE OH.EntityId = @ResourceId AND OH.EntityTypeName = 'Resource'  
  	   AND MH.ServiceHistoryId BETWEEN @StartServiceHistoryId AND @EndServiceHistoryId
      AND (@FacilityId IS NULL OR FT.FacilityId IN (SELECT FacilityId FROM #FacilityTab))
			   AND (@AreaID  IS NULL OR TR.AreaID  IN (SELECT AreaId FROM #AreaTab))
  	GROUP BY M.MaterialId,
  			      	M.Name,
  			      	M.ProductId, 
  			      	P.Name, 
  			      	PD.Description,
  			      	MH.ProductionOrderId,
  			      	PO.Name,
  			      	TIO.TrackInServiceHistoryId,
  			      	TIO.TrackoutServiceHistoryId;
   
  	
  	/* Get Elegible materials that where used in that timeframe */
  	INSERT #ElegibleAttachedMaterials
  	SELECT MH.MaterialId
    	FROM CoreDataModel.T_MaterialHistory MH
  	  JOIN dbo.T_OperationHistory OH ON (MH.ServiceHistoryId = OH.ServiceHistoryId 
  																		               AND MH.OperationHistorySeq = OH.OperationHistorySeq 
  																		               AND OH.OperationName IN ('AttachConsumables', 'DetachConsumable', 'Terminate', 'AssembleTo')) 
  	 WHERE (MH.ServiceHistoryId BETWEEN @StartServiceHistoryId AND @EndServiceHistoryId)
  	GROUP BY MH.MaterialId
  	 
  
  	/* Get all the materials in the subresources with attach and detach */ 
  	;WITH SubResources AS
  	(
  	SELECT SR.TargetEntityId AS SubResourceId,
  				    R.Name AS SubResourceName,
  				    CASE WHEN SR.Name LIKE '%E_Band_Edge%' THEN 1 ELSE 0 END AS IsEdgeBand,
  				    CASE WHEN (SR.Name LIKE '%_E_Band_EG%' OR SR.Name LIKE '%_E_Band_GM%') THEN 1 ELSE 0 END AS IsGlue
  	  FROM CoreDataModel.T_SubResource SR
  	  JOIN CoreDataModel.T_Resource R ON SR.TargetEntityId = R.ResourceId
  	 WHERE (SR.Name LIKE '%E_Band_Edge%' OR SR.Name LIKE '%_E_Band_EG%' OR SR.Name LIKE '%_E_Band_GM%') AND SR.SourceEntityId = @ResourceId
  	)
  
  	INSERT #SubResourceMaterials
  	SELECT SR.SubResourceName,		
  	   			 SR.IsEdgeBand,
  	   			 SR.IsGlue,
  	   			 P.Name AS ProductName,
  	   			 PD.Description AS Description,
  	   			 BM.Name AS Batch,
  	   			 ISNULL(MIN(CASE WHEN OH.operationName = 'AttachConsumables' THEN MH.ServiceHistoryId END), @StartServiceHistoryId) AS AttachServiceHistoryId, 
  	   			 ISNULL(MAX(CASE WHEN OH.operationName = 'DetachConsumable' THEN MH.ServiceHistoryId END), @EndServiceHistoryId) AS DetachServiceHistoryId  			  
    	FROM CoreDataModel.T_MaterialHistory MH
  	  JOIN dbo.T_OperationHistory OH ON (MH.ServiceHistoryId = OH.ServiceHistoryId AND MH.OperationHistorySeq = OH.OperationHistorySeq) 
    	JOIN SubResources SR ON SR.SubResourceId = OH.EntityId
    	JOIN CoreDataModel.T_Product P ON MH.ProductId = P.ProductId
     LEFT JOIN CoreDataModel.T_Product PD On P.DefinitionId = PD.ProductId 
  	  JOIN #ElegibleAttachedMaterials EAM ON MH.MaterialId = EAM.MaterialId 
  	  LEFT JOIN [UserDataModel].[T_CustomMaterialBatch] CMB ON MH.MaterialId = CMB.SourceEntityId
  	  LEFT JOIN [CoreDataModel].[T_Material] BM ON CMB.TargetEntityId = BM.MaterialId
  	 WHERE OH.OperationName IN ('AttachConsumables', 'DetachConsumable') AND OH.EntityTypeName = 'Resource' 
  	GROUP BY MH.MaterialId, SR.IsEdgeBand, SR.IsGlue, SR.SubResourceName, P.Name, PD.Description, BM.Name
  
  END
  
  /* Load Data Collection temporary tables (Charts and Checklists) */
  BEGIN
  	
     /* Load elegible Charts */
     INSERT INTO #Charts
     SELECT C.ChartId, 
            CASE WHEN C.Name LIKE'%GlueApplTempAct_%' THEN 1
                 WHEN C.Name LIKE'%QM_Homag_FeedSpeedAct%' THEN 2 
                 WHEN C.Name LIKE '%QM_Homag_Ambient_humidity%' THEN 3
                 WHEN C.Name LIKE '%QM_Homag_Ambient_temperature%' THEN 4
                 ELSE 0 END ChartType  
     FROM CoreDataModel.T_Chart C
     WHERE C.Type ='Quality';
  	 
     
     /* Load elegible CheckLists */
  	INSERT INTO #CheckLists
  	SELECT CheckListID --Pressure rollers
  				,1 AS TypeId
  	FROM CoreDataModel.T_Checklist 
  	WHERE Name = N'QM_plan_kontroli'
  	UNION ALL
  	SELECT CheckListID --Dimension Control
  				,2 AS TypeId
  	FROM CoreDataModel.T_Checklist
  	WHERE Name LIKE N'%QM_Homag_ kontrola_wymiar�w%'
  	UNION ALL
  	SELECT CheckListID --Drilling
  				,3 AS TypeId
  	FROM CoreDataModel.T_Checklist
  	WHERE Name  =N'Qm_Homag_wiercenie';
    
  
  	/* Load elegible Maintenance Activity orders */
  	INSERT INTO #MaintenanceActivityOrders
  	SELECT MAO.MaintenancePlanInstanceId,
  				 MAO.CheckListInstanceId,
  				 MAO.Name 
  	FROM CoreDataModel.T_MaintenanceActivityOrder  MAO
  	WHERE MAO.LastServiceHistoryId BETWEEN @StartServiceHistoryId AND @EndServiceHistoryId
  	AND MAO.Type = 'QUALITY'
  	AND MAO.UniversalState = 4
  	AND MAO.CheckListInstanceId IS NOT NULL;
    
  
    /* Load Chart Glue temperature chart data load */
  	INSERT #ProcessCharts (ObjectType, ChartDataPointId, DataPointName, DataPointValue, Facility, Area, Material, Product, ProductGroup, [Resource], Flow, FlowPath, Step, ResourceState, ProcessSegment)
   SELECT C.TypeId,
  				    CDP.ChartDataPointID,
  				    CDP.Name AS DataPointName,
  				    CDP.Value1 AS DataPointValue,
          CDPC.[Facility],
          CDPC.[Area],
          CDPC.[Material],
          CDPC.[Product],
          CDPC.[ProductGroup],
          CDPC.[Resource],
          CDPC.[Flow],
          CDPC.[FlowPath],
          CDPC.[Step],
          CDPC.[ResourceState],
          CDPC.ProcessSegment
  	  FROM #Charts C   
  	  JOIN CoreDatamodel.T_Chart CH ON C.ChartId= CH.CHartId
  	  JOIN CoreDataModel.T_LogicalChart LC ON LC.ChartId = C.ChartId
  	  JOIN CoreDataModel.T_ChartContextInformation CCI ON CCI.ChartId = C.ChartId AND CCI.ContextSource = 'Resource'    
   	 JOIN CoreDataModel.T_ChartDataPoint CDP  ON CDP.LogicalChartId = LC.LogicalChartId  
   	 left hash join (select distinct 
                            ChartDataPointId,
						 			                 	Name, 
							 	                  first_value(Value) over (partition by ChartDataPointId, Name order by LastServiceHistoryId desc) as Value 
						                from CoreDataModel.T_ChartDataPointContext
						                where isTemplate = 0
						                  and LastServiceHistoryId between @StartServiceHistoryId and @EndServiceHistoryId
							                 and Name in ('Material', 'Product','ProductGroup','Resource','Flow','FlowPath','Step','Area','Facility','ResourceState', 'ProcessSegment')
					               	 ) AS SourceTable 
						              pivot ( MIN(Value) FOR Name IN ([Material],[Product],[ProductGroup],[Resource],[Flow],[FlowPath],[Step],[Area],[Facility],[ResourceState], [ProcessSegment])) AS CDPC on CDP.ChartDataPointId = CDPC.ChartDataPointId
     JOIN CoreDataModel.T_Resource R ON R.Name = CDPC.Resource
   	WHERE R.ResourceId = @ResourceId 
  	 AND CDP.ChartDataPointId BETWEEN @StartServiceHistoryId AND @EndServiceHistoryId

  	OPTION (RECOMPILE);
  
  
  	/* Load all checklists */
  	INSERT #ProcessCheckLists
  	SELECT CL.TypeId AS ObjectType,
  				 MPI.Name AS MPInstanceName,
  				 CL.ChecklistId,
  				 CLI.ChecklistInstanceId,
  				 CLITI.ChecklistItemInstanceId,
  				 CLIIP.ChecklistItemInstanceParameterId,
  				 CLIP.Name AS CheckListParameterName,
  				 CLIIP.Value AS CheckListParameterValue
  	FROM #MaintenanceActivityOrders MAO
  	JOIN CoreDataModel.T_MaintenancePlanInstance MPI ON MPI.MaintenancePlanInstanceId = MAO.MaintenancePlanInstanceId
  	JOIN CoreDataModel.T_ChecklistInstance CLI ON MAO.CheckListInstanceId = CLI.ChecklistInstanceId
  	JOIN #CheckLists Cl ON CLI.ParentEntityId = CL.ChecklistId
  	JOIN CoreDataModel.T_ChecklistItemInstance CLITI ON CLITI.ChecklistInstanceId = CLI.ChecklistInstanceId
  	JOIN CoreDataModel.T_ChecklistItem CLIT ON CLITI.ParentEntityId = CLIT.ChecklistItemId 
  	JOIN CoreDataModel.T_ChecklistItemInstanceParameter CLIIP ON CLIIP.ChecklistItemInstanceId = CLITI.CheckListItemInstanceId
  	JOIN CoreDataModel.T_ChecklistItemParameter CLIP ON CLIP.ChecklistItemId = CLIT.ChecklistItemId
  	WHERE CLIIP.CheckListItemInstanceParameterId BETWEEN @StartServiceHistoryId AND @EndServiceHistoryId
  	AND CLI.LastServiceHistoryId BETWEEN @StartServiceHistoryId AND @EndServiceHistoryId
    AND CLITI.LastServiceHistoryId BETWEEN @StartServiceHistoryId AND @EndServiceHistoryId
  	AND MPI.ResourceId = @ResourceId
  	OPTION (RECOMPILE);
  
  END 
  
  -- Glue SubResources and Materials
  SELECT RMO.ResourceName,
  				   RMO.MOName, 				 
  				   RMO.TrackInServiceHistoryId,
  				   RMO.TrackoutServiceHistoryId,
  				   RMO.StartTime,
  				   RMO.EndTime,
  				   RMO.ProductName, 
  				   RMO.ProductDescription,
  				   RMO.ProductionOrderName,
  				   SUBGLUE.SubResourceName AS    SubResource, 
  				   SUBGLUE.ProductName AS        SRProduct, 
  				   SUBGLUE.ProductDescription AS SRProductDescription, 
  				   SUBGLUE.MaterialBatch AS      SRBatch,
         CASE WHEN SUBGLUE.IsGlue = 1 
                   THEN 1 
              ELSE 0 
         END            AS IsGlue,
         NULL           AS MeasureName,
         NULL           AS MeasureValue,
         NULL           AS ContextFacility,
         NULL           AS ContextArea,
         NULL           AS ContextMaterial,
         NULL           AS ContextProduct,
         NULL           AS ContextProductGroup,
         NULL           AS ContextResource,
         NULL           AS ContextFlow,
         NULL           AS ContextFlowPath,
         NULL           AS ContextStep,
         NULL           AS ContextResourceState,
         NULL           AS ContextProcessSegment,
         NULL           AS Type,
         0              AS IsCheckList,
         0              AS IsChart
  	 FROM #ResourceMOs RMO
    JOIN #SubResourceMaterials SUBGLUE 
  					ON ((SUBGLUE.AttachServiceHistoryId BETWEEN RMO.TrackInServiceHistoryId AND RMO.TrackoutServiceHistoryId) OR 
  							(SUBGLUE.DetachServiceHistoryId > RMO.TrackInServiceHistoryId AND SUBGLUE.DetachServiceHistoryId < RMO.TrackoutServiceHistoryId) OR 
  							(SUBGLUE.AttachServiceHistoryId < RMO.TrackInServiceHistoryId AND SUBGLUE.DetachServiceHistoryId > RMO.TrackoutServiceHistoryId))
  					AND SUBGLUE.IsGlue = 1
  UNION 
   -- EdgeBand SubResources and Materials
  SELECT RMO.ResourceName,
  				   RMO.MOName, 				 
  				   RMO.TrackInServiceHistoryId,
  				   RMO.TrackoutServiceHistoryId,
  				   RMO.StartTime,
  				   RMO.EndTime,
  				   RMO.ProductName, 
  				   RMO.ProductDescription,
  				   RMO.ProductionOrderName,
  				   SUBEDGE.SubResourceName    AS SubResource, 
  				   SUBEDGE.ProductName        AS Product, 
  				   SUBEDGE.ProductDescription AS ProductDescription, 
  				   SUBEDGE.MaterialBatch      AS Batch,
         CASE WHEN SUBEDGE.IsGlue = 1 
                   THEN 1 
              ELSE 0 
         END            AS IsGlue,
         NULL           AS MeasureName,
         NULL           AS MeasureValue,
         NULL           AS ContextFacility,
         NULL           AS ContextArea,
         NULL           AS ContextMaterial,
         NULL           AS ContextProduct,
         NULL           AS ContextProductGroup,
         NULL           AS ContextResource,
         NULL           AS ContextFlow,
         NULL           AS ContextFlowPath,
         NULL           AS ContextStep,
         NULL           AS ContextResourceState,
         NULL           AS ContextProcessSegment,
         NULL           AS Type,
         0              AS IsCheckList,
         0              AS IsChart
  	 FROM #ResourceMOs RMO
    JOIN #SubResourceMaterials SUBEDGE 
  					ON ((SUBEDGE.AttachServiceHistoryId BETWEEN RMO.TrackInServiceHistoryId AND RMO.TrackoutServiceHistoryId) OR 
  							(SUBEDGE.DetachServiceHistoryId > RMO.TrackInServiceHistoryId AND SUBEDGE.DetachServiceHistoryId < RMO.TrackoutServiceHistoryId) OR 
  							(SUBEDGE.AttachServiceHistoryId < RMO.TrackInServiceHistoryId AND SUBEDGE.DetachServiceHistoryId > RMO.TrackoutServiceHistoryId))
  					AND SUBEDGE.IsEdgeBand = 1
  --  PressureRollers Chart
  UNION 
  SELECT RMO.ResourceName,
  				   RMO.MOName, 				 
  				   RMO.TrackInServiceHistoryId,
  				   RMO.TrackoutServiceHistoryId,
  				   RMO.StartTime,
  				   RMO.EndTime,
  				   RMO.ProductName, 
  				   RMO.ProductDescription,
  				   RMO.ProductionOrderName,
         NULL AS SubResource, 
         NULL AS SRProduct, 
         NULL AS SRProductDescription,
         NULL AS SRBatch,
         0    AS IsGlue,
         CLROL.CheckListParameterName   AS MeasureName,
         CLROL.CheckListParameterValue  AS MeasureValue,
         NULL                           AS ContextFacility,
         NULL                           AS ContextArea,
         NULL                           AS ContextMaterial,
         NULL                           AS ContextProduct,
         NULL                           AS ContextProductGroup,
         NULL                           AS ContextResource,
         NULL                           AS ContextFlow,
         NULL                           AS ContextFlowPath,
         NULL                           AS ContextStep,
         NULL                           AS ContextResourceState,
         NULL                           AS ContextProcessSegment,
         1                              AS Type,
         1                              AS IsCheckList,
         0                              AS IsChart
  	 FROM #ResourceMOs RMO
    JOIN #ProcessCheckLists CLROL 
  					ON CLROL.CheckListItemInstanceParameterId BETWEEN RMO.TrackInServiceHistoryId AND RMO.TrackOutServiceHistoryId
  					AND CLROL.ObjectType = 1
  UNION 
  -- Dimension Control CheckList 
  SELECT RMO.ResourceName,
  				   RMO.MOName, 				 
  				   RMO.TrackInServiceHistoryId,
  				   RMO.TrackoutServiceHistoryId,
  				   RMO.StartTime,
  				   RMO.EndTime,
  				   RMO.ProductName, 
  				   RMO.ProductDescription,
  				   RMO.ProductionOrderName,
         NULL AS SubResource, 
         NULL AS SRProduct, 
         NULL AS SRProductDescription,
         NULL AS SRBatch,
         0    AS IsGlue,
         CLDIM.CheckListParameterName,
         CLDIM.CheckListParameterValue,
         NULL           AS ContextFacility,
         NULL           AS ContextArea,
         NULL           AS ContextMaterial,
         NULL           AS ContextProduct,
         NULL           AS ContextProductGroup,
         NULL           AS ContextResource,
         NULL           AS ContextFlow,
         NULL           AS ContextFlowPath,
         NULL           AS ContextStep,
         NULL           AS ContextResourceState,
         NULL           AS ContextProcessSegment,
         2 AS [Type],
         1 AS IsCheckList,
         0 AS IsChart
  	 FROM #ResourceMOs RMO
   JOIN #ProcessCheckLists CLDIM 
  					ON CLDIM.CheckListItemInstanceParameterId BETWEEN RMO.TrackInServiceHistoryId AND RMO.TrackOutServiceHistoryId
  					AND CLDIM.ObjectType = 2
  UNION 
   -- Drilling CheckList 
  SELECT RMO.ResourceName,
  				   RMO.MOName, 				 
  				   RMO.TrackInServiceHistoryId,
  				   RMO.TrackoutServiceHistoryId,
  				   RMO.StartTime,
  				   RMO.EndTime,
  				   RMO.ProductName, 
  				   RMO.ProductDescription,
  				   RMO.ProductionOrderName,
         NULL AS SubResource, 
         NULL AS SRProduct, 
         NULL AS SRProductDescription,
         NULL AS SRBatch,
         0    AS IsGlue,
         CLDRI.CheckListParameterName,
         CLDRI.CheckListParameterValue,
         NULL           AS ContextFacility,
         NULL           AS ContextArea,
         NULL           AS ContextMaterial,
         NULL           AS ContextProduct,
         NULL           AS ContextProductGroup,
         NULL           AS ContextResource,
         NULL           AS ContextFlow,
         NULL           AS ContextFlowPath,
         NULL           AS ContextStep,
         NULL           AS ContextResourceState,
         NULL           AS ContextProcessSegment,
         2 AS [Type],
         1 AS IsCheckList,
         0 AS IsChart
  	 FROM #ResourceMOs RMO
  JOIN #ProcessCheckLists CLDRI 
  					ON CLDRI.CheckListItemInstanceParameterId BETWEEN RMO.TrackInServiceHistoryId AND RMO.TrackOutServiceHistoryId
  					AND CLDRI.ObjectType = 3
  -- GlueTemperature Charts
  UNION 
  SELECT RMO.ResourceName,
  				   RMO.MOName, 				 
  				   RMO.TrackInServiceHistoryId,
  				   RMO.TrackoutServiceHistoryId,
  				   RMO.StartTime,
  				   RMO.EndTime,
  				   RMO.ProductName, 
  				   RMO.ProductDescription,
  				   RMO.ProductionOrderName,
         NULL AS SubResource, 
         NULL AS SRProduct, 
         NULL AS SRProductDescription,
         NULL AS SRBatch,
         0    AS IsGlue,
         PCGLUE.DataPointName,
         PCGLUE.DataPointValue,
         PCGLUE.Facility          AS ContextFacility,
         PCGLUE.Area              AS ContextArea,
         PCGLUE.Material          AS ContextMaterial,
         PCGLUE.Product           AS ContextProduct,
         PCGLUE.ProductGroup      AS ContextProductGroup,
         PCGLUE.[Resource]        AS ContextResource,
         PCGLUE.Flow              AS ContextFlow,
         PCGLUE.FlowPath          AS ContextFlowPath,
         PCGLUE.Step              AS ContextStep,
         PCGLUE.ResourceState     AS ContextResourceState,
         PCGLUE.ProcessSegment    AS ContextProcessSegment,
         1 AS [Type],
         0 AS IsCheckList,
         1 AS IsChart
  	 FROM #ResourceMOs RMO JOIN #ProcessCharts PCGLUE
  					ON PCGLUE.ChartDataPointId BETWEEN RMO.TrackInServiceHistoryId AND RMO.TrackOutServiceHistoryId
  					AND PCGLUE.ObjectType = 1
  UNION 
  -- FeedSpeed Charts
  SELECT RMO.ResourceName,
  				   RMO.MOName, 				 
  				   RMO.TrackInServiceHistoryId,
  				   RMO.TrackoutServiceHistoryId,
  				   RMO.StartTime,
  				   RMO.EndTime,
  				   RMO.ProductName, 
  				   RMO.ProductDescription,
  				   RMO.ProductionOrderName,
         NULL AS SubResource, 
         NULL AS SRProduct, 
         NULL AS SRProductDescription,
         NULL AS SRBatch,
         0    AS IsGlue,
         PCSPEED.DataPointName,
         PCSPEED.DataPointValue,
         PCSPEED.Facility          AS ContextFacility,
         PCSPEED.Area              AS ContextArea,
         PCSPEED.Material          AS ContextMaterial,
         PCSPEED.Product           AS ContextProduct,
         PCSPEED.ProductGroup      AS ContextProductGroup,
         PCSPEED.[Resource]        AS ContextResource,
         PCSPEED.Flow              AS ContextFlow,
         PCSPEED.FlowPath          AS ContextFlowPath,
         PCSPEED.Step              AS ContextStep,
         PCSPEED.ResourceState     AS ContextResourceState,
         PCSPEED.ProcessSegment    AS ContextProcessSegment,
         2 AS [Type],
         0 AS IsCheckList,
         1 AS IsChart
  	 FROM #ResourceMOs RMO JOIN #ProcessCharts PCSPEED
  					ON PCSPEED.ChartDataPointId BETWEEN RMO.TrackInServiceHistoryId AND RMO.TrackOutServiceHistoryId
  					AND PCSPEED.ObjectType = 2
  -- Ambient Humidity Charts
  UNION 
  SELECT RMO.ResourceName,
  				   RMO.MOName, 				 
  				   RMO.TrackInServiceHistoryId,
  				   RMO.TrackoutServiceHistoryId,
  				   RMO.StartTime,
  				   RMO.EndTime,
  				   RMO.ProductName, 
  				   RMO.ProductDescription,
  				   RMO.ProductionOrderName,
         NULL AS SubResource, 
         NULL AS SRProduct, 
         NULL AS SRProductDescription,
         NULL AS SRBatch,
         0    AS IsGlue,
         PCAH.DataPointName,
         PCAH.DataPointValue,
         PCAH.Facility        AS ContextFacility,
         PCAH.Area            AS ContextArea,
         PCAH.Material        AS ContextMaterial,
         PCAH.Product         AS ContextProduct,
         PCAH.ProductGroup    AS ContextProductGroup,
         PCAH.[Resource]      AS ContextResource,
         PCAH.Flow            AS ContextFlow,
         PCAH.FlowPath        AS ContextFlowPath,
         PCAH.Step            AS ContextStep,
         PCAH.ResourceState   AS ContextResourceState,
         PCAH.ProcessSegment  AS ContextProcessSegment,
         3 AS [Type],
         0 AS IsCheckList,
         1 AS IsChart        
  	 FROM #ResourceMOs RMO JOIN #ProcessCharts PCAH
  					ON PCAH.ChartDataPointId BETWEEN RMO.TrackInServiceHistoryId AND RMO.TrackOutServiceHistoryId
  					AND PCAH.ObjectType = 3
  UNION 
  -- Ambient Temperature Charts
  SELECT RMO.ResourceName,
  				   RMO.MOName, 				 
  				   RMO.TrackInServiceHistoryId,
  				   RMO.TrackoutServiceHistoryId,
  				   RMO.StartTime,
  				   RMO.EndTime,
  				   RMO.ProductName, 
  				   RMO.ProductDescription,
  				   RMO.ProductionOrderName,
         NULL AS SubResource, 
         NULL AS SRProduct, 
         NULL AS SRProductDescription,
         NULL AS SRBatch,
         0    AS IsGlue,
         PCAT.DataPointName,
         PCAT.DataPointValue,
         PCAT.Facility        AS ContextFacility,
         PCAT.Area            AS ContextArea,
         PCAT.Material        AS ContextMaterial,
         PCAT.Product         AS ContextProduct,
         PCAT.ProductGroup    AS ContextProductGroup,
         PCAT.[Resource]      AS ContextResource,
         PCAT.Flow            AS ContextFlow,
         PCAT.FlowPath        AS ContextFlowPath,
         PCAT.Step            AS ContextStep,
         PCAT.ResourceState   AS ContextResourceState,
         PCAT.ProcessSegment  AS ContextProcessSegment,
         4 AS [Type],
         0 AS IsCheckList,
         1 AS IsChart
  	 FROM #ResourceMOs RMO JOIN #ProcessCharts PCAT
  					ON PCAT.ChartDataPointId BETWEEN RMO.TrackInServiceHistoryId AND RMO.TrackOutServiceHistoryId
  					AND PCAT.ObjectType = 4
  
  	ORDER BY RMO.TrackInServiceHistoryId, RMO.TrackoutServiceHistoryId
 
OPTION(RECOMPILE);		

END


