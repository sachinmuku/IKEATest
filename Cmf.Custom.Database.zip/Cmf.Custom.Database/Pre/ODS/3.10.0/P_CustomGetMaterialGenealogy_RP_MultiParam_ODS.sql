/**
** Version History

** Version       Date          Author           Description 
** ---------     ----------    -----------      ------------------------------------------------------------------------------------------------------------------------
** Sprint 20     02/07/2021    Pedro Silva      New custom procedure based on the P_GetMaterialGenealogy_RP_MultiParam_ODS with the product filter and additional fields
** Sprint 25     21/12/2021    JM Marie         ADD batch parameter and columns to P_GetMaterialGenealogy_RP_MultiParam_ODS
*/

CREATE OR ALTER   PROCEDURE [UserDataModel].[P_CustomGetMaterialGenealogy_RP_MultiParam_ODS]
        @Material NVARCHAR(256),
        @MatId BIGINT,
        @Facilities NVARCHAR(MAX),
        @NFacTotalElems INT,
        @Steps NVARCHAR(MAX),
        @NStepTotalElems INT,
        @DateStart DATETIME,
        @DateEnd DATETIME,
        @Depth INT,
        @GenealogyMode INT, -- 0 Ascendant / 1 Descendant or 0 Downstream / 1 Upstream
        @UserAccount NVARCHAR(512) = NULL,
        @ProductName  NVARCHAR(MAX),
        @Batch  NVARCHAR(MAX)
--WITH ENCRYPTION
AS
BEGIN
    SET NOCOUNT ON
-- data from report comes as varchar, we need to map to bigint
    DECLARE @MaterialId BIGINT = CONVERT(BIGINT,@MatId)
    DECLARE @RowCount INT;
    DECLARE @level int = 1;

    BEGIN 
        
-- Facility Filter Handling
        DECLARE @HasFacilityFilter BIT;
        DECLARE @FacilityTab TABLE
        (    
            FacilityID BIGINT
        );
        INSERT INTO @FacilityTab(FacilityID)
            select convert(bigint, [Value]) as facilityid from [dbo].[F_Split2](@Facilities, ',');
    
        SET @RowCount = @@ROWCOUNT;
        IF (@RowCount > 0  AND @RowCount <> @NFacTotalElems) 
        BEGIN
            SET @HasFacilityFilter = 1
        END
        ELSE 
        BEGIN
            SET @HasFacilityFilter = 0;
            delete from @FacilityTab;
        END
    
-- Step Filter Handling
        DECLARE @HasStepFilter BIT;
        DECLARE @StepTab TABLE
        (    
            StepID BIGINT
        );

        if (@HasFacilityFilter > 0)
        BEGIN
            INSERT INTO @StepTab
            SELECT convert(BIGINT, s.[Value]) AS stepid
            FROM [dbo].[F_Split2](@Steps, ',') s
            INNER JOIN CoreDataModel.T_StepArea SA
                ON (convert(BIGINT, s.[Value]) = SA.SourceEntityId)
            INNER JOIN CoreDataModel.T_Area A
                ON (SA.TargetEntityId = A.AreaId)
            INNER JOIN @FacilityTab F
                ON (A.FacilityId = F.FacilityID)
--
            OPTION(RECOMPILE);
        END
        ELSE
        BEGIN
            INSERT INTO @StepTab
            select convert(bigint, s.[Value]) as stepid from [dbo].[F_Split2](@Steps, ',') s;
        END;
    
        SET @RowCount = @@ROWCOUNT;
        IF (@RowCount > 0  AND @RowCount <> @NStepTotalElems) 
        BEGIN
            SET @HasStepFilter = 1
        END
        ELSE 
        BEGIN
            SET @HasStepFilter = 0;
            delete from @StepTab;
        END    
     
        DECLARE @DateStartHost    DATETIME    = dbo.F_TimeLocalTimeToUTC(ISNULL(@DateStart, GETDATE() - 200));
        DECLARE @DateEndHost    DATETIME    = dbo.F_TimeLocalTimeToUTC(ISNULL(@DateEnd, GETDATE()));

-- get object level security activation state
        DECLARE @IsObjectSecurityEnabled BIT = [Reports].[F_IsObjectSecurityEnabled]()

-- user datagroups collection
        BEGIN
    
            IF(OBJECT_ID(N'tempdb..#UserDataGroups') IS NOT NULL)
                DROP TABLE #UserDataGroups

            CREATE TABLE #UserDataGroups([DataGroupId] BIGINT UNIQUE CLUSTERED ([DataGroupId]))
        
            INSERT #UserDataGroups
            EXEC [Reports].[P_GetUserReadableDataGroups] @UserAccount
        END

-- material ids to search the genealogy for
        DECLARE @HasProductFilter BIT;
        DECLARE @MaterialsTab TABLE
        (    
            MaterialID BIGINT,
            Name NVARCHAR(256)
        );

-- If there is a ProductName given, insert all material ids associated with that product
        IF (@ProductName IS NOT NULL AND @ProductName <> '')
        BEGIN
            INSERT INTO @MaterialsTab
            SELECT DISTINCT M.MaterialId, M.Name
            FROM CoreDataModel.T_Product P
            INNER JOIN CoreDataModel.T_Material M
                ON M.ProductId = P.ProductId
            LEFT JOIN UserDataModel.T_CustomMaterialBatch AS B ON B.SourceEntityId = M.MaterialId
            LEFT JOIN CoreDataModel.T_Material BM on (BM.MaterialId = B.TargetEntityId)
            LEFT JOIN #UserDataGroups UDG_M ON UDG_M.DataGroupId = M.DataGroupId
            LEFT JOIN #UserDataGroups UDG_P ON UDG_P.DataGroupId = P.DataGroupId
            WHERE P.Name = @ProductName
                AND M.MaterialId IS NOT NULL AND M.MaterialId > 0
-- if batch filter is not empty, include only matching materials for that batch
                AND (@Batch IS NULL OR @Batch = '' OR BM.Name = @Batch)
-- include only materials that can have operations recorded between the given dates
                AND M.CreatedOn <= @DateEndHost AND M.ModifiedOn >= @DateStartHost
                AND (
                    @IsObjectSecurityEnabled = 0
                    OR
                    (
                        (M.DataGroupId IS NULL OR UDG_M.DataGroupId IS NOT NULL)
                        AND
                        (P.DataGroupId IS NULL OR UDG_P.DataGroupId IS NOT NULL)
                    )
                );

            IF (@@ROWCOUNT = 0)
                RETURN;
        END
        ELSE IF (@Batch IS NOT NULL AND @Batch <> '')
        BEGIN
            INSERT INTO @MaterialsTab
            SELECT DISTINCT M.MaterialId, M.Name
            FROM CoreDataModel.T_Material BM
            INNER JOIN UserDataModel.T_CustomMaterialBatch AS B ON B.TargetEntityId = BM.MaterialId
            INNER JOIN CoreDataModel.T_Material M on (M.MaterialId = B.SourceEntityId)
            LEFT JOIN #UserDataGroups UDG_M ON UDG_M.DataGroupId = M.DataGroupId
            WHERE BM.Name = @Batch
-- include only materials that can have operations recorded between the given dates
                AND M.CreatedOn <= @DateEndHost AND M.ModifiedOn >= @DateStartHost
                AND (
                    @IsObjectSecurityEnabled = 0
                    OR
                    (
                        (M.DataGroupId IS NULL OR UDG_M.DataGroupId IS NOT NULL)
                    )
                );

            IF (@@ROWCOUNT = 0)
                RETURN;
        END
        ELSE BEGIN
            IF ((@MaterialId IS NULL OR @MaterialId <= 0) AND @Material IS NOT NULL) 
            BEGIN
                SELECT @MaterialId = MaterialId From CoreDataModel.T_Material where name = @Material
            END;
            
            INSERT INTO @MaterialsTab
            SELECT M.MaterialId, M.Name
            FROM CoreDataModel.T_Material M
            LEFT JOIN #UserDataGroups UDG ON UDG.DataGroupId = M.DataGroupId
            WHERE M.MaterialId = @MaterialId
                AND (
                    @IsObjectSecurityEnabled = 0
                    OR
                    M.DataGroupId IS NULL
                    OR
                    UDG.DataGroupId IS NOT NULL
                );

            IF (@@ROWCOUNT = 0)
                RETURN;
        END;
    END;

    IF (@GenealogyMode = 0)
    BEGIN /* Ascendants */
        SET @level = 1;
        IF object_id('tempdb..#tmpGenealogyAsc') IS NOT NULL
            DROP TABLE #tmpGenealogyAsc

--, CASE WHEN (@IsObjectSecurityEnabled = 0 OR .DataGroupId IS NULL OR UDG_.DataGroupId IS NOT NULL) THEN 1 ELSE -1 END AS []
--, CASE WHEN (@IsObjectSecurityEnabled = 0 OR .DataGroupId IS NULL OR UDG_.DataGroupId IS NOT NULL) THEN  ELSE N'[No Access]' END AS []
-- distinct used because same material may have multiple entries on same servicehistoryid
        SELECT distinct 1 as [Level], M.MaterialId as RootMaterialId, M.Name as RootMaterial, g.OperationEndTime, g.OperationId, g.Operation, g.ServiceHistoryId, g.OperationHistorySeq
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR MA.DataGroupId IS NULL OR UDG_MA.DataGroupId IS NOT NULL) THEN g.AscMaterialId ELSE -1 END AS [AscMaterialId]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR MA.DataGroupId IS NULL OR UDG_MA.DataGroupId IS NOT NULL) THEN g.AscMaterialName ELSE N'[No Access]' END AS [AscMaterialName]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR MD.DataGroupId IS NULL OR UDG_MD.DataGroupId IS NOT NULL) THEN g.DescMaterialId ELSE -1 END AS [DescMaterialId]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR MD.DataGroupId IS NULL OR UDG_MD.DataGroupId IS NOT NULL) THEN g.DescMaterialName ELSE N'[No Access]' END AS [DescMaterialName]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR MA.DataGroupId IS NULL OR UDG_MA.DataGroupId IS NOT NULL) THEN AscBatchMat.MaterialId ELSE N'[No Access]' END AS [AscBatchId]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR MA.DataGroupId IS NULL OR UDG_MA.DataGroupId IS NOT NULL) THEN AscBatchMat.Name ELSE N'[No Access]' END AS [AscBatchName]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR MD.DataGroupId IS NULL OR UDG_MD.DataGroupId IS NOT NULL) THEN DescBatchMat.MaterialId ELSE N'[No Access]' END AS [DescBatchId]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR MD.DataGroupId IS NULL OR UDG_MD.DataGroupId IS NOT NULL) THEN DescBatchMat.Name ELSE N'[No Access]' END AS [DescBatchName]
				, CASE WHEN (@IsObjectSecurityEnabled = 0 OR MD.DataGroupId IS NULL OR UDG_MD.DataGroupId IS NOT NULL) THEN DescBatch.IsParentBatch ELSE N'[No Access]' END AS [DescIsParentBatch]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR RA.DataGroupId IS NULL OR UDG_RA.DataGroupId IS NOT NULL) THEN g.AscResourceId ELSE -1 END AS [AscResourceId]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR RA.DataGroupId IS NULL OR UDG_RA.DataGroupId IS NOT NULL) THEN g.AscResourceName ELSE N'[No Access]' END AS [AscResource]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR RD.DataGroupId IS NULL OR UDG_RD.DataGroupId IS NOT NULL) THEN g.DescResourceId ELSE -1 END AS [DescResourceId]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR RD.DataGroupId IS NULL OR UDG_RD.DataGroupId IS NOT NULL) THEN g.DescResourceName ELSE N'[No Access]' END AS [DescResource]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR AA.DataGroupId IS NULL OR UDG_AA.DataGroupId IS NOT NULL) THEN AA.AreaId ELSE -1 END AS [AscAreaId]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR AA.DataGroupId IS NULL OR UDG_AA.DataGroupId IS NOT NULL) THEN AA.Name ELSE N'[No Access]' END AS [AscArea]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR AD.DataGroupId IS NULL OR UDG_AD.DataGroupId IS NOT NULL) THEN AD.AreaId ELSE -1 END AS [DescAreaId]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR AD.DataGroupId IS NULL OR UDG_AD.DataGroupId IS NOT NULL) THEN AD.Name ELSE N'[No Access]' END AS [DescArea]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR SA.DataGroupId IS NULL OR UDG_SA.DataGroupId IS NOT NULL) THEN g.AscStepId ELSE -1 END AS [AscStepId]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR SA.DataGroupId IS NULL OR UDG_SA.DataGroupId IS NOT NULL) THEN g.AscStep ELSE N'[No Access]' END AS [AscStep]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR SD.DataGroupId IS NULL OR UDG_SD.DataGroupId IS NOT NULL) THEN g.DescStepId ELSE -1 END AS [DescStepId]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR SD.DataGroupId IS NULL OR UDG_SD.DataGroupId IS NOT NULL) THEN g.DescStep ELSE N'[No Access]' END AS [DescStep]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR PAD.DataGroupId IS NULL OR UDG_PAD.DataGroupId IS NOT NULL) THEN g.AscProductId ELSE -1 END AS [AscProductId]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR PAD.DataGroupId IS NULL OR UDG_PAD.DataGroupId IS NOT NULL) THEN g.AscProduct ELSE N'[No Access]' END AS [AscProduct]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR PAD.DataGroupId IS NULL OR UDG_PAD.DataGroupId IS NOT NULL) THEN g.AscProductDescription ELSE N'[No Access]' END AS [AscProductDescription]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR PDD.DataGroupId IS NULL OR UDG_PDD.DataGroupId IS NOT NULL) THEN g.DescProductId ELSE -1 END AS [DescProductId]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR PDD.DataGroupId IS NULL OR UDG_PDD.DataGroupId IS NOT NULL) THEN g.DescProduct ELSE N'[No Access]' END AS [DescProduct]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR PDD.DataGroupId IS NULL OR UDG_PDD.DataGroupId IS NOT NULL) THEN g.DescProductDescription ELSE N'[No Access]' END AS [DescProductDescription]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR BAD.DataGroupId IS NULL OR UDG_BAD.DataGroupId IS NOT NULL) THEN g.AscBOM ELSE N'[No Access]' END AS [AscBOM]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR BDD.DataGroupId IS NULL OR UDG_BDD.DataGroupId IS NOT NULL) THEN g.DescBOM ELSE N'[No Access]' END AS [DescBOM]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR E.DataGroupId IS NULL OR UDG_E.DataGroupId IS NOT NULL) THEN E.EmployeeId ELSE -1 END AS [EmployeeId]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR E.DataGroupId IS NULL OR UDG_E.DataGroupId IS NOT NULL) THEN E.Name ELSE N'[No Access]' END AS [Employee]
                , g.AscPQ, g.AscPQAfter, g.AscPrimaryUnits, g.AscSQ, g.AscSQAfter, g.AscSecondaryUnits,g.DescPQ, g.DescPrimaryUnits, g.DescSQ, g.DescSecondaryUnits, g.AscAssembleQ, g.AscAssembleSecQ, g.DescAssembleQ, g.DescAssembleSecQ
                , g.ReferenceDesignator, g.SourceLocation, g.TargetLocation
            into #tmpGenealogyAsc
            FROM [CoreDataModel].[V_MaterialGenealogy] g
            INNER JOIN @MaterialsTab M ON M.MaterialId = g.DescMaterialId
            LEFT OUTER JOIN @StepTab AscStep ON (AscStep.StepID = g.AscStepId)
            LEFT OUTER JOIN @StepTab DescStep ON (DescStep.StepID = g.DescStepId)
            INNER JOIN CoreDataModel.T_Material MA ON MA.MaterialId = g.AscMaterialId
            INNER JOIN CoreDataModel.T_Material MD ON MD.MaterialId = g.DescMaterialId
            LEFT JOIN CoreDataModel.T_Resource RA ON RA.ResourceId = g.AscResourceId
            LEFT JOIN CoreDataModel.T_Resource RD ON RD.ResourceId = g.DescResourceId
            LEFT JOIN CoreDataModel.T_Area AA ON AA.AreaId = RA.AreaId
            LEFT JOIN CoreDataModel.T_Area AD ON AD.AreaId = RD.AreaId
            INNER JOIN CoreDataModel.T_Step SA ON SA.StepId = g.AscStepId
            INNER JOIN CoreDataModel.T_Step SD ON SD.StepId = g.DescStepId
            INNER JOIN CoreDataModel.T_Product PA ON PA.ProductId = g.AscProductId
            INNER JOIN CoreDataModel.T_Product PAD ON PAD.ProductId = PA.DefinitionId
            INNER JOIN CoreDataModel.T_Product PD ON PD.ProductId = g.DescProductId
            INNER JOIN CoreDataModel.T_Product PDD ON PDD.ProductId = PD.DefinitionId
            LEFT JOIN CoreDataModel.T_BOM BA ON BA.BOMId = g.AscBOMId
            LEFT JOIN CoreDataModel.T_BOM BAD ON BAD.BOMId = BA.DefinitionId
            LEFT JOIN CoreDataModel.T_BOM BD ON BD.BOMId = g.DescBOMId
            LEFT JOIN CoreDataModel.T_BOM BDD ON BDD.BOMId = BD.DefinitionId
            INNER JOIN dbo.T_ServiceHistory SH ON SH.ServiceHistoryId = g.ServiceHistoryId
            LEFT JOIN [Security].T_User U ON U.UserAccount = SH.CreatedBy
            LEFT JOIN [CoreDataModel].[T_Employee] E ON E.UserId = U.UserId
            LEFT JOIN #UserDataGroups UDG_MA ON UDG_MA.DataGroupId = MA.DataGroupId
            LEFT JOIN #UserDataGroups UDG_MD ON UDG_MD.DataGroupId = MD.DataGroupId
            LEFT JOIN #UserDataGroups UDG_RA ON UDG_RA.DataGroupId = RA.DataGroupId
            LEFT JOIN #UserDataGroups UDG_RD ON UDG_RD.DataGroupId = RD.DataGroupId
            LEFT JOIN #UserDataGroups UDG_AA ON UDG_AA.DataGroupId = AA.DataGroupId
            LEFT JOIN #UserDataGroups UDG_AD ON UDG_AD.DataGroupId = AD.DataGroupId
            LEFT JOIN #UserDataGroups UDG_SA ON UDG_SA.DataGroupId = SA.DataGroupId
            LEFT JOIN #UserDataGroups UDG_SD ON UDG_SD.DataGroupId = SD.DataGroupId
            LEFT JOIN #UserDataGroups UDG_PAD ON UDG_PAD.DataGroupId = PAD.DataGroupId
            LEFT JOIN #UserDataGroups UDG_PDD ON UDG_PDD.DataGroupId = PDD.DataGroupId
            LEFT JOIN #UserDataGroups UDG_BAD ON UDG_BAD.DataGroupId = BAD.DataGroupId
            LEFT JOIN #UserDataGroups UDG_BDD ON UDG_BDD.DataGroupId = BDD.DataGroupId
            LEFT JOIN #UserDataGroups UDG_E ON UDG_E.DataGroupId = E.DataGroupId
            LEFT JOIN UserDataModel.T_CustomMaterialBatch AS AscBatch ON AscBatch.SourceEntityId = g.AscMaterialId
            LEFT JOIN CoreDataModel.T_Material AscBatchMat on (AscBatchMat.MaterialId = AscBatch.TargetEntityId)
            LEFT JOIN UserDataModel.T_CustomMaterialBatch AS DescBatch ON DescBatch.SourceEntityId = g.DescMaterialId
            LEFT JOIN CoreDataModel.T_Material DescBatchMat on (DescBatchMat.MaterialId = DescBatch.TargetEntityId)
            WHERE g.OperationEndTime between @DateStartHost AND @DateEndHost
            AND (@HasStepFilter = 0 OR AscStep.StepID > 0 OR DescStep.StepID > 0)
--
            OPTION (RECOMPILE);

        SET @RowCount = @@ROWCOUNT;

-- create index to speed up execution
        CREATE CLUSTERED INDEX Idx_tmpGenealogyAsc ON #tmpGenealogyAsc
        (    AscMaterialId, ServiceHistoryId, [level], OperationHistorySeq, DescMaterialId
        ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = OFF);

        WHILE ( @RowCount > 0 AND @level < @Depth)
        BEGIN
            SET @level += 1;

            INSERT INTO #tmpGenealogyAsc
            SELECT distinct @level AS [Level], b.RootMaterialId, b.RootMaterial, g.OperationEndTime, g.OperationId, g.Operation, g.ServiceHistoryId, g.OperationHistorySeq
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR MA.DataGroupId IS NULL OR UDG_MA.DataGroupId IS NOT NULL) THEN g.AscMaterialId ELSE -1 END AS [AscMaterialId]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR MA.DataGroupId IS NULL OR UDG_MA.DataGroupId IS NOT NULL) THEN g.AscMaterialName ELSE N'[No Access]' END AS [AscMaterialName]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR MD.DataGroupId IS NULL OR UDG_MD.DataGroupId IS NOT NULL) THEN g.DescMaterialId ELSE -1 END AS [DescMaterialId]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR MD.DataGroupId IS NULL OR UDG_MD.DataGroupId IS NOT NULL) THEN g.DescMaterialName ELSE N'[No Access]' END AS [DescMaterialName]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR MA.DataGroupId IS NULL OR UDG_MA.DataGroupId IS NOT NULL) THEN AscBatchMat.MaterialId ELSE N'[No Access]' END AS [AscBatchId]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR MA.DataGroupId IS NULL OR UDG_MA.DataGroupId IS NOT NULL) THEN AscBatchMat.Name ELSE N'[No Access]' END AS [AscBatchName]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR MD.DataGroupId IS NULL OR UDG_MD.DataGroupId IS NOT NULL) THEN DescBatchMat.MaterialId ELSE N'[No Access]' END AS [DescBatchId]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR MD.DataGroupId IS NULL OR UDG_MD.DataGroupId IS NOT NULL) THEN DescBatchMat.Name ELSE N'[No Access]' END AS [DescBatchName]
				, CASE WHEN (@IsObjectSecurityEnabled = 0 OR MD.DataGroupId IS NULL OR UDG_MD.DataGroupId IS NOT NULL) THEN DescBatch.IsParentBatch ELSE N'[No Access]' END AS [DescIsParentBatch]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR RA.DataGroupId IS NULL OR UDG_RA.DataGroupId IS NOT NULL) THEN g.AscResourceId ELSE -1 END AS [AscResourceId]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR RA.DataGroupId IS NULL OR UDG_RA.DataGroupId IS NOT NULL) THEN g.AscResourceName ELSE N'[No Access]' END AS [AscResource]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR RD.DataGroupId IS NULL OR UDG_RD.DataGroupId IS NOT NULL) THEN g.DescResourceId ELSE -1 END AS [DescResourceId]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR RD.DataGroupId IS NULL OR UDG_RD.DataGroupId IS NOT NULL) THEN g.DescResourceName ELSE N'[No Access]' END AS [DescResource]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR AA.DataGroupId IS NULL OR UDG_AA.DataGroupId IS NOT NULL) THEN AA.AreaId ELSE -1 END AS [AscAreaId]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR AA.DataGroupId IS NULL OR UDG_AA.DataGroupId IS NOT NULL) THEN AA.Name ELSE N'[No Access]' END AS [AscArea]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR AD.DataGroupId IS NULL OR UDG_AD.DataGroupId IS NOT NULL) THEN AD.AreaId ELSE -1 END AS [DescAreaId]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR AD.DataGroupId IS NULL OR UDG_AD.DataGroupId IS NOT NULL) THEN AD.Name ELSE N'[No Access]' END AS [DescArea]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR SA.DataGroupId IS NULL OR UDG_SA.DataGroupId IS NOT NULL) THEN g.AscStepId ELSE -1 END AS [AscStepId]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR SA.DataGroupId IS NULL OR UDG_SA.DataGroupId IS NOT NULL) THEN g.AscStep ELSE N'[No Access]' END AS [AscStep]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR SD.DataGroupId IS NULL OR UDG_SD.DataGroupId IS NOT NULL) THEN g.DescStepId ELSE -1 END AS [DescStepId]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR SD.DataGroupId IS NULL OR UDG_SD.DataGroupId IS NOT NULL) THEN g.DescStep ELSE N'[No Access]' END AS [DescStep]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR PAD.DataGroupId IS NULL OR UDG_PAD.DataGroupId IS NOT NULL) THEN g.AscProductId ELSE -1 END AS [AscProductId]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR PAD.DataGroupId IS NULL OR UDG_PAD.DataGroupId IS NOT NULL) THEN g.AscProduct ELSE N'[No Access]' END AS [AscProduct]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR PAD.DataGroupId IS NULL OR UDG_PAD.DataGroupId IS NOT NULL) THEN g.AscProductDescription ELSE N'[No Access]' END AS [AscProductDescription]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR PDD.DataGroupId IS NULL OR UDG_PDD.DataGroupId IS NOT NULL) THEN g.DescProductId ELSE -1 END AS [DescProductId]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR PDD.DataGroupId IS NULL OR UDG_PDD.DataGroupId IS NOT NULL) THEN g.DescProduct ELSE N'[No Access]' END AS [DescProduct]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR PDD.DataGroupId IS NULL OR UDG_PDD.DataGroupId IS NOT NULL) THEN g.DescProductDescription ELSE N'[No Access]' END AS [DescProductDescription]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR BAD.DataGroupId IS NULL OR UDG_BAD.DataGroupId IS NOT NULL) THEN g.AscBOM ELSE N'[No Access]' END AS [AscBOM]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR BDD.DataGroupId IS NULL OR UDG_BDD.DataGroupId IS NOT NULL) THEN g.DescBOM ELSE N'[No Access]' END AS [DescBOM]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR E.DataGroupId IS NULL OR UDG_E.DataGroupId IS NOT NULL) THEN E.EmployeeId ELSE -1 END AS [EmployeeId]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR E.DataGroupId IS NULL OR UDG_E.DataGroupId IS NOT NULL) THEN E.Name ELSE N'[No Access]' END AS [Employee]
                , g.AscPQ, g.AscPQAfter, g.AscPrimaryUnits, g.AscSQ, g.AscSQAfter, g.AscSecondaryUnits,g.DescPQ, g.DescPrimaryUnits, g.DescSQ, g.DescSecondaryUnits, g.AscAssembleQ, g.AscAssembleSecQ, g.DescAssembleQ, g.DescAssembleSecQ
                , g.ReferenceDesignator, g.SourceLocation, g.TargetLocation
            FROM [CoreDataModel].[V_MaterialGenealogy] g
            INNER JOIN #tmpGenealogyAsc b ON (b.level = @level-1 AND b.AscMaterialId = g.DescMaterialId AND g.ServiceHistoryId <= b.ServiceHistoryId)
--following branches out repeated branches avoiding infinite cycles when materials have splits and merge backs
            LEFT OUTER JOIN #tmpGenealogyAsc c ON (c.AscMaterialId = g.AscMaterialId AND c.ServiceHistoryId = g.ServiceHistoryId and c.RootMaterialId = b.RootMaterialId)
            LEFT OUTER JOIN @StepTab AscStep ON (AscStep.StepID = g.AscStepId)
            LEFT OUTER JOIN @StepTab DescStep ON (DescStep.StepID = g.DescStepId)
            INNER JOIN CoreDataModel.T_Material MA ON MA.MaterialId = g.AscMaterialId
            INNER JOIN CoreDataModel.T_Material MD ON MD.MaterialId = g.DescMaterialId
            LEFT JOIN CoreDataModel.T_Resource RA ON RA.ResourceId = g.AscResourceId
            LEFT JOIN CoreDataModel.T_Resource RD ON RD.ResourceId = g.DescResourceId
            LEFT JOIN CoreDataModel.T_Area AA ON AA.AreaId = RA.AreaId
            LEFT JOIN CoreDataModel.T_Area AD ON AD.AreaId = RD.AreaId
            INNER JOIN CoreDataModel.T_Step SA ON SA.StepId = g.AscStepId
            INNER JOIN CoreDataModel.T_Step SD ON SD.StepId = g.DescStepId
            INNER JOIN CoreDataModel.T_Product PA ON PA.ProductId = g.AscProductId
            INNER JOIN CoreDataModel.T_Product PAD ON PAD.ProductId = PA.DefinitionId
            INNER JOIN CoreDataModel.T_Product PD ON PD.ProductId = g.DescProductId
            INNER JOIN CoreDataModel.T_Product PDD ON PDD.ProductId = PD.DefinitionId
            LEFT JOIN CoreDataModel.T_BOM BA ON BA.BOMId = g.AscBOMId
            LEFT JOIN CoreDataModel.T_BOM BAD ON BAD.BOMId = BA.DefinitionId
            LEFT JOIN CoreDataModel.T_BOM BD ON BD.BOMId = g.DescBOMId
            LEFT JOIN CoreDataModel.T_BOM BDD ON BDD.BOMId = BD.DefinitionId
            INNER JOIN dbo.T_ServiceHistory SH ON SH.ServiceHistoryId = g.ServiceHistoryId
            LEFT JOIN [Security].T_User U ON U.UserAccount = SH.CreatedBy
            LEFT JOIN [CoreDataModel].[T_Employee] E ON E.UserId = U.UserId
            LEFT JOIN #UserDataGroups UDG_MA ON UDG_MA.DataGroupId = MA.DataGroupId
            LEFT JOIN #UserDataGroups UDG_MD ON UDG_MD.DataGroupId = MD.DataGroupId
            LEFT JOIN #UserDataGroups UDG_RA ON UDG_RA.DataGroupId = RA.DataGroupId
            LEFT JOIN #UserDataGroups UDG_RD ON UDG_RD.DataGroupId = RD.DataGroupId
            LEFT JOIN #UserDataGroups UDG_AA ON UDG_AA.DataGroupId = AA.DataGroupId
            LEFT JOIN #UserDataGroups UDG_AD ON UDG_AD.DataGroupId = AD.DataGroupId
            LEFT JOIN #UserDataGroups UDG_SA ON UDG_SA.DataGroupId = SA.DataGroupId
            LEFT JOIN #UserDataGroups UDG_SD ON UDG_SD.DataGroupId = SD.DataGroupId
            LEFT JOIN #UserDataGroups UDG_PAD ON UDG_PAD.DataGroupId = PAD.DataGroupId
            LEFT JOIN #UserDataGroups UDG_PDD ON UDG_PDD.DataGroupId = PDD.DataGroupId
            LEFT JOIN #UserDataGroups UDG_BAD ON UDG_BAD.DataGroupId = BAD.DataGroupId
            LEFT JOIN #UserDataGroups UDG_BDD ON UDG_BDD.DataGroupId = BDD.DataGroupId
            LEFT JOIN #UserDataGroups UDG_E ON UDG_E.DataGroupId = E.DataGroupId
            LEFT JOIN UserDataModel.T_CustomMaterialBatch AS AscBatch ON AscBatch.SourceEntityId = g.AscMaterialId
            LEFT JOIN CoreDataModel.T_Material AscBatchMat on (AscBatchMat.MaterialId = AscBatch.TargetEntityId)
            LEFT JOIN UserDataModel.T_CustomMaterialBatch AS DescBatch ON DescBatch.SourceEntityId = g.DescMaterialId
            LEFT JOIN CoreDataModel.T_Material DescBatchMat on (DescBatchMat.MaterialId = DescBatch.TargetEntityId)
            WHERE g.OperationEndTime BETWEEN @DateStartHost AND @DateEndHost            
              AND c.LEVEL IS NULL
              AND (@HasStepFilter = 0 OR AscStep.StepID > 0 OR DescStep.StepID > 0)
--
            OPTION (RECOMPILE);

            SET @RowCount = @@ROWCOUNT;
        END;
        select 'Ascendant' as GenealogyMode, t.*, 'R' + Format(row_number() over (order by [level], OperationEndTime desc, ServiceHistoryId, DescIsParentBatch DESC ), '00000000000000000000') rnum 
        from #tmpGenealogyAsc t;

	 --	select 'Ascendant' as GenealogyMode, t.*, 'R' + Format(row_number() over (order by [level], OperationEndTime desc, ServiceHistoryId ), '00000000000000000000') rnum 
     --   from #tmpGenealogyAsc t;
    END
    ELSE /* Descendants */
    BEGIN
        SET @level = 1;

        IF object_id('tempdb..#tmpGenealogyDesc') IS NOT NULL
            DROP TABLE #tmpGenealogyDesc;

-- distinct used because same material may have multiple entries on same servicehistoryid
        SELECT  distinct 1 as [Level], M.MaterialId as RootMaterialId, M.Name as RootMaterial, g.OperationEndTime, g.OperationId, g.Operation, g.ServiceHistoryId, g.OperationHistorySeq
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR MA.DataGroupId IS NULL OR UDG_MA.DataGroupId IS NOT NULL) THEN g.AscMaterialId ELSE -1 END AS [AscMaterialId]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR MA.DataGroupId IS NULL OR UDG_MA.DataGroupId IS NOT NULL) THEN g.AscMaterialName ELSE N'[No Access]' END AS [AscMaterialName]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR MD.DataGroupId IS NULL OR UDG_MD.DataGroupId IS NOT NULL) THEN g.DescMaterialId ELSE -1 END AS [DescMaterialId]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR MD.DataGroupId IS NULL OR UDG_MD.DataGroupId IS NOT NULL) THEN g.DescMaterialName ELSE N'[No Access]' END AS [DescMaterialName]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR MA.DataGroupId IS NULL OR UDG_MA.DataGroupId IS NOT NULL) THEN AscBatchMat.MaterialId ELSE N'[No Access]' END AS [AscBatchId]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR MA.DataGroupId IS NULL OR UDG_MA.DataGroupId IS NOT NULL) THEN AscBatchMat.Name ELSE N'[No Access]' END AS [AscBatchName]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR MD.DataGroupId IS NULL OR UDG_MD.DataGroupId IS NOT NULL) THEN DescBatchMat.MaterialId ELSE N'[No Access]' END AS [DescBatchId]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR MD.DataGroupId IS NULL OR UDG_MD.DataGroupId IS NOT NULL) THEN DescBatchMat.Name ELSE N'[No Access]' END AS [DescBatchName]
				, CASE WHEN (@IsObjectSecurityEnabled = 0 OR MD.DataGroupId IS NULL OR UDG_MD.DataGroupId IS NOT NULL) THEN DescBatch.IsParentBatch ELSE N'[No Access]' END AS [DescIsParentBatch]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR RA.DataGroupId IS NULL OR UDG_RA.DataGroupId IS NOT NULL) THEN g.AscResourceId ELSE -1 END AS [AscResourceId]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR RA.DataGroupId IS NULL OR UDG_RA.DataGroupId IS NOT NULL) THEN g.AscResourceName ELSE N'[No Access]' END AS [AscResource]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR RD.DataGroupId IS NULL OR UDG_RD.DataGroupId IS NOT NULL) THEN g.DescResourceId ELSE -1 END AS [DescResourceId]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR RD.DataGroupId IS NULL OR UDG_RD.DataGroupId IS NOT NULL) THEN g.DescResourceName ELSE N'[No Access]' END AS [DescResource]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR AA.DataGroupId IS NULL OR UDG_AA.DataGroupId IS NOT NULL) THEN AA.AreaId ELSE -1 END AS [AscAreaId]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR AA.DataGroupId IS NULL OR UDG_AA.DataGroupId IS NOT NULL) THEN AA.Name ELSE N'[No Access]' END AS [AscArea]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR AD.DataGroupId IS NULL OR UDG_AD.DataGroupId IS NOT NULL) THEN AD.AreaId ELSE -1 END AS [DescAreaId]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR AD.DataGroupId IS NULL OR UDG_AD.DataGroupId IS NOT NULL) THEN AD.Name ELSE N'[No Access]' END AS [DescArea]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR SA.DataGroupId IS NULL OR UDG_SA.DataGroupId IS NOT NULL) THEN g.AscStepId ELSE -1 END AS [AscStepId]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR SA.DataGroupId IS NULL OR UDG_SA.DataGroupId IS NOT NULL) THEN g.AscStep ELSE N'[No Access]' END AS [AscStep]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR SD.DataGroupId IS NULL OR UDG_SD.DataGroupId IS NOT NULL) THEN g.DescStepId ELSE -1 END AS [DescStepId]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR SD.DataGroupId IS NULL OR UDG_SD.DataGroupId IS NOT NULL) THEN g.DescStep ELSE N'[No Access]' END AS [DescStep]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR PAD.DataGroupId IS NULL OR UDG_PAD.DataGroupId IS NOT NULL) THEN g.AscProductId ELSE -1 END AS [AscProductId]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR PAD.DataGroupId IS NULL OR UDG_PAD.DataGroupId IS NOT NULL) THEN g.AscProduct ELSE N'[No Access]' END AS [AscProduct]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR PAD.DataGroupId IS NULL OR UDG_PAD.DataGroupId IS NOT NULL) THEN g.AscProductDescription ELSE N'[No Access]' END AS [AscProductDescription]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR PDD.DataGroupId IS NULL OR UDG_PDD.DataGroupId IS NOT NULL) THEN g.DescProductId ELSE -1 END AS [DescProductId]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR PDD.DataGroupId IS NULL OR UDG_PDD.DataGroupId IS NOT NULL) THEN g.DescProduct ELSE N'[No Access]' END AS [DescProduct]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR PDD.DataGroupId IS NULL OR UDG_PDD.DataGroupId IS NOT NULL) THEN g.DescProductDescription ELSE N'[No Access]' END AS [DescProductDescription]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR BAD.DataGroupId IS NULL OR UDG_BAD.DataGroupId IS NOT NULL) THEN g.AscBOM ELSE N'[No Access]' END AS [AscBOM]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR BDD.DataGroupId IS NULL OR UDG_BDD.DataGroupId IS NOT NULL) THEN g.DescBOM ELSE N'[No Access]' END AS [DescBOM]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR E.DataGroupId IS NULL OR UDG_E.DataGroupId IS NOT NULL) THEN E.EmployeeId ELSE -1 END AS [EmployeeId]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR E.DataGroupId IS NULL OR UDG_E.DataGroupId IS NOT NULL) THEN E.Name ELSE N'[No Access]' END AS [Employee]
                , g.AscPQ, g.AscPQAfter, g.AscPrimaryUnits, g.AscSQ, g.AscSQAfter, g.AscSecondaryUnits,g.DescPQ, g.DescPrimaryUnits, g.DescSQ, g.DescSecondaryUnits, g.AscAssembleQ, g.AscAssembleSecQ, g.DescAssembleQ, g.DescAssembleSecQ
                , g.ReferenceDesignator, g.SourceLocation, g.TargetLocation
            into #tmpGenealogyDesc
            FROM [CoreDataModel].[V_MaterialGenealogy] g
            INNER JOIN @MaterialsTab M ON M.MaterialId = g.AscMaterialId
            LEFT OUTER JOIN @StepTab AscStep ON (AscStep.StepID = g.AscStepId)
            LEFT OUTER JOIN @StepTab DescStep ON (DescStep.StepID = g.DescStepId)
            INNER JOIN CoreDataModel.T_Material MA ON MA.MaterialId = g.AscMaterialId
            INNER JOIN CoreDataModel.T_Material MD ON MD.MaterialId = g.DescMaterialId
            LEFT JOIN CoreDataModel.T_Resource RA ON RA.ResourceId = g.AscResourceId
            LEFT JOIN CoreDataModel.T_Resource RD ON RD.ResourceId = g.DescResourceId
            LEFT JOIN CoreDataModel.T_Area AA ON AA.AreaId = RA.AreaId
            LEFT JOIN CoreDataModel.T_Area AD ON AD.AreaId = RD.AreaId
            INNER JOIN CoreDataModel.T_Step SA ON SA.StepId = g.AscStepId
            INNER JOIN CoreDataModel.T_Step SD ON SD.StepId = g.DescStepId
            INNER JOIN CoreDataModel.T_Product PA ON PA.ProductId = g.AscProductId
            INNER JOIN CoreDataModel.T_Product PAD ON PAD.ProductId = PA.DefinitionId
            INNER JOIN CoreDataModel.T_Product PD ON PD.ProductId = g.DescProductId
            INNER JOIN CoreDataModel.T_Product PDD ON PDD.ProductId = PD.DefinitionId
            LEFT JOIN CoreDataModel.T_BOM BA ON BA.BOMId = g.AscBOMId
            LEFT JOIN CoreDataModel.T_BOM BAD ON BAD.BOMId = BA.DefinitionId
            LEFT JOIN CoreDataModel.T_BOM BD ON BD.BOMId = g.DescBOMId
            LEFT JOIN CoreDataModel.T_BOM BDD ON BDD.BOMId = BD.DefinitionId
            INNER JOIN dbo.T_ServiceHistory SH ON SH.ServiceHistoryId = g.ServiceHistoryId
            LEFT JOIN [Security].T_User U ON U.UserAccount = SH.CreatedBy
            LEFT JOIN [CoreDataModel].[T_Employee] E ON E.UserId = U.UserId
            LEFT JOIN #UserDataGroups UDG_MA ON UDG_MA.DataGroupId = MA.DataGroupId
            LEFT JOIN #UserDataGroups UDG_MD ON UDG_MD.DataGroupId = MD.DataGroupId
            LEFT JOIN #UserDataGroups UDG_RA ON UDG_RA.DataGroupId = RA.DataGroupId
            LEFT JOIN #UserDataGroups UDG_RD ON UDG_RD.DataGroupId = RD.DataGroupId
            LEFT JOIN #UserDataGroups UDG_AA ON UDG_AA.DataGroupId = AA.DataGroupId
            LEFT JOIN #UserDataGroups UDG_AD ON UDG_AD.DataGroupId = AD.DataGroupId
            LEFT JOIN #UserDataGroups UDG_SA ON UDG_SA.DataGroupId = SA.DataGroupId
            LEFT JOIN #UserDataGroups UDG_SD ON UDG_SD.DataGroupId = SD.DataGroupId
            LEFT JOIN #UserDataGroups UDG_PAD ON UDG_PAD.DataGroupId = PAD.DataGroupId
            LEFT JOIN #UserDataGroups UDG_PDD ON UDG_PDD.DataGroupId = PDD.DataGroupId
            LEFT JOIN #UserDataGroups UDG_BAD ON UDG_BAD.DataGroupId = BAD.DataGroupId
            LEFT JOIN #UserDataGroups UDG_BDD ON UDG_BDD.DataGroupId = BDD.DataGroupId
            LEFT JOIN #UserDataGroups UDG_E ON UDG_E.DataGroupId = E.DataGroupId
            LEFT JOIN UserDataModel.T_CustomMaterialBatch AS AscBatch ON AscBatch.SourceEntityId = g.AscMaterialId
            LEFT JOIN CoreDataModel.T_Material AscBatchMat on (AscBatchMat.MaterialId = AscBatch.TargetEntityId)
            LEFT JOIN UserDataModel.T_CustomMaterialBatch AS DescBatch ON DescBatch.SourceEntityId = g.DescMaterialId
            LEFT JOIN CoreDataModel.T_Material DescBatchMat on (DescBatchMat.MaterialId = DescBatch.TargetEntityId)
            Where g.OperationEndTime between @DateStartHost AND @DateEndHost
            AND (@HasStepFilter = 0 OR AscStep.StepID > 0 OR DescStep.StepID > 0)


--
            OPTION (RECOMPILE);

        SET @RowCount = @@ROWCOUNT;

-- create index to speed up execution
        CREATE CLUSTERED INDEX Idx_tmpGenealogyDesc ON #tmpGenealogyDesc
        (    DescMaterialId, ServiceHistoryId, [level], OperationHistorySeq, AscMaterialId
        ) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = OFF);


        WHILE ( @RowCount > 0 AND @level < @Depth)
        BEGIN
            SET @level += 1;

            INSERT INTO #tmpGenealogyDesc
            SELECT distinct @level AS [Level], b.RootMaterialId, b.RootMaterial, g.OperationEndTime, g.OperationId, g.Operation, g.ServiceHistoryId, g.OperationHistorySeq
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR MA.DataGroupId IS NULL OR UDG_MA.DataGroupId IS NOT NULL) THEN g.AscMaterialId ELSE -1 END AS [AscMaterialId]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR MA.DataGroupId IS NULL OR UDG_MA.DataGroupId IS NOT NULL) THEN g.AscMaterialName ELSE N'[No Access]' END AS [AscMaterialName]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR MD.DataGroupId IS NULL OR UDG_MD.DataGroupId IS NOT NULL) THEN g.DescMaterialId ELSE -1 END AS [DescMaterialId]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR MD.DataGroupId IS NULL OR UDG_MD.DataGroupId IS NOT NULL) THEN g.DescMaterialName ELSE N'[No Access]' END AS [DescMaterialName]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR MA.DataGroupId IS NULL OR UDG_MA.DataGroupId IS NOT NULL) THEN AscBatchMat.MaterialId ELSE N'[No Access]' END AS [AscBatchId]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR MA.DataGroupId IS NULL OR UDG_MA.DataGroupId IS NOT NULL) THEN AscBatchMat.Name ELSE N'[No Access]' END AS [AscBatchName]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR MD.DataGroupId IS NULL OR UDG_MD.DataGroupId IS NOT NULL) THEN DescBatchMat.MaterialId ELSE N'[No Access]' END AS [DescBatchId]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR MD.DataGroupId IS NULL OR UDG_MD.DataGroupId IS NOT NULL) THEN DescBatchMat.Name ELSE N'[No Access]' END AS [DescBatchName]
				, CASE WHEN (@IsObjectSecurityEnabled = 0 OR MD.DataGroupId IS NULL OR UDG_MD.DataGroupId IS NOT NULL) THEN DescBatch.IsParentBatch ELSE N'[No Access]' END AS [DescIsParentBatch]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR RA.DataGroupId IS NULL OR UDG_RA.DataGroupId IS NOT NULL) THEN g.AscResourceId ELSE -1 END AS [AscResourceId]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR RA.DataGroupId IS NULL OR UDG_RA.DataGroupId IS NOT NULL) THEN g.AscResourceName ELSE N'[No Access]' END AS [AscResource]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR RD.DataGroupId IS NULL OR UDG_RD.DataGroupId IS NOT NULL) THEN g.DescResourceId ELSE -1 END AS [DescResourceId]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR RD.DataGroupId IS NULL OR UDG_RD.DataGroupId IS NOT NULL) THEN g.DescResourceName ELSE N'[No Access]' END AS [DescResource]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR AA.DataGroupId IS NULL OR UDG_AA.DataGroupId IS NOT NULL) THEN AA.AreaId ELSE -1 END AS [AscAreaId]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR AA.DataGroupId IS NULL OR UDG_AA.DataGroupId IS NOT NULL) THEN AA.Name ELSE N'[No Access]' END AS [AscArea]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR AD.DataGroupId IS NULL OR UDG_AD.DataGroupId IS NOT NULL) THEN AD.AreaId ELSE -1 END AS [DescAreaId]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR AD.DataGroupId IS NULL OR UDG_AD.DataGroupId IS NOT NULL) THEN AD.Name ELSE N'[No Access]' END AS [DescArea]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR SA.DataGroupId IS NULL OR UDG_SA.DataGroupId IS NOT NULL) THEN g.AscStepId ELSE -1 END AS [AscStepId]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR SA.DataGroupId IS NULL OR UDG_SA.DataGroupId IS NOT NULL) THEN g.AscStep ELSE N'[No Access]' END AS [AscStep]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR SD.DataGroupId IS NULL OR UDG_SD.DataGroupId IS NOT NULL) THEN g.DescStepId ELSE -1 END AS [DescStepId]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR SD.DataGroupId IS NULL OR UDG_SD.DataGroupId IS NOT NULL) THEN g.DescStep ELSE N'[No Access]' END AS [DescStep]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR PAD.DataGroupId IS NULL OR UDG_PAD.DataGroupId IS NOT NULL) THEN g.AscProductId ELSE -1 END AS [AscProductId]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR PAD.DataGroupId IS NULL OR UDG_PAD.DataGroupId IS NOT NULL) THEN g.AscProduct ELSE N'[No Access]' END AS [AscProduct]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR PAD.DataGroupId IS NULL OR UDG_PAD.DataGroupId IS NOT NULL) THEN g.AscProductDescription ELSE N'[No Access]' END AS [AscProductDescription]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR PDD.DataGroupId IS NULL OR UDG_PDD.DataGroupId IS NOT NULL) THEN g.DescProductId ELSE -1 END AS [DescProductId]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR PDD.DataGroupId IS NULL OR UDG_PDD.DataGroupId IS NOT NULL) THEN g.DescProduct ELSE N'[No Access]' END AS [DescProduct]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR PDD.DataGroupId IS NULL OR UDG_PDD.DataGroupId IS NOT NULL) THEN g.DescProductDescription ELSE N'[No Access]' END AS [DescProductDescription]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR BAD.DataGroupId IS NULL OR UDG_BAD.DataGroupId IS NOT NULL) THEN g.AscBOM ELSE N'[No Access]' END AS [AscBOM]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR BDD.DataGroupId IS NULL OR UDG_BDD.DataGroupId IS NOT NULL) THEN g.DescBOM ELSE N'[No Access]' END AS [DescBOM]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR E.DataGroupId IS NULL OR UDG_E.DataGroupId IS NOT NULL) THEN E.EmployeeId ELSE -1 END AS [EmployeeId]
                , CASE WHEN (@IsObjectSecurityEnabled = 0 OR E.DataGroupId IS NULL OR UDG_E.DataGroupId IS NOT NULL) THEN E.Name ELSE N'[No Access]' END AS [Employee]
                , g.AscPQ, g.AscPQAfter, g.AscPrimaryUnits, g.AscSQ, g.AscSQAfter, g.AscSecondaryUnits,g.DescPQ, g.DescPrimaryUnits, g.DescSQ, g.DescSecondaryUnits, g.AscAssembleQ, g.AscAssembleSecQ, g.DescAssembleQ, g.DescAssembleSecQ
                , g.ReferenceDesignator, g.SourceLocation, g.TargetLocation
            FROM [CoreDataModel].[V_MaterialGenealogy] g
            INNER JOIN #tmpGenealogyDesc b
                ON (b.level = @level-1 AND b.DescMaterialId = g.AscMaterialId AND g.ServiceHistoryId >= b.ServiceHistoryId )
--following branches out repeated branches avoiding infinite cycles when materials have splits and merge backs
            LEFT OUTER JOIN #tmpGenealogyDesc c
                ON (c.DescMaterialId = g.DescMaterialId AND c.ServiceHistoryId = g.ServiceHistoryId AND c.RootMaterialId = b.RootMaterialId)
            LEFT OUTER JOIN @StepTab AscStep ON (AscStep.StepID = g.AscStepId)
            LEFT OUTER JOIN @StepTab DescStep ON (DescStep.StepID = g.DescStepId)
            INNER JOIN CoreDataModel.T_Material MA ON MA.MaterialId = g.AscMaterialId
            INNER JOIN CoreDataModel.T_Material MD ON MD.MaterialId = g.DescMaterialId
            LEFT JOIN CoreDataModel.T_Resource RA ON RA.ResourceId = g.AscResourceId
            LEFT JOIN CoreDataModel.T_Resource RD ON RD.ResourceId = g.DescResourceId
            LEFT JOIN CoreDataModel.T_Area AA ON AA.AreaId = RA.AreaId
            LEFT JOIN CoreDataModel.T_Area AD ON AD.AreaId = RD.AreaId
            INNER JOIN CoreDataModel.T_Step SA ON SA.StepId = g.AscStepId
            INNER JOIN CoreDataModel.T_Step SD ON SD.StepId = g.DescStepId
            INNER JOIN CoreDataModel.T_Product PA ON PA.ProductId = g.AscProductId
            INNER JOIN CoreDataModel.T_Product PAD ON PAD.ProductId = PA.DefinitionId
            INNER JOIN CoreDataModel.T_Product PD ON PD.ProductId = g.DescProductId
            INNER JOIN CoreDataModel.T_Product PDD ON PDD.ProductId = PD.DefinitionId
            LEFT JOIN CoreDataModel.T_BOM BA ON BA.BOMId = g.AscBOMId
            LEFT JOIN CoreDataModel.T_BOM BAD ON BAD.BOMId = BA.DefinitionId
            LEFT JOIN CoreDataModel.T_BOM BD ON BD.BOMId = g.DescBOMId
            LEFT JOIN CoreDataModel.T_BOM BDD ON BDD.BOMId = BD.DefinitionId
            INNER JOIN dbo.T_ServiceHistory SH ON SH.ServiceHistoryId = g.ServiceHistoryId
            LEFT JOIN [Security].T_User U ON U.UserAccount = SH.CreatedBy
            LEFT JOIN [CoreDataModel].[T_Employee] E ON E.UserId = U.UserId
            LEFT JOIN #UserDataGroups UDG_MA ON UDG_MA.DataGroupId = MA.DataGroupId
            LEFT JOIN #UserDataGroups UDG_MD ON UDG_MD.DataGroupId = MD.DataGroupId
            LEFT JOIN #UserDataGroups UDG_RA ON UDG_RA.DataGroupId = RA.DataGroupId
            LEFT JOIN #UserDataGroups UDG_RD ON UDG_RD.DataGroupId = RD.DataGroupId
            LEFT JOIN #UserDataGroups UDG_AA ON UDG_AA.DataGroupId = AA.DataGroupId
            LEFT JOIN #UserDataGroups UDG_AD ON UDG_AD.DataGroupId = AD.DataGroupId
            LEFT JOIN #UserDataGroups UDG_SA ON UDG_SA.DataGroupId = SA.DataGroupId
            LEFT JOIN #UserDataGroups UDG_SD ON UDG_SD.DataGroupId = SD.DataGroupId
            LEFT JOIN #UserDataGroups UDG_PAD ON UDG_PAD.DataGroupId = PAD.DataGroupId
            LEFT JOIN #UserDataGroups UDG_PDD ON UDG_PDD.DataGroupId = PDD.DataGroupId
            LEFT JOIN #UserDataGroups UDG_BAD ON UDG_BAD.DataGroupId = BAD.DataGroupId
            LEFT JOIN #UserDataGroups UDG_BDD ON UDG_BDD.DataGroupId = BDD.DataGroupId
            LEFT JOIN #UserDataGroups UDG_E ON UDG_E.DataGroupId = E.DataGroupId
            LEFT JOIN UserDataModel.T_CustomMaterialBatch AS AscBatch ON AscBatch.SourceEntityId = g.AscMaterialId
            LEFT JOIN CoreDataModel.T_Material AscBatchMat on (AscBatchMat.MaterialId = AscBatch.TargetEntityId)
            LEFT JOIN UserDataModel.T_CustomMaterialBatch AS DescBatch ON DescBatch.SourceEntityId = g.DescMaterialId
            LEFT JOIN CoreDataModel.T_Material DescBatchMat on (DescBatchMat.MaterialId = DescBatch.TargetEntityId)
            WHERE g.OperationEndTime BETWEEN @DateStartHost AND @DateEndHost            
              AND c.LEVEL IS NULL
              AND (@HasStepFilter = 0 OR AscStep.StepID > 0 OR DescStep.StepID > 0)
--
            OPTION (RECOMPILE);

            SET @RowCount = @@ROWCOUNT;
        END;

        select 'Descendant' as GenealogyMode, t.*, 'R' + Format(row_number() over (order by  RootMaterialId, [level],  OperationEndTime, ServiceHistoryId , DescIsParentBatch DESC ), '00000000000000000000') rnum 
        from #tmpGenealogyDesc t;


    END;    
END;