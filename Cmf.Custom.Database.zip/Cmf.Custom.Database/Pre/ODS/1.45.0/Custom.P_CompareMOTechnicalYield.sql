
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = 'Custom')
BEGIN
EXEC('create schema Custom')
END
GO


IF EXISTS ( SELECT * 
            FROM   sysobjects 
            WHERE  id = object_id(N'[Custom].[P_CompareMOTechnicalYield]') 
                   and OBJECTPROPERTY(id, N'IsProcedure') = 1 )
BEGIN
    DROP PROCEDURE [Custom].[P_CompareMOTechnicalYield]
END
GO

CREATE PROCEDURE [Custom].[P_CompareMOTechnicalYield]
	@PoName nvarchar(max),
	@Start datetime,
	@End datetime,
	@FacilityName nvarchar(max),
	@AreaName nvarchar(max)
AS 
BEGIN
	
	SET NOCOUNT ON;

	/* declare vars */
	declare @fst_srvhistory_id bigint = null
	declare @lst_srvhistory_id bigint = null
	declare @StartDate datetime = @Start
	declare @EndDate datetime = dateadd(day, 1, @End)
	declare @ordermaterialform nvarchar(30)


	/* Delete temporary tables. They should not exist at this point but helps on debugging.. */
	if(object_id('tempdb..#FacilityTempTable') is not null) drop table #FacilityTempTable
	if(object_id('tempdb..#AreaTempTable') is not null) drop table #AreaTempTable
	if(object_id('tempdb..#ResourceTempTable') is not null) drop table #ResourceTempTable
	if(object_id('tempdb..#allowedServices') is not null) drop table #allowedServices
	if(object_id('tempdb..#materialservices') is not null) drop table #materialservices
	if(OBJECT_ID('tempdb..#completedMaterialForm') IS NOT NULL) DROP TABLE #completedMaterialForm


	/* Create temporary tables */
	create table #FacilityTempTable (Name nvarchar(512))
	create table #ResourceTempTable (Name nvarchar(512))
	create table #AreaTempTable(Name nvarchar(512))
	create table #allowedServices (service_id bigint, Name nvarchar(512))
	create table #completedMaterialForm (Form nvarchar(512))
	create table #materialservices (MaterialId bigint, Name nvarchar(512), ServiceName nvarchar(512), ServiceHistoryId bigint, ServiceStartTime datetime,   
														  ProductionOrderId bigint, FirstSIDOpSeq int, LastSIDOpSeq int)


	/* Set data for completed Material Form */
	INSERT INTO #completedMaterialForm
	SELECT Form FROM UserDataModel.T_ST_CustomCompletedMaterialForm
	UNION
	SELECT [dbo].[F_GetConfigStringValue](N'/Cmf/Custom/MaterialTracking/CompletedMaterialForm/', N'Pallet')

	DECLARE @RejectUnit NVARCHAR(512) = (SELECT [dbo].[F_GetConfigStringValue](N'/Cmf/Custom/ScrapManagement/RejectUnit/', N'Reject'))

	DECLARE @BaseMaterialETP BIGINT = (
										SELECT ISNULL(MAX(ETP.EntityTypePropertyId), 0)
										FROM dbo.T_EntityType ET
										INNER JOIN dbo.T_EntityTypeProperty ETP ON ETP.EntityTypeId = ET.EntityTypeId
										WHERE ET.Name = 'Material' AND ETP.Name = 'BaseMaterial'
									   )


	/* If no PO is supplied show all */
	if trim(@PoName) = ''
	begin
		set @PoName = null
	end

	/* Temp Table with Facilities */
	if(len(@FacilityName) > 0)
	begin
	  insert into #FacilityTempTable 
	  select [Value] from dbo.F_Split2(@FacilityName, ';');

	end

	/* Temp Table with Areas */
	if(len(@AreaName) > 0)
	begin
		   insert into #AreaTempTable
		   select [Value] from dbo.F_Split2(@AreaName, ';');

	end


	/* If MOs are supplied in a string, Resolve material IDs and et Date interval */
	if(@PoName is not null)
	begin    
	  select @StartDate = min(M.CreatedOn), @EndDate = max(M.ModifiedOn)
	  from CoreDataModel.T_Material M
	  where M.Name like (@PoName + '%')
	end

	/* Get first and last service history ids by date */
	set @fst_srvhistory_id = [dbo].[F_Part_GetMinServiceHistoryIdForDate](dateadd(day, -1, @StartDate))
	set @lst_srvhistory_id = [dbo].[F_Part_GetMaxServiceHistoryIdForDate](dateadd(day, 1, @EndDate))


	/* Set data for selected services IDs */
	insert into #allowedServices
	select ServiceId, Name from Security.T_Service
	where name IN ('ChangeMaterialFlowAndStep',
					'ComplexMoveMaterialsToNextStep',
					'ComplexMoveMaterialToNextStep',
					'ComplexMoveMaterialToStep',
					'ComplexTrackOutAndMoveMaterialsToNextStep',
					'ComplexTrackOutAndMoveMaterialToNextStep',
					'MoveMaterialsToNextStep',
					'MoveMaterialToNextStep',
					'MoveMaterialToStep',
					'TerminateMaterial')

	DECLARE @FlowERPOperationCodeETP BIGINT = (
												SELECT ISNULL(MAX(ETP.EntityTypePropertyId), 0)
												FROM dbo.T_EntityType ET
												INNER JOIN dbo.T_EntityTypeProperty ETP ON ETP.EntityTypeId = ET.EntityTypeId
												WHERE ET.Name = 'Flow' AND ETP.Name = 'ERPOperationCode'
											  )

	;WITH BASE_DATA AS
	(
		SELECT MH.Name AS MaterialName, MH.MaterialId, MH.ServiceHistoryId
				, FIRST_VALUE(ISNULL(MHP.ProductionOrderId, MH.ProductionOrderId))  OVER (PARTITION BY MH.ServiceHistoryId, MH.MaterialId ORDER BY MH.ModifiedOn, MH.OperationHistorySeq, OH.SubOperationSequence) ProductionOrderId
				, FIRST_VALUE(ISNULL(MHP.FlowPath, MH.FlowPath))  OVER (PARTITION BY MH.ServiceHistoryId, MH.MaterialId ORDER BY MH.ModifiedOn, MH.OperationHistorySeq, OH.SubOperationSequence) StartingFlowPath
				, FIRST_VALUE(ISNULL(MHP.StepId, MH.StepId)) OVER (PARTITION BY MH.ServiceHistoryId, MH.MaterialId ORDER BY MH.ModifiedOn, MH.OperationHistorySeq, OH.SubOperationSequence) StartingStep
				, MH.FlowPath EndingFlowPath
				, MH.StepId EndingStep
				, DENSE_RANK()  OVER (PARTITION BY MH.ServiceHistoryId, MH.MaterialId ORDER BY MH.ModifiedOn DESC, MH.OperationHistorySeq DESC, OH.SubOperationSequence DESC) IsLastRecord
				, MH.TrackInDate
				, MH.ModifiedOn
				, MH.Form
				, MH.Type
				, MH.PrimaryQuantity + (CASE ISNULL(MH.SecondaryUnits, N'') WHEN @RejectUnit THEN MH.SecondaryQuantity ELSE 0 END) TotalQuantity
				, MH.UniversalState
				, MA.Value AS MoMaterialName
				, MH.LastProcessedResourceId
				, MH.FacilityId
		FROM #allowedServices ALLS
		INNER JOIN dbo.T_ServiceHistory SH ON SH.ServiceId = ALLS.service_id
		INNER JOIN CoreDataModel.T_MaterialHistory MH ON MH.ServiceHistoryId = SH.ServiceHistoryId AND MH.ServiceHistoryId BETWEEN @fst_srvhistory_id AND @lst_srvhistory_id
		LEFT JOIN CoreDataModel.T_MaterialAttribute MA ON MA.MaterialId = MH.MaterialId AND MA.EntityTypePropertyId = @BaseMaterialETP
		LEFT JOIN CoreDataModel.T_MaterialHistory MHP ON MHP.ServiceHistoryId = MH.OldServiceHistoryId
				AND MHP.OperationHistorySeq = MH.OldOperationHistorySeq
		INNER JOIN dbo.T_OperationHistory OH ON OH.ServiceHistoryId = MH.ServiceHistoryId AND OH.OperationHistorySeq = MH.OperationHistorySeq

		WHERE SH.ServiceHistoryId BETWEEN @fst_srvhistory_id AND @lst_srvhistory_id
		AND (@PoName IS NULL OR MH.Name LIKE '%'+ @PoName +'%')
	)
	, BASE_DATA_FILTERED AS(
		SELECT F.Name AS FacilityName, A.Name AS AreaName, BD.*
		FROM BASE_DATA BD
		INNER JOIN CoreDataModel.T_Facility F ON F.FacilityId = BD.FacilityId
		INNER JOIN #FacilityTempTable FT ON FT.Name = F.Name
		INNER JOIN CoreDataModel.T_StepArea SA ON SA.SourceEntityId = BD.StartingStep
		INNER JOIN CoreDataModel.T_Area A ON A.AreaId = SA.TargetEntityId AND a.FacilityId = BD.FacilityId
		INNER JOIN #AreaTempTable ATemp ON ATemp.Name = A.Name
	)
	, FINAL_EVENTS AS
	(
		   SELECT BD.*
		   FROM BASE_DATA_FILTERED BD
		   INNER JOIN #completedMaterialForm CMF ON CMF.Form = BD.Form
		   WHERE BD.IsLastRecord = 1
				AND BD.ModifiedON BETWEEN @StartDate AND @EndDate
	)
	, DECODED_FLOW_PATHS AS
	(
		SELECT *
				, SUBSTRING(StartingFlowPath,
									CASE CHARINDEX('/', REVERSE(StartingFlowPath), CHARINDEX('/', REVERSE(StartingFlowPath), 1) + 1)
									WHEN 0 THEN 1
									ELSE LEN(StartingFlowPath) - CHARINDEX('/', REVERSE(StartingFlowPath), CHARINDEX('/', REVERSE(StartingFlowPath), 1) + 1) + 2
									END
								, CASE CHARINDEX('/', REVERSE(StartingFlowPath), CHARINDEX('/', REVERSE(StartingFlowPath), 1) + 1)
									WHEN 0 THEN CHARINDEX('/', StartingFlowPath) - 1
									ELSE CHARINDEX('/', REVERSE(StartingFlowPath), CHARINDEX('/', REVERSE(StartingFlowPath), 1) + 1) - CHARINDEX('/', REVERSE(StartingFlowPath), 1) - 1
									END
						   ) StartingFlowPathDecoded
				, SUBSTRING(EndingFlowPath,
									CASE CHARINDEX('/', REVERSE(EndingFlowPath), CHARINDEX('/', REVERSE(EndingFlowPath), 1) + 1)
									WHEN 0 THEN 1
									ELSE LEN(EndingFlowPath) - CHARINDEX('/', REVERSE(EndingFlowPath), CHARINDEX('/', REVERSE(EndingFlowPath), 1) + 1) + 2
									END
								, CASE CHARINDEX('/', REVERSE(EndingFlowPath), CHARINDEX('/', REVERSE(EndingFlowPath), 1) + 1)
									WHEN 0 THEN CHARINDEX('/', EndingFlowPath) - 1
									ELSE CHARINDEX('/', REVERSE(EndingFlowPath), CHARINDEX('/', REVERSE(EndingFlowPath), 1) + 1) - CHARINDEX('/', REVERSE(EndingFlowPath), 1) - 1
									END
						   ) EndingFlowPathDecoded
		FROM FINAL_EVENTS
	)
	, FLOW_EXTRACTION AS
	(
		SELECT *
				, LEFT(StartingFlowPathDecoded, CHARINDEX(':', StartingFlowPathDecoded, 1) - 1) StartingFlowName
				, LEFT(EndingFlowPathDecoded, CHARINDEX(':', EndingFlowPathDecoded, 1) - 1) EndingFlowName
		FROM DECODED_FLOW_PATHS
	)
	SELECT PO.Name AS PoName
		   , BD.MoMaterialName
		   , INFA.Value StartingFlowERPOperationCode , ENFA.Value EndingFlowERPOperationCode
		   , INF.Name StartingFlow
		   , SS.Name StartingStep
		   , ENF.Name EndingFlow
		   , ES.Name EndingStep
		   , CPR.PlannedGoodQuantity
		   , CPR.PlannedOperationQuantity
		   , CPR.ProjectedCycleTime
		   , BD.Type
		   , Sum(BD.TotalQuantity) AS Quantity
		   , BD.FacilityName
		   , BD.AreaName
	FROM FLOW_EXTRACTION BD
	INNER JOIN CoreDataModel.T_Flow INF ON INF.Name = BD.StartingFlowName AND INF.Version = 0
	LEFT JOIN CoreDataModel.T_FlowAttribute INFA ON INFA.FlowId = INF.FlowId AND INFA.EntityTypePropertyId = @FlowERPOperationCodeETP
	INNER JOIN CoreDataModel.T_Flow ENF ON ENF.Name = BD.EndingFlowName AND ENF.Version = 0
	LEFT JOIN CoreDataModel.T_FlowAttribute ENFA ON ENFA.FlowId = ENF.FlowId AND INFA.EntityTypePropertyId = @FlowERPOperationCodeETP
	INNER JOIN CoreDataModel.T_Step SS ON SS.StepId = BD.StartingStep
	INNER JOIN CoreDataModel.T_Step ES ON ES.StepId = BD.EndingStep
	INNER JOIN CoreDataModel.T_ProductionOrder PO ON PO.ProductionOrderId = BD.ProductionOrderId
	LEFT JOIN UserDataModel.T_CustomPOOperationResource CPR ON CPR.SourceEntityId = PO.ProductionOrderId AND CPR.OperationCode = ISNULL(INFA.Value, '')

	WHERE BD.UniversalState = 4 OR ISNULL(INFA.Value, '') <> ISNULL(ENFA.Value, '')
	AND (@PoName IS NULL OR PO.Name LIKE '%'+ @PoName +'%')
	
	GROUP BY PO.Name, MoMaterialName, BD.Type
		   , INFA.Value, ENFA.Value 
		   , INF.Name , SS.Name 
		   , ENF.Name , ES.Name 
		   , CPR.PlannedGoodQuantity
		   , CPR.PlannedOperationQuantity
		   , CPR.ProjectedCycleTime
		   , BD.FacilityName
		   , BD.AreaName

END
GO