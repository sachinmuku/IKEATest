IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = 'Custom')
BEGIN
EXEC('create schema Custom')
END
GO
IF EXISTS ( SELECT * 
            FROM   sysobjects 
            WHERE  id = object_id(N'[Custom].[P_CustomGetResourceMaintenanceHistory]') 
                   AND objectproperty(id, N'IsProcedure') = 1 )
BEGIN
    DROP PROCEDURE [Custom].[P_CustomGetResourceMaintenanceHistory]
END
GO

CREATE PROCEDURE [Custom].[P_CustomGetResourceMaintenanceHistory]
	@DateStart DATETIME,
	@DateEnd DATETIME,
	@FacilityId NVARCHAR(MAX),
	@NFacTotalElems INT,
	@Area_ID NVARCHAR(MAX),
	@NAreaTotalElems INT,
	@Resource_ID NVARCHAR(MAX),
	@NResourceTotalElems INT,	
	@ResourceType NVARCHAR(MAX),
	@NResTypeTotalElems INT,
	@ResourceModel NVARCHAR(MAX),
	@NResModelTotalElems INT,
	@MaintenanceActivityType NVARCHAR(MAX),
	@NResMaintenanceActivityTypes INT,
	@ScheduleType NVARCHAR(200),
    @MaintenanceSourceTypes NVARCHAR(200)

AS
BEGIN

	SET NOCOUNT ON;

/* --  TO TEST
DECLARE @DateStart			DATETIME = dateadd(day,-60, getdate()),
		@DateEnd			DATETIME = dateadd(day, 3, getdate()),
		@FacilityId NVARCHAR(MAX) = '1905221058290000005',
		@NFacTotalElems INT = 1,
		@Area_ID NVARCHAR(MAX) = '1905221058290000005',
		@NAreaTotalElems INT = 1,
		@Resource_ID NVARCHAR(MAX) = '1905221058290000018, 1905221058290000019, 1905221058290000026,1905221058290000027,1905221058290000041,1905221058290000042',
		@NResourceTotalElems INT = 6,	
		@ResourceType NVARCHAR(MAX) = 'Feed,Standard',
		@NResTypeTotalElems INT = 2,
		@ResourceModel NVARCHAR(MAX) = 'All',
		@NResModelTotalElems INT = 1,
		@MaintenanceActivityType NVARCHAR(MAX) = 'CorrectiveMaintenance,Generic,PlannedMaintenance,Standard',
		@NResMaintenanceActivityTypes INT = 4,
		@ScheduleType NVARCHAR(200) = 'UsageBase,TimeBase,Adhoc',
		@MaintenanceSourceTypes NVARCHAR(200) = 'MANUAL;AUTOMATIC;SPC;Any'
*/

	IF(object_id('tempdb..#ResourceMaintenanceH') IS NOT NULL) DROP TABLE #ResourceMaintenanceH
	IF(object_id('tempdb..#TempSourceTypes') IS NOT NULL) DROP TABLE #TempSourceTypes

	CREATE TABLE #TempSourceTypes(SourceTypes NVARCHAR(200))

	IF(LEN(@MaintenanceSourceTypes) > 0)
	BEGIN
	  INSERT INTO #TempSourceTypes 
	  SELECT CASE WHEN [Value] = 'Any' THEN '' 
				  WHEN [Value] <> 'Any' THEN 'Source: '+ [Value] ELSE [Value] END
	   FROM dbo.F_Split2(@MaintenanceSourceTypes, ',');
	END
	
	CREATE TABLE #ResourceMaintenanceH
	(
		MaintenancePlanId BIGINT
		, MaintenancePlanName NVARCHAR(256)
		, MaintenancePlanInstanceId BIGINT
		, ResourceId BIGINT
		, ResourceName NVARCHAR(256)
		, MaintenanceActivityOrderId BIGINT
		, MaintenanceActivityOrderName NVARCHAR(256)
		, [Description] NVARCHAR(256)
		, CreatedBy NVARCHAR(256)
		, CreatedOn DATETIME
		, LastModifiedOn DATETIME
		, IsAdhoc BIT
		, IsTimeBased BIT
		, IsUsageBased BIT
		, IgnoreInScheduling BIT
		, BeginAndCompleteMode NVARCHAR(256)
		, ScheduleState NVARCHAR(256)
		, [ExecutionState] NVARCHAR(256)
		, AdhocRequestComment NVARCHAR(256)
		, BeginDate DATETIME
		, EndDate DATETIME
		, EffectiveEndDate DATETIME
		, CounterDue DECIMAL(18,8)
		, CounterValue DECIMAL(18,8)
		, DueDate DATETIME
		, ScheduledDate DATETIME
		, DataCollectionInstanceId BIGINT
		, CheckListInstanceId BIGINT
		, ExpectedDuration DECIMAL(18,8)
		, MaintenanceActivityType NVARCHAR(256)
		, Cost DECIMAL(18,8)
		, MaintenanceActivityId BIGINT
		, MaintenanceActivityName NVARCHAR(256)
		, rnum NVARCHAR(256)
	);

	INSERT INTO #ResourceMaintenanceH Exec [Reports].[P_GetResourceMaintenanceHistory_RP_ODS] 
												@DateStart, @DateEnd, @FacilityId, @NFacTotalElems, @Area_ID, @NAreaTotalElems, @Resource_ID, @NResourceTotalElems, @ResourceType,
												@NResTypeTotalElems, @ResourceModel, @NResModelTotalElems, @MaintenanceActivityType, @NResMaintenanceActivityTypes


	SELECT * FROM #ResourceMaintenanceH R
	INNER JOIN #TempSourceTypes T ON  isnull(R.AdhocRequestComment, '') = T.SourceTypes
	WHERE 
		  IsAdhoc = CASE WHEN @ScheduleType LIKE '%Adhoc%' THEN 1 ELSE 0 END  OR
		  IsTimeBased = CASE WHEN @ScheduleType LIKE '%TimeBase%' THEN 1 ELSE 0 END OR
		  IsUsageBased = CASE WHEN @ScheduleType LIKE '%UsageBase%' THEN 1 ELSE 0 END

		
END
GO