/**
** Version History

** Version		     Date		      Author		  Description 
** ---------		   ----------  -------		 ----------------------------------------------------------------------
** Sprint 13     30/06/2021  Paulo S.		New custom procedure based on the GetResourceOEE with the shift filter
*/

CREATE OR ALTER   PROCEDURE [UserDataModel].[P_CustomGetResourceOEE_ODS]
     @TimeFrame NVARCHAR(28), --Day, Week, Month 
     @GetActual BIT, -- 0: yesterday, 1: today
					@ShowDecimals BIT, -- 0: round to 0, 1: round to 1 decimal digits
     @Facility NVARCHAR(512), -- One or more Facilities split by name
     @Area NVARCHAR(512), -- One or more Areas split by name
     @Resources NVARCHAR(4000),-- One or more resources split by name
					@ResourceTypes NVARCHAR(4000), -- One or more resource types (only key will be set)
					@ResourceResourceTypes NVARCHAR(4000), -- One or more resource resource types (only key will be set)
    	@ShiftDefinition NVARCHAR(4000), -- Only Works with one ShiftDefinition
	    @ShiftName NVARCHAR(4000), -- Requires the ShiftDefinition to be defined
					@PrintScript BIT=0
AS
BEGIN

--DECLARE
--     @TimeFrame NVARCHAR(28) = 'Month', --Day, Week, Month 
--     @GetActual BIT =1, -- 0: yesterday, 1: today
--					@ShowDecimals BIT=1, -- 0: round to 0, 1: round to 1 decimal digits
--     @Facility NVARCHAR(512), -- One or more Facilities split by name
--     @Area NVARCHAR(512), -- One or more Areas split by name
--     @Resources NVARCHAR(4000),-- One or more resources split by name
--					@ResourceTypes NVARCHAR(4000), -- One or more resource types (only key will be set)
--					@ResourceResourceTypes NVARCHAR(4000), -- One or more resource resource types (only key will be set)
--     @ShiftDefinition nvarchar(1000),
--	   	@ShiftName nvarchar(1000),
--					@PrintScript BIT=1
	SET NOCOUNT ON;

	declare @ResultSet as table 
	(
		[Time] int,
	 [Year] nvarchar(100),
		[Month] nvarchar(100),
		[Day] nvarchar(100),
		[Week] nvarchar(100),
		[OEE] decimal(18, 1),
		[Availability] decimal(18, 1),
		[Quality] decimal(18, 1),
		[Performance] decimal(18, 1)
	)
	DECLARE @LinkedServer nvarchar(4000);
	SET @LinkedServer =  N'cm'+[dbo].[F_GetSystemName]()+N'ASLink';
	declare @ResourceFilter nvarchar(1000),  @FacilityFilter nvarchar(1000), @AreaFilter nvarchar(1000), @ClosureCommas nvarchar(10) = ')',
		    @TimeFilter nvarchar(1000), @TimeSelectCols nvarchar(1000), @DataSelect nvarchar(1000), @ResourceTypesFilter nvarchar(1000), @ResourceResourceTypesFilter nvarchar(1000),@ShiftFilter nvarchar(1000);   
    
-- resources
	IF (len(@Resources) > 0)
	BEGIN
		SET @ResourceFilter = 'FROM ( SELECT ( {[Resource].[Resource Name].&[' + replace(@Resources, ',', '], [Resource].[Resource Name].&[') + '] } ) ON COLUMNS';
		SET @ClosureCommas += ')';
	END
	ELSE
	BEGIN
		SET @ResourceFilter = '';
	END;

-- resource types
	IF (len(@ResourceTypes) > 0)
	BEGIN
		SET @ResourceTypesFilter = 'FROM ( SELECT ( {[Resource].[Type].&[' + replace(@ResourceTypes, ',', '], [Resource].[Type].&[') + '] } ) ON COLUMNS';
		SET @ClosureCommas += ')';
	END
	ELSE
	BEGIN
		SET @ResourceTypesFilter = '';
	END;

-- resource resource types
	IF (len(@ResourceResourceTypes) > 0)
	BEGIN
		SET @ResourceResourceTypesFilter = 'FROM ( SELECT ( {[Resource].[Resource Type].&[' + replace(@ResourceResourceTypes, ',', '], [Resource].[Resource Type].&[') + '] } ) ON COLUMNS';
		SET @ClosureCommas += ')';
	END
	ELSE
	BEGIN
		SET @ResourceResourceTypesFilter = '';
	END;
	
--facility
	IF (len(@Facility) > 0)
	BEGIN
		SET @FacilityFilter = 'FROM ( SELECT ( {[Facility].[Facility Name].&[' + replace(@Facility, ',', '], [Facility].[Facility Name].&[') + '] } ) ON COLUMNS';
		SET @ClosureCommas += ')';
	END
	ELSE
	BEGIN
		SET @FacilityFilter = '';
	END;

--area
	IF (len(@Area) > 0)
	BEGIN
		SET @AreaFilter = 'FROM ( SELECT ( {[Area].[Area Name].&[' + replace(@Area, ',', '], [Area].[Area Name].&[') + '] } ) ON COLUMNS';
		SET @ClosureCommas += ')';
	END
	ELSE
	BEGIN
		SET @AreaFilter = '';
	END;

 	-- Shift filter
		IF (LEN(@ShiftName) > 0 AND LEN(@ShiftDefinition) > 0)
		BEGIN
			SET @ShiftFilter = 'FROM ( SELECT ( {[Shift].[Shift Hierarchy].[Shift Description].&[' + @ShiftDefinition + ' (' + @ShiftDefinition + ' - ' + replace(@ShiftName, ',', ')], [Shift].[Shift Hierarchy].[Shift Description].&[' + @ShiftDefinition + ' (' + @ShiftDefinition + ' - ') + ')] } ) ON COLUMNS';
			SET @ClosureCommas += ')';
		END
		ELSE
		BEGIN
			SET @ShiftFilter = '';
		END;

	IF(@TimeFrame = 'Day')
	BEGIN
-- get actual influences start and end search
		SET @TimeFilter = 
'FROM ( SELECT ( StrToMember(''''[Date].[Calendar Day].[Calendar Day].&['''' + FORMAT(Now(), "yyyy-MM-dd") + '''']'''').Lag('			
					+ case when @GetActual = 0 then '8' else '7' end +')  : StrToMember(''''[Date].[Calendar Day].[Calendar Day].&['''' + FORMAT(Now(), "yyyy-MM-dd") + '''']'''')'+ case when @GetActual = 0 then '.Lag(1)' else '' end +' ) ON COLUMNS';
		SET @TimeSelectCols = '([Date].[Calendar Month].[Calendar Month].ALLMEMBERS * [Date].[Calendar Months].[Calendar Year].ALLMEMBERS * [Date].[Calendar Day].[Calendar Day].ALLMEMBERS)'

		SET @DataSelect = 'select 1 - row_number() over (order by [Year] desc, [Month] desc, [Day] desc) as [time]
				, dat.[Year]
				, dat.[Month]
				, dat.[Day]
				, dat.[OEE]
				, dat.[Availability]
				, dat.Quality
				, dat.Performance		  
		from (
			SELECT convert(nvarchar(100),"[Date].[Calendar Month].[Calendar Month].[MEMBER_CAPTION]") as [Month]
				,convert(nvarchar(100),"[Date].[Calendar Months].[Calendar Year].[MEMBER_CAPTION]") as [Year]
				,convert(nvarchar(100),"[Date].[Calendar Day].[Calendar Day].[MEMBER_CAPTION]") as [Day]
				,"[Measures].[Availability]" as [Availability]
				,"[Measures].[Performance]" as [Performance]
				,"[Measures].[Quality]" as [Quality]
				,"[Measures].[OEE]" as [OEE]';

	END
	ELSE IF(@TimeFrame = 'Week')
	BEGIN
-- get actual influences start and end search
		SET @TimeFilter = 
'FROM ( SELECT ( StrToMember(''''[Date].[Calendar Weeks].[Calendar Week].&['			 + Format(datepart(ISO_WEEK, getutcdate()), '00')+']&['+Format(datepart(year, getutcdate()), '0000')+']'''').Lag('
					+ case when @GetActual = 0 then '8' else '7' end +')  : StrToMember(''''[Date].[Calendar Weeks].[Calendar Week].&[' + Format(datepart(week, getutcdate()), '00')+']&['+Format(datepart(year, getutcdate()), '0000')+']'''')'+ case when @GetActual = 0 then '.Lag(1)' else '' end +' ) ON COLUMNS';
		SET @TimeSelectCols = '([Date].[Calendar Months].[Calendar Year].ALLMEMBERS * [Date].[Calendar Weeks].[Calendar Week].ALLMEMBERS)'

		SET @DataSelect = 'select 1 - row_number() over (order by [Year] desc, [Week] desc) as [time]
				, dat.[Year]
				, dat.[Week]
				, dat.[OEE]
				, dat.[Availability]
				, dat.Quality
				, dat.Performance		  
		from (
			SELECT convert(nvarchar(100),"[Date].[Calendar Weeks].[Calendar Week].[MEMBER_CAPTION]") as [Week]
				,convert(nvarchar(100),"[Date].[Calendar Weeks].[Calendar Year].[MEMBER_CAPTION]") as [Year]
				,"[Measures].[Availability]" as [Availability]
				,"[Measures].[Performance]" as [Performance]
				,"[Measures].[Quality]" as [Quality]
				,"[Measures].[OEE]" as [OEE]';

	END
	ELSE IF(@TimeFrame = 'Month')
	BEGIN
-- get actual influences start and end search
		SET @TimeFilter = 
'FROM ( SELECT ( StrToMember(''''[Date].[Calendar Months].[Calendar Month].&['''' + FORMAT(Now(), "\MMM \C\Y yyyy") + '''']'''').Lag('			
					+ case when @GetActual = 0 then '8' else '7' end +')  : StrToMember(''''[Date].[Calendar Months].[Calendar Month].&['''' + FORMAT(Now(), "\MMM \C\Y yyyy") + '''']'''')'+ case when @GetActual = 0 then '.Lag(1)' else '' end +' ) ON COLUMNS';
		SET @TimeSelectCols = '([Date].[Calendar Month].[Calendar Month].ALLMEMBERS * [Date].[Calendar Months].[Calendar Year].ALLMEMBERS )'

		SET @DataSelect = 'select 1 - row_number() over (order by [Year] desc, [Month] desc) as [time]
				, dat.[Year]
				, dat.[Month]
				, dat.[OEE]
				, dat.[Availability]
				, dat.Quality
				, dat.Performance		  
		from (
			SELECT convert(nvarchar(100),"[Date].[Calendar Month].[Calendar Month].[MEMBER_CAPTION]") as [Month]
				,convert(nvarchar(100),"[Date].[Calendar Months].[Calendar Year].[MEMBER_CAPTION]") as [Year]
				,"[Measures].[Availability]" as [Availability]
				,"[Measures].[Performance]" as [Performance]
				,"[Measures].[Quality]" as [Quality]
				,"[Measures].[OEE]" as [OEE]';

	END;

	IF (exists(select * from sys.servers where name = @LinkedServer))
	BEGIN
		declare @MDXQuery nvarchar(4000) = '
		select r.[Time], ISNULL([OEE], 0) as [OEE], ISNULL([Availability], 0) as [Availability], ISNULL([Quality], 0) as [Quality], ISNULL([Performance], 0) as [Performance] 
		from (
			${InnerSelection} 
		FROM OPENQUERY('+ @LinkedServer + N',''
		WITH MEMBER [Measures].[Availability] AS ''''Round([Measures].[Up Time (%)]*100,${ShowDecimals})''''
			 MEMBER [Measures].[OEE] AS ''''Round([Measures].[OEE (%)]*100,${ShowDecimals})''''
			 MEMBER [Measures].[Performance] AS ''''Round([Performance Efficiency (%)]*100,${ShowDecimals})''''
			 MEMBER [Measures].[Quality] AS ''''Round([Measures].[Rate of Quality (%)]*100,${ShowDecimals})''''

			SELECT  { [Measures].[Availability], [Measures].[Performance], [Measures].[Quality] , [Measures].[OEE] } ON COLUMNS
				     , { ${TimeSelectCols} }  ON ROWS 
			       ${ResourceFilter}
			       ${ResourceTypeFilter}
			       ${ResourceResourceTypeFilter}
			       ${FacilityFilter}
			       ${AreaFilter}		
			       ${TimeFilter}	  
          ${ShiftFilter}
			  FROM [Resource] ${ClosureCommas}'') idat ) dat
				) r'; 

		SET @MDXQuery = REPLACE(@MDXQuery, '${ShowDecimals}', convert(char(1), @ShowDecimals));
		SET @MDXQuery = REPLACE(@MDXQuery, '${ResourceFilter}', @ResourceFilter);
		SET @MDXQuery = REPLACE(@MDXQuery, '${ResourceTypeFilter}',	 @ResourceTypesFilter);
		SET @MDXQuery = REPLACE(@MDXQuery, '${ResourceResourceTypeFilter}',@ResourceResourceTypesFilter);
		SET @MDXQuery = REPLACE(@MDXQuery, '${FacilityFilter}', @FacilityFilter);
		SET @MDXQuery = REPLACE(@MDXQuery, '${AreaFilter}', @AreaFilter);
  SET @MDXQuery = REPLACE(@MDXQuery, '${ShiftFilter}', @ShiftFilter);
		SET @MDXQuery = REPLACE(@MDXQuery, '${ClosureCommas}', @ClosureCommas);
		SET @MDXQuery = REPLACE(@MDXQuery, '${TimeSelectCols}', @TimeSelectCols);			
		SET @MDXQuery = REPLACE(@MDXQuery, '${TimeFilter}', @TimeFilter);
		SET @MDXQuery = REPLACE(@MDXQuery, '${InnerSelection}',	@DataSelect);

		BEGIN TRY
			IF(@PrintScript = 1) 
			BEGIN
				PRINT substring(@MDXQuery, 1, 3000)
				if(len(@MDXQuery) > 3000)
					PRINT substring(@MDXQuery, 3001, len(@MDXQuery));
			END;

			exec sp_executesql @MDXQuery;
		END TRY
		BEGIN CATCH						
			DECLARE @ErrorMessage NVARCHAR(4000);
			DECLARE @ErrorSeverity INT;
			DECLARE @ErrorState INT;

			SELECT  @ErrorMessage = ERROR_MESSAGE(),
					@ErrorSeverity = ERROR_SEVERITY(),
					@ErrorState = ERROR_STATE();

			IF @@TRANCOUNT > 0
				ROLLBACK TRANSACTION;

			PRINT @ErrorMessage;
			select null as [Time], null as [OEE], null as [Availability], null as [Quality], null as [Performance] where 1=0;

		END CATCH;
		
	END
	ELSE
	BEGIN
		DECLARE @Msg nvarchar(512) = 'Missing Linked Server. Assuming no SSAS services were configured.';
		RAISERROR ( @Msg, 0, 1) WITH NOWAIT
	END		
	
END