/**
** Version History

** Version		     Date		      Author		  Description 
** ---------		   ----------  -------		 -----------------------------------------------------------------------------------------------
** Sprint 13     02/07/2021  Paulo S.		New custom procedure based on the P_GetResourcePerformanceStateChange_ODS with the shift filter
*/

CREATE OR ALTER PROCEDURE UserDataModel.P_CustomGetResourcePerformanceStateChange_ODS 
     @TimeFrame NVARCHAR(28), --Day, Week, Month 
     @GetActual BIT, -- 0: yesterday, 1: today                 
     @Resources NVARCHAR(4000), -- One or more Resources split by comma
					@ResourceTypes NVARCHAR(4000), -- One or more resource types (only key will be set)
					@ResourceResourceTypes NVARCHAR(4000), -- One or more resource resource types (only key will be set)
     @ShiftDefinition NVARCHAR(4000), -- Only Works with one ShiftDefinition
	    @ShiftName NVARCHAR(4000), -- Requires the ShiftDefinition to be defined
					@PrintScript BIT = 0

AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @TSQL nvarchar(4000), @LinkedServer nvarchar(4000);
	SET @LinkedServer =  N'cm'+[dbo].[F_GetSystemName]()+N'ASLink';
	declare @ResourceFilter nvarchar(1000), @ClosureCommas nvarchar(10) = ')',
		 @TimeFilter nvarchar(1000), @TimeSelectCols nvarchar(1000), @DecodePreviousDate nvarchar(100),
			@ResourceTypesFilter nvarchar(1000),
			@ResourceResourceTypesFilter nvarchar(1000),
   @ShiftFilter nvarchar(1000);  
    
	BEGIN /* Filters Instantiation */

		IF (len(@Resources) > 0)
		BEGIN
			SET @ResourceFilter = 'FROM ( SELECT ( {[Resource].[Resource Name].&[' + replace(@Resources, ',', '], [Resource].[Resource Name].&[') + '] } ) ON COLUMNS';
			SET @ClosureCommas += ')';
		END
		ELSE
		BEGIN
			SET @ResourceFilter = '';
		END;	

-- resource types
		IF (len(@ResourceTypes) > 0)
		BEGIN
			SET @ResourceTypesFilter = 'FROM ( SELECT ( {[Resource].[Type].&[' + replace(@ResourceTypes, ',', '], [Resource].[Type].&[') + '] } ) ON COLUMNS';
			SET @ClosureCommas += ')';
		END
		ELSE
		BEGIN
			SET @ResourceTypesFilter = '';
		END;

-- resource resource types
		IF (len(@ResourceResourceTypes) > 0)
		BEGIN
			SET @ResourceResourceTypesFilter = 'FROM ( SELECT ( {[Resource].[Resource Type].&[' + replace(@ResourceResourceTypes, ',', '], [Resource].[Resource Type].&[') + '] } ) ON COLUMNS';
			SET @ClosureCommas += ')';
		END
		ELSE
		BEGIN
			SET @ResourceResourceTypesFilter = '';
		END;

  -- Shift filter
		IF (LEN(@ShiftName) > 0 AND LEN(@ShiftDefinition) > 0)
		BEGIN
			SET @ShiftFilter = 'FROM ( SELECT ( {[Shift].[Shift Hierarchy].[Shift Description].&[' + @ShiftDefinition + ' (' + @ShiftDefinition + ' - ' + replace(@ShiftName, ',', ')], [Shift].[Shift Hierarchy].[Shift Description].&[' + @ShiftDefinition + ' (' + @ShiftDefinition + ' - ') + ')] } ) ON COLUMNS';
			SET @ClosureCommas += ')';
		END
		ELSE
		BEGIN
			SET @ShiftFilter = '';
		END;

		IF(@TimeFrame = 'Day')
		BEGIN
-- get actual influences start and end search
			SET @TimeFilter = 
'FROM ( SELECT ( StrToMember(''''[Date].[Calendar Day].[Calendar Day].&['''' + FORMAT(Now(), "yyyy-MM-dd") + '''']'''').Lag('				
						+ case when @GetActual = 0 then '8' else '7' end +')  : StrToMember(''''[Date].[Calendar Day].[Calendar Day].&['''' + FORMAT(Now(), "yyyy-MM-dd") + '''']'''')'+ case when @GetActual = 0 then '.Lag(1)' else '' end +' ) ON COLUMNS';
			SET @TimeSelectCols = '([Resource].[Resource Name].[Resource Name].ALLMEMBERS * [Date].[Calendar Month].[Calendar Month].ALLMEMBERS * [Date].[Calendar Months].[Calendar Year].ALLMEMBERS * [Date].[Calendar Day].[Calendar Day].ALLMEMBERS)'
			SET @DecodePreviousDate = 'convert(date, GETUTCDATE())'
		END
		ELSE IF(@TimeFrame = 'Week')
		BEGIN
-- get actual influences start and end search
			SET @TimeFilter = 
'FROM ( SELECT ( StrToMember(''''[Date].[Calendar Weeks].[Calendar Week].&['				 + Format(datepart(week, getutcdate()), '00')+']&['+Format(datepart(year, getutcdate()), '0000')+']'''').Lag('
						+ case when @GetActual = 0 then '8' else '7' end +')  : StrToMember(''''[Date].[Calendar Weeks].[Calendar Week].&[' + Format(datepart(week, getutcdate()), '00')+']&['+Format(datepart(year, getutcdate()), '0000')+']'''')'+ case when @GetActual = 0 then '.Lag(1)' else '' end +' ) ON COLUMNS';
			SET @TimeSelectCols = '([Resource].[Resource Name].[Resource Name].ALLMEMBERS * [Date].[Calendar Months].[Calendar Year].ALLMEMBERS * [Date].[Calendar Weeks].[Calendar Week].ALLMEMBERS)'
			SET @DecodePreviousDate = 'convert(date, DATEADD(day, - (DATEPART(dw, GETUTCDATE()) + @@DATEFIRST - 2) % 7,GETUTCDATE() ))'
		END
		ELSE IF(@TimeFrame = 'Month')
		BEGIN
-- get actual influences start and end search
			SET @TimeFilter = 
'FROM ( SELECT ( StrToMember(''''[Date].[Calendar Months].[Calendar Month].&['''' + FORMAT(Now(), "\MMM \C\Y yyyy") + '''']'''').Lag('				
						+ case when @GetActual = 0 then '8' else '7' end +')  : StrToMember(''''[Date].[Calendar Months].[Calendar Month].&['''' + FORMAT(Now(), "\MMM \C\Y yyyy") + '''']'''')'+ case when @GetActual = 0 then '.Lag(1)' else '' end +' ) ON COLUMNS';
			SET @TimeSelectCols = '([Resource].[Resource Name].[Resource Name].ALLMEMBERS * [Date].[Calendar Month].[Calendar Month].ALLMEMBERS * [Date].[Calendar Months].[Calendar Year].ALLMEMBERS )'
			SET @DecodePreviousDate = 'CONVERT(date,dateadd(day,1,dateadd(d,-(day(GETUTCDATE())),GETUTCDATE())))'
		END;
	END;
	
	IF (exists(select * from sys.servers where name = @LinkedServer))
	BEGIN	

		declare @MDXQuery nvarchar(4000) = '
			SELECT  NON EMPTY { [Measures].[Total Time] } ON COLUMNS
				  , NON EMPTY { ([Date].[Calendar Day].[Calendar Day].ALLMEMBERS * [Resource].[Resource Name].[Resource Name].ALLMEMBERS * [Time].[Time].[Time24].ALLMEMBERS * [Resource State Model].[State Model Value].[State Model Value].ALLMEMBERS ) } ON ROWS  
				  ${ResourceFilter}	
				  ${ResourceTypeFilter}
				  ${ResourceResourceTypeFilter}
      ${ShiftFilter}
				  ${TimeFilter}	  
				  FROM [Resource] ${ClosureCommas}'')';
		
		SET @MDXQuery = 'select dat2.ResourceName, ISNULL(lag(dat2.dateend) over (partition by dat2.ResourceName, IsTransition order by dat2.datestart), dat2.firstVal) as [Start], ISNULL(dat2.dateend, ' +
		case when @GetActual = 1 then 'getutcdate()' else @DecodePreviousDate end +') as [End], dat2.[State]
			from 
			(
				select dat.*, lead(dat.datestart) over (partition by dat.ResourceName  order by dat.datestart, rnum) as dateend, lead(dat.[State]) over (partition by dat.ResourceName  order by dat.datestart, rnum) as NextState,
					case when lead(dat.[State]) over (partition by dat.ResourceName  order by dat.datestart, rnum) != dat.[State] 
						or row_number() over (partition by dat.ResourceName  order by dat.datestart desc, rnum desc) = 1
					then 1 else 0 end IsTransition,
					FIRST_VALUE(dat.datestart) over (partition by dat.ResourceName order by dat.datestart, rnum) firstVal,
					row_number() over (partition by dat.ResourceName order by dat.datestart desc, rnum desc) LastR
				from (select *,
					row_number() over (partition by i.ResourceName order by dateadd(MILLISECOND, i.Duration, i.datestart)) rnum
				from (
					select 
						dbo.F_ConvertTimeToUtc(convert(datetime, convert(nvarchar(100),"[Date].[Calendar Day].[Calendar Day].[MEMBER_CAPTION]") + '' '' + convert(nvarchar(100),"[Time].[Time].[Time24].[MEMBER_CAPTION]"), 120)) datestart,
						convert(nvarchar(100),"[Resource State Model].[State Model Value].[State Model Value].[MEMBER_CAPTION]") [State],
						convert(nvarchar(256),"[Resource].[Resource Name].[Resource Name].[MEMBER_CAPTION]") [ResourceName],
						convert(bigint, "[Measures].[Total Time]") as [Duration]  FROM OPENQUERY('+ @LinkedServer + ',''' + @MDXQuery + ')  i) dat	
			) DAT2
			WHERE DAT2.IsTransition = 1
			order by dat2.ResourceName, dat2.datestart';

		SET @MDXQuery = REPLACE(@MDXQuery, '${TimeSelectCols}', @TimeSelectCols);			
		SET @MDXQuery = REPLACE(@MDXQuery, '${TimeFilter}', @TimeFilter);		
		SET @MDXQuery = REPLACE(@MDXQuery, '${ResourceFilter}', @ResourceFilter);
		SET @MDXQuery = REPLACE(@MDXQuery, '${ResourceTypeFilter}',	 @ResourceTypesFilter);
		SET @MDXQuery = REPLACE(@MDXQuery, '${ResourceResourceTypeFilter}',@ResourceResourceTypesFilter);
  SET @MDXQuery = REPLACE(@MDXQuery, '${ShiftFilter}', @ShiftFilter);
		SET @MDXQuery = REPLACE(@MDXQuery, '${ClosureCommas}', @ClosureCommas);

		BEGIN TRY
			IF(@PrintScript = 1) 
			BEGIN
				PRINT substring(@MDXQuery, 1, 3000)
				if(len(@MDXQuery) > 3000)
					PRINT substring(@MDXQuery, 3001, len(@MDXQuery));
			END;

			exec sp_executesql @MDXQuery;	
		END TRY
		BEGIN CATCH						
			DECLARE @ErrorMessage NVARCHAR(4000);
			DECLARE @ErrorSeverity INT;
			DECLARE @ErrorState INT;

			SELECT  @ErrorMessage = ERROR_MESSAGE(),
					@ErrorSeverity = ERROR_SEVERITY(),
					@ErrorState = ERROR_STATE();

			IF @@TRANCOUNT > 0
				ROLLBACK TRANSACTION;

			PRINT @ErrorMessage;
			select null as ResourceName, null as [Start], null as [End], null as [State] where 1=0;

		END CATCH;
	END
	ELSE
	BEGIN
		DECLARE @Msg nvarchar(512) = 'Missing Linked Server. Assuming no SSAS services were configured.';
		RAISERROR ( @Msg, 0, 1) WITH NOWAIT
	END		
END

