/**
** Version History

** Version		     Date		      Author		  Description 
** ---------		   ----------  -------		 ------------------------------------------------------------------------------------------------------
** Sprint 13     02/07/2021  Paulo S.		New custom procedure based on the P_GetResourcePerformanceStateChangeSummary_ODS with the shift filter
*/

CREATE OR ALTER PROCEDURE UserDataModel.P_CustomGetResourcePerformanceStateChangeSummary_ODS 
     @TimeFrame NVARCHAR(28), --Day, Week, Month 
     @GetActual BIT, -- 0: yesterday, 1: today                 
     @Resources NVARCHAR(4000),-- One or more Resources split by comma
					@ResourceTypes NVARCHAR(4000), -- One or more resource types (only key will be set)
					@ResourceResourceTypes NVARCHAR(4000), -- One or more resource resource types (only key will be set)
     @ShiftDefinition NVARCHAR(4000), -- Only Works with one ShiftDefinition
	    @ShiftName NVARCHAR(4000), -- Requires the ShiftDefinition to be defined
					@TimeScale INT = 1, --enum TimeScale{0 - Days; 1 - Hours; 2 - Minutes; 3 - Seconds}
					@ShowDecimals BIT=1, -- 0: round to 0, 1: round to 1 decimal digits
					@PrintScript BIT=0

AS
BEGIN
	SET NOCOUNT ON;

	DECLARE @TSQL nvarchar(4000), @LinkedServer nvarchar(4000);
	SET @LinkedServer =  N'cm'+[dbo].[F_GetSystemName]()+N'ASLink';
	declare @ResourceFilter nvarchar(1000), @ClosureCommas nvarchar(10) = ')',
		    @TimeFilter nvarchar(1000), @TimeSelectCols nvarchar(1000),
			   @ResourceTypesFilter nvarchar(1000),
		   	@ResourceResourceTypesFilter nvarchar(1000),
			   @TimeScaleFilter nvarchar(1000),
      @ShiftFilter nvarchar(1000);  

	BEGIN /* Filters Instantiation */
		IF (len(@Resources) > 0)
		BEGIN
			SET @ResourceFilter = 'FROM ( SELECT ( {[Resource].[Resource Name].&[' + replace(@Resources, ',', '], [Resource].[Resource Name].&[') + '] } ) ON COLUMNS';
			SET @ClosureCommas += ')';
		END
		ELSE
		BEGIN
			SET @ResourceFilter = '';
		END;

-- resource types
		IF (len(@ResourceTypes) > 0)
		BEGIN
			SET @ResourceTypesFilter = 'FROM ( SELECT ( {[Resource].[Type].&[' + replace(@ResourceTypes, ',', '], [Resource].[Type].&[') + '] } ) ON COLUMNS';
			SET @ClosureCommas += ')';
		END
		ELSE
		BEGIN
			SET @ResourceTypesFilter = '';
		END;

-- resource resource types
		IF (len(@ResourceResourceTypes) > 0)
		BEGIN
			SET @ResourceResourceTypesFilter = 'FROM ( SELECT ( {[Resource].[Resource Type].&[' + replace(@ResourceResourceTypes, ',', '], [Resource].[Resource Type].&[') + '] } ) ON COLUMNS';
			SET @ClosureCommas += ')';
		END
		ELSE
		BEGIN
			SET @ResourceResourceTypesFilter = '';
		END;

  -- Shift filter
		IF (LEN(@ShiftName) > 0 AND LEN(@ShiftDefinition) > 0)
		BEGIN
			SET @ShiftFilter = 'FROM ( SELECT ( {[Shift].[Shift Hierarchy].[Shift Description].&[' + @ShiftDefinition + ' (' + @ShiftDefinition + ' - ' + replace(@ShiftName, ',', ')], [Shift].[Shift Hierarchy].[Shift Description].&[' + @ShiftDefinition + ' (' + @ShiftDefinition + ' - ') + ')] } ) ON COLUMNS';
			SET @ClosureCommas += ')';
		END
		ELSE
		BEGIN
			SET @ShiftFilter = '';
		END;


-- time scale filter to return to the widget in:
--enum TimeScale{0 - Days; 1 - Hours; 2 - Minutes; 3 - Seconds}
		SET @TimeScaleFilter = case when @TimeScale = 0 then ' / 60.0 / 60.0 / 24.0 '
									when @TimeScale  = 1 then ' / 60.0 / 60.0  '
									when @TimeScale  = 2 then ' / 60.0  ' 
									else '' end;

		IF(@TimeFrame = 'Day')
		BEGIN
-- get actual influences start and end search
			SET @TimeFilter = 
'FROM ( SELECT ( StrToMember(''''[Date].[Calendar Day].[Calendar Day].&['''' + FORMAT(Now(), "yyyy-MM-dd") + '''']'''').Lag('				
						+ case when @GetActual = 0 then '8' else '7' end +')  : StrToMember(''''[Date].[Calendar Day].[Calendar Day].&['''' + FORMAT(Now(), "yyyy-MM-dd") + '''']'''')'+ case when @GetActual = 0 then '.Lag(1)' else '' end +' ) ON COLUMNS';
			SET @TimeSelectCols = '([Date].[Calendar Month].[Calendar Month].ALLMEMBERS * [Date].[Calendar Months].[Calendar Year].ALLMEMBERS * [Date].[Calendar Day].[Calendar Day].ALLMEMBERS)'
		END
		ELSE IF(@TimeFrame = 'Week')
		BEGIN
-- get actual influences start and end search
			SET @TimeFilter = 
'FROM ( SELECT ( StrToMember(''''[Date].[Calendar Weeks].[Calendar Week].&['				 + Format(datepart(week, getutcdate()), '00')+']&['+Format(datepart(year, getutcdate()), '0000')+']'''').Lag('
						+ case when @GetActual = 0 then '8' else '7' end +')  : StrToMember(''''[Date].[Calendar Weeks].[Calendar Week].&[' + Format(datepart(week, getutcdate()), '00')+']&['+Format(datepart(year, getutcdate()), '0000')+']'''')'+ case when @GetActual = 0 then '.Lag(1)' else '' end +' ) ON COLUMNS';
			SET @TimeSelectCols = '([Date].[Calendar Months].[Calendar Year].ALLMEMBERS * [Date].[Calendar Weeks].[Calendar Week].ALLMEMBERS)'
			
		END
		ELSE IF(@TimeFrame = 'Month')
		BEGIN
-- get actual influences start and end search
			SET @TimeFilter = 
'FROM ( SELECT ( StrToMember(''''[Date].[Calendar Months].[Calendar Month].&['''' + FORMAT(Now(), "\MMM \C\Y yyyy") + '''']'''').Lag('				
						+ case when @GetActual = 0 then '8' else '7' end +')  : StrToMember(''''[Date].[Calendar Months].[Calendar Month].&['''' + FORMAT(Now(), "\MMM \C\Y yyyy") + '''']'''')'+ case when @GetActual = 0 then '.Lag(1)' else '' end +' ) ON COLUMNS';
			SET @TimeSelectCols = '([Date].[Calendar Month].[Calendar Month].ALLMEMBERS * [Date].[Calendar Months].[Calendar Year].ALLMEMBERS )'
		END;
	END;	

	IF (exists(select * from sys.servers where name = @LinkedServer))
	BEGIN	
		
		declare @MDXQuery nvarchar(4000) = '
			WITH MEMBER [Measures].[Total_Time] AS ''''Round([Measures].[Total Time] ${TimeScale}, ${ShowDecimals})''''
				  member [Measures].[Ratio] as  ''''Round(([Measures].[Total Time]/([Resource State Model].[State Model Value].CurrentMember.Parent, [Measures].[Total Time] ))*100, ${ShowDecimals})''''
				  member [Measures].[Total] as  ''''IIF(IsEmpty([Measures].[Total Time]) ,NULL ,Round((([Resource State Model].[State Model Value].CurrentMember.Parent, [Measures].[Total Time] ) ${TimeScale}), ${ShowDecimals}))''''
			SELECT NON EMPTY { [Measures].[Total_Time], [Measures].[Ratio], [Measures].[Total] } ON COLUMNS
				 , NON EMPTY { except([Resource State Model].[State Model Value].[State Model Value].ALLMEMBERS, { [Resource State Model].[State Model Value].&[-], [Resource State Model].[State Model Value].[All].UNKNOWNMEMBER }) } ON ROWS  
				  ${ResourceFilter}
				  ${ResourceTypeFilter}
				  ${ResourceResourceTypeFilter}
      ${ShiftFilter}
				  ${TimeFilter}	  
				  FROM [Resource] ${ClosureCommas}'')';

		SET @MDXQuery = ';with ASData as 
						(
							select convert(nvarchar(256), "[Resource State Model].[State Model Value].[State Model Value].[MEMBER_CAPTION]") as [State]
							, convert(decimal(18,2), ROUND(convert(decimal(18,8), "[Measures].[Total_Time]"), ${ShowDecimals})) as [Duration]
							, convert(decimal(18,2), ROUND(convert(decimal(18,8), "[Measures].[Ratio]"), ${ShowDecimals})) [Ratio]
							, convert(decimal(18,2), ROUND(convert(decimal(18,8), "[Measures].[Total]"), ${ShowDecimals})) [Total]
							FROM OPENQUERY('+ @LinkedServer + ','''	+ @MDXQuery + ')
		select [State], [Duration], [Ratio] from ASData
		union all
		select ''Total'' as [State], MAX([Total]) as [Duration], 100 as [Ratio]
		from ASDATA';

		SET @MDXQuery = REPLACE(@MDXQuery, '${ShowDecimals}', case when @ShowDecimals = 0 then '0' else '1' end);
		SET @MDXQuery = REPLACE(@MDXQuery, '${ResourceFilter}', @ResourceFilter);
		SET @MDXQuery = REPLACE(@MDXQuery, '${ResourceTypeFilter}',	 @ResourceTypesFilter);
		SET @MDXQuery = REPLACE(@MDXQuery, '${ResourceResourceTypeFilter}',@ResourceResourceTypesFilter);
  SET @MDXQuery = REPLACE(@MDXQuery, '${ShiftFilter}', @ShiftFilter);
		SET @MDXQuery = REPLACE(@MDXQuery, '${ClosureCommas}', @ClosureCommas);
		SET @MDXQuery = REPLACE(@MDXQuery, '${TimeSelectCols}', @TimeSelectCols);			
		SET @MDXQuery = REPLACE(@MDXQuery, '${TimeFilter}', @TimeFilter);
		SET @MDXQuery = REPLACE(@MDXQuery, '${TimeScale}', @TimeScaleFilter);
		
		BEGIN TRY
			IF(@PrintScript = 1) 
			BEGIN
				PRINT substring(@MDXQuery, 1, 3000)
				if(len(@MDXQuery) > 3000)
					PRINT substring(@MDXQuery, 3001, len(@MDXQuery));
			END;

			exec sp_executesql @MDXQuery;
		END TRY
		BEGIN CATCH						
			DECLARE @ErrorMessage NVARCHAR(4000);
			DECLARE @ErrorSeverity INT;
			DECLARE @ErrorState INT;

			SELECT  @ErrorMessage = ERROR_MESSAGE(),
					@ErrorSeverity = ERROR_SEVERITY(),
					@ErrorState = ERROR_STATE();

			IF @@TRANCOUNT > 0
				ROLLBACK TRANSACTION;

			PRINT @ErrorMessage;
			select null as [State], null as Duration, null as Ratio where 1=0;

		END CATCH;
	END
	ELSE
	BEGIN
		DECLARE @Msg nvarchar(512) = 'Missing Linked Server. Assuming no SSAS services were configured.';
		RAISERROR ( @Msg, 0, 1) WITH NOWAIT
	END		
END

