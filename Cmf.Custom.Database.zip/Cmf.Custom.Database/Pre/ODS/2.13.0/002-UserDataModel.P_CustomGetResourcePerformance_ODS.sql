/**
** Version History

** Version		     Date		      Author		  Description 
** ---------		   ----------  -------		 -----------------------------------------------------------------------------------
** Sprint 13     02/07/2021  Paulo S.		New custom procedure based on the GetResourcePerformance_ODS with the shift filter
*/

CREATE OR ALTER PROCEDURE UserDataModel.P_CustomGetResourcePerformance_ODS 
     @TimeFrame NVARCHAR(28), --Day, Week, Month 
     @GetActual BIT, -- 0: yesterday, 1: today
					@ShowDecimals BIT, -- 0: round to 0 or 1 decimal digits                   
     @Resources NVARCHAR(4000),-- One or more Resources split by comma
					@ResourceTypes NVARCHAR(4000), -- One or more resource types (only key will be set)
					@ResourceResourceTypes NVARCHAR(4000), -- One or more resource resource types (only key will be set)
     @ShiftDefinition NVARCHAR(4000), -- Only Works with one ShiftDefinition
	    @ShiftName NVARCHAR(4000), -- Requires the ShiftDefinition to be defined
					@PrintScript BIT=0
AS
BEGIN
	SET NOCOUNT ON;

	declare @ResultSet as table 
	(
		[Time] int,
	 [Year] nvarchar(100),
		[Month] nvarchar(100),
		[Day] nvarchar(100),
		[Week] nvarchar(100),
		[ResourceName] nvarchar(100),
		[Uptime] decimal(18,1),
		[Downtime] decimal(18,1),
		[NonScheduledTime] decimal(18,1),
		[MTBF] decimal(18,1),
		[MTTR] decimal(18,1)
	)
	DECLARE @LinkedServer nvarchar(4000);
	SET @LinkedServer =  N'cm'+[dbo].[F_GetSystemName]()+N'ASLink';
	declare @ResourceFilter nvarchar(1000), @ClosureCommas nvarchar(10) = ')',
		 @TimeFilter nvarchar(1000), @TimeSelectCols nvarchar(1000),
			@DataSelect nvarchar(1000),
			@ResourceTypesFilter nvarchar(1000),
			@ResourceResourceTypesFilter nvarchar(1000),
   @ShiftFilter nvarchar(1000); 
    
	BEGIN /* Filters Instantiation */
		IF (len(@Resources) > 0)
		BEGIN
			SET @ResourceFilter = 'FROM ( SELECT ( {[Resource].[Resource Name].&[' + replace(@Resources, ',', '], [Resource].[Resource Name].&[') + '] } ) ON COLUMNS';
			SET @ClosureCommas += ')';
		END
		ELSE
		BEGIN
			SET @ResourceFilter = '';
		END;

-- resource types
		IF (len(@ResourceTypes) > 0)
		BEGIN
			SET @ResourceTypesFilter = 'FROM ( SELECT ( {[Resource].[Type].&[' + replace(@ResourceTypes, ',', '], [Resource].[Type].&[') + '] } ) ON COLUMNS';
			SET @ClosureCommas += ')';
		END
		ELSE
		BEGIN
			SET @ResourceTypesFilter = '';
		END;

-- resource resource types
		IF (len(@ResourceResourceTypes) > 0)
		BEGIN
			SET @ResourceResourceTypesFilter = 'FROM ( SELECT ( {[Resource].[Resource Type].&[' + replace(@ResourceResourceTypes, ',', '], [Resource].[Resource Type].&[') + '] } ) ON COLUMNS';
			SET @ClosureCommas += ')';
		END
		ELSE
		BEGIN
			SET @ResourceResourceTypesFilter = '';
		END;

  -- Shift filter
		IF (LEN(@ShiftName) > 0 AND LEN(@ShiftDefinition) > 0)
		BEGIN
			SET @ShiftFilter = 'FROM ( SELECT ( {[Shift].[Shift Hierarchy].[Shift Description].&[' + @ShiftDefinition + ' (' + @ShiftDefinition + ' - ' + replace(@ShiftName, ',', ')], [Shift].[Shift Hierarchy].[Shift Description].&[' + @ShiftDefinition + ' (' + @ShiftDefinition + ' - ') + ')] } ) ON COLUMNS';
			SET @ClosureCommas += ')';
		END
		ELSE
		BEGIN
			SET @ShiftFilter = '';
		END;

		IF(@TimeFrame = 'Day')
		BEGIN
-- get actual influences start and end search
			SET @TimeFilter = 
'FROM ( SELECT ( StrToMember(''''[Date].[Calendar Day].[Calendar Day].&['''' + FORMAT(Now(), "yyyy-MM-dd") + '''']'''').Lag('				
						+ case when @GetActual = 0 then '8' else '7' end +')  : StrToMember(''''[Date].[Calendar Day].[Calendar Day].&['''' + FORMAT(Now(), "yyyy-MM-dd") + '''']'''')'+ case when @GetActual = 0 then '.Lag(1)' else '' end +' ) ON COLUMNS';
			SET @TimeSelectCols = '([Date].[Calendar Month].[Calendar Month].ALLMEMBERS * [Date].[Calendar Months].[Calendar Year].ALLMEMBERS * [Date].[Calendar Day].[Calendar Day].ALLMEMBERS)'

			SET @DataSelect = 'select 1 - row_number() over (order by [Year] desc, [Month] desc, [Day] desc) as [time]
					, dat.[Year]
					, dat.[Month]
					, dat.[Day]
					, dat.[Up_Time]
					, dat.[Down_Time]
					, dat.[Non_Scheduled_Time]
					, dat.[MTTR]
					, dat.[MTBF]		  
			from (
				SELECT convert(nvarchar(100),"[Date].[Calendar Month].[Calendar Month].[MEMBER_CAPTION]") as [Month]
					,convert(nvarchar(100),"[Date].[Calendar Months].[Calendar Year].[MEMBER_CAPTION]") as [Year]
					,convert(nvarchar(100),"[Date].[Calendar Day].[Calendar Day].[MEMBER_CAPTION]") as [Day]
					,"[Measures].[Up_Time]" as [Up_Time]
					,"[Measures].[Down_Time]" as [Down_Time]
					,"[Measures].[Non_Scheduled_Time]" as [Non_Scheduled_Time]
					,"[Measures].[MTTR(h)]" as [MTTR]
					,"[Measures].[MTBF(h)]" as [MTBF]'				

		END
		ELSE IF(@TimeFrame = 'Week')
		BEGIN
-- get actual influences start and end search
			SET @TimeFilter = 
'FROM ( SELECT ( StrToMember(''''[Date].[Calendar Weeks].[Calendar Week].&['				 + Format(datepart(week, getutcdate()), '00')+']&['+Format(datepart(year, getutcdate()), '0000')+']'''').Lag('
						+ case when @GetActual = 0 then '8' else '7' end +')  : StrToMember(''''[Date].[Calendar Weeks].[Calendar Week].&[' + Format(datepart(week, getutcdate()), '00')+']&['+Format(datepart(year, getutcdate()), '0000')+']'''')'+ case when @GetActual = 0 then '.Lag(1)' else '' end +' ) ON COLUMNS';
			SET @TimeSelectCols = '([Date].[Calendar Months].[Calendar Year].ALLMEMBERS * [Date].[Calendar Weeks].[Calendar Week].ALLMEMBERS)'

			SET @DataSelect = 'select 1 - row_number() over (order by [Year] desc, [Week] desc) as [time]
					, dat.[Year]
					, dat.[Week]
					, dat.[Up_Time]
					, dat.[Down_Time]
					, dat.[Non_Scheduled_Time]
					, dat.[MTTR]
					, dat.[MTBF]		  
			from (
				SELECT convert(nvarchar(100),"[Date].[Calendar Weeks].[Calendar Week].[MEMBER_CAPTION]") as [Week]
					,convert(nvarchar(100),"[Date].[Calendar Weeks].[Calendar Year].[MEMBER_CAPTION]") as [Year]
					,"[Measures].[Up_Time]" as [Up_Time]
					,"[Measures].[Down_Time]" as [Down_Time]
					,"[Measures].[Non_Scheduled_Time]" as [Non_Scheduled_Time]
					,"[Measures].[MTTR(h)]" as [MTTR]
					,"[Measures].[MTBF(h)]" as [MTBF]'

		END
		ELSE IF(@TimeFrame = 'Month')
		BEGIN
-- get actual influences start and end search
			SET @TimeFilter = 
'FROM ( SELECT ( StrToMember(''''[Date].[Calendar Months].[Calendar Month].&['''' + FORMAT(Now(), "\MMM \C\Y yyyy") + '''']'''').Lag('				
						+ case when @GetActual = 0 then '8' else '7' end +')  : StrToMember(''''[Date].[Calendar Months].[Calendar Month].&['''' + FORMAT(Now(), "\MMM \C\Y yyyy") + '''']'''')'+ case when @GetActual = 0 then '.Lag(1)' else '' end +' ) ON COLUMNS';
			SET @TimeSelectCols = '([Date].[Calendar Month].[Calendar Month].ALLMEMBERS * [Date].[Calendar Months].[Calendar Year].ALLMEMBERS )'

			SET @DataSelect = 'select 1 - row_number() over (order by [Year] desc, [Month] desc) as [time]
					, dat.[Year]
					, dat.[Month]
					, dat.[Up_Time]
					, dat.[Down_Time]
					, dat.[Non_Scheduled_Time]
					, dat.[MTTR]
					, dat.[MTBF]		  
			from (
				SELECT convert(nvarchar(100),"[Date].[Calendar Month].[Calendar Month].[MEMBER_CAPTION]") as [Month]
					,convert(nvarchar(100),"[Date].[Calendar Months].[Calendar Year].[MEMBER_CAPTION]") as [Year]
					,"[Measures].[Up_Time]" as [Up_Time]
					,"[Measures].[Down_Time]" as [Down_Time]
					,"[Measures].[Non_Scheduled_Time]" as [Non_Scheduled_Time]
					,"[Measures].[MTTR(h)]" as [MTTR]
					,"[Measures].[MTBF(h)]" as [MTBF]'
		
		END;
	END;

	IF (exists(select * from sys.servers where name = @LinkedServer))
	BEGIN
		BEGIN TRY
			declare @MDXQuery nvarchar(4000) = '
			select r.[Time], ISNULL([Up_time], 0) as [Uptime], ISNULL([Down_time], 0) as [Downtime], ISNULL([Non_Scheduled_Time], 0) as [NonScheduledTime], ISNULL([MTBF], 0) as [MTBF], ISNULL([MTTR], 0) as [MTTR] 
			FROM (
				${InnerSelection} 
			FROM OPENQUERY('+ @LinkedServer + N',''
			WITH MEMBER [Measures].[Up_Time] AS ''''Round([Measures].[Up Time (%)]*100,${ShowDecimals})''''
				 MEMBER [Measures].[Down_Time] AS ''''Round([Measures].[Down Time (%)]*100,${ShowDecimals})''''
				 MEMBER [Measures].[Non_Scheduled_Time] AS ''''Round([Measures].[Non Scheduled Time (%)]*100,${ShowDecimals})''''
				 MEMBER [Measures].[MTTR(h)] AS ''''Round([Measures].[MTTR]/3600.0,${ShowDecimals})''''
				 MEMBER [Measures].[MTBF(h)] AS ''''Round([Measures].[MTBF]/3600.0,${ShowDecimals})''''

				SELECT  { [Measures].[Up_Time], [Measures].[Down_Time], [Measures].[Non_Scheduled_Time], [Measures].[MTTR(h)] , [Measures].[MTBF(h)] } ON COLUMNS
					  , { ${TimeSelectCols} }  ON ROWS 
				  ${ResourceFilter}
				  ${ResourceTypeFilter}
				  ${ResourceResourceTypeFilter}		
      ${ShiftFilter}
				  ${TimeFilter}	  
				  FROM [Resource] ${ClosureCommas}'') idat ) dat
					) r';

			SET @MDXQuery = REPLACE(@MDXQuery, '${ShowDecimals}', convert(char(1), @ShowDecimals));
			SET @MDXQuery = REPLACE(@MDXQuery, '${ResourceFilter}', @ResourceFilter);
			SET @MDXQuery = REPLACE(@MDXQuery, '${ResourceTypeFilter}',	 @ResourceTypesFilter);
			SET @MDXQuery = REPLACE(@MDXQuery, '${ResourceResourceTypeFilter}',@ResourceResourceTypesFilter);
   SET @MDXQuery = REPLACE(@MDXQuery, '${ShiftFilter}', @ShiftFilter);
			SET @MDXQuery = REPLACE(@MDXQuery, '${ClosureCommas}', @ClosureCommas);
			SET @MDXQuery = REPLACE(@MDXQuery, '${TimeSelectCols}', @TimeSelectCols);			
			SET @MDXQuery = REPLACE(@MDXQuery, '${TimeFilter}', @TimeFilter);
			SET @MDXQuery = REPLACE(@MDXQuery, '${InnerSelection}',	@DataSelect);

			IF(@PrintScript = 1) 
			BEGIN
				PRINT substring(@MDXQuery, 1, 3000)
				if(len(@MDXQuery) > 3000)
					PRINT substring(@MDXQuery, 3001, len(@MDXQuery));
			END;

			exec sp_executesql @MDXQuery;		
		END TRY
		BEGIN CATCH						
			DECLARE @ErrorMessage NVARCHAR(4000);
			DECLARE @ErrorSeverity INT;
			DECLARE @ErrorState INT;

			SELECT  @ErrorMessage = ERROR_MESSAGE(),
					@ErrorSeverity = ERROR_SEVERITY(),
					@ErrorState = ERROR_STATE();

			IF @@TRANCOUNT > 0
				ROLLBACK TRANSACTION;

			PRINT @ErrorMessage;

			select [Time], [Uptime], [Downtime], [NonScheduledTime], [MTBF], [MTTR]  from @ResultSet where 1=0;

		END CATCH
		
	END
	ELSE
	BEGIN
		DECLARE @Msg nvarchar(512) = 'Missing Linked Server. Assuming no SSAS services were configured.';
		RAISERROR ( @Msg, 0, 1) WITH NOWAIT
	END	
	
END
GO
