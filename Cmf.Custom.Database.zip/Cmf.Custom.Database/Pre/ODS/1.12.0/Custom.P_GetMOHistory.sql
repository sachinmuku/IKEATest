
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = 'Custom')
BEGIN
EXEC('CREATE SCHEMA Custom')
END
GO

IF EXISTS ( SELECT * 
            FROM   sysobjects 
            WHERE  id = object_id(N'[Custom].[P_GetMOHistory]') 
                   and OBJECTPROPERTY(id, N'IsProcedure') = 1 )
BEGIN
    DROP PROCEDURE [Custom].[P_GetMOHistory]
END
GO


CREATE PROCEDURE [Custom].[P_GetMOHistory]
              @Start datetime = null,
              @End datetime = null,  
              @FacilityName nvarchar(max) = null,
              @AreaName nvarchar(max) = null,
              @StepName nvarchar(max) = null,
              @ResourceName nvarchar(max) = null,
              @OrderStatus nvarchar(max) = null,
              @MaterialName nvarchar(max) = null

as


set nocount on;


/* declare vars */
declare @fst_srvhistory_id bigint = null
declare @lst_srvhistory_id bigint = null
declare @ordermaterialform nvarchar(30)
declare @StartDate datetime = dbo.F_TimeLocalTimeToUTC(@Start);
declare @FinalDate datetime = dateadd(day, 1, dbo.F_TimeLocalTimeToUTC(@End));


/* Create temporary tables. They should not exist, but just in case drop them if they do.. */
if(object_id('tempdb..#ordersystemstates') is not null) drop table #ordersystemstates
if(object_id('tempdb..#allowedservices') is not null) drop table #allowedservices
if(object_id('tempdb..#FacilityTempTable') is not null) drop table #FacilityTempTable
if(object_id('tempdb..#AreaTempTable') is not null) drop table #AreaTempTable
if(object_id('tempdb..#StepTempTable') is not null) drop table #StepTempTable
if(object_id('tempdb..#ResourceTempTable') is not null) drop table #ResourceTempTable
if(object_id('tempdb..#OrderStatusTempTable') is not null) drop table #OrderStatusTempTable
if(object_id('tempdb..#materialservices') is not null) drop table #materialservices
if(object_id('tempdb..#actions') is not null) drop table #actions
if(object_id('tempdb..#mogeneratedmaterials') is not null) drop table #mogeneratedmaterials

create table #ordersystemstates (systemstate int, Name nvarchar(512), status nvarchar(512))
create table #allowedservices (service_id bigint, Name nvarchar(512))
create table #FacilityTempTable (Name nvarchar(512))
create table #StepTempTable (Name nvarchar(512))
create table #ResourceTempTable (Name nvarchar(512))
create table #OrderStatusTempTable (Name nvarchar(512))

create table #materialservices (MaterialId bigint
                              ,Name nvarchar(512)
                              ,ServiceName nvarchar(512)
                              ,ServiceHistoryId bigint
                              ,ServiceStartTime datetime
                              ,ProductionOrderId bigint
                              ,FirstSIDOpSeq int
                              ,LastSIDOpSeq int)

create table #actions(MaterialId bigint
                    ,Name nvarchar(512)
                    ,ProductionOrderId bigint
                    ,Start_ServiceHistoryId bigint
                    ,End_ServiceHistoryId bigint
                    ,Start_FirstOperationSeq int
                    ,Start_LastOperationSeq int
                    ,End_FirstOperationSeq int
                    ,End_LastOperationSeq int
                    ,c1ServiceName nvarchar(512)
                    ,c2ServiceName nvarchar(512)
                    ,Start_ServiceDate datetime
                    ,End_ServiceDate datetime)

create table #mogeneratedmaterials(MOId bigint
                                  ,MaterialId bigint
                                  ,Start_ServiceHistoryId bigint
                                  ,Pallet_MaterialName nvarchar(512)
                                  ,pallet_primary_quantity decimal
                                  ,ModifiedOn datetime)





/* Set data for production order system states */
insert into #ordersystemstates
values
(0, 'Created', 'Open'),
(1, 'Released', 'Open'),
(2, 'InProgress', 'Open'),
(3, 'Completed', 'Closed'),
(4, 'Closed', 'Closed'),
(5, 'Canceled', 'Closed')


/* Temp Table with Facilities */
if(@FacilityName is not null)
begin
  insert into #FacilityTempTable 
  select [Value] from [dbo].[F_Split2](@FacilityName, ';');
end

/* Temp Table with Steps */
if(@StepName is not null)
begin
  insert into #StepTempTable
  select [Value] from [dbo].[F_Split2](@StepName, ';');
end

/* Temp Table with Resources */
if(@ResourceName is not null)
begin
  insert into #ResourceTempTable
  select [Value] from [dbo].[F_Split2](@ResourceName, ';');
end

/* Temp Table with OrderStatus */
if(@OrderStatus is not null)
begin
	insert into #OrderStatusTempTable
	select [Value] from [dbo].[F_Split2](@OrderStatus, ';');
end


/* Set data for selected services IDs */
insert into #allowedservices
select ServiceId, Name from Security.T_Service
where name IN ('ComplexDispatchAndTrackInMaterials', 
              'ComplexDispatchAndTrackInMaterial',
              'ComplexTrackInMaterials',
              'ComplexTrackInMaterial',
              'ComplexTrackOutMaterials', 
              'ComplexTrackOutMaterial',
              'AbortMaterialsProcess',
              'AbortMaterialProcess',
              'TerminateMaterial')


/* Gets default material Form from Configuration */
select @ordermaterialform = [dbo].[F_GetConfigStringValue](N'/Cmf/Custom/MaterialTracking/OrderMaterialForm/', N'MO')


/* If MOs are supplied in a string, Resolve material IDs and et Date interval */
if(@MaterialName is not null)
begin    
  select @StartDate = min(mh.ModifiedOn), @FinalDate = max(mh.ModifiedOn)
  from CoreDataModel.T_materialhistory mh
  where mh.Name like (@MaterialName + '%')
end


/* Get first and last service history ids by date */
set @fst_srvhistory_id = [dbo].[F_Part_GetMinServiceHistoryIdForDate](dateadd(day, -1, @StartDate))
set @lst_srvhistory_id = [dbo].[F_Part_GetMaxServiceHistoryIdForDate](dateadd(day, 1, @FinalDate))

/* Get material events and mark them with start and end service id. */
insert into #materialservices
select SRC.MaterialId
      ,SRC.Name
      ,SRC.ServiceName
      ,SRC.ServiceHistoryId
      ,SRC.ServiceStartTime
      ,max(SRC.ProductionOrderId) as ProductionOrderId
      ,min(FirstSIDOpSeq) FirstSIDOpSeq
      ,max(LastSIDOpSeq) LastSIDOpSeq
from
(
select mh.MaterialId
      ,mh.Name
      ,sh.ServiceName
      ,sh.ServiceHistoryId
      ,sh.ServiceStartTime
      ,mh.ProductionOrderId 
      ,first_value(mh.OperationHistorySeq) OVER(PARTITION BY Mh.MaterialId, sh.ServiceHistoryId ORDER by mh.ModifiedON ASC, mh.OperationHistorySeq ASC) FirstSIDOpSeq
      ,last_value(mh.OperationHistorySeq) OVER(PARTITION BY Mh.MaterialId, sh.ServiceHistoryId ORDER by mh.ModifiedON ASC, mh.OperationHistorySeq ASC) LastSIDOpSeq
      ,first_value(mh.ServiceHistoryId) OVER(PARTITION BY Mh.MaterialId, sh.ServiceName ORDER by mh.ModifiedON desc) LastTrackoutServiceId
from CoreDataModel.T_MaterialHistory mh 
inner join dbo.T_ServiceHistory sh on (mh.ServiceHistoryId = sh.ServiceHistoryId) 
inner join #allowedservices asrv on (asrv.service_id = sh.ServiceId)
where sh.ServiceHistoryId between @fst_srvhistory_id and @lst_srvhistory_id
and mh.ModifiedOn between @StartDate and @FinalDate
and mh.Form = @ordermaterialform
and (@MaterialName is null or mh.Name like '%'+ @MaterialName +'%')
) SRC
where ServiceHistoryId = case when SRC.ServiceName like '%trackout%' then LastTrackoutServiceId else ServiceHistoryId end
group by SRC.MaterialId
        ,SRC.Name
        ,SRC.ServiceName
        ,SRC.ServiceHistoryId
        ,SRC.ServiceStartTime

;with cte_sequencedservices
as
(
select ROW_NUMBER() OVER(PARTITION BY MaterialId ORDER BY ServiceHistoryId ASC) AS Idx
      ,MaterialId
      ,Name
      ,ServiceName
      ,ProductionOrderId
      ,ServiceHistoryId
      ,ServiceStartTime
      ,FirstSIDOpSeq
      ,LastSIDOpSeq
from #materialservices
)

insert into #actions
select c1.MaterialId
      ,c1.Name
      ,c1.ProductionOrderId
      ,c1.ServiceHistoryId as 'Start_ServiceHistoryId'
      ,c2.ServiceHistoryId as 'End_ServiceHistoryId'
      ,c1.FirstSIDOpSeq as 'Start_FirstOperationSeq'
      ,c1.LastSIDOpSeq as 'Start_LastOperationSeq'
      ,c2.FirstSIDOpSeq as 'End_FirstOperationSeq'
      ,c2.LastSIDOpSeq as 'End_LastOperationSeq'
      ,c1.ServiceName as 'c1ServiceName'
      ,c2.ServiceName as 'c2ServiceName'
      ,c1.ServiceStartTime as 'Start_ServiceDate'
      ,c2.ServiceStartTime as 'End_ServiceDate'
from cte_sequencedservices c1 
left join cte_sequencedservices c2 on (c1.MaterialId = c2.MaterialId and c1.Idx + 1 = c2.Idx)
where c1.ServiceName like '%trackin%' and c2.ServiceName not like '%trackin%'


insert into #mogeneratedmaterials
select mhSS.MaterialId MOId
			,mh2.MaterialId
			,ca.Start_ServiceHistoryId
			,mh2.name as 'Pallet_MaterialName'
			,mh2.PrimaryQuantity as 'pallet_primary_quantity'
			,mh2.ModifiedOn
from #actions CA 
inner join CoreDataModel.T_MaterialHistory mhSS ON mhSS.ServiceHistoryId = ca.Start_ServiceHistoryId AND mhSS.OperationHistorySeq = ca.Start_FirstOperationSeq
inner join CoreDataModel.T_MaterialAttribute mattrh on mattrh.Name = 'BaseMaterial' and mattrh.Value = mhSS.Name
inner join CoreDataModel.T_MaterialHistory mh2 on mattrh.MaterialId = mh2.MaterialId and mh2.DatabaseOperation = 0 
                                          and mh2.ServiceHistoryId between ca.Start_ServiceHistoryId AND ca.End_ServiceHistoryId


select ca.Start_ServiceHistoryId
      ,ca.End_ServiceHistoryId 
	,dbo.F_TimeUTCToLocalTime(ca.Start_ServiceDate) as 'Start_ServiceDate'
	,dbo.F_TimeUTCToLocalTime(ca.End_ServiceDate) as 'End_ServiceDate'
      ,ca.c1ServiceName as 'StartEventService'
      ,ca.c2ServiceName as 'EndEventService'
      ,po.Name as 'OrderNumber'
      ,f.Name as 'Facility'
      ,s.name as 'Step'
      ,coalesce(pvers.name, p.Name) as 'ProductName'
      ,coalesce(pvers.Description, p.Description) as 'ProductDescription'   
      ,m.Name as 'mo_MaterialName'
      ,r.Name as 'LastResource'
      ,mattr.Value as 'm_attributte_manufactured_quantity'
      ,po.Quantity as 'po_planned_quantity'
      --,po.SystemState as 'prod_order_system_state_id'
      ,sso.status as 'PO_Status'
      ,cmgm.Pallet_MaterialName
      ,cmgm.pallet_primary_quantity as 'Pallet_PrimaryQuantity'
      ,dbo.F_TimeUTCToLocalTime(cmgm.ModifiedOn) as 'ModifiedOn'
      ,PM.Type
from #actions CA 
inner join CoreDataModel.T_MaterialHistory mhSS ON mhSS.ServiceHistoryId = ca.Start_ServiceHistoryId AND mhSS.OperationHistorySeq = ca.Start_FirstOperationSeq
inner join CoreDataModel.T_MaterialHistory mhSE ON mhSE.ServiceHistoryId = ca.Start_ServiceHistoryId AND mhSE.OperationHistorySeq = ca.Start_LastOperationSeq
inner join CoreDataModel.T_Material m on mhSS.MaterialId = m.MaterialId
inner join CoreDataModel.t_product p on m.ProductId = p.ProductId
left join CoreDataModel.t_product pvers on p.DefinitionId = pvers.ProductId
inner join CoreDataModel.T_Facility f on m.FacilityId = f.FacilityId
inner join CoreDataModel.T_Step s on m.StepId = s.StepId
inner join CoreDataModel.T_Resource r on r.ResourceId = mhSE.LastProcessedResourceId
left join CoreDataModel.T_MaterialAttribute mattr on (mhSS.MaterialId = mattr.MaterialId and mattr.Name = 'CompletedQuantity')
inner join CoreDataModel.t_productionorder po on po.ProductionOrderId = ca.ProductionOrderId
inner join #ordersystemstates sso on po.systemstate = sso.systemstate
left join #mogeneratedmaterials cmgm ON cmgm.MOId = mhSS.MaterialId AND cmgm.Start_ServiceHistoryId = ca.Start_ServiceHistoryId
left join CoreDataModel.T_Material PM ON PM.MaterialId = cmgm.MaterialId

left join #FacilityTempTable filt_f ON (f.Name = filt_f.Name)
left join #StepTempTable filt_s ON (s.Name = filt_s.Name)
left join #ResourceTempTable filt_r ON (r.Name = filt_r.Name)
left join #OrderStatusTempTable filt_o ON (sso.status = filt_o.Name)

where ((@FacilityName is not null and filt_f.Name is not null) or @FacilityName is null)
and ((@StepName is not null and filt_s.Name is not null) or @StepName is null)
and ((@ResourceName is not null and filt_r.Name is not null) or @ResourceName is null)
and ((@OrderStatus is not null and filt_o.Name is not null) or @OrderStatus is null)


