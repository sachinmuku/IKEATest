﻿
if not exists (select * from sys.schemas where name = 'Custom')
begin
	exec('create schema Custom')
end
go

if exists(select 1 from sys.sysobjects 
					where id = object_id(N'[Custom].[P_GetMOProcessingTime]') 
          and objectproperty(id, N'IsProcedure') = 1)
begin
	drop procedure [Custom].[P_GetMOProcessingTime]
end
go


CREATE PROCEDURE [Custom].[P_GetMOProcessingTime]
	@Start datetime = null,
	@End datetime = null,	
	@FacilityName nvarchar(max) = null,
	@AreaName nvarchar(max) = null,
	@ResourceName nvarchar(max) = null,
	@ProductName nvarchar(512) = null
as

set nocount on;


/* declare vars */
declare @fst_srvhistory_id bigint = null
declare @lst_srvhistory_id bigint = null
declare @ordermaterialform nvarchar(30)
declare @setpointparametername nvarchar(30)
declare @StartDate datetime = dbo.F_TimeLocalTimeToUTC(@Start);
declare @FinalDate datetime = dateadd(day, 1, dbo.F_TimeLocalTimeToUTC(@End));


/* Delete temporary tables. They should not exist at this point but helps on debugging.. */
if(object_id('tempdb..#allowedservices') is not null) drop table #allowedservices
if(object_id('tempdb..#FacilityTempTable') is not null) drop table #FacilityTempTable
if(object_id('tempdb..#AreaTempTable') is not null) drop table #AreaTempTable
if(object_id('tempdb..#TemporaryMoData') is not null) drop table #TemporaryMoData
if(object_id('tempdb..#ResourceTempTable') is not null) drop table #ResourceTempTable
if(object_id('tempdb..#materialservices') is not null) drop table #materialservices
if(object_id('tempdb..#actions') is not null) drop table #actions
if(object_id('tempdb..#mogeneratedmaterials') is not null) drop table #mogeneratedmaterials
if(object_id('tempdb..#materialstimestamps') is not null) drop table #materialstimestamps
if(object_id('tempdb..#TimeUnits') is not null) drop table #TimeUnits
if(object_id('tempdb..#ProductTempTable') is not null) drop table #ProductTempTable
if(object_id('tempdb..#RecipeTempTable') is not null) drop table #RecipeTempTable

/* Create temporary tables */
create table #allowedservices (service_id bigint, Name nvarchar(512))
create table #FacilityTempTable (Name nvarchar(512))
create table #ResourceTempTable (Name nvarchar(512))
create table #AreaTempTable(Name nvarchar(512))
create table #TimeUnits(DataUnit nvarchar(30), Multiplier int)
create table #ProductTempTable(Name nvarchar(512))
create table #RecipeTempTable(SetPoint decimal, SetPointUnits nvarchar(512), MaterialId bigint)

create table #materialservices 
(
 MaterialId bigint
,Name nvarchar(512)
,ServiceName nvarchar(512)
,ServiceHistoryId bigint
,ServiceStartTime datetime
,ProductionOrderId bigint
,FirstSIDOpSeq int
,LastSIDOpSeq int
)
create table #actions
(
 MaterialId bigint
,Name nvarchar(512)
,ProductionOrderId bigint
,Start_ServiceHistoryId bigint
,End_ServiceHistoryId bigint
,Start_FirstOperationSeq int
,Start_LastOperationSeq int
,End_FirstOperationSeq int
,End_LastOperationSeq int
,c1ServiceName nvarchar(512)
,c2ServiceName nvarchar(512)
,Start_ServiceDate datetime
,End_ServiceDate datetime
)
create table #mogeneratedmaterials
(
 MOId bigint
,MaterialId bigint
,Start_ServiceHistoryId bigint
,Pallet_MaterialName nvarchar(512)
,pallet_primary_quantity decimal
,ModifiedOn datetime
)
create table #TemporaryMoData 
(
 Start_ServiceHistoryId bigint
,End_ServiceHistoryId bigint
,MaterialId bigint
,mo_MaterialName nvarchar(512)
,PalletId bigint
,Pallet_MaterialName nvarchar(512)
,Start_EventService nvarchar(512)
,End_EventService nvarchar(512)
)
create table #materialstimestamps
(
 MaterialId bigint
,ProductId bigint
,FacilityId bigint
,StepId bigint
,LastProcessedResourceId bigint
,Material nvarchar(512)
,StartDate datetime
,EndDate datetime
,StartModelState nvarchar(512)
,EndModelState nvarchar(512)
,PrimaryQuantity decimal
,SetPoint decimal
,SetPointUnits nvarchar(512)
)


/* Add units for conversion (show all values in seconds?)*/
insert into #TimeUnits
values
('days', 86400),
('hours', 3600),
('minutes', 60),
('seconds', 1)


/* Temp Table with Facilities */
if(@FacilityName is not null)
begin
  insert into #FacilityTempTable 
  select [Value] from [dbo].[F_Split2](@FacilityName, ';');
end

/* Temp Table with Areas */
if(@AreaName is not null)
begin
	insert into #AreaTempTable
	select Value from dbo.F_Split2(@AreaName, ';');
end

/* Temp Table with Resources */
if(@ResourceName is not null)
begin
  insert into #ResourceTempTable
  select [Value] from [dbo].[F_Split2](@ResourceName, ';');
end

/* Temp Table with Products */
if(@ProductName is not null)
begin
	insert into #ProductTempTable
	select Value from dbo.F_Split2(@ProductName, ';');
end

/* Set data for selected services IDs */
insert into #allowedservices
select ServiceId, Name from Security.T_Service
where name IN ('ComplexDispatchAndTrackInMaterials', 
              'ComplexDispatchAndTrackInMaterial',
              'ComplexTrackInMaterials',
              'ComplexTrackInMaterial',
              'ComplexTrackOutMaterials', 
              'ComplexTrackOutMaterial',
              'AbortMaterialsProcess',
              'AbortMaterialProcess',
              'TerminateMaterial')


/* Gets default material Form and Resource SetPoint from Configurations */
select @setpointparametername = [dbo].[F_GetConfigStringValue](N'/Cmf/Custom/SetPointParameter/', N'SetPoint')	/* No data from ODS db */
select @ordermaterialform = [dbo].[F_GetConfigStringValue](N'/Cmf/Custom/MaterialTracking/OrderMaterialForm/', N'MO')	/* No data from ODS db */


/* Get first and last service history ids by date */
set @fst_srvhistory_id = [dbo].[F_Part_GetMinServiceHistoryIdForDate](dateadd(day, -1, @StartDate))
set @lst_srvhistory_id = [dbo].[F_Part_GetMaxServiceHistoryIdForDate](dateadd(day, 1, @FinalDate))


/* Get material events and mark them with start and end service id. */
insert into #materialservices
select SRC.MaterialId
      ,SRC.Name
      ,SRC.ServiceName
      ,SRC.ServiceHistoryId
      ,SRC.ServiceStartTime
      ,max(SRC.ProductionOrderId) as ProductionOrderId
      ,MIN(FirstSIDOpSeq) FirstSIDOpSeq
      ,MAX(LastSIDOpSeq) LastSIDOpSeq
from
(
select mh.MaterialId
      ,mh.Name
      ,sh.ServiceName
      ,sh.ServiceHistoryId
      ,sh.ServiceStartTime
      ,mh.ProductionOrderId 
      ,first_value(mh.OperationHistorySeq) OVER(PARTITION BY Mh.MaterialId, sh.ServiceHistoryId ORDER by mh.ModifiedON ASC, mh.OperationHistorySeq ASC) FirstSIDOpSeq
      ,last_value(mh.OperationHistorySeq) OVER(PARTITION BY Mh.MaterialId, sh.ServiceHistoryId ORDER by mh.ModifiedON ASC, mh.OperationHistorySeq ASC) LastSIDOpSeq
from CoreDataModel.T_MaterialHistory mh 
inner join dbo.T_ServiceHistory sh on (mh.ServiceHistoryId = sh.ServiceHistoryId) 
inner join #allowedservices asrv on (asrv.service_id = sh.ServiceId)
where sh.ServiceHistoryId between @fst_srvhistory_id and @lst_srvhistory_id
and mh.ModifiedOn between @StartDate and @FinalDate
and mh.Form = @ordermaterialform
and mh.UniversalState = case when asrv.Name like '%trackout%' then 4 else mh.UniversalState end
) SRC
group by SRC.MaterialId
        ,SRC.Name
        ,SRC.ServiceName
        ,SRC.ServiceHistoryId
        ,SRC.ServiceStartTime

;with cte_sequencedservices
as
(
select ROW_NUMBER() OVER(PARTITION BY MaterialId ORDER BY ServiceHistoryId ASC) AS Idx
      ,MaterialId
      ,Name
      ,ServiceName
      ,ProductionOrderId
      ,ServiceHistoryId
      ,ServiceStartTime
      ,FirstSIDOpSeq
      ,LastSIDOpSeq
from #materialservices
)

insert into #actions
select c1.MaterialId
      ,c1.Name
      ,c1.ProductionOrderId
      ,c1.ServiceHistoryId as 'Start_ServiceHistoryId'
      ,c2.ServiceHistoryId as 'End_ServiceHistoryId'
      ,c1.FirstSIDOpSeq as 'Start_FirstOperationSeq'
      ,c1.LastSIDOpSeq as 'Start_LastOperationSeq'
      ,c2.FirstSIDOpSeq as 'End_FirstOperationSeq'
      ,c2.LastSIDOpSeq as 'End_LastOperationSeq'
      ,c1.ServiceName as 'c1ServiceName'
      ,c2.ServiceName as 'c2ServiceName'
      ,c1.ServiceStartTime as 'Start_ServiceDate'
      ,c2.ServiceStartTime as 'End_ServiceDate'
from cte_sequencedservices c1 
left join cte_sequencedservices c2 on (c1.MaterialId = c2.MaterialId and c1.Idx + 1 = c2.Idx)
where c1.ServiceName like '%trackin%' and c2.ServiceName not like '%trackin%'


insert into #mogeneratedmaterials
select mhSS.MaterialId MOId
			,mh2.MaterialId
			,ca.Start_ServiceHistoryId
			,mh2.name as 'Pallet_MaterialName'
			,mh2.PrimaryQuantity as 'pallet_primary_quantity'
			,mh2.ModifiedOn
from #actions CA 
inner join CoreDataModel.T_MaterialHistory mhSS ON mhSS.ServiceHistoryId = ca.Start_ServiceHistoryId AND mhSS.OperationHistorySeq = ca.Start_FirstOperationSeq
inner join CoreDataModel.T_MaterialAttribute mattrh on mattrh.Name = 'BaseMaterial' and mattrh.Value = mhSS.Name
inner join CoreDataModel.T_MaterialHistory mh2 on mattrh.MaterialId = mh2.MaterialId and mh2.DatabaseOperation = 0 
                                          and mh2.ServiceHistoryId between ca.Start_ServiceHistoryId AND ca.End_ServiceHistoryId


insert into #TemporaryMoData
select ca.Start_ServiceHistoryId
	,ca.End_ServiceHistoryId 
	,m.MaterialId
	,m.Name as 'mo_MaterialName'
	,cmgm.MaterialId as 'PalletId'
	,cmgm.Pallet_MaterialName
	,ca.c1ServiceName as 'StartEventService'
	,ca.c2ServiceName as 'EndEventService'
from #actions CA 
inner join CoreDataModel.T_MaterialHistory mhSS ON mhSS.ServiceHistoryId = ca.Start_ServiceHistoryId AND mhSS.OperationHistorySeq = ca.Start_FirstOperationSeq
inner join CoreDataModel.T_MaterialHistory mhSE ON mhSE.ServiceHistoryId = ca.Start_ServiceHistoryId AND mhSE.OperationHistorySeq = ca.Start_LastOperationSeq
inner join CoreDataModel.T_Material m on mhSS.MaterialId = m.MaterialId
inner join CoreDataModel.t_product p on m.ProductId = p.ProductId
inner join CoreDataModel.T_Facility f on m.FacilityId = f.FacilityId
inner join CoreDataModel.T_Step s on m.StepId = s.StepId
inner join CoreDataModel.T_Resource r on r.ResourceId = mhSE.LastProcessedResourceId
left join CoreDataModel.T_MaterialAttribute mattr on (mhSS.MaterialId = mattr.MaterialId and mattr.Name = 'CompletedQuantity')
inner join CoreDataModel.t_productionorder po on po.ProductionOrderId = ca.ProductionOrderId
left join #mogeneratedmaterials cmgm ON cmgm.MOId = mhSS.MaterialId AND cmgm.Start_ServiceHistoryId = ca.Start_ServiceHistoryId
left join CoreDataModel.T_Material PM ON PM.MaterialId = cmgm.MaterialId
left join #FacilityTempTable filt_f ON (f.Name = filt_f.Name)
left join #ResourceTempTable filt_r ON (r.Name = filt_r.Name)
where ((@FacilityName is not null and filt_f.Name is not null) or @FacilityName is null)
and ((@ResourceName is not null and filt_r.Name is not null) or @ResourceName is null)


insert into #RecipeTempTable
select distinct cast(rip.Value * tu.Multiplier as decimal) as 'SetPoint'
			,par.DataUnit as 'SetPointUnits'
			,mh.MaterialId
from CoreDataModel.T_MaterialHistory mh 
inner join CoreDataModel.T_RecipeInstance ri on ri.RecipeInstanceId = mh.CurrentRecipeInstance
inner join CoreDataModel.T_RecipeInstanceParameter rip on ri.RecipeInstanceId = rip.SourceEntityId
inner join CoreDataModel.T_Parameter par on (rip.TargetEntityId = par.parameterid )
inner join #TimeUnits tu on par.DataUnit = tu.DataUnit
inner join #TemporaryMoData tmd on mh.MaterialId = tmd.MaterialId
where par.name = @setpointparametername


;with materialdata
as
(
select row_number() over(partition by mh.MaterialId, tmd.Start_ServiceHistoryId, tmd.End_ServiceHistoryId order by min(mh.ModifiedOn) asc) as Idx
			,mh.MaterialId as 'MaterialId'
			,tmd.Start_ServiceHistoryId
			,tmd.End_ServiceHistoryId
			,tmd.Start_eventService
			,tmd.End_eventService
			,mh.ProductId
			,mh.FacilityId
			,mh.StepId
			,mh.LastProcessedResourceId
			,mh.Name as 'Material'
      ,min(mh.ModifiedOn) as 'ModifiedOn'
			,st.Name as 'StateModelState'
			,rt.SetPoint
			,rt.SetPointUnits
from CoreDataModel.T_MaterialHistory mh 
inner join dbo.T_StateModelState st on (mh.MainStateModelStateId = st.StateModelStateId and st.Name in ('INPROCESS', 'FINALIZED', 'QUEUED'/*, 'DISPATCHED'*/))
left join #RecipeTempTable rt on (/*mh.CurrentRecipeInstance = rt.CurrentRecipeInstance and*/ mh.MaterialId = rt.MaterialId)
inner join #TemporaryMoData tmd on (mh.ServiceHistoryId > tmd.Start_ServiceHistoryId and mh.ServiceHistoryId <= tmd.End_ServiceHistoryId and mh.MaterialId = tmd.MaterialId)
group by mh.MaterialId
				,mh.ProductId
				,mh.FacilityId
				,mh.StepId
				,mh.Name
				,st.Name
				,rt.SetPoint
				,rt.SetPointUnits
			  ,tmd.Start_ServiceHistoryId
			  ,tmd.End_ServiceHistoryId
			  ,tmd.Start_eventService
			  ,tmd.End_eventService
				,mh.LastProcessedResourceId
)


insert into #materialstimestamps
select c1.MaterialId
			,c1.ProductId
			,c1.FacilityId
			,c1.StepId
			,c1.LastProcessedResourceId
			,c1.Material as 'Material'
			,c1.ModifiedOn as 'Started' 			 
			,c2.ModifiedOn as 'Ended'
			,c1.StateModelState as 'StartModelState'
			,c2.StateModelState as 'EndModelState'
			,sum(mh2.PrimaryQuantity) as 'PrimaryQuantity'
			,c1.SetPoint
			,c1.SetPointUnits
from materialdata c1 
left join materialdata c2 on (c1.Idx + 1 = c2.Idx and c1.MaterialId = c2.MaterialId and c1.Start_ServiceHistoryId = c2.Start_ServiceHistoryId) 
inner join CoreDataModel.T_MaterialAttribute mattrh on mattrh.Name = 'BaseMaterial' and mattrh.Value = c1.Material
inner join CoreDataModel.T_MaterialHistory mh2 on (mattrh.MaterialId = mh2.MaterialId and mh2.DatabaseOperation = 0 and c1.LastProcessedResourceId = mh2.LastProcessedResourceId and mh2.ModifiedOn between c1.ModifiedOn and c2.ModifiedOn)
where c1.StateModelState = 'INPROCESS'
and c2.StateModelState IN ('FINALIZED', 'QUEUED')
group by c1.MaterialId 
				,c1.ProductId
				,c1.LastProcessedResourceId
				,c1.FacilityId
				,c1.StepId
				,c1.Material
				,c1.ModifiedOn		 
				,c2.ModifiedOn
				,c1.StateModelState
				,c2.StateModelState
				,c1.SetPoint
				,c1.SetPointUnits


select m.Material
			,dbo.F_TimeUTCToLocalTime(m.StartDate) as 'StartDate'
			,dbo.F_TimeUTCToLocalTime(m.EndDate) as 'EndDate'		
			,m.StartModelState
			,m.EndModelState
			,m.PrimaryQuantity
			,f.Name as 'Facility'
			,a.name as 'Area'
			,r.Name as 'LastResource'
			,p.Name as 'ProductName'
			,case when m.PrimaryQuantity > 0 then datediff(second, m.StartDate, m.EndDate) / m.PrimaryQuantity else null end as 'ActualCyleTime'
			,(f_ict.TimePerUnit * tu.Multiplier) as 'IdealCycleTime'
			,m.SetPoint
			,m.SetPointUnits
from #materialstimestamps m
inner join CoreDataModel.t_product p on m.ProductId = p.ProductId
inner join CoreDataModel.T_Facility f on m.FacilityId = f.FacilityId
inner join CoreDataModel.T_Step s on m.StepId = s.StepId
inner join CoreDataModel.T_Resource r on r.ResourceId = m.LastProcessedResourceId
inner join CoreDataModel.T_Area a on r.AreaId = a.AreaId

left join CoreDataModel.T_ProductGroup pg on p.ProductGroupId = p.ProductGroupId

left join #FacilityTempTable filt_f ON (f.Name = filt_f.Name)
left join #AreaTempTable filt_a ON (a.Name = filt_a.Name)
left join #ResourceTempTable filt_r ON (r.Name = filt_r.Name)
left join #ProductTempTable filt_p ON (p.Name = filt_p.Name)

outer apply CoreDataModel.F_ST_ResolveResourceIdealCycleTime(1, r.Name, r.ResourceType, r.Model, s.name, p.name, pg.Name) f_ict
left join #TimeUnits tu on f_ict.TimeScale = tu.DataUnit

where ((@FacilityName is not null and filt_f.Name is not null) or @FacilityName is null)
and ((@AreaName is not null and filt_a.Name is not null) or @AreaName is null)
and ((@ResourceName is not null and filt_r.Name is not null) or @ResourceName is null)
and ((@ProductName is not null and filt_p.Name is not null) or @ProductName is null)
order by Material, StartDate
