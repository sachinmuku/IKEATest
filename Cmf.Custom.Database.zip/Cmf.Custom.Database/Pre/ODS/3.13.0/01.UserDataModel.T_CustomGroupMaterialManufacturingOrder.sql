
BEGIN TRY
    BEGIN
		DECLARE @MachineName varchar(64) = CONVERT(VARCHAR(64), SERVERPROPERTY('MachineName'))
		DECLARE @ServiceName nvarchar(256) = 'CustomGroupMaterialManufacturingOrder: Update PartsPerCycle property'
		DECLARE @EntityTypeName nvarchar(256) = 'CustomGroupMaterialManufacturingOrder'
		DECLARE @NewOperationSequence bigint = 1
		DECLARE @EntityTypeId bigint      
		DECLARE @GeneratedAssemblyName nvarchar(256) = 'Cmf.Custom.IKEA.BusinessObjects.CustomGroupMaterialManufacturingOrder.dll'
		DECLARE @LastOperationHistorySequence BIGINT = 0
		DECLARE @PrintScriptOnly bit = 0
		DECLARE @WithTriggers bit = 1
		DECLARE @UseCommandQueue bit = 0
		DECLARE @NewServiceHistoryId bigint
		DECLARE @ServiceHistoryId bigint
		DECLARE @BatchExecutionId uniqueidentifier
		DECLARE @LastServiceHistoryId bigint
		DECLARE @ModifiedBy varchar(64)
		DECLARE @ModifiedOn datetime
		DECLARE @LastOnlineServiceHistoryID bigint

		BEGIN TRANSACTION

        -- Add code here
		SELECT @EntityTypeId  = EntityTypeId FROM dbo.T_EntityType WHERE Name = @EntityTypeName
		SELECT @ModifiedBy = ModifiedBy,  @LastServiceHistoryId = LastServiceHistoryId FROM  [dbo].T_EntityType WHERE Name = @EntityTypeName
		SELECT @ModifiedOn = GETUTCDATE()

		-- Generate new Service History Id
		PRINT 'Generate new Service History Id'
		EXECUTE [dbo].[P_CreateServiceHistoryId] -1, @ServiceName, NULL, @MachineName, @ServiceHistoryId OUTPUT

		SELECT @NewServiceHistoryId = @ServiceHistoryId + 1

		-- Delete Generated Assembly
		PRINT 'Delete Generated Assembly'
		delete from Services.T_GeneratedAssembly
		where Name = @GeneratedAssemblyName

		-- Update Entity Type and Property
		PRINT 'Update Entity Type'
		update dbo.T_EntityType
		set UniversalState = 0,
		ModifiedBy = @ModifiedBy,
		ModifiedOn = @ModifiedOn,
		LastServiceHistoryId = @NewServiceHistoryId,
		LastOperationHistorySeq = @NewOperationSequence
		where Name = @EntityTypeName

		PRINT 'Update Entity Type Property'
		update dbo.T_EntityTypeProperty
		set UniversalState = 0,
		ModifiedBy = @ModifiedBy,
		ModifiedOn = @ModifiedOn,
		LastServiceHistoryId = @NewServiceHistoryId +1,
		LastOperationHistorySeq = @NewOperationSequence 
		where EntityTypeId = (
			select EntityTypeId from dbo.T_EntityType
			where Name = @EntityTypeName
		)

		SELECT @EntityTypeId = EntityTypeId, @ModifiedBy=ModifiedBy,  @LastOnlineServiceHistoryID= LastServiceHistoryId FROM  [dbo].T_EntityType WHERE Name = @EntityTypeName
		SELECT  @NewOperationSequence = @NewOperationSequence + 1, @ModifiedOn = GETUTCDATE()
		SELECT @NewServiceHistoryId = @NewServiceHistoryId +1


		-- Update Property PartsPerCycle to decimal
		PRINT 'Update Property PartsPerCycle to decimal'
		UPDATE [T_EntityTypeProperty]
			SET  
			Description = N'PartsPerCycle', 
			[ScalarTypeId] = ( select ScalarTypeId from [T_ScalarType] where Name = 'Decimal'), 
			[ScalarSize] = 8, 
			[ScalarPrecision] = 16,
			[IsArray] = 0,
			[IsEnabled] = 1,
			[IsOperationAttribute] = 0,
			[IsMandatory] = 0,
			[DefaultValue] = 0,
			[ModifiedBy] = N'System',
			[ModifiedOn] = GETUTCDATE(), 
			[LastServiceHistoryId] = @NewServiceHistoryId +1,
			[LastOperationHistorySeq] = @NewOperationSequence, 
			[DataGroupId] = NULL, 
			[DataGroupName] = NULL,
			[UniversalState] = 0,
			[ReferencedObjectId] = NULL,
			[ReferenceType] = 0,
			[AccessLevel] = 0,
			[ValidationRange] = NULL,
			[ValidationRegex] = NULL,
			[IsSystemProperty] = 0,
			[PropertyType] = 1,
			[IsIndexed] = 0,
			[ReferenceName] = NULL,
			[LoadToDWH] = 1,
			[IsHistoryEnable] = 1,
			[BelongsTo] = 0,
			[LowerRangeValue] = NULL,
			[UpperRangeValue] = NULL,
			[CopyOnClone] = 0
		WHERE [EntityTypeId] = (
			select EntityTypeId from dbo.T_EntityType
			where Name = @EntityTypeName
		) and Name = 'PartsPerCycle'

		SELECT @LastOperationHistorySequence = @LastOperationHistorySequence+1
		
		-- Alter tables to account for property change
		PRINT 'Alter tables to account for property change'
		ALTER TABLE UserDataModel.T_CustomGroupMaterialManufacturingOrder ALTER COLUMN PartsPerCycle decimal(16, 8)
		ALTER TABLE UserDataModel.T_CustomGroupMaterialManufacturingOrderHistory ALTER COLUMN PartsPerCycle decimal(16, 8)

		-- Generate Schema
		PRINT 'Generate Schema'
		EXEC [dbo].[P_GenerateEntityType]
			@Type = @EntityTypeName,
			@BatchExecutionId = @BatchExecutionId OUTPUT,
			@PrintScriptOnly = 0,
			@WithTriggers = 1,
			@UseCommandQueue = 0,
			@LastServiceHistoryId = @LastOnlineServiceHistoryID,
			@NewServiceHistoryId = @NewServiceHistoryId,
			@NewOperationSequence = @NewOperationSequence,
			@ModifiedBy = 'System',
			@ModifiedOn = @ModifiedOn

        -- End of code

        -- UPDATE dbo.T_ServiceHistory
		PRINT 'UPDATE dbo.T_ServiceHistory'
		UPDATE [dbo].[T_ServiceHistory] SET [ServiceEndTime] = GETUTCDATE()
		WHERE ServiceHistoryId = @NewServiceHistoryId 
        COMMIT
		--ROLLBACK
    END
END TRY
BEGIN CATCH
    ROLLBACK
    DECLARE @ErrorMessage NVARCHAR(4000);
    DECLARE @ErrorSeverity INT;
    DECLARE @ErrorState INT;
	DECLARE @ErrorLine INT;
    
	SELECT
		@ErrorMessage = ERROR_MESSAGE(),
		@ErrorSeverity = ERROR_SEVERITY(),
		@ErrorState = ERROR_STATE(),
		@ErrorLine = ERROR_LINE();
	-- Use RAISERROR inside the CATCH block to return error
	-- information about the original error that caused
	-- execution to jump to the CATCH block.
    RAISERROR(  
        @ErrorMessage, -- Message text.
        @ErrorSeverity, -- Severity.
        @ErrorState, -- State.
		@ErrorLine -- Line
    );
END CATCH
