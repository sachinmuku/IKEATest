/******************************
** Name: UserDataModel.P_CustomGetProductionKpis
** Description: Procedure to get the production kpis: OEE, resource times, MTBF, MTTR, etc;
** Author: Paulo Soares
** Date: 28-Apr-2021
**************************

** Version History

** Version  Date          Author                       Description 
** ---------------------------------------------------------------------------------------------------------------------------------------------                    
** Sprint 8  28/Apr/2021  Paulo S.                      Procedure to get the production kpis: OEE, resource times, MTBF, MTTR, etc;
*/
ALTER  PROCEDURE [UserDataModel].[P_CustomGetProductionKpis] 
  @FacilityId          NVARCHAR(MAX),
  @NFacTotalElems      INT,
  @AreaId              NVARCHAR(MAX),
  @NAreaTotalElems     INT,
  @ShiftId             NVARCHAR(MAX),
  @NShiftsTotalElems   INT, 
  @ResourceId          NVARCHAR(MAX),
  @NResourceTotalElems INT, 
  @ProductName         NVARCHAR(MAX) = NULL,
  @DateStart		   DateTime = NULL,
  @DateEnd			   DateTime = NULL 
AS
BEGIN
-- DECLARE
-- @FacilityId NVARCHAR(MAX)='2001220000010000002',
-- @NFacTotalElems INT=3,
-- @AreaId NVARCHAR(MAX)='2001220000010000003',
-- @NAreaTotalElems INT = 3,
-- @ShiftId NVARCHAR(MAX) = NULL,
-- @NShiftsTotalElems INT = 4, 
-- @ResourceId NVARCHAR(MAX)='2004290000000000002',
-- @NResourceTotalElems INT=3, 
-- @DateStart DateTime = '2024-01-09 06:00:00', 
-- @DateEnd DateTime = '2024-01-11 05:59:00',  
-- @ProductName NVARCHAR(MAX) =NULL

SET NOCOUNT ON

BEGIN /* Filters instantiation */
  DECLARE @RowCount INT;


  IF ISNULL(@DateStart,0) = 0	 SET @DateStart = DateAdd(DD,-7,GETDATE()) 
  IF ISNULL (@DateEnd,0) = 0	 SET @DateEnd = GETDATE() 

  --set @DateEnd = CONVERT(DATETIME, CONVERT(varchar(11),@DateEnd, 111 ) + ' 23:59:59', 111) 
  --set @DateStart = CONVERT(DATETIME, CONVERT(varchar(11),@DateStart, 111 ) + ' 00:00:00', 111)  

  DECLARE @ProcName nvarchar(30) = 'P_LoadFactResourceServiceTime';
--
-- #Temp Tables Check
--
  IF(object_id('tempdb..#ELIGIBLE_RESOURCES') is not null)           DROP TABLE #ELIGIBLE_RESOURCES
  IF(object_id('tempdb..#PROCESSED_MATERIALS') is not null)          DROP TABLE #PROCESSED_MATERIALS
  IF(object_id('tempdb..#MAT_PERF') is not null)                     DROP TABLE #MAT_PERF
  IF(object_id('tempdb..#ELIGIBLE_RESOURCES_CONDENSED') is not null) DROP TABLE #ELIGIBLE_RESOURCES_CONDENSED
  IF(object_id('tempdb..#IDEAL_PROCESSED_QUANTITY') is not null)     DROP TABLE #IDEAL_PROCESSED_QUANTITY
  IF(object_id('tempdb..#RES_PERF') is not null)                     DROP TABLE #RES_PERF
  IF(object_id('tempdb..#RES_IDEAL_QTY') is not null)                DROP TABLE #RES_IDEAL_QTY
  IF(object_id('tempdb..#V_FACTMATERIALLOSSBONUSTIME_WITH_SECQUANTITYNORMALIZED')is not null) DROP TABLE #V_FACTMATERIALLOSSBONUSTIME_WITH_SECQUANTITYNORMALIZED

--V_FactMaterialLossBonusTime
-- Facility Filter
--
  DECLARE @HasFacilityFilter BIT;
  DECLARE @FacilityTab TABLE
  ( 
    FacilityKey BIGINT
  );
  INSERT INTO @FacilityTab(FacilityKey)
    SELECT dF.FacilityKey
      FROM DataSets.fnSplit(@FacilityId, ',') f
      INNER JOIN [DataSets].[V_DimFacility] dF
      ON (CONVERT(BIGINT, f.item) = dF.FacilityId);
 
  SET @RowCount = @@ROWCOUNT;
  IF (@RowCount > 0  AND @RowCount <> @NFacTotalElems) 
  BEGIN
     SET @HasFacilityFilter = 1
  END
  ELSE 
  BEGIN
     SET @HasFacilityFilter = 0;
     DELETE FROM @FacilityTab;
  END
 
--
-- Area Filter
--
  DECLARE @HasAreaFilter BIT;
  DECLARE @AreaTab TABLE
  (
    AreaKey bigint
  ); 
  INSERT INTO @AreaTab(AreaKey) 
    SELECT dA.AreaKey
      FROM DataSets.fnSplit(@AreaId, ',') a
      INNER JOIN [DataSets].[V_DimArea] dA
      ON (dA.AreaId = CONVERT(BIGINT, a.item));

  SET @RowCount = @@ROWCOUNT;
  IF (@RowCount > 0  AND @RowCount <> @NAreaTotalElems) 
  BEGIN
     SET @HasAreaFilter = 1
  END

  ELSE 
  BEGIN
    SET @HasAreaFilter = 0;
    DELETE FROM @AreaTab;
  END

--
-- Shifts Filter
--
  DECLARE @HasShifts BIT;
  DECLARE @ShiftsTab TABLE
  ( 
    ShiftKey BIGINT
  );
  INSERT INTO @ShiftsTab
     SELECT dP.ShiftKey AS ShiftKey
       FROM DataSets.fnSplit(@Shiftid, ',') s
       INNER JOIN [DataSets].[V_DimShift] dP
       ON (dP.ShiftDefinitionShiftId = CONVERT(BIGINT, s.item));

  SET @RowCount = @@ROWCOUNT;
  IF (@RowCount > 0  AND @RowCount <> @NShiftsTotalElems) 
  BEGIN
    SET @HasShifts = 1
  END
  ELSE 
  BEGIN
    SET @HasShifts = 0;
    DELETE FROM @ShiftsTab;
  END 

--
-- Resources Filter
--
  DECLARE @HasResources BIT;
  DECLARE @ResourcesTab TABLE
  ( 
   ResourceKey BIGINT
  );
 INSERT INTO @ResourcesTab
     SELECT dP.ResourceKey AS ResourceKey
       FROM DataSets.fnSplit(@ResourceId, ',') s
       INNER JOIN [DataSets].[V_DimResource] dP
       ON (dP.[ResourceId] = CONVERT(BIGINT, s.item));

  SET @RowCount = @@ROWCOUNT;
  IF (@RowCount > 0  AND @RowCount <> @NResourceTotalElems) 
  BEGIN
    SET @HasResources = 1
  END
  ELSE 
  BEGIN
    SET @HasResources = 0;
    DELETE FROM @ResourcesTab;
  END 
  
--Adittional variables declarations
  DECLARE @DateStartHost DATETIME = @DateStart;
  DECLARE @DateEndHost DATETIME = @DateEnd; 
  DECLARE @DateStartHostInt INT = [dbo].[F_GetDateKeyFROMDateTime](@DateStartHost);
  DECLARE @DateEndHostInt INT = [dbo].[F_GetDateKeyFROMDateTime](@DateEndHost);
  DECLARE @DateStartHostIntPartId INT = [dbo].[F_GetDateKeyFROMDateTime](@DateStartHost-2);
  DECLARE @DateEndHostIntPartId INT = [dbo].[F_GetDateKeyFROMDateTime](@DateEndHost+2);

 END; 
 BEGIN
/* Resources filtered */
  SELECT R.ResourceKey, R.ResourceName
    INTO #ELIGIBLE_RESOURCES
    FROM DataSets.V_DimResource R
    LEFT OUTER JOIN @ResourcesTab RR ON (RR.ResourceKey = R.ResourceKey)
   WHERE (@HasResources = 0 OR RR.ResourceKey > 0)
  OPTION (RECOMPILE);
   
 END
 CREATE CLUSTERED INDEX TMP_IDX_ELIGIBLE_RESOURCES ON #ELIGIBLE_RESOURCES(ResourceKey);

 --V_FactMaterialLossTimeBonus With Sec Quantity Normalized

BEGIN
  WITH ResourceUndefinedKey as (
	SELECT top(1) ResourceKey from DimResource where ResourceName = [Constants].[F_GetUndefinedKeyName]()
)
select  mpt.DateKey,
        mpt.TimeKey,
        mpt.ShiftDateKey, 
		mpt.ShiftKey, 
		mpt.LC1DateKey,
		mpt.LC1TimeKey,
		bl.AreaKey, 
		bl.ResourceKey,
		bl.ParentResourceKey,
		bl.ParentMaterialKey,
		bl.MaterialKey,
		mpt.MaterialHierarchyKey,
		bl.ProductKey,
		bl.StepKey,
		bl.DetectedByStepKey,
		bl.LastRelatedOperationName,
		bl.FlowKey,		
		cast(isnull(bl.PrimaryQuantityLoss,0.0) as decimal(38,15)) * mpt.ParcelQtyFactorApplied * (mpt.[IdealCycleTime]*1/mpt.[IdealBaseCycleTime]) as TotalPrimaryQuantityLossNormalized,
		cast(isnull(bl.SecondaryQuantityLoss,0.0) as decimal(38,15)) * mpt.ParcelQtyFactorApplied * (mpt.[IdealCycleTime]*1/mpt.[IdealBaseCycleTime]) as TotalSecondaryQuantityLossNormalized,
		case when bl.StepKey = bl.DetectedByStepKey and bl.LastRelatedOperationName in ('TrackIn', 'SplitFrom') then cast(isnull(bl.PrimaryQuantityLoss,0.0) as decimal(38,15)) * mpt.ParcelQtyFactorApplied * (mpt.[IdealCycleTime]*1/mpt.[IdealBaseCycleTime]) else 0 end as TotalPrimaryQuantityInprocessLossNormalized,
		case when bl.StepKey = bl.DetectedByStepKey and bl.LastRelatedOperationName = 'TrackOut' then cast(isnull(bl.PrimaryQuantityLoss,0.0) as decimal(38,15)) * mpt.ParcelQtyFactorApplied * (mpt.[IdealCycleTime]*1/mpt.[IdealBaseCycleTime]) else 0 end as TotalPrimaryQuantityProcessedLossNormalized,
		case when bl.StepKey != bl.DetectedByStepKey then cast(isnull(bl.PrimaryQuantityLoss,0.0) as decimal(38,15)) * mpt.ParcelQtyFactorApplied * (mpt.[IdealCycleTime]*1/mpt.[IdealBaseCycleTime]) else 0 end as TotalPrimaryQuantityOutOfStepLossNormalized,
		cast(isnull(bl.PrimaryQuantityBonus,0.0) as decimal(38,15)) * mpt.ParcelQtyFactorApplied * (mpt.[IdealCycleTime]*1/mpt.[IdealBaseCycleTime]) as TotalPrimaryQuantityBonusNormalized,
		cast(isnull(bl.PrimaryQuantityLoss,0.0) as decimal(38,15)) * mpt.ParcelQtyFactorApplied as MaterialsPrimaryQuantityLoss,
		cast(isnull(bl.SecondaryQuantityLoss,0.0) as decimal(38,15)) * mpt.ParcelQtyFactorApplied as MaterialsSecondaryQuantityLoss,
		cast(isnull(bl.PrimaryQuantityBonus,0.0) as decimal(38,15)) * mpt.ParcelQtyFactorApplied as MaterialsPrimaryQuantityBonus,
		cast(isnull(bl.SecondaryQuantityBonus,0.0) as decimal(38,15)) * mpt.ParcelQtyFactorApplied as MaterialsSecondaryQuantityBonus,
		null as TotalSubResourcesPrimaryQuantityLossNormalized,
		null as TotalSubResourcesSecondaryQuantityLossNormalized,
		null as TotalSubResourcesPrimaryQuantityInprocessLossNormalized,
		null as TotalSubResourcesPrimaryQuantityProcessedLossNormalized,
		null as TotalSubResourcesPrimaryQuantityOutOfStepLossNormalized,
		null as TotalSubResourcesPrimaryQuantityBonusNormalized,
		null as SubResourcesMaterialsPrimaryQuantityLoss,
		null as SubResourcesMaterialsSecondaryQuantityLoss,
		null as SubResourcesMaterialsPrimaryQuantityBonus,
		null as SubResourcesMaterialsSecondaryQuantityBonus,
		bl.PrimaryUnitKey,
		bl.SecondaryUnitKey
		into #V_FACTMATERIALLOSSBONUSTIME_WITH_SECQUANTITYNORMALIZED
	from FactResourceMaterialLossBonus bl
	inner join DimMaterial dmloss on dmloss.MaterialKey = bl.MaterialKey
	cross apply (select mpt.* 
	               from FactMaterialProcessTime mpt
				   inner join DimMaterial dmmpt on dmmpt.MaterialKey = mpt.MaterialKey
				  where  mpt.AreaKey = bl.AreaKey and 
					mpt.ResourceKey = bl.ResourceKey and 
					mpt.FlowKey = BL.FlowKey and 
					mpt.StepKey = bl.StepKey and
					mpt.UTCTrackInDateTime = bl.UTCTrackInOperationEndTime and
					dmmpt.MaterialId = dmloss.MaterialID and 
					(@HasAreaFilter = 0 OR mpt.AreaKey IN (SELECT AreaKey FROM @AreaTab)) and
					(@HasShifts = 0 OR mpt.ShiftKey IN (SELECT ShiftKey FROM @ShiftsTab)) and
					(@HasResources = 0 OR mpt.ResourceKey IN (SELECT ResourceKey FROM @ResourcesTab))
				) mpt
	where bl.isResourceRelated = 1 and (@HasAreaFilter = 0 OR bl.AreaKey IN (SELECT AreaKey FROM @AreaTab)) and
					(@HasShifts = 0 OR bl.ShiftKey IN (SELECT ShiftKey FROM @ShiftsTab)) and
					(@HasResources = 0 OR bl.ResourceKey IN (SELECT ResourceKey FROM @ResourcesTab))
	union all
	select mpt.DateKey,
        mpt.TimeKey,
        mpt.ShiftDateKey, 
		mpt.ShiftKey, 
		mpt.LC1DateKey,
		mpt.LC1TimeKey,
		bl.AreaKey, 
		bl.ParentResourceKey as ResourceKey,
		(select top(1) resourceKey from ResourceUndefinedKey) as ParentResourceKey,
		bl.ParentMaterialKey,
		bl.MaterialKey,
		mpt.MaterialHierarchyKey,
		bl.ProductKey,
		bl.StepKey,
		bl.DetectedByStepKey,
		bl.LastRelatedOperationName,
		bl.FlowKey,
		null as TotalPrimaryQuantityLossNormalized,
		null as TotalSecondaryQuantityLossNormalized,
		null as TotalPrimaryQuantityInprocessLossNormalized,
		null as TotalPrimaryQuantityProcessedLossNormalized,
		null as TotalPrimaryQuantityOutOfStepLossNormalized,
		null as TotalPrimaryQuantityBonusNormalized,
		null as MaterialsPrimaryQuantityLoss,
		null as MaterialsSecondaryQuantityLoss,
		null as MaterialsPrimaryQuantityBonus,
		null as MaterialsSecondaryQuantityBonus,
		case when mpt.[ParentIdealBaseCycleTime] != 0 then  cast(isnull(bl.PrimaryQuantityLoss,0.0) as decimal(38,15)) * mpt.ParcelQtyFactorApplied * (mpt.[ParentIdealCycleTime]*1/mpt.[ParentIdealBaseCycleTime]) end as TotalSubResourcesPrimaryQuantityLossNormalized,
		case when mpt.[ParentIdealBaseCycleTime] != 0 then cast(isnull(bl.SecondaryQuantityLoss,0.0) as decimal(38,15)) * mpt.ParcelQtyFactorApplied * (mpt.[ParentIdealCycleTime]*1/mpt.[ParentIdealBaseCycleTime]) end as TotalSubResourcesSecondaryQuantityLossNormalized,
		case when bl.StepKey = bl.DetectedByStepKey and 
			( bl.LastRelatedOperationName in ('TrackIn', 'SplitFrom')
-- copes with scenario where when using submaterial tracking submaterials may be trackout before the parent
			  OR bl.LastRelatedOperationName = 'TrackOut' and bl.UTCOperationEndTime < lastParentState.UTCTrackOutDateTime) then case when mpt.[ParentIdealBaseCycleTime] != 0 then cast(isnull(bl.PrimaryQuantityLoss,0.0) as decimal(38,15)) * mpt.ParcelQtyFactorApplied * (mpt.[ParentIdealCycleTime]*1/mpt.[ParentIdealBaseCycleTime]) end else 0 end as TotalSubResourcesPrimaryQuantityInprocessLossNormalized,
		case when bl.StepKey = bl.DetectedByStepKey and bl.LastRelatedOperationName = 'TrackOut' 
-- following condition is to make sure quantities are not duplicated on the "InProcess" and "Processed" depending on the parent being already trackout or not
			and bl.UTCOperationEndTime >= ISNULL(lastParentState.UTCTrackOutDateTime, bl.UTCOperationEndTime) then case when mpt.[ParentIdealBaseCycleTime] != 0 then cast(isnull(bl.PrimaryQuantityLoss,0.0) as decimal(38,15)) * mpt.ParcelQtyFactorApplied * (mpt.[ParentIdealCycleTime]*1/mpt.[ParentIdealBaseCycleTime]) end else 0 end as TotalSubResourcesPrimaryQuantityProcessedLossNormalized,
		case when bl.StepKey != bl.DetectedByStepKey then case when mpt.[ParentIdealBaseCycleTime] != 0 then cast(isnull(bl.PrimaryQuantityLoss,0.0) as decimal(38,15)) * mpt.ParcelQtyFactorApplied * (mpt.[ParentIdealCycleTime]*1/mpt.[ParentIdealBaseCycleTime]) end else 0 end as TotalSubResourcesPrimaryQuantityOutOfStepLossNormalized,
		case when mpt.[ParentIdealBaseCycleTime] != 0 then cast(isnull(bl.PrimaryQuantityBonus,0.0) as decimal(38,15)) * mpt.ParcelQtyFactorApplied * (mpt.[ParentIdealCycleTime]*1/mpt.[ParentIdealBaseCycleTime]) end as TotalSubResourcesPrimaryQuantityBonusNormalized,
		cast(isnull(bl.PrimaryQuantityLoss,0.0) as decimal(38,15)) * mpt.ParcelQtyFactorApplied as SubResourcesMaterialsPrimaryQuantityLoss,
		cast(isnull(bl.SecondaryQuantityLoss,0.0) as decimal(38,15)) * mpt.ParcelQtyFactorApplied as SubResourcesMaterialsSecondaryQuantityLoss,
		cast(isnull(bl.PrimaryQuantityBonus,0.0) as decimal(38,15)) * mpt.ParcelQtyFactorApplied as SubResourcesMaterialsPrimaryQuantityBonus,
		cast(isnull(bl.SecondaryQuantityBonus,0.0) as decimal(38,15)) * mpt.ParcelQtyFactorApplied as SubResourcesMaterialsSecondaryQuantityBonus,
		bl.PrimaryUnitKey,
		bl.SecondaryUnitKey
	from FactResourceMaterialLossBonus bl
	inner join DimMaterial dmloss on dmloss.MaterialKey = bl.MaterialKey
	cross apply (select mpt.* 
	               from FactMaterialProcessTime mpt
				   inner join DimMaterial dmmpt on dmmpt.MaterialKey = mpt.MaterialKey
				  where  mpt.AreaKey = bl.AreaKey and 
					mpt.ResourceKey = bl.ResourceKey and 
					mpt.FlowKey = BL.FlowKey and 
					mpt.StepKey = bl.StepKey and
					mpt.DateKey between CAST(CONVERT(char(8),dateadd(day, -1, bl.UTCTrackInOperationEndTime),112) AS INT) 
						and CAST(CONVERT(char(8),dateadd(day, +1, bl.UTCTrackInOperationEndTime),112) AS INT) and
					(@HasAreaFilter = 0 OR mpt.AreaKey IN (SELECT AreaKey FROM @AreaTab)) and
					(@HasShifts = 0 OR mpt.ShiftKey IN (SELECT ShiftKey FROM @ShiftsTab)) and
					(@HasResources = 0 OR mpt.ResourceKey IN (SELECT ResourceKey FROM @ResourcesTab)) and
					mpt.UTCTrackInDateTime = bl.UTCTrackInOperationEndTime and
					dmmpt.MaterialId = dmloss.MaterialID
				) mpt
	outer apply (select top(1) mpt.* 
	               from FactMaterialProcessTime mpt
				  where  mpt.AreaKey = bl.AreaKey and 
					mpt.ResourceKey = bl.ParentResourceKey and 
					(@HasAreaFilter = 0 OR bl.AreaKey IN (SELECT AreaKey FROM @AreaTab)) and
					(@HasShifts = 0 OR bl.ShiftKey IN (SELECT ShiftKey FROM @ShiftsTab)) and
					(@HasResources = 0 OR bl.ResourceKey IN (SELECT ResourceKey FROM @ResourcesTab))and
-- gives a 5 Day margin between parent trackin and submaterials trackin
					mpt.UTCTrackInDateTime between dateadd(day, -5, bl.UTCTrackInOperationEndTime) and bl.UTCTrackInOperationEndTime and
					mpt.DateKey between CAST(CONVERT(char(8),dateadd(day, -5, bl.UTCTrackInOperationEndTime),112) AS INT) 
						and CAST(CONVERT(char(8),dateadd(day, +1, bl.UTCTrackInOperationEndTime),112) AS INT) and
					mpt.MaterialKey = bl.ParentMaterialKey and
					bl.LastRelatedOperationName = 'TrackOut' 
				 order by UTCOperationEndTime desc
				) lastParentState
	WHERE bl.isResourceRelated = 1 and bl.ParentResourceKey <> (select top(1) resourceKey from ResourceUndefinedKey) and (@HasAreaFilter = 0 OR bl.AreaKey IN (SELECT AreaKey FROM @AreaTab)) and
					(@HasShifts = 0 OR bl.ShiftKey IN (SELECT ShiftKey FROM @ShiftsTab)) and
					(@HasResources = 0 OR bl.ResourceKey IN (SELECT ResourceKey FROM @ResourcesTab))
END

	CREATE CLUSTERED INDEX TMP_INDEX_#V_FACTMATERIALLOSSBONUSTIME_WITH_SECQUANTITYNORMALIZED ON #V_FACTMATERIALLOSSBONUSTIME_WITH_SECQUANTITYNORMALIZED (DateKey, TimeKey, ShiftDateKey);
 
/* Processed Materials */
 BEGIN 
     SELECT a.ShiftDateKey
            ,a.shiftkey 
            ,a.AreaKey 
            ,a.ResourceKey
            ,SUM(ParcelProcessingQuantity) AS ProcessedQuantity
            ,SUM(ParcelInputQuantity) AS InputQuantity
						      ,CAST(SUM(ISNULL(lb.MaterialsPrimaryQuantityLoss,0))  AS DECIMAL(38,15)) AS MaterialsPrimaryQuantityLoss
						      ,CAST(SUM(ISNULL(lb.MaterialsSecondaryQuantityLoss,0))  AS DECIMAL(38,15)) AS MaterialsSecondaryQuantityLoss 
						      ,CAST(SUM(ISNULL(lb.MaterialsPrimaryQuantityBonus,0)) AS DECIMAl(38,15)) AS MaterialsPrimaryQuantityBonus
       INTO #MAT_PERF
       FROM (SELECT mat.shiftkey
                    ,mat.ShiftDateKey
                    ,mat.AreaKey
                    ,mat.ResourceKey
                    ,SUM(ISNULL(mat.ParcelOutTotalQuantityNormalized,0)) AS ParcelProcessingQuantity
                    ,SUM(ISNULL(mat.ParcelInTotalQuantityNormalized,0)) AS ParcelInputQuantity
               FROM #ELIGIBLE_RESOURCES ER    
               INNER HASH JOIN FactMaterialProcessTime mat ON (ER.ResourceKey = mat.ResourceKey)     
               INNER HASH JOIN dbo.DimArea DA ON (DA.AreaKey = mat.AreaKey)
               INNER HASH JOIN dbo.DimProduct DP ON (DP.ProductKey = mat.ProductKey)
               LEFT OUTER HASH JOIN @AreaTab AT ON (AT.AreaKey = DA.AreaKey)
               LEFT OUTER HASH JOIN @FacilityTab F ON (F.FacilityKey = DA.FacilityKey)
               LEFT OUTER HASH JOIN @ShiftsTab SF ON (SF.ShiftKey = mat.ShiftKey)
              WHERE (@HasAreaFilter = 0 OR AT.AreaKey > 0)
               AND (@HasFacilityFilter = 0 OR F.FacilityKey > 0)
--shift and time filter
               AND  mat.ShiftDateKey between @DateStartHostInt AND @DateEndHostInt 
               AND mat.DateKey between @DateStartHostIntPartId AND @DateEndHostIntPartId
-- parcel should be included within the timeframe SELECTed by users
               AND mat.LC1ParcelStartDateTime between @DateStartHost AND @DateEndHost
-- AND mat.LC1ParcelEndDateTime between @DateStartHost AND @DateEndHost
               AND (@HasShifts = 0 OR SF.ShiftKey > 0)
               AND (@ProductName IS NULL OR DP.ProductName LIKE '%'+@ProductName+'%')
            GROUP BY mat.shiftkey
                     ,mat.ShiftDateKey
                     ,mat.AreaKey
                     ,mat.ResourceKey
          ) a
            LEFT JOIN (SELECT bl.shiftkey
                              ,bl.ShiftDateKey
                              ,bl.AreaKey
                              ,bl.ResourceKey,
                              SUM (ISNULL(TotalPrimaryQuantityLossNormalized,0) + ISNULL(TotalSubResourcesPrimaryQuantityLossNormalized,0))  MaterialsPrimaryQuantityLoss,
                              SUM (ISNULL(TotalSecondaryQuantityLossNormalized,0) + ISNULL(TotalSubResourcesSecondaryQuantityLossNormalized,0))  MaterialsSecondaryQuantityLoss, 
                              SUM (ISNULL(TotalPrimaryQuantityBonusNormalized,0) + ISNULL(TotalSubResourcesPrimaryQuantityBonusNormalized,0)) MaterialsPrimaryQuantityBonus
                         FROM #V_FACTMATERIALLOSSBONUSTIME_WITH_SECQUANTITYNORMALIZED bl            
                         INNER HASH JOIN #ELIGIBLE_RESOURCES ER ON (ER.ResourceKey = bl.ResourceKey)
                         INNER HASH JOIN dbo.DimArea DA ON (DA.AreaKey = bl.AreaKey)
                         INNER HASH JOIN dbo.DimProduct DP ON (DP.ProductKey = bl.ProductKey)
						             inner HASH JOIN dbo.DimMaterial DM on (DM.MaterialKey = bl.MaterialKey) 
                         LEFT OUTER HASH JOIN @AreaTab                 AT ON (AT.AreaKey = bl.AreaKey)
                         LEFT OUTER HASH JOIN @FacilityTab             F ON (F.FacilityKey = DA.FacilityKey)
                         LEFT OUTER HASH JOIN @ShiftsTab               SF ON (SF.ShiftKey = bl.ShiftKey)  
                         WHERE bl.ShiftDateKey between @DateStartHostInt AND @DateEndHostInt 
                           AND bl.DateKey between @DateStartHostIntPartId AND @DateEndHostIntPartId        
                           AND (@HasAreaFilter = 0 OR AT.AreaKey > 0)
                           AND (@HasFacilityFilter = 0 OR F.FacilityKey > 0)
                           AND (@HasShifts = 0 OR SF.ShiftKey > 0)
                           AND (@ProductName IS NULL OR DP.ProductName LIKE '%'+@ProductName+'%')
						   AND UPPER(DM.Form) like('PALLET') 
						   AND UPPER(DM.Type) IN ('OUTSORTED', 'REWORK', 'REPAIR', 'SCRAP') 
						   
                        GROUP BY bl.ShiftKey
                                 ,bl.ShiftDateKey
                                 ,bl.AreaKey
                                 ,bl.ResourceKey
                      ) lb ON lb.shiftkey = a.shiftkey 
                          AND lb.ShiftDateKey = a.ShiftDateKey 
                          AND lb.ResourceKey = a.ResourceKey 
                          AND a.AreaKey = lb.AreaKey
      GROUP BY a.shiftkey
               ,a.ShiftDateKey
               ,a.AreaKey
               ,a.ResourceKey

 SELECT RMP.ResourceKey
        ,RMP.AreaKey 
        ,SUM(RMP.ProcessedQuantity)            ProcessedQuantity
        ,SUM(RMP.InputQuantity)                InputQuantity
        ,(SUM(RMP.MaterialsPrimaryQuantityLoss)+ SUM(RMP.MaterialsSecondaryQuantityLoss)) LossQuantity 
   INTO #PROCESSED_MATERIALS
   FROM (SELECT matperf.ResourceKey
                ,matperf.AreaKey
                ,matperf.ProcessedQuantity
                ,matperf.InputQuantity
                ,ISNULL(matperf.MaterialsPrimaryQuantityLoss,0.0)  AS MaterialsPrimaryQuantityLoss
                ,ISNULL(matperf.MaterialsSecondaryQuantityLoss,0.0)  AS MaterialsSecondaryQuantityLoss 
                ,ISNULL(matperf.MaterialsPrimaryQuantityBonus,0.0) AS MaterialsPrimaryQuantityBonus
           FROM #MAT_PERF AS matperf
        )RMP
   GROUP BY RMP.ResourceKey, RMP.AreaKey
   OPTION(RECOMPILE);

  CREATE CLUSTERED INDEX TMP_IDX_PROCESSED_MATERIALS ON #PROCESSED_MATERIALS(ResourceKey, AreaKey );
 END
 
 BEGIN
  SELECT MAX(IdealBaseCycleTime) IdealBaseCycleTime
         ,FIQ.ResourceKey
         ,DateKey
         ,ShiftKey
         ,AreaKey
    INTO #RES_IDEAL_QTY
    FROM FactResourceIdealQuantity  FIQ
    JOIN #ELIGIBLE_RESOURCES        ER On FIQ.ResourceKey= ER.ResourceKey
   WHERE FIQ.ShiftDateKey BETWEEN @DateStartHostInt AND @DateEndHostInt 
     AND FIQ.DateKey BETWEEN @DateStartHostIntPartId AND @DateEndHostIntPartId
    GROUP BY FIQ.ResourceKey
            ,DateKey
            ,ShiftKey
            ,AreaKey
   CREATE CLUSTERED INDEX IDC_FRIQ ON #RES_IDEAL_QTY (ResourceKey, AreaKey, DateKey, ShiftKey,IdealBaseCycleTime);
 END 

-- ELIGIBLE RESOURCE RECORDS
 BEGIN
  SELECT ResourceKey
         ,FacilityKey
         ,AreaKey
         ,StateModelStateReason
         ,MIN(ShiftStartDateTime)       StartTimeStamp
         ,MAX(ShiftEndDateTime)         EndTimeStamp
         ,SUM(UpDuration)               UpDuration
         ,SUM(DownToUpTransition)       DownToUpTransition
         ,SUM(UpToDownTransition)       UpToDownTransition
         ,SUM(ProductiveDuration)       ProductiveDuration
         ,SUM(StandbyDuration)          StandbyDuration
         ,SUM(EngineeringDuration)      EngineeringDuration
         ,SUM(UnscheduledDownDuration)  UnscheduledDownDuration
         ,SUM(ResourceGlobalTime)       ResourceGlobalTime
         ,SUM(ResourceDownTime)         ResourceDownTime	 
		       ,SUM(ResourceUpTime)           ResourceUpTime
		       ,SUM(ResourceNumberOfFailures) ResourceNumberOfFailures
		       ,SUM(ResourceNumberOfRepairs)  ResourceNumberOfRepairs
         ,SUM(ResourceLoadingTime)      ResourceLoadingTime
         ,SUM(ResourceRunningTime)      ResourceRunningTime
         ,SUM(ResourceSetupTime)        ResourceSetupTime
         ,SUM(ResourceStopTime)         ResourceStopTime
         ,SUM(IdealQuantity)            ResourceIdealQuantity
         ,MAX(IdealBaseCycleTime)       IdealBaseCycleTime
     INTO #ELIGIBLE_RESOURCES_CONDENSED
     FROM (SELECT  
                  f.ResourceKey                         ResourceKey
                  ,f.DateKey                            DateKey
                  ,f.ShiftDateKey                       ShiftDateKey
                  ,f.ShiftKey                           ShiftKey
                  ,cds.LC1StartDateTime                 ShiftStartDateTime
                  ,cds.LC1EndDateTime                   ShiftEndDateTime
                  ,f.AreaKey                            AreaKey
                  ,DA.FacilityKey                       FacilityKey
                  ,ISNULL(f.UpDuration, 0)              UpDuration
                  ,f.DownToUpTransition                 DownToUpTransition
                  ,f.UpToDownTransition                 UpToDownTransition
                  ,ISNULL(f.ProductiveDuration, 0)      ProductiveDuration
                  ,ISNULL(f.StandbyDuration, 0)         StandbyDuration
                  ,ISNULL(f.EngineeringDuration, 0)     EngineeringDuration
                  ,ISNULL(f.ScheduledDownDuration, 0)   ScheduledDownDuration
                  ,ISNULL(f.UnscheduledDownDuration, 0) UnscheduledDownDuration
                  ,ISNULL(f.DownDuration, 0)+ISNULL(f.UpDuration, 0)                 ResourceGlobalTime
			               ,ISNULL(f.UpDurationForTransitions, 0)   ResourceUpTime
			               ,ISNULL(f.DownDurationForTransitions, 0) ResourceDownTime
			               ,ISNULL(f.DownToUpTransition,0)          ResourceNumberOfRepairs
		               	,ISNULL(f.UpToDownTransition,0)          ResourceNumberOfFailures
                  ,CASE WHEN DRSM.StateModelStateName NOT IN ('NOT PLANNED TIME','UN-PLANNED TIME')
                            THEN COALESCE(f.UpDuration,f.DownDuration,0)    
                   END                                     ResourceLoadingTime
                  ,CASE WHEN DRSM.StateModelStateName NOT IN ('NOT PLANNED TIME','UN-PLANNED TIME','WAITING TIME','BREAKDOWN TIME MACHINE')
                            THEN COALESCE(f.UpDuration,f.DownDuration,0)    
                   END                                     ResourceRunningTime
                  ,CASE WHEN DRSM.StateModelStateName ='BREAKDOWN TIME MACHINE'
                            THEN ISNULL(f.DownDuration,0)      
                   END                                     ResourceStopTime
                  ,ISNULL(f.SetupTime,0)                   ResourceSetupTime
                  ,CASE WHEN DRSM.StateModelStateName ='BREAKDOWN TIME MACHINE'
                            THEN MainStateModelStateReason
                   END                                     StateModelStateReason 
                  ,CASE WHEN FIQ.IdealBaseCycleTime IS NULL THEN NULL
                        ELSE CASE WHEN DRSM.StateModelStateName NOT IN ('NOT PLANNED TIME','UN-PLANNED TIME','BREAKDOWN TIME MACHINE')
                                      THEN COALESCE(f.UpDuration,f.DownDuration,0) 
                                   ELSE 0   
                             END / FIQ.IdealBaseCycleTime
                   END IdealQuantity
                  ,ISNULL(FIQ.IdealBaseCycleTime,0)    IdealBaseCycleTime
              FROM [dbo].[V_FactResource]              f
              INNER HASH JOIN #ELIGIBLE_RESOURCES      ER  ON (ER.ResourceKey = f.ResourceKey) 
              INNER  JOIN #RES_IDEAL_QTY               FIQ ON f.ResourceKey= FIQ.ResourceKey 
                                                          AND f.AreaKey=FIQ.AreaKey
                                                          AND f.DateKey = FIQ.DateKey
                                                          AND f.ShiftKey = FIQ.ShiftKey                                        
              INNER JOIN FactShift                     CDS ON (f.ShiftKey = CDS.ShiftKey AND CDS.DateKey = f.ShiftDateKey AND CDS.AreaKey = f.AreaKey)
              INNER HASH JOIN dbo.DimArea              DA  ON (DA.AreaKey = f.AreaKey)
              LEFT OUTER HASH JOIN @AreaTab            AT  ON (AT.AreaKey = f.AreaKey)
              LEFT OUTER HASH JOIN @FacilityTab        FT  ON (FT.FacilityKey = DA.FacilityKey)
              LEFT OUTER HASH JOIN @ShiftsTab          SF  ON (SF.ShiftKey = f.ShiftKey)      
              INNER HASH JOIN DimResourceStateModel   DRSM ON DRSM.ResourceStateModelKey = f.ResourceStateModelKey
              INNER HASH JOIN DimDate DD ON F.DateKey = DD.DateKey 
                                            AND DD.FullDateAlternateKey BETWEEN @DateStartHost-1 AND @DateEndHost
              WHERE (@HasAreaFilter = 0 OR AT.AreaKey > 0)
                AND (@HasFacilityFilter = 0 OR FT.FacilityKey > 0)
                AND f.ShiftDateKey between @DateStartHostInt AND @DateEndHostInt 
                AND f.DateKey between @DateStartHostIntPartId AND @DateEndHostIntPartId
--AND f.LC1OperationEndtime between @DateStartHost AND @DateEndHost
                AND CDS.LC1StartDatetime  between @DateStartHost AND  @DateEndHost    
--AND CDS.LC1EndDatetime  between @DateStartHost AND  @DateEndHost  
                AND (@HasShifts = 0 OR SF.ShiftKey > 0)
      ) DATA
  GROUP BY ResourceKey, FacilityKey, AreaKey,StateModelStateReason
  OPTION(RECOMPILE);
  CREATE CLUSTERED INDEX TMP_IDX_ELIGIBLE_RESOURCES_COND ON #ELIGIBLE_RESOURCES_CONDENSED(ResourceKey, FacilityKey, AreaKey );
 END
 
 SELECT ERR.ResourceKey                                ResourceKey
        ,DR.ResourceName                               Resource
        ,DR.Model                                      ResourceModel
        ,DR.ResourceType                               ResourceType
        ,ERR.StartTimeStamp                            StartTimeStamp
        ,ERR.EndTimeStamp                              EndTimeStamp
        ,ERR.FacilityKey                               FacilityKey
        ,DF.FacilityName                               Facility
        ,DF.FacilityDisplayOrder                       FacilityDisplayOrder
        ,ERR.AreaKey                                   AreaKey
        ,DA.AreaName                                   Area
        ,DA.AreaDisplayOrder                           AreaDisplayOrder
        ,ISNULL(PM.LossQuantity,0)                     ResourceLossQuantity
        ,ISNULL(PM.ProcessedQuantity,0)                ResourceProcessedQuantity
        ,ISNULL(PM.InputQuantity,0)                    ResourceInputQuantity
        ,UnscheduledDownDuration                       ResourceUnscheduledDownDuration
        ,ProductiveDuration
        ,PM.ProcessedQuantity
        ,PM.LossQuantity
        ,ERR.ResourceIdealQuantity
        ,ERR.IdealBaseCycleTime
		      ,ResourceNumberOfFailures
		      ,ResourceNumberOfRepairs
        ,ResourceUpTime
        ,ResourceDownTime
        ,ResourceLoadingTime
        ,ResourceRunningTime
        ,ResourceSetupTime
        ,ResourceStopTime
        ,StateModelStateReason 
        ,ISNULL(ERR.ResourceGlobalTime, 0)              ResourceGlobalTime
        ,CASE WHEN ISNULL(PM.InputQuantity, 0) = 0 
                  THEN 0
              ELSE CONVERT(DECIMAL(38,15),(PM.InputQuantity - PM.LossQuantity)) / (CONVERT(DECIMAL(38,15),PM.InputQuantity))
         END                                          ResourceRateOfQuality
         ,CASE WHEN ISNULL(ERR.ResourceLoadingTime, 0) = 0 
                  THEN 0
             ELSE CONVERT(DECIMAL(38,15), ISNULL(ERR.ResourceRunningTime, 0)) / CONVERT(DECIMAL(38,15),ERR.ResourceLoadingTime)
        END                                           ResourceAvailability
        ,CASE WHEN ISNULL(ERR.ResourceIdealQuantity, 0) = 0 
                  THEN 0
              ELSE CONVERT(DECIMAL(38,15),ISNULL(PM.ProcessedQuantity, 0)) / (CONVERT(DECIMAL(38,15),ERR.ResourceRunningTime)/CONVERT(DECIMAL(38,15),ERR.IdealBaseCycleTime))
         END                                          ResourcePerformance
    INTO #REPORT_DATA
    FROM #ELIGIBLE_RESOURCES_CONDENSED        ERR
    INNER HASH JOIN DimResource DR               ON DR.ResourceKey = ERR.ResourceKey
    INNER HASH JOIN DimArea DA                   ON DA.AreaKey = ERR.AreaKey
    INNER HASH JOIN DimFacility DF               ON DF.FacilityKey = ERR.FacilityKey
    LEFT HASH JOIN  #PROCESSED_MATERIALS      PM ON PM.ResourceKey = ERR.ResourceKey
                                                AND PM.AreaKey = ERR.AreaKey
                                                AND ERR.ResourceDownTime=0

    WHERE ERR.ResourceGlobalTime > 0
 OPTION(RECOMPILE);
 
 SELECT * 
   FROM #REPORT_DATA RD
   
 OPTION(RECOMPILE);
 DROP TABLE #REPORT_DATA;
 
END