/*
** Version History

** Version      Date         Author              Description 
** --------------------------------------------------------------------------------------------------------------------------------------------- 
** Sprint 18    13/Sep/2021  Miguel and Paulo S. Bug fixing repetead lines on the reclassifications data source
*/
CREATE OR ALTER PROCEDURE [Custom].[P_LoadFactMaterialProcessTimeWithReclassifications] 
( 
	@InfServiceHistoryId bigint = NULL, 
	@SupServiceHistoryId bigint = NULL, 
	@ResourceId bigint = NULL 
)
 
AS
BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET XACT_ABORT ON
	SET NOCOUNT ON

	DECLARE 
		@StartTranCount int, --Controls number of transactions
		@ErrorMessage nvarchar(max), 
		@ErrorSeverity int, 
		@ErrorState int;

	DECLARE 
		@TABLENAME VARCHAR(32) = 'FactMaterialProcessTime',
		@PROCNAME VARCHAR(64) = (SELECT OBJECT_NAME(@@PROCID)),
		@CurrentDatetime DATETIME = GETUTCDATE(),
		@StatusMessage NVARCHAR(256),
		@IsOtherFilterApplied BIT = (SELECT CASE WHEN @ResourceId IS NOT NULL THEN 1 ELSE 0 END),
		@SystemName NVARCHAR(512) = dbo.F_GetSystemName();

	DECLARE 
		@MinServiceHistoryId BIGINT, 
		@MaxServiceHistoryId BIGINT,
		@ODSLink NVARCHAR(512) = 'cm' + @SystemName + 'ODSLink',
		@ODSDataBase NVARCHAR(512) = @SystemName + 'ODS';
		
	DECLARE 
		@MinServDateTime DATETIME, 
		@MaxServDateTime DATETIME;

	BEGIN TRY
		SELECT @StartTranCount = @@TRANCOUNT;

		IF (@StartTranCount = 0)
			BEGIN TRANSACTION;
	
		-- Execute Start Execution
		EXEC [Control].[P_StartExecution] @ProcedureName = @PROCNAME, 
											@MinServiceHistoryIdCalculated = @MinServiceHistoryId OUTPUT, 
											@MaxServiceHistoryIdCalculated = @MaxServiceHistoryId OUTPUT, 
											@InferiorServiceHistoryId = @InfServiceHistoryId, 
											@SuperiorServiceHistoryId = @SupServiceHistoryId, 
											@OtherFilters = @IsOtherFilterApplied;

		-- Get Minimum and Maximum Service History Dates
		SELECT 
			@MinServDateTime = MinServDateTime, 
			@MaxServDateTime = MaxServDateTime 
		FROM [dbo].[F_GetMinAndMaxServiceTime] (@MinServiceHistoryId, @MaxServiceHistoryId);		
		
		-- Get Date Keys
		DECLARE 
			@MinServDateKey INT = [dbo].[F_GetDateKeyFromDateTime] (@MinServDateTime), 
			@MaxServDateKey INT = [dbo].[F_GetDateKeyFromDateTime] (@MaxServDateTime);

		-- Get Date Keys Prunings
		DECLARE 
			@MinServDateKeyPruning INT = [dbo].[F_GetDateKeyFromDateTime](@MinServDateTime - 1),
			@MaxServDateKeyPruning INT = [dbo].[F_GetDateKeyFromDateTime](@MaxServDateTime + 1);
		
		IF(OBJECT_ID(N'tempdb..#ResourceStateReclassifications') IS NOT NULL)
			DROP TABLE #ResourceStateReclassifications;
			
		IF(OBJECT_ID(N'tempdb..#FactsReclassification') IS NOT NULL)
			DROP TABLE #FactsReclassification;

 CREATE TABLE #ResourceStateReclassifications
		(
			StartServiceHistoryId BIGINT,
			StartOperationHistorySeq BIGINT,
			StartModifiedOn DATETIME,
			EndServiceHistoryId BIGINT,
			EndOperationHistorySeq BIGINT,
			EndModifiedOn DATETIME,
			ResourceId BIGINT,
			StateModelId BIGINT,
			StateModelStateId BIGINT,
			StateModelStateReason NVARCHAR(512),
			ServiceHistoryId BIGINT,
			OperationHistorySeq BIGINT,
			ModifiedOn DATETIME,
			ModifiedBy VARCHAR(64)
		);
	
		-- Get Resource State Reclassification for the specific Service History Ids
		DECLARE @Query NVARCHAR(MAX) = '
		SELECT 
			[ServiceHistoryIdStart],
			[OperationHistorySequenceStart],
			[ServiceHistoryIdEnd],
			[OperationHistorySequenceEnd],
			[ResourceId],
			[StateModelId],
			[StateModelStateId],
			[StateModelStateReason],
			[ServiceHistoryId],
			[OperationHistorySeq],
			[ModifiedOn],
			[ModifiedBy]
		FROM 
		(
			SELECT
				[ServiceHistoryIdStart],
				[OperationHistorySequenceStart],
				[ServiceHistoryIdEnd],
				[OperationHistorySequenceEnd],
				[ResourceId],
				[StateModelId],
				[StateModelStateId],
				[StateModelStateReason],
				[ServiceHistoryId],
				[OperationHistorySeq],
				[ModifiedOn],
				[ModifiedBy],
				ROW_NUMBER() OVER (PARTITION BY [ResourceId], [ServiceHistoryIdStart], [OperationHistorySequenceStart], [ServiceHistoryIdEnd], [OperationHistorySequenceEnd] ORDER BY [ServiceHistoryId] DESC, [ModifiedOn] DESC, [OperationHistorySeq] DESC) AS RowNumber
			FROM ' + @ODSLink + '.' + @ODSDataBase + '.UserDataModel.T_CustomResourceStateReclassificationHistory 
			WHERE @ResourceId IS NULL 
				OR [ResourceId] = @ResourceId
		) AS ResourceStateReclassifications
		WHERE RowNumber = 1
			AND [ServiceHistoryIdEnd] BETWEEN @MinServiceHistoryId AND @MaxServiceHistoryId';
					
		INSERT INTO #ResourceStateReclassifications (StartServiceHistoryId, StartOperationHistorySeq, EndServiceHistoryId, EndOperationHistorySeq
			, ResourceId, StateModelId, StateModelStateId, StateModelStateReason, ServiceHistoryId, OperationHistorySeq
			, ModifiedOn, ModifiedBy)
		EXECUTE sp_executesql @Query, N'@MinServiceHistoryId BIGINT, @MaxServiceHistoryId BIGINT, @ResourceId BIGINT', @MinServiceHistoryId = @MinServiceHistoryId, @MaxServiceHistoryId = @MaxServiceHistoryId, @ResourceId = @ResourceId;
	 
  -- Update with occurrences' start and end modifiedon to be used in determining if not only an occurrence is
		-- within a range of service history Ids but also if the date of modification is inside, to cover cases of concurrent
		-- service history Ids that may generate an newer Service history to actually finish before the older one
		SET @Query = N'
			UPDATE RSR SET RSR.[StartModifiedOn] = RHS.[ModifiedOn]
				, RSR.[EndModifiedOn] = RHE.[ModifiedOn]
			FROM #ResourceStateReclassifications RSR
			INNER JOIN ' + @ODSLink + '.' + @ODSDataBase + '.CoreDataModel.T_ResourceHistory RHS ON RHS.[ResourceId] = RSR.[ResourceId]
				AND RHS.[ServiceHistoryId] = RSR.[StartServiceHistoryId]
				AND RHS.[OperationHistorySeq] = RSR.[StartOperationHistorySeq]
			INNER JOIN ' + @ODSLink + '.' + @ODSDataBase + '.CoreDataModel.T_ResourceHistory RHE ON RHE.[ResourceId] = RSR.[ResourceId]
				AND RHE.[ServiceHistoryId] = RSR.[EndServiceHistoryId]
				AND RHE.[OperationHistorySeq] = RSR.[EndOperationHistorySeq]'
        
		EXECUTE sp_executesql @Query
		
		CREATE TABLE #FactsReclassification
		(
			[DateKey] [int] NOT NULL,
			[TimeKey] [int] NOT NULL,
			[ResourceKey] [bigint] NOT NULL,
			[MaterialKey] [bigint] NOT NULL,
			[AreaKey] [bigint] NOT NULL,
			[ProductKey] [bigint] NOT NULL,
			[FlowKey] [bigint] NOT NULL,
			[StepKey] [bigint] NOT NULL,
			[UTCParcelStartDateTime] [datetime] NOT NULL,
			[TrackOutServiceHistoryId] [bigint] NOT NULL,
			[SEMI-E10] [nvarchar](512) NULL,
			CONSTRAINT [PK_TempFactMaterialProcessTime] PRIMARY KEY CLUSTERED 
			(
				[DateKey] ASC,
				[TimeKey] ASC,
				[ResourceKey] ASC,
				[MaterialKey] ASC,
				[AreaKey] ASC,
				[ProductKey] ASC,
				[FlowKey] ASC,
				[StepKey] ASC,
				[UTCParcelStartDateTime] ASC,
				[TrackOutServiceHistoryId] ASC
			)
		);
		
		-- Get Fact with reclassifications
		INSERT INTO #FactsReclassification
		SELECT
			FMPT.[DateKey],
			FMPT.[TimeKey],
			FMPT.[ResourceKey],
			FMPT.[MaterialKey],
			FMPT.[AreaKey],
			FMPT.[ProductKey],
			FMPT.[FlowKey],
			FMPT.[StepKey],
			FMPT.[UTCParcelStartDateTime],
			FMPT.[TrackOutServiceHistoryId],
			DRSM.[StateModelStateSemiE10Value] AS [SEMI-E10]
		FROM dbo.FactMaterialProcessTime AS FMPT
		INNER JOIN dbo.DimResource AS DR
			ON DR.ResourceKey = FMPT.ResourceKey
		INNER JOIN #ResourceStateReclassifications AS RSR
			ON RSR.[ResourceId] = DR.[ResourceId]
			AND FMPT.[ServiceHistoryId] BETWEEN RSR.[StartServiceHistoryId] AND RSR.[EndServiceHistoryId]
            AND FMPT.UTCTrackOutDateTime BETWEEN RSR.[StartModifiedOn] AND RSR.[EndModifiedOn]
			AND 
			(
				FMPT.[ServiceHistoryId] = RSR.[StartServiceHistoryId] AND FMPT.[OperationHistorySeq] >= RSR.[StartOperationHistorySeq]
				OR FMPT.[ServiceHistoryId] = RSR.[EndServiceHistoryId] AND FMPT.OperationHistorySeq < RSR.[EndOperationHistorySeq]
				OR (FMPT.[ServiceHistoryId] > RSR.[StartServiceHistoryId] AND FMPT.ServiceHistoryId < RSR.[EndServiceHistoryId])
			)
		INNER JOIN dbo.DimResourceStateModel AS DRSM
			ON DRSM.[StateModelId] = RSR.[StateModelId]
			AND DRSM.[StateModelStateId] = RSR.[StateModelStateId]
		WHERE FMPT.[ServiceHistoryId] BETWEEN @MinServiceHistoryId AND @MaxServiceHistoryId;

		-- Update the Fact Table with the reclassifications
		MERGE INTO dbo.FactMaterialProcessTime AS FACT
		USING #FactsReclassification AS Reclassifications
		ON FACT.[DateKey] = Reclassifications.[DateKey]
			AND FACT.[TimeKey] = Reclassifications.[TimeKey]
			AND FACT.[ResourceKey] = Reclassifications.[ResourceKey]
			AND FACT.[MaterialKey] = Reclassifications.[MaterialKey]
			AND FACT.[AreaKey] = Reclassifications.[AreaKey]
			AND FACT.[ProductKey] = Reclassifications.[ProductKey]
			AND FACT.[FlowKey] = Reclassifications.[FlowKey]
			AND FACT.[StepKey] = Reclassifications.[StepKey]
			AND FACT.[UTCParcelStartDateTime] = Reclassifications.[UTCParcelStartDateTime]
			AND FACT.[TrackOutServiceHistoryId] = Reclassifications.[TrackOutServiceHistoryId]
		WHEN MATCHED THEN
			UPDATE SET
				[SEMI-E10] = Reclassifications.[SEMI-E10];
				
		SET @StatusMessage = OBJECT_NAME(@@PROCID) + ': ' + cast(@@ROWCOUNT as varchar) + ' row(s) merged into [dbo].[FactMaterialProcessTime]'
		RAISERROR (@StatusMessage, 0, 1) WITH NOWAIT;
		
		-- Execute Stop Execution
		EXEC [Control].[P_StopExecution] @ProcedureName = @PROCNAME, 
											@StatusMsg = @StatusMessage;

		-- If There was no transaction on the beginning of the exception, a new one was created and has to be committed.
		IF(@StartTranCount = 0)
			COMMIT TRANSACTION;			
		
	END TRY
	BEGIN CATCH
		IF XACT_STATE() <> 0 AND @starttrancount = 0 
			ROLLBACK TRANSACTION;

		EXEC Control.P_StopExecution @PROCNAME;

		SELECT 
			@ErrorMessage = ERROR_MESSAGE() + ' Line ' + CAST(ERROR_LINE() AS NVARCHAR(5)), 
			@ErrorSeverity = ERROR_SEVERITY(), 
			@ErrorState = ERROR_STATE();

		RAISERROR (@ErrorMessage, @ErrorSeverity, @ErrorState);

	END CATCH

END;


