
/******************************
** Name: Custom.P_GetProductSetupTimeAggregated
** Description: Procedure to get the products setup times aggregated by product from and product to
** Author: Paulo Soares
** Date: 12-Feb-2021
**************************

** Version History

** Version    Date          Author                       Description 
** ----------------------------------------------------------------------------------------------------------------------------------------                    
** Sprint 4   22/Feb/2021  Paulo S. and Nuno Pacheco    Get the data from the products setup times aggregated by product from and product to 
** Sprint 33  29/Abr/2022  Simon Sehur                  Change Week and Day filters to DateFrom and DateTo 
** Sprint 6  20/Fev/2022   Diogo Silva					Remove MonthNumberofYear attribute and
*/

-- The SetupTimeFilter parameter can take 3 values:
-- 0 -> Display all setup times
-- 1 -> Display only setup times when the products are different
-- 2 -> Display only setup times when the products are the same

CREATE OR ALTER   PROCEDURE [Custom].[P_GetProductSetupTimeAggregated]
  @FacilityName NVARCHAR(MAX) = NULL,
  @AreaName NVARCHAR(MAX) = NULL,
  @ResourceName NVARCHAR(MAX) = NULL,
  @ShiftName NVARCHAR(MAX) = NULL,
  @CalendarYear INT,
  @DateFrom DATETIME = NULL,
  @DateTo DATETIME  = NULL,
  @ShowOnlyOvertime BIT = 0,
  @SetupTimeFilter TINYINT = 0

AS
BEGIN
/*
  declare
 @FacilityName NVARCHAR(MAX)=N'Flatline Production;Flatline Warehouse;LS Facility;Lubawa Components;Lubawa Logistics;Lubawa Pigment;Lubawa Veneer;SP Facility',
 @AreaName NVARCHAR(MAX)=N'LC Internal Warehouse;LP Packing;LP Lacquering;LP Homag;LP CNC;LP Inspection;Cutting;Lacquering;Packing;Inspection;Warehouse;FG Warehouse;LS Area 1;LS Area 2;LS Inspection;LS Warehouse;SP Area 1;SP Warehouse',
 @ResourceName NVARCHAR(MAX)=N'13C1R;13C2R;13C3R;13C4R;13C5R;13C6R;13C7R;13C8R;13C9R;13HAR;13HBR;13HCR;14LBR;14LCR;15GAR;15GBR;15GCR;262_13HBR;262_14LBR;Cutting Line 1;Cutting Line 2;Cutting Line 3;Cutting Line Without ERP Code;Glue Feeder Line 1 - 2;Kallfass;Lacquering Line 1;Lacquering Line 2;Lacquering Line 3;Lacquering Line 4;LS A1 Line 1;LS A1 Line 2;LS A2 Line 1;LS A2 Line 2;Packing Line 1;Packing Line 2;ProcessingResource1;ProcessingResource2;SP Line 1;SP Line 2;Test Resource 1;Test Resource 2;Test Resource 3;Test Resource 4',
 @CalendarYear INT=N'2021',
 @ShiftName NVARCHAR(MAX)=N'Afternoon Shift;Morning Shift;Night Shift;Nigth Shift',
 @MonthNumberOfYear INT=N'0',
 @WeekNumberOfYear INT=N'0',
 @DayNumberOfMonth INT=N'0',
 @ShowOnlyOvertime BIT = 0,
 @SetupTimeFilter TINYINT = 0,
 @DateFrom DATETIME = '2022-04-01',
 @DateTo DATETIME = '2022-05-01'
*/ 

-- SET NOCOUNT ON added to prevent extra result sets from interfering with SELECT statements.
 SET NOCOUNT ON;

-- DECLARE VARIABLES
 DECLARE @Delimiter NVARCHAR(1) = ';'

--IF @WeekNumberOfYear = 0 SET @WeekNumberOfYear = NULL
--IF @DayNumberOfMonth = 0 SET @DayNumberOfMonth = NULL

/* Create temporary tables */

-- Temporary table -> Resource
 IF(OBJECT_ID('tempdb..#Resource') IS NOT NULL) 
  DROP TABLE #Resource;

 CREATE TABLE #Resource
 (
  [Name] NVARCHAR(MAX)
 );

 IF(@ResourceName IS NOT NULL)
 BEGIN
   INSERT INTO #Resource
   SELECT item FROM [Datasets].[fnSplit](@ResourceName, @Delimiter);
 END

-- Temporary table -> Facility
 IF(OBJECT_ID('tempdb..#Facility') IS NOT NULL) 
  DROP TABLE #Facility;

 CREATE TABLE #Facility
 (
  [Name] NVARCHAR(MAX)
 );

 IF(@FacilityName IS NOT NULL)
 BEGIN
   INSERT INTO #Facility 
   SELECT item FROM [Datasets].[fnSplit](@FacilityName, @Delimiter);
 END

-- Temporary table -> Area
 IF(OBJECT_ID('tempdb..#Area') IS NOT NULL) 
  DROP TABLE #Area;

 CREATE TABLE #Area
 (
  [Name] NVARCHAR(MAX)
 );

 IF(@AreaName IS NOT NULL)
 BEGIN
   INSERT INTO #Area 
   SELECT item FROM [Datasets].[fnSplit](@AreaName, @Delimiter);
 END


-- Temporary table -> ShiftDefinitionShift
 IF(OBJECT_ID('tempdb..#ShiftDefinitionShift') IS NOT NULL) 
  DROP TABLE #ShiftDefinitionShift;

 CREATE TABLE #ShiftDefinitionShift
 (
  [Name] NVARCHAR(MAX)
 );

 IF(@ShiftName IS NOT NULL)
 BEGIN
   INSERT INTO #ShiftDefinitionShift 
   SELECT item FROM [Datasets].[fnSplit](@ShiftName, @Delimiter);
 END


 SELECT DPFrom.ProductName                      ProductFrom,
        DPFrom.Description                      ProductFromDescription,
        DPTo.ProductName                        ProductTo,
        DPTo.Description                        ProductToDescription,
        COUNT(FP.LC1DateKey)                    NumberOfSetups,
        AVG(FP.CalculatedSetupTime)             AvgSetupTimeInSeconds,
        AVG(FP.ExpectedSetupTime)               AvgSetupTargetTimeInSeconds,
        RIGHT('0' + CAST(CAST(AVG(FP.CalculatedSetupTime) AS INT)/ 3600 AS VARCHAR),2) + ':' +
        RIGHT('0' + CAST((CAST(AVG(FP.CalculatedSetupTime) AS INT) / 60) % 60 AS VARCHAR),2) + ':' +
        RIGHT('0' + CAST(CAST(AVG(FP.CalculatedSetupTime) AS INT) % 60 AS VARCHAR),2)                 AvgSetupTime, 
        RIGHT('0' + CAST(CAST(AVG(FP.ExpectedSetupTime) AS INT)/ 3600 AS VARCHAR),2) + ':' +
        RIGHT('0' + CAST((CAST(AVG(FP.ExpectedSetupTime) AS INT) / 60) % 60 AS VARCHAR),2) + ':' +
        RIGHT('0' + CAST(CAST(AVG(FP.ExpectedSetupTime) AS INT) % 60 AS VARCHAR),2)                   AvgSetupTargetTime
   FROM [Custom].[FactProductSetupTime] FP
   INNER JOIN [dbo].[DimProduct] DPFrom ON DPFrom.ProductKey = FP.ProductFromKey
   INNER JOIN [dbo].[DimProduct] DPTo ON DPTo.ProductKey = FP.ProductToKey
   INNER JOIN [dbo].[DimResource] R ON R.ResourceKey = FP.ResourceKey
   INNER JOIN [dbo].[DimFacility] F ON F.FacilityKey = FP.FacilityKey
   INNER JOIN [dbo].[DimArea] A ON A.AreaKey = FP.AreaKey
   INNER JOIN [dbo].[DimMaterial] PO ON PO.MaterialKey = FP.MaterialKey
   INNER JOIN [dbo].[DimShift] S ON S.ShiftKey = FP.ShiftKey
   INNER JOIN [dbo].[DimDate] D ON D.DateKey = FP.DateKey
  WHERE (@ResourceName IS NULL OR EXISTS (SELECT [Name] FROM #Resource T WHERE ResourceName = T.[Name]))
    AND (@FacilityName IS NULL OR EXISTS (SELECT [Name] FROM #Facility T WHERE FacilityName = T.[Name]))
    AND (@AreaName IS NULL OR EXISTS (SELECT [Name] FROM #Area T WHERE AreaName = T.[Name]))
    AND (@ShiftName IS NULL OR EXISTS (SELECT [Name] FROM #ShiftDefinitionShift T WHERE ShiftDefinitionShiftName = T.[Name]))
    AND D.CalendarYear = @CalendarYear
 
	AND D.FullDateAlternateKey between @DateFrom and @DateTo

	

    AND (@SetupTimeFilter = 0 
     OR (@SetupTimeFilter = 1 AND DPFrom.ProductName <> DPTo.ProductName)
     OR (@SetupTimeFilter = 2 AND DPFrom.ProductName = DPTo.ProductName))
 GROUP BY DPFrom.ProductName,
          DPFrom.Description,
          DPTo.ProductName,
          DPTo.Description,
          ExpectedSetupTime
 HAVING @ShowOnlyOvertime IS NULL OR @ShowOnlyOvertime = 0 
     OR (@ShowOnlyOvertime = 1 AND AVG(FP.ExpectedSetupTime)- AVG(FP.CalculatedSetupTime) < 0)

OPTION (RECOMPILE);
END