SET ANSI_NULLS, QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[P_LoadStagingTables]
	@InfServiceHistoryId bigint = NULL, @SupServiceHistoryId bigint = NULL
WITH ENCRYPTION
AS
BEGIN
	
-- SET NOCOUNT ON added to prevent extra result sets from
-- interfering with SELECT statements.

	SET XACT_ABORT ON;
	SET NOCOUNT ON;

	DECLARE @Message nvarchar(max)
	DECLARE @TableName nvarchar(50)
	DECLARE @StartTime datetime
	DECLARE @EndTime datetime
	DECLARE @RowCount int

-- Get configuration for SPC points grace period in which datapoint changes are considered (in hours)	
	DECLARE @SPCPointRetentionReady bigint = CAST([dbo].[F_GetConfigStringValue] ('/Cmf/System/Configuration/SPC/DataWarehouseAggregationDelay/', '8') AS bigint); -- TBD read from config
	DECLARE @SPCPointRetentionMinDate datetime = DATEADD(hh, (-1)*@SPCPointRetentionReady, GETUTCDATE());	
	DECLARE @SPCCreateServiceHistoryId bigint = [dbo].[F_GetMinServiceHistoryIdForDate](@SPCPointRetentionMinDate);

--Controls number of transactions
	DECLARE @starttrancount int

	declare @ErrorMessage nvarchar(max), 
		    @ErrorSeverity int, 
			@ErrorState int;

	DECLARE @PROCNAME varchar (64); 
	SELECT @PROCNAME = OBJECT_NAME(@@PROCID);

	DECLARE @CurrentDatetime datetime = getUTCdate();
	DECLARE @StatusMessage nvarchar(256);
	
	DECLARE @IsOtheFilterApplied bit;
	select @IsOtheFilterApplied = 0;

--Table Type for OUTPUT of Process
	DECLARE @ExecutionLimit Control.ExecutionLimit;

	DECLARE @MinServiceHistoryId bigint, @MaxServiceHistoryId bigint;
	
	DECLARE @MinMaxDateKey TABLE
	(
	    AreaKey bigint
	   ,ResourceKey bigint
	   ,ResourceName varchar(max)
	   ,ResourceId bigint
	   ,minOperationEndDate int
	   ,maxOperationEndDate int
	)

	DECLARE @TimeZone varchar(255) = [DateTimeUtil].[F_GetServerTimeZoneIdentifier]();

	BEGIN TRY
		SELECT @starttrancount = @@TRANCOUNT

		IF @starttrancount = 0
			BEGIN TRANSACTION

		exec Control.P_StartExecution @PROCNAME, @MinServiceHistoryIdCalculated = @MinServiceHistoryId OUTPUT, @MaxServiceHistoryIdCalculated = @MaxServiceHistoryId OUTPUT, 
									  @InferiorServiceHistoryId = @InfServiceHistoryId, @SuperiorServiceHistoryId = @SupServiceHistoryId;


		SET @StartTime = getdate();
		SET @Message = 'dbo.P_LoadStagingTables started at: ' + CONVERT(nvarchar,@StartTime,120) + CHAR(13) + CHAR(10);
		SET @Message = @Message + '  @MinServiceHistoryId: ' + CAST(ISNULL(@MinServiceHistoryId, 0) AS nvarchar) + CHAR(13) + CHAR(10);
		SET @Message = @Message + '  @MaxServiceHistoryId: ' + CAST(ISNULL(@MaxServiceHistoryId, 0) AS nvarchar) + CHAR(13) + CHAR(10);
		RAISERROR(@Message,10,1) WITH NOWAIT;

-- http://patorjk.com/software/taag/#p=display&f=Standard
-- __  __       _            _       _ _   _ _     _                   
--|  \/  | __ _| |_ ___ _ __(_) __ _| | | | (_)___| |_ ___  _ __ _   _ 
--| |\/| |/ _` | __/ _ \ '__| |/ _` | | |_| | / __| __/ _ \| '__| | | |
--| |  | | (_| | ||  __/ |  | | (_| | |  _  | \__ \ || (_) | |  | |_| |
--|_|  |_|\__,_|\__\___|_|  |_|\__,_|_|_| |_|_|___/\__\___/|_|   \__, |
--                                                               |___/ 
	
		SET @TableName = 'Staging.T_MaterialHistory'
		SET @Message = 'Deleting %s...'
		RAISERROR(@Message, 10, 1, @TableName) WITH NOWAIT

		TRUNCATE TABLE Staging.T_MaterialHistory;

		SET @StartTime = getdate()
		SET @Message = 'Loading %s started at: ' + CONVERT(nvarchar,@StartTime,120)
		RAISERROR(@Message, 10, 1, @TableName) WITH NOWAIT

-- Temporary StepArea history relationship materialized into temp table to optimize execution of next query
		IF OBJECT_ID('tempdb..#StepArea') IS NOT NULL
		   DROP TABLE #StepArea

		CREATE TABLE #StepArea
		(
			[StepId] [bigint] NOT NULL,
			[AreaId] [bigint] NOT NULL,
			[FacilityId] [bigint] NOT NULL,
			[CalendarId] [bigint] NULL,
			[DisplayOrder] [int] NULL,
			[Type] [nvarchar](512) NULL,
			[StepStartServiceHistoryId] [bigint] NOT NULL,
			[StepStartOperationHistorySeq] [bigint] NOT NULL,
			[StepEndServiceHistoryId] [bigint] NULL,
			[StepEndOperationHistorySeq] [bigint] NULL,
			[AreaStartServiceHistoryId] [bigint] NOT NULL,
			[AreaStartOperationHistorySeq] [bigint] NOT NULL,
			[AreaEndServiceHistoryId] [bigint] NULL,
			[AreaEndOperationHistorySeq] [bigint] NULL,
			primary key ([StepId], [FacilityId], [StepStartServiceHistoryId], [AreaStartServiceHistoryId], [AreaStartOperationHistorySeq], [AreaId])
		);

		insert into #StepArea ( [StepId],[AreaId],[FacilityId],[CalendarId],[DisplayOrder],[Type],[StepStartServiceHistoryId],[StepStartOperationHistorySeq],[StepEndServiceHistoryId]
							   ,[StepEndOperationHistorySeq],[AreaStartServiceHistoryId],[AreaStartOperationHistorySeq],[AreaEndServiceHistoryId],[AreaEndOperationHistorySeq])
		select Step.SourceEntityId as StepId, Area.AreaId, Area.FacilityId, Area.CalendarId, Area.DisplayOrder, Area.[Type], Step.ServiceHistoryId as StepStartServiceHistoryId,  Step.OperationHistorySeq as StepStartOperationHistorySeq,
				  Step.EndServiceHistoryId as StepEndServiceHistoryId,  Step.EndOperationHistorySeq as StepEndOperationHistorySeq,Area.ServiceHistoryId as AreaStartServiceHistoryId,  Area.OperationHistorySeq as AreaStartOperationHistorySeq,
				  Area.EndServiceHistoryId as AreaEndServiceHistoryId,  Area.EndOperationHistorySeq as AreaEndOperationHistorySeq				 
						from (select SourceEntityId, TargetEntityId, ServiceHistoryId, OperationHistorySeq, UniversalState, DatabaseOperation,
								LEAD(ServiceHistoryId) over (partition by SourceEntityId, TargetEntityId order by ServiceHistoryId, OperationHistorySeq) EndServiceHistoryId,
								LEAD(OperationHistorySeq) over (partition by SourceEntityId, TargetEntityId order by ServiceHistoryId, OperationHistorySeq) EndOperationHistorySeq,
								LEAD(UniversalState) over (partition by SourceEntityId, TargetEntityId order by ServiceHistoryId, OperationHistorySeq) EndUniversalState,
								LEAD(DatabaseOperation) over (partition by SourceEntityId, TargetEntityId order by ServiceHistoryId, OperationHistorySeq) EndDatabaseOperation			  
							from Staging.ODS_T_StepAreaHistory							
						) Step 
			inner join  (select AreaId, FacilityId, Name, CalendarId, DisplayOrder, [Type], 
										ServiceHistoryId, OperationHistorySeq, 
										UniversalState, DatabaseOperation,
										LEAD(ServiceHistoryId) over (partition by AreaId order by ServiceHistoryId, OperationHistorySeq) EndServiceHistoryId,
										LEAD(OperationHistorySeq) over (partition by AreaId order by ServiceHistoryId, OperationHistorySeq) EndOperationHistorySeq,
										LEAD(UniversalState) over (partition by AreaId order by ServiceHistoryId, OperationHistorySeq) EndUniversalState,
										LEAD(DatabaseOperation) over (partition by AreaId order by ServiceHistoryId, OperationHistorySeq) EndDatabaseOperation
						from [Staging].[ODS_T_AreaHistory]
						) Area
			on (Step.TargetEntityId = Area.AreaId) 
			where Step.DatabaseOperation <> 2
			  and Area.UniversalState <> 4 and Area.DatabaseOperation <> 2;
			  		
-- Temporary ProductGroup relationship materialized into temp table to optimize execution of next query
		IF OBJECT_ID('tempdb..#ProductGroup') IS NOT NULL
		   DROP TABLE #ProductGroup

		CREATE TABLE #ProductGroup
		(
			[ProductId] [bigint] NOT NULL,
			[ProductGroup] nvarchar(256) NULL
			primary key ([ProductId])
		);

		insert into #ProductGroup([ProductId], [ProductGroup])
			select prod.ProductId, prodg.Name as ProductGroup
			from Staging.ODS_T_Product prod
			left JOIN Staging.ODS_T_ProductGroup prodg on (prodg.ProductGroupId = prod.ProductGroupId);
		
		INSERT INTO Staging.T_MaterialHistory  WITH(TABLOCK)
											  ([ServiceHistoryId]
											  ,[OperationHistorySeq]
											  ,[MaterialId]
											  ,[DatabaseOperation]
											  ,[AssembledQuantity]
											  ,[Cost]
											  ,[CurrentBOMAssemblyType]
											  ,[CurrentBOMVersionId]
											  ,[CurrentChecklistInstanceId]
											  ,[CurrentDataCollectionInstance]
											  ,[CurrentRecipeInstance]
											  ,[DataGroupId]
											  ,[DataGroupName]
											  ,[DateEnteredFacility]
											  ,[DateEnteredStep]
											  ,[Description]
											  ,[DocumentationURL]
											  ,[DueDate]
											  ,[ExpirationDate]
											  ,[FacilityId]
											  ,[FlowId]
											  ,[FlowPath]
											  ,[Form]
											  ,[HoldCount]
											  ,[Image]
											  ,[InhibitMoveFromStep]
											  ,[InhibitShip]
											  ,[InTransitFromState]
											  ,[InTransitToFacilityId]
											  ,[IsDelivered]
											  ,[IsDispatchable]
											  ,[IsInNonSequentialBlock]
											  ,[IsInStore]
											  ,[IsProductionComplete]
											  ,[IsTemplate]
											  ,[LastProcessedResourceId]
											  ,[LastProcessState]
											  ,[MainStateModelId]
											  ,[MainStateModelStateId]
											  ,[MainStateModelStateReason]
											  ,[ModifiedBy]
											  ,[ModifiedOn]
											  ,[Name]
											  ,[OpenExceptionProtocolsCount]
											  ,[OrderNumber]
											  ,[ParentMaterialId]
											  ,[PrimaryQuantity]
											  ,[Priority]
											  ,[ProductId]
											  ,[ProductionOrderId]
											  ,[ProductionOrderQuantity]
											  ,[RequiredServiceId]
											  ,[ReworkCount]
											  ,[SecondaryQuantity]
											  ,[ShippingLabel]
											  ,[SplitMergeRestrictionType]
											  ,[StepId]
											  ,[AreaId]
											  ,[CalendarId]
											  ,[ShiftDefinitionId]
											  ,[SubMaterialCount]
											  ,[SubMaterialsCost]
											  ,[SubMaterialsDeferredCost]
											  ,[SubMaterialsPrimaryQuantity]
											  ,[SubMaterialsSecondaryQuantity]
											  ,[SystemState]
											  ,[TrackInDate]
											  ,[TrackInPrimaryQuantity]
											  ,[TrackInSecondaryQuantity]
											  ,[Type]
											  ,[UniversalState]
											  ,[Version]
											  ,[OrderDueDate]
											  ,[OldServiceHistoryId]
											  ,[OldOperationHistorySeq]
											  ,[ServiceId]
											  ,[ServiceStartTime]
											  ,[ServiceEndTime]
											  ,[CreatedBy]
											  ,[Notes]
											  ,[ServiceName]
											  ,[SubOperationSequence]
											  ,[EntityId]
											  ,[OperationId]
											  ,[OperationStartTime]
											  ,[EntityTypeId]
											  ,[OperationName]
											  ,[OperationEndTime]
											  ,[EntityTypeName]
											  ,[Processed]
											  ,[PrimaryUnits]
											  ,[SecondaryUnits]
											  ,[ProductGroup])
		SELECT MH.[ServiceHistoryId]								--[ServiceHistoryId]
			  ,MH.[OperationHistorySeq]								--,[OperationHistorySeq]
			  ,MH.[MaterialId]										--,[MaterialId]
			  ,MH.[DatabaseOperation] 								--,[DatabaseOperation]
			  ,MH.[AssembledQuantity] 								--,[AssembledQuantity]
			  ,MH.[Cost] 											--,[Cost]
			  ,MH.[CurrentBOMAssemblyType] 							--,[CurrentBOMAssemblyType]
			  ,MH.[CurrentBOMVersionId] 							--,[CurrentBOMVersionId]
			  ,MH.[CurrentChecklistInstanceId] 						--,[CurrentChecklistInstanceId]
			  ,MH.[CurrentDataCollectionInstance] 					--,[CurrentDataCollectionInstance]
			  ,MH.[CurrentRecipeInstance] 							--,[CurrentRecipeInstance]
			  ,MH.[DataGroupId] 									--,[DataGroupId]
			  ,MH.[DataGroupName] 									--,[DataGroupName]
			  ,MH.[DateEnteredFacility] 							--,[DateEnteredFacility]
			  ,MH.[DateEnteredStep]									--,[DateEnteredStep]
			  ,MH.[Description]										--,[Description]
			  ,MH.[DocumentationURL] 								--,[DocumentationURL]
			  ,MH.[DueDate] 										--,[DueDate]
			  ,MH.[ExpirationDate] 									--,[ExpirationDate]
			  ,MH.[FacilityId] 										--,[FacilityId]
			  ,MH.[FlowId] 											--,[FlowId]
			  ,MH.[FlowPath] 										--,[FlowPath]
			  ,MH.[Form] 											--,[Form]
			  ,MH.[HoldCount] 										--,[HoldCount]
			  ,MH.[Image] 											--,[Image]
			  ,MH.[InhibitMoveFromStep]								--,[InhibitMoveFromStep]
			  ,MH.[InhibitShip]										--,[InhibitShip]
			  ,MH.[InTransitFromState] 								--,[InTransitFromState]
			  ,MH.[InTransitToFacilityId] 							--,[InTransitToFacilityId]
			  ,MH.[IsDelivered]										--,[IsDelivered]
			  ,MH.[IsDispatchable] 									--,[IsDispatchable]
			  ,MH.[IsInNonSequentialBlock] 							--,[IsInNonSequentialBlock]
			  ,MH.[IsInStore] 										--,[IsInStore]
			  ,MH.[IsProductionComplete] 							--,[IsProductionComplete]
			  ,MH.[IsTemplate] 										--,[IsTemplate]
			  ,MH.[LastProcessedResourceId] 						--,[LastProcessedResourceId]
			  ,MH.[LastProcessState] 								--,[LastProcessState]
			  ,MH.[MainStateModelId] 								--,[MainStateModelId]
			  ,MH.[MainStateModelStateId] 							--,[MainStateModelStateId]
			  ,MH.[MainStateModelStateReason] 						--,[MainStateModelStateReason]
			  ,MH.[ModifiedBy] 										--,[ModifiedBy]
			  ,MH.[ModifiedOn] 										--,[ModifiedOn]
			  ,MH.[Name] 											--,[Name]
			  ,MH.[OpenExceptionProtocolsCount] 					--,[OpenExceptionProtocolsCount]
			  ,MH.[OrderNumber] 									--,[OrderNumber]
			  ,MH.[ParentMaterialId] 								--,[ParentMaterialId]
			  ,MH.[PrimaryQuantity] 								--,[PrimaryQuantity]
			  ,MH.[Priority] 										--,[Priority]
			  ,MH.[ProductId] 										--,[ProductId]
			  ,MH.[ProductionOrderId] 								--,[ProductionOrderId]
			  ,MH.[ProductionOrderQuantity] 						--,[ProductionOrderQuantity]
			  ,MH.[RequiredServiceId] 								--,[RequiredServiceId]
			  ,MH.[ReworkCount] 									--,[ReworkCount]
			  ,MH.[SecondaryQuantity] 								--,[SecondaryQuantity]
			  ,MH.[ShippingLabel] 									--,[ShippingLabel]
			  ,MH.[SplitMergeRestrictionType]						--,[SplitMergeRestrictionType]
			  ,MH.[StepId]											--,[StepId]
			  ,SA.[AreaId]											--,[AreaId]
			  ,SA.[CalendarId]										--,[CalendarId]	
			  ,0 AS ShiftDefinitionId								--,[ShiftDefinitionId]
			  ,MH.[SubMaterialCount]								--,[SubMaterialCount]
			  ,MH.[SubMaterialsCost]								--,[SubMaterialsCost]
			  ,MH.[SubMaterialsDeferredCost]						--,[SubMaterialsDeferredCost]
			  ,MH.[SubMaterialsPrimaryQuantity]						--,[SubMaterialsPrimaryQuantity]
			  ,MH.[SubMaterialsSecondaryQuantity]					--,[SubMaterialsSecondaryQuantity]
			  ,MH.[SystemState]										--,[SystemState]
			  ,MH.[TrackInDate]										--,[TrackInDate]
			  ,MH.[TrackInPrimaryQuantity]							--,[TrackInPrimaryQuantity]
			  ,MH.[TrackInSecondaryQuantity]						--,[TrackInSecondaryQuantity]
			  ,MH.[Type]											--,[Type]
			  ,MH.[UniversalState]									--,[UniversalState]
			  ,MH.[Version]											--,[Version]
			  ,MH.[OrderDueDate]									--,[OrderDueDate]
			  ,MH.[OldServiceHistoryId]								--,[OldServiceHistoryId]
			  ,MH.[OldOperationHistorySeq]							--,[OldOperationHistorySeq]
			  ,SH.[ServiceId]										--,[ServiceId]
			  ,SH.[ServiceStartTime]								--,[ServiceStartTime]
			  ,SH.[ServiceEndTime]									--,[ServiceEndTime]
			  ,SH.[CreatedBy]										--,[CreatedBy]
			  ,SH.[Notes]											--,[Notes]
			  ,SH.[ServiceName]										--,[ServiceName]
			  ,OH.[SubOperationSequence]							--,[SubOperationSequence]
			  ,OH.[EntityId]										--,[EntityId]
			  ,OH.[OperationId]										--,[OperationId]
			  ,OH.[OperationStartTime]								--,[OperationStartTime]
			  ,OH.[EntityTypeId]									--,[EntityTypeId]
			  ,OH.[OperationName]									--,[OperationName]
			  ,OH.[OperationEndTime]								--,[OperationEndTime]
			  ,OH.[EntityTypeName]									--,[EntityTypeName]
			  ,0 as Processed										--,[Processed]
			  ,MH.PrimaryUnits										--,[PrimaryUnits]
			  ,MH.SecondaryUnits									--,[SecondaryUnits]
			  ,PG.ProductGroup										--,[ProductGroup]		
		  FROM [Staging].[ODS_T_MaterialHistory] MH 
		INNER JOIN [Staging].[ODS_T_ServiceHistory] SH WITH(NOLOCK) on SH.ServiceHistoryId = MH.ServiceHistoryId AND SH.ServiceHistoryId BETWEEN @MinServiceHistoryId AND @MaxServiceHistoryId	
		INNER JOIN [Staging].[ODS_T_OperationHistory] OH WITH(NOLOCK) on OH.ServiceHistoryId = MH.ServiceHistoryId AND OH.ServiceHistoryId BETWEEN @MinServiceHistoryId AND @MaxServiceHistoryId
																			  and OH.OperationHistorySeq = MH.OperationHistorySeq
																			  and OH.EntityId = MH.MaterialId
																			  and OH.EntityTypeName = 'Material'		
		INNER JOIN #StepArea SA on 
		                       (SA.StepId = MH.StepId and SA.FacilityId = MH.FacilityId and
						          ( 
									( MH.ServiceHistoryId > SA.StepStartServiceHistoryId or (MH.ServiceHistoryId = SA.StepStartServiceHistoryId and MH.OperationHistorySeq >= SA.StepStartOperationHistorySeq) ) AND
									( SA.StepEndServiceHistoryId is NULL or MH.ServiceHistoryId < SA.StepEndServiceHistoryId or (MH.ServiceHistoryId = SA.StepEndServiceHistoryId and MH.OperationHistorySeq < SA.StepEndOperationHistorySeq) )
								 )
								 and ( 
									( MH.ServiceHistoryId > SA.AreaStartServiceHistoryId or (MH.ServiceHistoryId = SA.AreaStartServiceHistoryId and MH.OperationHistorySeq >= SA.AreaStartOperationHistorySeq) ) AND
									( SA.AreaEndServiceHistoryId is NULL or MH.ServiceHistoryId < SA.AreaEndServiceHistoryId or (MH.ServiceHistoryId = SA.AreaEndServiceHistoryId and MH.OperationHistorySeq < SA.AreaEndOperationHistorySeq) )
								 )
						        )		
		INNER JOIN #ProductGroup PG on (MH.ProductId = PG.ProductId)
		WHERE MH.IsTemplate = 0 AND MH.ServiceHistoryId BETWEEN @MinServiceHistoryId AND @MaxServiceHistoryId		
		OPTION(RECOMPILE);

		SET @RowCount = @@ROWCOUNT
		SET @EndTime = getdate()
		SET @Message = 'Loading %s ended at: ' + CONVERT(nvarchar,@EndTime,120) + '. ' + CONVERT(nvarchar, @RowCount) + ' row(s) inserted. Took ' + CONVERT(nvarchar,datediff(ms, @StartTime, @EndTime)) + 'ms'
		RAISERROR(@Message, 10, 1, @TableName) WITH NOWAIT		
		UPDATE STATISTICS [Staging].[T_MaterialHistory]
		

-- ____                                    _   _ _     _                   
--|  _ \ ___  ___  ___  _   _ _ __ ___ ___| | | (_)___| |_ ___  _ __ _   _ 
--| |_) / _ \/ __|/ _ \| | | | '__/ __/ _ \ |_| | / __| __/ _ \| '__| | | |
--|  _ <  __/\__ \ (_) | |_| | | | (_|  __/  _  | \__ \ || (_) | |  | |_| |
--|_| \_\___||___/\___/ \__,_|_|  \___\___|_| |_|_|___/\__\___/|_|   \__, |
--																	  |___/ 

-- Temporary ProductGroup relationship materialized into temp table to optimize execution of next query
		IF OBJECT_ID('tempdb..#ResourceStateModelLUT') IS NOT NULL
		   DROP TABLE #ResourceStateModelLUT

		CREATE TABLE #ResourceStateModelLUT
		(
			[StateModelId] [bigint] NOT NULL,
			[StateModelName] [nvarchar](256) NOT NULL,
			[StateModelStateId] [bigint] NOT NULL,
			[StateModelStateName] [nvarchar](256) NOT NULL,
			[Basic] [nvarchar](512) NULL,
			[SEMI-E10] [nvarchar](512) NULL,
			primary key ([StateModelId], [StateModelStateId])
		);

		insert into #ResourceStateModelLUT([StateModelId], [StateModelName], [StateModelStateId], [StateModelStateName], [Basic], [SEMI-E10])
		select StateModelId, StateModelName, StateModelStateId, StateModelStateName, [Basic], IsNull([SEMI-E10], StateModelStateName) as [SEMI-E10]
		  from 
			(select SM.StateModelId, SM.Name StateModelName, SMS.StateModelStateId, SMS.Name StateModelStateName, SMSA.Name StateModelStateAttributeName, SMSA.Value StateModelStateAttributeValue
			   from [Staging].[ODS_T_StateModel] SM
			  inner join [Staging].[ODS_T_StateModelState] SMS on SMS.StateModelId = SM.StateModelId 
			  inner join [Staging].[ODS_T_StateModelStateAttribute] SMSA on SMSA.StateModelStateId = SMS.StateModelStateId 
			  inner join (select EntityTypeId from [Staging].[ODS_T_EntityType] where name = 'Resource') ET on (ET.EntityTypeId = SM.EntityTypeId)
			  where SM.UniversalState = 2
			) SourceTable
			 pivot
			 (
				max(StateModelStateAttributeValue) for StateModelStateAttributeName in ([Basic],[SEMI-E10])
			 ) as PivotTable

		SET @TableName = 'Staging.T_ResourceHistory'
		SET @Message = 'Deleting %s...'
		RAISERROR(@Message, 10, 1, @TableName) WITH NOWAIT

		TRUNCATE TABLE Staging.T_ResourceHistory;		

		SET @StartTime = getdate()
		SET @Message = 'Loading %s started at: ' + CONVERT(nvarchar,@StartTime,120)
		RAISERROR(@Message, 10, 1, @TableName) WITH NOWAIT

		insert into Staging.T_ResourceHistory WITH(TABLOCK)
											( [ServiceHistoryId]
											  ,[OperationHistorySeq]
											  ,[ResourceId]
											  ,[DatabaseOperation]
											  ,[AreaId]
											  ,[AutomationAddress]
											  ,[AutomationMode]
											  ,[CostPerHour]
											  ,[CostPerUnit]
											  ,[CurrentBOMAssemblyType]
											  ,[CurrentBOMVersionId]
											  ,[CurrentRecipeVersionId]
											  ,[DataGroupId]
											  ,[DataGroupName]
											  ,[Description]
											  ,[DispatchableDate]
											  ,[DisplayOrder]
											  ,[DisplayPath]
											  ,[DocumentationURL]
											  ,[FixedCost]
											  ,[HoldCount]
											  ,[Image]
											  ,[IsAutoGeneratePositionEnabled]
											  ,[IsDispatchable]
											  ,[IsDownloadRecipeCapable]
											  ,[IsJobManagementCapable]
											  ,[IsNotifyRecipeSelectionChangeCapable]
											  ,[IsProductMixAllowed]
											  ,[IsRecipeManagementEnabled]
											  ,[IsSubMaterialTrackingEnabled]
											  ,[IsTemplate]
											  ,[IsUploadRecipeCapable]
											  ,[LastRecipeVersionId]
											  ,[LoadPortType]
											  ,[MainStateModelId]
											  ,[MainStateModelStateId]
											  ,[MainStateModelStateReason]
											  ,[MaterialsInProcessCount]
											  ,[MaterialsInQueueCount]
											  ,[MaterialsProcessedCount]
											  ,[MaxConcurrentMaterialsInProcess]
											  ,[Model]
											  ,[ModifiedBy]
											  ,[ModifiedOn]
											  ,[Name]
											  ,[PositionContainerType]
											  ,[PositionUnitType]
											  ,[Priority]
											  ,[ProcessingDate]
											  ,[ProcessingType]
											  ,[ResourceType]
											  ,[RestrictedToMaterialForm]
											  ,[RunningMode]
											  ,[SelectedRecipeId]
											  ,[SelectedRecipeSource]
											  ,[SelectedRecipeTimeStamp]
											  ,[SelectedResourceRecipe]
											  ,[SerialNumber]
											  ,[SortRuleSetId]
											  ,[SystemState]
											  ,[TotalPositions]
											  ,[Type]
											  ,[UniversalState]
											  ,[UsedPositions]
											  ,[Vendor]
											  ,[Version]
											  ,[OldServiceHistoryId]
											  ,[OldOperationHistorySeq]
											  ,[ServiceId]
											  ,[ServiceStartTime]
											  ,[ServiceEndTime]
											  ,[CreatedBy]
											  ,[Notes]
											  ,[ServiceName]
											  ,[SubOperationSequence]
											  ,[EntityId]
											  ,[OperationId]
											  ,[OperationStartTime]
											  ,[EntityTypeId]
											  ,[OperationName]
											  ,[OperationEndTime]
											  ,[EntityTypeName]
											  ,[Basic]
											  ,[SEMI-E10]
											  ,[Processed])
		select RH.[ServiceHistoryId]								--[ServiceHistoryId]
		      ,RH.[OperationHistorySeq]								--,[OperationHistorySeq]
		      ,[ResourceId]											--,[ResourceId]
		      ,[DatabaseOperation]									--,[DatabaseOperation]
		      ,[AreaId]												--,[AreaId]
		      ,[AutomationAddress]									--,[AutomationAddress]
		      ,[AutomationMode]										--,[AutomationMode]
		      ,0 as CostPerHour										--,[CostPerHour]
		      ,0 as CostPerUnit										--,[CostPerUnit]
		      ,[CurrentBOMAssemblyType]								--,[CurrentBOMAssemblyType]
		      ,[CurrentBOMVersionId]								--,[CurrentBOMVersionId]
		      ,[CurrentRecipeVersionId]								--,[CurrentRecipeVersionId]
		      ,[DataGroupId]										--,[DataGroupId]
		      ,[DataGroupName]										--,[DataGroupName]
		      ,[Description]										--,[Description]
		      ,[DispatchableDate]									--,[DispatchableDate]
		      ,[DisplayOrder]										--,[DisplayOrder]
		      ,[DisplayPath]										--,[DisplayPath]
		      ,[DocumentationURL]									--,[DocumentationURL]
		      ,0 as FixedCost										--,[FixedCost]
		      ,[HoldCount]											--,[HoldCount]
		      ,[Image]												--,[Image]
		      ,[IsAutoGeneratePositionEnabled]						--,[IsAutoGeneratePositionEnabled]
		      ,[IsDispatchable]										--,[IsDispatchable]
		      ,[IsDownloadRecipeCapable]							--,[IsDownloadRecipeCapable]
		      ,[IsJobManagementCapable]								--,[IsJobManagementCapable]
		      ,[IsNotifyRecipeSelectionChangeCapable]				--,[IsNotifyRecipeSelectionChangeCapable]
		      ,[IsProductMixAllowed]								--,[IsProductMixAllowed]
		      ,[IsRecipeManagementEnabled]							--,[IsRecipeManagementEnabled]
		      ,[IsSubMaterialTrackingEnabled]						--,[IsSubMaterialTrackingEnabled]
		      ,[IsTemplate]											--,[IsTemplate]
		      ,[IsUploadRecipeCapable]								--,[IsUploadRecipeCapable]
		      ,[LastRecipeVersionId]								--,[LastRecipeVersionId]
		      ,[LoadPortType]										--,[LoadPortType]
		      ,[MainStateModelId]									--,[MainStateModelId]
		      ,[MainStateModelStateId]								--,[MainStateModelStateId]
		      ,ltrim(rtrim(replace([MainStateModelStateReason],char(9),' '))) as [MainStateModelStateReason] --,[MainStateModelStateReason]
		      ,[MaterialsInProcessCount]							--,[MaterialsInProcessCount]
		      ,[MaterialsInQueueCount]								--,[MaterialsInQueueCount]
		      ,[MaterialsProcessedCount]							--,[MaterialsProcessedCount]
		      ,[MaxConcurrentMaterialsInProcess]					--,[MaxConcurrentMaterialsInProcess]
		      ,[Model]												--,[Model]
		      ,[ModifiedBy]											--,[ModifiedBy]
		      ,[ModifiedOn]											--,[ModifiedOn]
		      ,[Name]												--,[Name]
		      ,[PositionContainerType]								--,[PositionContainerType]
		      ,[PositionUnitType]									--,[PositionUnitType]
		      ,[Priority]											--,[Priority]
		      ,[ProcessingDate]										--,[ProcessingDate]
		      ,[ProcessingType]										--,[ProcessingType]
		      ,[ResourceType]										--,[ResourceType]
		      ,[RestrictedToMaterialForm]							--,[RestrictedToMaterialForm]
		      ,[RunningMode]										--,[RunningMode]
		      ,[SelectedRecipeId]									--,[SelectedRecipeId]
		      ,[SelectedRecipeSource]								--,[SelectedRecipeSource]
		      ,[SelectedRecipeTimeStamp]							--,[SelectedRecipeTimeStamp]
		      ,[SelectedResourceRecipe]								--,[SelectedResourceRecipe]
		      ,[SerialNumber]										--,[SerialNumber]
		      ,[SortRuleSetId]										--,[SortRuleSetId]
		      ,[SystemState]										--,[SystemState]
		      ,[TotalPositions]										--,[TotalPositions]
		      ,[Type]												--,[Type]
		      ,[UniversalState]										--,[UniversalState]
		      ,[UsedPositions]										--,[UsedPositions]
		      ,[Vendor]												--,[Vendor]
		      ,[Version]											--,[Version]
		      ,[OldServiceHistoryId]								--,[OldServiceHistoryId]
		      ,[OldOperationHistorySeq]								--,[OldOperationHistorySeq]
		      ,[ServiceId]											--,[ServiceId]
		      ,[ServiceStartTime]									--,[ServiceStartTime]
		      ,[ServiceEndTime]										--,[ServiceEndTime]
		      ,[CreatedBy]											--,[CreatedBy]
		      ,[Notes]												--,[Notes]
		      ,[ServiceName]										--,[ServiceName]
		      ,ISNULL([SubOperationSequence], 0)					--,[SubOperationSequence]
		      ,RH.ResourceId  as [EntityId]							--,[EntityId]
		      ,ISNULL([OperationId], [Constants].[F_GetUndefinedKey]())	--,[OperationId]
		      ,ISNULL([OperationStartTime], RH.ModifiedOn)		    --,[OperationStartTime]
		      ,ISNULL([EntityTypeId], -1)							--,[EntityTypeId]
		      ,ISNULL([OperationName], [Constants].F_GetUndefinedKeyName()) --,[OperationName]
		      ,ISNULL([OperationEndTime], RH.ModifiedOn)			--,[OperationEndTime]
		      ,ISNULL([EntityTypeName], 'Resource')					--,[EntityTypeName]
		      ,RSMLUT.[Basic]										--,[Basic]
		      ,RSMLUT.[SEMI-E10]									--,[SEMI-E10]
		      ,0 as Processed										--,[Processed])
		FROM [Staging].[ODS_T_ResourceHistory] RH
		  INNER JOIN [Staging].[ODS_T_ServiceHistory] SH WITH (NOLOCK) ON (SH.ServiceHistoryId = RH.ServiceHistoryId AND SH.ServiceId > 0 AND SH.ServiceHistoryId BETWEEN @MinServiceHistoryId AND @MaxServiceHistoryId)
		  LEFT JOIN [Staging].[ODS_T_OperationHistory] OH WITH (NOLOCK) ON (OH.ServiceHistoryId = RH.ServiceHistoryId 
																			AND OH.OperationHistorySeq = RH.OperationHistorySeq 
																			AND OH.EntityId = RH.ResourceId 
																			AND OH.EntityTypeName = 'Resource'
																			AND OH.ServiceHistoryId BETWEEN @MinServiceHistoryId AND @MaxServiceHistoryId)
		  INNER JOIN #ResourceStateModelLUT RSMLUT ON (RSMLUT.StateModelId = RH.[MainStateModelId] 
													AND RSMLUT.StateModelStateId = RH.[MainStateModelStateId])
		 WHERE RH.IsTemplate = 0 AND RH.ServiceHistoryId BETWEEN @MinServiceHistoryId AND @MaxServiceHistoryId
		OPTION (RECOMPILE);

		SET @RowCount = @@ROWCOUNT
		SET @EndTime = getdate()
		SET @Message = 'Loading %s ended at: ' + CONVERT(nvarchar,@EndTime,120) + '. ' + CONVERT(nvarchar, @RowCount) + ' row(s) inserted. Took ' + CONVERT(nvarchar,datediff(ms, @StartTime, @EndTime)) + 'ms'
		RAISERROR(@Message, 10, 1, @TableName) WITH NOWAIT
		UPDATE STATISTICS [Staging].[T_ResourceHistory]


-- __  __       _            _       _    _   _   _        _ _           _       _   _ _     _                   
--|  \/  | __ _| |_ ___ _ __(_) __ _| |  / \ | |_| |_ _ __(_) |__  _   _| |_ ___| | | (_)___| |_ ___  _ __ _   _ 
--| |\/| |/ _` | __/ _ \ '__| |/ _` | | / _ \| __| __| '__| | '_ \| | | | __/ _ \ |_| | / __| __/ _ \| '__| | | |
--| |  | | (_| | ||  __/ |  | | (_| | |/ ___ \ |_| |_| |  | | |_) | |_| | ||  __/  _  | \__ \ || (_) | |  | |_| |
--|_|  |_|\__,_|\__\___|_|  |_|\__,_|_/_/   \_\__|\__|_|  |_|_.__/ \__,_|\__\___|_| |_|_|___/\__\___/|_|   \__, |
--                                                                                                         |___/ 

		SET @TableName = 'Staging.T_MaterialAttributeHistory'
		SET @Message = 'Deleting %s...'
		RAISERROR(@Message, 10, 1, @TableName) WITH NOWAIT

		TRUNCATE TABLE Staging.T_MaterialAttributeHistory;
		
		SET @StartTime = getdate()
		SET @Message = 'Loading %s started at: ' + CONVERT(nvarchar,@StartTime,120)
		RAISERROR(@Message, 10, 1, @TableName) WITH NOWAIT

		insert into Staging.T_MaterialAttributeHistory WITH(TABLOCK)
				([ServiceHistoryId]
				,[OperationHistorySeq]
				,[OldServiceHistoryId]
				,[OldOperationHistorySeq]
				,[MaterialId]
				,[DatabaseOperation]
				,[EntityTypePropertyId]
				,[Name]
				,[Index]
				,[SubOperationSequence]
				,[OldValue]
				,[Value]
				,[ModifiedBy]
				,[ModifiedOn]
				,[Processed])
		select MAH.[ServiceHistoryId]
			  ,MAH.[OperationHistorySeq]
			  ,MAH.[OldServiceHistoryId]
			  ,MAH.[OldOperationHistorySeq]
			  ,MAH.[MaterialId]		
			  ,MAH.[DatabaseOperation]
			  ,MAH.[EntityTypePropertyId]
			  ,MAH.[Name]
			  ,MAH.[Index]
			  ,MAH.[SubOperationSequence]
			  ,MAH.[OldValue]
			  ,IsNull(ltrim(rtrim(replace(MAH.[Value],char(9),' ') )), [Constants].[F_GetUndefinedKeyName]()) [Value]
			  ,MAH.[ModifiedBy]
			  ,MAH.[ModifiedOn]
			  ,0
		 from [Staging].[ODS_T_MaterialAttributeHistory] MAH
		 INNER JOIN [Staging].[ODS_T_EntityTypeProperty] ETP ON ETP.[EntityTypePropertyId] = MAH.[EntityTypePropertyId]
		where MAH.ServiceHistoryId BETWEEN @MinServiceHistoryId AND @MaxServiceHistoryId
			AND (ETP.IsSystemProperty = 1 OR ETP.LoadToDWH = 1);

		SET @RowCount = @@ROWCOUNT
		SET @EndTime = getdate()
		SET @Message = 'Loading %s ended at: ' + CONVERT(nvarchar,@EndTime,120) + '. ' + CONVERT(nvarchar, @RowCount) + ' row(s) inserted. Took ' + CONVERT(nvarchar,datediff(ms, @StartTime, @EndTime)) + 'ms'
		RAISERROR(@Message, 10, 1, @TableName) WITH NOWAIT
		UPDATE STATISTICS [Staging].[T_MaterialAttributeHistory]

-- __  __       _            _       _  ____                       _                   
--|  \/  | __ _| |_ ___ _ __(_) __ _| |/ ___| ___ _ __   ___  __ _| | ___   __ _ _   _ 
--| |\/| |/ _` | __/ _ \ '__| |/ _` | | |  _ / _ \ '_ \ / _ \/ _` | |/ _ \ / _` | | | |
--| |  | | (_| | ||  __/ |  | | (_| | | |_| |  __/ | | |  __/ (_| | | (_) | (_| | |_| |
--|_|  |_|\__,_|\__\___|_|  |_|\__,_|_|\____|\___|_| |_|\___|\__,_|_|\___/ \__, |\__, |
--                                                                         |___/ |___/ 

		SET @TableName = 'Staging.T_MaterialGenealogy'
		SET @Message = 'Deleting %s...'
		RAISERROR(@Message, 10, 1, @TableName) WITH NOWAIT

		TRUNCATE TABLE Staging.T_MaterialGenealogy;
		
		SET @StartTime = getdate()
		SET @Message = 'Loading %s started at: ' + CONVERT(nvarchar,@StartTime,120)
		RAISERROR(@Message, 10, 1, @TableName) WITH NOWAIT

		INSERT INTO [Staging].[T_MaterialGenealogy] WITH(TABLOCK)
			   ([Operation]
			   ,[OperationId]
			   ,[OperationEndTime]
			   ,[ServiceHistoryId]
			   ,[OperationHistorySeq]
			   ,[AscMaterialId]
			   ,[AscMaterialName]
			   ,[AscModifiedon]
			   ,[AscStepId]
			   ,[AscStep]
			   ,[AscProduct]
			   ,[AscProductId]
			   ,[AscBOM]
			   ,[AscPQ]
			   ,[AscSQ]
			   ,[AscAssembleQ]
			   ,[AscAssembleSecQ]
			   ,[IsExplicitAssemble]
			   ,[DescMaterialId]
			   ,[DescMaterialName]
			   ,[DescStepId]
			   ,[DescStep]
			   ,[DescProduct]
			   ,[DescProductId]
			   ,[DescBOM]
			   ,[DescPQ]
			   ,[DescSQ]
			   ,[DescAssembleQ]
			   ,[DescAssembleSecQ]
			   ,[DescModifiedOn]
			   ,[AscCurrentBOMVersionId]
			   ,[DescCurrentBOMVersionId]
			   ,[AscPrimaryUnits]
			   ,[AscSecondaryUnits]
			   ,[DescPrimaryUnits]
			   ,[DescSecondaryUnits]
			   ,[AscServiceHistoryId]
			   ,[AscOperationHistorySeq]
			   ,[AscSubOperationSequence]
			   ,[DescServiceHistoryId]
			   ,[DescOperationHistorySeq]
			   ,[DescSubOperationSequence])
		 SELECT [Operation]
			   ,[OperationId]
			   ,[OperationEndTime]
			   ,[ServiceHistoryId]
			   ,[OperationHistorySeq]
			   ,[AscMaterialId]
			   ,[AscMaterialName]
			   ,[AscModifiedon]
			   ,[AscStepId]
			   ,[AscStep]
			   ,[AscProduct]
			   ,[AscProductId]
			   ,[AscBOM]
			   ,[AscPQ]
			   ,[AscSQ]
			   ,[AscAssembleQ]
			   ,[AscAssembleSecQ]
			   ,[IsExplicitAssemble]
			   ,[DescMaterialId]
			   ,[DescMaterialName]
			   ,[DescStepId]
			   ,[DescStep]
			   ,[DescProduct]
			   ,[DescProductId]
			   ,[DescBOM]
			   ,[DescPQ]
			   ,[DescSQ]
			   ,[DescAssembleQ]
			   ,[DescAssembleSecQ]
			   ,[DescModifiedOn]
			   ,[AscCurrentBOMVersionId]
			   ,[DescCurrentBOMVersionId]
			   ,[AscPrimaryUnits]
			   ,[AscSecondaryUnits]
			   ,[DescPrimaryUnits]
			   ,[DescSecondaryUnits]
			   ,[AscServiceHistoryId]
			   ,[AscOperationHistorySeq]
			   ,[AscSubOperationSequence]
			   ,[DescServiceHistoryId]
			   ,[DescOperationHistorySeq]
			   ,[DescSubOperationSequence]
		  FROM Staging.ODS_V_MaterialGenealogy
		 WHERE ServiceHistoryId BETWEEN @MinServiceHistoryId AND @MaxServiceHistoryId;

		SET @RowCount = @@ROWCOUNT
		SET @EndTime = getdate()
		SET @Message = 'Loading %s ended at: ' + CONVERT(nvarchar,@EndTime,120) + '. ' + CONVERT(nvarchar, @RowCount) + ' row(s) inserted. Took ' + CONVERT(nvarchar,datediff(ms, @StartTime, @EndTime)) + 'ms'
		RAISERROR(@Message, 10, 1, @TableName) WITH NOWAIT
		UPDATE STATISTICS [Staging].[T_MaterialGenealogy]
		
-- ____        _         ____      _ _           _   _             
--|  _ \  __ _| |_ __ _ / ___|___ | | | ___  ___| |_(_) ___  _ __  
--| | | |/ _` | __/ _` | |   / _ \| | |/ _ \/ __| __| |/ _ \| '_ \ 
--| |_| | (_| | || (_| | |__| (_) | | |  __/ (__| |_| | (_) | | | |
--|____/ \__,_|\__\__,_|\____\___/|_|_|\___|\___|\__|_|\___/|_| |_|
		

		SET @TableName = 'Staging.T_DataCollection'
		SET @Message = 'Deleting %s...'
		RAISERROR(@Message, 10, 1, @TableName) WITH NOWAIT

		TRUNCATE TABLE Staging.T_DataCollection;
		
		SET @StartTime = getdate()
		SET @Message = 'Loading %s started at: ' + CONVERT(nvarchar,@StartTime,120)
		RAISERROR(@Message, 10, 1, @TableName) WITH NOWAIT
		
/* [Staging].[ODS_T_Parameter].[DataType] values:
		String = 0,
        Url = 1,
        Long = 2,
        Decimal = 3,
        DateTime = 4,
        Duration = 5,
        Boolean = 6
		*/

		insert into Staging.T_DataCollection WITH(TABLOCK)
		(	
		   [MaterialId]
		  ,[DataCollectionId]
		  ,[DataCollectionInstanceId]
		  ,[ParameterId]
		  ,[AreaId]
		  ,[StepId]
		  ,[ProductId]
		  ,[FlowId]
		  ,[ResourceId]
		  ,[ContainerId]
		  ,[ServiceHistoryId]
		  ,[OperationHistorySeq]
		  ,[SubOperationSequence]
		  ,[OperationEndTime]
		  ,[ReadingNumber]
		  ,[ReadingName]
		  ,[SampleId]
		  ,[ParameterName]
		  ,[NumericValue]
		  ,[StringValue]
		  ,[MaterialPrimaryQuantity]
		  ,[MaterialSecondaryQuantity]
		  ,[Processed]
		  ,[PrimaryUnits]
		  ,[SecondaryUnits]
		)
		select MaterialId
				,DataCollectionId
				,DataCollectionInstanceId
				,ParameterId
				,AreaId
				,StepId
				,ProductId
				,FlowId
				,ResourceId
				,ContainerId
				,ServiceHistoryId
				,OperationHistorySeq
				,SubOperationSequence
				,OperationEndTime
				,[ReadingNumber]
				,[ReadingName]
				,[SampleId]
				,ParameterName
				,CASE WHEN [DataType] in (2,3) then try_cast([VALUE] AS decimal(18,8))
					ELSE NULL
				 END NumericValue				
				,[Value] as StringValue
				,MaterialPrimaryQuantity
				,MaterialSecondaryQuantity
				,Processed
				,PrimaryUnits
				,SecondaryUnits
		  from (SELECT DCI.MaterialId
					  ,DC.DataCollectionId
					  ,DCI.DataCollectionInstanceId
					  ,P.ParameterId
					  ,ISNULL(Res.AreaId, DCI.AreaId) as AreaId
					  ,DCI.StepId
					  ,DCI.ProductId
					  ,DCI.FlowId
					  ,DCI.ResourceId
					  ,DCI.ContainerId
					  ,OH.ServiceHistoryId
					  ,OH.OperationHistorySeq
					  ,OH.SubOperationSequence
					  ,OH.OperationEndTime
					  ,[ReadingNumber]
					  ,[ReadingName]
					  ,LTRIM(RTRIM(REPLACE([SampleId],CHAR(9),' ') )) as [SampleId]
					  ,P.[Name] ParameterName
					  ,P.[DataType]
					  ,isnull(ltrim(rtrim(replace(DCP.VALUE,char(9),' ') )), [Constants].[F_GetUndefinedKeyName]()) [Value]
					  ,MaterialPrimaryQuantity
					  ,MaterialSecondaryQuantity
					  ,0 as Processed
					  ,DCI.MaterialPrimaryUnits as PrimaryUnits
					  ,DCI.MaterialSecondaryUnits as SecondaryUnits
				  FROM [Staging].[ODS_T_DataCollectionPoint] DCP
				  inner join [Staging].[ODS_T_DataCollectionInstance] DCI on DCP.[SourceEntityId] = DCI.DataCollectionInstanceId
				  inner join [Staging].[ODS_T_DataCollection] DC on DCI.DataCollectionId = DC.DataCollectionId
				  inner join [Staging].[ODS_T_Parameter] P on P.ParameterId = DCP.TargetEntityId
				  left join [Staging].[ODS_T_Resource] Res on Res.ResourceId = DCI.ResourceId
				  inner join [Staging].[ODS_T_OperationHistory] OH WITH(NOLOCK) on OH.ServiceHistoryId = DCP.LastServiceHistoryId 
														  AND OH.OperationHistorySeq = DCP.LastOperationHistorySeq
														  AND OH.EntityTypeName = 'DataCollectionInstance'
														  AND OH.EntityId = DCI.DataCollectionInstanceId
				  Where DCI.UniversalState = 4
				  and OH.servicehistoryID between @MinServiceHIstoryID and @MaxServiceHistoryId
				  and DCP.LastServicehistoryID between @MinServiceHIstoryID and @MaxServiceHistoryId
			  ) a
		OPTION(RECOMPILE);

		SET @RowCount = @@ROWCOUNT
		SET @EndTime = getdate()
		SET @Message = 'Loading %s ended at: ' + CONVERT(nvarchar,@EndTime,120) + '. ' + CONVERT(nvarchar, @RowCount) + ' row(s) inserted. Took ' + CONVERT(nvarchar,datediff(ms, @StartTime, @EndTime)) + 'ms'
		RAISERROR(@Message, 10, 1, @TableName) WITH NOWAIT
		UPDATE STATISTICS [Staging].[T_DataCollection]


--  ____ _                _   ____        _        ____       _       _   ____                _ _             
-- / ___| |__   __ _ _ __| |_|  _ \  __ _| |_ __ _|  _ \ ___ (_)_ __ | |_|  _ \ ___  __ _  __| (_)_ __   __ _ 
--| |   | '_ \ / _` | '__| __| | | |/ _` | __/ _` | |_) / _ \| | '_ \| __| |_) / _ \/ _` |/ _` | | '_ \ / _` |
--| |___| | | | (_| | |  | |_| |_| | (_| | || (_| |  __/ (_) | | | | | |_|  _ <  __/ (_| | (_| | | | | | (_| |
-- \____|_| |_|\__,_|_|   \__|____/ \__,_|\__\__,_|_|   \___/|_|_| |_|\__|_| \_\___|\__,_|\__,_|_|_| |_|\__, |
--                                                                                                      |___/ 

		SET @TableName = 'Staging.T_ChartDataPointReading'
		SET @Message = 'Deleting %s...'
		RAISERROR(@Message, 10, 1, @TableName) WITH NOWAIT

		TRUNCATE TABLE Staging.T_ChartDataPointReading;

-- when reagregating, DimDataPoint state must be reset
		IF (@MinServiceHistoryId <= @SPCCreateServiceHistoryId )
		BEGIN
			DECLARE @MinServDateTime datetime, @MaxServDateTime datetime;
			select @MinServDateTime = MinServDateTime, @MaxServDateTime = MaxServDateTime
			from [dbo].[F_GetMinAndMaxServiceTime](@MinServiceHistoryId, @MaxServiceHistoryId);

			SET @TableName = 'dbo.DimDataPoint'
			SET @Message = 'Resetting %s due to DWH data reagregation...'
			RAISERROR(@Message, 10, 1, @TableName) WITH NOWAIT;

			update DimDataPoint set IsClosedInDWH = 0, [UpdateTimestamp] = getUTCdate()
			where IsClosedInDWH = convert(bit, 1)
			AND DataPointCreatedOn >= @MinServDateTime
			and DataPointId <> [Constants].[F_GetUndefinedKey]();

			SET @Message = 'Reset ' + convert(nvarchar, @@ROWCOUNT) + ' datapoints on table %s...';
			RAISERROR(@Message, 10, 1, @TableName) WITH NOWAIT;

		END;
		
		SET @StartTime = getdate()
		SET @TableName = 'Staging.T_ChartDataPointReading'
		SET @Message = 'Loading %s started at: ' + CONVERT(nvarchar,@StartTime,120)
		RAISERROR(@Message, 10, 1, @TableName) WITH NOWAIT

		INSERT INTO Staging.T_ChartDataPointReading WITH(TABLOCK)
			([ChartId]
			,[ParameterId]
			,[ChartDataPointId]
			,[ChartDataPointName]
			,[MaterialId]
			,[ProductId]
			,[ResourceId]
			,[FlowID]
			,[StepId]
			,[FacilityId]
			,[MaterialOperation]
			,[DataCollectionId]
			,[DataCollectionInstanceId]
			,[ContainerId]
			,[SampleId]
			,[TargetSpecValue]
			,[LowerControlLimit1]
			,[LowerControlLimit2]
			,[LowerSpecLimit]
			,[UpperControlLimit1]
			,[UpperControlLimit2]
			,[UpperSpecLimit]
			,[DataPointValue1]
			,[DataPointValue2]
			,[OriginalDataPointValue1]
			,[OriginalDataPointValue2]
			,[IsEdited]
			,[SystemState]
			,[ReadingNumber]
			,[DataPointReadingValue]
			,[ServiceHistoryId]
			,[OperationHistorySeq]
			,[SubOperationSequence]
			,[OperationStartTime]
			,[OperationEndTime]
			,[ChartName]
			,[ChartType]
			,[Type]
			,[UniversalState])
		select [ChartId]
			,[ParameterId]
			,[ChartDataPointId]
			,[ChartDataPointName]
			,[MaterialId]
			,[ProductId]
			,[ResourceId]
			,[FlowID]
			,[StepId]
			,[FacilityId]
			,[MaterialOperation]
			,[DataCollectionId]
			,[DataCollectionInstanceId]
			,[ContainerId]
			,[SampleId]
			,[TargetSpecValue]
			,[LowerControlLimit1]
			,[LowerControlLimit2]
			,[LowerSpecLimit]
			,[UpperControlLimit1]
			,[UpperControlLimit2]
			,[UpperSpecLimit]
			,[DataPointValue1]
			,[DataPointValue2]
			,[OriginalDataPointValue1]
			,[OriginalDataPointValue2]
			,[IsEdited]
			,[SystemState]
			,[ReadingNumber]
			,[DataPointReadingValue]
			,[ServiceHistoryId]
			,[OperationHistorySeq]
			,[SubOperationSequence]
			,[OperationStartTime]
			,[OperationEndTime]
			,[ChartName]
			,[ChartType]
			,[Type]
			,[UniversalState]
		from (
		  SELECT C.ChartId, /*C.Name as ChartName,*/ 
			   P.ParameterId, /*P.Name as ParameterName,*/ 
			   cdp.ChartDataPointId, 
			   cdp.Name as ChartDataPointName,
			   dm.MaterialId, 
			   dr.ResourceID,
			   dp.ProductId,  
			   df.FlowId, 
			   ds.StepId, 
			   dfac.FacilityId, 
			   cdpc.MaterialOperation, 
			   dc.DataCollectionId, 
			   dci.DataCollectionInstanceId,
			   ct.ContainerId,
			   LTRIM(RTRIM(REPLACE(cdp.[SampleId],CHAR(9),' ') )) AS SampleId,
			   cdp.TargetSpecValue,
			   cdp.LowerControlLimit1, 
			   cdp.LowerControlLimit2, 
			   cdp.LowerSpecLimit, 
			   cdp.UpperControlLimit1, 
			   cdp.UpperControlLimit2, 
			   cdp.UpperSpecLimit,			   
-- always put at null datapointvalues, only when [DimDataPoint].[IsClosedInDWH] is updated to 1 in P_LoadFactChartDataPointReading then update this at same time
			   null as DataPointValue1,
			   null as DataPointValue2,
			   cdp.Value1 as OriginalDataPointValue1, 
			   cdp.Value2 as OriginalDataPointValue2, 
			   cdp.IsEdited, 
			   cdp.SystemState, --  = 0 'Ok', 1 'IsDeleted', 2 'IsExcluded' 
			   cdpr.ReadingNumber, 
			   cdpr.Value as DataPointReadingValue, 
--sh.ServiceHistoryId, 
--isnull(oh.OperationHistorySeq,cdpr.LastOperationHistorySeq) as OperationHistorySeq, 
			   cdpr.LastServiceHistoryId as ServiceHistoryId,
			   cdpr.LastOperationHistorySeq as OperationHistorySeq, 
			   isnull(oh.SubOperationSequence,0) as SubOperationSequence, 
			   sh.ServiceStartTime as OperationStartTime,  
			   cdp.CreatedOn as OperationEndTime
			   ,c.[Name] ChartName
				,case when c.ChartType = 0 then 'AverageAndRange' 
					when c.ChartType = 1 then 'AverageAndStandardDeviation' 
					when c.ChartType = 2 then 'MedianAndRange'  
					when c.ChartType = 3 then 'IndividualsAndMovingRange'  
					when c.ChartType = 4 then 'FractionDefective'  
					when c.ChartType = 5 then 'NumberDefective'
					when c.ChartType = 6 then 'NumberOfDefects'
					when c.ChartType = 7 then 'NumberOfDefectsPerUnit'
				end ChartType 
				,c.[Type]
-- following is used to avoid issues when same material is recreated in online after having being purged leading to 2 distinct materialids in ODS
-- moreover, when editing readings the old ones are terminated, avoid reading those
				,row_number() over(partition by CDP.ChartDataPointId, P.ParameterId, cdpr.ReadingNumber  order by dm.MaterialId, cdpr.CreatedOn desc) rnum 
				,cdp.[UniversalState]
		  FROM [Staging].[ODS_T_ChartDataPoint] CDP
-- uses dimension here to avoid aggregate same point multiple times due to fast DWH aggregation before datapoint is terminated
		left outer join DimDataPoint ddp on (cdp.Name = ddp.[DataPointName] and ddp.[DataPointType] = 'Chart')
		inner join [Staging].[ODS_T_ChartDataPointReading] CDPR ON CDP.ChartDataPointId = CDPR.ChartDataPointId
		inner join [Staging].[ODS_T_LogicalChart] LC on LC.LogicalChartId = CDP.LogicalChartId
		inner join [Staging].[ODS_T_Chart] C ON C.ChartId = LC.ChartId
		inner join [Staging].[ODS_T_Parameter] P ON P.ParameterId = C.ParameterId
		inner join [Staging].[ODS_T_ServiceHistory] SH WITH(NOLOCK) on SH.ServiceHistoryId = cdpr.LastServiceHistoryId
		left hash join (select distinct ChartDataPointId, /*CreatedBy, CreatedOn, ModifiedBy, ModifiedOn,*/
										Name, 
								first_value(Value) over (partition by ChartDataPointId, Name order by LastServiceHistoryId desc) as Value 
						   from [Staging].[ODS_T_ChartDataPointContext]
						  where isTemplate = 0
						    and LastServiceHistoryId between @MinServiceHistoryId and @MaxServiceHistoryId
							and Name in ('Material', 'Product','Resource','Flow','Step','Facility','MaterialOperation','DataCollection','DataCollectionInstance', 'Container')
						) AS SourceTable 
						pivot ( MIN(Value) FOR Name IN ([Material],[Product],[Resource],[Flow],[Step],[Facility],[MaterialOperation],[DataCollection],[DataCollectionInstance], [Container])) AS CDPC on CDP.ChartDataPointId = CDPC.ChartDataPointId
		left join (select MaterialId, Name from [Staging].[ODS_T_Material] where [version] = 0) dm on (dm.Name = CDPC.[Material])
		left join (select ProductId, Name from [Staging].[ODS_T_Product] where [version] = 0) dp on (dp.Name = CDPC.[Product])
		left join (select ResourceId, Name from [Staging].[ODS_T_Resource] where [version] = 0) dr on (dr.Name = CDPC.[Resource])
		left join (select FlowId, Name from [Staging].[ODS_T_Flow] where [version] = 0) df on (df.Name = CDPC.Flow)
		left join (select StepId, Name from [Staging].[ODS_T_Step] where [version] = 0) ds on (ds.Name = CDPC.Step)
		left join (select FacilityId, Name from [Staging].[ODS_T_Facility] where [version] = 0) dfac on (dfac.Name = CDPC.Facility)
		left join (select DataCollectionId, Name from [Staging].[ODS_T_DataCollection] where [version] = 0) dc on (dc.Name = CDPC.DataCollection)
		left join (select DataCollectionInstanceId, Name from [Staging].[ODS_T_DataCollectionInstance] where [version] = 0) dci on (dci.Name = CDPC.DataCollectionInstance)
		left join (select ContainerId, Name from [Staging].[ODS_T_Container] where [version] = 0) ct on (ct.Name = CDPC.[Container])
		left join [Staging].[ODS_T_OperationHistory] OH WITH(NOLOCK) on ( /*OH.EntityTypeName = 'ChartDataPoint' and*/ OH.ServiceHistoryId = cdpr.LastServiceHistoryId and OH.OperationHistorySeq = cdpr.LastOperationHistorySeq 
																and OH.ServiceHistoryId between @MinServiceHistoryId and @MaxServiceHistoryId)
		where p.IsTemplate = 0
		  and cdp.IsTemplate = 0
		  and cdpr.IsTemplate = 0
		  and lc.IsTemplate = 0
		  and c.IsTemplate = 0
-- following forces the index usage
		  and cdp.LastServiceHistoryId between @MinServiceHistoryId and @MaxServiceHistoryId
		  and (
-- process only if datapoint is still within the grace period or first time being processed
				ISNULL(ddp.IsClosedInDWH, 0) = 0
-- or 
-- following should only occur if @SPCPointRetentionReady is increased
-- DATEADD(hh, (-1)*@SPCPointRetentionReady, cdp.ModifiedOn) <= cdp.CreatedOn				
			  )
		) a
		where rnum=1
		OPTION(RECOMPILE);

		SET @RowCount = @@ROWCOUNT
		SET @EndTime = getdate()
		SET @Message = 'Loading %s ended at: ' + CONVERT(nvarchar,@EndTime,120) + '. ' + CONVERT(nvarchar, @RowCount) + ' row(s) inserted. Took ' + CONVERT(nvarchar,datediff(ms, @StartTime, @EndTime)) + 'ms'
		RAISERROR(@Message, 10, 1, @TableName) WITH NOWAIT
		UPDATE STATISTICS [Staging].[T_ChartDataPointReading]

-- ____            _                  _ __  __       _            _       _ 
--|  _ \ _ __ ___ | |_ ___   ___ ___ | |  \/  | __ _| |_ ___ _ __(_) __ _| |
--| |_) | '__/ _ \| __/ _ \ / __/ _ \| | |\/| |/ _` | __/ _ \ '__| |/ _` | |
--|  __/| | | (_) | || (_) | (_| (_) | | |  | | (_| | ||  __/ |  | | (_| | |
--|_|   |_|  \___/ \__\___/ \___\___/|_|_|  |_|\__,_|\__\___|_|  |_|\__,_|_|
                                                                           
		SET @TableName = 'Staging.T_Protocol_Material'
		SET @Message = 'Deleting %s...'
		RAISERROR(@Message, 10, 1, @TableName) WITH NOWAIT

		TRUNCATE TABLE Staging.T_Protocol_Material;
		
		SET @StartTime = getdate()
		SET @Message = 'Loading %s started at: ' + CONVERT(nvarchar,@StartTime,120)
		RAISERROR(@Message, 10, 1, @TableName) WITH NOWAIT
		
		INSERT INTO Staging.T_Protocol_Material WITH(TABLOCK)
		SELECT PM.ServiceHistoryId
			, PM.operationhistoryseq
			, PRI.ProtocolInstanceId
			, PRI.ParentEntityId as protocolid
			, PM.TargetEntityId MaterialId
			, ISNULL(A.AreaId,[Constants].[F_GetUndefinedKey]()) AreaId
			, MH.PrimaryQuantity
			, MH.SecondaryQuantity
			, MH.SubMaterialsPrimaryQuantity
			, MH.SubMaterialsSecondaryQuantity
			, PM.ModifiedBy
			, PM.ModifiedOn
		FROM Staging.ODS_T_ProtocolMaterialHistory PM
		INNER JOIN Staging.ODS_T_ProtocolInstance PRI ON PRI.ProtocolInstanceId = PM.SourceEntityId	
		CROSS APPLY (select top 1 MH1.*
		               from Staging.ODS_T_MaterialHistory MH1
					  where MH1.MaterialId = PM.TargetEntityId
					    and ( MH1.ServiceHistoryId < PM.ServiceHistoryId or
						      (MH1.ServiceHistoryId = PM.ServiceHistoryId and MH1.OperationHistorySeq <= PM.OperationHistorySeq)
							)
					  order by Mh1.ServiceHistoryId desc, Mh1.OperationHistorySeq desc
					) MH		
		LEFT OUTER JOIN Staging.ODS_T_StepArea SA ON SA.SourceEntityId = MH.StepId
		LEFT OUTER JOIN Staging.ODS_T_Area A ON A.AreaId = SA.TargetEntityId	AND A.FacilityId = MH.FacilityId
		WHERE PM.ServiceHistoryId between @MinServiceHistoryId and @MaxServiceHistoryId
		OPTION (RECOMPILE);
			
		SET @RowCount = @@ROWCOUNT
		SET @EndTime = getdate()
		SET @Message = 'Loading %s ended at: ' + CONVERT(nvarchar,@EndTime,120) + '. ' + CONVERT(nvarchar, @RowCount) + ' row(s) inserted. Took ' + CONVERT(nvarchar,datediff(ms, @StartTime, @EndTime)) + 'ms'
		RAISERROR(@Message, 10, 1, @TableName) WITH NOWAIT
		UPDATE STATISTICS [Staging].[T_Protocol_Material]

-- ____            _                  _ ___           _                       
--|  _ \ _ __ ___ | |_ ___   ___ ___ | |_ _|_ __  ___| |_ __ _ _ __   ___ ___ 
--| |_) | '__/ _ \| __/ _ \ / __/ _ \| || || '_ \/ __| __/ _` | '_ \ / __/ _ \
--|  __/| | | (_) | || (_) | (_| (_) | || || | | \__ \ || (_| | | | | (_|  __/
--|_|   |_|  \___/ \__\___/ \___\___/|_|___|_| |_|___/\__\__,_|_| |_|\___\___|
                                                                             
		SET @TableName = 'Staging.T_Protocol_Instance'
		SET @Message = 'Deleting %s...'
		RAISERROR(@Message, 10, 1, @TableName) WITH NOWAIT

 		TRUNCATE TABLE Staging.T_Protocol_Instance;
		
		SET @StartTime = getdate()
		SET @Message = 'Loading %s started at: ' + CONVERT(nvarchar,@StartTime,120)
		RAISERROR(@Message, 10, 1, @TableName) WITH NOWAIT
 		
-- distinct due to bug which allowed to create duplicated protocol resource relations
		INSERT INTO Staging.T_Protocol_Instance  WITH(TABLOCK)
			SELECT distinct proti.protocolInstanceid,prot.protocolid,proti.CreatedOn,
				ISNULL(PROTI.facilityid, [Constants].[F_GetUndefinedKey]()) facilityid,ISNULL(PROTI.FlowId, [Constants].[F_GetUndefinedKey]()) FlowId,
				ISNULL(PROTI.ProductId, [Constants].[F_GetUndefinedKey]()) ProductId, ISNULL(PROTI.StepId, [Constants].[F_GetUndefinedKey]()) StepId,
				ISNULL(TR.ResourceId, [Constants].[F_GetUndefinedKey]()) ResourceId, PROTI.SystemState, PROTI.InhibitMoveFromStep,PROTI.InhibitShip,
				PROTI.LastServiceHistoryId, 
				CASE WHEN (PROTI.SystemState = 1 ) 
					THEN PROTI.ModifiedOn 
				END TerminatedOn				
			FROM  [Staging].[ODS_T_Protocol] PROT 
				inner join [Staging].[ODS_T_ProtocolInstance] PROTI ON PROT.ProtocolId = PROTI.ParentEntityId
				LEFT OUTER JOIN [Staging].[ODS_T_ProtocolResource] PR  ON PR.SourceEntityId = PROTI.ProtocolInstanceId
				LEFT OUTER JOIN [Staging].[ODS_T_Resource] TR ON TR.ResourceId = PR.TargetEntityId
			WHERE PROTI.LastServiceHistoryId between @MinServiceHistoryId and @MaxServiceHistoryId 
		OPTION(RECOMPILE);
		
		SET @RowCount = @@ROWCOUNT
		SET @EndTime = getdate()
		SET @Message = 'Loading %s ended at: ' + CONVERT(nvarchar,@EndTime,120) + '. ' + CONVERT(nvarchar, @RowCount) + ' row(s) inserted. Took ' + CONVERT(nvarchar,datediff(ms, @StartTime, @EndTime)) + 'ms'
		RAISERROR(@Message, 10, 1, @TableName) WITH NOWAIT
		UPDATE STATISTICS [Staging].[T_Protocol_Instance]

-- ____            _                  _ ____                                _            
--|  _ \ _ __ ___ | |_ ___   ___ ___ | |  _ \ __ _ _ __ __ _ _ __ ___   ___| |_ ___ _ __ 
--| |_) | '__/ _ \| __/ _ \ / __/ _ \| | |_) / _` | '__/ _` | '_ ` _ \ / _ \ __/ _ \ '__|
--|  __/| | | (_) | || (_) | (_| (_) | |  __/ (_| | | | (_| | | | | | |  __/ ||  __/ |   
--|_|   |_|  \___/ \__\___/ \___\___/|_|_|   \__,_|_|  \__,_|_| |_| |_|\___|\__\___|_|   
                                                                                        
		SET @TableName = 'Staging.T_Protocol_Parameter'
		SET @Message = 'Deleting %s...'
		RAISERROR(@Message, 10, 1, @TableName) WITH NOWAIT

		TRUNCATE TABLE Staging.T_Protocol_Parameter;
		
		SET @StartTime = getdate()
		SET @Message = 'Loading %s started at: ' + CONVERT(nvarchar,@StartTime,120)
		RAISERROR(@Message, 10, 1, @TableName) WITH NOWAIT

		INSERT INTO Staging.T_Protocol_Parameter WITH(TABLOCK)
		select distinct ProtocolInstanceId, ProtocolPathId, ProtocolPathStateId, CheckListItemId, ParameterId,-- ParameterName,
			   FIRST_VALUE(ParameterValue) over (partition by ProtocolInstanceId, ProtocolPathId, ProtocolPathStateId, CheckListItemId, ParameterId order by LastServiceHistoryId desc) as ParameterValue,
			   FIRST_VALUE(NumericValue)  over (partition by ProtocolInstanceId, ProtocolPathId, ProtocolPathStateId, CheckListItemId, ParameterId order by LastServiceHistoryId desc) as NumericValue, 
			   FIRST_VALUE(StringValue)  over (partition by ProtocolInstanceId, ProtocolPathId, ProtocolPathStateId, CheckListItemId, ParameterId order by LastServiceHistoryId desc) as StringValue, 
			   FIRST_VALUE(ParameterKey)  over (partition by ProtocolInstanceId, ProtocolPathId, ProtocolPathStateId, CheckListItemId, ParameterId order by LastServiceHistoryId desc) as ParameterKey
		  from ( SELECT  PROTI.protocolinstanceid, PP.ProtocolPathId,PP.State ProtocolPathStateId, CKI.ParentEntityId as ChecklistItemId,
						ISNULL(CKIP.ChecklistItemParameterId, [Constants].[F_GetUndefinedKey]()) ParameterId, CKIP.Value ParameterValue,
						CASE WHEN CIP.Type in (0,1,5) AND dbo.[F_IsConvertableToDecimal](CKIP.Value,18,8) = 1 then CAST(CKIP.Value AS decimal(18,8))	
							 ELSE NULL
						END NumericValue,
						CASE WHEN CIP.Type in (4,6) THEN CKIP.Value 
							 WHEN CIP.Type in (0,1,5) AND dbo.[F_IsConvertableToDecimal](CKIP.Value,18,8) = 0 then CKIP.Value 
							 ELSE NULL
						END StringValue,
						-1 as parameterkey,
						CIP.name ParameterName,
						PROTI.LastServiceHistoryId
					FROM [Staging].[ODS_T_ProtocolInstance] PROTI 
						  INNER JOIN [Staging].[ODS_T_ProtocolPath] PP ON PP.ParentID = PROTI.ProtocolInstanceID
--INNER JOIN [Staging].[ODS_T_ChecklistInstance] CK ON CK.ChecklistInstanceId = PP.ChecklistId
						  INNER JOIN [Staging].[ODS_T_ChecklistItemInstance] CKI ON CKI.ChecklistInstanceID = PP.ChecklistId --CK.ChecklistInstanceID
						  LEFT OUTER JOIN [Staging].[ODS_T_ChecklistItemInstanceParameter] CKIP ON CKIP.ChecklistItemInstanceId = CKI.ChecklistItemInstanceId 
--INNER JOIN [Staging].[ODS_T_ChecklistItem] CI ON CKI.ParentEntityId = CI.ChecklistItemId
						  LEFT OUTER JOIN [Staging].[ODS_T_ChecklistItemParameter] CIP ON CIP.ChecklistItemId = CKI.ParentEntityId--CI.ChecklistItemId
													AND CKIP.ChecklistItemParameterId = CIP.ChecklistItemParameterId
					WHERE PROTI.LastServiceHistoryId between @MinServiceHistoryId and @MaxServiceHistoryId 
					UNION ALL 
					SELECT PROTI.protocolinstanceid,PP.ProtocolPathId, PP.State ProtocolPathStateId,
						[Constants].[F_GetUndefinedKey]() as ChecklistItemId,
						Par.protocolparameterid,PPP.ParameterValue,
						CASE WHEN par.datatype in (1,2) AND dbo.[F_IsConvertableToDecimal](PPP.ParameterValue,18,8) = 1 then CAST(PPP.ParameterValue AS decimal(18,8))	
							 ELSE NULL
						END NumericValue,
						CASE WHEN par.datatype in (1,2) AND dbo.[F_IsConvertableToDecimal](PPP.ParameterValue,18,8) = 0 then PPP.ParameterValue	
							 WHEN par.datatype in (0,5)  then PPP.ParameterValue
						END StringValue,
						-2 as parameterkey, Par.name ParameterName, PROTI.LastServiceHistoryId				   
					FROM [Staging].[ODS_T_ProtocolInstance] PROTI 
						INNER JOIN [Staging].[ODS_T_ProtocolPath] PP ON PP.ParentID = PROTI.ProtocolInstanceID 
						INNER JOIN [Staging].[ODS_T_ProtocolPathParameter] PPP ON PPP.SourceEntityId = PP.ProtocolPathId
						INNER JOIN [Staging].[ODS_T_ProtocolParameter] Par ON Par.protocolparameterid = PPP.TargetEntityId
					WHERE PROTI.LastServiceHistoryId between @MinServiceHistoryId and @MaxServiceHistoryId
				) a
		OPTION (RECOMPILE); 

		SET @RowCount = @@ROWCOUNT
		SET @EndTime = getdate()
		SET @Message = 'Loading %s ended at: ' + CONVERT(nvarchar,@EndTime,120) + '. ' + CONVERT(nvarchar, @RowCount) + ' row(s) inserted. Took ' + CONVERT(nvarchar,datediff(ms, @StartTime, @EndTime)) + 'ms'
		RAISERROR(@Message, 10, 1, @TableName) WITH NOWAIT
		UPDATE STATISTICS [Staging].[T_Protocol_Parameter]

-- ____                _            _   _              ___          _           _   _ _     _                   
--|  _ \ _ __ ___   __| |_   _  ___| |_(_) ___  _ __  / _ \ _ __ __| | ___ _ __| | | (_)___| |_ ___  _ __ _   _ 
--| |_) | '__/ _ \ / _` | | | |/ __| __| |/ _ \| '_ \| | | | '__/ _` |/ _ \ '__| |_| | / __| __/ _ \| '__| | | |
--|  __/| | | (_) | (_| | |_| | (__| |_| | (_) | | | | |_| | | | (_| |  __/ |  |  _  | \__ \ || (_) | |  | |_| |
--|_|   |_|  \___/ \__,_|\__,_|\___|\__|_|\___/|_| |_|\___/|_|  \__,_|\___|_|  |_| |_|_|___/\__\___/|_|   \__, |
--                                                                                                        |___/ 

		SET @TableName = 'Staging.T_ProductionOrderHistory'
		SET @Message = 'Deleting %s...'
		RAISERROR(@Message, 10, 1, @TableName) WITH NOWAIT

		TRUNCATE TABLE [Staging].[T_ProductionOrderHistory];
		
		SET @StartTime = getdate()
		SET @Message = 'Loading %s started at: ' + CONVERT(nvarchar,@StartTime,120)
		RAISERROR(@Message, 10, 1, @TableName) WITH NOWAIT

		INSERT INTO [Staging].[T_ProductionOrderHistory]
			  ([ServiceHistoryId]
			  ,[OperationHistorySeq]
			  ,[SubOperationSequence]
			  ,[OperationName]
			  ,[OperationStartTime]
			  ,[OperationEndTime]
			  ,[ProductionOrderId]
			  ,[DatabaseOperation]
			  ,[OldServiceHistoryId]
			  ,[OldOperationHistorySeq]
			  ,[ActiveMaterialsCount]
			  ,[Comment]
			  ,[CompletedQuantity]
			  ,[CustomerId]
			  ,[DataGroupId]
			  ,[DataGroupName]
			  ,[DeliveredQuantity]
			  ,[Description]
			  ,[DistributionList]
			  ,[DocumentationURL]
			  ,[DueDate]
			  ,[FacilityId]
			  ,[Image]
			  ,[InProgressQuantity]
			  ,[IsRestricted]
			  ,[IsTemplate]
			  ,[MainStateModelId]
			  ,[MainStateModelStateId]
			  ,[MainStateModelStateReason]
			  ,[MaterialsInProgressCount]
			  ,[MaterialsCompletedCount]
			  ,[MaterialsDeliveredCount]
			  ,[ModifiedBy]
			  ,[ModifiedOn]
			  ,[Name]
			  ,[NotificationDate]
			  ,[NotifyChanges]
			  ,[OrderNumber]
			  ,[OrderLine]
			  ,[OverDeliveryTolerance]
			  ,[OwnerRoleId]
			  ,[PlannedStartDate]
			  ,[PlannedEndDate]
			  ,[Priority]
			  ,[ProductId]
			  ,[Quantity]
			  ,[RestrictOnComplete]
			  ,[SystemState]
			  ,[Type]
			  ,[Units]
			  ,[UniversalState]
			  ,[ValidateMaterialProducts]
			  ,[Version]
			  ,[Processed])
		SELECT POH.[ServiceHistoryId]
			  ,POH.[OperationHistorySeq]
			  ,ISNULL(OH.[SubOperationSequence], 0) [SubOperationSequence]
			  ,ISNULL(OH.[OperationName], 'NoOperation') [OperationName] 
			  ,ISNULL(OH.[OperationStartTime], [ModifiedOn]) [OperationStartTime]
			  ,ISNULL(OH.[OperationEndTime], [ModifiedOn]) [OperationEndTime]
			  ,[ProductionOrderId]
			  ,[DatabaseOperation]
			  ,[OldServiceHistoryId]
			  ,[OldOperationHistorySeq]
			  ,[ActiveMaterialsCount]
			  ,[Comment]
			  ,[CompletedQuantity]
			  ,[CustomerId]
			  ,[DataGroupId]
			  ,[DataGroupName]
			  ,[DeliveredQuantity]
			  ,[Description]
			  ,[DistributionList]
			  ,[DocumentationURL]
			  ,[DueDate]
			  ,[FacilityId]
			  ,[Image]
			  ,[InProgressQuantity]
			  ,[IsRestricted]
			  ,[IsTemplate]
			  ,[MainStateModelId]
			  ,[MainStateModelStateId]
			  ,[MainStateModelStateReason]
			  ,[MaterialsInProgressCount]
			  ,[MaterialsCompletedCount]
			  ,[MaterialsDeliveredCount]
			  ,[ModifiedBy]
			  ,[ModifiedOn]
			  ,[Name]
			  ,[NotificationDate]
			  ,[NotifyChanges]
			  ,[OrderNumber]
			  ,[OrderLine]
			  ,[OverDeliveryTolerance]
			  ,[OwnerRoleId]
			  ,[PlannedStartDate]
			  ,[PlannedEndDate]
			  ,[Priority]
			  ,[ProductId]
			  ,[Quantity]
			  ,[RestrictOnComplete]
			  ,[SystemState]
			  ,[Type]
			  ,[Units]
			  ,[UniversalState]
			  ,[ValidateMaterialProducts]
			  ,[Version]
			  ,0 as Processed
          FROM [Staging].[ODS_T_ProductionOrderHistory] POH
		 LEFT OUTER JOIN [Staging].[ODS_T_OperationHistory] OH  WITH (NOLOCK) on OH.ServiceHistoryId = POH.ServiceHistoryId 
														 and OH.OperationHistorySeq = POH.OperationHistorySeq 
														 and OH.EntityId = POH.ProductionOrderId  
														 and OH.EntityTypeName = 'ProductionOrder'
		where POH.ServiceHistoryId between @MinServiceHistoryId AND @MaxServiceHistoryId AND POH.IsTemplate = 0
		OPTION (RECOMPILE); 

		SET @RowCount = @@ROWCOUNT
		SET @EndTime = getdate()
		SET @Message = 'Loading %s ended at: ' + CONVERT(nvarchar,@EndTime,120) + '. ' + CONVERT(nvarchar, @RowCount) + ' row(s) inserted. Took ' + CONVERT(nvarchar,datediff(ms, @StartTime, @EndTime)) + 'ms'
		RAISERROR(@Message, 10, 1, @TableName) WITH NOWAIT

		UPDATE STATISTICS [Staging].[T_ProductionOrderHistory];

		SET @StatusMessage = OBJECT_NAME(@@PROCID) + ': ' + CAST(@@ROWCOUNT AS VARCHAR) + ' finished.'
		
		RAISERROR (@StatusMessage, 0, 1) WITH NOWAIT

		EXEC Control.P_StopExecution @PROCNAME, @StatusMessage;

-- If There was no transaction on the beginning of the exception, a new one was created and has to be committed.
		IF @starttrancount = 0
			COMMIT TRANSACTION;

	END TRY
	BEGIN CATCH
		IF XACT_STATE() <> 0 AND @starttrancount = 0 
			ROLLBACK TRANSACTION

		EXEC Control.P_StopExecution @PROCNAME;

		SELECT @ErrorMessage = ERROR_MESSAGE() + ' Line ' + CAST(ERROR_LINE() AS NVARCHAR(5)), @ErrorSeverity = ERROR_SEVERITY(), @ErrorState = ERROR_STATE();
		RAISERROR (@ErrorMessage, @ErrorSeverity, @ErrorState);


	END CATCH
END
GO
