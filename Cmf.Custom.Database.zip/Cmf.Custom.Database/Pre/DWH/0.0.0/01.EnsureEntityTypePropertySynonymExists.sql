DECLARE @SystemName NVARCHAR(512) = [dbo].[F_GetSystemName]()
DECLARE @ODSDatabase NVARCHAR(512) = @SystemName + N'ODS'
DECLARE @ODSLink NVARCHAR(512) = N'cm' + @SystemName + 'ODSLink'
DECLARE @SqlStatement NVARCHAR(MAX) = N'
IF(NOT EXISTS(
	SELECT *
	FROM [sys].[synonyms] SSN
	INNER JOIN [sys].[schemas] SS ON SS.[schema_id] = SSN.[schema_id]
	WHERE SSN.[name] = N''ODS_T_EntityTypeProperty''
		AND SS.[name] = N''Staging''
))
BEGIN
	CREATE SYNONYM [Staging].[ODS_T_EntityTypeProperty] FOR [' + @ODSLink +  '].[' + @ODSDatabase + '].[dbo].[T_EntityTypeProperty]
END
'

EXEC sp_executesql @SqlStatement