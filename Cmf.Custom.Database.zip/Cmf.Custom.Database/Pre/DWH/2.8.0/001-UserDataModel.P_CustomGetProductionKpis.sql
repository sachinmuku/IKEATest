/******************************
** Name: UserDataModel.P_CustomGetProductionKpis
** Description: Procedure to get the production kpis: OEE, resource times, MTBF, MTTR, etc;
** Author: Paulo Soares
** Date: 28-Apr-2021
**************************

** Version History

** Version  Date          Author                       Description 
** ---------------------------------------------------------------------------------------------------------------------------------------------                    
** Sprint 8  28/Apr/2021  Paulo S.                      Procedure to get the production kpis: OEE, resource times, MTBF, MTTR, etc;
*/
CREATE OR ALTER  PROCEDURE [UserDataModel].[P_CustomGetProductionKpis] 
  @FacilityId          NVARCHAR(MAX),
  @NFacTotalElems      INT,
  @AreaId              NVARCHAR(MAX),
  @NAreaTotalElems     INT,
  @ShiftId             NVARCHAR(MAX),
  @NShiftsTotalElems   INT, 
  @ResourceId          NVARCHAR(MAX),
  @NResourceTotalElems INT, 
  @CalendarYear        INT = NULL,
  @QuarterNumberOfYear INT = NULL,
  @MonthNumberOfYear   INT = NULL,
  @WeekNumberOfYear    INT = NULL,
  @DayNumberOfMonth    INT = NULL,
  @ProductName         NVARCHAR(MAX) = NULL
AS
BEGIN
--DECLARE
--  @FacilityId NVARCHAR(MAX)='2101150000130000001,2101150000130000002,2101150000130000003,2101150000130000004',
--  @NFacTotalElems INT=5,
--  @AreaId NVARCHAR(MAX)='2101150000130000001,2101150000130000002,2101150000130000003',
--  @NAreaTotalElems INT = 5,
--  @ShiftId NVARCHAR(MAX),
--  @NShiftsTotalElems INT, 
--  @ResourceId NVARCHAR(MAX)=NULL,--'2101150000130000005',
--  @NResourceTotalElems INT=0, 
--  @CalendarYear INT = 2021,
--  @QuarterNumberOfYear INT = NULL,
--  @MonthNumberOfYear   INT = NULL,
--  @WeekNumberOfYear    INT = NULL,
--  @DayNumberOfMonth    INT = NULL,
--  @ProductName         NVARCHAR(MAX) =NULL--'Cut Board 100x100'

SET NOCOUNT ON

BEGIN /* Filters instantiation */
  DECLARE @RowCount INT;
  
  DECLARE @DateStart			DATETIME
	 DECLARE @DateEnd		  	DATETIME  
  /* Date filters initialization */
  IF ISNUll(@CalendarYear,0) = 0 SET @CalendarYear = YEAR(GETDATE())
  IF @QuarterNumberOfYear=0      SET @QuarterNumberOfYear= NULL
  IF @MonthNumberOfYear = 0      SET @MonthNumberOfYear = NULL
  IF @WeekNumberOfYear = 0       SET @WeekNumberOfYear = NULL
  IF @DayNumberOfMonth = 0       SET @DayNumberOfMonth = NULL


  /* Date Filters conversion in start and end datetimes */
  SELECT @DateStart=MiN(FullDateAlternateKey),
         @DateEnd = CONVERT(DATETIME, CONVERT(varchar(11),MAX(FullDateAlternateKey), 111 ) + ' 23:59:59', 111)
    FROM DimDate DD
   WHERE DD.CalendarYear = @CalendarYear
     AND (@MonthNumberOfYear IS NULL OR DD.MonthNumberOfYear = @MonthNumberOfYear)
     AND (@WeekNumberOfYear IS NULL OR DD.WeekNumberOfYear = @WeekNumberOfYear)
     AND (@DayNumberOfMonth IS NULL OR DD.DayNumberOfMonth = @DayNumberOfMonth)   
   

  DECLARE @ProcName nvarchar(30) = 'P_LoadFactResourceServiceTime';
  --
  -- #Temp Tables Check
  --
  IF(object_id('tempdb..#ELIGIBLE_RESOURCES') is not null)           DROP TABLE #ELIGIBLE_RESOURCES
  IF(object_id('tempdb..#PROCESSED_MATERIALS') is not null)          DROP TABLE #PROCESSED_MATERIALS
  IF(object_id('tempdb..#MAT_PERF') is not null)                     DROP TABLE #MAT_PERF
  IF(object_id('tempdb..#ELIGIBLE_RESOURCES_CONDENSED') is not null) DROP TABLE #ELIGIBLE_RESOURCES_CONDENSED
  IF(object_id('tempdb..#IDEAL_PROCESSED_QUANTITY') is not null)     DROP TABLE #IDEAL_PROCESSED_QUANTITY
  IF(object_id('tempdb..#RES_PERF') is not null)                     DROP TABLE #RES_PERF
  IF(object_id('tempdb..#RES_IDEAL_QTY') is not null)                DROP TABLE #RES_IDEAL_QTY
  --
  -- Facility Filter
  --
  DECLARE @HasFacilityFilter BIT;
  DECLARE @FacilityTab TABLE
  ( 
    FacilityKey BIGINT
  );
  INSERT INTO @FacilityTab(FacilityKey)
    SELECT dF.FacilityKey
      FROM DataSets.fnSplit(@FacilityId, ',') f
      INNER JOIN [DataSets].[V_DimFacility] dF
      ON (CONVERT(BIGINT, f.item) = dF.FacilityId);

  SET @RowCount = @@ROWCOUNT;
  IF (@RowCount > 0  AND @RowCount <> @NFacTotalElems) 
  BEGIN
     SET @HasFacilityFilter = 1
  END
  ELSE 
  BEGIN
     SET @HasFacilityFilter = 0;
     DELETE FROM @FacilityTab;
  END
 
  --
  -- Area Filter
  --
  DECLARE @HasAreaFilter BIT;
  DECLARE @AreaTab TABLE
  (
    AreaKey bigint
  ); 
  INSERT INTO @AreaTab(AreaKey) 
    SELECT dA.AreaKey
      FROM DataSets.fnSplit(@AreaId, ',') a
      INNER JOIN [DataSets].[V_DimArea] dA
      ON (dA.AreaId = CONVERT(BIGINT, a.item));

  SET @RowCount = @@ROWCOUNT;
  IF (@RowCount > 0  AND @RowCount <> @NAreaTotalElems) 
  BEGIN
     SET @HasAreaFilter = 1
  END

  ELSE 
  BEGIN
    SET @HasAreaFilter = 0;
    DELETE FROM @AreaTab;
  END

  --
  -- Shifts Filter
  --
  DECLARE @HasShifts BIT;
  DECLARE @ShiftsTab TABLE
  ( 
    ShiftKey BIGINT
  );
  INSERT INTO @ShiftsTab
     SELECT dP.ShiftKey AS ShiftKey
       FROM DataSets.fnSplit(@Shiftid, ',') s
       INNER JOIN [DataSets].[V_DimShift] dP
       ON (dP.ShiftDefinitionShiftId = CONVERT(BIGINT, s.item));

  SET @RowCount = @@ROWCOUNT;
  IF (@RowCount > 0  AND @RowCount <> @NShiftsTotalElems) 
  BEGIN
    SET @HasShifts = 1
  END
  ELSE 
  BEGIN
    SET @HasShifts = 0;
    DELETE FROM @ShiftsTab;
  END 

  --
  -- Resources Filter
  --
  DECLARE @HasResources BIT;
  DECLARE @ResourcesTab TABLE
  ( 
   ResourceKey BIGINT
  );
 INSERT INTO @ResourcesTab
     SELECT dP.ResourceKey AS ResourceKey
       FROM DataSets.fnSplit(@ResourceId, ',') s
       INNER JOIN [DataSets].[V_DimResource] dP
       ON (dP.[ResourceId] = CONVERT(BIGINT, s.item));

  SET @RowCount = @@ROWCOUNT;
  IF (@RowCount > 0  AND @RowCount <> @NResourceTotalElems) 
  BEGIN
    SET @HasResources = 1
  END
  ELSE 
  BEGIN
    SET @HasResources = 0;
    DELETE FROM @ResourcesTab;
  END 
  
  --Adittional variables declarations
  DECLARE @DateStartHost DATETIME = CAST(CAST(@DateStart AS FLOAT) AS DATETIME)
  DECLARE @DateEndHost DATETIME = CAST(CAST(@DateEnd AS FLOAT) AS DATETIME)
  DECLARE @DateStartHostInt INT = [dbo].[F_GetDateKeyFROMDateTime](@DateStartHost);
  DECLARE @DateEndHostInt INT = [dbo].[F_GetDateKeyFROMDateTime](@DateEndHost);
  DECLARE @DateStartHostIntPartId INT = [dbo].[F_GetDateKeyFROMDateTime](@DateStartHost-2);
  DECLARE @DateEndHostIntPartId INT = [dbo].[F_GetDateKeyFROMDateTime](@DateEndHost+2);

 END; 
 BEGIN
  /* Resources filtered */
  SELECT R.ResourceKey, R.ResourceName
    INTO #ELIGIBLE_RESOURCES
    FROM DataSets.V_DimResource R
    LEFT OUTER JOIN @ResourcesTab RR ON (RR.ResourceKey = R.ResourceKey)
   WHERE (@HasResources = 0 OR RR.ResourceKey > 0)
  OPTION (RECOMPILE);
   
 END
 CREATE CLUSTERED INDEX TMP_IDX_ELIGIBLE_RESOURCES ON #ELIGIBLE_RESOURCES(ResourceKey);
 
 /* Processed Materials */
 BEGIN 
     SELECT a.ShiftDateKey
            ,a.shiftkey 
            ,a.AreaKey 
            ,a.ResourceKey
            ,SUM(ParcelProcessingQuantity) AS ProcessedQuantity
            ,SUM(ParcelInputQuantity) AS InputQuantity
						      ,CAST(SUM(ISNULL(lb.MaterialsPrimaryQuantityLoss,0))  AS DECIMAL(38,15)) AS MaterialsPrimaryQuantityLoss
						      ,CAST(SUM(ISNULL(lb.MaterialsPrimaryQuantityBonus,0)) AS DECIMAl(38,15)) AS MaterialsPrimaryQuantityBonus
       INTO #MAT_PERF
       FROM (SELECT mat.shiftkey
                    ,mat.ShiftDateKey
                    ,mat.AreaKey
                    ,mat.ResourceKey
                    ,SUM(ISNULL(mat.ParcelOutTotalQuantityNormalized,0)) AS ParcelProcessingQuantity
                    ,SUM(ISNULL(mat.ParcelInTotalQuantityNormalized,0)) AS ParcelInputQuantity
               FROM #ELIGIBLE_RESOURCES ER    
               INNER HASH JOIN FactMaterialProcessTime mat ON (ER.ResourceKey = mat.ResourceKey)     
               INNER HASH JOIN dbo.DimArea DA ON (DA.AreaKey = mat.AreaKey)
               INNER HASH JOIN dbo.DimProduct DP ON (DP.ProductKey = mat.ProductKey)
               LEFT OUTER HASH JOIN @AreaTab AT ON (AT.AreaKey = DA.AreaKey)
               LEFT OUTER HASH JOIN @FacilityTab F ON (F.FacilityKey = DA.FacilityKey)
               LEFT OUTER HASH JOIN @ShiftsTab SF ON (SF.ShiftKey = mat.ShiftKey)
              WHERE (@HasAreaFilter = 0 OR AT.AreaKey > 0)
               AND (@HasFacilityFilter = 0 OR F.FacilityKey > 0)
               --shift and time filter
               AND  mat.ShiftDateKey between @DateStartHostInt AND @DateEndHostInt 
               AND mat.DateKey between @DateStartHostIntPartId AND @DateEndHostIntPartId
               -- parcel should be included within the timeframe SELECTed by users
               AND mat.LC1ParcelStartDateTime between @DateStartHost AND @DateEndHost
               AND mat.LC1ParcelEndDateTime between @DateStartHost AND @DateEndHost
               AND (@HasShifts = 0 OR SF.ShiftKey > 0)
               AND (@ProductName IS NULL OR DP.ProductName LIKE '%'+@ProductName+'%')
            GROUP BY mat.shiftkey
                     ,mat.ShiftDateKey
                     ,mat.AreaKey
                     ,mat.ResourceKey
          ) a
            LEFT JOIN (SELECT bl.shiftkey
                              ,bl.ShiftDateKey
                              ,bl.AreaKey
                              ,bl.ResourceKey,
                              SUM (ISNULL(TotalPrimaryQuantityLossNormalized,0) + ISNULL(TotalSubResourcesPrimaryQuantityLossNormalized,0))  MaterialsPrimaryQuantityLoss,
                              SUM (ISNULL(TotalPrimaryQuantityBonusNormalized,0) + ISNULL(TotalSubResourcesPrimaryQuantityBonusNormalized,0)) MaterialsPrimaryQuantityBonus
                         FROM V_FactMaterialLossBonusTime bl            
                         INNER HASH JOIN #ELIGIBLE_RESOURCES ER ON (ER.ResourceKey = bl.ResourceKey)
                         INNER HASH JOIN dbo.DimArea DA ON (DA.AreaKey = bl.AreaKey)
                         INNER HASH JOIN dbo.DimProduct DP ON (DP.ProductKey = bl.ProductKey)
                         LEFT OUTER HASH JOIN @AreaTab                 AT ON (AT.AreaKey = bl.AreaKey)
                         LEFT OUTER HASH JOIN @FacilityTab             F ON (F.FacilityKey = DA.FacilityKey)
                         LEFT OUTER HASH JOIN @ShiftsTab               SF ON (SF.ShiftKey = bl.ShiftKey)  
                         WHERE bl.ShiftDateKey between @DateStartHostInt AND @DateEndHostInt 
                           AND bl.DateKey between @DateStartHostIntPartId AND @DateEndHostIntPartId        
                           AND (@HasAreaFilter = 0 OR AT.AreaKey > 0)
                           AND (@HasFacilityFilter = 0 OR F.FacilityKey > 0)
                           AND (@HasShifts = 0 OR SF.ShiftKey > 0)
                           AND (@ProductName IS NULL OR DP.ProductName LIKE '%'+@ProductName+'%')
                        GROUP BY bl.ShiftKey
                                 ,bl.ShiftDateKey
                                 ,bl.AreaKey
                                 ,bl.ResourceKey
                      ) lb ON lb.shiftkey = a.shiftkey 
                          AND lb.ShiftDateKey = a.ShiftDateKey 
                          AND lb.ResourceKey = a.ResourceKey 
                          AND a.AreaKey = lb.AreaKey
      GROUP BY a.shiftkey
               ,a.ShiftDateKey
               ,a.AreaKey
               ,a.ResourceKey


 SELECT RMP.ResourceKey
        ,RMP.AreaKey 
        ,SUM(RMP.ProcessedQuantity)            ProcessedQuantity
        ,SUM(RMP.InputQuantity)                InputQuantity
        ,SUM(RMP.MaterialsPrimaryQuantityLoss) LossQuantity
   INTO #PROCESSED_MATERIALS
   FROM (SELECT matperf.ResourceKey
                ,matperf.AreaKey
                ,matperf.ProcessedQuantity
                ,matperf.InputQuantity
                ,ISNULL(matperf.MaterialsPrimaryQuantityLoss,0.0)  AS MaterialsPrimaryQuantityLoss
                ,ISNULL(matperf.MaterialsPrimaryQuantityBonus,0.0) AS MaterialsPrimaryQuantityBonus
           FROM #MAT_PERF AS matperf
        )RMP
   GROUP BY RMP.ResourceKey, RMP.AreaKey
   OPTION(RECOMPILE);

  CREATE CLUSTERED INDEX TMP_IDX_PROCESSED_MATERIALS ON #PROCESSED_MATERIALS(ResourceKey, AreaKey );
  
 END
 
 BEGIN

  SELECT MAX(IdealBaseCycleTime) IdealBaseCycleTime
         ,FIQ.ResourceKey
         ,DateKey
         ,ShiftKey
         ,AreaKey
    INTO #RES_IDEAL_QTY
    FROM FactResourceIdealQuantity  FIQ
    JOIN #ELIGIBLE_RESOURCES        ER On FIQ.ResourceKey= ER.ResourceKey
   WHERE FIQ.ShiftDateKey BETWEEN @DateStartHostInt AND @DateEndHostInt 
     AND FIQ.DateKey BETWEEN @DateStartHostIntPartId AND @DateEndHostIntPartId
    GROUP BY FIQ.ResourceKey
            ,DateKey
            ,ShiftKey
            ,AreaKey
   CREATE CLUSTERED INDEX IDC_FRIQ ON #RES_IDEAL_QTY (ResourceKey, AreaKey, DateKey, ShiftKey,IdealBaseCycleTime);
                                                      
 END 
 
-- ELIGIBLE RESOURCE RECORDS
 BEGIN
  SELECT ResourceKey
         ,FacilityKey
         ,AreaKey
         ,StateModelStateReason
         ,MIN(ShiftStartDateTime)       StartTimeStamp
         ,MAX(ShiftEndDateTime)         EndTimeStamp
         ,SUM(UpDuration)               UpDuration
         ,SUM(DownToUpTransition)       DownToUpTransition
         ,SUM(UpToDownTransition)       UpToDownTransition
         ,SUM(ProductiveDuration)       ProductiveDuration
         ,SUM(StandbyDuration)          StandbyDuration
         ,SUM(EngineeringDuration)      EngineeringDuration
         ,SUM(UnscheduledDownDuration)  UnscheduledDownDuration
         ,SUM(ResourceGlobalTime)       ResourceGlobalTime
         ,SUM(ResourceDownTime)         ResourceDownTime	 
		       ,SUM(ResourceUpTime)           ResourceUpTime
		       ,SUM(ResourceNumberOfFailures) ResourceNumberOfFailures
		       ,SUM(ResourceNumberOfRepairs)  ResourceNumberOfRepairs
         ,SUM(ResourceLoadingTime)      ResourceLoadingTime
         ,SUM(ResourceRunningTime)      ResourceRunningTime
         ,SUM(ResourceSetupTime)        ResourceSetupTime
         ,SUM(ResourceStopTime)         ResourceStopTime
         ,SUM(IdealQuantity)            ResourceIdealQuantity
         ,MAX(IdealBaseCycleTime)       IdealBaseCycleTime
     INTO #ELIGIBLE_RESOURCES_CONDENSED
     FROM (SELECT  
                  f.ResourceKey                         ResourceKey
                  ,f.DateKey                            DateKey
                  ,f.ShiftDateKey                       ShiftDateKey
                  ,f.ShiftKey                           ShiftKey
                  ,cds.LC1StartDateTime                 ShiftStartDateTime
                  ,cds.LC1EndDateTime                   ShiftEndDateTime
                  ,f.AreaKey                            AreaKey
                  ,DA.FacilityKey                       FacilityKey
                  ,ISNULL(f.UpDuration, 0)              UpDuration
                  ,f.DownToUpTransition                 DownToUpTransition
                  ,f.UpToDownTransition                 UpToDownTransition
                  ,ISNULL(f.ProductiveDuration, 0)      ProductiveDuration
                  ,ISNULL(f.StandbyDuration, 0)         StandbyDuration
                  ,ISNULL(f.EngineeringDuration, 0)     EngineeringDuration
                  ,ISNULL(f.ScheduledDownDuration, 0)   ScheduledDownDuration
                  ,ISNULL(f.UnscheduledDownDuration, 0) UnscheduledDownDuration
                  ,ISNULL(f.DownDuration, 0) 
                  +ISNULL(f.UpDuration, 0)                 ResourceGlobalTime
			               ,ISNULL(f.UpDurationForTransitions, 0)   ResourceUpTime
			               ,ISNULL(f.DownDurationForTransitions, 0) ResourceDownTime
			               ,ISNULL(f.DownToUpTransition,0)          ResourceNumberOfRepairs
		               	,ISNULL(f.UpToDownTransition,0)          ResourceNumberOfFailures
                  ,CASE WHEN DRSM.StateModelStateName NOT IN ('NOT PLANNED TIME','UN-PLANNED TIME')
                            THEN COALESCE(f.UpDuration,f.DownDuration,0)    
                   END                                     ResourceLoadingTime
                  ,CASE WHEN DRSM.StateModelStateName NOT IN ('NOT PLANNED TIME','UN-PLANNED TIME','WAITING TIME','BREAKDOWN TIME MACHINE')
                            THEN COALESCE(f.UpDuration,f.DownDuration,0)    
                   END                                     ResourceRunningTime
                  ,CASE WHEN DRSM.StateModelStateName ='BREAKDOWN TIME MACHINE'
                            THEN ISNULL(f.DownDuration,0)      
                   END                                     ResourceStopTime
                  ,ISNULL(f.SetupTime,0)                   ResourceSetupTime
                  ,CASE WHEN DRSM.StateModelStateName ='BREAKDOWN TIME MACHINE'
                            THEN MainStateModelStateReason
                   END                                     StateModelStateReason 
                  ,CASE WHEN FIQ.IdealBaseCycleTime IS NULL THEN NULL
                        ELSE CASE WHEN DRSM.StateModelStateName NOT IN ('NOT PLANNED TIME','UN-PLANNED TIME','WAITING TIME','BREAKDOWN TIME MACHINE')
                                      THEN COALESCE(f.UpDuration,f.DownDuration,0) 
                                   ELSE 0   
                             END / FIQ.IdealBaseCycleTime
                   END IdealQuantity
                  ,ISNULL(FIQ.IdealBaseCycleTime,0)    IdealBaseCycleTime
              FROM [dbo].[V_FactResource]              f
              INNER HASH JOIN #ELIGIBLE_RESOURCES      ER  ON (ER.ResourceKey = f.ResourceKey) 
              INNER  JOIN #RES_IDEAL_QTY               FIQ ON f.ResourceKey= FIQ.ResourceKey 
                                                          AND f.AreaKey=FIQ.AreaKey
                                                          AND f.DateKey = FIQ.DateKey
                                                          AND f.ShiftKey = FIQ.ShiftKey                                        
              INNER JOIN FactShift                     CDS ON (f.ShiftKey = CDS.ShiftKey AND CDS.DateKey = f.ShiftDateKey AND CDS.AreaKey = f.AreaKey)
              INNER HASH JOIN dbo.DimArea              DA  ON (DA.AreaKey = f.AreaKey)
              LEFT OUTER HASH JOIN @AreaTab            AT  ON (AT.AreaKey = f.AreaKey)
              LEFT OUTER HASH JOIN @FacilityTab        FT  ON (FT.FacilityKey = DA.FacilityKey)
              LEFT OUTER HASH JOIN @ShiftsTab          SF  ON (SF.ShiftKey = f.ShiftKey)      
              INNER HASH JOIN DimResourceStateModel   DRSM ON DRSM.ResourceStateModelKey = f.ResourceStateModelKey
              INNER HASH JOIN DimDate DD ON F.DateKey = DD.DateKey
                                        AND DD.CalendarYear = @CalendarYear
                                        AND (@MonthNumberOfYear IS NULL OR DD.MonthNumberOfYear = @MonthNumberOfYear)
                                        AND (@WeekNumberOfYear IS NULL OR DD.WeekNumberOfYear = @WeekNumberOfYear)
                                        AND (@DayNumberOfMonth IS NULL OR DD.DayNumberOfMonth = @DayNumberOfMonth)
              WHERE (@HasAreaFilter = 0 OR AT.AreaKey > 0)
                AND (@HasFacilityFilter = 0 OR FT.FacilityKey > 0)
                AND f.ShiftDateKey between @DateStartHostInt AND @DateEndHostInt 
                AND f.DateKey between @DateStartHostIntPartId AND @DateEndHostIntPartId
                AND f.LC1OperationEndtime between @DateStartHost AND @DateEndHost
                AND CDS.LC1StartDatetime  between @DateStartHost AND  @DateEndHost    
                AND CDS.LC1EndDatetime  between @DateStartHost AND  @DateEndHost  
                AND (@HasShifts = 0 OR SF.ShiftKey > 0)
      ) DATA
  GROUP BY ResourceKey, FacilityKey, AreaKey,StateModelStateReason
  OPTION(RECOMPILE);
  CREATE CLUSTERED INDEX TMP_IDX_ELIGIBLE_RESOURCES_COND ON #ELIGIBLE_RESOURCES_CONDENSED(ResourceKey, FacilityKey, AreaKey );
 
 
 END
 
 SELECT ERR.ResourceKey                                ResourceKey
        ,DR.ResourceName                               Resource
        ,DR.Model                                      ResourceModel
        ,DR.ResourceType                               ResourceType
        ,ERR.StartTimeStamp                            StartTimeStamp
        ,ERR.EndTimeStamp                              EndTimeStamp
        ,ERR.FacilityKey                               FacilityKey
        ,DF.FacilityName                               Facility
        ,DF.FacilityDisplayOrder                       FacilityDisplayOrder
        ,ERR.AreaKey                                   AreaKey
        ,DA.AreaName                                   Area
        ,DA.AreaDisplayOrder                           AreaDisplayOrder
        ,ISNULL(PM.LossQuantity,0)                     ResourceLossQuantity
        ,ISNULL(PM.ProcessedQuantity,0)                ResourceProcessedQuantity
        ,ISNULL(PM.InputQuantity,0)                    ResourceInputQuantity
        ,UnscheduledDownDuration                       ResourceUnscheduledDownDuration
        ,ProductiveDuration
        ,PM.ProcessedQuantity
        ,PM.LossQuantity
        ,ERR.ResourceIdealQuantity
        ,ERR.IdealBaseCycleTime
		      ,ResourceNumberOfFailures
		      ,ResourceNumberOfRepairs
        ,ResourceUpTime
        ,ResourceDownTime
        ,ResourceLoadingTime
        ,ResourceRunningTime
        ,ResourceSetupTime
        ,ResourceStopTime
        ,StateModelStateReason 
        ,ISNULL(ERR.ResourceGlobalTime, 0)            ResourceGlobalTime
        ,CASE WHEN ISNULL(PM.InputQuantity, 0) = 0 
                  THEN 0
              ELSE CONVERT(DECIMAL(38,15),(PM.InputQuantity - PM.LossQuantity)) / (CONVERT(DECIMAL(38,15),PM.InputQuantity))
         END                                          ResourceRateOfQuality
         ,CASE WHEN ISNULL(ERR.ResourceLoadingTime, 0) = 0 
                  THEN 0
             ELSE CONVERT(DECIMAL(38,15), ISNULL(ERR.ResourceRunningTime, 0)) / CONVERT(DECIMAL(38,15),ERR.ResourceLoadingTime)
        END                                           ResourceAvailability
        ,CASE WHEN ISNULL(ERR.ResourceIdealQuantity, 0) = 0 
                  THEN 0
              ELSE CONVERT(DECIMAL(38,15),ISNULL(PM.InputQuantity, 0)) / CONVERT(DECIMAL(38,15),ERR.ResourceIdealQuantity) 
         END                                          ResourcePerformance
    INTO #REPORT_DATA
    FROM #ELIGIBLE_RESOURCES_CONDENSED        ERR
    INNER HASH JOIN DimResource DR               ON DR.ResourceKey = ERR.ResourceKey
    INNER HASH JOIN DimArea DA                   ON DA.AreaKey = ERR.AreaKey
    INNER HASH JOIN DimFacility DF               ON DF.FacilityKey = ERR.FacilityKey
    LEFT HASH JOIN  #PROCESSED_MATERIALS      PM ON PM.ResourceKey = ERR.ResourceKey
                                                AND PM.AreaKey = ERR.AreaKey
                                                AND ERR.ResourceDownTime=0

    WHERE ERR.ResourceGlobalTime > 0
 OPTION(RECOMPILE);
 
 SELECT * 
   FROM #REPORT_DATA RD
   
 OPTION(RECOMPILE);

 DROP TABLE #REPORT_DATA;
 
END
GO

