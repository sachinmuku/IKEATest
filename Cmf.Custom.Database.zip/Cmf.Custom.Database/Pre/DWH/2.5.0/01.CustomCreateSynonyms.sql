IF  EXISTS (SELECT name FROM sys.synonyms WHERE name = N'ODS_T_GT_ProductUnitConversionFactorsHistory')
     DROP SYNONYM  [Staging].[ODS_T_GT_ProductUnitConversionFactorsHistory]
GO

CREATE SYNONYM [Staging].[ODS_T_GT_ProductUnitConversionFactorsHistory] FOR [$(ODSDatabaseName)].[CoreDataModel].[T_GT_ProductUnitConversionFactorsHistory]
GO