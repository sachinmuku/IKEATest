IF(NOT EXISTS(SELECT * FROM [sys].[synonyms] SSY INNER JOIN [sys].[schemas] SS ON SS.[schema_id] = SSY.[schema_id] WHERE SSY.[name] = N'ODS_T_CustomResourceStateReclassificationHistory' AND SS.[name] = N'Custom'))
BEGIN
	
	DECLARE @EnvironmentName NVARCHAR(512) = [dbo].[F_GetSystemName]()
	DECLARE @CreateStatement NVARCHAR(MAX) = N'CREATE SYNONYM [Custom].[ODS_T_CustomResourceStateReclassificationHistory] FOR [cm' + @EnvironmentName + N'ODSLink].[' + @EnvironmentName + N'ODS].[UserDataModel].[T_CustomResourceStateReclassificationHistory]'
	EXEC sp_executesql @CreateStatement
END
GO