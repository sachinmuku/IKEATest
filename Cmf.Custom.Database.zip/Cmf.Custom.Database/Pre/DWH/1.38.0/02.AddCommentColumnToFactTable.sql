IF COL_LENGTH('Custom.FactProductSetupTime', 'Comments') IS NULL
BEGIN
    
    ALTER TABLE [Custom].[FactProductSetupTime]
    ADD [Comments] NVARCHAR(MAX)

END;