/******************************
** Name: UserDataModel.P_GetProductOutputStatus
** Description: Procedure to get the products status quantities and losses
** Author: Paulo Soares
** Date: 17-Mar-2021
**************************

** Version History

** Version Date Author Description 
** --------------------------------------------------------------------------------------------------------------------------------------------- 
** Sprint 5 17/Mar/2021 Paulo S. Get the products status quantities and losses
*/
CREATE OR ALTER PROCEDURE [UserDataModel].[P_GetProductOutputStatus]
   @FacilityKey NVARCHAR(MAX) = NULL,
   @AreaKey NVARCHAR(MAX) = NULL,
   @ResourceKey NVARCHAR(MAX)= NULL,
   @ShiftKey NVARCHAR(MAX)= NULL,
   @ProductName NVARCHAR(MAX)= NULL,
   @ProductionOrder NVARCHAR(MAX)= NULL,
   @ReasonKey NVARCHAR(MAX)= NULL,
   @UnitName NVARCHAR(MAX) = NULL,
   @CalendarYear INT = NULL,
   @MonthNumberOfYear INT = NULL,
   @WeekNumberOfYear INT = NULL,
   @DayNumberOfMonth INT = NULL
AS
BEGIN
--DECLARE @FacilityKey NVARCHAR(MAX) = NULL,
--        @AreaKey NVARCHAR(MAX) = NULL, --'7,8', --7
--        @ResourceKey NVARCHAR(MAX) =NULL,-- '143,115,165',--143
--        @ShiftKey NVARCHAR(MAX) = NULL,
--        @ProductName NVARCHAR(MAX) = NULL,--'10,24,28', --7
--        @ProductionOrder NVARCHAR(MAX) = NULL,
--        @ReasonKey NVARCHAR(MAX) = NULL,
--        @UnitName NVARCHAR(MAX) = 'pcs',
--        @CalendarYear INT = 2021,
--        @MonthNumberOfYear INT = NULL,
--        @WeekNumberOfYear INT = NULL,
--        @DayNumberOfMonth INT = NULL

 DECLARE @Delimiter NVARCHAR(1) = ','
 IF ISNUll(@CalendarYear,0) = 0 SET @CalendarYear = YEAR(GETDATE())
 IF @MonthNumberOfYear = 0 SET @MonthNumberOfYear = NULL
 IF @WeekNumberOfYear = 0 SET @WeekNumberOfYear = NULL
 IF @DayNumberOfMonth = 0 SET @DayNumberOfMonth = NULL

 /* Create temporary tables */
 -- Temporary table -> Resource
 IF(OBJECT_ID('tempdb..#Resource') IS NOT NULL) DROP TABLE #Resource;
 CREATE TABLE #Resource
  (
   ResourceKey BIGINT
  );

 IF(@ResourceKey IS NOT NULL)
 BEGIN
  INSERT INTO #Resource
  SELECT Item FROM [Datasets].[fnSplit](@ResourceKey, @Delimiter);
 END

 -- Temporary table -> Facility
 IF(OBJECT_ID('tempdb..#Facility') IS NOT NULL) DROP TABLE #Facility;
 CREATE TABLE #Facility
  (
   FacilityKey BIGINT
  );
 IF(@FacilityKey IS NOT NULL)
 BEGIN
  INSERT INTO #Facility 
  SELECT item FROM [Datasets].[fnSplit](@Facilitykey, @Delimiter);
 END

 -- Temporary table -> Area
 IF(OBJECT_ID('tempdb..#Area') IS NOT NULL) DROP TABLE #Area;
 CREATE TABLE #Area
  (
   AreaKey BIGINT
  );

 IF(@AreaKey IS NOT NULL)
 BEGIN
  INSERT INTO #Area 
  SELECT item FROM [Datasets].[fnSplit](@AreaKey, @Delimiter);
 END

 -- Temporary table -> ShiftDefinitionShift
 IF(OBJECT_ID('tempdb..#ShiftDefinitionShift') IS NOT NULL) DROP TABLE #ShiftDefinitionShift;
 CREATE TABLE #ShiftDefinitionShift
  (
   ShiftKey NVARCHAR(MAX)
  );

 IF(@ShiftKey IS NOT NULL)
 BEGIN
  INSERT INTO #ShiftDefinitionShift 
  SELECT item FROM [Datasets].[fnSplit](@ShiftKey, @Delimiter);
 END

 -- Temporary table -> Reason
 IF(OBJECT_ID('tempdb..#Reason') IS NOT NULL) DROP TABLE #Reason;
 CREATE TABLE #Reason
  (
   ReasonKey NVARCHAR(MAX)
  );

 IF(@ReasonKey IS NOT NULL)
 BEGIN
  INSERT INTO #Reason 
  SELECT item FROM [Datasets].[fnSplit](@ReasonKey, @Delimiter);
 END

 -- Temporary table -> ProcessedMaterials
 IF(OBJECT_ID('tempdb..#ProcessedMaterials') IS NOT NULL) DROP TABLE #ProcessedMaterials;
 CREATE TABLE #ProcessedMaterials
  (
   MaterialKey BIGINT
   ,MaterialType NVARCHAR(512)
   ,ProcessedQty DECIMAL (15, 8)
   ,Units NVARCHAR(512)
   ,ProductKey BIGINT
   ,ProductName NVARCHAR(512)
   ,ConversionFactor DECIMAL (15, 8)
   ,ConvertedUnit NVARCHAR(512)
   ,ConvertedProcessedQty AS ProcessedQty*ISNULL(ConversionFactor,1)
  )
 CREATE CLUSTERED INDEX IDX_ProcMatKey ON #ProcessedMaterials (MaterialKey);

 -- Temporary table -> MaterialTypes
 IF(OBJECT_ID('tempdb..#MaterialTypes') IS NOT NULL) DROP TABLE #MaterialTypes;
 CREATE TABLE #MaterialTypes
  (
   [Type]   NVARCHAR(MAX)
   ,MTORDER INT
  );
 BEGIN
  INSERT INTO #MaterialTypes ([Type],MTOrder)
    SELECT [Type],
           CASE WHEN Type='Good' 
                    THEN 1 
                 ELSE 2 
           END            MTOrder 
      FROM Staging.ODS_T_Material
     WHERE [Type] IN('Good','DirectRepair','Repair','Outsorted','Rework','Scrap','ProcessLoss')
    GROUP BY [Type];
  END
   -- Temporary table -> Losses
  IF(OBJECT_ID('tempdb..#Losses') IS NOT NULL)
   DROP TABLE #Losses;
   CREATE TABLE #Losses
    (
     ProductKey  BIGINT,
     LossQuantity DECIMAL (15, 8),
     LossReason   NVARCHAR(512)
    )
  CREATE CLUSTERED INDEX IDX_LossMatKey ON #Losses (ProductKey);
  /* Get processed quantities */
  
  ;WITH BASE_DATA AS
   (SELECT MV.MaterialKey
           ,DM.Type As MaterialType
           ,PrimaryQuantity ProcessedQty
           ,DU.UnitName UnitName
           ,MV.ProductKey
           ,DP.ProductName
      FROM FactMaterial MV
      JOIN DimMaterial DM ON MV.MaterialKey = DM.MaterialKey
      JOIN DimOperation DO ON MV.OperationKey= DO.OperationKey
      JOIN DimUnit DU ON MV.PrimaryUnitKey = DU.UnitKey
      JOIN DimProduct DP ON MV.Productkey = DP.Productkey
      JOIN DimDate DD ON MV.DateKey = DD.DateKey
      JOIN DimArea DA ON MV.AreaKey = DA.AreaKey 
      WHERE DM.Form ='Pallet'
        AND DO.OperationName ='TrackOut'
        AND (@ResourceKey IS NULL OR EXISTS (SELECT ResourceKey FROM #Resource T WHERE MV.ResourceKey = T.ResourceKey))
        AND (@FacilityKey IS NULL OR EXISTS (SELECT FacilityKey FROM #Facility T WHERE DA.FacilityKey = T.FacilityKey))
        AND (@AreaKey IS NULL OR EXISTS (SELECT AreaKey FROM #Area T WHERE MV.AreaKey = T.AreaKey))
        AND (@ShiftKey IS NULL OR EXISTS (SELECT ShiftKey FROM #ShiftDefinitionShift T WHERE MV.ShiftKey = T.ShiftKey))
        AND DD.CalendarYear = @CalendarYear
        AND (@MonthNumberOfYear IS NULL OR DD.MonthNumberOfYear = @MonthNumberOfYear)
        AND (@WeekNumberOfYear IS NULL OR DD.WeekNumberOfYear = @WeekNumberOfYear)
        AND (@DayNumberOfMonth IS NULL OR DD.DayNumberOfMonth = @DayNumberOfMonth)
        AND (@ProductionOrder IS NULL OR DM.MaterialName LIKE '%'+@ProductionOrder+'%')
        AND (@ProductName IS NULL OR DP.ProductName LIKE '%'+@ProductName+'%')
   )
  
  /* Load temp table with processed quantities */
  INSERT INTO #ProcessedMaterials 
      (MaterialKey, MaterialType,ProductKey,ProductName,ProcessedQty,Units,ConvertedUnit,ConversionFactor)  
        SELECT BD.MaterialKey
               ,BD.MaterialType
               ,BD.ProductKey
               ,DP.ProductName
               ,BD.ProcessedQty
               ,ISNULL(FromUnit,BD.UnitName)
               ,ToUnit
               ,ConversionFactor
          FROM BASE_DATA BD
          JOIN DimProduct           DP ON BD.ProductKey = DP.ProductKey
          LEFT JOIN Staging.ODS_T_GT_ProductUnitConversionFactorsHistory PCF ON DP.ProductName= PCF.ProductName
         WHERE (@UnitName IS NULL OR PCF.ToUnit = @UnitName OR BD.UnitName = @UnitName); 
  
  /* Load loss values and reasons om the losses temp table*/
  INSERT INTO #Losses 
  (ProductKey,LossReason,LossQuantity)
          SELECT PM.ProductKey
                 ,DR.ReasonName           LossReason
                 ,SUM(MQ.PrimaryQuantity) LossQuantity        
            FROM FactMaterialQuality MQ
            JOIN #ProcessedMaterials PM ON MQ.MaterialKey = PM.MaterialKey
             AND PM.MaterialType ='ProcessLoss' 
            JOIN DimMaterial DM ON MQ.MaterialKey = DM.MaterialKey
            JOIN DimReason DR ON MQ.ReasonKey = DR.ReasonKey
             AND ReasonType ='Loss'
            JOIN DimDate DD ON MQ.DateKey = DD.DateKey 
           WHERE DD.CalendarYear = @CalendarYear
             AND (@MonthNumberOfYear IS NULL OR DD.MonthNumberOfYear = @MonthNumberOfYear)
             AND (@WeekNumberOfYear IS NULL OR DD.WeekNumberOfYear = @WeekNumberOfYear)
             AND (@DayNumberOfMonth IS NULL OR DD.DayNumberOfMonth = @DayNumberOfMonth)
             AND (@ReasonKey IS NULL OR EXISTS (SELECT ReasonKey FROM #Reason T WHERE MQ.ReasonKey = T.ReasonKey))
          GROUP BY PM.ProductKey,
                   DR.ReasonName;
 END
 BEGIN
  /*Summarizing the processed quantities */
  ;WITH ProcessedMaterials_Sumarized AS
  (SELECT ProductKey
          ,ProductName
          ,MaterialType
          ,Units
          ,ConvertedUnit
          ,ConversionFactor
          ,SUM(ProcessedQty)                    ProcessedQty
          ,SUM(ISNULL(ConvertedProcessedQty,0)) ConvertedProcessedQty
     FROM #ProcessedMaterials
   GROUP BY ProductKey
           ,ProductName
           ,MaterialType
           ,Units
           ,ConvertedUnit
           ,ConversionFactor
  )
  
  SELECT ProductName
        ,MT.[Type]
        ,Units
        ,ConvertedUnit
        ,ConversionFactor
        ,LS.LossReason
        ,ProcessedQty
        ,ConvertedProcessedQty
        ,LossQuantity 
   FROM #MaterialTypes MT
   LEFT JOIN ProcessedMaterials_Sumarized PM ON MT.[Type]=PM.MaterialType
   LEFT JOIN #Losses                      LS ON LS.ProductKey = PM.ProductKey
                                            AND PM.MaterialType ='ProcessLoss'
  ORDER BY MTOrder
  OPTION(RECOMPILE); 

END