﻿IF NOT EXISTS (
		SELECT NAME
		FROM sys.indexes
		WHERE NAME = 'PK_T_CommandQueue'
		AND object_id = OBJECT_ID('[Control].[T_CommandQueue]') )
BEGIN

	declare @CommandQueue_PK NVARCHAR(MAX) = 
	'
	CREATE UNIQUE CLUSTERED INDEX [PK_T_CommandQueue]
		ON [Control].[T_CommandQueue] ([CommandId])			
	 ';

	 EXECUTE sp_executesql @CommandQueue_PK;

END;
GO
