﻿
alter view Staging.V_ResourceHistoryFull
--WITH ENCRYPTION
as
select RH.[ServiceHistoryId]
		  ,RH.[OperationHistorySeq]
		  ,[ResourceId]
		  ,[DatabaseOperation]
		  ,[AreaId]
		  ,[AutomationAddress]
		  ,[AutomationMode]
		  ,0 as [CostPerHour]
		  ,0 as [CostPerUnit]
		  ,[CurrentBOMAssemblyType]
		  ,[CurrentBOMVersionId]
		  ,[CurrentRecipeVersionId]
		  ,[DataGroupId]
		  ,[DataGroupName]
		  ,[Description]
		  ,[DispatchableDate]
		  ,[DisplayOrder]
		  ,[DisplayPath]
		  ,[DocumentationURL]
		  ,0 as [FixedCost]
		  ,[HoldCount]
		  ,[Image]
		  ,[IsAutoGeneratePositionEnabled]
		  ,[IsDispatchable]
		  ,[IsDownloadRecipeCapable]
		  ,[IsJobManagementCapable]
		  ,[IsNotifyRecipeSelectionChangeCapable]
		  ,[IsProductMixAllowed]
		  ,[IsRecipeManagementEnabled]
		  ,[IsSubMaterialTrackingEnabled]
		  ,[IsTemplate]
		  ,[IsUploadRecipeCapable]
		  ,[LastRecipeVersionId]
		  ,[LoadPortType]
		  ,[MainStateModelId]
		  ,[MainStateModelStateId]
		  ,[MainStateModelStateReason]
		  ,[MaterialsInProcessCount]
		  ,[MaterialsInQueueCount]
		  ,[MaterialsProcessedCount]
		  ,[MaxConcurrentMaterialsInProcess]
		  ,[Model]
		  ,[ModifiedBy]
		  ,[ModifiedOn]
		  ,[Name]
		  ,[PositionContainerType]
		  ,[PositionUnitType]
		  ,[Priority]
		  ,[ProcessingDate]
		  ,[ProcessingType]
		  ,[ResourceType]
		  ,[RestrictedToMaterialForm]
		  ,[RunningMode]
		  ,[SelectedRecipeId]
		  ,[SelectedRecipeSource]
		  ,[SelectedRecipeTimeStamp]
		  ,[SelectedResourceRecipe]
		  ,[SerialNumber]
		  ,[SortRuleSetId]
		  ,[SystemState]
		  ,[TotalPositions]
		  ,[Type]
		  ,[UniversalState]
		  ,[UsedPositions]
		  ,[Vendor]
		  ,[Version]
		  ,[OldServiceHistoryId]
		  ,[OldOperationHistorySeq]
		  ,[ServiceId]
		  ,[ServiceStartTime]
		  ,[ServiceEndTime]
		  ,[CreatedBy]
		  ,[Notes]
		  ,[ServiceName]
		  ,[SubOperationSequence]
		  ,[EntityId]
		  ,[OperationId]
		  ,[OperationStartTime]
		  ,[EntityTypeId]
		  ,[OperationName]
		  ,[OperationEndTime]
		  ,[EntityTypeName]
		  ,RSMLUT.[Basic]
		  ,RSMLUT.[SEMI-E10]
		  from [Staging].[ODS_T_ResourceHistory] RH
		inner hash join [Staging].[ODS_T_ServiceHistory] SH on SH.ServiceHistoryId = RH.ServiceHistoryId
		inner hash join [Staging].[ODS_T_OperationHistory] OH on OH.ServiceHistoryId = RH.ServiceHistoryId
														and OH.OperationHistorySeq = RH.OperationHistorySeq
														--and OH.EntityId = RH.ResourceId
														--and OH.EntityTypeName = 'Resource'
		inner hash join (select StateModelId, StateModelName, StateModelStateId, StateModelStateName, [Basic], IsNull([SEMI-E10], StateModelStateName) as [SEMI-E10]
		  from 
			(select SM.StateModelId, SM.Name StateModelName, SMS.StateModelStateId, SMS.Name StateModelStateName, SMSA.Name StateModelStateAttributeName, SMSA.Value StateModelStateAttributeValue
			   from [Staging].[ODS_T_StateModel] SM
			  inner hash join [Staging].[ODS_T_StateModelState] SMS on SMS.StateModelId = SM.StateModelId 
			  inner hash join [Staging].[ODS_T_StateModelStateAttribute] SMSA on SMSA.StateModelStateId = SMS.StateModelStateId 
			  where EntityTypeId = (select EntityTypeId from [Staging].[ODS_T_EntityType] where name = 'Resource') and SM.UniversalState = 2
			) SourceTable
			 pivot
			 (
				max(StateModelStateAttributeValue) for StateModelStateAttributeName in ([Basic],[SEMI-E10])
			 ) as PivotTable) RSMLUT on RSMLUT.StateModelId = RH.[MainStateModelId] and RSMLUT.StateModelStateId = RH.[MainStateModelStateId];
GO
