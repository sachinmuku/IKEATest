﻿ALTER PROCEDURE [dbo].[P_LoadFactResourceServiceTime] ( @InfServiceHistoryId bigint = NULL, @SupServiceHistoryId bigint = NULL, @ResourceId bigint = NULL )
--WITH ENCRYPTION
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements. 
	SET XACT_ABORT ON
	SET NOCOUNT ON
	SET QUOTED_IDENTIFIER ON

	--Controls number of transactions
	DECLARE @starttrancount int

	declare @ErrorMessage nvarchar(max), 
		    @ErrorSeverity int, 
			@ErrorState int;

	DECLARE @TABLENAME nvarchar (32) = 'FactResourceServiceTime'; 

	DECLARE @PROCNAME nvarchar (64); 
	SELECT @PROCNAME = OBJECT_NAME(@@PROCID);

	DECLARE @CurrentDatetime datetime = getUTCdate();
	DECLARE @StatusMessage nvarchar(256);

	DECLARE @IsOtheFilterApplied bit;
	select @IsOtheFilterApplied = case when @ResourceId is not null then 1 else 0 end;

	DECLARE @MinServiceHistoryId bigint, @MaxServiceHistoryId bigint;

	DECLARE @HasAreaOrTerminationChanges INT;


	declare @ProcessingTimeStamp datetime = GETUTCDATE();

	DECLARE @DataValidation bit = 0;  -- Change to 1, for generating error due to additional validations (consumes more CPU!!!)
	
	DECLARE @DebugDMLTiming bit = 1;  -- Change to 1, for acquiring Routine steps timing
	DECLARE @DebugTimingMessage nvarchar(max);
	DECLARE @DebugStep int;
	DECLARE @DebugStartDate datetime, @DebugEndDate datetime;

	--If running this in CMF, then further validate results
	if @DataValidation = 0
		select @DataValidation = [Constants].[F_IsCMFHeadquarters]()
	--

	IF OBJECT_ID('tempdb..#OperationNames') IS NOT NULL
		DROP TABLE #OperationNames
		
	CREATE TABLE #OperationNames
	(
		OperationName nvarchar(256),
		unique clustered (OperationName) 
	);

	insert into #OperationNames
	select distinct operationName from DimOperation where entityName = 'Resource' and operationName <> 'SetOrUnsetResourcesDispatchable';	

	DECLARE @DefaultTimeZone TINYINT = [DateTimeUtil].[F_GetServerTimeZoneId](null);

	BEGIN TRY
		SELECT @starttrancount = @@TRANCOUNT

		IF @starttrancount = 0
			BEGIN TRANSACTION
	
		exec Control.P_StartExecution @PROCNAME, @MinServiceHistoryIdCalculated = @MinServiceHistoryId OUTPUT, @MaxServiceHistoryIdCalculated = @MaxServiceHistoryId OUTPUT, 
									  @InferiorServiceHistoryId = @InfServiceHistoryId, @SuperiorServiceHistoryId = @SupServiceHistoryId, @OtherFilters = @IsOtheFilterApplied;

		

if @DebugDMLTiming = 1
BEGIN
	set @DebugStartDate = GETUTCDATE();
	set @DebugEndDate = null;
	set @DebugStep = 0;
	set @DebugTimingMessage = null;
END

	declare @resourcekey bigint;
	select @resourcekey = resourcekey from DimResource where resourceid = @ResourceId; 

	DECLARE @MinServDateTime datetime, @MaxServDateTime datetime;

	select @MinServDateTime = MinServDateTime, @MaxServDateTime = MaxServDateTime
	from [dbo].[F_GetMinAndMaxServiceTime](@MinServiceHistoryId, @MaxServiceHistoryId);

	declare @MinServiceDateKey int, @MaxServiceDateKey int, @MinServiceDateKeyPruning int;
	set @MinServiceDateKey = dbo.F_GetDateKeyFromDateTime(@MinServDateTime);
	set @MaxServiceDateKey = dbo.F_GetDateKeyFromDateTime(@MaxServDateTime);
	-- 2 months of pruning, if DWH was stopped for 2 months then something really bad happened
	set @MinServiceDateKeyPruning = dbo.F_GetDateKeyFromDateTime(@MinServDateTime-60);

	if (@MinServiceDateKey < @MinServiceDateKeyPruning) set @MinServiceDateKeyPruning = @MinServiceDateKey;

	DECLARE @UndefinedTeamKey BIGINT,	@UndefinedShiftKey BIGINT;
	select @UndefinedTeamKey = TeamKey from DimTeam where TeamId = [Constants].[F_GetUndefinedKey]();
	select @UndefinedShiftKey = ShiftKey from DimShift where ShiftDefinitionId = [Constants].[F_GetUndefinedKey]();

	DECLARE @MinServDateKeyPruning int, @MaxServDateKeyPruning int, @OrigMinServDateKeyPruning int, @OrigMaxServDateKeyPruning int;
	select @MinServDateKeyPruning = [dbo].[F_GetDateKeyFromDateTime](@MinServDateTime-1), @MaxServDateKeyPruning = [dbo].[F_GetDateKeyFromDateTime](@MaxServDateTime + 1);
	select @OrigMinServDateKeyPruning = @MinServDateKeyPruning, @OrigMaxServDateKeyPruning = @MaxServDateKeyPruning;

	
	declare @MaxServiceHistoryIdInTable bigint, @UTCOperationEndTimeInTable datetime;
	select @MaxServiceHistoryIdInTable = MAX(ServiceHistoryId), @UTCOperationEndTimeInTable = MAX(UTCOperationEndTime) 
	  from FactResourceServiceTime
	where DateKey >= @MinServiceDateKeyPruning
	and ResourceKey = isnull(@resourcekey,ResourceKey);

	-- if no rows returned then repeat query without partitioning filter pruning
	IF(@@ROWCOUNT = 0)
	BEGIN
		select @MaxServiceHistoryIdInTable = MAX(ServiceHistoryId), @UTCOperationEndTimeInTable = MAX(UTCOperationEndTime) 
		  from FactResourceServiceTime
		where ResourceKey = isnull(@resourcekey,ResourceKey);
	END;

	-- When manually reprocessing data.
	if @MaxServiceHistoryIdInTable >= @MinServiceHistoryId  or @UTCOperationEndTimeInTable >= @MinServDateTime
    BEGIN

		set @StatusMessage = @PROCNAME + ': Deletion and Update are required. Rows found: Max(ServiceHistoryID)='+CAST(@MaxServiceHistoryIdInTable as nvarchar)+' and Max(UTCOperationEndTime)='+CAST(@UTCOperationEndTimeInTable as nvarchar)+' on ' + @TABLENAME
		RAISERROR (@StatusMessage, 0, 1) WITH NOWAIT

		delete from factResourceServiceTime WITH(TABLOCK)
		 where resourcekey = isnull(@resourcekey,resourcekey) 
		   and Datekey >= @MinServiceDateKey  --Partitioning filter... 
		   and ServiceHistoryId >= @MinServiceHistoryId ;

		set @StatusMessage = @PROCNAME + ': ' + cast(@@ROWCOUNT as nvarchar) + ' row(s) deleted by ServiceHistoryId from ' + @TABLENAME
		RAISERROR (@StatusMessage, 0, 1) WITH NOWAIT


		/*Begin/end Day/shift manual Marks are being created using the ServiceHistoryID from previous real fact events. So, although ServiceHistoryId is from an old range, 
		  UTCOperationEndTime can be from the range we want to delete. Because of this, we must delete by UTCOPerationEndTime also.
	  
		  NOTE that ServiceHistoryIds can be overlapped in time due to paralelism on Online, and because of that, 
		  deleting by UTCOPerationEndTime based on ServiceHistoryId dates can only be done for Manual Operation Keys.
		*/
		delete from factResourceServiceTime  WITH(TABLOCK)
		 where resourcekey = isnull(@resourcekey,resourcekey) 
		   and Datekey >= @MinServiceDateKey  --Partitioning filter... 
		   and UTCOPerationEndTime >= @MinServDateTime
		   and OperationKey in (select operationKey from DimOperation where EntityName = 'Resource' and OperationId = Constants.F_GetUndefinedKey())
  
	
		set @StatusMessage = @PROCNAME + ': ' + cast(@@ROWCOUNT as nvarchar) + ' row(s) deleted by UTCOPerationEndTime from ' + @TABLENAME
		RAISERROR (@StatusMessage, 0, 1) WITH NOWAIT
	
		
		--Garantees that, after the deletion, we get the last row for each resourceKey open, unless it's terminated.
		;WITH lastR as
		(
			select *
			from (
				select ResourceKey, 
					DateKey,
					TimeKey,
					OperationKey,
					UTCoperationendtime,
					UTCNextOperationEndTime,
					ServiceHistoryId,
					OperationHistorySeq,
					SubOperationSequence,
					ROW_NUMBER() over (partition by resourcekey order by Datekey desc, TimeKey desc, UTCOperationEndTime desc, ServiceHistoryId desc, OperationHistorySeq desc, SubOperationSequence desc) as rnum			
				from FactResourceServiceTime fr
				Where fr.ResourceKey = isnull(@resourcekey,fr.ResourceKey)
				and fr.Datekey >= @MinServiceDateKeyPruning  --Partitioning filter...
			) dat
			where dat.rnum = 1 and dat.UTCNextOperationEndTime is not null
		),
		stg as
		(
			select dr.ResourceKey
			  from lastR
			  inner join DimResource dr on (dr.ResourceKey = lastR.ResourceKey)
			  where Isnull(dr.IsTerminated, 0) = 0
		)
		update tgt 
			set UTCNextOperationEndTime = NULL
				,UpdateServiceHistoryId = NULL
				,UpdateTimestamp = NULL
		from lastR
		inner join stg on stg.ResourceKey = lastR.ResourceKey
		inner join FactResourceServiceTime tgt WITH(TABLOCK) on (	tgt.ResourceKey = lastR.ResourceKey 
														and tgt.DateKey = lastR.DateKey 
														and tgt.TimeKey = lastR.TimeKey 
														and tgt.ServiceHistoryId = lastR.ServiceHistoryId
														and tgt.OperationHistorySeq = lastR.OperationHistorySeq
														and tgt.SubOperationSequence = lastR.SubOperationSequence
														and tgt.OperationKey = lastR.OperationKey
														and tgt.UTCOperationEndTime = lastR.UTCOperationEndTime
														);

		set @StatusMessage = @PROCNAME + ': ' + cast(@@ROWCOUNT as nvarchar) + ' row(s) updated on ' + @TABLENAME
		RAISERROR (@StatusMessage, 0, 1) WITH NOWAIT
	END

	if @DebugDMLTiming = 1
	BEGIN
		set @DebugEndDate = GETUTCDATE();
		set @DebugTimingMessage = 'Step ' + cast(@DebugStep as nvarchar) +' took ' + cast(datediff(ss,@DebugStartDate,@DebugEndDate) as nvarchar) + ' Seconds to execute.'
		RAISERROR ( @DebugTimingMessage, 0, 1) WITH NOWAIT

		set @DebugStartDate = GETUTCDATE();
		set @DebugEndDate = null;
		set @DebugStep =  1;
		set @DebugTimingMessage = null;
	END

	/* Following sets the @MinServTimeLastExecution to cope with IDLE resources, uses the last aggregation end time as baseline to find shift changes since then */            
    DECLARE @MinServTimeLastExecution DATETIME;
    SELECT @MinServTimeLastExecution = s.ServiceStartTime
    FROM (
        SELECT max(a.MaxServiceHistoryId) AS ServiceHistoryId
        FROM CONTROL.T_ExecutionLog a
        WHERE a.procedurename = @PROCNAME AND a.MaxServiceHistoryId < @MinServiceHistoryId
        ) Serv
    INNER JOIN [Staging].[ODS_T_ServiceHistory] s
        ON (s.serviceHistoryId = Serv.ServiceHistoryId);        
            
    SET @MinServTimeLastExecution = ISNULL(@MinServTimeLastExecution, @MinServDateTime);   

	-- Due to performance, perform below aggregation in chunks
	DECLARE @NumberOfInstancesInChunk	INT = 5000;
	DECLARE @RankID INT,
			@MaxRankID INT,
			@SqlRowCnt INT,
			@startDateLoop datetime,
			@endDateLoop datetime;

	CREATE TABLE #dResources(			
		[ResourceId] [bigint] NOT NULL,
		[ResourceKey] [bigint] NOT NULL,
		[MinServiceHistoryId] [bigint] NOT NULL,
		[MaxOperationHistorySeq] [bigint] NOT NULL,
		[RankId] [int] NOT NULL,
		unique clustered ([ResourceId], [ResourceKey], [MinServiceHistoryId],[MaxOperationHistorySeq])
	);

	create nonclustered index tmp_ResourceKey on #dResources([ResourceKey]);
	create nonclustered index tmp_RankId on #dResources([RankId]);

	insert into #dResources
	select dr.ResourceId, dr.ResourceKey, resources.MinServiceHistoryId, resources.MaxServiceHistoryId, CAST(DENSE_RANK() OVER (ORDER BY resources.ResourceId) / @NumberOfInstancesInChunk AS INT) as RankID
	from (
		select tr.ResourceId, min(ServiceHistoryId) as MinServiceHistoryId, max(ServiceHistoryId) as MaxServiceHistoryId
		from Staging.T_ResourceHistory tr
		where tr.ServiceHistoryId between @MinServiceHistoryId and @MaxServiceHistoryId		
		and tr.ResourceId = ISNULL(@resourceId, tr.ResourceId)	   					
		and tr.[Basic] is not null -- includes only statemodels which have a correspondence with the basic state model
		group by ResourceId
	) resources
	inner join DimResource dr on (dr.ResourceId = resources.ResourceId);
	
	set @StatusMessage = @PROCNAME + ': ' + cast(@@ROWCOUNT as varchar) + ' row(s) inserted into temporary #dResources'
	RAISERROR (@StatusMessage, 0, 1) WITH NOWAIT

	SELECT @MaxRankID = max(RankID) FROM #dResources;
	set @DebugTimingMessage = 'Execution will be processed in ' + convert(nvarchar(20), @MaxRankID + 1) + ' iterations ';
	RAISERROR ( @DebugTimingMessage, 0, 1) WITH NOWAIT

	--goes through RankIds starting at 0
	SET @RankID = 0;
	
WHILE @RankID <= @MaxRankID
BEGIN

	set @startDateLoop = GETUTCDATE();
	set @DebugTimingMessage = 'Starting iteration ' + convert(nvarchar(20), @RankID + 1) + '/' + convert(nvarchar(20), @MaxRankID + 1) + ' on ' + CONVERT(nvarchar(50), @startDateLoop,121);
	RAISERROR ( @DebugTimingMessage, 0, 1) WITH NOWAIT

	if @DebugDMLTiming = 1
	BEGIN
	
		set @DebugStartDate = GETUTCDATE();
		set @DebugEndDate = null;
		set @DebugStep =  1;
		set @DebugTimingMessage = null;
	END
 		
		IF OBJECT_ID('tempdb..#resources') IS NOT NULL
			DROP TABLE #resources
		
		CREATE TABLE #resources
		(
			AreaKey bigint,
			AreaId bigint,
			ResourceKey bigint, 
			ResourceName nvarchar(256),
			ResourceId bigint,
			FromModifiedOn datetime,
			ToModifiedOn datetime,
			FromServiceHistoryId bigint,
			ToServiceHistoryId bigint,
			ServiceStartTime datetime,
			ServiceEndTime datetime,
			HasAreaChanges bit DEFAULT 0,
			HasTermination bit DEFAULT 0,
			CanProcessInNonWorkingTime bit default 0,
			HasHistoryInServiceHistoryRange bit default 0,
			[TimeZoneKey] TINYINT
			unique clustered (ResourceKey) 
		);		
 		
		
		-- We require to generate manual marks inside a dynamic range (the maximum one is from @MinServiceHistoryId to @MaxServiceHistoryId), even if there are no events on the range
		-- for a non terminated resource (manual marks can be BeginOfShift, BeginOfDay, EndOfShiftmark and EndOfDayMark):
		-- This section defines the AreaId to be used first, for each resource (see the next update statement for explanation).
		-- This section defines the ServiceHistoryID range for each Resource:

		--1) FromServiceHistoryId:
		--1a) If maximum ServiceHistoryId from History that is less than @MinServiceHistoryID corresponds to a non terminated resource, that uses @MinServiceHistoryID
		--1b) If maximum ServiceHistoryId from History that is less than @MinServiceHistoryID corresponds to a terminated resource, or there's no record on at all, then use the Minimum 
		--    ServiceHistoryId inside the processing range that is not terminated (in case there isn't, do not process this resource).
		
		--2) ToServiceHistoryId:
		--2a) If the maximum ServiceHistoryID in range corresponds to a terminated resource, than process untill this ServiceHistoryId, otherwise use the @MaxServiceHistoryID.

		--NOTE that multiple Terminated/unterminate can occur during processing range for the same resource. This will be split into several rows in the next statement.

		;WITH LastFromRange --Last ServiceHistoryId from Range...may be terminated or not
		as
		(
			select t.ResourceKey, t.ResourceId, t.ServiceHistoryId, 
			       t.ModifiedOn, t.UniversalState, t.AreaId, t.[ServiceStartTime], t.[ServiceEndTime]
			  from (select dr.ResourceKey, tr.ResourceId, tr.ServiceHistoryId, tr.ModifiedOn, tr.[ServiceStartTime], tr.[ServiceEndTime], tr.universalState, tr.AreaId, row_number() over (partition by tr.ResourceId order by tr.ServiceHistoryId desc, tr.OperationHistorySeq desc) rnum
					  from Staging.T_ResourceHistory tr
					  inner join #dResources dr on (dr.ResourceId = tr.ResourceId)
					  where dr.[RankId] = @RankID 					
				   ) t
			 where t.rnum=1
		)
		,LastFromHst --Last ServiceHistoryId from History...may be terminated or not
		as
		(
			select a.ResourceKey, a.ResourceId, a.ServiceHIstoryId, a.UTCOperationEndTime as ModifiedOn, hst.UniversalState, da.AreaId
			  from (select rst.ResourceKey, 
						   rst.ResourceId,
						   rst.ServiceHistoryId,
						   rst.UTCOperationEndTime,
						   rst.AreaKey
					  from (
							select tr.ResourceKey, r.ResourceId, tr.ServiceHistoryId, tr.UTCOperationEndTime, tr.AreaKey,
							row_number() over(partition by tr.resourcekey order by tr.DateKey desc, tr.TimeKey desc, tr.UTCOperationEndTime DESC, tr.ServiceHistoryId DESC, tr.OperationHistorySeq DESC, tr.SubOperationSequence DESC ) rnum
							from FactResourceServiceTime tr
							inner join LastFromRange r on (tr.ResourceKey = r.ResourceKey)
							where tr.DateKey >= @MinServiceDateKeyPruning  --Partitioning filter...											   
						   ) rst
						WHERE RST.rnum = 1
				  ) a
			 inner join DimArea da on da.AreaKey = a.AreaKey
			 cross apply (select top 1 rh.UniversalState
			                from Staging.ODS_T_ResourceHistory rh 
						   where rh.ResourceId = a.ResourceId
						     and rh.ServiceHIstoryId = a.ServiceHIstoryId
							 order by rh.ModifiedOn DESC, rh.ServiceHistoryID DESC, rh.OperationHistorySeq DESC
					      )hst
		)
		,MinInRangeNotTerminated --Min ServiceHistoryId from range that corresponds to a not terminated resource.
		as
		(
			select t.ResourceKey, t.ResourceId, t.ServiceHistoryId, 
			       t.ModifiedOn, t.UniversalState, t.AreaId, [ServiceStartTime]
			  from (select  dr.ResourceKey, tr.ResourceId, ServiceHistoryId, tr.ModifiedOn, tr.universalState, tr.AreaId, tr.[ServiceStartTime], row_number() over (partition by tr.ResourceId order by tr.ServiceHistoryId asc, tr.OperationHistorySeq asc, tr.ModifiedOn asc) rnum
					  from Staging.T_ResourceHistory tr
					  inner join #dResources dr on (dr.ResourceId = tr.ResourceId)
					  where dr.[RankId] = @RankID 									
				   ) t
			 where t.rnum=1
		)
		,AllStart
		as
		(
			select allResourcesToProcess.ResourceKey, allResourcesToProcess.ResourceId,
			       case when LastFromHst.UniversalState IS NULL then MinInRangeNotTerminated.AreaId
						when LastFromHst.UniversalState = 4 then MinInRangeNotTerminated.AreaId 
						when LastFromHst.UniversalState <> 4 then LastFromHst.AreaID
						else NULL
					end AreaId,
				   case when LastFromHst.UniversalState IS NULL then MinInRangeNotTerminated.ModifiedOn
						when LastFromHst.UniversalState = 4 then MinInRangeNotTerminated.ModifiedOn 
						when LastFromHst.UniversalState <> 4 then LastFromHst.ModifiedOn
						else NULL
					end FromModifiedOn,
				   case when lastFromRange.UniversalState is null then NULL
					    when lastFromRange.UniversalState <> 4 then NULL
					    else lastFromRange.ModifiedOn
					end ToModifiedOn,
				   case when LastFromHst.UniversalState IS NULL then MinInRangeNotTerminated.ServiceHistoryId
						when LastFromHst.UniversalState = 4 then MinInRangeNotTerminated.ServiceHistoryId 
						when LastFromHst.UniversalState <> 4 then LastFromHst.ServiceHistoryId
						else @MinServiceHistoryId
					end FromServiceHistoryId,
				   case when LastFromHst.UniversalState IS NULL then MinInRangeNotTerminated.ServiceStartTime
						when LastFromHst.UniversalState = 4 then MinInRangeNotTerminated.ServiceStartTime 
						when LastFromHst.UniversalState <> 4 then LastFromHst.ModifiedOn
						else @MinServDateTime
					end ServiceStartTime,
				   case when lastFromRange.UniversalState is null then @MaxServiceHistoryId
					    when lastFromRange.UniversalState <> 4 then @MaxServiceHistoryId
					    else lastFromRange.ServiceHistoryId
					end ToServiceHistoryId,
					case when lastFromRange.UniversalState is null then @MaxServDateTime
					    when lastFromRange.UniversalState <> 4 then @MaxServDateTime
					    else lastFromRange.ServiceEndTime
					end ServiceEndTime

			  from ( select resourcekey, ResourceId from LastFromHst where UniversalState <> 4
						union 
					 select resourcekey, ResourceId from MinInRangeNotTerminated) allResourcesToProcess
			  inner join lastFromRange on lastFromRange.ResourceId = allResourcesToProcess.ResourceId
			  left join LastFromHst on LastFromHst.ResourceId = allResourcesToProcess.ResourceId
			  left join MinInRangeNotTerminated on MinInRangeNotTerminated.ResourceId = allResourcesToProcess.ResourceId			  
		)
		insert into #resources (AreaKey, AreaId, ResourceKey, ResourceName, ResourceId, FromModifiedOn, ToModifiedOn, FromServiceHistoryId, ToServiceHistoryId, ServiceStartTime, ServiceEndTime, CanProcessInNonWorkingTime, HasHistoryInServiceHistoryRange, [TimeZoneKey])
		SELECT da.AreaKey, da.AreaId, dr.ResourceKey, dr.ResourceName, evt.ResourceId, 
		       ISNULL(evt.FromModifiedOn,evt.ServiceStartTime), ISNULL(evt.ToModifiedOn,ISNULL(evt.ServiceEndTime, @MaxServDateTime)), 
		       evt.FromServiceHistoryId, evt.ToServiceHistoryId, evt.ServiceStartTime, ISNULL(evt.ServiceEndTime, @MaxServDateTime), ISNULL(dr.CanProcessInNonWorkingTime, 0), 1 AS HasHistoryInServiceHistoryRange,
			   dr.[TimeZoneKey]
		  from AllStart evt
		  inner join DimResource dr on (dr.ResourceId = evt.ResourceId)
		  inner join DimArea da on (da.AreaId = evt.AreaId);


		--Marks #resources table with information to quickly determine which resources changed areas during or between processing ranges.
		--1) One row for resource and, and the area is determined as follows:
		--1a) If maximum ServiceHistoryId from History that is less than @MinServiceHistoryID corresponds to a non terminated resource, that uses its AreaId
		--1b) If maximum ServiceHistoryId from History that is less than @MinServiceHistoryID corresponds to a terminated resource, or there's no record on at all, then use the AreaID from 
		--    the minimum ServiceHistoryId inside the processing range that is not terminated.
		
		-- If there are changes from Whatever UniversalState to 4, or vice-versa, we mark the resource for future split.
		update T
			set T.HasTermination = 1
			from #resources T
			inner join ( select distinct ResourceId
								from (select rh.ResourceId, 
											case when isnull(rh.UniversalState,0) = 4 then 1 else 0 end IsTerminated, 
											LEAD(case when isnull(rh.UniversalState,0) = 4 then 1 else 0 end) over (partition by rh.ResourceId order by rh.ModifiedOn ASC, rh.ServiceHistoryID ASC, rh.OperationHistorySeq ASC ) NextIsTerminated
										from Staging.T_ResourceHistory rh where rh.ServiceHistoryID between @MinServiceHistoryId and @MaxServiceHistoryId
									)inn
								where inn.IsTerminated <> isnull(inn.NextIsTerminated,inn.IsTerminated)
							) a on a.ResourceId = T.ResourceId;

		SET @HasAreaOrTerminationChanges = @@ROWCOUNT;

		IF (@HasAreaOrTerminationChanges = 0)
		BEGIN
			--If there are distinct areas from #resources combined with Staging, then we mark it.
			update T
				set T.HasAreaChanges = 1
				from #resources T
				inner join (  select r.ResourceKey, count(distinct RH.AreaId) countDistinct, max(case when r.AreaId != RH.AreaId then 1 else 0 end) distAreas
									from #resources r
									inner join Staging.T_ResourceHistory RH on (rh.ResourceId = r.ResourceId and rh.ServiceHistoryId between @MinServiceHistoryId and @MaxServiceHistoryId)								
									group by r.ResourceKey
									having count(distinct RH.AreaId) > 1 or max(case when r.AreaId != RH.AreaId then 1 else 0 end) > 0
							) a on a.ResourceKey = T.ResourceKey;

			SET @HasAreaOrTerminationChanges = @@ROWCOUNT;			
		END;



		if @DebugDMLTiming = 1
		BEGIN
			set @DebugEndDate = GETUTCDATE();
			set @DebugTimingMessage = 'Step ' + cast(@DebugStep as nvarchar) +' (iteration ' + convert(nvarchar(20), @RankID + 1) + '/' + convert(nvarchar(20), @MaxRankID + 1) + ' )' +' took ' + cast(datediff(ss,@DebugStartDate,@DebugEndDate) as nvarchar) + ' Seconds to execute.'
			RAISERROR ( @DebugTimingMessage, 0, 1) WITH NOWAIT

			set @DebugStartDate = GETUTCDATE();
			set @DebugEndDate = null;
			set @DebugStep = 2;
			set @DebugTimingMessage = null;
		END

		IF OBJECT_ID('tempdb..#MinMaxDateKey') IS NOT NULL
			DROP TABLE #MinMaxDateKey
		
		CREATE TABLE #MinMaxDateKey
		(
			 AreaKey bigint
			,ResourceKey bigint
			,ResourceName nvarchar(256)
			,ResourceId bigint
			,minOperationEndDateKey int
			,maxOperationEndDateKey int
			,minOperationEndDate datetime
			,maxOperationEndDate datetime
			,minLC1OperationEndDate datetime
			,maxLC1OperationEndDate datetime
			,CanProcessInNonWorkingTime bit
			,[TimeZoneKey] tinyint
			,unique clustered (AreaKey, ResourceKey, minOperationEndDate, maxOperationEndDate)
		);		

		IF (@HasAreaOrTerminationChanges > 0)
		BEGIN
		
			IF OBJECT_ID('tempdb..#tmp_Leads') IS NOT NULL
			   DROP TABLE #tmp_Leads
		
			CREATE TABLE #tmp_Leads
			(
				ResourceKey bigint,
				AreaKey bigint,
				IsTerminated bit,
				ServiceHistoryId bigint,
				ModifiedOn datetime,
				NextIsTerminated bigint,
				NextAreaKey bigint,
				NextServiceHistoryId bigint,
				NextModifiedOn datetime,
				unique clustered (ResourceKey, ModifiedOn,  ServiceHistoryId , NextServiceHistoryId, NextModifiedOn)
			);
		
			insert into #tmp_Leads WITH(TABLOCK)
				select dat.ResourceKey,
					   case when LAG(dat.AreaKey) over (partition by dat.ResourceKey order by dat.ModifiedOn) IS NULL THEN dat.origAreaKey else dat.AreaKey end AreaKey,
					   dat.IsTerminated,
					   dat.ServiceHistoryId,
					   dat.ModifiedOn,
					   ISNULL(LEAD(dat.IsTerminated) over (partition by dat.ResourceKey order by dat.ModifiedOn),dat.IsTerminated) NextIsTerminated,
					   ISNULL(LEAD(dat.AreaKey) over (partition by dat.ResourceKey order by dat.ModifiedOn), dat.AreaKey) NextAreaKey,
					   ISNULL(LEAD(dat.ServiceHistoryId) over (partition by dat.ResourceKey order by dat.ModifiedOn),dat.ToServiceHistoryId) NextServiceHistoryId,
					   ISNULL(LEAD(dat.ModifiedOn) over (partition by dat.ResourceKey order by dat.ModifiedOn),dat.ToModifiedOn) NextModifiedOn
				  from ( 
					select distinct r.ToServiceHistoryId, r.ToModifiedOn, r.AreaKey origAreaKey, da.AreaKey, dr.ResourceKey, case when isnull(UniversalState,0) = 4 then 1 else 0 end IsTerminated, rh.ServiceHistoryId as ServiceHistoryId, rh.ModifiedOn
					  from (select * from #resources where HasAreaChanges = 1 or HasTermination = 1) r
					  inner join Staging.T_ResourceHistory rh on rh.ResourceId = r.ResourceId and rh.ServiceHistoryId between r.FromServiceHistoryId and r.ToServiceHistoryId
					  inner join DimArea da on da.AreaId = rh.AreaId
					  inner join DimResource dr on dr.ResourceId = rh.ResourceId						  			  
				  )dat;

			--Here we split records which changes area during the processing range and between processing ranges. FromServiceHistoryIds and ToServiceHistoryIds are adjusted accordingly.
			--Also, OperationEndDates are here determined based on ServiceHistory table. These are the dates that will be used for generating manual marks (manual marks can be 
			-- BeginOfShift, BeginOfDay, EndOfShiftmark and EndOfDayMark).

			--Using the same logic, we split the terminated periods for each resource, and exclude them in the where clause: where split.IsTerminated = 0;
			;WITH split as
			 (
				 select chg.ResourceKey, chg.AreaKey, ISNULL(bef.ModifiedOn,r.FromModifiedOn) as ModifiedOn,
						ISNULL(bef.ServiceHistoryId,r.FromServiceHistoryId) as FromServiceHistoryId, chg.NextServiceHistoryId as ToServiceHistoryId, chg.IsTerminated
				   from (select * from #resources where HasAreaChanges = 1 or HasTermination = 1) r
				   inner join (select * from #tmp_Leads where AreaKey <> NextAreaKey or IsTerminated <> NextIsTerminated) chg on chg.ResourceKey = r.ResourceKey
				   outer apply (select MAX(L1.NextServiceHistoryId) ServiceHistoryId, MAX(L1.NextModifiedOn) ModifiedOn
								  from #tmp_Leads L1
								 where L1.ResourceKey = chg.ResourceKey
								   and L1.NextServiceHistoryID <= chg.ServiceHistoryiD
								   and L1.NextModifiedOn <= chg.ModifiedOn
								   and (L1.AreaKey <> L1.NextAreaKey or L1.IsTerminated <> L1.NextIsTerminated)
								) bef
				  where chg.IsTerminated = 0
				 UNION ALL
				 select chg.ResourceKey, chg.NextAreaKey, chg.NextModifiedOn as ModifiedOn,
						chg.NextServiceHistoryId as FromServiceHistoryId, r.ToServiceHistoryId as ToServiceHistoryId, chg.IsTerminated
				   from (select * from #resources where HasAreaChanges = 1 or HasTermination = 1) r
				   inner join (select * from #tmp_Leads where AreaKey <> NextAreaKey or IsTerminated <> NextIsTerminated) chg on chg.ResourceKey = r.ResourceKey
				   outer apply (select MAX(L1.NextServiceHistoryId) ServiceHistoryId, MAX(L1.NextModifiedOn) ModifiedOn
								  from #tmp_Leads L1
								 where L1.ResourceKey = chg.ResourceKey
								   and L1.NextServiceHistoryID >= chg.ServiceHistoryiD
								   and L1.NextModifiedOn >= chg.ModifiedOn
								   and not exists (select 1
													 from #tmp_Leads L2
													where L2.ResourceKey = L1.ResourceKey
													  and L2.ServiceHistoryId > L1.ServiceHistoryId
													  and (L2.AreaKey <> L2.NextAreaKey or L2.IsTerminated <> L2.NextIsTerminated)
												  )

								) aft
				where chg.NextIsTerminated = 0
				  and not exists (select 1
									from #tmp_Leads L3
								   where L3.ResourceKey = chg.ResourceKey
									 and L3.ServiceHistoryId > chg.ServiceHistoryId
									 and (L3.AreaKey <> L3.NextAreaKey or L3.IsTerminated <> L3.NextIsTerminated)
								 )
			)
			insert into #MinMaxDateKey
			select distinct split.AreaKey, split.ResourceKey, dr.ResourceName, dr.ResourceId,
				   dbo.F_GetDateKeyFromDateTime(isnull(split.ModifiedOn,servStart.ServiceStartTime)) as minOperationEndDateKey, 
				   dbo.F_GetDateKeyFromDateTime(isnull(servEnd.ServiceEndTime, @MaxServDateTime)) as maxOperationEndDateKey,
				   isnull(split.ModifiedOn,servStart.ServiceStartTime) as minOperationEndDate, 
				   isnull(servEnd.ServiceEndTime, @MaxServDateTime) as maxOperationEndDate,
				   null, null, ISNULL(dr.CanProcessInNonWorkingTime, 0), dr.[TimeZoneKey]
			from split
			inner join DimResource dr on dr.ResourceKey = split.ResourceKey
			OUTER APPLY  (select ServiceStartTime ,ServiceHistoryId
							from [Staging].[ODS_T_ServiceHistory] 
							where serviceHistoryId = split.FromServiceHistoryId
							) servStart
			OUTER APPLY  (select ServiceEndTime , ServiceHistoryId
							from [Staging].[ODS_T_ServiceHistory] 
							where serviceHistoryId = split.ToServiceHistoryId
							) servEnd;

		END;


		
		insert into #MinMaxDateKey
		select distinct r.AreaKey, r.ResourceKey, r.ResourceName, r.ResourceId,
			   dbo.F_GetDateKeyFromDateTime(r.ServiceStartTime) as minOperationEndDateKey, 
			   dbo.F_GetDateKeyFromDateTime(r.ServiceEndTime) as maxOperationEndDateKey,
		       isnull(r.FromModifiedOn,r.ServiceStartTime) as minOperationEndDate, 
			   r.ServiceEndTime as maxOperationEndDate,
			   null, null, r.CanProcessInNonWorkingTime, r.[TimeZoneKey]
		  from #resources r
		 where HasAreaChanges = 0 and HasTermination = 0;

		SELECT @MinServDateKeyPruning = [dbo].[F_GetDateKeyFromDateTime](ISNULL(min(a.minOperationEndDate), @MinServDateTime) - 2)
			,@MaxServDateKeyPruning = [dbo].[F_GetDateKeyFromDateTime](ISNULL(max(a.maxOperationEndDate), @MaxServDateTime) + 2)
		FROM #MinMaxDateKey a;

		if (@MinServDateKeyPruning > @MinServiceDateKeyPruning) SET @MinServDateKeyPruning = @MinServiceDateKeyPruning;
		
		BEGIN /* Grabing IDLE resources whenever there was a shift change, uses the last aggregation end time as baseline to find shift changes since then */
                 
            ;WITH ForcedResourcesInRange
            as
            (   
                    select R.ResourceName, R.ResourceKey, R.CanProcessInNonWorkingTime, A.AreaKey, R.ResourceId, @MinServiceHistoryId as ServiceHistoryId, @MaxServDateTime as ModifiedOn, 2 as UniversalState, A.AreaId
						 , @MinServDateTime AS [ServiceStartTime], @MaxServDateTime AS [ServiceEndTime], r.[TimeZoneKey]
                    from (
                        select distinct AreaKey from 
                        (
                            select AreaKey, ShiftKey, count(1) as NShifts from FactShift 
                            where datekey between @OrigMinServDateKeyPruning and @OrigMaxServDateKeyPruning
                            and (
                                StartDateTime between @MinServTimeLastExecution and @MaxServDateTime
                                or
                                EndDateTime between @MinServTimeLastExecution and @MaxServDateTime
                            )
                            group by AreaKey, ShiftKey
                        )x
                    ) dat
                    inner join DimArea A on (a.AreaKey = dat.AreaKey)
                    inner join DimResource r on (r.AreaKey = dat.AreaKey)       
                    left join #dResources rr on (rr.ResourceKey = r.ResourceKey)
                    where rr.ResourceKey is null
                     and r.ResourceId = ISNULL(@resourceId, r.ResourceId)
                     and Isnull(r.IsTerminated, 0) = 0 
					 and @RankID = 0 /* in this scenario one loop is enough */
            )
            ,LastFromHst --Last ServiceHistoryId from History...may be terminated or not
            as
            (
                select a.ResourceKey, a.ServiceHIstoryId, a.UTCOperationEndTime as ModifiedOn, a.AreaKey
                  from (select rst.ResourceKey, 
                               rst.ServiceHistoryId,
                               rst.UTCOperationEndTime,
                               rst.AreaKey
                          from (
                                select tr.ResourceKey, tr.ServiceHistoryId, tr.UTCOperationEndTime, tr.AreaKey,
                                row_number() over(partition by resourcekey order by tr.DateKey desc, tr.TimeKey desc, tr.UTCOperationEndTime DESC, tr.ServiceHistoryId DESC, tr.OperationHistorySeq DESC, tr.SubOperationSequence DESC ) rnum
                                from FactResourceServiceTime tr
                                inner hash join (select distinct dr.ResourceKey as ResourceKeyFilter from ForcedResourcesInRange dr) r on (tr.ResourceKey = r.ResourceKeyFilter)
                            where tr.DateKey >= @MinServDateKeyPruning  --Partitioning filter...    
                                and tr.UTCNextOperationEndTime is null -- only open rows are of interest                                           
                               ) rst
                            WHERE RST.rnum = 1
                      ) a
            )       
            ,AllStart
            as
            (
                select ForcedResourcesInRange.ResourceKey,
                       ForcedResourcesInRange.ResourceId,
                       ForcedResourcesInRange.ResourceName,
                       ForcedResourcesInRange.CanProcessInNonWorkingTime,
                       ForcedResourcesInRange.AreaID,
                       LastFromHst.ModifiedOn as FromModifiedOn,
                       ForcedResourcesInRange.ModifiedOn as ToModifiedOn,
                       LastFromHst.ServiceHistoryId FromServiceHistoryId,
                       LastFromHst.ModifiedOn as ServiceStartTime,
                       ForcedResourcesInRange.ServiceHistoryId as ToServiceHistoryId,
                       ForcedResourcesInRange.ServiceEndTime,
                       ForcedResourcesInRange.AreaKey,
					   ForcedResourcesInRange.[TimeZoneKey]
                  from  ForcedResourcesInRange
                  inner join LastFromHst on LastFromHst.ResourceKey = ForcedResourcesInRange.ResourceKey
            )
            insert into #resources (AreaKey, AreaId, ResourceKey, ResourceName, ResourceId, FromModifiedOn, ToModifiedOn, FromServiceHistoryId, ToServiceHistoryId, ServiceStartTime, ServiceEndTime, CanProcessInNonWorkingTime, HasHistoryInServiceHistoryRange, [TimeZoneKey])
            select evt.AreaKey, evt.AreaId, evt.ResourceKey, evt.ResourceName, evt.ResourceId, 
                   isnull(evt.FromModifiedOn,evt.ServiceStartTime), isnull(evt.ToModifiedOn,ISNULL(evt.ServiceEndTime, @MaxServDateTime)), 
                   evt.FromServiceHistoryId, evt.ToServiceHistoryId, evt.ServiceStartTime, ISNULL(evt.ServiceEndTime, @MaxServDateTime), ISNULL(evt.CanProcessInNonWorkingTime, 0), 0 AS HasHistoryInServiceHistoryRange,
				   evt.[TimeZoneKey]
              from AllStart evt;

            insert into #MinMaxDateKey
            select distinct r.AreaKey, r.ResourceKey, r.ResourceName, r.ResourceId,
                   dbo.F_GetDateKeyFromDateTime(r.ServiceStartTime) as minOperationEndDateKey, 
                   dbo.F_GetDateKeyFromDateTime(r.ServiceEndTime) as maxOperationEndDateKey,
                   isnull(r.FromModifiedOn,r.ServiceStartTime) as minOperationEndDate, 
                   r.ServiceEndTime as maxOperationEndDate,
                   null, null, r.CanProcessInNonWorkingTime,
				   r.[TimeZoneKey]
              from #resources r
              -- forced resources to create end of shifts and days marks
             where r.HasHistoryInServiceHistoryRange = 0;

        END;

		update #MinMaxDateKey
		   set minLC1OperationEndDate = [DateTimeUtil].[UDF_ConvertUtcToLocalByTimezoneId]([TimeZoneKey], minOperationEndDate)										
		      ,maxLC1OperationEndDate = [DateTimeUtil].[UDF_ConvertUtcToLocalByTimezoneId]([TimeZoneKey], maxOperationEndDate);
										

		-- updates pruning dates because events processed also include events prior to the @MinServiceHistoryId dates
		SELECT @MinServDateKeyPruning = [dbo].[F_GetDateKeyFromDateTime](min(a.minOperationEndDate) - 2)
			,@MaxServDateKeyPruning = [dbo].[F_GetDateKeyFromDateTime](max(a.maxOperationEndDate) + 2)
		FROM #MinMaxDateKey a;

	if @DebugDMLTiming = 1
	BEGIN
		set @DebugEndDate = GETUTCDATE();
		set @DebugTimingMessage = 'Step ' + cast(@DebugStep as nvarchar) +' (iteration ' + convert(nvarchar(20), @RankID + 1) + '/' + convert(nvarchar(20), @MaxRankID + 1) + ' )' +' took ' + cast(datediff(ss,@DebugStartDate,@DebugEndDate) as nvarchar) + ' Seconds to execute.'
		RAISERROR ( @DebugTimingMessage, 0, 1) WITH NOWAIT

		set @DebugStartDate = GETUTCDATE();
		set @DebugEndDate = null;
		set @DebugStep = 3;
		set @DebugTimingMessage = null;
	END		

		
		IF OBJECT_ID('tempdb..#tmp_EndMarks') IS NOT NULL
		   DROP TABLE #tmp_EndMarks
		
		CREATE TABLE #tmp_EndMarks
		(
				 [UTCServiceEndTime] datetime
				,[UTCOperationEndTime] datetime
				,[ShiftDateKey] int
				,[ShiftKey] bigint
				,ResourceId bigint
				,[ResourceKey] bigint
				,[AreaKey] bigint
				,[SEMI-E10] nvarchar(256) COLLATE DATABASE_DEFAULT
				,[OperationKey] bigint
				,[OperationName] nvarchar(256) COLLATE DATABASE_DEFAULT
				,[ServiceKey] bigint
				,[ServiceName] nvarchar(256) COLLATE DATABASE_DEFAULT
				,[DateKey] int
				,[TimeKey] int
				,[ResourceName] nvarchar(256) COLLATE DATABASE_DEFAULT
				,[ResourceType] nvarchar(512) COLLATE DATABASE_DEFAULT
				,[Model] nvarchar(512) COLLATE DATABASE_DEFAULT
				,[Basic] nvarchar(512) COLLATE DATABASE_DEFAULT
				,[ServiceHistoryId] bigint
				,[OperationHistorySeq] bigint
				,[SubOperationSequence] int
				,[OldServiceHistoryId] bigint
				,[OldOperationHistorySeq] bigint
				,[ResourceStateModelKey] bigint
				,[MainStateModelStateReason] nvarchar(512) COLLATE DATABASE_DEFAULT
				,[LC1ServiceEndTime] datetime
				,[LC1operationEndTime] datetime
				,[UpToDownTransition] bit
				,[DownToUpTransition] bit
				,[TeamKey] bigint
				,[EmployeeKey] bigint
				,[IsManualMark] bit
				,[IsTermination] bit default 0
				,CanProcessInNonWorkingTime bit default 0
				,ResourceStateModelChangeReasonKey bigint
				,[TimeZoneKey] TINYINT
			    ,[UTCToLC1OffSetMin] SMALLINT NULL
				,[InSetup] SMALLINT
				,unique clustered (ResourceKey, UTCOperationEndTime , ServiceHistoryId , OperationHistorySeq , SubOperationSequence)
		);
				
		create nonclustered index tmp_manual_endmarks on #tmp_EndMarks([IsManualMark]);


		DECLARE @NotDefinedEmployee BIGINT; DECLARE @NotDefinedService BIGINT; DECLARE @NotDefinedResourceStateModelKey BIGINT, @NotDefinedResourceStateModelChangeReasonKey bigint, @NotDefinedName NVARCHAR(512);

		select @NotDefinedService = ServiceKey from DimService where ServiceId = Constants.F_GetUndefinedKey() and ServiceContractName = 'ResourceManagement'

		select @NotDefinedEmployee = EmployeeKey from DimEmployee where UserId = Constants.F_GetUndefinedKey();

		select @NotDefinedResourceStateModelKey = ResourceStateModelKey from DimResourceStateModel where StateModelId = Constants.F_GetUndefinedKey();
		select @NotDefinedResourceStateModelChangeReasonKey = ResourceStateModelChangeReasonKey from DimResourceStateModelChangeReason where ResourceStateModelChangeReason = Constants.F_GetUndefinedKeyName();

		select @NotDefinedName = [Constants].[F_GetUndefinedKeyName]();

		--Real events
		insert into #tmp_EndMarks WITH(TABLOCK)
		SELECT	 a.[ServiceEndTime] as UTCServiceEndTime
				,a.[OperationEndTime] as UTCOperationEndTime
				,a.[ShiftDateKey]
				,a.[ShiftKey]
				,a.ResourceId
				,a.[ResourceKey]
				,a.[AreaKey]
				,a.[SEMI-E10]
				,a.[OperationKey]
				,a.[OperationName]
				,a.[ServiceKey]
				,a.[ServiceName]
				,a.[DateKey]
				,a.[TimeKey]
				,a.[ResourceName]
				,a.[ResourceType]
				,a.[Model]
				,a.[Basic]
				,a.[ServiceHistoryId]
				,a.[OperationHistorySeq]
				,a.[SubOperationSequence]
				,a.[OldServiceHistoryId]
				,a.[OldOperationHistorySeq]
				,a.ResourceStateModelKey
				,a.[MainStateModelStateReason]
				,a.[LC1ServiceEndTime]
				,a.[LC1OperationEndTime]
		        ,case when a.PrevMachineUpDownState = 'Up' and a.MachineUpDownState = 'Down' then 1 else 0 end as [UpToDownTransition]
				,case when a.PrevMachineUpDownState = 'Down' and a.MachineUpDownState = 'Up' then 1 else 0 end as [DownToUpTransition]
				,a.TeamKey
				,ISNULL(a.EmployeeKey, @NotDefinedEmployee)
				,0 as [isManualMark]
				,a.isTermination
				,ISNULL(a.CanProcessInNonWorkingTime, 0) as CanProcessInNonWorkingTime
				,a.ResourceStateModelChangeReasonKey
				,a.[TimeZoneKey]
			    ,a.[UTCToLC1OffSetMin]
				,a.[InSetup]
		  FROM (SELECT	 rh.[ServiceEndTime]
						,[fs].[datekey] as ShiftDateKey
						,ISNULL([fs].[ShiftKey],@UndefinedShiftKey) as ShiftKey
						,RH.ResourceId
						,res.[ResourceKey]
						,area.[AreaKey]
						,isnull(drsm.StateModelStateSemiE10Value,@NotDefinedName) as [SEMI-E10]--rh.[SEMI-E10]
						,rh.[OperationEndTime]
						,do.OperationKey as OperationKey
						,rh.[OperationName]
						,ISNULL(ds.[ServiceKey],@NotDefinedService) ServiceKey
						,rh.[ServiceName]
						, CAST(CONVERT(char(8),rh.[OperationEndTime],112) AS INT) as [DateKey]				
						, DATEPART(HH, rh.[OperationEndTime])*(10000)+DATEPART(MI, rh.[OperationEndTime])*(100)+DATEPART(SS, rh.[OperationEndTime]) as [TimeKey]
						,res.ResourceName
						,rh.[ResourceType]
						,rh.[Model]
						,isnull(drsm.StateModelStateBasicValue,@NotDefinedName) as [Basic]--rh.[Basic]
						,rh.[ServiceHistoryId]
						,rh.[OperationHistorySeq]
						,rh.[SubOperationSequence]
						,rh.[OldServiceHistoryId]
						,rh.[OldOperationHistorySeq] 
						,isnull(drsm.ResourceStateModelKey,@NotDefinedResourceStateModelKey) as ResourceStateModelKey
						,isnull(rh.[MainStateModelStateReason],@NotDefinedName) as [MainStateModelStateReason]
						,isnull(drsmcr.ResourceStateModelChangeReasonKey, @NotDefinedResourceStateModelChangeReasonKey) as ResourceStateModelChangeReasonKey
						,case when fs.UTCToLC1OffSetMin IS NULL
								then [DateTimeUtil].[UDF_ConvertUtcToLocalByTimezoneId](fs.TimeZoneKey, rh.ServiceEndTime)
								else dateadd(MI, fs.UTCToLC1OffSetMin, rh.ServiceEndTime)
						 end as LC1ServiceEndTime
						,case when fs.UTCToLC1OffSetMin IS NULL
								then [DateTimeUtil].[UDF_ConvertUtcToLocalByTimezoneId](fs.TimeZoneKey, rh.[OperationEndTime])
								else dateadd(MI, fs.UTCToLC1OffSetMin, rh.[OperationEndTime])
						 end as LC1OperationEndTime
						,case when RHPrev.[SEMI-E10] IS NULL then (case when RHPrev.Basic IN ('Down','Nonscheduled') then 'Down' else 'Up' end)
						      when RHPrev.[SEMI-E10] = 'Unscheduled Down' then 'Down' 
							  else 'Up'
						  end PrevMachineUpDownState
						,case when drsm.StateModelStateSemiE10Value IS NULL then (case when drsm.StateModelStateBasicValue IN ('Down','Nonscheduled') then 'Down' else 'Up' end)
						      when drsm.StateModelStateSemiE10Value = 'Unscheduled Down' then 'Down' else 'Up'
						  end MachineUpDownState
						,RHPrev.Basic as prevBasic
						,RHPrev.[SEMI-E10] as prevSemiE10
						,isnull(fs.TeamKey,@UndefinedTeamKey) as TeamKey
						,emp.EmployeeKey
						,case when rh.UniversalState = 4 then 1 else 0 end isTermination
						,res.CanProcessInNonWorkingTime
						,fs.TimeZoneKey
						,fs.UTCToLC1OffSetMin
						,case when do.OperationName = 'CompleteSetup' then 2 else rh.InSetup end InSetup
				  FROM [Staging].[T_ResourceHistory] RH
				   INNER JOIN #dResources dr on (dr.ResourceId = RH.ResourceId and dr.RankId = @RankID)
				   INNER JOIN #OperationNames OP on (OP.OperationName = RH.OperationName)
				   LEFT JOIN
						   (						   
						   select  distinct RH.Resourceid, RH.ServiceHistoryId, RH.OperationHistorySeq
							  ,RSMLUT.[Basic]
							  ,RSMLUT.[SEMI-E10]
							  from 
							  (
							  select RH.Resourceid, RH.ServiceHistoryId, RH.OperationHistorySeq, RH.[MainStateModelId], RH.[MainStateModelStateId]  
								from [Staging].[T_ResourceHistory] RH
								INNER JOIN #dResources dr on (dr.ResourceId = RH.ResourceId and dr.RankId = @RankID)		
							  union all
							  select RH.Resourceid, RH.ServiceHistoryId, RH.OperationHistorySeq, RH.[MainStateModelId], RH.[MainStateModelStateId]  
							    from [Staging].[ODS_T_ResourceHistory] RH
								INNER JOIN #dResources dr on (dr.ResourceId = RH.ResourceId and dr.RankId = @RankID)
								INNER JOIN ( 
									   select * from (
										select oldServiceHistoryId, OldOperationHistorySeq, RH.resourceid, row_number() over(partition by RH.resourceid order by RH.modifiedon) rnum 
										from [Staging].[T_ResourceHistory] RH
										INNER JOIN #dResources dr on (dr.ResourceId = RH.ResourceId and dr.RankId = @RankID)
										) dat where dat.rnum = 1 and OldServiceHistoryId is not null
									) R on (R.ResourceId = RH.resourceid and R.oldServiceHistoryId = RH.ServiceHistoryId and R.OldOperationHistorySeq = RH.OperationHistorySeq)
							  
							  ) RH
							inner join (							
								select StateModelId, StateModelName, StateModelStateId, StateModelStateName, [Basic], IsNull([SEMI-E10], StateModelStateName) as [SEMI-E10]
								  from 
									(
									 select SM.StateModelId, SM.Name StateModelName, SMS.StateModelStateId, SMS.Name StateModelStateName, SMSA.Name StateModelStateAttributeName, SMSA.Value StateModelStateAttributeValue
								   from [Staging].[ODS_T_StateModel] SM
								  inner join [Staging].[ODS_T_StateModelState] SMS on SMS.StateModelId = SM.StateModelId 
								  inner join [Staging].[ODS_T_StateModelStateAttribute] SMSA on SMSA.StateModelStateId = SMS.StateModelStateId 
								  where EntityTypeId = (select EntityTypeId from [Staging].[ODS_T_EntityType] where name = 'Resource') and SM.UniversalState = 2
								) SourceTable
								 pivot
								 (
									max(StateModelStateAttributeValue) for StateModelStateAttributeName in ([Basic],[SEMI-E10])
									 ) as PivotTable
								 ) RSMLUT on RSMLUT.StateModelId = RH.[MainStateModelId] and RSMLUT.StateModelStateId = RH.[MainStateModelStateId]
						 
						   ) RHPrev ON ( RH.ResourceId = RHPrev.ResourceId and RHPrev.ServiceHistoryId = RH.OldServiceHistoryId and RHPrev.OperationHistorySeq = RH.OldOperationHistorySeq )				
				   LEFT JOIN DimResource Res ON Res.ResourceId = RH.ResourceId
				   LEFT JOIN DimArea Area ON Area.AreaId = RH.AreaId
				   LEFT JOIN DimOperation do ON (do.OperationId = rh.OperationId)
				   LEFT JOIN DimService ds ON (ds.ServiceId = rh.ServiceId)
				   LEFT JOIN FactShift fs ON (fs.DateKey between @MinServDateKeyPruning and @MaxServDateKeyPruning and fs.AreaKey = Area.AreaKey and RH.OperationEndTime >= fs.StartDateTime and RH.OperationEndTime < fs.EndDateTime)				   
				   LEFT JOIN DimEmployee emp ON (emp.UserAccount = rh.ModifiedBy)
				   LEFT JOIN DimResourceStateModel drsm on (drsm.StateModelId = rh.MainStateModelId and drsm.StateModelStateId = rh.MainStateModelStateId)
				   LEFT JOIN DimResourceStateModelChangeReason drsmcr on (drsmcr.ResourceStateModelChangeReason = substring(RH.MainStateModelStateReason, 1, 450) /* size limited to 450 chars due to index restrictions */)
				  WHERE RH.ServiceHistoryId between @MinServiceHistoryId and @MaxServiceHistoryId 
					AND RH.IsTemplate = 0
					AND rh.ResourceId = IsNull(@ResourceId, rh.ResourceId)
			) as a;


			declare @LC1StartOfDayTime time = '00:00:00';

			IF OBJECT_ID('tempdb..#LC1EndOfDays') IS NOT NULL
			   DROP TABLE #LC1EndOfDays
		
			CREATE TABLE #LC1EndOfDays
			(
				DateMark datetime,
				unique clustered (DateMark)
			);

			insert into #LC1EndOfDays (DateMark)
			select a.FullDateAlternateKey
			  from(	select d.FullDateAlternateKey
					  from (select min(minLC1OperationEndDate) as minOperationEndDate, max(maxLC1OperationEndDate) as maxOperationEndDate from #MinMaxDateKey) r
					  inner join DimDate d on d.FullDateAlternateKey between r.minOperationEndDate and r.maxOperationEndDate
				  ) a;

	if @DebugDMLTiming = 1
	BEGIN
		set @DebugEndDate = GETUTCDATE();
		set @DebugTimingMessage = 'Step ' + cast(@DebugStep as nvarchar) +' (iteration ' + convert(nvarchar(20), @RankID + 1) + '/' + convert(nvarchar(20), @MaxRankID + 1) + ' )' +' took ' + cast(datediff(ss,@DebugStartDate,@DebugEndDate) as nvarchar) + ' Seconds to execute.'
		RAISERROR ( @DebugTimingMessage, 0, 1) WITH NOWAIT

		set @DebugStartDate = GETUTCDATE();
		set @DebugEndDate = null;
		set @DebugStep = 4;
		set @DebugTimingMessage = null;
	END	
		
		--LC1 End Marks
		--Constants.F_MarkEndOfShiftKey(), Constants.F_MarkEndOfDayKey() and Constants.F_MarkBeginOfShiftKey() marks
		;WITH ManualMarks AS
		(
			select a.IsManualMark
					,a.ResourceKey
					,a.UTCOperationEndTime
					,a.[SEMI-E10]
					,a.ServiceKey
					,a.resourceType
					,a.Model
					,a.[Basic]
					,a.ServicehistoryId
					,a.OperationHistorySeq
					,a.OldServicehistoryId
					,a.OldOperationHistorySeq
					,a.ResourceStateModelKey
					,a.ResourceStateModelChangeReasonKey
					,a.MainStateModelStateReason
					,a.EmployeeKey
					,a.ServiceName
					,a.TimeZoneKey
					,a.UTCToLC1OffSetMin
					,LEAD(a.UTCOperationEndTime)  OVER (partition by a.ResourceKey ORDER BY a.UTCOperationEndTime ASC, a.ServiceHistoryId ASC, a.OperationHistorySeq ASC, a.SubOperationSequence ASC ) as LEADUTCOperationEndTime
					,a.InSetup
				from #tmp_EndMarks a

		),gen as (
			select --End of shift mark
					do.operationKey, do.OperationName, r.AreaKey, r.resourceId, r.ResourceName, r.ResourceKey, f.DateKey, f.TeamKey, f.ShiftKey, 
					f.LC1StartDateTime as StartDateTime, f.LC1EndDateTime as EndDateTime,
					2147483644 as [SubOperationSequence],  --max int val - 1
					f.LC1EndDateTime as LC1OperationEndTime, r.CanProcessInNonWorkingTime, f.EndDateTime as UTCOperationEndTime, f.TimeZoneKey, f.UTCToLC1OffSetMin
			  from #MinMaxDateKey r
			 cross join (select top(1) OperationId, OperationKey, OperationName from DimOperation where Operationid = Constants.F_GetUndefinedKey() and entityName = 'Resource' and OperationName = Constants.F_MarkEndOfShiftKey() ) as do
			 inner join factshift f on (f.DateKey between @MinServDateKeyPruning and @MaxServDateKeyPruning and f.AreaKey = r.areaKey and ( (f.LC1EndDateTime > r.minLC1OperationEndDate and f.LC1EndDateTime <= r.maxLC1OperationEndDate) ) )
			UNION ALL 
			select --End of Day
					do.operationKey, do.OperationName, r.AreaKey, r.resourceId, r.ResourceName, r.ResourceKey, n.DateKey, n.TeamKey, n.ShiftKey, 
					dateadd(day,-1,d.DateMark) as StartDateTime, d.DateMark as EndDateTime,
					2147483645 as [SubOperationSequence],  --max int val - 1
					d.DateMark as LC1OperationEndTime, r.CanProcessInNonWorkingTime, 
					case when n.UTCToLC1OffSetMin IS NULL
								then [DateTimeUtil].[UDF_ConvertLocalToUtcByTimezoneId](ISNULL(n.TimeZoneKey, r.TimeZoneKey), d.DateMark)
								else dateadd(MI, (0-n.UTCToLC1OffSetMin), d.DateMark)
					end as UTCOperationEndTime
					, ISNULL(n.TimeZoneKey, r.TimeZoneKey) as TimeZoneKey, n.UTCToLC1OffSetMin
			  from #MinMaxDateKey r
			 cross join (select top(1) OperationId, OperationKey, OperationName from DimOperation where Operationid = Constants.F_GetUndefinedKey() and entityName = 'Resource' and OperationName = Constants.F_MarkEndOfDayKey() ) as do
			 inner join #LC1EndOfDays d on (d.DateMark > r.minLC1OperationEndDate and d.DateMark <= r.maxLC1OperationEndDate )
			  left join factshift n on (n.DateKey between @MinServDateKeyPruning and @MaxServDateKeyPruning and n.AreaKey = r.areaKey and ( d.DateMark > n.LC1StartDatetime and d.DateMark <= n.LC1EndDateTime ))
			 where n.EndDateTime <> d.DateMark
			 UNION ALL
			select --Begin of shift mark
					do.operationKey, do.OperationName, r.AreaKey, r.resourceId, r.ResourceName, r.ResourceKey, f.DateKey, f.TeamKey, f.ShiftKey, 
					f.LC1StartDateTime as StartDateTime, f.LC1EndDateTime as EndDateTime, 
					2147483647 as [SubOperationSequence],  --max int val - 1
					f.LC1StartDateTime as LC1OperationEndTime, r.CanProcessInNonWorkingTime, f.StartDateTime as UTCOperationEndTime, f.TimeZoneKey, f.UTCToLC1OffSetMin
			  from #MinMaxDateKey r
			 cross join (select top(1) OperationId, OperationKey, OperationName from DimOperation where Operationid = Constants.F_GetUndefinedKey() and entityName = 'Resource' and OperationName = Constants.F_MarkBeginOfShiftKey() ) as do
			 inner join factshift f on (f.DateKey between @MinServDateKeyPruning and @MaxServDateKeyPruning and f.AreaKey = r.areaKey and (f.LC1StartDateTime >= r.minLC1OperationEndDate and f.LC1StartDateTime < r.maxLC1OperationEndDate) )
		)
		insert into #tmp_EndMarks WITH(TABLOCK)
		select   a.[UTCOperationEndTime] as [UTCServiceEndTime]
				,a.[UTCOperationEndTime]
				,a.[ShiftDateKey]
				,a.[ShiftKey]
				,a.[ResourceId]
				,a.[ResourceKey]
				,a.[AreaKey]
				,src.[SEMI-E10]
				,[OperationKey]
				,[OperationName]
				,src.[ServiceKey]
				,src.[ServiceName]
				, CAST(CONVERT(char(8),a.UTCOperationEndTime,112) AS INT) as [DateKey]				
				, DATEPART(HH, a.UTCOperationEndTime)*(10000)+DATEPART(MI, a.UTCOperationEndTime)*(100)+DATEPART(SS, a.UTCOperationEndTime) as [TimeKey]
				,a.[ResourceName]
				,src.[ResourceType]
				,src.[Model]
				,src.[Basic]
				,src.[ServiceHistoryId]
				,src.[OperationHistorySeq]
				,a.[SubOperationSequence]
				,src.[OldServiceHistoryId]
				,src.[OldOperationHistorySeq]
				,src.[ResourceStateModelKey]
				,src.[MainStateModelStateReason]
				,a.LC1OperationEndTime as LC1ServiceEndTime
				,a.LC1OperationEndTime
				,a.[UpToDownTransition]
				,a.[DownToUpTransition]
				,a.[TeamKey]
				,src.[EmployeeKey]
				,1 as [IsManualMark]
				,0 as IsTermination
				,a.CanProcessInNonWorkingTime
				,src.[ResourceStateModelChangeReasonKey]
				,ISNULL(src.TimeZoneKey, a.TimeZoneKey) as TimeZoneKey
				,ISNULL(src.UTCToLC1OffSetMin, a.UTCToLC1OffSetMin) as UTCToLC1OffSetMin
				,case when src.InSetup = 1 then 1 else 0 end
		  from	(select  distinct
						 gen.[UTCOperationEndTime]
						,gen.DateKey as ShiftDateKey
						,gen.ShiftKey
						,gen.ResourceId
						,gen.[ResourceKey]
						,gen.[AreaKey]
						,gen.OperationKey
						,gen.[OperationName]
						,gen.ResourceName as ResourceName
						,gen.[SubOperationSequence]  --max int val - 1
						,gen.LC1OperationEndTime
						,0 as [UpToDownTransition]
						,0 as [DownToUpTransition]
						,gen.TeamKey
						,gen.CanProcessInNonWorkingTime
						,gen.TimeZoneKey
						,gen.UTCToLC1OffSetMin
				 from  gen
				) as a
				left merge join ManualMarks src on (a.ResourceKey = src.ResourceKey and a.UTCOperationEndTime >= src.UTCOperationEndTime and a.UTCOperationEndTime < isnull(src.LEADUTCOperationEndTime,dateadd(minute,1,a.UTCOperationEndTime)))


	if @DebugDMLTiming = 1
	BEGIN
		set @DebugEndDate = GETUTCDATE();
		set @DebugTimingMessage = 'Step ' + cast(@DebugStep as nvarchar) +' (iteration ' + convert(nvarchar(20), @RankID + 1) + '/' + convert(nvarchar(20), @MaxRankID + 1) + ' )' +' took ' + cast(datediff(ss,@DebugStartDate,@DebugEndDate) as nvarchar) + ' Seconds to execute.'
		RAISERROR ( @DebugTimingMessage, 0, 1) WITH NOWAIT

		set @DebugStartDate = GETUTCDATE();
		set @DebugEndDate = null;
		set @DebugStep = 5;
		set @DebugTimingMessage = null;
	END 
			--Let's update remaining manually created marks, for getting last status from events, registered on the fact table
			;WITH Data as
			(
				select * from (
					select  fr.ResourceKey, fr.[DateKey], fr.[ServiceHistoryId], fr.[OperationHistorySeq], fr.[SubOperationSequence],
							fr.[SEMI-E10], fr.ServiceKey, fr.ResourceType, fr.Model, fr.[Basic], fr.ResourceStateModelKey, fr.ResourceStateModelChangeReasonKey, fr.MainStateModelStateReason, fr.EmployeeKey, fr.InSetup					
					  from (select ResourceKey, MIN(DateKey) DateKey
							  from #tmp_EndMarks
							 where IsManualMark = 1 and ServiceHistoryId is null
							 group by ResourceKey ) Unserv
					  cross apply (select top 1 fr.* from FactResourceServiceTime fr 
									where fr.ResourceKey = Unserv.ResourceKey and fr.DateKey <= Unserv.DateKey and fr.ServiceHistoryId <= @MaxServiceHistoryIdInTable 
											and fr.DateKey >= @MinServDateKeyPruning
									order by fr.DateKey desc, fr.TimeKey desc, fr.UTCOperationEndTime DESC, fr.ServiceHistoryId DESC, fr.OperationHistorySeq DESC, fr.SubOperationSequence DESC
						) fr
				) dat
			)
			update tgt
			   set   tgt.[SEMI-E10] = src.[SEMI-E10]
					,tgt.ServiceKey = ISNULL(src.ServiceKey, @NotDefinedService)
					,tgt.ResourceType = src.resourceType
					,tgt.Model = src.Model
					,tgt.[Basic] = src.[Basic]
					,tgt.ServiceHistoryId = ISNULL(src.ServicehistoryId, @MinServiceHistoryId)
					,tgt.OperationHistorySeq = ISNULL(src.OperationHistorySeq, 0)
					,tgt.OldServiceHistoryId = ISNULL(src.ServicehistoryId, @MinServiceHistoryId)
					,tgt.OldOperationHistorySeq = ISNULL(src.OperationHistorySeq, 0)
					,tgt.ResourceStateModelKey = ISNULL(src.ResourceStateModelKey, @NotDefinedResourceStateModelKey)
					,tgt.ResourceStateModelChangeReasonKey = ISNULL(src.ResourceStateModelChangeReasonKey, @NotDefinedResourceStateModelChangeReasonKey)
					,tgt.MainStateModelStateReason = ISNULL(src.MainStateModelStateReason, @NotDefinedName)
					,tgt.EmployeeKey = ISNULL(src.EmployeeKey, @NotDefinedEmployee)
					,tgt.InSetup = case when src.InSetup = 1 then 1 else 0 end
			  from #tmp_EndMarks tgt WITH(TABLOCK)
			  left merge join Data src on (src.ResourceKey = tgt.ResourceKey)
			  where tgt.IsManualMark = 1 and tgt.ServiceHistoryId is null;

	if @DebugDMLTiming = 1
	BEGIN
		set @DebugEndDate = GETUTCDATE();
		set @DebugTimingMessage = 'Step ' + cast(@DebugStep as nvarchar) +' (iteration ' + convert(nvarchar(20), @RankID + 1) + '/' + convert(nvarchar(20), @MaxRankID + 1) + ' )' +' took ' + cast(datediff(ss,@DebugStartDate,@DebugEndDate) as nvarchar) + ' Seconds to execute.'
		RAISERROR ( @DebugTimingMessage, 0, 1) WITH NOWAIT

		set @DebugStartDate = GETUTCDATE();
		set @DebugEndDate = null;
		set @DebugStep = 6;
		set @DebugTimingMessage = null;
	END

		--Sets The next operationEndDate on previously saved records.
		;WITH fact as
		(
			select * from (
				select  AreaKey, ResourceKey, 
						DateKey as ToUpdateDateKey,
						ShiftKey,
						TimeKey as ToUpdateTimeKey,
						OperationKey as ToUpdateOperationKey,
						UTCoperationendtime as ToUpdateUTCOperationEndTime,
						ServiceHistoryId as ToUpdateServiceHistoryId,
						OperationHistorySeq as ToUpdateOperationhistorySeq,
						SubOperationSequence as ToUpdateSubOperationSequence,
						LC1OperationEndTime,
						UTCOperationEndTime,
						UTCNextOperationEndTime,
						LC1NextOperationEndTime,
						UpdateServiceHistoryId,
						UpdateTimestamp,
						[NonWorkingTimeInSeconds],
						ROW_NUMBER() over (partition by areakey, resourcekey order by Datekey desc, UTCOperationEndTime desc, ServiceHistoryId desc, OperationHistorySeq desc, SubOperationSequence desc) as rnum
				  from FactResourceServiceTime fr			 
				 where fr.DateKey >= @MinServDateKeyPruning and fr.UTCNextOperationEndTime is NULL
			) dat
			where dat.rnum = 1
		 ),
		 newFact as
		 (
			select *, case when dat.UTCToLC1OffSetMin IS NULL
														then [DateTimeUtil].[UDF_ConvertUtcToLocalByTimezoneId](dat.TimeZoneKey, dat.UpdateUTCOperationendtime)
														else dateadd(MI, dat.UTCToLC1OffSetMin, dat.UpdateUTCOperationendtime)
											end as UpdateLC1NextOperationEndTime
			 from (
			 select areakey, a.resourcekey,
					DateKey as UpdateDateKey,	
					TimeKey as UpdateTimeKey,	
					OperationKey as UpdateOperationKey,	
					UTCOperationendtime as UpdateUTCOperationendtime,
					ServiceHistoryId as UpdateServiceHistoryId,
					OperationHistorySeq as UpdateOperationhistorySeq,
					SubOperationSequence as UpdateSubOperationSequence,
					a.TimeZoneKey,
					a.[UTCToLC1OffSetMin],
					a.CanProcessInNonWorkingTime,
					ROW_NUMBER() over (partition by a.resourcekey order by Datekey asc, UTCOperationEndTime asc, ServiceHistoryId asc, OperationHistorySeq asc, SubOperationSequence asc) as rnum
			  from #tmp_EndMarks a			 
			   where a.IsManualMark = 0 or 
					(a.IsManualMark = 1 and not exists 
								( select top (1) 1 
									from factResourceServicetime b
									where b.DateKey = a.DateKey
										and b.ShiftDateKey = a.ShiftDateKey
										and b.ShiftKey = a.ShiftKey
										and b.TimeKey = a.TimeKey
										and b.ResourceKey = a.ResourceKey
										and b.AreaKey = a.AreaKey
										and b.ServiceHistoryId = a.ServiceHistoryId
										and b.OperationHistorySeq = a.OperationHistorySeq
										and b.SubOperationSequence = a.SubOperationSequence))
			)dat
			where dat.rnum = 1
		) 
		update T
		   set T.UTCNextOperationEndTime = newFact.UpdateUTCOperationendtime
		      ,T.LC1NextOperationEndTime = newFact.UpdateLC1NextOperationEndTime
			  ,T.UpdateServiceHistoryId = newFact.UpdateServiceHistoryId
			  ,T.UpdateTimestamp = @ProcessingTimeStamp
			  ,T.[NonWorkingTimeInSeconds] = -- sums non working times in intervals				
						ISNULL( case when newFact.CanProcessInNonWorkingTime = 1 OR T.UTCOperationEndTime = T.UTCNextOperationEndTime then 0
							   else
									(
										select SUM(datediff(SS, StartThreshold, EndThreshold)) as NonWorkingTimeInSeconds  
											from (
													select case when (timeStartInterval <= starttime)
															then starttime
															when timeStartInterval >= endtime 
															then null
															else timeStartInterval
															end StartThreshold,
														   case when (timeEndInterval >= EndTime)
															then EndTime
															else timeEndInterval
															end EndThreshold
													from (
														select *
														from (
															select
																cast(StartTime as datetime) as StartTime, 
																
																case when s.[StartIntervalTime] < ShiftStartTime
																	then dateadd(day, 1, cast( s.[StartIntervalTime] as datetime))
																	else cast( s.[StartIntervalTime] as datetime) 
																end as timeStartInterval,	
																
																case when ( s.[EndIntervalTime] <=  s.[StartIntervalTime] OR s.[StartIntervalTime] < ShiftStartTime )
																	then dateadd(day, 1, cast( s.[EndIntervalTime] as datetime))
																	else cast( s.[EndIntervalTime] as datetime) 
																end as timeEndInterval,
																
																case when EndTime <= StartTime 
																	then dateadd(day, 1, cast(EndTime as datetime))
																	else cast(EndTime as datetime) 
																end as EndTime
															from (
																	select s.starttime, s.endtime, ds.StartTime as ShiftStartTime,
																	  -- Start and End Intervals in TimeZone datetime to directly compare with DimShiftNonWorkingTime which always contains datetimes for the calendar timezone 
																	  cast(T.[LC1OperationEndTime] as time(7)) as [StartIntervalTime],
																	  cast(newFact.UpdateLC1NextOperationEndTime as time(7)) as [EndIntervalTime]
																	from dbo.DimShiftNonWorkingTime s
																	inner join dbo.dimshift ds on s.ShiftKey = ds.ShiftKey
																	where (s.ShiftKey != @UndefinedShiftKey and s.ShiftKey = T.ShiftKey)
															) s 
														) s
														where ( 
															timeStartInterval between StartTime and EndTime
															OR
															timeEndInterval between StartTime and EndTime
															OR
															timeStartInterval < starttime and timeEndInterval > endtime
														)
												) dat
										) finalSum
									)
							   end, 0)

          from fact T WITH(TABLOCK)		  
		  inner merge join newFact on (	newFact.ResourceKey = T.ResourceKey 
									);

		  set @StatusMessage = @PROCNAME + ': ' + cast(@@ROWCOUNT as nvarchar) + ' row(s) updated from ' + @TABLENAME
		  RAISERROR (@StatusMessage, 0, 1) WITH NOWAIT


	--DATA VALIDATION
	IF @DataValidation = 1		  
	BEGIN		  
		
			declare @auxResourceKey0 int;

			select top 1 @auxResourceKey0 = resourceKey 
					from factResourceServiceTime
					where UTCNextOperationEndTime is null and DateKey >= @MinServDateKeyPruning
					GROUP by areakey, resourcekey
					having COUNT(1) > 1
					order by ResourceKey;

			if @auxResourceKey0 is not null
			BEGIN

				select *
					from factResourceServiceTime
					where ResourceKey = @auxResourceKey0 and DateKey >= @MinServDateKeyPruning
					order by UTCOperationEndTime DESC, CreateTimestamp DESC, ISNULL(UTCNextOperationEndTime, dateadd(year,2,UTCOperationEndTime ) ) desc;

				declare @mesg0 nvarchar(max);
				set @mesg0 = 'Validation error when setting UTCNextOperationEndTime for previously processed rows for (at least) ResourceKey: '+ cast(@auxResourceKey0 as nvarchar)
				RAISERROR ( @mesg0, 16, 1) WITH NOWAIT
			END

			if exists(select top 1 1 from #tmp_EndMarks where ServiceHistoryId is null or OperationHistorySeq is null) 
			BEGIN
				select * from #tmp_EndMarks where ServiceHistoryId is null or OperationHistorySeq is null order by resourceKey, UTCOperationEndTime

				select * from #MinMaxDateKey order by resourcekey
			END
	END
	--DATA VALIDATION



	if @DebugDMLTiming = 1
	BEGIN
		set @DebugEndDate = GETUTCDATE();
		set @DebugTimingMessage = 'Step ' + cast(@DebugStep as nvarchar) +' (iteration ' + convert(nvarchar(20), @RankID + 1) + '/' + convert(nvarchar(20), @MaxRankID + 1) + ' )' +' took ' + cast(datediff(ss,@DebugStartDate,@DebugEndDate) as nvarchar) + ' Seconds to execute.'
		RAISERROR ( @DebugTimingMessage, 0, 1) WITH NOWAIT

		set @DebugStartDate = GETUTCDATE();
		set @DebugEndDate = null;
		set @DebugStep = 7;
		set @DebugTimingMessage = null;
	END

		--Inserts all facts (real or manual marks).
		--Notice that when a fact corresponds to a resource termination, it will be inserted with UTCNextOperationEndTime = UTCOperationEndTime, closing its cycle.
		INSERT INTO FactResourceServiceTime  WITH(TABLOCK)(
					[UTCServiceEndTime]
					,[UTCOperationEndTime]
					,[UTCNextOperationEndTime]
					,[ShiftDateKey]
					,[ShiftKey]
					,[ResourceKey]
					,[AreaKey]
					,[SEMI-E10]
					,[OperationKey]
					,[ServiceKey]
					,[DateKey]
					,[TimeKey]
					,[ResourceName]
					,[ResourceType]
					,[Model]
					,[Basic]
					,[ServiceHistoryId]
					,[OperationHistorySeq]
					,[SubOperationSequence]
					,[OldServiceHistoryId]
					,[OldOperationHistorySeq]
					,[CreateTimestamp]
					,[UpdateTimestamp]
					,[ResourceStateModelKey]
					,[ResourceStateModelChangeReasonKey]
					,[MainStateModelStateReason]
					,[LC1ServiceEndTime]
					,[LC1OperationEndTime]
					,[LC1NextOperationEndTime]
					,[LC1DateKey]
					,[LC1TimeKey]
					,[DownToUpTransition]
					,[UpToDownTransition]
					,[TeamKey]
					,[EmployeeKey]
					,[NonWorkingTimeInSeconds]
					,[InSetup])
		select   [UTCServiceEndTime]
				,[UTCOperationEndTime]
				,[UTCNextOperationEndTime]
				,[ShiftDateKey]
				,[ShiftKey]
				,[ResourceKey]
				,[AreaKey]
				,[SEMI-E10]
				,[OperationKey]
				,[ServiceKey]
				,[DateKey]
				,[TimeKey]
				,[ResourceName]
				,[ResourceType]
				,[Model]
				,[Basic]
				,[ServiceHistoryId]
				,[OperationHistorySeq]
				,[SubOperationSequence]
				,[OldServiceHistoryId]
				,[OldOperationHistorySeq]
				,[CreateTimestamp]
				,[UpdateTimestamp]
				,[ResourceStateModelKey]
				,[ResourceStateModelChangeReasonKey]
				,[MainStateModelStateReason]
				,[LC1ServiceEndTime]
				,[LC1OperationEndTime]
				,[LC1NextOperationEndTime]
				,[LC1DateKey]
				,[LC1TimeKey]
				,[DownToUpTransition]
				,[UpToDownTransition]
				,[TeamKey]
				,[EmployeeKey]
				-- sums non working times in intervals				
				,ISNULL( case when CanProcessInNonWorkingTime = 1 OR UTCOperationEndTime = UTCNextOperationEndTime then 0
					   else
							(
								select SUM(datediff(SS, StartThreshold, EndThreshold)) as NonWorkingTimeInSeconds  from (
											select case when (timeStartInterval <= starttime)
													then starttime
													when timeStartInterval >= endtime 
													then null
													else timeStartInterval
													end StartThreshold,
												   case when (timeEndInterval >= EndTime)
													then EndTime
													else timeEndInterval
													end EndThreshold
											from (
												select * from (
													select 
														case when c.[StartIntervalTime] < ds.StartTime
															then dateadd(day, 1, cast( c.[StartIntervalTime] as datetime))
															else cast( c.[StartIntervalTime] as datetime) end as timeStartInterval
														, case when ( c.[EndIntervalTime] <=  c.[StartIntervalTime] OR c.[StartIntervalTime] < ds.StartTime )
															then dateadd(day, 1, cast( c.[EndIntervalTime] as datetime))
															else cast( c.[EndIntervalTime] as datetime) end as timeEndInterval
														, cast(s.StartTime as datetime) as StartTime
														, case when s.EndTime <= s.StartTime 
															then dateadd(day, 1, cast(s.EndTime as datetime))
															else cast(s.EndTime as datetime) end as EndTime												
													from dbo.DimShiftNonWorkingTime s
													inner join dbo.dimshift ds on s.ShiftKey = ds.ShiftKey
													where s.ShiftKey != @UndefinedShiftKey and s.ShiftKey = c.ShiftKey
												) s
												where ( 
													timeStartInterval between starttime and endtime
													OR
													timeEndInterval between starttime and endtime
													OR
													timeStartInterval < starttime and timeEndInterval > endtime
												)
											) dat
										) finalSum
							)
					   end, 0) as NonWorkingTimeInSeconds
					   ,[InSetup]
			from (
			 SELECT	 b.[UTCServiceEndTime]
					,b.[UTCOperationEndTime]					
					,case when b.IsTermination = 1 then b.[UTCOperationEndTime]
						  else b.[UTCNextOperationEndTime] 
					  end [UTCNextOperationEndTime] 
					-- Start and End Intervals in TimeZone datetime to directly compare with DimShiftNonWorkingTime which always contains datetimes for the calendar timezone 
					, cast(b.[LC1OperationEndTime] as time(7)) as [StartIntervalTime]
					, cast(case when b.IsTermination = 1 then b.[LC1OperationEndTime]							 
							else case when b.UTCToLC1OffSetMin IS NULL
									then [DateTimeUtil].[UDF_ConvertUtcToLocalByTimezoneId](b.TimeZoneKey, b.[UTCNextOperationEndTime])
									else dateadd(MI, b.UTCToLC1OffSetMin, b.[UTCNextOperationEndTime])								
								end 
							end as time(7)) as [EndIntervalTime] 
					,b.[ShiftDateKey]
					,b.[ShiftKey]
					,b.[ResourceKey]
					,b.[AreaKey]
					,b.[SEMI-E10]
					,b.[OperationKey]
					,b.[ServiceKey]
					,b.[DateKey]
					,b.[TimeKey]
					,b.[ResourceName]
					,b.[ResourceType]
					,b.[Model]
					,b.[Basic]
					,b.[ServiceHistoryId]
					,b.[OperationHistorySeq]
					,b.[SubOperationSequence]
					,b.[OldServiceHistoryId]
					,b.[OldOperationHistorySeq]
					,b.[CreateTimestamp]
					,NULL as UpdateTimestamp
					,b.[ResourceStateModelKey]
					,b.[ResourceStateModelChangeReasonKey]
					,b.[MainStateModelStateReason]
					,b.[LC1ServiceEndTime]
					,b.[LC1OperationEndTime]
					,case when b.IsTermination = 1 then case when b.UTCToLC1OffSetMin IS NULL
															then [DateTimeUtil].[UDF_ConvertUtcToLocalByTimezoneId](b.TimeZoneKey, b.[UTCOperationEndTime])
															else dateadd(MI, b.UTCToLC1OffSetMin, b.[UTCOperationEndTime])								
														end
						  else  case when b.UTCToLC1OffSetMin IS NULL
									then [DateTimeUtil].[UDF_ConvertUtcToLocalByTimezoneId](b.TimeZoneKey, b.[UTCNextOperationEndTime])
									else dateadd(MI, b.UTCToLC1OffSetMin, b.[UTCNextOperationEndTime])								
								end
						  end as [LC1NextOperationEndTime] 						
					,b.[LC1DateKey]
					,b.[LC1TimeKey]
					,b.[DownToUpTransition]
					,b.[UpToDownTransition]
					,b.TeamKey
					,isnull(b.EmployeeKey,@NotDefinedEmployee) as [EmployeeKey]
					,b.CanProcessInNonWorkingTime
					,b.InSetup
			  FROM (SELECT	a.*
							,CAST(CONVERT(char(8),a.LC1OperationEndTime,112) AS INT) as [LC1DateKey]
							,DATEPART(HH, a.LC1OperationEndTime)*(10000)+DATEPART(MI, a.LC1OperationEndTime)*(100)+DATEPART(SS, a.LC1OperationEndTime) as [LC1TimeKey]
							,lead(UTCOperationEndTime) over (partition by resourcekey order by UTCOperationEndTime, ShiftDateKey, ShiftKey, servicehistoryid, operationhistoryseq, suboperationsequence ) AS UTCNextOperationEndTime
							,@ProcessingTimeStamp as [CreateTimestamp] 
						FROM #tmp_EndMarks a
							where not exists (select 1
						                    from factResourceServiceTime act											 
											where	act.[AreaKey] = a.[AreaKey] and 
													act.[ResourceKey] = a.[ResourceKey] and 
													act.dateKey = a.Datekey and 
													act.timeKey = a.timekey and 
													act.shiftKey = a.shiftkey and 
													act.shiftdatekey = a.shiftdatekey and
													act.servicehistoryId = a.servicehistoryid and
													act.operationhistoryseq = a.operationhistoryseq and
													act.suboperationsequence = a.suboperationsequence
										 )

					) b
			)c;

		set @StatusMessage = @PROCNAME + ': ' + cast(@@ROWCOUNT as nvarchar) + ' row(s) inserted into ' + @TABLENAME

		RAISERROR (@StatusMessage, 0, 1) WITH NOWAIT

	if @DebugDMLTiming = 1
	BEGIN
		set @DebugEndDate = GETUTCDATE();
		set @DebugTimingMessage = 'Step ' + cast(@DebugStep as nvarchar) +' (iteration ' + convert(nvarchar(20), @RankID + 1) + '/' + convert(nvarchar(20), @MaxRankID + 1) + ' )' +' took ' + cast(datediff(ss,@DebugStartDate,@DebugEndDate) as nvarchar) + ' Seconds to execute.'
		RAISERROR ( @DebugTimingMessage, 0, 1) WITH NOWAIT

		set @DebugStartDate = GETUTCDATE();
		set @DebugEndDate = null;	
		set @DebugStep = 8;
		set @DebugTimingMessage = null;
	END

	set @endDateLoop = GETUTCDATE();
	set @DebugTimingMessage = 'Ending iteration ' + convert(nvarchar(20), @RankID + 1) + '/' + convert(nvarchar(20), @MaxRankID + 1) + ' on ' + CONVERT(nvarchar(50), @endDateLoop,121) + ' took ' + cast(datediff(ss,@startDateLoop,@endDateLoop) as varchar) + ' seconds to execute.'
	RAISERROR ( @DebugTimingMessage, 0, 1) WITH NOWAIT
	set @startDateLoop = GETUTCDATE();

	--next rank iteration
	SET @RankID = @RankID + 1;
END; 
-- end of loop on chunks

		exec Control.P_StopExecution @PROCNAME, @StatusMessage;

		-- If There was no transaction on the beginning of the exception, a new one was created and has to be committed.
		IF @starttrancount = 0
			COMMIT TRANSACTION;
			
		
	END TRY
	BEGIN CATCH
		IF XACT_STATE() <> 0 AND @starttrancount = 0 
			ROLLBACK TRANSACTION

		--select @ErrorMessage = ERROR_MESSAGE()
		--RAISERROR (@ErrorMessage, 0, 1) WITH NOWAIT
		
		exec Control.P_StopExecution @PROCNAME;

		SELECT @ErrorMessage = ERROR_MESSAGE() + ' Line ' + cast(ERROR_LINE() as nvarchar(5)), @ErrorSeverity = ERROR_SEVERITY(), @ErrorState = ERROR_STATE();
		RAISERROR (@ErrorMessage, @ErrorSeverity, @ErrorState);

	END CATCH

END
GO
