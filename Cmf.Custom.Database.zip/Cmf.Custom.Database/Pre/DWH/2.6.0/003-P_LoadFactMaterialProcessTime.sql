﻿ALTER PROCEDURE [dbo].[P_LoadFactMaterialProcessTime] ( @InfServiceHistoryId bigint = NULL, @SupServiceHistoryId bigint = NULL, @ResourceId bigint = NULL )
--WITH ENCRYPTION
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements. 
	SET XACT_ABORT ON
	SET NOCOUNT ON

	--Controls number of transactions
	DECLARE @starttrancount int

	declare @ErrorMessage nvarchar(max), 
		    @ErrorSeverity int, 
			@ErrorState int;

	DECLARE @DebugDMLTiming bit = 1;  -- Change to 1, for acquiring Routine steps timing
	DECLARE @DebugTimingMessage varchar(max);
	DECLARE @DebugStep int;
	DECLARE @DebugStartDate datetime, @DebugEndDate datetime;

	DECLARE @TABLENAME varchar (32) = 'FactMaterialProcessTime'; 

	DECLARE @PROCNAME varchar (64); 
	SELECT @PROCNAME = OBJECT_NAME(@@PROCID);
	--SELECT @PROCNAME = 'P_LoadFactResourceMaterialPerformance';

	DECLARE @CurrentDatetime datetime = getUTCdate();
	DECLARE @StatusMessage nvarchar(256);

	DECLARE @IsOtheFilterApplied bit;
	select @IsOtheFilterApplied = case when @ResourceId is not null then 1 else 0 end;

	DECLARE @MinServiceHistoryId bigint, @MaxServiceHistoryId bigint;

	DECLARE @DefaultTimeZone TINYINT = [DateTimeUtil].[F_GetServerTimeZoneId](null);
	
	BEGIN TRY
		SELECT @starttrancount = @@TRANCOUNT

		IF @starttrancount = 0
			BEGIN TRANSACTION
	
		exec Control.P_StartExecution @PROCNAME, @MinServiceHistoryIdCalculated = @MinServiceHistoryId OUTPUT, @MaxServiceHistoryIdCalculated = @MaxServiceHistoryId OUTPUT, 
									  @InferiorServiceHistoryId = @InfServiceHistoryId, @SuperiorServiceHistoryId = @SupServiceHistoryId, @OtherFilters = @IsOtheFilterApplied;
	
	

if @DebugDMLTiming = 1
BEGIN
	set @DebugStartDate = GETUTCDATE();
	set @DebugEndDate = null;
	set @DebugStep = 0;
	set @DebugTimingMessage = null;
END

		declare @ResourceKey bigint;
		select @ResourceKey = ResourceKey from DimResource where ResourceId = @ResourceId; 

		declare @UndefinedResourceKey bigint;
		select @UndefinedResourceKey = ResourceKey from DimResource where ResourceId = Constants.F_GetUndefinedKey();

		DECLARE @MinServDateTime datetime, @MaxServDateTime datetime;

		select @MinServDateTime = MinServDateTime, @MaxServDateTime = MaxServDateTime
		from [dbo].[F_GetMinAndMaxServiceTime](@MinServiceHistoryId, @MaxServiceHistoryId);

		declare @MinServiceDateKey int, @MaxServiceDateKey int;
		set @MinServiceDateKey = dbo.F_GetDateKeyFromDateTime(@MinServDateTime);
		set @MaxServiceDateKey = dbo.F_GetDateKeyFromDateTime(@MaxServDateTime);

		-- no material quality can exist previously to the material creation so use this servicehistoryid to apply partitioning filtering
		declare @UpdateMinServiceHistoryId bigint, @MinServiceDateKeyPruning int;
		SELECT @UpdateMinServiceHistoryId = min(mm.startservicehistoryid)
		FROM (
			SELECT DISTINCT MaterialId
			FROM [Staging].[T_MaterialHistory]
			) m
		INNER JOIN DimMaterial mm ON (m.MaterialId = mm.MaterialId);

		select @MinServiceDateKeyPruning = dbo.F_GetDateKeyFromDateTime(MinServDateTime)
		from [dbo].[F_GetMinAndMaxServiceTime](@UpdateMinServiceHistoryId, @MaxServiceHistoryId);

		delete from [dbo].[FactMaterialProcessTime] WITH(TABLOCK)
		 where ResourceKey = isnull(@ResourceKey,ResourceKey) 
		   and TrackOutServiceHistoryId >= @MinServiceHistoryId		
		   and datekey >= @MinServiceDateKeyPruning;


		set @StatusMessage = OBJECT_NAME(@@PROCID) + ': ' + cast(@@ROWCOUNT as varchar) + ' row(s) deleted from ' + @TABLENAME
		RAISERROR ( @StatusMessage , 0, 1) WITH NOWAIT


if @DebugDMLTiming = 1
BEGIN
	set @DebugEndDate = GETUTCDATE();
	set @DebugTimingMessage = 'Step ' + cast(@DebugStep as varchar) +' took ' + cast(datediff(ss,@DebugStartDate,@DebugEndDate) as varchar) + ' Seconds to execute.'
	RAISERROR ( @DebugTimingMessage, 0, 1) WITH NOWAIT

	set @DebugStartDate = GETUTCDATE();
	set @DebugEndDate = null;
	set @DebugStep =  2;
	set @DebugTimingMessage = null;
END

		
		IF OBJECT_ID('tempdb..#tmp_semioperations') IS NOT NULL
		   DROP TABLE #tmp_semioperations


		CREATE TABLE #tmp_semioperations
		(
			AreaKey bigint,
			StepKey bigint,
			ProductKey bigint,
			FlowKey bigint,
			AreaId bigint,
			ResourceKey bigint,
			ResourceId bigint,
			ParentResourceKey bigint,
			MaterialKey bigint,
			MaterialId bigint,
			TrackInOperationTime datetime,
			TrackInServiceHistoryId bigint,
			TrackInOperationHistorySeq bigint,
			TrackInSubOperationSequence int,
			TrackOutOperationTime datetime,
			TrackOutServiceHistoryId bigint,
			TrackOutOperationHistorySeq bigint,
			TrackOutSubOperationSequence int,
			SubMaterialCount int,
			MaterialHierarchykey int,
			ParentMaterialKey bigint,
			HasChildren bit,
			IdealCycleTime decimal(18,8),
			IdealBaseCycleTime decimal(18,8),
			ParentIdealCycleTime decimal(18,8),
			ParentIdealBaseCycleTime decimal(18,8),
			PrimaryUnitKey bigint,
			SecondaryUnitKey bigint,
			StartPrimaryQuantity decimal(18,8),
			StartSubMaterialsPrimaryQuantity decimal(18,8),
			StartSecondaryQuantity decimal(18,8),
			StartSubMaterialsSecondaryQuantity decimal(18,8),
			EndPrimaryQuantity decimal(18,8),
			EndSubMaterialsPrimaryQuantity decimal(18,8),
			EndSecondaryQuantity decimal(18,8),
			EndSubMaterialsSecondaryQuantity decimal(18,8),
			[TimeZoneKey] TINYINT,
			[UTCToLC1OffSetMin] SMALLINT NULL,
			UNIQUE CLUSTERED (areakey, resourcekey, TrackInOperationTime, TrackOutOperationTime, MaterialKey)
		);

		
		--We're only handling production tracked out during this ServiceHistoryId range or for materials which were aborted or terminated within process
		insert into #tmp_semioperations WITH(TABLOCK) ( areakey, StepKey, ProductKey, FlowKey, areaId, ResourceKey, ResourceId, ParentResourceKey, MaterialKey, materialId, 
										  TrackInOperationTime, TrackInServiceHistoryId, TrackInOperationHistorySeq, TrackInSubOperationSequence,
										  TrackOutOperationTime, TrackOutServiceHistoryId, TrackOutOperationHistorySeq, TrackOutSubOperationSequence,
										  SubMaterialCount, MaterialHierarchykey, ParentMaterialKey, HasChildren, IdealCycleTime,IdealBaseCycleTime,
										  ParentIdealCycleTime, ParentIdealBaseCycleTime, PrimaryUnitKey, SecondaryUnitKey, 
										  StartPrimaryQuantity, StartSubMaterialsPrimaryQuantity, EndPrimaryQuantity, EndSubMaterialsPrimaryQuantity,
										  StartSecondaryQuantity, StartSubMaterialsSecondaryQuantity, EndSecondaryQuantity, EndSubMaterialsSecondaryQuantity,
										  TimeZoneKey, UTCToLC1OffSetMin
										)
		select MEP.StartResourceAreaKey as AreaKey, 
			   MEP.StepKey, MEP.ProductKey, MEP.FlowKey,
			   da.areaId, 
			   MEP.StartResourceKey as ResourceKey, 
			   dr.ResourceId,
			   MEP.StartParentResourceKey as ParentResourceKey,
			   MEP.MaterialKey, 
			   dm.materialId, 
			   MEP.StartUTCDatetime as TrackInOperationTime, 
			   MEP.StartServiceHistoryId as TrackInServiceHistoryId, 
			   MEP.StartOperationHistorySeq as TrackInOperationHistorySeq, 
			   MEP.StartSubOperationSequence as TrackInSubOperationSequence,
			   MEP.EndUTCDatetime as TrackOutOperationTime, 
			   MEP.EndServiceHistoryId as TrackOutServiceHistoryId, 
			   MEP.EndOperationHistorySeq as TrackOutOperationHistorySeq,
			   MEP.EndSubOperationSequence as TrackOutSubOperationSequence,
			   isnull(MEP.EndSubMaterialCount, MEP.StartSubMaterialCount) as SubMaterialCount,
			   MEP.MaterialHierarchyKey, 
			   MEP.ParentMaterialKey,
			   0 as HasChildren, --default value

			   --TODO Adjust the 2 lines below if necessary
			  -- [dbo].[F_GetResourceIdealCycleTime](dr.ResourceName, dp.ProductName, MEP.StartProductGroup, ds.Stepname, MEP.StartResourceType, MEP.StartResourceModel, MEP.StartUTCDatetime) IdealCycleTime,
			   dbo.F_ResolveResourceIdealCycleTime (dr.ResourceName, dp.ProductName, MEP.StartProductGroup, ds.Stepname, MEP.StartResourceType, MEP.StartResourceModel, 0 /* IsReference = false */) as IdealCycleTime,  
			   dbo.F_ResolveResourceIdealCycleTime (dr.ResourceName, dp.ProductName, MEP.StartProductGroup, ds.Stepname, MEP.StartResourceType, MEP.StartResourceModel, 1 /* IsReference = true */) as IdealBaseCycleTime,

			   /* Store the CycleTime to normalize quantities relative to the parent times */
			   case when drp.ResourceKey = @UndefinedResourceKey then 0 else dbo.F_ResolveResourceIdealCycleTime (drp.ResourceName, dp.ProductName, MEP.StartProductGroup, ds.Stepname, MEP.StartResourceType, MEP.StartResourceModel, 0 /* IsReference = false */) end as ParentIdealCycleTime,  
			   case when drp.ResourceKey = @UndefinedResourceKey then 0 else dbo.F_ResolveResourceIdealCycleTime (drp.ResourceName, dp.ProductName, MEP.StartProductGroup, ds.Stepname, MEP.StartResourceType, MEP.StartResourceModel, 1 /* IsReference = true */) end as ParentIdealBaseCycleTime, 

			   MEP.PrimaryUnitKey, MEP.SecondaryUnitKey,
			   /* When the "In Operation" is SplitFrom, the input quantity must be 0 because is already considered in other operation */
			   /* When the "Out Operation" either Terminate or Abort but StartPrimaryQuantity - EndPrimaryQuantity is higher than 0, then assume quantity was transfered to other materials (split) */
			   case when dos.OperationName = 'SplitFrom' then 0 when doe.OperationName IN ('Terminate', 'AbortProcess') THEN MEP.StartPrimaryQuantity - MEP.EndPrimaryQuantity else MEP.StartPrimaryQuantity end StartPrimaryQuantity, 
			   case when dos.OperationName = 'SplitFrom' then 0  when doe.OperationName IN ('Terminate', 'AbortProcess') THEN MEP.StartSubMaterialsPrimaryQuantity - MEP.EndSubMaterialsPrimaryQuantity else MEP.StartSubMaterialsPrimaryQuantity end StartSubMaterialsPrimaryQuantity, 
			   case when doe.OperationName IN ('Terminate', 'AbortProcess') then 0 else MEP.EndPrimaryQuantity end as EndPrimaryQuantity, 
			   case when doe.OperationName IN ('Terminate', 'AbortProcess') then 0 else MEP.EndSubMaterialsPrimaryQuantity end as EndSubMaterialsPrimaryQuantity,
			   case when dos.OperationName = 'SplitFrom' then 0 when doe.OperationName IN ('Terminate', 'AbortProcess') then MEP.StartSecondaryQuantity - MEP.EndSecondaryQuantity else MEP.StartSecondaryQuantity end StartSecondaryQuantity, 
			   case when dos.OperationName = 'SplitFrom' then 0 when doe.OperationName IN ('Terminate', 'AbortProcess') then MEP.StartSubMaterialsSecondaryQuantity - MEP.EndSubMaterialsSecondaryQuantity else MEP.StartSubMaterialsSecondaryQuantity end StartSubMaterialsSecondaryQuantity, 
			   case when doe.OperationName IN ('Terminate', 'AbortProcess') then 0 else MEP.EndSecondaryQuantity end as EndSecondaryQuantity, 
			   case when doe.OperationName IN ('Terminate', 'AbortProcess') then 0 else MEP.EndSubMaterialsSecondaryQuantity end as EndSubMaterialsSecondaryQuantity,
			   COALESCE(fs.TimeZoneKey, dr.TimeZoneKey, da.TimeZoneKey, @DefaultTimeZone) AS TimeZoneKey, fs.[UTCToLC1OffSetMin]
		  from FactMaterialEventPair MEP
		inner join DimMaterial dm on dm.MaterialKey = MEP.MaterialKey
		inner join DimOperation dos on dos.OperationKey = MEP.StartOperationKey
		LEFT JOIN DimOperation doe ON doe.OperationKey = MEP.EndOperationKey
		LEFT JOIN DimArea da ON da.AreaKey = MEP.StartResourceAreaKey
		LEFT JOIN DimResource dr ON dr.ResourceKey = MEP.StartResourceKey
		LEFT JOIN DimResource drp ON drp.ResourceKey = MEP.StartParentResourceKey
		LEFT JOIN DimStep ds ON ds.StepKey = MEP.StepKey
		LEFT JOIN DimProduct dp ON dp.ProductKey = MEP.ProductKey
		LEFT JOIN FactShift fs on (fs.DateKey = MEP.StartShiftDateKey and fs.AreaKey = MEP.StartAreaKey and fs.ShiftKey = MEP.StartShiftKey)
		where dos.OperationName in ('TrackIn','SplitFrom')
			and (
					doe.OperationName = 'TrackOut'
					OR 
					(dos.OperationName = 'TrackIn' AND DOE.OperationName IN ('Terminate', 'AbortProcess') 
					  AND (MEP.StartPrimaryQuantity - MEP.EndPrimaryQuantity) > 0) -- if out quantity diferent than StartPrimaryQuantity then count it as most likely material had a split
				)
		  and MEP.StartResourceKey = isnull(@ResourceKey, MEP.StartResourceKey)
		  and MEP.IsOpen = 0
		  and MEP.EndServiceHistoryId between @MinServiceHistoryId and @MaxServiceHistoryId
		  AND MEP.StartDateKey between @MinServiceDateKeyPruning and @MaxServiceDateKey
	OPTION(RECOMPILE);



if @DebugDMLTiming = 1
BEGIN
	set @DebugEndDate = GETUTCDATE();
	set @DebugTimingMessage = 'Step ' + cast(@DebugStep as varchar) +' took ' + cast(datediff(ss,@DebugStartDate,@DebugEndDate) as varchar) + ' Seconds to execute.'
	RAISERROR ( @DebugTimingMessage, 0, 1) WITH NOWAIT

	set @DebugStartDate = GETUTCDATE();
	set @DebugEndDate = null;
	set @DebugStep =  3;
	set @DebugTimingMessage = null;
END
	
/*		
		--Top most materials and Inner Materials can have children tracked in during its trackin/trackout interval. 
		-- We're marking those so the parents can be excluded, so quantities are not duplicated.
		update T
		   set HasChildren = 1
		  from #tmp_semioperations T WITH(TABLOCK)
		  cross apply (select top 1 ResourceKey, MaterialKey, ParentMaterialKey, TrackInOperationTime, TrackOutOperationTime
		                 from #tmp_semioperations c
					    where c.MaterialHierarchyKey > T.MaterialHierarchykey
						  and c.ParentMaterialKey = T.MaterialKey
						  and c.ResourceKey = T.ResourceKey 
						  and c.TrackInOperationTime between T.TrackInOperationTime and T.TrackOutOperationTime
					  ) child 
		 where T.MaterialHierarchykey <> 3;
*/		  	
if @DebugDMLTiming = 1
BEGIN
	set @DebugEndDate = GETUTCDATE();
	set @DebugTimingMessage = 'Step ' + cast(@DebugStep as varchar) +' took ' + cast(datediff(ss,@DebugStartDate,@DebugEndDate) as varchar) + ' Seconds to execute.'
	RAISERROR ( @DebugTimingMessage, 0, 1) WITH NOWAIT

	set @DebugStartDate = GETUTCDATE();
	set @DebugEndDate = null;
	set @DebugStep = 4;
	set @DebugTimingMessage = null;
END

	
	IF OBJECT_ID('tempdb..#tmp_ResourceTransitions') IS NOT NULL
		   DROP TABLE #tmp_ResourceTransitions

	CREATE TABLE #tmp_ResourceTransitions
	(
		AreaKey bigint,
		ResourceKey bigint,
		ShiftDateKey int,
		DateKey int,
		LC1DateKey int,
		ShiftKey bigint,
		[SEMI-E10] nvarchar(256) COLLATE DATABASE_DEFAULT,
		UTCOperationEndTime datetime,
		UTCNextOperationEndTime DATETIME,
		UNIQUE CLUSTERED (areakey, resourcekey, UTCOperationEndTime, UTCNextOperationEndTime, ShiftDateKey, DateKey, LC1DateKey, ShiftKey, [SEMI-E10] )
    );

	/*In this step, we break Trackin/Trackout and split/trackout periods into smaller parcels in time.
	  This is done, to assure that every parcel will fit a shift definition, and that only periods of SEMI-E10 = Production are considered.
	  A factor is calculated based on the following formula ( [Parcel Period] * 1 /  [total time of paired operations] ).
	  Factor is used to adjust quantities of parcels.
	*/
	
	insert into #tmp_ResourceTransitions WITH(TABLOCK)(	AreaKey,
											ResourceKey,
											ShiftDateKey,
											DateKey,
											LC1DateKey,
											ShiftKey,
											[SEMI-E10],
											UTCOperationEndTime,
											UTCNextOperationEndTime)
	(
		select  AreaKey, ResourceKey, 
			ISNULL(lag(dat.LeadShiftDateKey) over (partition by IsTransition, ResourceKey order by rnum), dat.FirstShiftDateKey) as ShiftDateKey,
			ISNULL(lag(dat.LeadDateKey) over (partition by IsTransition, ResourceKey order by rnum), dat.FirstDateKey) as DateKey,
			ISNULL(lag(dat.LeadLC1DateKey) over (partition by IsTransition, ResourceKey order by rnum), dat.FirstLC1DateKey) as LC1DateKey,
			ISNULL(lag(dat.LeadShiftKey) over (partition by IsTransition, ResourceKey order by rnum), dat.FirstShiftKey) as ShiftKey,
			ISNULL(lag(dat.[LeadSEMI-E10]) over (partition by IsTransition, ResourceKey order by rnum), dat.[FirstSEMI-E10]) as [SEMI-E10],
			ISNULL(lag(dat.[UTCNextOperationEndTime]) over (partition by IsTransition, ResourceKey order by rnum), dat.FirstUTCOperationEndTime) as UTCOperationEndTime,
			[UTCNextOperationEndTime]
	     from (	select datII.*, 
		               CASE WHEN LeadShiftDateKey <> ShiftDateKey 
									OR  LeadLC1DateKey <> LC1DateKey
									OR  LeadShiftKey <> ShiftKey
									OR  [LeadSEMI-E10] <> [SEMI-E10]
									OR  [LeadLC1DateKey] IS NULL
									OR RNUM = 1 THEN 1 
							ELSE 0 
						END IsTransition
				
				from (select datI.*, 
							LEAD(ShiftDateKey) over (partition by ResourceKey order by rnum) LeadShiftDateKey,
							LEAD(LC1DateKey) over (partition by ResourceKey order by rnum) LeadLC1DateKey,
							LEAD(DateKey) over (partition by ResourceKey order by rnum) LeadDateKey,
							LEAD(ShiftKey) over (partition by ResourceKey order by rnum) LeadShiftKey,
							LEAD(UTCOperationEndTime) over (partition by ResourceKey order by rnum) LeadUTCOperationEndTime,
							LEAD([SEMI-E10]) over (partition by ResourceKey order by rnum) [LeadSEMI-E10]
						from (select AreaKey, f.ResourceKey, DateKey, LC1DateKey, ShiftDateKey, ShiftKey, UTCOperationEndTime, UTCNextOperationEndTime, [SEMI-E10], ServiceHIstoryID, OPerationHistorySeq, SubOperationSequence,
									row_number() over (partition by ResourceKey order by UTCOperationEndTime, ShiftDateKey, ShiftKey, servicehistoryid, operationhistoryseq, suboperationsequence) as rnum,
									FIRST_VALUE(DateKey) over  (partition by ResourceKey order by UTCOperationEndTime, ShiftDateKey, ShiftKey, servicehistoryid, operationhistoryseq, suboperationsequence) as FirstDateKey,
									FIRST_VALUE(LC1DateKey) over  (partition by ResourceKey order by UTCOperationEndTime, ShiftDateKey, ShiftKey, servicehistoryid, operationhistoryseq, suboperationsequence) as FirstLC1DateKey,
									FIRST_VALUE(ShiftDateKey) over  (partition by ResourceKey order by UTCOperationEndTime, ShiftDateKey, ShiftKey, servicehistoryid, operationhistoryseq, suboperationsequence) as FirstShiftDateKey,
									FIRST_VALUE(ShiftKey) over  (partition by ResourceKey order by UTCOperationEndTime, ShiftDateKey, ShiftKey, servicehistoryid, operationhistoryseq, suboperationsequence) as FirstShiftKey,
									FIRST_VALUE(UTCOperationEndTime) over  (partition by ResourceKey order by UTCOperationEndTime, ShiftDateKey, ShiftKey, servicehistoryid, operationhistoryseq, suboperationsequence) as FirstUTCOperationEndTime,
									FIRST_VALUE([SEMI-E10]) over  (partition by ResourceKey order by UTCOperationEndTime, ShiftDateKey, ShiftKey, servicehistoryid, operationhistoryseq, suboperationsequence) as [FirstSEMI-E10]
								from (select AreaKey as InnerAreaKey, ResourceKey as InnerResourceKey, 
								             CAST(CONVERT(char(8),(min(TrackInOperationTime)),112) AS INT) as minDateKey, 
											 CAST(CONVERT(char(8),(max(TrackOutOperationTime)),112) AS INT) as maxDateKey
										from #tmp_semioperations
									   group by AreaKey, ResourceKey
									 ) R 
								cross apply ( select f.* 
								                from FactResourceServiceTime f
											   where R.InnerResourceKey = f.ResourceKey and f.AreaKey = r.InnerAreaKey and f.DateKey between r.minDateKey and r.maxDateKey
												 and UTCOperationEndTime <> UTCNextOperationEndTime	  
											) f
					  
							) datI 
					) datII
			) dat
			where dat.IsTransition = 1
	)
	OPTION(RECOMPILE);
	
	

if @DebugDMLTiming = 1
BEGIN
	set @DebugEndDate = GETUTCDATE();
	set @DebugTimingMessage = 'Step ' + cast(@DebugStep as varchar) +' took ' + cast(datediff(ss,@DebugStartDate,@DebugEndDate) as varchar) + ' Seconds to execute.'
	RAISERROR ( @DebugTimingMessage, 0, 1) WITH NOWAIT

	set @DebugStartDate = GETUTCDATE();
	set @DebugEndDate = null;
	set @DebugStep = 5;
	set @DebugTimingMessage = null;
END

	
	


	IF OBJECT_ID('tempdb..#tmp_operations') IS NOT NULL
		   DROP TABLE #tmp_operations


	CREATE TABLE #tmp_operations
	(
		[DateKey] [int] NULL,
		[LC1DateKey] [int] NULL,
		[AreaKey] [bigint] NULL,
		[StepKey] bigint,
		[ProductKey] bigint,
		[FlowKey] bigint,
		[AreaId] [bigint] NULL,
		[ShiftKey] [bigint] NULL,
		[ShiftDateKey] [int] NULL,
		[ResourceKey] [bigint] NULL,
		[ResourceId] [bigint] NULL,
		[ParentResourceKey] [bigint] NULL,
		[MaterialKey] [bigint] NULL,
		[MaterialId] [bigint] NULL,
		[TrackInOperationTime] [datetime] NULL,
		[LC1TrackInOperationTime] [datetime] NULL,
		[TrackInServiceHistoryId] [bigint] NULL,
		[TrackInOperationhistorySeq] [bigint] NULL,
		[TrackInSubOperationSequence] [int] NULL,
		[TrackOutOperationTime] [datetime] NULL,
		[LC1TrackOutOperationTime] [datetime] NULL,
		[TrackOutServiceHistoryId] [bigint] NULL,
		[TrackOutOperationhistorySeq] [bigint] NULL,
		[TrackOutSubOperationSequence] [int] NULL,
		[SubMaterialCount] [int] NULL,
		[MaterialHierarchykey] [int] NULL,
		[HasChildren] [bit] NULL,
		[IdealCycleTime] [decimal](18, 8) NULL,
		[IdealBaseCycleTime] [decimal](18, 8) NULL,
		[ParentIdealCycleTime] [decimal](18, 8) NULL,
		[ParentIdealBaseCycleTime] [decimal](18, 8) NULL,
		[PrimaryUnitKey] [bigint] NULL,
		[SecondaryUnitKey] [bigint] NULL,
		[ParcelInOperationTime] [datetime] NULL,
		[ParcelOutOperationTime] [datetime] NULL,
		[LC1ParcelInOperationTime] [datetime] NULL,
		[LC1ParcelOutOperationTime] [datetime] NULL,
		[ParcelSeconds] [decimal](38, 15) NULL,
		[TotalSeconds] [decimal](38, 15) NULL,
		[status] [nvarchar](256) NULL,
		[StartPrimaryQuantity] [decimal](38, 15) NULL,
		[StartSubMaterialsPrimaryQuantity] [decimal](38, 15) NULL,
		[StartSecondaryQuantity] [decimal](38, 15) NULL,
		[StartSubMaterialsSecondaryQuantity] [decimal](38, 15) NULL,
		[EndPrimaryQuantity] [decimal](38, 15) NULL,
		[EndSubMaterialsPrimaryQuantity] [decimal](38, 15) NULL,
		[EndSecondaryQuantity] [decimal](38, 15) NULL,
		[EndSubMaterialsSecondaryQuantity] [decimal](38, 15) NULL,
		[ParcelQtyFactorApplied] [decimal](38, 15) NULL,
		[ParcelInPrimaryQuantity] [decimal](38, 15) NULL,
		[ParcelInSubMaterialsPrimaryQuantity] [decimal](38, 15) NULL,
		[ParcelInSecondaryQuantity] [decimal](38, 15) NULL,
		[ParcelInSubMaterialsSecondaryQuantity] [decimal](38, 15) NULL,
		[ParcelOutPrimaryQuantity] [decimal](38, 15) NULL,
		[ParcelOutSubMaterialsPrimaryQuantity] [decimal](38, 15) NULL,
		[ParcelOutSecondaryQuantity] [decimal](38, 15) NULL,
		[ParcelOutSubMaterialsSecondaryQuantity] [decimal](38, 15) NULL,
		[ParcelInFactorizedQuantity] [decimal](38, 15) NULL,
		[ParcelOutFactorizedQuantity] [decimal](38, 15) NULL,
		UNIQUE CLUSTERED ([MaterialKey], TrackInServiceHistoryId, TrackInOperationhistorySeq, [ParcelInOperationTime], [ResourceKey], [AreaKey])
	);


	
	insert into #tmp_operations WITH(TABLOCK)
	(
		[DateKey],
		[LC1DateKey],
		[AreaKey] , StepKey, ProductKey, FlowKey,
		[AreaId] ,
		[ShiftKey] ,
		[ShiftDateKey] ,
		[ResourceKey] ,
		[ResourceId] ,
		[ParentResourceKey] ,
		[MaterialKey] ,
		[MaterialId] ,
		[TrackInOperationTime] ,
		[LC1TrackInOperationTime] ,
		[TrackInServiceHistoryId] ,
		[TrackInOperationhistorySeq] ,
		[TrackInSubOperationSequence] ,
		[TrackOutOperationTime] ,
		[LC1TrackOutOperationTime] ,
		[TrackOutServiceHistoryId] ,
		[TrackOutOperationhistorySeq] ,
		[TrackOutSubOperationSequence] ,
		[SubMaterialCount] ,
		[MaterialHierarchykey] ,
		[HasChildren] ,
		[IdealCycleTime] ,
		[IdealBaseCycleTime] ,
		[ParentIdealCycleTime] ,
		[ParentIdealBaseCycleTime] ,
		[PrimaryUnitKey] ,
		[SecondaryUnitKey] ,
		[ParcelInOperationTime] ,
		[ParcelOutOperationTime] ,
		[LC1ParcelInOperationTime] ,
		[LC1ParcelOutOperationTime] ,
		[ParcelSeconds] ,
		[TotalSeconds] ,
		[status] ,
		[StartPrimaryQuantity] ,
		[StartSubMaterialsPrimaryQuantity] ,
		[StartSecondaryQuantity] ,
		[StartSubMaterialsSecondaryQuantity] ,
		[EndPrimaryQuantity] ,
		[EndSubMaterialsPrimaryQuantity] ,
		[EndSecondaryQuantity] ,
		[EndSubMaterialsSecondaryQuantity] ,
		[ParcelQtyFactorApplied] ,
		[ParcelInPrimaryQuantity],
		[ParcelInSubMaterialsPrimaryQuantity] ,
		[ParcelInSecondaryQuantity] ,
		[ParcelInSubMaterialsSecondaryQuantity] ,
		[ParcelOutPrimaryQuantity] ,
		[ParcelOutSubMaterialsPrimaryQuantity] ,
		[ParcelOutSecondaryQuantity] ,
		[ParcelOutSubMaterialsSecondaryQuantity],
		[ParcelInFactorizedQuantity] ,
		[ParcelOutFactorizedQuantity] 
	)
	select  CAST(CONVERT(char(8),final.ParcelInOperationTime,112) AS INT) as [DateKey] ,
			CAST(CONVERT(char(8),final.LC1ParcelInOperationTime,112) AS INT) as [LC1DateKey] ,
			final.[AreaKey] , final.StepKey, final.ProductKey, final.FlowKey,
			final.[AreaId] ,
			final.[ShiftKey] ,
			final.[ShiftDateKey] ,
			final.[ResourceKey] ,
			final.[ResourceId] ,
			final.[ParentResourceKey] ,
			final.[MaterialKey] ,
			final.[MaterialId] ,
			final.[TrackInOperationTime] ,
			final.[LC1TrackInOperationTime],
			final.[TrackInServiceHistoryId] ,
			final.[TrackInOperationhistorySeq] ,
			final.[TrackInSubOperationSequence] ,
			final.[TrackOutOperationTime] ,
			final.[LC1TrackOutOperationTime],
			final.[TrackOutServiceHistoryId] ,
			final.[TrackOutOperationhistorySeq] ,
			final.[TrackOutSubOperationSequence] ,
			final.[SubMaterialCount] ,
			final.[MaterialHierarchykey] ,
			final.[HasChildren] ,
			final.[IdealCycleTime] ,
			final.[IdealBaseCycleTime] ,
			final.[ParentIdealCycleTime] ,
			final.[ParentIdealBaseCycleTime] ,
			final.[PrimaryUnitKey] ,
			final.[SecondaryUnitKey] ,
			final.[ParcelInOperationTime] ,
			final.[ParcelOutOperationTime] ,
			final.[LC1ParcelInOperationTime],
			final.[LC1ParcelOutOperationTime],
			final.[ParcelSeconds] ,
			final.[TotalSeconds] ,
			final.[status] ,
			final.[StartPrimaryQuantity] ,
			final.[StartSubMaterialsPrimaryQuantity] ,
			final.[StartSecondaryQuantity] ,
			final.[StartSubMaterialsSecondaryQuantity] ,
			final.[EndPrimaryQuantity] ,
			final.[EndSubMaterialsPrimaryQuantity] ,
			final.[EndSecondaryQuantity] ,
			final.[EndSubMaterialsSecondaryQuantity] ,
			final.[ParcelQtyFactorApplied] , 

			final.[ParcelInPrimaryQuantity],
			final.[ParcelInSubMaterialsPrimaryQuantity] ,
			final.[ParcelInSecondaryQuantity] ,
			final.[ParcelInSubMaterialsSecondaryQuantity] ,
			
			final.[ParcelOutPrimaryQuantity],
			final.[ParcelOutSubMaterialsPrimaryQuantity] ,
			final.[ParcelOutSecondaryQuantity] ,
			final.[ParcelOutSubMaterialsSecondaryQuantity],
		   
			final.ParcelInFactorizedQuantity,
			final.ParcelOutFactorizedQuantity
	  from (select  norm.[AreaKey] , norm.StepKey, norm.ProductKey, norm.FlowKey,
					norm.[AreaId] ,
					norm.[ShiftKey] ,
					norm.[ShiftDateKey] ,
					norm.[ResourceKey] ,
					norm.[ResourceId] ,
					norm.[ParentResourceKey] ,
					norm.[MaterialKey] ,
					norm.[MaterialId] ,
					norm.[TrackInOperationTime] ,
					CASE WHEN norm.UTCToLC1OffSetMin IS NULL
							THEN [DateTimeUtil].[UDF_ConvertUtcToLocalByTimezoneId](norm.TimeZoneKey, norm.[TrackInOperationTime])
							ELSE DATEADD(MI, norm.UTCToLC1OffSetMin, norm.[TrackInOperationTime])
						END AS [LC1TrackInOperationTime],
					norm.[TrackInServiceHistoryId] ,
					norm.[TrackInOperationhistorySeq] ,
					norm.[TrackInSubOperationSequence] ,
					norm.[TrackOutOperationTime] ,
					CASE WHEN norm.UTCToLC1OffSetMin IS NULL
							THEN [DateTimeUtil].[UDF_ConvertUtcToLocalByTimezoneId](norm.TimeZoneKey, norm.[TrackOutOperationTime])
							ELSE DATEADD(MI, norm.UTCToLC1OffSetMin, norm.[TrackOutOperationTime])
						END AS [LC1TrackOutOperationTime],
					norm.[TrackOutServiceHistoryId] ,
					norm.[TrackOutOperationhistorySeq] ,
					norm.[TrackOutSubOperationSequence] ,
					norm.[SubMaterialCount] ,
					norm.[MaterialHierarchykey] ,
					norm.[HasChildren] ,
					norm.[IdealCycleTime] ,
					norm.[IdealBaseCycleTime] ,
					norm.[ParentIdealCycleTime] ,
					norm.[ParentIdealBaseCycleTime] ,
					norm.[PrimaryUnitKey] ,
					norm.[SecondaryUnitKey] ,
					norm.[ParcelInOperationTime] ,
					norm.[ParcelOutOperationTime] ,
					case when norm.UTCToLC1OffSetMin IS NULL
							THEN [DateTimeUtil].[UDF_ConvertUtcToLocalByTimezoneId](norm.TimeZoneKey, norm.[ParcelInOperationTime])
							ELSE DATEADD(MI, norm.UTCToLC1OffSetMin, norm.[ParcelInOperationTime])
						END as [LC1ParcelInOperationTime],
					case WHEN norm.UTCToLC1OffSetMin IS NULL
							THEN [DateTimeUtil].[UDF_ConvertUtcToLocalByTimezoneId](norm.TimeZoneKey, norm.[ParcelOutOperationTime])
							ELSE DATEADD(MI, norm.UTCToLC1OffSetMin, norm.[ParcelOutOperationTime])
						END AS [LC1ParcelOutOperationTime],
					norm.[ParcelSeconds] ,
					norm.[TotalSeconds] ,
					norm.[status] ,
					norm.[StartPrimaryQuantity] ,
					norm.[StartSubMaterialsPrimaryQuantity] ,
					norm.[StartSecondaryQuantity] ,
					norm.[StartSubMaterialsSecondaryQuantity] ,
					norm.[EndPrimaryQuantity] ,
					norm.[EndSubMaterialsPrimaryQuantity] ,
					norm.[EndSecondaryQuantity] ,
					norm.[EndSubMaterialsSecondaryQuantity] ,
					norm.[ParcelQtyFactorApplied] , 

					norm.[StartPrimaryQuantity] * norm.[ParcelQtyFactorApplied] as [ParcelInPrimaryQuantity],
					norm.[StartSubMaterialsPrimaryQuantity] * norm.[ParcelQtyFactorApplied] as [ParcelInSubMaterialsPrimaryQuantity] ,
					norm.[StartSecondaryQuantity] as [ParcelInSecondaryQuantity] ,
					norm.[StartSubMaterialsSecondaryQuantity] as [ParcelInSubMaterialsSecondaryQuantity] ,
			
					norm.[EndPrimaryQuantity] * norm.[ParcelQtyFactorApplied] as [ParcelOutPrimaryQuantity],
					norm.[EndSubMaterialsPrimaryQuantity] * norm.[ParcelQtyFactorApplied] as [ParcelOutSubMaterialsPrimaryQuantity] ,
					norm.[EndSecondaryQuantity] as [ParcelOutSecondaryQuantity] ,
					norm.[EndSubMaterialsSecondaryQuantity] as [ParcelOutSubMaterialsSecondaryQuantity],
		   
				   (norm.StartPrimaryQuantity + norm.StartSubMaterialsPrimaryQuantity) * norm.[ParcelQtyFactorApplied] as ParcelInFactorizedQuantity,
				   (norm.EndPrimaryQuantity + norm.EndSubMaterialsPrimaryQuantity) * norm.[ParcelQtyFactorApplied] as ParcelOutFactorizedQuantity

			  from (select fact.*, cast(ParcelSeconds  as decimal(38,15)) * cast(1.0  as decimal(38,15)) / cast(TotalSeconds  as decimal(38,15)) as [ParcelQtyFactorApplied]
					  from (select evt.AreaKey, evt.StepKey, evt.ProductKey, evt.FlowKey, evt.AreaId, evt.ShiftKey, evt.ShiftDateKey, evt.ResourceKey, evt.ResourceId, evt.ParentResourceKey, evt.MaterialKey, evt.MaterialId
									,evt.TrackInOperationTime, evt.TrackInServiceHistoryId, evt.TrackInOperationhistorySeq, evt.TrackInSubOperationSequence
									,evt.TrackOutOperationTime, evt.TrackOutServiceHistoryId, evt.TrackOutOperationhistorySeq, evt.TrackOutSubOperationSequence
									,evt.SubMaterialCount, evt.MaterialHierarchykey
									,evt.HasChildren
									,evt.IdealCycleTime
									,evt.IdealBaseCycleTime
									,evt.ParentIdealCycleTime
									,evt.ParentIdealBaseCycleTime
									,evt.PrimaryUnitKey
									,evt.SecondaryUnitKey
									,evt.ParcelInOperationTime
									,evt.ParcelOutOperationTime
									,case when datediff(day, ParcelInOperationTime, ParcelOutOperationTime) > 1   then  datediff(ss, ParcelInOperationTime, ParcelOutOperationTime)
											else cast(datediff(ms, ParcelInOperationTime, ParcelOutOperationTime) as decimal(38,15) )/1000.0
										end as ParcelSeconds 
									,case when datediff(day, evt.TrackInOperationTime, evt.TrackOutOperationTime) > 1   then  datediff(ss, evt.TrackInOperationTime, evt.TrackOutOperationTime)
											else cast(datediff(ms, evt.TrackInOperationTime, evt.TrackOutOperationTime) as decimal(38,15) )/1000.0
										end as TotalSeconds 
									,evt.status
									,evt.StartPrimaryQuantity
									,evt.StartSubMaterialsPrimaryQuantity
									,evt.StartSecondaryQuantity
									,evt.StartSubMaterialsSecondaryQuantity
									,evt.EndPrimaryQuantity
									,evt.EndSubMaterialsPrimaryQuantity
									,evt.EndSecondaryQuantity
									,evt.EndSubMaterialsSecondaryQuantity
									,evt.TimeZoneKey, evt.UTCToLC1OffSetMin
									,ROW_NUMBER() over(partition by [ParcelInOperationTime], [ResourceKey], [MaterialKey], [AreaKey], [TrackOutServiceHistoryId] order by [ShiftDateKey], [Status]) as rnum
								from (select trc.*, a.ShiftDateKey, a.ShiftKey
											,replace(a.[SEMI-E10] ,' ', '') as status
											 -- if parcel start time is before trackin, or time difference smaller than 2s then use trackin date to avoid issues on parcel factorization which lose units
											,case   when datediff(ss, trc.TrackInOperationTime, a.UTCOperationEndTime) > 2
													  then a.UTCOperationEndTime
												    when isNUll(a.UTCOperationEndTime,trc.TrackInOperationTime) <= trc.TrackInOperationTime 
														OR a.UTCOperationEndTime > trc.TrackInOperationTime AND datediff(ms, trc.TrackInOperationTime, a.UTCOperationEndTime) between 0 and 2000
												      then trc.TrackInOperationTime 
												else a.UTCOperationEndTime end as ParcelInOperationTime
											-- if parcel end time is before trackout, or time difference smaller than 2s then use trackin date to avoid issues on parcel factorization which lose units
											,case   when datediff(SS, a.UTCNextOperationEndTime, trc.TrackOutOperationTime) > 2
													  then a.UTCNextOperationEndTime
												    when isNUll(a.UTCNextOperationEndTime,trc.TrackOutOperationTime) >= trc.TrackOutOperationTime 
														OR a.UTCNextOperationEndTime < trc.TrackOutOperationTime AND datediff(ms, a.UTCNextOperationEndTime, trc.TrackOutOperationTime) between 0 and 2000
													then trc.TrackOutOperationTime 
												else a.UTCNextOperationEndTime end as ParcelOutOperationTime												
					   
										from #tmp_semioperations as trc
										inner merge join #tmp_ResourceTransitions a on (a.areakey = trc.areakey and a.ResourceKey = trc.ResourceKey
																						and a.UTCOperationEndTime <> a.UTCNextOperationEndTime
																						and (  (trc.TrackInOperationTime >= a.UTCOperationEndTime  and trc.TrackInOperationTime < a.UTCNextOperationEndTime)
																							or (trc.TrackOutOperationTime >= a.UTCOperationEndTime  and trc.TrackOutOperationTime < a.UTCNextOperationEndTime)
																							or (trc.TrackInOperationTime < a.UTCOperationEndTime  and trc.TrackOutOperationTime >= a.UTCNextOperationEndTime)
																							or (trc.TrackInOperationTime <= a.UTCOperationEndTime  and trc.TrackOutOperationTime > a.UTCNextOperationEndTime)
																							)
																						-- Decided that all states should be equally considered to split material by parcel
																						-- and  a.[SEMI-E10] IN ('Productive', 'Engineering')
																						and [SEMI-E10] is not null
																					   ) 
										
									) as evt
								-- removes intervals with less than 2s to not count these on quantity parcel factorization unless since trackin till trackout it also took less than 2s							    
								-- NOTE: If a resource is idle on the standby state and a material is trackedin the resource state changes to Productive
								--      however there are a few ms difference between the material TrackInOperationTime and the productive start time of the resource state 
								--		and to not lose units on OEE calculation the system forces the TrackInOperationTime to be used instead of the resource state start time but then has to exclude 
								--		the rows which also match the "standby" occurrence since if we look at the data stored in factresourceservicetime the trackin effectively started while the resource was still on standby 
								where 
								case when datediff(SS, evt.ParcelInOperationTime, evt.ParcelOutOperationTime) > 2 
											OR datediff(SS, evt.ParcelInOperationTime, evt.ParcelOutOperationTime) <= 2 and datediff(SS, evt.TrackInOperationTime, evt.TrackOutOperationTime) <= 2 then
									3000
									WHEN datediff(SS, evt.ParcelInOperationTime, evt.ParcelOutOperationTime) between 0 and 2 THEN
										datediff(MS, evt.ParcelInOperationTime, evt.ParcelOutOperationTime)
									ELSE NULL
								END > 2000
						) fact
					-- excludes those small intervals which fit into 2 transitions with same parcel trackin and trackout dates
					where rnum = 1
				) norm
		)final
	OPTION(RECOMPILE);




if @DebugDMLTiming = 1
BEGIN
	set @DebugEndDate = GETUTCDATE();
	set @DebugTimingMessage = 'Step ' + cast(@DebugStep as varchar) +' took ' + cast(datediff(ss,@DebugStartDate,@DebugEndDate) as varchar) + ' Seconds to execute.'
	RAISERROR ( @DebugTimingMessage, 0, 1) WITH NOWAIT

	set @DebugStartDate = GETUTCDATE();
	set @DebugEndDate = null;
	set @DebugStep = 6;
	set @DebugTimingMessage = null;
END


		INSERT into [dbo].[FactMaterialProcessTime] WITH(TABLOCK)
		        ([DateKey]
				,[TimeKey]
				,[ShiftDateKey]
				,[ShiftKey]
				,[ResourceKey]
				,[ParentResourceKey]
				,[MaterialKey]
				,[MaterialHierarchyKey]
				,[AreaKey]
				,[ProductKey]
				,[FlowKey]
				,[StepKey]
				,[PrimaryUnitKey]
				,[SecondaryUnitKey]
				,[SubMaterialCount]
				,[IdealCycleTime]
				,[IdealBaseCycleTime]
				,[ParentIdealCycleTime]
				,[ParentIdealBaseCycleTime]
				,[UTCParcelStartDateTime]
				,[UTCParcelEndDateTime]
				,[UTCTrackInDateTime]
				,[UTCTrackOutDateTime]
				,[ParcelQtyFactorApplied]
				,[LC1DateKey]
				,[LC1TimeKey]
				,[LC1ParcelStartDateTime]
				,[LC1ParcelEndDateTime]
				,[LC1TrackInDateTime]
				,[LC1TrackOutDateTime]
				,[ServiceHistoryId]
				,[OperationHistorySeq]
				,[ParcelInPrimaryQuantity]
				,[ParcelInSubMaterialsPrimaryQuantity]
				,[ParcelInSecondaryQuantity]
				,[ParcelInSubMaterialsSecondaryQuantity]
				,[ParcelOutPrimaryQuantity]
				,[ParcelOutSubMaterialsPrimaryQuantity]
				,[ParcelOutSecondaryQuantity]
				,[ParcelOutSubMaterialsSecondaryQuantity]
				,[HasChildren]
				,[SEMI-E10]
				,[TrackOutServiceHistoryId]
				,[ParcelInTotalQuantityNormalized]
				,[ParcelOutTotalQuantityNormalized]
				,[ParcelInPrimaryQuantityNormalized]
				,[ParcelOutPrimaryQuantityNormalized]
			  )
		select	 CAST(CONVERT(char(8),op.[ParcelInOperationTime],112) AS INT) as [DateKey]
				,DATEPART(HH, op.[ParcelInOperationTime])*(10000)+DATEPART(MI, op.[ParcelInOperationTime])*(100)+DATEPART(SS, op.[ParcelInOperationTime]) as [TimeKey]
				,op.[ShiftDateKey]
				,op.[ShiftKey]
				,op.[ResourceKey]
				,op.[ParentResourceKey]
				,op.[MaterialKey]
				,op.[MaterialHierarchyKey]	
				,op.[AreaKey]
				,op.[ProductKey]
				,op.[FlowKey]
				,op.[StepKey]
				,op.[PrimaryUnitKey]
				,op.[SecondaryUnitKey]
				,op.[SubMaterialCount]
				,op.[IdealCycleTime]
				,op.[IdealBaseCycleTime]
				,op.[ParentIdealCycleTime]
				,op.[ParentIdealBaseCycleTime]
				,op.[ParcelInOperationTime] as [UTCParcelStartDateTime]
				,op.[ParcelOutOperationTime] as [UTCParcelEndDateTime]
				,op.[TrackInOperationTime] as [UTCTrackInDateTime]
				,op.[TrackOutOperationTime] as [UTCTrackOutDateTime]
				,op.[ParcelQtyFactorApplied]
				,CAST(CONVERT(char(8),op.[LC1ParcelInOperationTime],112) AS INT) as [LC1DateKey]
				,DATEPART(HH, op.[LC1ParcelInOperationTime])*(10000)+DATEPART(MI, op.[LC1ParcelInOperationTime])*(100)+DATEPART(SS, op.[LC1ParcelInOperationTime]) as [LC1TimeKey]
				,op.LC1ParcelInOperationTime as [LC1ParcelStartDateTime]
				,op.LC1ParcelOutOperationTime as [LC1ParcelEndDateTime]
				,op.[LC1TrackInOperationTime] as [LC1TrackInDateTime]
				,op.[LC1TrackOutOperationTime] as [LC1TrackOutDateTime]
				,op.TrackInServiceHistoryId as [ServiceHistoryId]
				,op.TrackInOperationHistorySeq as [OperationHistorySeq]
				,op.[ParcelInPrimaryQuantity] as [ParcelInPrimaryQuantity]
				,op.[ParcelInSubMaterialsPrimaryQuantity]
				,op.[ParcelInSecondaryQuantity]
				,op.[ParcelInSubMaterialsSecondaryQuantity]
				,op.[ParcelOutPrimaryQuantity]
				,op.[ParcelOutSubMaterialsPrimaryQuantity]
				,op.[ParcelOutSecondaryQuantity]
				,op.[ParcelOutSubMaterialsSecondaryQuantity]
				,op.[HasChildren]
				,op.status as [SEMI-E10]
				,op.[TrackOutServiceHistoryId]
				,NULL as [ParcelInTotalQuantityNormalized]
				,NULL as [ParcelOutTotalQuantityNormalized]
				,NULL as [ParcelInPrimaryQuantityNormalized]
				,NULL as [ParcelOutPrimaryQuantityNormalized]
			from #tmp_operations op			
		OPTION(RECOMPILE);

		
		set @StatusMessage = OBJECT_NAME(@@PROCID) + ': ' + cast(@@ROWCOUNT as varchar) + ' row(s) inserted into '+@TABLENAME;
		
		RAISERROR (@StatusMessage, 0, 1) WITH NOWAIT


if @DebugDMLTiming = 1
BEGIN
	set @DebugEndDate = GETUTCDATE();
	set @DebugTimingMessage = 'Step ' + cast(@DebugStep as varchar) +' took ' + cast(datediff(ss,@DebugStartDate,@DebugEndDate) as varchar) + ' Seconds to execute.'
	RAISERROR ( @DebugTimingMessage, 0, 1) WITH NOWAIT

	set @DebugStartDate = GETUTCDATE();
	set @DebugEndDate = null;
	set @DebugStep = 7;
	set @DebugTimingMessage = null;
END

		-- following table is to optimize the call to the UDF function F_ResolveResourceIdealCycleTime
		IF object_id('tempdb..#IdealBaseCycleTime') IS NOT NULL
			DROP TABLE #IdealBaseCycleTime

		CREATE TABLE #IdealBaseCycleTime (
			ResourceKey BIGINT
			,IdealBaseCycleTime DECIMAL(18, 8) UNIQUE CLUSTERED (ResourceKey),
			);

		-- Storing the ideal cycle time based quantities.
		-- Notice that multiple products, hence different ideal cycle times may exist in period, and that's why we're factoring the quantities to one product spec, to match
		-- the quantities unit stored on the FactMaterialProcessTime table.
		;WITH DateShiftsToProcess AS 
		(
			select ResourceKey
				from FactResourceServiceTime RST
				where datekey between @MinServiceDateKey and @MaxServiceDateKey 
				   and isnull(@ResourceKey, ResourceKey) = ResourceKey 
				group by ResourceKey
		)
		insert into #IdealBaseCycleTime WITH(TABLOCK) (ResourceKey, IdealBaseCycleTime)
		SELECT  R1.ResourceKey
			  , dbo.F_ResolveResourceIdealCycleTime(R.ResourceName, NULL, NULL, NULL, R.ResourceType, R.Model, 1 /* IsReference = true */) AS IdealBaseCycleTime
		FROM DateShiftsToProcess R1
		INNER JOIN DimResource R 
			ON (R.ResourceKey = R1.ResourceKey)

		;WITH DateShiftsToProcess AS 
		(
			select AreaKey, ResourceKey, LC1DateKey, ShiftKey, DateKey, ShiftDateKey, 
				sum(case when RST.[SEMI-E10] IN ('Productive', 'Engineering')
										then DATEDIFF(ss, RST.UTCOperationEndTime, RST.UTCNextOperationEndTime) 
										else 0
									end
								) ProductiveTime
				from FactResourceServiceTime RST
				where datekey between @MinServiceDateKey and @MaxServiceDateKey 
				   and isnull(@ResourceKey, ResourceKey) = ResourceKey 
				-- all states should be included, even though this could lead to processed quantities on shifts where the resource was non productive
				-- and [SEMI-E10] IN ('Productive', 'Engineering')
				group by AreaKey, ResourceKey, LC1DateKey, ShiftKey, DateKey, ShiftDateKey
		)
		,currFactResourceIdealQuantity as (
			select frs.* from [dbo].[FactResourceIdealQuantity] frs WITH(TABLOCK)
			inner join (select ResourceKey, min(datekey) as minDateKey, max(dateKey) as maxDateKey from DateShiftsToProcess group by ResourceKey ) Resourcedates
			on ( Resourcedates.ResourceKey = frs.ResourceKey and frs.DateKey between Resourcedates.minDateKey and Resourcedates.maxDateKey)
			where datekey between @MinServiceDateKey and @MaxServiceDateKey 
				   and isnull(@ResourceKey, frs.ResourceKey) = frs.ResourceKey
		)
		merge into currFactResourceIdealQuantity as T
		using (	
			select FRS.AreaKey, FRS.ResourceKey, FRS.DateKey, FRS.ShiftDateKey, FRS.LC1DateKey, FRS.ShiftKey, 
					Ideal.IdealBaseCycleTime, null as RealScheduledTime, CASE WHEN ISNULL(Ideal.IdealBaseCycleTime, 0) = 0 THEN NULL 
																			ELSE ISNULL(FRS.ProductiveTime, 0) / Ideal.IdealBaseCycleTime  
																			END as IdealQuantity
			from DateShiftsToProcess FRS	
				inner join #IdealBaseCycleTime Ideal	
				on (FRS.ResourceKey = Ideal.ResourceKey)
		) as S
		ON (T.AreaKey = S.AreaKey and T.ResourceKey = S.ResourceKey and T.DateKey = S.DateKey and T.ShiftDateKey = S.ShiftDateKey and T.LC1DateKey = S.LC1DateKey and T.ShiftKey = S.ShiftKey) 
		WHEN NOT MATCHED BY SOURCE
			THEN DELETE -- if reprocessing should purge old rows from shifts which were discontinued for some reason
		WHEN NOT MATCHED BY TARGET 
			THEN INSERT(
			[AreaKey]
           ,[ResourceKey]
           ,[DateKey]
		   ,[ShiftDateKey]
           ,[LC1DateKey]
           ,[ShiftKey]
           ,[IdealBaseCycleTime]
           ,[RealScheduledTime]
           ,[IdealQuantity]) 
		   VALUES(
		   S.[AreaKey]
           ,S.[ResourceKey]
           ,S.[DateKey]
		   ,S.[ShiftDateKey]
           ,S.[LC1DateKey]
           ,S.[ShiftKey]
           ,S.[IdealBaseCycleTime]
           ,NULL --S.[RealScheduledTime]
           ,S.[IdealQuantity])
		WHEN MATCHED 
			THEN UPDATE SET T.[IdealBaseCycleTime] = S.[IdealBaseCycleTime]
           ,T.[RealScheduledTime] = NULL -- S.[RealScheduledTime]
           ,T.[IdealQuantity] = S.[IdealQuantity]
		OPTION(RECOMPILE);
												
		
		set @StatusMessage = OBJECT_NAME(@@PROCID) + ': ' + cast(@@ROWCOUNT as varchar) + ' row(s) merged into FactResourceIdealQuantity';
		
		RAISERROR (@StatusMessage, 0, 1) WITH NOWAIT
		

if @DebugDMLTiming = 1
BEGIN
	set @DebugEndDate = GETUTCDATE();
	set @DebugTimingMessage = 'Step ' + cast(@DebugStep as varchar) +' took ' + cast(datediff(ss,@DebugStartDate,@DebugEndDate) as varchar) + ' Seconds to execute.'
	RAISERROR ( @DebugTimingMessage, 0, 1) WITH NOWAIT

	set @DebugStartDate = GETUTCDATE();
	set @DebugEndDate = null;
	set @DebugStep = 8;
	set @DebugTimingMessage = null;
END

	--Merge [FactMaterialProcessTime] where FactResourceIdealQuantity has been recalculated
	merge [dbo].[FactMaterialProcessTime] WITH(TABLOCK) as T
		using (		
				  select AreaKey, ResourceKey, LC1DateKey, ShiftKey, DateKey, ShiftDateKey, IdealBaseCycleTime
					from FactResourceIdealQuantity RST
				  where datekey between @MinServiceDateKey and @MaxServiceDateKey 
					and isnull(@ResourceKey, ResourceKey) = ResourceKey 				
				) as S
		ON (T.AreaKey = S.AreaKey and T.ResourceKey = S.ResourceKey and T.DateKey = S.DateKey and T.ShiftDateKey = S.ShiftDateKey and T.LC1DateKey = S.LC1DateKey and T.ShiftKey = S.ShiftKey) 
		WHEN MATCHED 
			THEN UPDATE SET T.[IdealBaseCycleTime] = S.[IdealBaseCycleTime]
			,T.[ParcelInPrimaryQuantityNormalized] = (T.[ParcelInPrimaryQuantity]) * (T.[IdealCycleTime]*1.0/S.[IdealBaseCycleTime])
			,T.[ParcelOutPrimaryQuantityNormalized] = (T.[ParcelOutPrimaryQuantity]) * (T.[IdealCycleTime]*1.0/S.[IdealBaseCycleTime])
			,T.[ParcelInTotalQuantityNormalized] = (T.[ParcelInPrimaryQuantity] + T.[ParcelInSubMaterialsPrimaryQuantity]) * (T.[IdealCycleTime]*1.0/S.[IdealBaseCycleTime])
			,T.[ParcelOutTotalQuantityNormalized] = (T.[ParcelOutPrimaryQuantity] + T.[ParcelOutSubMaterialsPrimaryQuantity]) * (T.[IdealCycleTime]*1.0/S.[IdealBaseCycleTime])
	OPTION(RECOMPILE);

	--Merge [FactMaterialProcessTime] for ParentResource where FactResourceIdealQuantity has been recalculated
	merge [dbo].[FactMaterialProcessTime] WITH(TABLOCK) as T
		using (		
				  select AreaKey, ResourceKey, LC1DateKey, ShiftKey, DateKey, ShiftDateKey, IdealBaseCycleTime
					from FactResourceIdealQuantity RST
				  where datekey between @MinServiceDateKey and @MaxServiceDateKey 
					and isnull(@ResourceKey, ResourceKey) = ResourceKey 				
				) as S
		ON (T.AreaKey = S.AreaKey and T.ParentResourceKey = S.ResourceKey and T.DateKey = S.DateKey and T.ShiftDateKey = S.ShiftDateKey and T.LC1DateKey = S.LC1DateKey and T.ShiftKey = S.ShiftKey) 
		WHEN MATCHED 
			THEN UPDATE SET T.[ParentIdealBaseCycleTime] = S.[IdealBaseCycleTime]
	OPTION(RECOMPILE);

if @DebugDMLTiming = 1
BEGIN
	set @DebugEndDate = GETUTCDATE();
	set @DebugTimingMessage = 'Step ' + cast(@DebugStep as varchar) +' took ' + cast(datediff(ss,@DebugStartDate,@DebugEndDate) as varchar) + ' Seconds to execute.'
	RAISERROR ( @DebugTimingMessage, 0, 1) WITH NOWAIT

	set @DebugStartDate = GETUTCDATE();
	set @DebugEndDate = null;
	set @DebugStep = 9;
	set @DebugTimingMessage = null;
END


		drop table #tmp_ResourceTransitions;

		drop table #tmp_semioperations;

		drop table #tmp_operations;


		exec Control.P_StopExecution @PROCNAME, @StatusMessage;

		-- If There was no transaction on the beginning of the exception, a new one was created and has to be committed.
		IF @starttrancount = 0
			COMMIT TRANSACTION;

		
	END TRY
	BEGIN CATCH
		IF XACT_STATE() <> 0 AND @starttrancount = 0 
			ROLLBACK TRANSACTION

		exec Control.P_StopExecution @PROCNAME;

		SELECT @ErrorMessage = ERROR_MESSAGE() + ' Line ' + cast(ERROR_LINE() as nvarchar(5)), @ErrorSeverity = ERROR_SEVERITY(), @ErrorState = ERROR_STATE();
		RAISERROR (@ErrorMessage, @ErrorSeverity, @ErrorState);

	END CATCH

END
GO
