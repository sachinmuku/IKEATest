﻿ALTER PROCEDURE [dbo].[P_LoadFactChartDataPointReading](@InfServiceHistoryId bigint = NULL, @SupServiceHistoryId bigint = NULL)
--WITH ENCRYPTION
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET XACT_ABORT ON
	SET NOCOUNT ON

	--Controls number of transactions
	DECLARE @starttrancount int

	declare @ErrorMessage nvarchar(max), 
		    @ErrorSeverity int, 
			@ErrorState int,
			@ErrorNumber int;

	DECLARE @TABLENAME varchar (32) = 'FactChartDataPointReading';  

	DECLARE @PROCNAME varchar (64); 
	SELECT @PROCNAME = OBJECT_NAME(@@PROCID);

	DECLARE @CurrentDatetime datetime = getUTCdate();
	DECLARE @StatusMessage nvarchar(256);

	DECLARE @MinServiceHistoryId bigint, @MaxServiceHistoryId bigint;

	DECLARE @DefaultTimeZone tinyint = [DateTimeUtil].[F_GetServerTimeZoneId](NULL);

	declare @UndefinedId bigint = [Constants].[F_GetUndefinedKey]();

	declare @UndefinedName varchar(1) = [Constants].[F_GetUndefinedKeyName]();

	declare @UndefinedMaterialKey bigint;
	select @UndefinedMaterialKey = MaterialKey from DimMaterial where MaterialId = @UndefinedId;

	declare @UndefinedProductKey bigint;
	select @UndefinedProductKey = ProductKey from DimProduct where ProductId = @UndefinedId;

	declare @UndefinedResourceKey bigint;
	select @UndefinedResourceKey = ResourceKey from DimResource where ResourceId = @UndefinedId;

	declare @UndefinedContainerKey bigint;
	select @UndefinedContainerKey = ContainerKey from DimContainer where ContainerId = @UndefinedId;

	declare @UndefinedFlowKey bigint;
	select @UndefinedFlowKey = FlowKey from DimFlow where FlowId = @UndefinedId;

	declare @UndefinedStepKey bigint;
	select @UndefinedStepKey = StepKey from DimStep where StepId = @UndefinedId;

	declare @UndefinedFacilityKey bigint;
	select @UndefinedFacilityKey = FacilityKey from Dimfacility where FacilityId = @UndefinedId;

	declare @UndefinedDataCollectionKey bigint;
	select @UndefinedDataCollectionKey = DataCollectionKey from DimDataCollection where DataCollectionId = @UndefinedId;

	declare @UndefinedOperationKey bigint;
	select @UndefinedOperationKey = min(OperationKey) from DimOperation where OperationId = @UndefinedId;

	declare @UndefinedSampleKey bigint;
	select @UndefinedSampleKey = SampleKey from DimSample where SampleId = @UndefinedName;


	BEGIN TRY
		-- Get configuration for SPC points max retention time (in hours)
		DECLARE @SPCPointRetentionReady BIGINT = CAST([dbo].[F_GetConfigStringValue] ('/Cmf/System/Configuration/SPC/DataWarehouseAggregationDelay/', '8') AS bigint);
		DECLARE @SPCPointRetentionReadyDate DATETIME = DATEADD(hh, (-1)*@SPCPointRetentionReady, GETUTCDATE());
		
		SELECT @starttrancount = @@TRANCOUNT

		IF @starttrancount = 0
			BEGIN TRANSACTION
	
		exec Control.P_StartExecution @PROCNAME, @MinServiceHistoryIdCalculated = @MinServiceHistoryId OUTPUT, @MaxServiceHistoryIdCalculated = @MaxServiceHistoryId OUTPUT, 
									  @InferiorServiceHistoryId = @InfServiceHistoryId, @SuperiorServiceHistoryId = @SupServiceHistoryId, @OtherFilters = 0;

		BEGIN -- Handle reprocessing 

			DECLARE @MinServDateTime datetime, @MaxServDateTime datetime;

			select @MinServDateTime = MinServDateTime, @MaxServDateTime = MaxServDateTime
			from [dbo].[F_GetMinAndMaxServiceTime](@MinServiceHistoryId, @MaxServiceHistoryId);

			declare @MinServiceDateKey int;
			set @MinServiceDateKey = dbo.F_GetDateKeyFromDateTime(@MinServDateTime);
		
			delete from [dbo].[FactChartDataPointReading]
			 where Datekey >= @MinServiceDateKey  --Partitioning filter... 
			   and (ServiceHistoryId >= @MinServiceHistoryId or UpdateServiceHistoryid >= @MinServiceHistoryId);

			set @StatusMessage = OBJECT_NAME(@@PROCID) + ': ' + cast(@@ROWCOUNT as varchar) + ' row(s) deleted from ' + @TABLENAME
		
			RAISERROR (@StatusMessage, 0, 1) WITH NOWAIT
		END

		
		MERGE INTO [dbo].[DimChart] WITH(TABLOCK) as [Target]
		USING
		(
			select [Constants].[F_GetUndefinedKey]() as ChartId, 
				   [Constants].[F_GetUndefinedKeyName]() as ChartName, 
				   [Constants].[F_GetUndefinedKeyName]() as [ChartType], 
				   [Constants].[F_GetUndefinedKeyName]() as [Type], 
				   [Constants].[F_GetMinDateTime]() as ChartStartDateTime, 
				   0 as [LowerSpecLimit], 
				   0 as [UpperSpecLimit], 
				   0 as CreateServiceHistoryId,
				   1 as rnum
			 where not exists (select 1 from DimChart dc where dc.ChartId = [Constants].[F_GetUndefinedKey]() )
			UNION ALL
			select * from (
				select dr.ChartId,
					dr.ChartName,
					dr.[Type],
					dr.ChartType, 
					OperationEndTime as ChartStartDateTime,
					dr.LowerSpecLimit, 
					dr.UpperSpecLimit, 
					ServiceHistoryId as CreateServiceHistoryId,
					row_number() over (partition by ChartId, LowerSpecLimit, UpperSpecLimit order by OperationEndTime asc) as rnum
			   from Staging.T_ChartDataPointReading AS dr
			) dat 
			where dat.rnum = 1
		   ) [Source] 
		   on (	[Source].ChartId = [Target].ChartId and 
				IsNull([Source].LowerSpecLimit, 99999999)  = IsNull([Target].LowerSpecLimit, 99999999) and
				IsNull([Source].UpperSpecLimit, -99999999) = IsNull([Target].UpperSpecLimit, -99999999))
		WHEN MATCHED THEN
		UPDATE SET  [Target].[ChartName] = [Source].[ChartName]
				   ,[Target].[Type] = [Target].[Type]
				   ,[Target].[ChartType] = [Source].[ChartType]
		WHEN NOT MATCHED THEN
		INSERT ([ChartId] 
		       ,[ChartName]
			   ,[Type]
			   ,[ChartType]
			   ,[LowerSpecLimit]
			   ,[UpperSpecLimit]
			   ,[ChartStartDateTime]
			   ,[CreateServiceHistoryId]
			   ,[CreateTimestamp]
			   )
		values( [Source].[ChartId] 
			   ,[Source].[ChartName]
			   ,[Source].[Type]
			   ,[Source].[ChartType]
			   ,[Source].[LowerSpecLimit]
			   ,[Source].[UpperSpecLimit]
			   ,[Source].[ChartStartDateTime]
			   ,[Source].[CreateServiceHistoryId]
			   ,GETUTCDATE()
		)
		OPTION(RECOMPILE);


		set @StatusMessage = OBJECT_NAME(@@PROCID) + ': ' + cast(@@ROWCOUNT as varchar) + ' row(s) merged into DimChart';		
		RAISERROR (@StatusMessage, 0, 1) WITH NOWAIT;
				
		IF(EXISTS (select 1 from [Staging].[T_ChartDataPointReading]))
		BEGIN
			MERGE INTO [dbo].[FactChartDataPointReading] WITH(TABLOCK) as [Target]
			USING
			(
			select  fin.DateKey,
					fin.TimeKey,
					fin.UTCOperationEndTime,
					fin.ChartKey, fin.ParameterKey, fin.DataPointKey,
					fin.MaterialKey,
					fin.ProductKey,
					fin.ResourceKey,
					fin.ContainerKey,
					fin.FlowKey,
					fin.StepKey,
					fin.FacilityKey,
					fin.DataCollectionKey,
					fin.OperationKey,
					fin.SampleKey, 
					fin.TargetSpecValue,
					fin.LowerControlLimit1,	fin.LowerControlLimit2,	fin.LowerSpecLimit,
					fin.UpperControlLimit1,	fin.UpperControlLimit2,	fin.UpperSpecLimit,
					fin.DataPointValue1, fin.DataPointValue2,
					fin.OriginalDataPointValue1, fin.OriginalDataPointValue2,
					fin.IsEdited, fin.SystemState,
					fin.ReadingNumberKey, fin.DataPointReadingValue,
					dbo.F_GetDateKeyFromDateTime(fin.LC1OperationEndTime)as LC1DateKey,
					dbo.F_GetTimeKeyFromDateTime(fin.LC1OperationEndTime)as LC1TimeKey,
					fin.LC1OperationEndTime,
					fin.ServiceHistoryId,
					fin.OperationHistorySeq,
					fin.SubOperationSequence,
					fin.ServiceHistoryId as UpdateServiceHistoryId,
					fin.TimeZoneKey,
					GETUTCDATE() as [RecordTimeStamp]
					from ( SELECT	dbo.F_GetDateKeyFromDateTime(stg.OperationEndTime) as DateKey,
									dbo.F_GetTimeKeyFromDateTime(stg.OperationEndTime) as TimeKey,
									stg.OperationEndTime as UTCOperationEndTime,								
									-- TimeZoneKey priorities: From DimResource, then DimFacility, then Default
									[DateTimeUtil].[UDF_ConvertUtcToLocalByTimezoneId](COALESCE(dr.TimeZoneKey, dfac.TimeZoneKey, @DefaultTimeZone )
																								, stg.OperationEndTime) as LC1OperationEndTime, 
									COALESCE(dr.TimeZoneKey, dfac.TimeZoneKey, @DefaultTimeZone ) as TimeZoneKey,
									dc.ChartKey, 
									dp.ParameterKey, 
									dcdp.DataPointKey,
									isnull(dm.MaterialKey,@UndefinedMaterialKey) as MaterialKey,
									isnull(dprod.ProductKey,@UndefinedProductKey) as ProductKey,
									isnull(dr.ResourceKey,@UndefinedResourceKey) as ResourceKey,
									isnull(ct.ContainerKey,@UndefinedContainerKey) as ContainerKey,
									isnull(df.FlowKey,@UndefinedFlowKey) as FlowKey,
									isnull(ds.StepKey,@UndefinedStepKey) as StepKey,
									isnull(dfac.FacilityKey,@UndefinedFacilityKey) as FacilityKey,
									isnull(dtc.DataCollectionKey,@UndefinedDataCollectionKey) as DataCollectionKey,
									isnull(do.OperationKey,@UndefinedOperationKey) as OperationKey,
									isnull(dsam.SampleKey,@UndefinedSampleKey) as SampleKey,
									stg.TargetSpecValue, 
									stg.LowerControlLimit1,	stg.LowerControlLimit2,	stg.LowerSpecLimit,
									stg.UpperControlLimit1,	stg.UpperControlLimit2,	stg.UpperSpecLimit,
									stg.DataPointValue1, stg.DataPointValue2, stg.OriginalDataPointValue1, stg.OriginalDataPointValue2, stg.IsEdited, stg.SystemState,
									drn.ReadingNumberKey, stg.DataPointReadingValue,								
									stg.ServiceHistoryId,
									stg.OperationHistorySeq,
									stg.SubOperationSequence
								FROM (SELECT   [ChartId]
											  ,[ParameterId]
											  ,[ChartDataPointId]
											  ,[ChartDataPointName]
											  ,[MaterialId]
											  ,[ProductId]
											  ,[ResourceID]
											  ,[ContainerId]
											  ,[FlowID]
											  ,[StepId]
											  ,[FacilityID]
											  ,[MaterialOperation]
											  ,[DataCollectionId]
											  ,[SampleId]
											  ,[TargetSpecValue]
											  ,[LowerControlLimit1]
											  ,[LowerControlLimit2]
											  ,[LowerSpecLimit]
											  ,[UpperControlLimit1]
											  ,[UpperControlLimit2]
											  ,[UpperSpecLimit]
											  ,[DataPointValue1]
											  ,[DataPointValue2]
											  ,[OriginalDataPointValue1]
											  ,[OriginalDataPointValue2]
											  ,[IsEdited]
											  ,[SystemState]
											  ,cast([ReadingNumber] as nvarchar) ReadingNumber
											  ,[DataPointReadingValue]
											  ,[ServiceHistoryId]
											  ,[OperationHistorySeq]
											  ,[SubOperationSequence]
											  ,[OperationEndTime]
										  FROM [Staging].[T_ChartDataPointReading]
							   WHERE [ServiceHistoryId] between @MinServiceHistoryId and @MaxServiceHistoryId 
								) stg
							left join DimParameter dp on dp.ParameterId = stg.ParameterId and dp.[Type] not in ('Protocol','Checklist')
							left join DimMaterial dm on dm.MaterialId = stg.MaterialId and 
																				   (( stg.ServiceHistoryId > dm.StartServiceHistoryId or (stg.ServiceHistoryId = dm.StartServiceHistoryId and stg.OperationHistorySeq >= dm.StartOperationHistorySeq)) AND
																					( dm.EndServiceHistoryId is null or stg.ServiceHistoryId < dm.EndServiceHistoryId or (stg.ServiceHistoryId = dm.EndServiceHistoryId and stg.OperationHistorySeq < dm.EndOperationHistorySeq)))
							left join DimProduct dprod on dprod.ProductId = stg.ProductId
							left join DimResource dr on dr.ResourceId = stg.ResourceId
							left join DimContainer ct on ct.ContainerId = stg.ContainerId
							left join DimFlow df on df.FlowId = stg.FlowId
							left join DimStep ds on ds.StepId = stg.StepId
							left join DimFacility dfac on dfac.FacilityId = stg.FacilityId
							left join DimDataCollection dtc on dtc.DataCollectionId = stg.DataCollectionId 
							left join DimOperation do on do.OperationName = stg.MaterialOperation and do.EntityName = 'Material'
							left join DimSample dsam on dsam.SampleId = stg.SampleId
							left join DimDataPoint dcdp on dcdp.DataPointId = stg.[ChartDataPointId] and dcdp.DataPointType = 'Chart'
							left join DimReadingNumber drn on drn.ReadingNumber = stg.ReadingNumber
							inner join 
							( 
							   select *
								  from (
									  select dc.ChartKey, dc.ChartId, dc.LowerSpecLimit, dc.UpperSpecLimit, ROW_NUMBER() over (PARTITION BY dc.chartid, IsNull(dc.LowerSpecLimit, 99999999), IsNull(dc.UpperSpecLimit, -99999999) ORDER BY CreateTimeStamp DESC) rnum
									  from dimchart dc
									  inner join (select distinct chartid, LowerSpecLimit,UpperSpecLimit from [Staging].[T_ChartDataPointReading]) currentCharts
									  on ( dc.ChartId = currentCharts.chartid and IsNull(dc.LowerSpecLimit, 99999999) = IsNull(currentCharts.LowerSpecLimit, 99999999) and IsNull(dc.UpperSpecLimit, -99999999) = IsNull(currentCharts.UpperSpecLimit, -99999999))		
								 )	dat
							   where dat.rnum = 1
							)dc
							on dc.ChartId = stg.ChartId and IsNull(dc.LowerSpecLimit, 99999999) = IsNull(stg.LowerSpecLimit, 99999999) and IsNull(dc.UpperSpecLimit, -99999999) = IsNull(stg.UpperSpecLimit, -99999999)
						  ) fin
			) [Source] on (	[Source].DateKey = [Target].DateKey and 
							[Source].TimeKey = [Target].TimeKey and 
							[Source].ChartKey = [Target].ChartKey and 
							[Source].ParameterKey = [Target].ParameterKey and
							[Source].DataPointKey = [Target].ChartDataPointKey and 
							[Source].ReadingNumberKey = [Target].ReadingNumberKey) 						
						
			WHEN MATCHED THEN
			UPDATE SET  [Target].[MaterialKey] = [Source].[MaterialKey]
					   ,[Target].[ResourceKey] = [Source].[ResourceKey]
					   ,[Target].[ContainerKey] = [Source].[ContainerKey]
					   ,[Target].[ProductKey] = [Source].[ProductKey]
					   ,[Target].[FlowKey] = [Source].[FlowKey]
					   ,[Target].[StepKey] = [Source].[StepKey]
					   ,[Target].[FacilityKey] = [Source].[FacilityKey]
					   ,[Target].[DataCollectionKey] = [Source].[DataCollectionKey]
					   ,[Target].[OperationKey] = [Source].[OperationKey]
					   ,[Target].[SampleKey] = [Source].[SampleKey]
					   ,[Target].[TargetSpecValue] = [Source].[TargetSpecValue]
					   ,[Target].[LowerControlLimit1] = [Source].[LowerControlLimit1]
					   ,[Target].[LowerControlLimit2] = [Source].[LowerControlLimit2]
					   ,[Target].[LowerSpecLimit] = [Source].[LowerSpecLimit]
					   ,[Target].[UpperControlLimit1] = [Source].[UpperControlLimit1]
					   ,[Target].[UpperControlLimit2] = [Source].[UpperControlLimit2]
					   ,[Target].[UpperSpecLimit] = [Source].[UpperSpecLimit]
					   ,[Target].[DataPointValue1] = [Source].[DataPointValue1]
					   ,[Target].[DataPointValue2] = [Source].[DataPointValue2]
					   ,[Target].[OriginalDataPointValue1] = [Source].[OriginalDataPointValue1]
					   ,[Target].[OriginalDataPointValue2] = [Source].[OriginalDataPointValue2]
					   ,[Target].[IsEdited] = [Source].[IsEdited]
					   ,[Target].[SystemState] = [Source].[SystemState]
					   ,[Target].[DataPointReadingValue] = [Source].[DataPointReadingValue]
					   ,[Target].[ServiceHistoryId] = [Source].[ServiceHistoryId]
					   ,[Target].[OperationHistorySeq] = [Source].[OperationHistorySeq]
					   ,[Target].[SubOperationSequence] = [Source].[SubOperationSequence]
					   ,[Target].[UpdateServiceHistoryId] = [Source].[UpdateServiceHistoryId]
					   ,[Target].[TimeZoneKey] = [Source].[TimeZoneKey]
					   ,[Target].[UpdateTimeStamp] = [Source].[RecordTimeStamp]
			WHEN NOT MATCHED THEN
			INSERT ([DateKey]
				   ,[TimeKey]
				   ,[UTCOperationEndTime]
				   ,[ChartKey]
				   ,[ParameterKey]
				   ,[ChartDataPointKey]
				   ,[MaterialKey]
				   ,[ProductKey]
				   ,[ResourceKey]
				   ,[ContainerKey]
				   ,[FlowKey]
				   ,[StepKey]
				   ,[FacilityKey]
				   ,[DataCollectionKey]
				   ,[OperationKey]
				   ,[SampleKey]
				   ,[TargetSpecValue]
				   ,[LowerControlLimit1]
				   ,[LowerControlLimit2]
				   ,[LowerSpecLimit]
				   ,[UpperControlLimit1]
				   ,[UpperControlLimit2]
				   ,[UpperSpecLimit]
				   ,[DataPointValue1]
				   ,[DataPointValue2]
				   ,[OriginalDataPointValue1]
				   ,[OriginalDataPointValue2]
				   ,[IsEdited]
				   ,[SystemState]
				   ,[ReadingNumberKey]
				   ,[DataPointReadingValue]
				   ,[LC1DateKey]
				   ,[LC1TimeKey]
				   ,[LC1OperationEndTime]
				   ,[TimeZoneKey]
				   ,[ServiceHistoryId]
				   ,[OperationHistorySeq]
				   ,[SubOperationSequence]
				   ,[UpdateServiceHistoryId]
				   ,[CreateTimeStamp]
				   ,[UpdateTimeStamp])
			values( [Source].[DateKey]
				   ,[Source].[TimeKey]
				   ,[Source].[UTCOperationEndTime]
				   ,[Source].[ChartKey]
				   ,[Source].[ParameterKey]
				   ,[Source].[DataPointKey]
				   ,[Source].[MaterialKey]
				   ,[Source].[ProductKey]
				   ,[Source].[ResourceKey]
				   ,[Source].[ContainerKey]
				   ,[Source].[FlowKey]
				   ,[Source].[StepKey]
				   ,[Source].[FacilityKey]
				   ,[Source].[DataCollectionKey]
				   ,[Source].[OperationKey]
				   ,[Source].[SampleKey]
				   ,[Source].[TargetSpecValue]
				   ,[Source].[LowerControlLimit1]
				   ,[Source].[LowerControlLimit2]
				   ,[Source].[LowerSpecLimit]
				   ,[Source].[UpperControlLimit1]
				   ,[Source].[UpperControlLimit2]
				   ,[Source].[UpperSpecLimit]
				   ,[Source].[DataPointValue1]
				   ,[Source].[DataPointValue2]
				   ,[Source].[OriginalDataPointValue1]
				   ,[Source].[OriginalDataPointValue2]
				   ,[Source].[IsEdited]
				   ,[Source].[SystemState]
				   ,[Source].[ReadingNumberKey]
				   ,[Source].[DataPointReadingValue]
				   ,[Source].[LC1DateKey]
				   ,[Source].[LC1TimeKey]
				   ,[Source].[LC1OperationEndTime]
				   ,[Source].[TimeZoneKey]
				   ,[Source].[ServiceHistoryId]
				   ,[Source].[OperationHistorySeq]
				   ,[Source].[SubOperationSequence]
				   ,[Source].[UpdateServiceHistoryId]
				   ,[Source].[RecordTimeStamp]
				   ,[Source].[RecordTimeStamp]
			)
			OPTION (RECOMPILE);
		
			set @StatusMessage = OBJECT_NAME(@@PROCID) + ': ' + cast(@@ROWCOUNT as varchar) + ' row(s) merged into ' + @TABLENAME
			RAISERROR (@StatusMessage, 0, 1) WITH NOWAIT;

		END
		-- review which datapoints exceeded the grace period and close them in DWH
		DECLARE @DataPointsToUpdate TABLE
		(
			[DataPointkey] bigint,
			[DataPointCreatedOn] datetime
		);

		DECLARE @SPCGracePeriodThreshold datetime = DATEADD(hh, (-1)*@SPCPointRetentionReady, @MaxServDateTime)

		update DimDataPoint set IsClosedInDWH = 1, [UpdateTimestamp] = getUTCdate()		
		  output inserted.[DataPointKey], inserted.DataPointCreatedOn into @DataPointsToUpdate
		where IsClosedInDWH = convert(bit, 0)
		AND DataPointCreatedOn <= @SPCGracePeriodThreshold;		

		IF (@@ROWCOUNT > 0)
		BEGIN
			
			select @MinServiceDateKey = dbo.F_GetDateKeyFromDateTime(min([DataPointCreatedOn]))
			from @DataPointsToUpdate;

			-- if there were datapoints closed then run following update which will lead to the CPK calculation in the analysis services
			UPDATE fcdpr SET 
					[DataPointValue1] = [OriginalDataPointValue1], 
					[DataPointValue2] = [OriginalDataPointValue2],
					[UpdateTimestamp] = getUTCdate()	
			from [FactChartDataPointReading] fcdpr
			inner join @DataPointsToUpdate dps on (dps.DataPointkey = fcdpr.ChartDataPointKey)
			where fcdpr.DateKey >= @MinServiceDateKey
			and [SystemState] = 0; -- 0 - Active; 1 - Deleted; 2 - Excluded

			set @StatusMessage = OBJECT_NAME(@@PROCID) + ': ' + cast(@@ROWCOUNT as varchar) + ' row(s) closed on ' + @TABLENAME;	
			RAISERROR (@StatusMessage, 0, 1) WITH NOWAIT;

		END;		

		

		EXEC Control.P_StopExecution @PROCNAME, @StatusMessage;

		-- If There was no transaction on the beginning of the exception, a new one was created and has to be committed.
		IF @starttrancount = 0
			COMMIT TRANSACTION;
		
	END TRY
	BEGIN CATCH
		IF XACT_STATE() <> 0 AND @starttrancount = 0 
			ROLLBACK TRANSACTION

		EXEC Control.P_StopExecution @PROCNAME;

		SELECT @ErrorMessage = ERROR_MESSAGE() + ' Line ' + cast(ERROR_LINE() as nvarchar(5)), @ErrorSeverity = ERROR_SEVERITY(), @ErrorState = ERROR_STATE();
		RAISERROR (@ErrorMessage, @ErrorSeverity, @ErrorState);

	END CATCH
END
GO
