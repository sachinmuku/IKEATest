ALTER TABLE [Custom].[FactProductSetupTime] ALTER COLUMN [CalculatedSetupTime] DECIMAL(15, 8)
ALTER TABLE [Custom].[FactProductSetupTime] ALTER COLUMN [ExpectedSetupTime] DECIMAL(15, 8)