IF (EXISTS(SELECT * FROM sys.procedures SP INNER JOIN sys.schemas SS ON SS.schema_id = SP.schema_id WHERE SP.name = 'P_LoadFactOrderCycleTimes' AND SS.name = 'Custom'))
BEGIN
	DROP PROCEDURE [Custom].[P_LoadFactOrderCycleTimes]
END
GO

CREATE PROCEDURE [Custom].[P_LoadFactOrderCycleTimes]	
(
	@InfServiceHistoryId BIGINT = NULL
	, @SupServiceHistoryId BIGINT = NULL
	, @MaterialId BIGINT = NULL
)
WITH ENCRYPTION
AS

BEGIN

	SET NOCOUNT ON
	
	-- TRANSACTION CONTROL VARIABLES
	DECLARE @StartTranCount					INTEGER
	
	-- ERROR HANDLING VARIABLES
	DECLARE @ErrorSeverity					INTEGER
	DECLARE @ErrorState						INTEGER
	DECLARE @ErrorMessage					NVARCHAR(MAX)
	
	-- EXECUTION CONTROL VARIABLES
	DECLARE @ProcedureName					NVARCHAR(64)	= OBJECT_NAME(@@PROCID)
	DECLARE @IsOtheFilterApplied			BIT				= (CASE WHEN @MaterialId IS NOT NULL THEN 1 ELSE 0 END)
	DECLARE @MinServiceHistoryId			BIGINT
	DECLARE @MaxServiceHistoryId			BIGINT
	DECLARE @InternalMinServiceHistoryId	BIGINT
	DECLARE @InternalMaxServiceHistoryId	BIGINT
	DECLARE @InternalMinDate				DATETIME
	DECLARE @InternalMaxDate				DATETIME
	DECLARE @MinServDateTime				DATETIME
	DECLARE	@MaxServDateTime				DATETIME
	DECLARE @MinServDateKey					INTEGER
	DECLARE @MaxServDateKey					INTEGER
	DECLARE @ApplyUDF						BIT				= 0
	DECLARE	@ConversionOffsetToLocal		INT				= 0
	DECLARE	@ConversionOffsetToUTC			INT				= 0
	DECLARE @TimeZone						NVARCHAR(255)	= [DateTimeUtil].[F_GetServerTimeZoneIdentifier]()
	DECLARE @LogMessage						NVARCHAR(MAX)	= N''
	DECLARE @LogMessageTemplateStart		NVARCHAR(MAX)	= @ProcedureName + N': %TaskName%'
	DECLARE @LogMessageTemplateEnd			NVARCHAR(MAX)	= REPLICATE(N' ', LEN(@ProcedureName) + 2) +  N'Task Completed in %ExecutionTime% second(s). Rows Affected: %RowsAffected%.'
	DECLARE @ExecutionControlTS				DATETIME
	DECLARE @ProcedureStart					DATETIME		= GETDATE()
	DECLARE @ExecutionTimeInSeconds			BIGINT			= 0
	DECLARE @RowsAffected					BIGINT			= 0
	DECLARE @LC1TimeZoneIdentifier			NVARCHAR(255)	= [Constants].[F_GetLC1TimeZoneIdentifier]()
	DECLARE @SqlStatement					NVARCHAR(MAX)	= N''
	DECLARE @SystemName						NVARCHAR(MAX)	= [dbo].[F_GetSystemName]()
	DECLARE @OnlineLink						NVARCHAR(MAX)	= 'cm' + @SystemName + 'OnlineLink'
		
	-- FALLBACK KEYS
	DECLARE @UndefinedKey					BIGINT			= Constants.F_GetUndefinedKey()
	DECLARE @UndefinedProductKey			BIGINT			= (SELECT [ProductKey]	FROM [dbo].[DimProduct]		WHERE [ProductId] = @UndefinedKey)
	DECLARE @UndefinedMaterialKey			BIGINT			= (SELECT [MaterialKey] FROM [dbo].[DimMaterial]	WHERE [MaterialId] = @UndefinedKey)
	DECLARE @UndefinedResourceKey			BIGINT			= (SELECT [ResourceKey] FROM [dbo].[DimResource]	WHERE [ResourceId]	= @UndefinedKey)
	DECLARE @UndefinedAreaKey				BIGINT			= (SELECT [AreaKey]		FROM [dbo].[DimArea]		WHERE [AreaId]		= @UndefinedKey)
	DECLARE @UndefinedFacilityKey			BIGINT			= (SELECT [FacilityKey] FROM [dbo].[DimFacility]	WHERE [FacilityId]	= @UndefinedKey)
	
	BEGIN TRY

		-- GET CURRENT TRANSACTION COUNTER
		SELECT @StartTranCount = @@TRANCOUNT

		-- BEGIN A TRANSACTION IF EXECUTION IS NOT UNDER AN ALREADY RUNNING TRANSACTION
		IF @StartTranCount = 0
			BEGIN TRANSACTION

		IF(@IsOtheFilterApplied = 1)
		BEGIN
			
			SELECT @InfServiceHistoryId = MIN(MH.[ServiceHistoryId]), @SupServiceHistoryId = MAX(MH.[ServiceHistoryId])
			FROM [Staging].[ODS_T_MaterialHistory] MH
			WHERE MH.[MaterialId] = @MaterialId

		END
		
		-- LOG START OF EXECUTION
		EXEC Control.P_StartExecution @ProcedureName, @MinServiceHistoryIdCalculated = @MinServiceHistoryId OUTPUT, @MaxServiceHistoryIdCalculated = @MaxServiceHistoryId OUTPUT
									, @InferiorServiceHistoryId = @InfServiceHistoryId, @SuperiorServiceHistoryId = @SupServiceHistoryId, @OtherFilters = @IsOtheFilterApplied
		
		SELECT @MinServDateTime = [MinServDateTime], @MaxServDateTime = [MaxServDateTime] FROM [dbo].[F_GetMinAndMaxServiceTime](@MinServiceHistoryId, @MaxServiceHistoryId)

		SELECT @ApplyUDF = ApplyUDFCalculation, @ConversionOffsetToLocal = LocalConversionOffset, @ConversionOffsetToUTC = UTCConversionOffset
		FROM [DateTimeUtil].[F_GetLocalDateTimeProcessingType](@TimeZone, @MinServDateTime, @MaxServDateTime)

		-- DEFINE KEY INTERVALS
		SELECT @MinServDateTime = MinServDateTime, @MaxServDateTime = MaxServDateTime FROM [dbo].[F_GetMinAndMaxServiceTime](@MinServiceHistoryId, @MaxServiceHistoryId)
		SET @MinServDateKey = [dbo].[F_GetDateKeyFromDateTime](@MinServDateTime)
		SET @MaxServDateKey = [dbo].[F_GetDateKeyFromDateTime](@MaxServDateTime);
		
		IF(@MaxServiceHistoryId >= @MinServiceHistoryId)
		BEGIN
			
			-- GET ORDER RUN NUMBER ATTRIBUTE FROM METADATA TO EXTRACT
			-- ALL PALLETS GENERATED OUT OF THE CURRENT ORDER RUN
			DECLARE @OrderRunAttributeId	BIGINT = (
														SELECT ISNULL(MAX(ETP.[EntityTypePropertyId]), -1)
														FROM [Staging].[ODS_T_EntityType] ET
														INNER JOIN [Staging].[ODS_T_EntityTypeProperty] ETP ON ETP.[EntityTypeId] = ET.[EntityTypeId]
														WHERE ET.[Name] = N'Material'
															AND ETP.[Name] = N'OrderRunNumber'
														)
			-- ORDER MATERIAL FORM
			DECLARE @MaterialOrderForm		NVARCHAR(512) = (
																SELECT ISNULL(MAX([ValueString]), N'MO')
																FROM [Staging].[ODS_T_Config]
																WHERE [ConfigPath] = '/Cmf/Custom/MaterialTracking/OrderMaterialForm/'
															)

			-- SET POINT RECIPE PARAMETER
			DECLARE @SetpointParameter		NVARCHAR(512) = (
																SELECT ISNULL(MAX([ValueString]), N'SetPoint')
																FROM [Staging].[ODS_T_Config]
																WHERE [ConfigPath] = '/Cmf/Custom/SetPointParameter/'
															)

			-- BASED ON THE ELIGIBLE ORDERS FOUND FOR PROCESSING, THESE PARAMETERS WILL BE USED TO
			-- DEFINE THE SERVICE HISTORY ID RANGE SUBJECT TO PROCESSING
			DECLARE @MaterialMinServiceHistoryId	BIGINT
			DECLARE @MaterialMaxServiceHistoryId	BIGINT

			-- TABLE DECLARATIONS
			BEGIN
								
				SET @ExecutionControlTS = GETDATE()
				SET @LogMessage = REPLACE(@LogMessageTemplateStart, N'%TaskName%' , + N'Setting up temporary tables...')
				RAISERROR (@LogMessage, 0, 1) WITH NOWAIT
					
				-- TABLE #EligibleRecords
				-- WILL HOLD CAPTURED OPERATIONS THAT FALL WITHIN THE EXPECTED TIME FRAME
				BEGIN
					IF(OBJECT_ID('tempdb..#EligibleRecords') IS NOT NULL)
						DROP TABLE #EligibleRecords

					CREATE TABLE #EligibleRecords
					(
						[MaterialId]				BIGINT
						, [ResourceId]				BIGINT
						, [AreaId]					BIGINT
						, [FacilityId]				BIGINT
						, [ProductId]				BIGINT
						, [StepId]					BIGINT
						, [OrderRunNumber]			INTEGER
						, [OrderOperationStart]		DATETIME
						, [OrderOperationEnd]		DATETIME
						, [OrderScheduledQuantity]	DECIMAL(15, 8)
						, [OrderSetpoint]			DECIMAL(15, 8)
						, [OrderSetpointUnits]		NVARCHAR(512)
						, [OrderSetpointInMinutes]	AS (
													CASE [OrderSetpointUnits]
														WHEN N'Days' THEN [OrderSetpoint] * 60 * 24
														WHEN N'Hours' THEN [OrderSetpoint] * 60
														WHEN N'Minutes' THEN [OrderSetpoint]
														WHEN N'Seconds' THEN [OrderSetpoint] / 60.0
														ELSE NULL
														END
													)
						, [OrderRecipeInstanceId]	BIGINT
						, [ServiceHistoryId]		BIGINT
						, [OperationHistorySeq]		BIGINT
						, PRIMARY KEY([MaterialId], [ResourceId], [OrderRunNumber])
					)

				END

				-- TABLE #OrderShiftSplitRecords
				-- WILL HOLD CAPTURED OPERATIONS THAT FALL WITHIN THE EXPECTED TIME FRAME, SPLIT BY SHIFT
				BEGIN

					IF(OBJECT_ID('tempdb..#OrderShiftSplitRecords') IS NOT NULL)
						DROP TABLE #OrderShiftSplitRecords

					CREATE TABLE #OrderShiftSplitRecords
					(
						[UID]						BIGINT
						, [MaterialId]				BIGINT
						, [MaterialKey]				BIGINT
						, [StepKey]					BIGINT
						, [ProductKey]				BIGINT
						, [ResourceKey]				BIGINT
						, [AreaKey]					BIGINT
						, [FacilityKey]				BIGINT
						, [ShiftKey]				BIGINT
						, [OrderRunNumber]			INTEGER
						, [OrderOperationStart]		DATETIME
						, [OrderOperationEnd]		DATETIME
						, [OrderScheduledQuantity]	DECIMAL(15, 8)
						, [OrderSetpointInMinutes]	DECIMAL(15, 8)
						, [ServiceHistoryId]		BIGINT
						, [OrderOperationStartLC1]	DATETIME
						, PRIMARY KEY([UID])
					)

				END

				-- TABLE #ValidInProcessStates
				BEGIN
					IF(OBJECT_ID('tempdb..#ValidInProcessStates') IS NOT NULL)
						DROP TABLE #ValidInProcessStates

					CREATE TABLE #ValidInProcessStates([StateName] NVARCHAR(512))

					INSERT INTO #ValidInProcessStates([StateName])
					SELECT 'INPROCESS'
					UNION ALL
					SELECT 'COMPLETED'
					UNION ALL
					SELECT 'COMPLETING'
					UNION ALL
					SELECT 'ABORTED'
					UNION ALL
					SELECT 'ABORTING'

				END

				-- TABLE #OrderRunGeneratedPallets
				-- WILL HOLD GENERATED PALLETS PER ORDER RUN, QUANTITIES AND PALLET GENERATION TIMESTAMPS
				BEGIN

					IF(OBJECT_ID('tempdb..#OrderRunGeneratedPallets') IS NOT NULL)
						DROP TABLE #OrderRunGeneratedPallets

					CREATE TABLE #OrderRunGeneratedPallets
					(
						[UID]							BIGINT
						, [GeneratedPalletId]			BIGINT
						, [GeneratedPalletName]			NVARCHAR(512)
						, [GeneratedQuantity]			DECIMAL(15, 8)
						, [OrderRunNumber]				INTEGER
						, [PalletGenerationTimestamp]	DATETIME
						, PRIMARY KEY([UID], [GeneratedPalletId])
					)

				END

				-- TABLE #OrderRunGeneratedPalletsSummary
				-- WILL HOLD SUMMARY PER RUN OCCURRENCE OF ALL QUANTITIES PRODUCED
				BEGIN

					IF(OBJECT_ID('tempdb..#OrderRunGeneratedPalletsSummary') IS NOT NULL)
						DROP TABLE #OrderRunGeneratedPalletsSummary

					CREATE TABLE #OrderRunGeneratedPalletsSummary
					(
						[UID]							BIGINT
						, [GeneratedQuantity]			DECIMAL(15, 8)
						, PRIMARY KEY([UID])
					)
				END

				-- TABLE #MaterialStates
				-- USED TO DETERMINE CHUNKS OF TIME REPORTING TO PROCESSING TIMES WITHIN THE ORDER BASED ON PROCESSING STATES DEFINED
				BEGIN

					IF(OBJECT_ID('tempdb..#MaterialStates') IS NOT NULL)
						DROP TABLE #MaterialStates

					CREATE TABLE #MaterialStates(
							[UID]							BIGINT
							, [MaterialId]					BIGINT
							, [ModifiedOn]					DATETIME
							, [ServiceHistoryId]			BIGINT
							, [OperationHistorySeq]			BIGINT
							, [StateModelState]				NVARCHAR(512)
							, [MaterialHistoryOrder]		BIGINT
							, [IsProcessingState]			BIT
							, [PreviousIsProcessingState]	BIT
							, [StateBlockOrder]				BIGINT
							, [PrevHistoryRecordTimeStamp]	DATETIME
							, [NextHistoryRecordTimeStamp]	DATETIME
					)
	
				END

				-- TABLE #OrderRunProcessingTime
				-- HOLDS PER ORDER RUN THE TOTAL AMOUNT OF TIME IN MINUTES
				-- WHERE THE ORDER WAS IN PROCESSING STATE
				BEGIN
	
					IF(OBJECT_ID('tempdb..#OrderRunProcessingTime') IS NOT NULL)
						DROP TABLE #OrderRunProcessingTime

					CREATE TABLE #OrderRunProcessingTime(
							[UID]							BIGINT
							, [ProcessingTimeInMinutes]		DECIMAL(15, 8)
							, PRIMARY KEY ([UID])
					)
				END

				-- TABLE #ExpectedCycleTime
				BEGIN

					IF(OBJECT_ID('tempdb..#ExpectedCycleTime') IS NOT NULL)
						DROP TABLE #ExpectedCycleTime

					CREATE TABLE #ExpectedCycleTime
					(
						[StepKey]				BIGINT
						, [ProductKey]			BIGINT
						, [ResourceKey]			BIGINT
						, [TimeScale]			NVARCHAR(512)
						, [TimePerUnit]			DECIMAL(15, 8)
						, [TimePerUnitMinutes]  AS (
													CASE [TimeScale]
														WHEN N'Days' THEN [TimePerUnit] * 60 * 24
														WHEN N'Hours' THEN [TimePerUnit] * 60
														WHEN N'Minutes' THEN [TimePerUnit]
														WHEN N'Seconds' THEN [TimePerUnit] / 60.0
														ELSE NULL
														END
													)
						, PRIMARY KEY([StepKey], [ProductKey], [ResourceKey])
					)
				END

				-- DROP TABLE #FactProductSetupTimeTemp IF ALREADY IN SESSION
				BEGIN
					IF(OBJECT_ID('tempdb..#FactProductSetupTimeTemp') IS NOT NULL)
						DROP TABLE #FactProductSetupTimeTemp

				END
				
				SET @ExecutionTimeInSeconds = DATEDIFF(SECOND, @ExecutionControlTS, GETDATE())
				SET @LogMessage = REPLACE(REPLACE(@LogMessageTemplateEnd, N'%ExecutionTime%', CONVERT(NVARCHAR, @ExecutionTimeInSeconds)), N'%RowsAffected%', N'N/A')
				RAISERROR(@LogMessage, 0, 1) WITH NOWAIT

			END
		
			-- COLLECT ALL OPERATIONS THAT SHALL BE SUBJECT TO THIS PROCESSING
			BEGIN

				SET @ExecutionControlTS = GETDATE()
				SET @LogMessage = REPLACE(@LogMessageTemplateStart, N'%TaskName%' , + N'Collect all operations eligible for processing...')
				RAISERROR (@LogMessage, 0, 1) WITH NOWAIT

				;WITH BASE_DATA AS
				(
					SELECT M.[MaterialId]
						, R.[ResourceId]
						, R.[AreaId]
						, A.[FacilityId]
						, M.[ProductId]
						, CEOTH.[OrderRunNumber]
						, CEOTH.[OrderOperationStart]
						-- IF NO OPERATION END LOGGED, ASSUME TERMINATION DATE
						, ISNULL(CEOTH.[OrderOperationEnd], CEOTH.[ModifiedOn]) [OrderOperationEnd]
						-- ORDER SCHEDULED QUANTITY FOR REFERENCE
						, CEOTH.[OrderScheduledQuantity]
						, CEOTH.[ServiceHistoryId]
						, CEOTH.[OperationHistorySeq]
						, DENSE_RANK() OVER (PARTITION BY M.[MaterialId], CEOTH.[OrderRunNumber], CEOTH.[OrderOperationStart]
												ORDER BY CEOTH.[ModifiedOn] DESC, CEOTH.[ServiceHistoryId] DESC, CEOTH.[OperationHistorySeq] DESC) [IsLastRecord]
					FROM [Custom].[ODS_T_CustomERPOperationTrackingHistory] CEOTH
					INNER JOIN [Staging].[ODS_T_Material] M ON M.[Name] = CEOTH.[OrderMaterial]
					INNER JOIN [Staging].[ODS_T_Resource] R ON R.[Name] = CEOTH.[OrderResource]
					INNER JOIN [Staging].[ODS_T_Area] A ON A.[AreaId] = R.[AreaId]
					WHERE CEOTH.[ServiceHistoryId] BETWEEN @MinServiceHistoryId AND @MaxServiceHistoryId
						AND (@IsOtheFilterApplied = 0 OR (@IsOtheFilterApplied = 1 AND M.[MaterialId] = @MaterialId))
				)
				INSERT INTO #EligibleRecords([MaterialId], [ResourceId], [AreaId], [FacilityId],  [ProductId], [OrderRunNumber]
												, [OrderOperationStart], [OrderOperationEnd], [OrderScheduledQuantity], [ServiceHistoryId], [OperationHistorySeq])
				SELECT BD.[MaterialId]
					, BD.[ResourceId]
					, BD.[AreaId]
					, BD.[FacilityId]
					, BD.[ProductId]
					, BD.[OrderRunNumber]
					, BD.[OrderOperationStart]
					, BD.[OrderOperationEnd]
					, BD.[OrderScheduledQuantity]
					, BD.[ServiceHistoryId]
					, BD.[OperationHistorySeq]
				FROM BASE_DATA BD
				WHERE BD.[IsLastRecord] = 1

				SET @RowsAffected = @@ROWCOUNT
				SET @ExecutionTimeInSeconds = DATEDIFF(SECOND, @ExecutionControlTS, GETDATE())
				SET @LogMessage = REPLACE(REPLACE(@LogMessageTemplateEnd, N'%ExecutionTime%', CONVERT(NVARCHAR, @ExecutionTimeInSeconds)), N'%RowsAffected%', CONVERT(NVARCHAR, @RowsAffected))
				RAISERROR(@LogMessage, 0, 1) WITH NOWAIT

				SET @ExecutionControlTS = GETDATE()
				SET @LogMessage = REPLACE(@LogMessageTemplateStart, N'%TaskName%' , + N'Extract Step and Recipes used...')
				RAISERROR (@LogMessage, 0, 1) WITH NOWAIT

				-- EXTRACT STEP AND RECIPE AT THE TIME OFF OCCURRENCE
				;WITH BASE_DATA AS
				(
					SELECT ER.[MaterialId], ER.[OrderOperationStart], ER.[OrderOperationEnd], MH.[StepId], MH.[CurrentRecipeInstance]
						, DENSE_RANK() OVER (PARTITION BY ER.[MaterialId], ER.[OrderOperationStart], ER.[OrderOperationEnd] ORDER BY MH.[ModifiedOn], MH.[ServiceHistoryId], MH.[OperationHistorySeq]) [IsFirstRecord]
					FROM #EligibleRecords ER
					INNER JOIN [Staging].[ODS_T_MaterialHistory] MH ON MH.[ServiceHistoryId] BETWEEN @MinServiceHistoryId AND @MaxServiceHistoryId
						AND MH.[ModifiedOn] BETWEEN ER.[OrderOperationStart] AND ER.[OrderOperationEnd]
						AND MH.[MaterialId] = ER.[MaterialId]
				), FINAL_DATA AS
				(
					SELECT DISTINCT BD.[MaterialId], BD.[OrderOperationStart], BD.[OrderOperationEnd], BD.[StepId], BD.[CurrentRecipeInstance]
					FROM BASE_DATA BD
					WHERE BD.[IsFirstRecord] = 1
				)
				UPDATE ER
				SET ER.[StepId] = FD.[StepId]
					, ER.[OrderRecipeInstanceId] = FD.[CurrentRecipeInstance]
				FROM #EligibleRecords ER
				INNER JOIN FINAL_DATA FD ON FD.[MaterialId] = ER.[MaterialId] AND FD.[OrderOperationStart] = ER.[OrderOperationStart] AND FD.[OrderOperationEnd] = ER.[OrderOperationEnd]

				SET @RowsAffected = @@ROWCOUNT
				SET @ExecutionTimeInSeconds = DATEDIFF(SECOND, @ExecutionControlTS, GETDATE())
				SET @LogMessage = REPLACE(REPLACE(@LogMessageTemplateEnd, N'%ExecutionTime%', CONVERT(NVARCHAR, @ExecutionTimeInSeconds)), N'%RowsAffected%', CONVERT(NVARCHAR, @RowsAffected))
				RAISERROR(@LogMessage, 0, 1) WITH NOWAIT

				SET @ExecutionControlTS = GETDATE()
				SET @LogMessage = REPLACE(@LogMessageTemplateStart, N'%TaskName%' , + N'Extract Setpoint if defined...')
				RAISERROR (@LogMessage, 0, 1) WITH NOWAIT

				-- EXTRACT SET POINT VALUE IF DEFINED
				;WITH BASE_DATA AS
				(
					SELECT ER.[MaterialId]
						, ER.[OrderOperationStart]
						, ER.[OrderOperationEnd]
						, RIP.[Value] [OrderSetpoint]
						, P.[DataUnit] [OrderSetpointUnits]
					FROM #EligibleRecords ER
					INNER JOIN [Custom].[ODS_T_RecipeInstance] RI ON RI.[RecipeInstanceId] = ER.[OrderRecipeInstanceId]
					INNER JOIN [Custom].[ODS_T_RecipeInstanceParameter] RIP ON RIP.[SourceEntityId] = RI.[RecipeInstanceId]
					INNER JOIN [Staging].[ODS_T_Parameter] P ON P.[ParameterId] = RIP.[TargetEntityId]
					WHERE P.[Name] = @SetpointParameter
				)
				UPDATE ER
				SET ER.[OrderSetpoint] = BD.[OrderSetpoint]
					, ER.[OrderSetpointUnits] = BD.[OrderSetpointUnits]
				FROM BASE_DATA BD
				INNER JOIN #EligibleRecords ER ON ER.[MaterialId] = BD.[MaterialId] AND ER.[OrderOperationStart] = BD.[OrderOperationStart] AND ER.[OrderOperationEnd] = BD.[OrderOperationEnd]

				SET @RowsAffected = @@ROWCOUNT
				SET @ExecutionTimeInSeconds = DATEDIFF(SECOND, @ExecutionControlTS, GETDATE())
				SET @LogMessage = REPLACE(REPLACE(@LogMessageTemplateEnd, N'%ExecutionTime%', CONVERT(NVARCHAR, @ExecutionTimeInSeconds)), N'%RowsAffected%', CONVERT(NVARCHAR, @RowsAffected))
				RAISERROR(@LogMessage, 0, 1) WITH NOWAIT
			END

			-- SPREAD OCCURRENCE BETWEEN ALL AFFECTED SHIFTS
			BEGIN

				SET @ExecutionControlTS = GETDATE()
				SET @LogMessage = REPLACE(@LogMessageTemplateStart, N'%TaskName%' , + N'Spread operation occurrence between all shifts it passes by...')
				RAISERROR (@LogMessage, 0, 1) WITH NOWAIT

				;WITH BASE_DATA AS
				(
					SELECT ER.[MaterialId]
						, ER.[ResourceId]
						, ER.[AreaId]
						, ER.[FacilityId]
						, ER.[ProductId]
						, ER.[StepId]
						, ER.[OrderRunNumber]
						, CASE WHEN FS.[StartDateTime] > ER.[OrderOperationStart]
								THEN FS.[StartDateTime]
								ELSE ER.[OrderOperationStart]
								END [OrderOperationStart]
						, CASE WHEN FS.[EndDateTime] < ER.[OrderOperationEnd]
								THEN FS.[EndDateTime]
								ELSE ER.[OrderOperationEnd]
								END [OrderOperationEnd]
						, ER.[OrderScheduledQuantity]
						, ER.[ServiceHistoryId]
						, ER.[OperationHistorySeq]
						, FS.[ShiftKey]
						, ER.[OrderSetpointInMinutes]
					FROM #EligibleRecords ER
					LEFT JOIN [dbo].[DimArea] DA ON DA.[AreaId] = ER.[AreaId]
					LEFT JOIN [dbo].[FactShift] FS ON FS.[AreaKey] = DA.[AreaKey]
						AND (
								(FS.[StartDateTime] >= ER.[OrderOperationStart] AND (FS.[StartDateTime] < ER.[OrderOperationEnd] OR FS.[EndDateTime] < ER.[OrderOperationEnd]))
								OR
								(FS.[StartDateTime] <= ER.[OrderOperationStart] AND FS.[EndDateTime] > ER.[OrderOperationEnd])
								OR
								(FS.[EndDateTime] >  ER.[OrderOperationStart] AND FS.[EndDateTime] < ER.[OrderOperationEnd])
						)
				)
				-- PICK ALL ERP OPERATIONS FINISHED WITHIN TIMEFRAME AND SHIFT
				INSERT INTO #OrderShiftSplitRecords([UID], [MaterialId], [MaterialKey], [ProductKey], [StepKey], [ResourceKey], [AreaKey], [FacilityKey], [ShiftKey]
													, [OrderRunNumber], [OrderOperationStart], [OrderOperationEnd], [OrderScheduledQuantity],[ServiceHistoryId]
													, [OrderSetpointInMinutes], [OrderOperationStartLC1])
				-- CREATE ROW UID TO CORRELATE WITH PALLETS PRODUCED AFTER
				SELECT DENSE_RANK() OVER (ORDER BY M.[MaterialId], ER.[ResourceId], ER.[OrderRunNumber], ER.[OrderOperationStart])
					, ER.[MaterialId]
					, DM.[MaterialKey]
					, DP.[ProductKey]
					, DS.[StepKey]
					, DR.[ResourceKey]
					, DA.[AreaKey]
					, DF.[FacilityKey]
					, ER.[ShiftKey]
					, ER.[OrderRunNumber]
					, ER.[OrderOperationStart]
					, ER.[OrderOperationEnd]
					-- ORDER SCHEDULED QUANTITY FOR REFERENCE
					, ER.[OrderScheduledQuantity]
					-- STORE DATE OF CREATION AND LAST MODIFICATION TO DETERMINE INTERNAL MIN AND MAX SERVICE HISTORY IDS WHEN SWEWPING HISTORY
					, ER.[ServiceHistoryId]
					, ER.[OrderSetpointInMinutes]
					, [DateTimeUtil].[UDF_ConvertUtcToLocalByTimezoneIdentifier] (@LC1TimeZoneIdentifier, ER.[OrderOperationStart])
				FROM BASE_DATA ER
				INNER JOIN [Staging].[ODS_T_Material] M ON M.[MaterialId] = ER.[MaterialId]
				--INNER JOIN [Staging].[ODS_T_Resource] R ON R.[ResourceId] = ER.[ResourceId]
				LEFT JOIN [DimMaterial] DM ON DM.[MaterialId] = M.[MaterialId] AND DM.[Form] = @MaterialOrderForm
				LEFT JOIN [dbo].[DimArea] DA ON DA.[AreaId] = ER.[AreaId]
				LEFT JOIN [dbo].[DimFacility] DF ON DF.[FacilityId] = ER.[FacilityId]
				LEFT JOIN [dbo].[DimResource] DR ON DR.[ResourceId] = ER.[ResourceId]
				LEFT JOIN [dbo].[DimProduct] DP ON DP.[ProductId] = M.[ProductId]
				LEFT JOIN [dbo].[DimStep] DS ON DS.[StepId] = ER.[StepId]
				WHERE (
							(ER.[ServiceHistoryId] > DM.[StartServiceHistoryId] AND ER.[ServiceHistoryId] < DM.[EndServiceHistoryId])
							OR (ER.[ServiceHistoryId] = DM.[StartServiceHistoryId] AND ER.[OperationHistorySeq] >= DM.[StartOperationHistorySeq])
							OR (ER.[ServiceHistoryId] = DM.[EndServiceHistoryId] AND ER.[OperationHistorySeq] <= DM.[EndOperationHistorySeq])
						)


				SET @RowsAffected = @@ROWCOUNT
				SET @ExecutionTimeInSeconds = DATEDIFF(SECOND, @ExecutionControlTS, GETDATE())
				SET @LogMessage = REPLACE(REPLACE(@LogMessageTemplateEnd, N'%ExecutionTime%', CONVERT(NVARCHAR, @ExecutionTimeInSeconds)), N'%RowsAffected%', CONVERT(NVARCHAR, @RowsAffected))
				RAISERROR(@LogMessage, 0, 1) WITH NOWAIT

			END

			-- EXTRACT MIN AND MAX MATERIAL SERVICE HISTORY IDS FROM ELIGIBLE MATERIALS TO THEN EXTRACT INTERNAL SERVICE HISTORY ID RANGE
			SELECT @MaterialMinServiceHistoryId = [dbo].[F_GetMinServiceHistoryIdForDate](MIN(ER.[OrderOperationStart]))
				, @MaterialMaxServiceHistoryId = [dbo].[F_GetMaxServiceHistoryIdForDate](MAX(ER.[OrderOperationEnd]))
			FROM #EligibleRecords ER
		
			-- COLLECT GENERATED QUANTITIES WITHIN ORDER RUN
			BEGIN

				SET @ExecutionControlTS = GETDATE()
				SET @LogMessage = REPLACE(@LogMessageTemplateStart, N'%TaskName%' , + N'Collect Generated Quantities within order run...')
				RAISERROR (@LogMessage, 0, 1) WITH NOWAIT

				INSERT INTO #OrderRunGeneratedPallets([UID], [GeneratedPalletId], [GeneratedPalletName], [GeneratedQuantity], [OrderRunNumber], [PalletGenerationTimestamp])
				-- GET ALL PALLETS GENERATED FROM WITHIN A GIVEN ORDER AND RUN AND LOG UID FOR CORRELATION LATER
				SELECT DISTINCT ER.[UID]
					, MH.[MaterialId]		[GeneratedPalletId]
					, MH.[Name]				[GeneratedPalletName]
					, MH.[PrimaryQuantity]	[GeneratedQuantity]
					, MAH.[Value]			[OrderRunNumber]
					, MH.[ModifiedOn]		[PalletGenerationTimestamp]
				FROM #OrderShiftSplitRecords ER
				-- LINK WITH BATCH HISTORY WITHIN RANGE OF SERVICE HISTORY IDS
				INNER JOIN [Custom].[ODS_T_CustomMaterialBatchHistory] CMB ON CMB.[ServiceHistoryId] BETWEEN @MaterialMinServiceHistoryId AND @MaterialMaxServiceHistoryId
					-- ONLY GET RECORDS FOR ELIGIBLE PALLETS COMING FROM ELIGIBLE ORDER MATERIAL IDS
					AND CMB.[TargetEntityId] = ER.[MaterialId]
					-- MUST BE A PALLET GENERATED FROM WITHIN THE ORDER
					AND CMB.[IsParentBatch] = 1
					-- GET CREATION EVENT ONLY TO DETERMINE MOMENT OF GENERATION OF PALLET IF REQUIRED TO SPLIT BY SHIFT
					AND CMB.[DatabaseOperation] = 0
					-- GET ONLY PALLETS GENERATED FROM WITHIN THE ORDER TIME FRAME
					AND CMB.[ModifiedOn] BETWEEN ER.[OrderOperationStart] AND ER.[OrderOperationEnd]
				-- LINK WITH MATERIAL HISTORY WITHIN RANGE OF SERVICE HISTORY IDS
				INNER JOIN [Staging].[ODS_T_MaterialHistory] MH ON MH.[ServiceHistoryId] BETWEEN @MaterialMinServiceHistoryId AND @MaterialMaxServiceHistoryId
					-- ONLY GET RECORDS FOR ELIGIBLE PALLETS COMING FROM BATCH RELATIONS
					AND MH.[MaterialId] = CMB.[SourceEntityId]
					-- GET CREATION EVENT ONLY TO ACCOUNT FOR ACTUAL QUANTITY AT THAT MOMENT
					AND MH.[DatabaseOperation] = 0
				-- LINK WITH MATERIAL ATTRIBUTE HISTORY FOR THE PALLET GENEARATION EVENT SERVICE HISTORY ID
				LEFT JOIN [Staging].[ODS_T_MaterialAttributeHistory] MAH ON MAH.[ServiceHistoryId] = MH.[ServiceHistoryId]
					-- ONLY GET RECORDS FOR ELIGIBLE PALLETS COMING MATERIAL HISTORY ABOVE
					AND MAH.[MaterialId] = MH.[MaterialId]
					-- ONLY GET RECORDS FOR THE ORDER RUN NUMBER ATTRIBUTE
					AND MAH.[EntityTypePropertyId] = @OrderRunAttributeId

				-- AGGREGATE DATE PER UID - ORDER RUN OCCURRENCE
				INSERT INTO #OrderRunGeneratedPalletsSummary([UID], [GeneratedQuantity])
				SELECT ORGP.[UID], SUM(ORGP.[GeneratedQuantity])
				FROM #OrderRunGeneratedPallets ORGP
				GROUP BY ORGP.[UID]

				SET @RowsAffected = @@ROWCOUNT
				SET @ExecutionTimeInSeconds = DATEDIFF(SECOND, @ExecutionControlTS, GETDATE())
				SET @LogMessage = REPLACE(REPLACE(@LogMessageTemplateEnd, N'%ExecutionTime%', CONVERT(NVARCHAR, @ExecutionTimeInSeconds)), N'%RowsAffected%', CONVERT(NVARCHAR, @RowsAffected))
				RAISERROR(@LogMessage, 0, 1) WITH NOWAIT

			END

			-- PROCESSING TIME EXTRACTION
			BEGIN

				SET @ExecutionControlTS = GETDATE()
				SET @LogMessage = REPLACE(@LogMessageTemplateStart, N'%TaskName%' , + N'Get Material History within timeframes to extract actual processing times...')
				RAISERROR (@LogMessage, 0, 1) WITH NOWAIT

				-- GET MATERIAL HISTORY WITHIN TIMEFRAMES TO EXTRACT ACTUAL PROCESSING TIMES
				INSERT INTO #MaterialStates([UID], [MaterialId], [ModifiedOn], [ServiceHistoryId], [OperationHistorySeq], [StateModelState], [MaterialHistoryOrder], [IsProcessingState], [PrevHistoryRecordTimeStamp], [NextHistoryRecordTimeStamp])
				SELECT OSSR.[UID], MH.[MaterialId], MH.[ModifiedOn], MH.[ServiceHistoryId], MH.[OperationHistorySeq], SMS.[Name]
					, DENSE_RANK() OVER (PARTITION BY MH.[MaterialId] ORDER BY MH.[ModifiedOn], MH.[ServiceHistoryId], MH.[OperationHistorySeq])
					, CASE WHEN VIIP.[StateName] IS NULL THEN 0 ELSE 1 END /* IsProcessingState */
					-- GET PREVIOUS AND NEXT HISTORY RECORD TIMESTAMP TO KNOW WHEN THE ACTUAL ONE FINISHES
					, LAG(MH.[ModifiedOn]) OVER (PARTITION BY MH.[MaterialId] ORDER BY MH.[ModifiedOn], MH.[ServiceHistoryId], MH.[OperationHistorySeq]) [PrevHistoryRecordTimeStamp]
					, LEAD(MH.[ModifiedOn]) OVER (PARTITION BY MH.[MaterialId] ORDER BY MH.[ModifiedOn], MH.[ServiceHistoryId], MH.[OperationHistorySeq]) [NextHistoryRecordTimeStamp]
				FROM #OrderShiftSplitRecords OSSR
				INNER JOIN [Staging].[ODS_T_MaterialHistory] MH ON MH.[MaterialId] = OSSR.[MaterialId]
				LEFT JOIN [Staging].[ODS_T_StateModelState] SMS ON SMS.[StateModelStateId] = MH.[MainStateModelStateId]
				LEFT JOIN #ValidInProcessStates VIIP ON VIIP.[StateName] = SMS.[Name]
				-- MAKE USE OF PARTIONING FILTERING
				WHERE MH.[ServiceHistoryId] BETWEEN @MaterialMinServiceHistoryId AND @MaterialMaxServiceHistoryId
					AND MH.[ModifiedOn] BETWEEN OSSR.[OrderOperationStart] AND OSSR.[OrderOperationEnd]

				SET @RowsAffected = @@ROWCOUNT
				SET @ExecutionTimeInSeconds = DATEDIFF(SECOND, @ExecutionControlTS, GETDATE())
				SET @LogMessage = REPLACE(REPLACE(@LogMessageTemplateEnd, N'%ExecutionTime%', CONVERT(NVARCHAR, @ExecutionTimeInSeconds)), N'%RowsAffected%', CONVERT(NVARCHAR, @RowsAffected))
				RAISERROR(@LogMessage, 0, 1) WITH NOWAIT
				
				SET @ExecutionControlTS = GETDATE()
				SET @LogMessage = REPLACE(@LogMessageTemplateStart, N'%TaskName%' , + N'Update records marking state context change...')
				RAISERROR (@LogMessage, 0, 1) WITH NOWAIT

				-- UPDATE RECORDS MARKING STATE CONTEXT CHANGE, WHEN SWITCHING FROM PROCESSING STATE BLOCK TO NON PROCESSING STATE BLOCK AND VICE VERSA
				;WITH BASE_DATA AS
				(
					SELECT MS.[MaterialId], MS.[MaterialHistoryOrder]
						-- GET IF CURRENT RECORD IS MARKING THE START OF A NEW SETUP/NON SETUP BLOCK, TO BE USED IN PUTTING ALL RECORDS WITHIN SAME BLOCK AS ONE
						, CASE WHEN ISNULL((LAG(MS.[IsProcessingState]) OVER (PARTITION BY MS.[MaterialId] ORDER BY MS.[MaterialHistoryOrder])), N'') <> MS.[IsProcessingState]
							THEN [MaterialHistoryOrder]
							ELSE NULL
							END [ProcessingStateChangeMarker]
						-- INDICATE IF RECORD MARKS A PROCESSING STATE CHANGE OR NOT
						, LAG([IsProcessingState]) OVER (PARTITION BY MS.[MaterialId] ORDER BY MS.[MaterialHistoryOrder]) [PreviousIsProcessingState]
					FROM #MaterialStates MS
				)
				UPDATE TRG
				SET TRG.[StateBlockOrder] = BD.[ProcessingStateChangeMarker]
					, TRG.[PreviousIsProcessingState] = BD.[PreviousIsProcessingState]
				FROM #MaterialStates TRG
				INNER JOIN BASE_DATA BD ON BD.[MaterialId] = TRG.[MaterialId]
					AND BD.[MaterialHistoryOrder] = TRG.[MaterialHistoryOrder]

				SET @RowsAffected = @@ROWCOUNT
				SET @ExecutionTimeInSeconds = DATEDIFF(SECOND, @ExecutionControlTS, GETDATE())
				SET @LogMessage = REPLACE(REPLACE(@LogMessageTemplateEnd, N'%ExecutionTime%', CONVERT(NVARCHAR, @ExecutionTimeInSeconds)), N'%RowsAffected%', CONVERT(NVARCHAR, @RowsAffected))
				RAISERROR(@LogMessage, 0, 1) WITH NOWAIT
				
				SET @ExecutionControlTS = GETDATE()
				SET @LogMessage = REPLACE(@LogMessageTemplateStart, N'%TaskName%' , + N'Group history records within same process block...')
				RAISERROR (@LogMessage, 0, 1) WITH NOWAIT


				-- UPDATE ALL ROWS WITHIN SAME LOGICAL PROCESSING STATE BLOCK
				;WITH BASE_DATA AS
				(
					SELECT MS.[MaterialId], MS.[MaterialHistoryOrder]
						-- GET MAXIMUM PROCESSING BLOCK IDENTIFIER TO UPDATE THE ROW WITH ITS ACTUAL BLOCK NUMBER
						, ISNULL(MAX([StateBlockOrder]) OVER (PARTITION BY MS.[MaterialId] ORDER BY MS.[MaterialHistoryOrder] ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW), 1) [NewStateBlockOrder]
					FROM #MaterialStates MS
				)
				UPDATE TRG
				SET TRG.[StateBlockOrder] = BD.[NewStateBlockOrder]			
				FROM #MaterialStates TRG
				INNER JOIN BASE_DATA BD ON BD.[MaterialId] = TRG.[MaterialId]
					AND BD.[MaterialHistoryOrder] = TRG.[MaterialHistoryOrder]

								SET @RowsAffected = @@ROWCOUNT
				SET @ExecutionTimeInSeconds = DATEDIFF(SECOND, @ExecutionControlTS, GETDATE())
				SET @LogMessage = REPLACE(REPLACE(@LogMessageTemplateEnd, N'%ExecutionTime%', CONVERT(NVARCHAR, @ExecutionTimeInSeconds)), N'%RowsAffected%', CONVERT(NVARCHAR, @RowsAffected))
				RAISERROR(@LogMessage, 0, 1) WITH NOWAIT
				
				SET @ExecutionControlTS = GETDATE()
				SET @LogMessage = REPLACE(@LogMessageTemplateStart, N'%TaskName%' , + N'Ensure correct timestamps are used for determining full inprocess duration...')
				RAISERROR (@LogMessage, 0, 1) WITH NOWAIT

				-- ENSURE CORRECT TIMESTAMPS ARE USED FOR DETERMINING FULL IN PROCESS DURATION.
				-- IF AN EVEN OCCURS WITHIN A SHIFT BUT PREVIOUS RECORD FALLS WITHIN THE SHIFT BEFORE,
				-- CHECK IF THE AMOUNT OF TIME IN BETWEEN, STARTING SINCE THE BEGINNING OF THE SHIFT OR OPERATION SHOULD NOT 
				-- BE ADDED OF THE GAP BETWEEN SHIFT START AND HISTORY RECORD
				;WITH BASE_DATA AS
				(
					SELECT OSSR.[UID], OSSR.[MaterialId], MS.[StateBlockOrder], MS.[IsProcessingState]
						--, OSSR.[ShiftKey], OSSR.[OrderOperationStart], OSSR.[OrderOperationEnd], OSSR.[Shiftkey]
						--, MS.[MaterialHistoryOrder], MS.[StateModelState], MS.[IsProcessingState], MS.[StateBlockOrder]
						--, MS.[PrevHistoryRecordTimeStamp], MS.[ModifiedOn], MS.[NextHistoryRecordTimeStamp]
						, CASE WHEN MS.[PreviousIsProcessingState] IS NULL
								THEN MS.[ModifiedOn]
							WHEN MS.[PreviousIsProcessingState] <> MS.[IsProcessingState]
								THEN MS.[ModifiedOn]
							WHEN MS.[PreviousIsProcessingState] = MS.[IsProcessingState]
								THEN (
										CASE WHEN MS.[ModifiedOn] > OSSR.[OrderOperationStart] AND MS.[PrevHistoryRecordTimeStamp] < OSSR.[OrderOperationStart]
											THEN OSSR.[OrderOperationStart]
											ELSE MS.[ModifiedOn] END
									)
							ELSE MS.[ModifiedOn]
							END [FinalHistoryEventStart]
						, CASE WHEN ISNULL(MS.[NextHistoryRecordTimeStamp], OSSR.[OrderOperationEnd]) >= OSSR.[OrderOperationEnd] THEN OSSR.[OrderOperationEnd]
							ELSE MS.[NextHistoryRecordTimeStamp]
							END [FinalHistoryEventEnd]
					FROM #OrderShiftSplitRecords OSSR
					LEFT JOIN #MaterialStates MS ON OSSR.[UID] = MS.[UID]
				), STATE_BLOCK_DETAILS AS
				(
					SELECT BD.[UID]
						, DATEDIFF(MILLISECOND, MIN(BD.[FinalHistoryEventStart]), MAX(BD.[FinalHistoryEventEnd])) / 60000.0 [ElapsedTimeMinutes]
					FROM BASE_DATA BD
					WHERE BD.[IsProcessingState] = 1
					GROUP BY BD.[UID], BD.[MaterialId], BD.[StateBlockOrder]
				)
				INSERT INTO #OrderRunProcessingTime([UID], [ProcessingTimeInMinutes])
				SELECT SBD.[UID], SUM([ElapsedTimeMinutes])
				FROM STATE_BLOCK_DETAILS SBD
				GROUP BY SBD.[UID]

				SET @RowsAffected = @@ROWCOUNT
				SET @ExecutionTimeInSeconds = DATEDIFF(SECOND, @ExecutionControlTS, GETDATE())
				SET @LogMessage = REPLACE(REPLACE(@LogMessageTemplateEnd, N'%ExecutionTime%', CONVERT(NVARCHAR, @ExecutionTimeInSeconds)), N'%RowsAffected%', CONVERT(NVARCHAR, @RowsAffected))
				RAISERROR(@LogMessage, 0, 1) WITH NOWAIT

			END

			-- COLLECT IDEAL CYCLE TIMES
			BEGIN

				SET @ExecutionControlTS = GETDATE()
				SET @LogMessage = REPLACE(@LogMessageTemplateStart, N'%TaskName%' , + N'Prepare temp table to collect ideal cycle times...')
				RAISERROR (@LogMessage, 0, 1) WITH NOWAIT

				;WITH BASE_DATA AS
				(
					SELECT DISTINCT OSSR.[ResourceKey], OSSR.[StepKey], OSSR.[ProductKey]
						, DR.[ResourceName], DR.[ResourceType], DR.[Model] [ResourceModel], DS.[StepName], DP.[ProductName], DPG.[ProductGroupName]
					FROM #OrderShiftSplitRecords OSSR
					INNER JOIN [dbo].[DimProduct] DP ON DP.[ProductKey] = OSSR.[ProductKey]
					INNER JOIN [dbo].[DimProductGroup] DPG ON DPG.[ProductGroupKey] = DP.[ProductGroupKey]
					INNER JOIN [dbo].[DimResource] DR ON DR.[ResourceKey] = OSSR.[ResourceKey]
					INNER JOIN [dbo].[DimStep] DS ON DS.[StepKey] = OSSR.[StepKey]
				)
				SELECT DENSE_RANK() OVER(ORDER BY BD.[StepKey], BD.[ProductKey], BD.[ResourceKey]) [RowNumber]
				, 'INSERT INTO #ExpectedCycleTime([StepKey], [ProductKey], [ResourceKey], [TimeScale], [TimePerUnit]) '
				+ 'SELECT ' + CONVERT(NVARCHAR, BD.[StepKey]) 
						+ ', ' + CONVERT(NVARCHAR, BD.[ProductKey]) 
						+ ', ' + CONVERT(NVARCHAR, BD.[ResourceKey]) 
						+ ', [TimeScale] '
						+ ', [TimePerUnit] '
					+ 'FROM OPENQUERY(' + @OnlineLink 
						+ ', ''' + ('SELECT * FROM [' + @SystemName +'].[CoreDataModel].[F_ST_ResolveResourceIdealCycleTime](1,''''' 
							+ ISNULL(BD.[ResourceName], N'') + ''''',''''' 
							+ ISNULL(BD.[ResourceType], N'') + ''''',''''' 
							+ ISNULL(BD.[ResourceModel], N'') + ''''',''''' 
							+ ISNULL(BD.[StepName], N'') + ''''',''''' 
							+ ISNULL(BD.[ProductName], N'') + ''''',''''' 
							+ ISNULL(BD.[ProductGroupName], N'') + ''''')'')') [QueryToExecute]
				INTO #FactProductSetupTimeTemp
				FROM BASE_DATA BD

				SET @RowsAffected = @@ROWCOUNT
				SET @ExecutionTimeInSeconds = DATEDIFF(SECOND, @ExecutionControlTS, GETDATE())
				SET @LogMessage = REPLACE(REPLACE(@LogMessageTemplateEnd, N'%ExecutionTime%', CONVERT(NVARCHAR, @ExecutionTimeInSeconds)), N'%RowsAffected%', CONVERT(NVARCHAR, @RowsAffected))
				RAISERROR(@LogMessage, 0, 1) WITH NOWAIT

				SET @ExecutionControlTS = GETDATE()
				SET @LogMessage = REPLACE(@LogMessageTemplateStart, N'%TaskName%' , + N'Resolve cycle times...')
				RAISERROR (@LogMessage, 0, 1) WITH NOWAIT
				
				-- GO LINE BY LINE AND TRY TO OBTAIN ESTIMATED SETUP TIMES
				DECLARE @Iterator				BIGINT = 1
				DECLARE @RowCount				BIGINT = (SELECT COUNT(1) FROM #FactProductSetupTimeTemp)
				DECLARE @SqlStatementToExecute	NVARCHAR(MAX)
				WHILE(@Iterator <= @RowCount)
				BEGIN
					SELECT @SqlStatementToExecute = [QueryToExecute] FROM #FactProductSetupTimeTemp WHERE [RowNumber] = @Iterator
					EXEC sp_executesql @SqlStatementToExecute

					SET @Iterator = @Iterator + 1
				END

				SET @ExecutionTimeInSeconds = DATEDIFF(SECOND, @ExecutionControlTS, GETDATE())
				SET @LogMessage = REPLACE(REPLACE(@LogMessageTemplateEnd, N'%ExecutionTime%', CONVERT(NVARCHAR, @ExecutionTimeInSeconds)), N'%RowsAffected%', CONVERT(NVARCHAR, @RowsAffected))
				RAISERROR(@LogMessage, 0, 1) WITH NOWAIT
			END

			-- LOAD DATA INTO FINAL FACT TABLE
			BEGIN
				SET @ExecutionControlTS = GETDATE()
				SET @LogMessage = REPLACE(@LogMessageTemplateStart, N'%TaskName%' , + N'Load data into [Custom].[FactOrderCycleTime]...')
				RAISERROR (@LogMessage, 0, 1) WITH NOWAIT
				
				MERGE INTO [Custom].[FactOrderCycleTime] TRG
				USING (
					SELECT OSSR.[FacilityKey]
						, OSSR.[AreaKey]
						, OSSR.[ResourceKey]
						, OSSR.[ShiftKey]
						, CAST(CONVERT(NVARCHAR(8), OSSR.[OrderOperationStart], 112) AS INTEGER) AS [DateKey]
						, DATEPART(HH, OSSR.[OrderOperationStart]) * (10000) + DATEPART(MI, OSSR.[OrderOperationStart]) * (100) + DATEPART(SS, OSSR.[OrderOperationStart]) [TimeKey]
						, CAST(CONVERT(NVARCHAR(8), OSSR.[OrderOperationStartLC1], 112) AS INTEGER) AS [LC1DateKey]
						, DATEPART(HH, OSSR.[OrderOperationStartLC1]) * (10000) + DATEPART(MI, OSSR.[OrderOperationStartLC1]) * (100) + DATEPART(SS, OSSR.[OrderOperationStartLC1]) [LC1TimeKey]
						, OSSR.[MaterialKey]
						, OSSR.[OrderRunNumber] [RunNumber]
						, OSSR.[ProductKey]
						, OSSR.[ServiceHistoryId]
						-- VALUE COLUMNS
						, ORGP.[GeneratedQuantity] [QuantityProduced]
						, ORPT.[ProcessingTimeInMinutes] [ProcessingTime]
						, ORPT.[ProcessingTimeInMinutes] / ORGP.[GeneratedQuantity] [ActualCycleTime]
						, ECT.[TimePerUnitMinutes] [IdealCycleTime]
						, OSSR.[OrderSetpointInMinutes] [SetPoint]
					FROM #OrderShiftSplitRecords OSSR
					LEFT JOIN #OrderRunGeneratedPalletsSummary ORGP ON ORGP.[UID] = OSSR.[UID]
					LEFT JOIN #OrderRunProcessingTime ORPT ON ORPT.[UID] = OSSR.[UID]
					LEFT JOIN #ExpectedCycleTime ECT ON ECT.[StepKey] = OSSR.[StepKey]
						AND ECT.[ProductKey] = OSSR.[ProductKey]
						AND ECT.[ResourceKey] = OSSR.[ResourceKey]
					WHERE ORGP.[GeneratedQuantity] > 0
				) SRC ON (TRG.[FacilityKey] = SRC.[FacilityKey]
							AND TRG.[AreaKey] = SRC.[AreaKey]
							AND TRG.[ResourceKey] = SRC.[ResourceKey]
							AND TRG.[MaterialKey] = SRC.[MaterialKey]
							AND TRG.[RunNumber] = SRC.[RunNumber]
							AND TRG.[ProductKey] = SRC.[ProductKey]
							AND TRG.[ShiftKey] = SRC.[ShiftKey]
							AND TRG.[TimeKey] = SRC.[TimeKey]
							AND TRG.[DateKey] = SRC.[DateKey])
				WHEN MATCHED THEN UPDATE SET TRG.[QuantityProduced] = SRC.[QuantityProduced]
							, TRG.[ProcessingTime] = SRC.[ProcessingTime]
							, TRG.[ActualCycleTime] = SRC.[ActualCycleTime]
							, TRG.[IdealCycleTime] = SRC.[IdealCycleTime]
							, TRG.[SetPoint] = SRC.[SetPoint]
				WHEN NOT MATCHED THEN INSERT([FacilityKey], [AreaKey], [ResourceKey], [ShiftKey], [DateKey], [TimeKey]
												, [LC1DateKey], [LC1TimeKey], [MaterialKey], [RunNumber], [ProductKey]
												, [ServiceHistoryId], [QuantityProduced], [ProcessingTime], [ActualCycleTime]
												, [IdealCycleTime], [SetPoint])
									VALUES(SRC.[FacilityKey], SRC.[AreaKey], SRC.[ResourceKey], SRC.[ShiftKey], SRC.[DateKey], SRC.[TimeKey]
												, SRC.[LC1DateKey], SRC.[LC1TimeKey], SRC.[MaterialKey], SRC.[RunNumber], SRC.[ProductKey]
												, SRC.[ServiceHistoryId], SRC.[QuantityProduced], SRC.[ProcessingTime], SRC.[ActualCycleTime]
												, SRC.[IdealCycleTime], SRC.[SetPoint]);

				SET @RowsAffected = @@ROWCOUNT
				SET @ExecutionTimeInSeconds = DATEDIFF(SECOND, @ExecutionControlTS, GETDATE())
				SET @LogMessage = REPLACE(REPLACE(@LogMessageTemplateEnd, N'%ExecutionTime%', CONVERT(NVARCHAR, @ExecutionTimeInSeconds)), N'%RowsAffected%', CONVERT(NVARCHAR, @RowsAffected))
				RAISERROR(@LogMessage, 0, 1) WITH NOWAIT
			END

		END

		SET @LogMessage = @ProcedureName + N': '  + CONVERT(NVARCHAR, @RowsAffected) + N' row(s) merged into [Custom].[P_LoadFactOrderCycleTimes]'
		EXEC Control.P_StopExecution @ProcedureName, @LogMessage;
		
		IF @StartTranCount = 0
			COMMIT

	END TRY
	BEGIN CATCH

		-- ROLLBACK TRANSACTION IF EXECUTING AUTONOMOUSLY
		IF XACT_STATE() <> 0 AND @StartTranCount = 0 
			ROLLBACK TRANSACTION

		-- LOG STOPING OF EXECUTION
		EXEC Control.P_StopExecution @ProcedureName

		-- GET ERROR AND RE-RAISE IT
		SELECT @ErrorMessage = ERROR_MESSAGE() + ' Line ' + cast(ERROR_LINE() AS nvarchar(5)), @ErrorSeverity = ERROR_SEVERITY(), @ErrorState = ERROR_STATE();
		RAISERROR (@ErrorMessage, @ErrorSeverity, @ErrorState);

	END CATCH
END


GO