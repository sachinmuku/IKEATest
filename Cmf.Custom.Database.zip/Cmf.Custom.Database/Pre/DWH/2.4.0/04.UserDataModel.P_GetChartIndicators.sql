/******************************
** Name: UserDataModel.P_GetChartIndicators
** Description: Procedure to get the charts indicators: Cp and Cpk on a date time range and chart violations
** Author: Paulo Soares
** Date: 3-Mar-2021
**************************

** Version History

** Version  Date          Author                       Description 
** ---------------------------------------------------------------------------------------------------------------------------------------------                    
** Sprint 4  3/Mar/2021  Paulo S.                      Get the charts indicators: Cp and Cpk, on a date time range and also the chart violations 
*/
CREATE OR ALTER   PROCEDURE [UserDataModel].[P_GetChartIndicators]
 @DateStart   DATE,
 @DateEnd     DATE,
 @ChartId    NVARCHAR(MAX),
 @ResourceKey NVARCHAR(MAX),
 @ShiftKey    NVARCHAR(MAX)
AS

BEGIN

--DECLARE @DateStart   DATE ='2021-03-03'
--DECLARE @DateEnd     DATE ='2021-03-06'
--DECLARE @ChartId    NVARCHAR(MAX) ='2101150000130000008'
--DECLARE @ResourceKey NVARCHAR(MAX) = 143
--DECLARE @ShiftKey    NVARCHAR(MAX) = NULL

SET NOCOUNT ON;

DECLARE @DateStartInt INT= CONVERT(INT, CONVERT(VARCHAR(8), @DateStart, 112))
DECLARE @DateEndInt   INT= CONVERT(INT, CONVERT(VARCHAR(8), @DateEnd, 112))
DECLARE @Deimiter     VARCHAR(1)=','

IF(object_id('tempdb..#Charts') is not null)    DROP TABLE #Charts
IF(object_id('tempdb..#Resources') is not null) DROP TABLE #Resources
IF(object_id('tempdb..#AreaKeys') is not null)  DROP TABLE #AreaKeys
IF(object_id('tempdb..#Shifts') is not null)    DROP TABLE #Shifts

/* Create temporary tables */
CREATE TABLE #Charts    (ChartId BIGINT)
CREATE TABLE #Resources (ResourceKey INT)
CREATE TABLE #AreaKeys  (AreaKey INT)
CREATE TABLE #Shifts    (ShiftKey  INT)

/* Temp Table with Charts */
IF LEN(@ChartId) > 0
BEGIN
  INSERT #Charts
  SELECT  *
    FROM [Datasets].[fnSplit](@ChartId, @Deimiter)
END 

/* Temp Table with Resources */
IF LEN(@ResourceKey) > 0
BEGIN
  INSERT #Resources
  SELECT *
    FROM [Datasets].[fnSplit](@ResourceKey,@Deimiter)
END


/* Temp Table with AreaKeys related to the selected resources */
IF LEN(@ResourceKey) > 0
BEGIN
INSERT #AreaKeys
   SELECT AreaKey
         FROM .DimResource DR
         JOIN #Resources   R ON DR.ResourceKey = R.ResourceKey 
        GROUP BY AreaKey
END

/* Temp Table with Shifts */
IF LEN(@ShiftKey) > 0
BEGIN
  INSERT INTO #Shifts
  SELECT item
    FROM [Datasets].[fnSplit](@ShiftKey,@Deimiter)
END



/* CTE to collect the Shifts in the time range */
; WITH Shifts AS 
(SELECT DISTINCT 
        DateKey,
        FS.[Day] AS [Date],
        FS.ShiftKey,
        FS.ShiftDefinitionShiftName,
        FS.StartDateTime,
        FS.EndDateTime,
        FS.AreaKey,
        FS.AreaName
   FROM factshift   FS
   JOIN #AreaKeys   A   ON FS.AreaKey= A.AreaKey  
   JOIN DimResource DR  ON A.AreaKey = DR.AreaKey
  WHERE DateKey BETWEEN @DateStartInt AND @DateEndInt
   AND (@ShiftKey IS NULL OR EXISTS (SELECT ShiftKey FROM #Shifts T WHERE FS.ShiftKey = T.ShiftKey))
   AND (@ResourceKey IS NULL OR EXISTS (SELECT ResourceKey FROM #Resources T WHERE DR.ResourceKey = T.ResourceKey))
),
/*CTE to collect the violations occurred in the time range*/
Violations AS 
(SELECT CH.ChartId,
        CH.Name          ChartName,
        CR.Name          RuleName,
        CDP.ModifiedOn   DataPointreadingTime,
        CDP.SampleId,
        SH.DateKey,
        SH.ShiftKey
   FROM Staging.ODS_T_ChartHistory                   CH    
   JOIN Staging.ODS_T_LogicalChart                   LC   ON LC.ChartId = CH.ChartId
   JOIN Staging.ODS_T_ChartDataPoint                 CDP  ON CDP.LogicalChartId = LC.LogicalChartId
   JOIN Staging.ODS_T_ChartDataPointOccurrence  CDPO ON CDPO.ChartDataPointId = CDP.ChartDataPointId
   JOIN Staging.ODS_T_Rule                      CR   ON CDPO.RuleId = CR.RuleId
   JOIN Staging.ODS_T_ChartContextInformation   CCI  ON CCI.ChartId= CCI.ChartId 
                                                       AND  CCI.ContextSource ='Resource'
   JOIN Shifts                                       SH   ON CDP.ModifiedOn BETWEEN SH.StartDateTime AND SH.EndDateTime
                                                         
  WHERE CDP.ModifiedOn BETWEEN @DateStart AND @DateEnd
)

SELECT DISTINCT
       SHI.DateKey,
       SHI.[Date],
       SHI.ShiftKey,
       SHI.ShiftDefinitionShiftName,
       SHI.StartDateTime,
       SHI.EndDateTime,
       SHI.AreaKey,
       SHI.AreaName,
       DATA.ChartKey,
       DATA.ChartId,
       DATA.ChartName,
       DATA.ResourceKey,
       DR.ResourceName,
       DATA.ChartStartDateTime,
       DATA.UTCOperationEndTime,
       DataPointAverage,
       DataPointStdDeviation,
       UpperSpecLimit,
       LowerSpecLimit,
       CASE WHEN UpperSpecLimit IS NULL OR LowerSpecLimit IS NULL OR ISNULL(DataPointStdDeviation,0)=0 
                 THEN NULL
            ELSE (UpperSpecLimit-LowerSpecLimit)/(6*DataPointStdDeviation)   
       END                                                              AS Cp,
       CASE WHEN UpperSpecLimit IS NULL OR LowerSpecLimit IS NULL OR ISNULL(DataPointStdDeviation,0)=0 OR ISNULL(DataPointAverage,0)=0
                THEN NULL
            ELSE CASE WHEN UpperSpecLimit-DataPointAverage <= DataPointAverage-LowerSpecLimit 
                          THEN UpperSpecLimit-DataPointAverage
                      ELSE DataPointAverage-LowerSpecLimit 
                 END / (3*DataPointStdDeviation)                                
       END                                                               AS Cpk,
       V.RuleName,
       V.DataPointreadingTime,
       V.SampleId
  FROM (SELECT DATA.DateKey,
               DATA.[Date], 
               DATA.ShiftKey,
               DATA.ShiftDefinitionShiftName,
               DATA.StartDateTime,
               DATA.EndDateTime, 
               DATA.ChartKey,
               DATA.Chartid,
               DATA.ChartName,
               DATA.ResourceKey,
               DATA.ChartStartDateTime,
               DATA.UpperSpecLimit,
               DATA.LowerSpecLimit,
               AVG(OriginalDataPointValue1)   AS DataPointAverage,
               STDEV(OriginalDataPointValue1) AS DataPointStdDeviation,
               MAX(DATA.UTCOperationEndTime)  AS UTCOperationEndTime
        FROM (SELECT DISTINCT
                     SH.DateKey,
                     SH.[Date],
                     SH.ShiftKey,
                     SH.ShiftDefinitionShiftName,
                     SH.StartDateTime,
                     SH.EndDateTime,
                     FPR.ChartKey,
                     DC.ChartId,
                     DC.ChartName,
                     DC.ChartStartDateTime,
                     FPR.UTCOperationEndTime,
                     FPR.ChartDataPointKey,
                     FPR.ResourceKey,
                     FPR.OriginalDataPointValue1,
                     FPR.UpperSpecLimit,
                     FPR.LowerSpecLimit
              FROM.FactChartDataPointReading   FPR 
              JOIN DimResource                 DR  ON FPR.ResourceKey= DR.ResourceKey
              JOIN DimChart                    DC  ON DC.ChartKey = FPR.ChartKey
              JOIN Shifts                      SH  ON SH.Datekey = FPR.DateKey 
                                                  AND SH.AreaKey = DR.AreaKey
                                                  AND FPR.UTCOperationEndTime BETWEEN SH.StartDateTime AND SH.EndDateTime
              WHERE FPR.UTCOperationEndTime BETWEEN @DateStart AND @DateEnd
                AND (@ChartId IS NULL OR EXISTS (SELECT ChartId FROM #Charts T WHERE DC.ChartId = T.ChartId))
            ) DATA
        GROUP BY DATA.DateKey,
                 DATA.[Date],   
                 DATA.ShiftKey,
                 DATA.ShiftDefinitionShiftName,
                 DATA.StartDateTime,
                 DATA.EndDateTime, 
                 DATA.ChartKey,
                 DATA.ChartId,  
                 DATA.ChartName,
                 DATA.ResourceKey,
                 DATA.ChartStartDateTime,
                 DATA.UpperSpecLimit,
                 DATA.LowerSpecLimit
      ) DATA
       JOIN DimResource                    DR  ON DATA.ResourceKey = DR.ResourceKey
       LEFT JOIN Violations                V   ON DATA.ChartId= V.ChartId
                                              AND DATA.DateKey = V.DateKey
                                              AND DATA.ShiftKey = V.ShiftKey  
       JOIN Shifts                         SHI ON DATA.DateKey= SHI.DateKey
                                              AND DATA.UTCOperationEndTime BETWEEN SHI.StartDateTime AND SHI.EndDateTime

OPTION (RECOMPILE);
 
END
 