IF NOT EXISTS (SELECT name FROM sys.schemas WHERE name = N'UserDataModel')
     EXEC('CREATE SCHEMA [UserDataModel]');
GO
