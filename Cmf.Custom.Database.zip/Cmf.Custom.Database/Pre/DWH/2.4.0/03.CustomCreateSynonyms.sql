
IF  EXISTS (SELECT name FROM sys.synonyms WHERE name = N'ODS_T_ChartHistory')
     DROP SYNONYM  [Staging].[ODS_T_ChartHistory]
GO

CREATE SYNONYM [Staging].[ODS_T_ChartHistory] FOR [$(ODSDatabaseName)].[CoreDataModel].[T_ChartHistory]
GO

IF  EXISTS (SELECT name FROM sys.synonyms WHERE name = N'ODS_T_ChartDataPoint ')
     DROP SYNONYM  [Staging].[ODS_T_ChartDataPoint]
GO
CREATE SYNONYM [Staging].[ODS_T_ChartDataPoint] FOR [$(ODSDatabaseName)].[CoreDataModel].[T_ChartDataPoint]
GO

IF  EXISTS (SELECT name FROM sys.synonyms WHERE name = N'ODS_T_LogicalChart')
     DROP SYNONYM  [Staging].[ODS_T_LogicalChart]
GO

CREATE SYNONYM [Staging].[ODS_T_LogicalChart] FOR [$(ODSDatabaseName)].[CoreDataModel].[T_LogicalChart]
GO

IF  EXISTS (SELECT name FROM sys.synonyms WHERE name = N'ODS_T_ChartDataPointOccurrence')
     DROP SYNONYM  [Staging].[ODS_T_ChartDataPointOccurrence]
GO

CREATE SYNONYM [Staging].[ODS_T_ChartDataPointOccurrence] FOR [$(ODSDatabaseName)].[CoreDataModel].[T_ChartDataPointOccurrence]
GO

IF  EXISTS (SELECT name FROM sys.synonyms WHERE name = N'ODS_T_Rule')
     DROP SYNONYM  [Staging].[ODS_T_Rule]
GO

CREATE SYNONYM [Staging].[ODS_T_Rule] FOR [$(ODSDatabaseName)].[CoreDataModel].[T_Rule]
GO

IF  EXISTS (SELECT name FROM sys.synonyms WHERE name = N'ODS_T_ChartContextInformation')
     DROP SYNONYM  [Staging].[ODS_T_ChartContextInformation]
GO

CREATE SYNONYM [Staging].[ODS_T_ChartContextInformation] FOR [$(ODSDatabaseName)].[CoreDataModel].[T_ChartContextInformation]
GO

IF  EXISTS (SELECT name FROM sys.synonyms WHERE name = N'ODS_T_ChartRule')
     DROP SYNONYM  [Staging].[ODS_T_ChartRule]
GO

CREATE SYNONYM [Staging].[ODS_T_ChartRule] FOR [$(ODSDatabaseName)].[CoreDataModel].[T_ChartRule]
GO