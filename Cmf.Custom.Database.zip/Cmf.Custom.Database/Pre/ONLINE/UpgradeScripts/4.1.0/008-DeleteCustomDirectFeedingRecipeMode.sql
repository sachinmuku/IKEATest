IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'UserDataModel' AND TABLE_NAME = 'T_ST_CustomDirectFeedingRecipeMode')
	AND NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'UserDataModel' AND TABLE_NAME = 'T_ST_CustomDirectFeedingRecipeModeTemp')
BEGIN
-- Backup data to Temp
SELECT * INTO [UserDataModel].[T_ST_CustomDirectFeedingRecipeModeTemp]
		 FROM [UserDataModel].[T_ST_CustomDirectFeedingRecipeMode];

-- Delete tables CustomDirectFeedingRecipeMode

	DROP TABLE [UserDataModel].[T_ST_CustomDirectFeedingRecipeMode];
	DROP TABLE [UserDataModel].[T_ST_CustomDirectFeedingRecipeModeHistory];
	DROP TABLE [UserDataModel].[T_ST_CustomDirectFeedingRecipeModeDelCtrl];
	DROP VIEW  [UserDataModel].[V_ST_CustomDirectFeedingRecipeMode];
	DELETE FROM [dbo].[T_SmartTable] WHERE NAME = 'CustomDirectFeedingRecipeMode';
	DELETE FROM [dbo].[T_SmartTable] WHERE NAME = 'CustomDirectFeedingRecipeModeHistory';
	DELETE FROM [dbo].[T_SmartTable] WHERE NAME = 'CustomDirectFeedingRecipeModeDelCtrl';
	DELETE FROM [Control].[T_ReplicationTables] WHERE SchemaName = 'UserDataModel' AND TableName = 'T_ST_CustomDirectFeedingRecipeMode';
	DELETE FROM [Control].[T_ReplicationTables] WHERE SchemaName = 'UserDataModel' AND TableName = 'T_ST_CustomDirectFeedingRecipeModeHistory';
	DELETE FROM [Control].[T_ReplicationTables] WHERE SchemaName = 'UserDataModel' AND TableName = 'T_ST_CustomDirectFeedingRecipeModeDelCtrl' ;
END
ELSE
BEGIN
PRINT 'Table CustomDirectFeedingRecipeMode does not exist or table CustomDirectFeedingRecipeModeTemp already exist'
END