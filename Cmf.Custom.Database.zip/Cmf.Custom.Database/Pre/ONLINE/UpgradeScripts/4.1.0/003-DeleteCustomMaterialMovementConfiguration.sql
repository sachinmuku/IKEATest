IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'UserDataModel' AND TABLE_NAME = 'T_ST_CustomMaterialMovementConfiguration')
	AND NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'UserDataModel' AND TABLE_NAME = 'T_ST_CustomMaterialMovementConfigurationTemp')
BEGIN
-- Backup data to Temp
SELECT * INTO [UserDataModel].[T_ST_CustomMaterialMovementConfigurationTemp]
		 FROM [UserDataModel].[T_ST_CustomMaterialMovementConfiguration];

-- Delete tables CustomMaterialMovementConfiguration

	DROP TABLE [UserDataModel].[T_ST_CustomMaterialMovementConfiguration];
	DROP TABLE [UserDataModel].[T_ST_CustomMaterialMovementConfigurationHistory];
	DROP TABLE [UserDataModel].[T_ST_CustomMaterialMovementConfigurationDelCtrl];
	DROP VIEW  [UserDataModel].[V_ST_CustomMaterialMovementConfiguration];
	DELETE FROM [dbo].[T_SmartTable] WHERE NAME = 'CustomMaterialMovementConfiguration';
	DELETE FROM [dbo].[T_SmartTable] WHERE NAME = 'CustomMaterialMovementConfigurationHistory';
	DELETE FROM [dbo].[T_SmartTable] WHERE NAME = 'CustomMaterialMovementConfigurationDelCtrl';
	DELETE FROM [Control].[T_ReplicationTables] WHERE SchemaName = 'UserDataModel' AND TableName = 'T_ST_CustomMaterialMovementConfiguration';
	DELETE FROM [Control].[T_ReplicationTables] WHERE SchemaName = 'UserDataModel' AND TableName = 'T_ST_CustomMaterialMovementConfigurationHistory';
	DELETE FROM [Control].[T_ReplicationTables] WHERE SchemaName = 'UserDataModel' AND TableName = 'T_ST_CustomMaterialMovementConfigurationDelCtrl' ;
END
ELSE
BEGIN
PRINT 'Table CustomMaterialMovementConfiguration does not exist or table CustomMaterialMovementConfigurationTemp already exist'
END