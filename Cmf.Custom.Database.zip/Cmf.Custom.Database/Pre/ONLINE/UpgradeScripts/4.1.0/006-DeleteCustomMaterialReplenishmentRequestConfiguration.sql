IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'UserDataModel' AND TABLE_NAME = 'T_ST_CustomMaterialReplenishmentRequestConfiguration')
	AND NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'UserDataModel' AND TABLE_NAME = 'T_ST_CustomMaterialReplenishmentRequestConfigurationTemp')
BEGIN
-- Backup data to Temp
SELECT * INTO [UserDataModel].[T_ST_CustomMaterialReplenishmentRequestConfigurationTemp]
		 FROM [UserDataModel].[T_ST_CustomMaterialReplenishmentRequestConfiguration];

-- Delete tables CustomMaterialReplenishmentRequestConfiguration

	DROP TABLE [UserDataModel].[T_ST_CustomMaterialReplenishmentRequestConfiguration];
	DROP TABLE [UserDataModel].[T_ST_CustomMaterialReplenishmentRequestConfigurationHistory];
	DROP TABLE [UserDataModel].[T_ST_CustomMaterialReplenishmentRequestConfigurationDelCtrl];
	DROP VIEW  [UserDataModel].[V_ST_CustomMaterialReplenishmentRequestConfiguration];
	DELETE FROM [dbo].[T_SmartTable] WHERE NAME = 'CustomMaterialReplenishmentRequestConfiguration';
	DELETE FROM [dbo].[T_SmartTable] WHERE NAME = 'CustomMaterialReplenishmentRequestConfigurationHistory';
	DELETE FROM [dbo].[T_SmartTable] WHERE NAME = 'CustomMaterialReplenishmentRequestConfigurationDelCtrl';
	DELETE FROM [Control].[T_ReplicationTables] WHERE SchemaName = 'UserDataModel' AND TableName = 'T_ST_CustomMaterialReplenishmentRequestConfiguration';
	DELETE FROM [Control].[T_ReplicationTables] WHERE SchemaName = 'UserDataModel' AND TableName = 'T_ST_CustomMaterialReplenishmentRequestConfigurationHistory';
	DELETE FROM [Control].[T_ReplicationTables] WHERE SchemaName = 'UserDataModel' AND TableName = 'T_ST_CustomMaterialReplenishmentRequestConfigurationDelCtrl' ;
END
ELSE
BEGIN
PRINT 'Table CustomMaterialReplenishmentRequestConfiguration does not exist or table CustomMaterialReplenishmentRequestConfigurationTemp already exist'
END