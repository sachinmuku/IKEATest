IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'UserDataModel' AND TABLE_NAME = 'T_ST_CustomAutoDispatchExceptionBehavior')
	AND NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'UserDataModel' AND TABLE_NAME = 'T_ST_CustomAutoDispatchExceptionBehaviorTemp')
BEGIN
-- Backup data to Temp
SELECT * INTO [UserDataModel].[T_ST_CustomAutoDispatchExceptionBehaviorTemp]
		 FROM [UserDataModel].[T_ST_CustomAutoDispatchExceptionBehavior];

-- Delete tables CustomAutoDispatchExceptionBehavior

	DROP TABLE [UserDataModel].[T_ST_CustomAutoDispatchExceptionBehavior];
	DROP TABLE [UserDataModel].[T_ST_CustomAutoDispatchExceptionBehaviorHistory];
	DROP TABLE [UserDataModel].[T_ST_CustomAutoDispatchExceptionBehaviorDelCtrl];
	DROP VIEW  [UserDataModel].[V_ST_CustomAutoDispatchExceptionBehavior];
	DELETE FROM [dbo].[T_SmartTable] WHERE NAME = 'CustomAutoDispatchExceptionBehavior';
	DELETE FROM [dbo].[T_SmartTable] WHERE NAME = 'CustomAutoDispatchExceptionBehaviorHistory';
	DELETE FROM [dbo].[T_SmartTable] WHERE NAME = 'CustomAutoDispatchExceptionBehaviorDelCtrl';
	DELETE FROM [Control].[T_ReplicationTables] WHERE SchemaName = 'UserDataModel' AND TableName = 'T_ST_CustomAutoDispatchExceptionBehavior';
	DELETE FROM [Control].[T_ReplicationTables] WHERE SchemaName = 'UserDataModel' AND TableName = 'T_ST_CustomAutoDispatchExceptionBehaviorHistory';
	DELETE FROM [Control].[T_ReplicationTables] WHERE SchemaName = 'UserDataModel' AND TableName = 'T_ST_CustomAutoDispatchExceptionBehaviorDelCtrl' ;
END
ELSE
BEGIN
PRINT 'Table CustomAutoDispatchExceptionBehavior does not exist or table CustomAutoDispatchExceptionBehaviorTemp already exist'
END