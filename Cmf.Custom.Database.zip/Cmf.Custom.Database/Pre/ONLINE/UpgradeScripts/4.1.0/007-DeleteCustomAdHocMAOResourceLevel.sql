IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'UserDataModel' AND TABLE_NAME = 'T_ST_CustomAdHocMAOResourceLevel')
	AND NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'UserDataModel' AND TABLE_NAME = 'T_ST_CustomAdHocMAOResourceLevelTemp')
BEGIN
-- Backup data to Temp
SELECT * INTO [UserDataModel].[T_ST_CustomAdHocMAOResourceLevelTemp]
		 FROM [UserDataModel].[T_ST_CustomAdHocMAOResourceLevel];

-- Delete tables CustomAdHocMAOResourceLevel

	DROP TABLE [UserDataModel].[T_ST_CustomAdHocMAOResourceLevel];
	DROP TABLE [UserDataModel].[T_ST_CustomAdHocMAOResourceLevelHistory];
	DROP TABLE [UserDataModel].[T_ST_CustomAdHocMAOResourceLevelDelCtrl];
	DROP VIEW  [UserDataModel].[V_ST_CustomAdHocMAOResourceLevel];
	DELETE FROM [dbo].[T_SmartTable] WHERE NAME = 'CustomAdHocMAOResourceLevel';
	DELETE FROM [dbo].[T_SmartTable] WHERE NAME = 'CustomAdHocMAOResourceLevelHistory';
	DELETE FROM [dbo].[T_SmartTable] WHERE NAME = 'CustomAdHocMAOResourceLevelDelCtrl';
	DELETE FROM [Control].[T_ReplicationTables] WHERE SchemaName = 'UserDataModel' AND TableName = 'T_ST_CustomAdHocMAOResourceLevel';
	DELETE FROM [Control].[T_ReplicationTables] WHERE SchemaName = 'UserDataModel' AND TableName = 'T_ST_CustomAdHocMAOResourceLevelHistory';
	DELETE FROM [Control].[T_ReplicationTables] WHERE SchemaName = 'UserDataModel' AND TableName = 'T_ST_CustomAdHocMAOResourceLevelDelCtrl' ;
END
ELSE
BEGIN
PRINT 'Table CustomAdHocMAOResourceLevel does not exist or table CustomAdHocMAOResourceLevelTemp already exist'
END