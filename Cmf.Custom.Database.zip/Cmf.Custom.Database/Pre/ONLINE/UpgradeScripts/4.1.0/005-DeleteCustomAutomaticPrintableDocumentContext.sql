IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'UserDataModel' AND TABLE_NAME = 'T_ST_CustomAutomaticPrintableDocumentContext')
	AND NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'UserDataModel' AND TABLE_NAME = 'T_ST_CustomAutomaticPrintableDocumentContextTemp')
BEGIN
-- Backup data to Temp
SELECT * INTO [UserDataModel].[T_ST_CustomAutomaticPrintableDocumentContextTemp]
		 FROM [UserDataModel].[T_ST_CustomAutomaticPrintableDocumentContext];

-- Delete tables CustomAutomaticPrintableDocumentContext

	DROP TABLE [UserDataModel].[T_ST_CustomAutomaticPrintableDocumentContext];
	DROP TABLE [UserDataModel].[T_ST_CustomAutomaticPrintableDocumentContextHistory];
	DROP TABLE [UserDataModel].[T_ST_CustomAutomaticPrintableDocumentContextDelCtrl];
	DROP VIEW  [UserDataModel].[V_ST_CustomAutomaticPrintableDocumentContext];
	DELETE FROM [dbo].[T_SmartTable] WHERE NAME = 'CustomAutomaticPrintableDocumentContext';
	DELETE FROM [dbo].[T_SmartTable] WHERE NAME = 'CustomAutomaticPrintableDocumentContextHistory';
	DELETE FROM [dbo].[T_SmartTable] WHERE NAME = 'CustomAutomaticPrintableDocumentContextDelCtrl';
	DELETE FROM [Control].[T_ReplicationTables] WHERE SchemaName = 'UserDataModel' AND TableName = 'T_ST_CustomAutomaticPrintableDocumentContext';
	DELETE FROM [Control].[T_ReplicationTables] WHERE SchemaName = 'UserDataModel' AND TableName = 'T_ST_CustomAutomaticPrintableDocumentContextHistory';
	DELETE FROM [Control].[T_ReplicationTables] WHERE SchemaName = 'UserDataModel' AND TableName = 'T_ST_CustomAutomaticPrintableDocumentContextDelCtrl' ;
END
ELSE
BEGIN
PRINT 'Table CustomAutomaticPrintableDocumentContext does not exist or table CustomAutomaticPrintableDocumentContextTemp already exist'
END