/*
This is a temporary and a very big 'martelade' !!!
Due to the fact that it is not possible to run LBOs in the second an more machines in a cluster
this script will remove the last entry of the GenLBOs package in PackageInfo so it can run in all machines.
Author: Nuno Pacheco - 23/10/2021
*/

IF EXISTS(SELECT * FROM [dbo].[T_PackageInfo] WHERE PackageId = 'Cmf.Custom.IKEA.GenLBOs' AND Status = 1)
BEGIN TRY

  BEGIN TRANSACTION

  UPDATE [dbo].[T_PackageInfo] SET Status = 2, RemovedBy = 'System', PackageId = (PackageId + '.' + CAST(PackageInfoId AS NVARCHAR))
  WHERE PackageId = 'Cmf.Custom.IKEA.GenLBOs' AND Status = 1

  COMMIT TRANSACTION

END TRY
BEGIN CATCH

  ROLLBACK TRANSACTION
  DECLARE @ErrorMessage NVARCHAR(MAX) = ERROR_MESSAGE()
  PRINT @ErrorMessage

END CATCH
