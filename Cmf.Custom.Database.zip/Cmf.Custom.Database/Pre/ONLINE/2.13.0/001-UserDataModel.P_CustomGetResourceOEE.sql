/**
** Version History

** Version		     Date		 Author		  Description 
** ---------		 ----------  -------      ----------------------------------------------------------------------
** Sprint 13         30/06/2021  Paulo S.	  New custom procedure based on the GetResourceOEE with the shift filter
*/

CREATE OR ALTER PROCEDURE [UserDataModel].[P_CustomGetResourceOEE] 
	@TimeFrame NVARCHAR(28), --Day, Week, Month 
	@GetActual BIT, -- 0: yesterday, 1: today
	@Facility NVARCHAR(512), -- Facility name
	@Area NVARCHAR(512), -- Area name
	@Resources [dbo].TY_ParametersList READONLY, -- One or more resources (only key will be set)
	@ResourceTypes [dbo].TY_ParametersList READONLY, -- One or more resource types (only key will be set)
	@ResourceResourceTypes [dbo].TY_ParametersList READONLY, -- One or more resource types (only key will be set)
	@ShiftDefinition NVARCHAR(4000), -- Only Works with one ShiftDefinition
	@Shifts [dbo].TY_ParametersList READONLY, -- Requires the ShiftDefinition to be defined
	@PrintScript BIT = 0

AS
BEGIN

--declare 
	--@TimeFrame NVARCHAR(28) ='Month', --Day, Week, Month 
	--@GetActual BIT =1, -- 0: yesterday, 1: today
	--@Facility NVARCHAR(512)=NULL, -- Facility name
	--@Area NVARCHAR(512) = NULL, -- Area name
	--@Resources [dbo].TY_ParametersList , -- One or more resources (only key will be set)
	--@ResourceTypes [dbo].TY_ParametersList , -- One or more resource types (only key will be set)
	--@ResourceResourceTypes [dbo].TY_ParametersList , -- One or more resource types (only key will be set)
	--@ShiftDefinition NVARCHAR(4000)=NULL, -- Only Works with one ShiftDefinition
	--@ShiftName NVARCHAR(4000)=NULL, -- Requires the ShiftDefinition to be defined
	--@PrintScript BIT = 1

	--@TimeFrame = 'Month', --Day, Week, Month 
	--@GetActual = 1, -- 0: yesterday, 1: today
	--@ShowDecimals=1, -- 0: round to 0, 1: round to 1 decimal digits
	--@Facility= NULL, -- One or more Facilities split by name
	--@Area= NULL, -- One or more Areas split by name
	--@Resources= NULL, -- One or more resources split by name
	--@ResourceTypes= NULL , -- One or more resource types (only key will be set)
	--@ResourceResourceTypes= NULL , -- One or more resource resource types (only key will be set)
	--@ShiftDefinition= 'Standard Shift',
	--@ShiftName= 'Morning Shift',
	--@PrintScript =1


	SET NOCOUNT ON;
	declare @DemoMode bit = 0;
	declare @ShowDecimals int = 0;

	SELECT @ShowDecimals = CASE WHEN count(1) > 0 THEN 1 ELSE 0 END
	FROM [Config].[T_Config]
	WHERE [ConfigPath] = '/Cmf/Guis/Configuration/Dashboards/Widgets/KPIs/ShowDecimals/' AND [ValueString] = 'True';

	SELECT @DemoMode = CASE WHEN count(1) > 0 THEN 1 ELSE 0 END
	FROM [Config].[T_Config]
	WHERE [ConfigPath] = '/Cmf/Guis/Configuration/Dashboards/Widgets/KPIs/DemoMode/' AND [ValueString] = 'True';

	declare @ResultSet as table 
	(
		[Time] int,			
		[OEE] decimal(18, 1),
		[Availability] decimal(18, 1),
		[Quality] decimal(18, 1),
		[Performance] decimal(18, 1)
	)

	BEGIN TRY
		if (@DemoMode = 1)
		BEGIN			
			declare @AvailabilityCenterLine int = 85
			declare @QualityCenterLine int = 90
			declare @PerformanceCenterLine int = 90

			insert into @ResultSet ([Time], [OEE], [Availability], [Quality], [Performance])
			select 0, 0, round(@AvailabilityCenterLine + CHECKSUM(NewId()) % (100 - @AvailabilityCenterLine), @ShowDecimals), round(@QualityCenterLine + CHECKSUM(NewId()) % (100 - @QualityCenterLine), @ShowDecimals), round(@PerformanceCenterLine + CHECKSUM(NewId()) % (100 - @PerformanceCenterLine), @ShowDecimals)
			union all
			select -1, 0, round(@AvailabilityCenterLine + CHECKSUM(NewId()) % (100 - @AvailabilityCenterLine), @ShowDecimals), round(@QualityCenterLine + CHECKSUM(NewId()) % (100 - @QualityCenterLine), @ShowDecimals), round(@PerformanceCenterLine + CHECKSUM(NewId()) % (100 - @PerformanceCenterLine), @ShowDecimals)
			union all
			select -2, 0, round(@AvailabilityCenterLine + CHECKSUM(NewId()) % (100 - @AvailabilityCenterLine), @ShowDecimals), round(@QualityCenterLine + CHECKSUM(NewId()) % (100 - @QualityCenterLine), @ShowDecimals), round(@PerformanceCenterLine + CHECKSUM(NewId()) % (100 - @PerformanceCenterLine), @ShowDecimals)
			union all
			select -3, 0, round(@AvailabilityCenterLine + CHECKSUM(NewId()) % (100 - @AvailabilityCenterLine), @ShowDecimals), round(@QualityCenterLine + CHECKSUM(NewId()) % (100 - @QualityCenterLine), @ShowDecimals), round(@PerformanceCenterLine + CHECKSUM(NewId()) % (100 - @PerformanceCenterLine), @ShowDecimals)
			union all
			select -4, 0, round(@AvailabilityCenterLine + CHECKSUM(NewId()) % (100 - @AvailabilityCenterLine), @ShowDecimals), round(@QualityCenterLine + CHECKSUM(NewId()) % (100 - @QualityCenterLine), @ShowDecimals), round(@PerformanceCenterLine + CHECKSUM(NewId()) % (100 - @PerformanceCenterLine), @ShowDecimals)
			union all
			select -5, 0, round(@AvailabilityCenterLine + CHECKSUM(NewId()) % (100 - @AvailabilityCenterLine), @ShowDecimals), round(@QualityCenterLine + CHECKSUM(NewId()) % (100 - @QualityCenterLine), @ShowDecimals), round(@PerformanceCenterLine + CHECKSUM(NewId()) % (100 - @PerformanceCenterLine), @ShowDecimals)
			union all
			select -6, 0, round(@AvailabilityCenterLine + CHECKSUM(NewId()) % (100 - @AvailabilityCenterLine), @ShowDecimals), round(@QualityCenterLine + CHECKSUM(NewId()) % (100 - @QualityCenterLine), @ShowDecimals), round(@PerformanceCenterLine + CHECKSUM(NewId()) % (100 - @PerformanceCenterLine), @ShowDecimals)
			union all
			select -7, 0, round(@AvailabilityCenterLine + CHECKSUM(NewId()) % (100 - @AvailabilityCenterLine), @ShowDecimals), round(@QualityCenterLine + CHECKSUM(NewId()) % (100 - @QualityCenterLine), @ShowDecimals), round(@PerformanceCenterLine + CHECKSUM(NewId()) % (100 - @PerformanceCenterLine), @ShowDecimals)

			update @ResultSet set OEE = round((CAST([Availability] as decimal)/100  * CAST([Quality] as decimal)/100 * CAST([Performance] as decimal)/100) * 100, @ShowDecimals)
			select * from @ResultSet
		END
		ELSE
		BEGIN
-- following prepares and dynamically calls ODS procedure which internally performs the MDX query to retrieve data
			declare @ScriptCommand nvarchar(4000);
			declare @v_fullTargetDBName nvarchar(100) = '[' + DB_NAME() + 'ODS]';
			declare @CRLR VARCHAR(8) = CHAR(13) + CHAR(10);
			declare @v_DbLinkName nvarchar(100);
			declare @ResourceFilter nvarchar(1000);
			DECLARE @ResourceTypeFilter nvarchar(1000);
			DECLARE @ResourceResourceTypeFilter nvarchar(1000);
   DECLARE @ShiftFilter nvarchar(1000);  
			
			declare @environmenteName nvarchar(512) = [dbo].[F_GetSystemName]();
			declare @ODSlinkedServerName sysname = 'cm'+@environmenteName+'ODSLink';

			IF (EXISTS(select * from sys.servers where name = @ODSlinkedServerName))
				SET @v_DbLinkName = @ODSlinkedServerName
			ELSE SET @v_DbLinkName = '';
			declare  @v_fullLinkedServName nvarchar(100) = ISNULL(NULLIF('['+@v_DbLinkName+']', '[]'), ' ')

			SELECT @ResourceFilter = STUFF((
				SELECT ',' + SUB.ParameterName AS [text()]
-- Add a comma (,) before each value
				FROM @Resources SUB
				FOR XML PATH(''), TYPE).value('.','NVARCHAR(MAX)'), 1, 1, '');

			SELECT @ResourceTypeFilter = STUFF((
				SELECT ',' + SUB.ParameterName AS [text()]
-- Add a comma (,) before each value
				FROM @ResourceTypes SUB
				FOR XML PATH(''), TYPE).value('.','NVARCHAR(MAX)'), 1, 1, '');

			SELECT @ResourceResourceTypeFilter = STUFF((
				SELECT ',' + SUB.ParameterName AS [text()]
-- Add a comma (,) before each value
				FROM @ResourceResourceTypes SUB
				FOR XML PATH(''), TYPE).value('.','NVARCHAR(MAX)'), 1, 1, '');

			SELECT @ShiftFilter = STUFF((
				SELECT ',' + SUB.ParameterName AS [text()]
-- Add a comma (,) before each value
				FROM @Shifts SUB
				FOR XML PATH('') -- Select it as XML
				), 1, 1, '');


			SET @ScriptCommand =  'USE '+@v_fullTargetDBName+'; ' + @CRLR							
								+ 'execute [UserDataModel].[P_CustomGetResourceOEE_ODS]  @TimeFrame1, @GetActual1, @ShowDecimals1, @Facility1, @Area1, @Resources1, @ResourceTypes1, @ResourceResourceTypes1, @ShiftDefinition1, @ShiftName1, @PrintScript1' + @CRLR		
			
-- Sets the dynamic execute command refering for the remote server name
			declare @ScriptToExecute nvarchar(4000) = 'EXECUTE '+@v_fullLinkedServName+'..[dbo].sp_executesql @sqlcommand, N''@TimeFrame1 NVARCHAR(28), @GetActual1 bit, @ShowDecimals1 bit, @Facility1 nvarchar(512), @Area1 nvarchar(512), @Resources1 nvarchar(4000), @ResourceTypes1 NVARCHAR(4000), @ResourceResourceTypes1 NVARCHAR(4000), @ShiftDefinition1 NVARCHAR(4000), @ShiftName1 NVARCHAR(4000), @PrintScript1 bit'', @TimeFrame, @GetActual, @ShowDecimals, @Facility, @Area, @Resources, @ResourceTypes, @ResourceResourceTypes, @ShiftDefinition, @ShiftName, @PrintScript';		
		
-- Executes the inner execute as a dynamic sql passing as input the sql command to run		
			EXECUTE sp_executesql @ScriptToExecute, N'@sqlcommand nvarchar(max),@TimeFrame NVARCHAR(28), @GetActual bit, @ShowDecimals bit, @Facility nvarchar(512), @Area nvarchar(512), @Resources nvarchar(4000), @ResourceTypes nvarchar(4000), @ResourceResourceTypes nvarchar(4000),@ShiftDefinition NVARCHAR(4000), @ShiftName NVARCHAR(4000), @PrintScript bit', @ScriptCommand, @TimeFrame, @GetActual, @ShowDecimals, @Facility, @Area, @ResourceFilter, @ResourceTypeFilter, @ResourceResourceTypeFilter, @ShiftDefinition, @ShiftFilter, @PrintScript;
		END;
	END TRY
	BEGIN CATCH						
		DECLARE @ErrorMessage NVARCHAR(4000);
		DECLARE @ErrorSeverity INT;
		DECLARE @ErrorState INT;

		SELECT  @ErrorMessage = ERROR_MESSAGE(),
				@ErrorSeverity = ERROR_SEVERITY(),
				@ErrorState = ERROR_STATE();

		IF @@TRANCOUNT > 0
			ROLLBACK TRANSACTION;

		PRINT @ErrorMessage;
		select * from @ResultSet where 1 = 0;

	END CATCH	
END
