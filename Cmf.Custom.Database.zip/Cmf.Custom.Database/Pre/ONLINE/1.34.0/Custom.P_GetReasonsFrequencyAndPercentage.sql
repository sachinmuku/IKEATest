SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = 'Custom')
BEGIN
EXEC('CREATE SCHEMA Custom')
END
GO

IF EXISTS ( SELECT * 
            FROM   sysobjects 
            WHERE  id = object_id(N'[Custom].[P_GetReasonsFrequencyAndPercentage]') 
                   and OBJECTPROPERTY(id, N'IsProcedure') = 1 )
BEGIN
    DROP PROCEDURE [Custom].[P_GetReasonsFrequencyAndPercentage]
END
GO

CREATE PROCEDURE [Custom].[P_GetReasonsFrequencyAndPercentage]
(
    @TimeFrame NVARCHAR(28), -- Day, Week, Month 
    @Facility NVARCHAR(512),  -- Facility name
    @Area NVARCHAR(512),  -- Area name,
    @ProductType NVARCHAR(512),  -- Product type (Product ProductType)
    @ProductGroup NVARCHAR(512), -- Product Group
    @Resources [dbo].TY_ParametersList READONLY, -- One or more resources (only key will be set)
    @Steps [dbo].TY_ParametersList READONLY, -- One or more steps (only key will be set)
    @Products [dbo].TY_ParametersList READONLY, -- One or more products (only key will be set)                
	@StepTypes [dbo].TY_ParametersList READONLY, -- One or more steps (only key will be set)
	@ResourceTypes [dbo].TY_ParametersList READONLY, -- One or more resource types (only key will be set)
	@ResourceResourceTypes [dbo].TY_ParametersList READONLY, -- One or more resource resource types (only key will be set)
	@ShiftDefinition NVARCHAR(512), -- Only one shift definition
	@Shifts [dbo].TY_ParametersList READONLY, -- One or more shifts (only key will be set)
    @PrintScript BIT = 0 
)
AS 
BEGIN

	SET NOCOUNT ON;
	declare @DemoMode bit = 0;
	declare @ShowDecimals int = 0;

	SELECT @ShowDecimals = CASE WHEN count(1) > 0 THEN 1 ELSE 0 END
	FROM [Config].[T_Config]
	WHERE [ConfigPath] = '/Cmf/Guis/Configuration/Dashboards/Widgets/KPIs/ShowDecimals/' AND [ValueString] = 'True';

	SELECT @DemoMode = CASE WHEN count(1) > 0 THEN 1 ELSE 0 END
	FROM [Config].[T_Config]
	WHERE [ConfigPath] = '/Cmf/Guis/Configuration/Dashboards/Widgets/KPIs/DemoMode/' AND [ValueString] = 'True';

	DECLARE @OUTPUT TABLE
	(
		[Reason] NVARCHAR(512),
		[Frequency] DECIMAL(18,8),
		[Percentage] DECIMAL(18,8)
	)
	BEGIN TRY
		if (@DemoMode = 1)
		BEGIN
			DECLARE @ReasonTable TABLE
			(
				[Reason] NVARCHAR(120),
				[Order] decimal(18,8)
			)

			declare @Total DECIMAL(18,8)

			insert into @ReasonTable ([Reason], [Order])
			select 'Adjustment', ABS(CHECKSUM(NewId())) % 100 UNION
			select 'BreakDown', ABS(CHECKSUM(NewId())) % 100 UNION
			select 'Jam', ABS(CHECKSUM(NewId())) % 100 UNION
			select 'Automomous Maintenance', ABS(CHECKSUM(NewId())) % 100 UNION
			select 'No Operator', ABS(CHECKSUM(NewId())) % 100 UNION
			select 'Down (Misc.)', ABS(CHECKSUM(NewId())) % 100 UNION
			select 'Cleaning', ABS(CHECKSUM(NewId())) % 100 UNION
			select 'No Materials', ABS(CHECKSUM(NewId())) % 100 UNION
			select 'Unable To DownLoad Recipe', ABS(CHECKSUM(NewId())) % 100 UNION
			select 'Internal Error', ABS(CHECKSUM(NewId())) % 100 UNION
			select 'Stepper Motor Driver Error', ABS(CHECKSUM(NewId())) % 100 UNION
			select 'Indexer Error', ABS(CHECKSUM(NewId())) % 100 UNION
			select 'Power Supply', ABS(CHECKSUM(NewId())) % 100 UNION
			select 'Power Supply Bias', ABS(CHECKSUM(NewId())) % 100 UNION
			select 'Phase Control Logic Error', ABS(CHECKSUM(NewId())) % 100 UNION
			select 'Pull-In Torque Low', ABS(CHECKSUM(NewId())) % 100 UNION
			select 'Pull-In Torque High', ABS(CHECKSUM(NewId())) % 100 UNION
			select 'Pullout Torque Low', ABS(CHECKSUM(NewId())) % 100 UNION
			select 'Pullout Torque High', ABS(CHECKSUM(NewId())) % 100 UNION
			select 'CRC Error', ABS(CHECKSUM(NewId())) % 100 UNION
			select 'Axis address', ABS(CHECKSUM(NewId())) % 100 UNION
			select 'Quadrant Compensation', ABS(CHECKSUM(NewId())) % 100 UNION
			select 'Drive type not allowed', ABS(CHECKSUM(NewId())) % 100 UNION
			select 'Table-ID is invalid', ABS(CHECKSUM(NewId())) % 100

			insert into @OUTPUT([Reason],  Frequency)
			select TOP 10 [Reason], 
						  ABS(CHECKSUM(NewId())) % 1000 
			  from @ReasonTable order by [Order] desc
	
			select @Total = SUM(Frequency) 
			  from @Output

			update @OUTPUT SET [Percentage] = (Frequency*100)/@Total

			SELECT [Reason],
				   [Frequency],
--		   [Percentage],
				   SUM([Percentage]) OVER(ORDER BY [Frequency] desc ROWS UNBOUNDED PRECEDING) AS RunningTotal
			FROM @OUTPUT
		END
		ELSE
		BEGIN
-- following prepares and dynamically calls ODS procedure which internally performs the MDX query to retrieve data
			declare @ScriptCommand nvarchar(4000);
			declare @v_fullTargetDBName nvarchar(100) = '[' + DB_NAME() + 'ODS]';
			declare @CRLR VARCHAR(8) = CHAR(13) + CHAR(10);
			declare @v_DbLinkName nvarchar(100);
			declare @environmenteName nvarchar(512) = [dbo].[F_GetSystemName]();
			declare @ODSlinkedServerName sysname = 'cm'+@environmenteName+'ODSLink';
		
			IF (EXISTS(select * from sys.servers where name = @ODSlinkedServerName))
				SET @v_DbLinkName = @ODSlinkedServerName
			ELSE SET @v_DbLinkName = '';
			declare  @v_fullLinkedServName nvarchar(100) = ISNULL(NULLIF('['+@v_DbLinkName+']', '[]'), ' ')

			DECLARE @ResourceFilter nvarchar(4000);
			DECLARE @ResourceTypeFilter nvarchar(4000);
			DECLARE @ResourceResourceTypeFilter nvarchar(4000);
			DECLARE @StepFilter nvarchar(4000);
			DECLARE @StepTypesFilter nvarchar(4000);
			DECLARE @ProdsFilter nvarchar(4000);
			DECLARE @ShiftFilter nvarchar(4000);

			SELECT @ResourceFilter = STUFF((
				SELECT ',' + SUB.ParameterName AS [text()]
-- Add a comma (,) before each value
				FROM @Resources SUB
				FOR XML PATH('') -- Select it as XML
				), 1, 1, '');

			SELECT @ResourceTypeFilter = STUFF((
				SELECT ',' + SUB.ParameterName AS [text()]
-- Add a comma (,) before each value
				FROM @ResourceTypes SUB
				FOR XML PATH('') -- Select it as XML
				), 1, 1, '');

			SELECT @ResourceResourceTypeFilter = STUFF((
				SELECT ',' + SUB.ParameterName AS [text()]
-- Add a comma (,) before each value
				FROM @ResourceResourceTypes SUB
				FOR XML PATH('') -- Select it as XML
				), 1, 1, '');

			SELECT @StepFilter = STUFF((
				SELECT ',' + SUB.ParameterName AS [text()]
-- Add a comma (,) before each value
				FROM @Steps SUB
				FOR XML PATH('') -- Select it as XML
				), 1, 1, '');
			
			SELECT @StepTypesFilter = STUFF((
				SELECT ',' + SUB.ParameterName AS [text()]
-- Add a comma (,) before each value
				FROM @StepTypes SUB
				FOR XML PATH('') -- Select it as XML
				), 1, 1, '');

			SELECT @ProdsFilter = STUFF((
				SELECT ',' + SUB.ParameterName AS [text()]
-- Add a comma (,) before each value
				FROM @Products SUB
				FOR XML PATH('') -- Select it as XML
				), 1, 1, '');
				
			SELECT @ShiftFilter = STUFF((
				SELECT ',' + SUB.ParameterName AS [text()]
-- Add a comma (,) before each value
				FROM @Shifts SUB
				FOR XML PATH('') -- Select it as XML
				), 1, 1, '');

			SET @ScriptCommand =  'USE '+@v_fullTargetDBName+'; ' + @CRLR							
								+ 'execute [Custom].[P_GetReasonsFrequencyAndPercentage_ODS]  @TimeFrame1, @GetActual1, @ShowDecimals1, @Facility1, @Area1, @ProductType1, @ProductGroup1, @Resources1, @Steps1, @Products1, @StepTypes1, @ResourceTypes1, @ResourceResourceTypes1, @ShiftDefinition1, @Shifts1, @PrintScript1' + @CRLR		
			
-- Sets the dynamic execute command refering for the remote server name
			declare @ScriptToExecute nvarchar(4000) = 'EXECUTE '+@v_fullLinkedServName+'..[dbo].sp_executesql @sqlcommand, N''@TimeFrame1 NVARCHAR(28), @GetActual1 bit, @ShowDecimals1 bit, @Facility1 NVARCHAR(512), @Area1 NVARCHAR(512), @ProductType1 NVARCHAR(512), @ProductGroup1 NVARCHAR(512), @Resources1 nvarchar(512), @Steps1 NVARCHAR(4000), @Products1 NVARCHAR(4000), @StepTypes1 NVARCHAR(4000), @ResourceTypes1 NVARCHAR(4000), @ResourceResourceTypes1 NVARCHAR(4000), @ShiftDefinition1 NVARCHAR(4000), @Shifts1 NVARCHAR(4000), @PrintScript1 bit'', @TimeFrame, @GetActual, @ShowDecimals, @Facility, @Area, @ProductType, @ProductGroup, @Resources, @Steps, @Products, @StepTypes,@ResourceTypes,@ResourceResourceTypes, @ShiftDefinition, @Shifts,@PrintScript';		
		
-- Executes the inner execute as a dynamic sql passing as input the sql command to run		
			EXECUTE sp_executesql @ScriptToExecute, N'@sqlcommand nvarchar(max),@TimeFrame NVARCHAR(28), @GetActual bit, @ShowDecimals bit, @Facility NVARCHAR(512), @Area NVARCHAR(512), @ProductType NVARCHAR(512), @ProductGroup NVARCHAR(512), @Resources nvarchar(512), @Steps NVARCHAR(4000), @Products NVARCHAR(4000), @StepTypes NVARCHAR(4000), @ResourceTypes NVARCHAR(4000), @ResourceResourceTypes NVARCHAR(4000), @ShiftDefinition NVARCHAR(4000), @Shifts NVARCHAR(4000), @PrintScript bit', @ScriptCommand, @TimeFrame, 1, @ShowDecimals, @Facility, @Area, @ProductType, @ProductGroup, @ResourceFilter, @StepFilter, @ProdsFilter, @StepTypesFilter,@ResourceTypeFilter,@ResourceResourceTypeFilter, @ShiftDefinition, @ShiftFilter, @PrintScript;
		END;
	END TRY
	BEGIN CATCH						
		DECLARE @ErrorMessage NVARCHAR(4000);
		DECLARE @ErrorSeverity INT;
		DECLARE @ErrorState INT;

		SELECT  @ErrorMessage = ERROR_MESSAGE(),
				@ErrorSeverity = ERROR_SEVERITY(),
				@ErrorState = ERROR_STATE();

		IF @@TRANCOUNT > 0
			ROLLBACK TRANSACTION;

		PRINT 'Test' + @ErrorMessage;
		SELECT [Reason],
				   [Frequency],
--		   [Percentage],
				   SUM([Percentage]) OVER(ORDER BY [Frequency] desc ROWS UNBOUNDED PRECEDING) AS RunningTotal
			FROM @OUTPUT WHERE 1=0;

	END CATCH
END
GO
