IF EXISTS (SELECT * 
FROM SYSOBJECTS
WHERE [id] = OBJECT_ID(N'Custom.P_GetResourceSubResources') AND OBJECTPROPERTY([id], N'IsProcedure') = 1 )
BEGIN
    DROP PROCEDURE [Custom].[P_GetResourceSubResources]
END
GO

CREATE PROCEDURE [Custom].[P_GetResourceSubResources]
	@ResourceId BIGINT
AS
BEGIN
	
	SET NOCOUNT ON;

	IF(OBJECT_ID(N'tempdb..#ResourcesToProcess') IS NOT NULL)
		DROP TABLE #ResourcesToProcess

	IF(OBJECT_ID(N'tempdb..#ResourcesToProcessAux') IS NOT NULL)
		DROP TABLE #ResourcesToProcessAux
	
	IF(OBJECT_ID(N'tempdb..#ProcessedResources') IS NOT NULL)
		DROP TABLE #ResourcesToProcess

	CREATE TABLE #ResourcesToProcess([ResourceId] BIGINT)

	CREATE TABLE #ResourcesToProcessAux([ResourceId] BIGINT)

	CREATE TABLE #ProcessedResources([ResourceId] BIGINT)

	INSERT INTO #ResourcesToProcess
	SELECT [TargetEntityId]
	FROM [CoreDataModel].[T_SubResource] SR
	INNER JOIN [CoreDataModel].[T_Resource] R ON R.[ResourceId] = SR.[TargetEntityId]
		AND R.[UniversalState] <> 4
	WHERE SR.[SourceEntityId] = @ResourceId
		AND SR.[UniversalState] <> 4

	INSERT INTO #ProcessedResources
	SELECT [ResourceId] FROM [CoreDataModel].[T_Resource] R WHERE R.[ResourceId] = @ResourceId
	UNION 
	SELECT [ResourceId]
	FROM #ResourcesToProcess

	WHILE(EXISTS(SELECT * FROM #ResourcesToProcess))
	BEGIN
		-- DELETE AUX TABLE
		DELETE #ResourcesToProcessAux

		-- gather delta of new resources found
		INSERT INTO #ResourcesToProcessAux
		SELECT DISTINCT SR.[TargetEntityId]
		FROM #ResourcesToProcess RTP
		INNER JOIN [CoreDataModel].[T_SubResource] SR ON SR.[SourceEntityId] = RTP.[ResourceId]
		INNER JOIN [CoreDataModel].[T_Resource] R ON R.[ResourceId] = SR.[TargetEntityId]
		WHERE SR.[UniversalState] <> 4 AND R.[UniversalState] <> 4
		EXCEPT 
		SELECT PR.[ResourceId] FROM #ProcessedResources PR

		-- put newly found resources as processed
		INSERT INTO #ProcessedResources([ResourceId])
		SELECT RPTA.[ResourceId] FROM #ResourcesToProcessAux RPTA

		-- change delta as the resources to process
		DELETE #ResourcesToProcess
		INSERT INTO #ResourcesToProcess([ResourceId])
		SELECT RPTA.[ResourceId] FROM #ResourcesToProcessAux RPTA
	END

	SELECT PR.[ResourceId] FROM #ProcessedResources PR;
END
GO
