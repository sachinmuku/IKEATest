IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'UserDataModel' AND TABLE_NAME = 'T_GT_CustomScanningConfiguration')
	AND NOT EXISTS(SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'UserDataModel' AND TABLE_NAME = 'T_GT_CustomScanningConfigurationTemp')
BEGIN
-- Backup data to Temp
SELECT * INTO [UserDataModel].[T_GT_CustomScanningConfigurationTemp]
		 FROM [UserDataModel].[T_GT_CustomScanningConfiguration];

-- Delete tables CustomScanningConfiguration

	DROP TABLE [UserDataModel].[T_GT_CustomScanningConfiguration];
	DROP TABLE [UserDataModel].[T_GT_CustomScanningConfigurationHistory];
	DROP TABLE [UserDataModel].[T_GT_CustomScanningConfigurationDelCtrl];
	DROP VIEW  [UserDataModel].[V_GT_CustomScanningConfiguration];
	DELETE FROM [dbo].[T_GenericTable] WHERE NAME = 'CustomScanningConfiguration';
	DELETE FROM [dbo].[T_GenericTable] WHERE NAME = 'CustomScanningConfigurationHistory';
	DELETE FROM [dbo].[T_GenericTable] WHERE NAME = 'CustomScanningConfigurationDelCtrl';
	DELETE FROM [Control].[T_ReplicationTables] WHERE SchemaName = 'UserDataModel' AND TableName = 'T_GT_CustomScanningConfiguration';
	DELETE FROM [Control].[T_ReplicationTables] WHERE SchemaName = 'UserDataModel' AND TableName = 'T_GT_CustomScanningConfigurationHistory';
	DELETE FROM [Control].[T_ReplicationTables] WHERE SchemaName = 'UserDataModel' AND TableName = 'T_GT_CustomScanningConfigurationDelCtrl' ;
END
ELSE
BEGIN
PRINT 'Table CustomScanningConfiguration does not exist or table CustomScanningConfigurationTemp already exist'
END