BEGIN TRY

BEGIN

DECLARE @ServiceName nvarchar(256) = 'Change ReferenceType from EntityType to EntityTypeDefinition'
DECLARE @ServiceHistoryId bigint
EXECUTE [dbo].[P_CreateServiceHistoryId] -1, @ServiceName, 'System', 'System', @ServiceHistoryId OUTPUT

DECLARE @LastOperationHistorySequence BIGINT = 0
DECLARE @LastOnlineServiceHistoryID BIGINT
DECLARE @ModifiedOn DATETIME = GETUTCDATE()
DECLARE @BatchExecutionId UNIQUEIDENTIFIER

DECLARE @Name1GenericTable nvarchar(256) = 'CustomBOMTemplateDetails'
DECLARE @Name2GenericTable nvarchar(256) = 'CustomULLPrintingResources'

BEGIN TRANSACTION

------------Add code here
	update T_GenericTableProperty set ReferenceType=7, LastServiceHistoryId=@ServiceHistoryId, LastOperationHistorySeq=@LastOperationHistorySequence
	where GenericTableId=(select GenericTableId from T_GenericTable where name=@Name1GenericTable)
	and name='Product'

	EXEC [dbo].[P_GenerateGenericTable] @BatchExecutionId = @BatchExecutionId OUTPUT
		,@GenericTable = @Name1GenericTable
		,@LastServiceHistoryId = @LastOnlineServiceHistoryID
		,@NewServiceHistoryId = @ServiceHistoryId
		,@NewOperationSequence = @LastOperationHistorySequence
		,@ModifiedOn = @ModifiedOn
		,@ModifiedBy = 'System'
		,@UseCommandQueue = 0

	---------------------------------------------
	SELECT @LastOperationHistorySequence = @LastOperationHistorySequence + 1

	update T_GenericTableProperty set ReferenceType=7, LastServiceHistoryId=@ServiceHistoryId, LastOperationHistorySeq=@LastOperationHistorySequence
	where GenericTableId=(select GenericTableId from T_GenericTable where name=@Name2GenericTable)
	and name='DefaultPrintableDocument'

	EXEC [dbo].[P_GenerateGenericTable] @BatchExecutionId = @BatchExecutionId OUTPUT
		,@GenericTable = @Name2GenericTable
		,@LastServiceHistoryId = @LastOnlineServiceHistoryID
		,@NewServiceHistoryId = @ServiceHistoryId
		,@NewOperationSequence = @LastOperationHistorySequence
		,@ModifiedOn = @ModifiedOn
		,@ModifiedBy = 'System'
		,@UseCommandQueue = 0


------------End of code


UPDATE dbo.T_ServiceHistory SET ServiceEndTime = GETUTCDATE() WHERE ServiceHistoryId = @ServiceHistoryId

 COMMIT
--ROLLBACK
END

END TRY
BEGIN CATCH
ROLLBACK

 DECLARE @ErrorMessage NVARCHAR(4000);
DECLARE @ErrorSeverity INT;
DECLARE @ErrorState INT;

 SELECT
@ErrorMessage = ERROR_MESSAGE(),
@ErrorSeverity = ERROR_SEVERITY(),
@ErrorState = ERROR_STATE();

 -- Use RAISERROR inside the CATCH block to return error
-- information about the original error that caused
-- execution to jump to the CATCH block.
RAISERROR(@ErrorMessage, -- Message text.
@ErrorSeverity, -- Severity.
@ErrorState -- State.
);
END CATCH