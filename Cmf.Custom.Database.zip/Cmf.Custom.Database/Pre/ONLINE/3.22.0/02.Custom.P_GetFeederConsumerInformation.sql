CREATE OR ALTER PROCEDURE [Custom].[P_GetFeederConsumerInformation] (@MaterialId BIGINT, @RestrictToForm NVARCHAR(512) = NULL, @OwnFacility BIT = 1, @DebugMode BIT = 0)
AS

BEGIN
-- GET BASE ATTRIBUTE ENTITY TYPE PROPERTY ID
	DECLARE @BaseProductEntityTypeProductId BIGINT = (
			SELECT ISNULL(MAX(ETP.[EntityTypePropertyId]), 0)
			FROM [dbo].[T_EntityType] ET
			INNER JOIN [dbo].[T_EntityTypeProperty] ETP ON ETP.[EntityTypeId] = ET.[EntityTypeId]
			WHERE ET.[Name] = N'Product' AND ETP.[Name] = N'BaseProduct'
		)

-- DETERMINE OWN FACILITY FILTER, GET PRODUCT BASE ATTRIBUTE
	DECLARE @FacilityFilter BIGINT
	DECLARE @BaseProduct NVARCHAR(512)
	DECLARE @MaterialType NVARCHAR(512)
	DECLARE @CurrentBOMVersionId BIGINT

	SELECT @FacilityFilter = CASE WHEN @OwnFacility = 0 THEN -1 ELSE 0 END
		, @BaseProduct = ISNULL(PA.[Value], P.[Name])
		, @MaterialType = M.[Type]
		, @CurrentBOMVersionId = M.[CurrentBOMVersionId]
	FROM [CoreDataModel].[T_Material] M
	INNER JOIN [CoreDataModel].[T_Product] P ON P.[ProductId] = M.[ProductId]
	LEFT JOIN [CoreDataModel].[T_ProductAttribute] PA ON PA.[ProductId] = P.[ProductId] AND PA.[EntityTypePropertyId] = @BaseProductEntityTypeProductId
	WHERE M.[MaterialId] = @MaterialId

-- GET ORDER MATERIAL FORM
	DECLARE @OrderMaterialForm NVARCHAR(512) = (SELECT [dbo].[F_GetConfigStringValue](N'/Cmf/Custom/MaterialTracking/OrderMaterialForm/', N'') [Value])

/* TABLES DECLARATION */
	BEGIN
		
/* TABLE #WIPTrackingForms */
		BEGIN
			IF(OBJECT_ID(N'tempdb..#WIPTrackingForms') IS NOT NULL)
				DROP TABLE #WIPTrackingForms

			CREATE TABLE #WIPTrackingForms (
				[EligibleForm] NVARCHAR(512)
			)
		END
		
/* TABLE #MaterialBOMProducts */
		BEGIN
			IF(OBJECT_ID(N'tempdb..#MaterialBOMProducts') IS NOT NULL)
				DROP TABLE #MaterialBOMProducts

			CREATE TABLE #MaterialBOMProducts (
				[MaterialId] BIGINT
				, [BaseProduct] NVARCHAR(512)
			)
		END

/* TABLE #PossibleConsumerMaterialAndBOM */
		BEGIN

			IF(OBJECT_ID(N'tempdb..#PossibleConsumerMaterialAndBOM') IS NOT NULL)
				DROP TABLE #PossibleConsumerMaterialAndBOM

			CREATE TABLE #PossibleConsumerMaterialAndBOM
			(
				[Form] NVARCHAR(512)
				, [MaterialId] BIGINT
				, [MaterialName] NVARCHAR(512)
				, [MaterialType] NVARCHAR(512)
				, [FacilityName] NVARCHAR(512)
				, [AreaName] NVARCHAR(512)
				, [ResourceName] NVARCHAR(512)
				, [StepName] NVARCHAR(512)
				, [FlowName] NVARCHAR(512)
				, [FlowRevision] NVARCHAR(256)
				, [LogicalFlowPath] NVARCHAR(512)
				, [ProductName] NVARCHAR(512)
				, [ProductRevision] NVARCHAR(256)
				, [ProductGroupName] NVARCHAR(512)
				, [ProductGroupRevision] NVARCHAR(256)
				, [DueDate] DATETIME
				, [PlannedStartDate] DATETIME
				, [PlannedEndDate] DATETIME
				, [SystemState] INTEGER
				, [Quantity] DECIMAL(18,8)
				, [HoldCount] INTEGER
				, [BOMVersionId] BIGINT
				, [ProductionOrder] NVARCHAR(512)
			)

			CREATE INDEX IDX_PCMAB_MaterialId ON #PossibleConsumerMaterialAndBOM([MaterialId])
			CREATE INDEX IDX_PCMAB_BOMVersionId ON #PossibleConsumerMaterialAndBOM([BOMVersionId])

		END

/* TABLE #ConsumerBOMReferencingBaseProduct */
		BEGIN

			IF(OBJECT_ID(N'tempdb..#ConsumerBOMReferencingBaseProduct') IS NOT NULL)
				DROP TABLE #ConsumerBOMReferencingBaseProduct

			CREATE TABLE #ConsumerBOMReferencingBaseProduct
			(
				[BOMVersionId] BIGINT
			)

		END

	END

/*	INITIALIZE FORM RESTRICTION 
		Get all eligible forms used for MO and palletization tracking
	*/
	BEGIN
		IF (ISNULL(@RestrictToForm, N'') = N'')
		BEGIN
			INSERT INTO #WIPTrackingForms([EligibleForm])
			SELECT DISTINCT SRC.[Value]
			FROM
			(
				SELECT @OrderMaterialForm [Value]
				UNION ALL
				SELECT DISTINCT CMF.[Form]
				FROM [UserDataModel].[T_ST_CustomCompletedMaterialForm] CMF
				UNION ALL
				SELECT [dbo].[F_GetConfigStringValue](N'/Cmf/Custom/MaterialTracking/CompletedMaterialForm/', N'') [Value]
				
			) SRC
			WHERE SRC.[Value] <> N''
		END
		ELSE
		BEGIN
			INSERT INTO #WIPTrackingForms([EligibleForm]) VALUES(@RestrictToForm)
		END


		IF(@DebugMode = 1)
			SELECT [EligibleForm] [Eligible Tracking Forms] FROM #WIPTrackingForms
		
	END

/* RETRIEVE MO BOM PRODUCTS */
	BEGIN

		IF(ISNULL(@CurrentBOMVersionId, 0) <= 0)
		BEGIN
			SELECT @CurrentBOMVersionId = ISNULL(MAX(B.[BOMId]), -1) 
			FROM [CoreDataModel].[T_Material] M
			INNER JOIN [CoreDataModel].[T_Step] S ON S.[StepId] = M.[StepId]
			INNER JOIN [CoreDataModel].[T_Flow] F ON F.[FlowId] = M.[FlowId]
			INNER JOIN [CoreDataModel].[T_Product] P ON P.[ProductId] = M.[ProductId]
			LEFT JOIN [CoreDataModel].[T_ProductGroup] PG ON PG.[ProductGroupId] = P.[ProductGroupId]
			LEFT JOIN [CoreDataModel].[T_ProductionOrder] PO ON PO.[ProductionOrderId] = M.[ProductionOrderId]
			OUTER APPLY CoreDataModel.F_ST_ResolveBOMContext(1, S.[Name], M.[LogicalFlowPath], P.[Name], P.[Revision], PG.[Name], PG.[Revision], F.[Name], F.[Revision], M.[Name],PO.[Name]) RB
			LEFT JOIN [CoreDataModel].[T_BOM] B ON B.[Name] = RB.BOM AND B.[UniversalState] = 3 -- LOOK FOR EFFECTIVE VERSION
			WHERE M.[MaterialId] = @MaterialId
		END

		INSERT INTO #MaterialBOMProducts([MaterialId], [BaseProduct])
		SELECT M.[MaterialId], ISNULL(PA.[Value], P.[Name])
		FROM [CoreDataModel].[T_Material] M
		INNER JOIN [CoreDataModel].[T_BOM] B ON B.[BOMId] = @CurrentBOMVersionId
		INNER JOIN [CoreDataModel].[T_BOMProduct] BP ON BP.[SourceEntityId] = B.[BOMId]
		INNER JOIN [CoreDataModel].[T_Product] P ON P.[ProductId] = BP.[TargetEntityId]
		LEFT JOIN [CoreDataModel].[T_ProductAttribute] PA ON PA.[ProductId] = P.[ProductId] AND PA.[EntityTypePropertyId] = @BaseProductEntityTypeProductId
		WHERE M.[MaterialId] = @MaterialId

	END

/* GET FEEDER MATERIALS */
	BEGIN

-- GET ALL MATERIALS ELIGIBLE
		SELECT M.[Form] [Form], M.[Name] [MaterialName], M.[Type] [MaterialType], P.[Name] [ProductName]
			, FA.[Name] [FacilityName], A.[Name] [AreaName], F.[Name] [FlowName], S.[Name] [StepName], R.[Name] [ResourceName]
			, M.[DueDate], PO.[PlannedStartDate], PO.[PlannedEndDate]
			, M.[SystemState], M.[PrimaryQuantity] [Quantity], M.[HoldCount]
		FROM [CoreDataModel].[T_Material] M
		INNER JOIN #WIPTrackingForms WTF ON WTF.[EligibleForm] = M.[Form]
		INNER JOIN [CoreDataModel].[T_Product] P ON P.[ProductId] = M.[ProductId]
		LEFT JOIN [CoreDataModel].[T_ProductAttribute] PA ON PA.[ProductId] = P.[ProductId] AND PA.[EntityTypePropertyId] = @BaseProductEntityTypeProductId
		INNER JOIN #MaterialBOMProducts MPB ON MPB.[MaterialId] = @MaterialId AND MPB.[BaseProduct] = ISNULL(PA.[Value], P.[Name])
		INNER JOIN [CoreDataModel].[T_Flow] F ON F.[FlowId] = M.[FlowId]
		INNER JOIN [CoreDataModel].[T_Step] S ON S.[StepId] = M.[StepId]
		INNER JOIN [CoreDataModel].[T_StepArea] SA ON SA.[SourceEntityId] = S.[StepId]
		INNER JOIN [CoreDataModel].[T_Area] A ON A.[AreaId] = SA.[TargetEntityId] AND A.[FacilityId] = M.[FacilityId]
		INNER JOIN [CoreDataModel].[T_Facility] FA ON FA.[FacilityId] = M.[FacilityId]
		LEFT JOIN [CoreDataModel].[T_MaterialResource] MR ON MR.[SourceEntityId] = M.[MaterialId] AND MR.[UniversalState] = 2
		LEFT JOIN [CoreDataModel].[T_Resource] R ON R.[ResourceId] = MR.[TargetEntityId]
		LEFT JOIN [CoreDataModel].[T_ProductionOrder] PO ON PO.[ProductionOrderId] = M.[ProductionOrderId]
		WHERE M.[MaterialId] <> @MaterialId -- CAN'T BE SELF
-- MUST BE ACTIVE
			AND M.[UniversalState] = 2
-- MUST HAVE QUANTITY
			AND M.[PrimaryQuantity] > 0
-- APPLY FACILITY RESTRICTION IF APPLICABLE
			AND (@FacilityFilter <= 0 OR M.[FacilityId] = @FacilityFilter)
-- MATERIAL TYPE MUST NOT BE SAMPLETESTING
			AND M.[Type] <> 'SampleTesting'
-- MUST BE QUEUED, DISPATCHED OR INPROCESS
			AND M.[SystemState] IN (0, 1, 2)
	
	END

	

/* GET CONSUMER MATERIALS */
	BEGIN

/* COLLECT ALL POSSIBLE CONSUMER MATERIALS */
		BEGIN
-- COLLECT ALL POSSIBLE CONSUMER MATERIALS 
			INSERT INTO #PossibleConsumerMaterialAndBOM([Form], [MaterialId], [MaterialName], [MaterialType], [FacilityName], [AreaName], [ResourceName], [StepName], [FlowName], [FlowRevision], [LogicalFlowPath], [ProductName], [ProductRevision], [ProductGroupName], [ProductGroupRevision], [DueDate], [PlannedStartDate], [PlannedEndDate], [SystemState], [Quantity], [HoldCount], [BOMVersionId],[ProductionOrder])
			SELECT M.[Form], M.[MaterialId], M.[Name], M.[Type], FA.[Name], A.[Name], R.[Name], S.[Name], F.[Name], F.[Revision], M.[LogicalFlowPath], P.[Name], P.[Revision], PG.[Name], PG.[Revision], M.[DueDate], PO.[PlannedStartDate], PO.[PlannedEndDate], M.[SystemState], M.[PrimaryQuantity], M.[HoldCount], M.[CurrentBOMVersionId],PO.[Name]
			FROM [CoreDataModel].[T_Material] M
			INNER JOIN [CoreDataModel].[T_Flow] F ON F.[FlowId] = M.[FlowId]
			INNER JOIN [CoreDataModel].[T_Step] S ON S.[StepId] = M.[StepId]
			INNER JOIN [CoreDataModel].[T_StepArea] SA ON SA.[SourceEntityId] = S.[StepId]
			INNER JOIN [CoreDataModel].[T_Area] A ON A.[AreaId] = SA.[TargetEntityId] AND A.[FacilityId] = M.[FacilityId]
			INNER JOIN [CoreDataModel].[T_Facility] FA ON FA.[FacilityId] = M.[FacilityId]
			INNER JOIN #WIPTrackingForms WTF ON WTF.[EligibleForm] = M.[Form]
			LEFT JOIN [CoreDataModel].[T_MaterialResource] MR ON MR.[SourceEntityId] = M.[MaterialId] AND MR.[UniversalState] = 2
			LEFT JOIN [CoreDataModel].[T_Resource] R ON R.[ResourceId] = MR.[TargetEntityId]
			INNER JOIN [CoreDataModel].[T_Product] P ON P.[ProductId] = M.[ProductId]
			LEFT JOIN [CoreDataModel].[T_ProductGroup] PG ON PG.[ProductGroupId] = P.[ProductGroupId]
			LEFT JOIN [CoreDataModel].[T_ProductionOrder] PO ON PO.[ProductionOrderId] = M.[ProductionOrderId]
			WHERE M.[MaterialId] <> @MaterialId -- CAN'T BE SELF
-- MUST BE ACTIVE
				AND M.[UniversalState] = 2
-- MUST HAVE QUANTITY
				AND M.[PrimaryQuantity] > 0
-- MUST BE QUEUED, DISPATCHED OR INPROCESS
				AND M.[SystemState] IN (0, 1, 2)
-- RESTRICT TO MO FORM
				AND M.[Form] = @OrderMaterialForm
-- APPLY FACILITY RESTRICTION IF APPLICABLE
				AND (@FacilityFilter <= 0 OR M.[FacilityId] = @FacilityFilter)
-- MATERIAL TYPE MUST NOT BE SAMPLETESTING
				AND M.[Type] <> 'SampleTesting'

			IF (@DebugMode = 1)
			BEGIN 
				SELECT '#PossibleConsumerMaterialAndBOM.Pre'
				SELECT * FROM #PossibleConsumerMaterialAndBOM
			END
		END

/* RESOLVE BOMS FOR MATERIALS THAT DON'T HAVE A BOM YET */
		BEGIN
		
			DECLARE @RowsChanged INT = 1
			DECLARE @MissingBOMMaterialId BIGINT
			WHILE(@RowsChanged > 0)
			BEGIN
-- PICK FIRST UNRESOLVED BOM MATERIAL
				SET @MissingBOMMaterialId = NULL
				SELECT TOP 1 @MissingBOMMaterialId = PCMAB.[MaterialId] FROM #PossibleConsumerMaterialAndBOM PCMAB WHERE PCMAB.[BOMVersionId] IS NULL
				IF(ISNULL(@MissingBOMMaterialId, 0) > 0)
				BEGIN
-- RESOLVE BOM FOR MATERIAL
					MERGE INTO #PossibleConsumerMaterialAndBOM TRG
					USING (
						SELECT PCMAB.[MaterialId], B.[BOMId]
						FROM #PossibleConsumerMaterialAndBOM PCMAB
						OUTER APPLY CoreDataModel.F_ST_ResolveBOMContext(1,PCMAB.[StepName],PCMAB.[LogicalFlowPath],PCMAB.[ProductName],PCMAB.[ProductRevision],PCMAB.[ProductGroupName],PCMAB.[ProductGroupRevision],PCMAB.[FlowName],PCMAB.[FlowRevision],PCMAB.[MaterialName],PCMAB.[ProductionOrder]) RB
						LEFT JOIN [CoreDataModel].[T_BOM] B ON B.[Name] = RB.BOM AND B.[UniversalState] = 3 AND B.[Revision] is not null -- LOOK FOR EFFECTIVE VERSION / AND REVISION NOT NULL --> WITH THE UPGRADE TO 9, WE HAVE TWO LINES WITH UNIVERSAL STATE 3, ONE HAS REVISION AND THE OTHER IS NULL
						WHERE PCMAB.[MaterialId] = @MissingBOMMaterialId
					) SRC ON (TRG.[MaterialId] = SRC.[MaterialId])
					WHEN MATCHED THEN UPDATE SET TRG.[BOMVersionId] = ISNULL(SRC.[BOMId], -1);
				
					SET @RowsChanged = @@ROWCOUNT
				END
				ELSE
				BEGIN
					SET @RowsChanged = 0
				END

			END

			IF (@DebugMode = 1)
			BEGIN 
				SELECT '#PossibleConsumerMaterialAndBOM.Post'
				SELECT * FROM #PossibleConsumerMaterialAndBOM
			END
		END

/* COLLECT ALL BOM PRODUCTS FOR EACH BOM RESOLVED THAT REQUIRE INCOMING MATERIAL BASE PRODUCT*/
		BEGIN
			;WITH BASE_DATA AS
			(
				SELECT DISTINCT PCMAB.[BOMVersionId]
				FROM #PossibleConsumerMaterialAndBOM PCMAB
			) 
			INSERT INTO #ConsumerBOMReferencingBaseProduct([BOMVersionId])
			SELECT BD.[BOMVersionId]
			FROM BASE_DATA BD
			INNER JOIN [CoreDataModel].[T_BOMProduct] BP ON BP.[SourceEntityId] = BD.[BOMVersionId]
			INNER JOIN [CoreDataModel].[T_Product] P ON P.[ProductId] = BP.[TargetEntityId]
			LEFT JOIN [CoreDataModel].[T_ProductAttribute] PA ON PA.[ProductId] = P.[ProductId] AND PA.[EntityTypePropertyId] = @BaseProductEntityTypeProductId
			WHERE ISNULL(PA.[Value], P.[Name]) = @BaseProduct
		END

-- PICK ONLY POSSIBLE CONSUMERS WITH BOMS RESOLVED AND THAT COULD USE THE CURRENT MATERIAL
		SELECT PCMAB.[Form], PCMAB.[MaterialName], PCMAB.[ProductName], PCMAB.[FacilityName], PCMAB.[AreaName], PCMAB.[FlowName], PCMAB.[StepName], PCMAB.[ResourceName], PCMAB.[DueDate], PCMAB.[PlannedStartDate], PCMAB.[PlannedEndDate], PCMAB.[SystemState], PCMAB.[Quantity], PCMAB.[HoldCount]
		FROM #PossibleConsumerMaterialAndBOM PCMAB
		INNER JOIN #ConsumerBOMReferencingBaseProduct CBRBP ON CBRBP.[BOMVersionId] = PCMAB.[BOMVersionId]
	END

END
GO


