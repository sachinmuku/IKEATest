BEGIN TRY
    --<summary>
    --    This script updates an existing column on a given SmartTable, sets it as Key, and re-populates the PrecedenceKeys
    --</summary>
    --<userparameters>
    --    @SmartTableName (nvarchar) => Smart Table Name to be updated
    --    @ColumnNameToUpdate (nvarchar) => Column Name from SmartTable selected to set as Key
    --    ** Special ** : From line 79 => type manually the Precedence Key list to update (Precedence Keys are deleted, and then re-populated)
    --</userparameters>

    --User parameters:
    DECLARE @ColumnNameToUpdate NVARCHAR(256) = 'MAOType';
    DECLARE @SmartTableName NVARCHAR(512) = N'CustomMAOHandlingOEEState';

    --Query derived parameters
    DECLARE @SmartTableId BIGINT = (SELECT SmartTableId FROM dbo.T_SmartTable WHERE [Name] = @SmartTableName);

    BEGIN
        DECLARE @ServiceName nvarchar(256) = 'Update SmartTable ' + @SmartTableName;
        DECLARE @ServiceHistoryId bigint;
        EXECUTE [dbo].[P_CreateServiceHistoryId] -1, @ServiceName, 'System', 'System', @ServiceHistoryId OUTPUT;

        DECLARE @LastOperationHistorySequence BIGINT = 0;

        DECLARE @NvarCharScalarTypeId bigint;
        DECLARE @BitScalarTypeId bigint;

        SELECT @NvarCharScalarTypeId = ScalarTypeId from dbo.T_ScalarType where [Name] = 'nVarchar';
        SELECT @BitScalarTypeId = ScalarTypeId from dbo.T_ScalarType where [Name] = 'Bit';

        BEGIN TRANSACTION

            -- Update column's IsKey property
            IF ISNULL(@SmartTableId, 0) > 0 /*AND NOT EXISTS(
                SELECT * 
                FROM T_SmartTableProperty
                WHERE SmartTableId = @SmartTableId
                    AND [Name] = @ColumnNameToUpdate
                )*/
            BEGIN
                -- Update LastOperationSequence
                SET @LastOperationHistorySequence = @LastOperationHistorySequence + 1;

                --Obtain ReferenceTypeId and ReferencePropertyId
                DECLARE @EntityReferenceTypeId bigint;
                DECLARE @EntityReferencePropertyId bigint;

                SELECT @EntityReferenceTypeId = EntityTypeId 
                FROM dbo.T_EntityType 
                WHERE [Name] = @ColumnNameToUpdate;
        
                SELECT @EntityReferencePropertyId = EntityTypePropertyId 
                FROM dbo.T_EntityTypeProperty 
                WHERE EntityTypeId = @EntityReferenceTypeId
                    AND [Name] = 'Name';

                --Update PropertyId
                UPDATE [dbo].[T_SmartTableProperty] 
                SET IsKey = 1,
                    LastOperationHistorySeq = @LastOperationHistorySequence
                WHERE [Name] = @ColumnNameToUpdate
                    AND SmartTableId = @SmartTableId;
                PRINT 'IsKey Updated';

                -- Update LastOperationSequence
                SET @LastOperationHistorySequence = @LastOperationHistorySequence + 1;
            END

            -- Delete PrecedenceKeys and insert new ones
            DELETE FROM [dbo].[T_SmartTablePrecedenceKey]
            WHERE SmartTableId = @SmartTableId;

            SET @LastOperationHistorySequence = @LastOperationHistorySequence + 1;

            -- Insert new PrecedenceKeys
            INSERT INTO [dbo].[T_SmartTablePrecedenceKey]
                ([SmartTableId],[RuleString],[RuleOrder],[CreatedBy],[CreatedOn],[ModifiedBy],[ModifiedOn],[LastServiceHistoryId],[LastOperationHistorySeq])
            VALUES
                (@SmartTableId,'Facility+Area+Resource+MAOType',1,'System',getdate(),'System',getdate(),@ServiceHistoryId,@LastOperationHistorySequence),
                (@SmartTableId,'Area+Resource+MAOType',2,'System',getdate(),'System',getdate(),@ServiceHistoryId,@LastOperationHistorySequence),
                (@SmartTableId,'Facility+Resource+MAOType',3,'System',getdate(),'System',getdate(),@ServiceHistoryId,@LastOperationHistorySequence),
                (@SmartTableId,'Facility+Area+MAOType',4,'System',getdate(),'System',getdate(),@ServiceHistoryId,@LastOperationHistorySequence),
                (@SmartTableId,'Resource+MAOType',5,'System',getdate(),'System',getdate(),@ServiceHistoryId,@LastOperationHistorySequence),
                (@SmartTableId,'Area+MAOType',6,'System',getdate(),'System',getdate(),@ServiceHistoryId,@LastOperationHistorySequence),
                (@SmartTableId,'Facility+MAOType',7,'System',getdate(),'System',getdate(),@ServiceHistoryId,@LastOperationHistorySequence);
        
            -- Regenerate schema for SmartTable
            SET @ServiceName = ('Regenerate schema for smart table ' + @SmartTableName);
            SET @LastOperationHistorySequence = 0
        
            -- Update CheckSum
            DECLARE @return_value int;
            DECLARE @BatchExecutionId uniqueidentifier;
            DECLARE @ChangeDate DATETIME = GETUTCDATE();
        
            IF EXISTS(
                SELECT * 
                FROM sys.indexes 
                WHERE object_id = OBJECT_ID(N'[UserDataModel].[T_ST_' + @SmartTableName + ']') 
                    AND [Name] = N'UC_' + @SmartTableName + '_SmartTableBusinessKey'
            )
            BEGIN
                DECLARE @QryDropConstraint NVARCHAR(MAX) = 'ALTER TABLE [UserDataModel].[T_ST_' + @SmartTableName + '] 
                    DROP CONSTRAINT [UC_' + @SmartTableName + '_SmartTableBusinessKey];';
                EXEC(@QryDropConstraint);
            END;

            IF COL_LENGTH(N'[UserDataModel].[T_ST_' + @SmartTableName + ']', 'CMF_UC_CheckSum') IS NOT NULL
            BEGIN
                DECLARE @QryDropColumn NVARCHAR(MAX) = 'ALTER TABLE [UserDataModel].[T_ST_' + @SmartTableName + ']
                    DROP COLUMN [CMF_UC_CheckSum];';
                EXEC(@QryDropColumn);
            END;
        
            EXEC @return_value = [dbo].[P_GenerateSmartTable] @BatchExecutionId = @BatchExecutionId OUTPUT, 
                @SmartTable = @SmartTableName, 
                @LastServiceHistoryId = @ServiceHistoryId, 
                @NewServiceHistoryId = @ServiceHistoryId, 
                @NewOperationSequence = @LastOperationHistorySequence,
                @ModifiedOn = @ChangeDate, 
                @ModifiedBy = 'System', 
                @UseCommandQueue = 0;
        
            UPDATE dbo.T_ServiceHistory 
            SET ServiceEndTime = GETUTCDATE() 
            WHERE ServiceHistoryId = @ServiceHistoryId;
        
        COMMIT
        --ROLLBACK
    END
END TRY
BEGIN CATCH
    ROLLBACK

    DECLARE @ErrorMessage NVARCHAR(4000);
    DECLARE @ErrorSeverity INT;
    DECLARE @ErrorState INT;

    SELECT 
        @ErrorMessage = ERROR_MESSAGE(),
        @ErrorSeverity = ERROR_SEVERITY(),
        @ErrorState = ERROR_STATE();

    -- Use RAISERROR inside the CATCH block to return error
    -- information about the original error that caused
    -- execution to jump to the CATCH block.
    RAISERROR(@ErrorMessage, -- Message text.
                @ErrorSeverity, -- Severity.
                @ErrorState -- State.
                );    
END CATCH