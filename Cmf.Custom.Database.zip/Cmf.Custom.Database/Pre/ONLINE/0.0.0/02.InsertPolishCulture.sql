DECLARE @TransactionStarted BIT = 0
BEGIN TRY

	DECLARE @ServiceHistoryId BIGINT
	DECLARE @ModifiedBy NVARCHAR(64) = 'System'
	DECLARE @ModifiedOn DATETIME = GETUTCDATE()
	DECLARE @ServiceName NVARCHAR(512) = N'Add Polish Language to System'
	DECLARE @CultureName NVARCHAR(512) = N'pl-PL'
	DECLARE @CultureDescription NVARCHAR(MAX) = N'Polish'
	DECLARE @CultureFlagImageFile NVARCHAR(MAX) = N'pl-PL.png'
	   
	IF(NOT EXISTS(SELECT * FROM [dbo].[T_Culture] C WHERE C.[Name] = @CultureName))
	BEGIN
	   
		BEGIN TRANSACTION
		
		SET @TransactionStarted = 1

		EXEC dbo.P_CreateServiceHistoryId -1, @ServiceName, @ModifiedBy, @ModifiedBy, @ServiceHistoryId OUT, @ModifiedBy, @ModifiedOn, NULL, NULL

		MERGE INTO [dbo].[T_Culture] TRG
		USING (
					SELECT @CultureName [Name]
						, @CultureDescription [Description]
						, @CultureFlagImageFile [FlagImageFile]
						, 1 [IsSystemCulture]
		) SRC ON (TRG.[Name] = SRC.[Name])
		WHEN NOT MATCHED THEN INSERT ([Name], [Description], [FlagImageFile], [IsSystemCulture]
										, [CreatedOn], [CreatedBy], [ModifiedOn], [ModifiedBy]
										, [LastServiceHistoryId], [LastOperationHistorySeq]
										, [HistoryRetentionTime], [UniversalState], [DataGroupId], [DataGroupName]) 
		VALUES(SRC.[Name], SRC.[Description], SRC.[FlagImageFile], SRC.[IsSystemCulture]
				, @ModifiedOn, @ModifiedBy, @ModifiedOn, @ModifiedBy
				, @ServiceHistoryId, 1
				, 0, 2, NULL, NULl);

		UPDATE [dbo].[T_ServiceHistory] SET [ServiceEndTime] = @ModifiedOn WHERE ServiceHistoryId = @ServiceHistoryId

		COMMIT TRANSACTION

		RAISERROR (N'Culture added.', 10, 1) WITH NOWAIT
	   
	END
	ELSE
	BEGIN
		RAISERROR (N'Culture already existing. Nothing done.', 10, 1) WITH NOWAIT
	END
END TRY
BEGIN CATCH

	IF(@TransactionStarted = 1)
	BEGIN
		ROLLBACK TRANSACTION
	END

	DECLARE @ERROR_MSG NVARCHAR(MAX) = ERROR_MESSAGE()
	PRINT @ERROR_MSG

END CATCH
