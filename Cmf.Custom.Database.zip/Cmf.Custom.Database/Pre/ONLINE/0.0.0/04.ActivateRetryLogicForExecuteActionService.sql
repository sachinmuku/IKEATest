
IF EXISTS(SELECT * FROM [Security].[T_Service] S WHERE S.[Name] = N'ExecuteAction' AND S.[ServiceContractName] = N'DynamicExecutionEngineManagement' AND S.[IsEnabledRetryLogic] = 0)
BEGIN TRY

       DECLARE @ServiceHistoryId BIGINT
       DECLARE @ModifiedBy NVARCHAR(64) = 'System'
       DECLARE @ModifiedOn DATETIME = GETUTCDATE()
	   DECLARE @ServiceName NVARCHAR(512) = N''

       BEGIN TRANSACTION

              EXEC dbo.P_CreateServiceHistoryId -1, @ServiceName, @ModifiedBy, @ModifiedBy, @ServiceHistoryId OUT, @ModifiedBy, @ModifiedOn, NULL, NULL

              UPDATE S SET S.[IsEnabledRetryLogic] = 1
				, S.[ModifiedOn] = @ModifiedOn
				, S.[ModifiedBy] = @ModifiedBy
				, S.[LastServiceHistoryId] = @ServiceHistoryId
				, S.[LastOperationHistorySeq] = 1
			  FROM [Security].[T_Service] S
			  WHERE S.[Name] = N'ExecuteAction'
				AND S.[ServiceContractName] = N'DynamicExecutionEngineManagement'
				AND S.[IsEnabledRetryLogic] = 0
       
              UPDATE [dbo].[T_ServiceHistory] SET [ServiceEndTime] = @ModifiedOn WHERE ServiceHistoryId = @ServiceHistoryId

       COMMIT TRANSACTION

END TRY
BEGIN CATCH

    ROLLBACK TRANSACTION
	DECLARE @ErrorMessage NVARCHAR(MAX) = ERROR_MESSAGE()
    PRINT @ErrorMessage

END CATCH
