DECLARE @EntityName				NVARCHAR(512)		= N'Resource'
DECLARE @AttributeName			NVARCHAR(512)		= N'UnitCompletionMode'
DECLARE	@EnumNamespace			NVARCHAR(512)		= N'Cmf.Custom.BusinessObjects.CustomUnitCompletionModeEnum'
DECLARE @ReferenceType			INTEGER				= 6 /*ENUM*/
DECLARE @UniversalState			INTEGER				= 0 /*CREATED*/
DECLARE @ScalarType				BIGINT				= (SELECT [ScalarTypeId] FROM [dbo].[T_ScalarType] WHERE [Name] = N'Int')
DECLARE @ModifiedBy				NVARCHAR(64)		= N'System'
DECLARE @ModifiedOn				DATETIME			= GETUTCDATE()
DECLARE @ServiceName			NVARCHAR(512)		= (N'Convert ' + @EntityName + N' property ' + @AttributeName + ' to Enum Reference')
DECLARE @BatchId				UNIQUEIDENTIFIER	= NULL
DECLARE @OldServiceHistoryId	BIGINT				= (SELECT [LastServiceHistoryId] FROM [dbo].[T_EntityType] ET WHERE ET.[Name] = @EntityName)
DECLARE @ServiceHistoryId		BIGINT				= 0
DECLARE @OperationHistorySeq	BIGINT				= 0
DECLARE @TransactionCommited	BIT					= 0
DECLARE @ErrorMessage			NVARCHAR(MAX)		= N''


/* CHECK IF PROPERTY EXISTS AND HAS INCORRECT TYPE */
DECLARE @EntityTypePropertyId	BIGINT	= (
	SELECT ISNULL(MAX(ETP.[EntityTypePropertyId]), 0)
	FROM [dbo].[T_EntityType] ET
	INNER JOIN [dbo].[T_EntityTypeProperty] ETP ON ETP.[EntityTypeId] = ET.[EntityTypeId]
	WHERE ET.[Name] = @EntityName
		AND ETP.[Name] = @AttributeName
		AND ETP.[ReferenceType] <> @ReferenceType /* ENUM */
	)

IF(@EntityTypePropertyId > 0)
BEGIN TRY

	BEGIN TRANSACTION

	-- OPEN SERVICE HISTORY
	EXEC dbo.P_CreateServiceHistoryId -1, @ServiceName, @ModifiedBy, @ModifiedBy, @ServiceHistoryId OUT, @ModifiedBy, @ModifiedOn, NULL, NULL

	-- UPDATE ENTITY TYPE
	SET @OperationHistorySeq = @OperationHistorySeq + 1
	UPDATE [dbo].[T_EntityTypeProperty]
	SET [ScalarTypeId] = @ScalarType
		, [ScalarSize] = 0
		, [ReferencedObjectId] = 0
		, [ReferenceType] = @ReferenceType
		, [UniversalState] = 0
		, [ReferenceName] = @EnumNamespace
		, [LastServiceHistoryId] = @ServiceHistoryId
		, [LastOperationHistorySeq] = @OperationHistorySeq
		, [ModifiedOn] = @ModifiedOn
		, [ModifiedBy] = @ModifiedBy
	WHERE [EntityTypePropertyId] = @EntityTypePropertyId

	-- MIGRATE DATA
	IF(OBJECT_ID(N'tempdb..#CustomResourceValueMapping') IS NOT NULL)
		DROP TABLE #CustomResourceValueMapping

	-- COLLECT RESOURCE ATTRIBUTES REQUIRING MIGRATION
	;WITH ENUM_MAPPING AS 
	(
		SELECT 0 EnumId, N' Manual' LookupValue
		UNION
		SELECT 1, N'ManualOutsorting'
		UNION
		SELECT 2, N'Automation'
	)
	SELECT RA.[ResourceId] [ResourceId]
		, RA.[EntityTypePropertyId] [EntityTypePropertyId]
		, CONVERT(NVARCHAR, EM.[EnumId]) [Value]
		, @ModifiedBy [ModifiedBy]
		, @ModifiedOn [ModifiedOn]
		, @ServiceHistoryId [LastServiceHistoryId]
		, @OperationHistorySeq [LastOperationHistorySeq]
	INTO #CustomResourceValueMapping
	FROM [CoreDataModel].[T_ResourceAttribute] RA
	INNER JOIN ENUM_MAPPING EM ON EM.[LookupValue] = RA.[Value]
	WHERE RA.[EntityTypePropertyId] = @EntityTypePropertyId

	-- UPDATE RESOURCE AND ATTRIBUTES IF ANY FOUND FOR UPDATE
	IF(EXISTS(SELECT * FROM #CustomResourceValueMapping))
	BEGIN

		SET @OperationHistorySeq = @OperationHistorySeq + 1

		-- UPDATE RESOURCE
		UPDATE R
		SET R.[LastServiceHistoryId] = @ServiceHistoryId
			, R.[LastOperationHistorySeq] = @OperationHistorySeq
			, R.[ModifiedOn] = @ModifiedOn
			, R.[ModifiedBy] = @ModifiedBy
		FROM #CustomResourceValueMapping CRVM
		INNER JOIN [CoreDataModel].[T_Resource] R ON R.[ResourceId] = CRVM.[ResourceId]
		
		-- UPDATE ATTRIBUTE
		UPDATE RA
		SET RA.[LastServiceHistoryId] = CRVM.[LastServiceHistoryId]
			, RA.[LastOperationHistorySeq] = CRVM.[LastOperationHistorySeq]
			, RA.[ModifiedOn] = CRVM.[ModifiedOn]
			, RA.[ModifiedBy] = CRVM.[ModifiedBy]
			, RA.[Value] = CRVM.[Value]
		FROM #CustomResourceValueMapping CRVM
		INNER JOIN [CoreDataModel].[T_ResourceAttribute] RA ON RA.[ResourceId] = CRVM.[ResourceId]
			AND RA.[EntityTypePropertyId] = CRVM.[EntityTypePropertyId]

	END

	-- REGENERATE ENTITY TYPE (MAKE CHANGES EFFECTIVE)
	SET @OperationHistorySeq = @OperationHistorySeq + 1
	EXEC [dbo].[P_GenerateEntityType] @Type = @EntityName, @BatchExecutionId = @BatchId OUTPUT, @PrintScriptOnly = 0, @WithTriggers = 1, @UseCommandQueue = 0, @LastServiceHistoryId = @OldServiceHistoryId, @NewServiceHistoryId = @ServiceHistoryId, @NewOperationSequence = @OperationHistorySeq /* OperationHistorySeq */, @ModifiedOn = @ModifiedOn, @ModifiedBy = @ModifiedBy

	-- CLOSE SERVICE HISTORY ID
	UPDATE [dbo].[T_ServiceHistory] SET [ServiceEndTime] = @ModifiedOn WHERE ServiceHistoryId = @ServiceHistoryId

	-- COMMIT TRANSACTION
	COMMIT TRANSACTION
	
	-- MARK TRANSACTION AS COMMITED
	SET @TransactionCommited = 1
	PRINT 'Transaction Commited'

END TRY
BEGIN CATCH
	
	-- ONLY ROLLBACK IF TRANSACTION NOT YET COMMITED
	IF(@TransactionCommited = 0)
	BEGIN
		ROLLBACK
	END

	SET @ErrorMessage = ERROR_MESSAGE()
	PRINT @ErrorMessage
END CATCH