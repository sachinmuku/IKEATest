IF EXISTS (SELECT * 
FROM SYSOBJECTS
WHERE [id] = OBJECT_ID(N'Custom.P_GetRunningMOs') AND OBJECTPROPERTY([id], N'IsProcedure') = 1 )
BEGIN
    drop procedure [Custom].[P_GetRunningMOs]
END
GO

CREATE PROCEDURE [Custom].[P_GetRunningMOs]
    @ResourceName NVARCHAR(512) = NULL
    , @FacilityName NVARCHAR(512) = NULL
    , @AreaName NVARCHAR(512) = NULL
AS
BEGIN

    SET NOCOUNT ON

    DECLARE @CurTimeStamp DATETIME = GETDATE()
    DECLARE @ExpectedSetupTime int = 10; -- TODO: Change WITH the expected value
    DECLARE @FlowERPOperationCodeETP BIGINT
    DECLARE @LastStateChangeTimestampAttributeETP BIGINT
    DECLARE @CompletedQuantityAttributeETP BIGINT
    DECLARE @OrderMaterialForm NVARCHAR(512)
    DECLARE @MaskFacility NVARCHAR(514) = (N'%' + ISNULL(@FacilityName, N'') + N'%')
    DECLARE @MaskArea NVARCHAR(514) = (N'%' + ISNULL(@AreaName, N'') + N'%')
    DECLARE @MaskResource NVARCHAR(514) = (N'%' + ISNULL(@ResourceName, N'') + N'%')


    /* create temparaty tables */    
    IF(OBJECT_ID('tempdb..#EligibleResources') IS NOT NULL) DROP TABLE #EligibleResources
    IF(OBJECT_ID('tempdb..#EligibleMaterials') IS NOT NULL) DROP TABLE #EligibleMaterials
    IF(OBJECT_ID('tempdb..#ResultData') IS NOT NULL) DROP TABLE #ResultData

    CREATE TABLE #EligibleResources
    (
                    [FacilityId] BIGINT
                    , [AreaId] BIGINT
                    , [ResourceId] BIGINT
                    , [ResourceName] NVARCHAR(512)
                    , [StateModelStateName] NVARCHAR(512)
                    , [LastStateChangeTimeStamp] DATETIME
                    , [LineStateReason] NVARCHAR(512)
    )              

    CREATE TABLE #EligibleMaterials
    (
                    [MaterialId] BIGINT
                    , [AreaId] BIGINT
                    , [ResourceId] BIGINT
                    , [FlowOperationCode] NVARCHAR(512)
                    , [ProductionOrderId] BIGINT
                    , [MaterialName] NVARCHAR(512)
                    , [PrimaryQuantity] DECIMAL(18,8)
                    , [TrackInDate] DATETIME
                    , [MainStateModelStateId] BIGINT
                    , [ResourceOrderRank] INT
    )

    CREATE TABLE #ResultData
    (
                    [Line] NVARCHAR(512)
                    , [MOName] NVARCHAR(512)
                    , [TrackInDate] DATETIME
                    , [ProjectedCycleTime] DECIMAL(18,8)
                    , [ExpectedSetupTime] DECIMAL(18,8)
                    , [ScheduledQuantity] DECIMAL(18,8)
                    , [CompletedQuantity] DECIMAL(18,8)
                    , [RemainingQuantity] DECIMAL(18,8)
                    , [LineState] NVARCHAR(512)
                    , [LineStateReason] NVARCHAR(512)
                    , [LineStateDuration] DECIMAL(18,8)
                    , [SetupEstimatedFinishTime] NVARCHAR(512)
                    , [EstimatedMOFinishedTime] NVARCHAR(512)
                    , [Name] NVARCHAR(512)
                    , [ResourceOrderRank] INTEGER
    )

    /* retrieve flow erp operation code etp id */
    SELECT @FlowERPOperationCodeETP = ISNULL(max(ETP.[EntityTypePropertyId]), 0)
    FROM [dbo].T_EntityType ET
    INNER JOIN [dbo].T_EntityTypeProperty ETP on ETP.EntityTypeId = ET.EntityTypeId
    WHERE ET.[Name] = N'Flow' AND ETP.[Name] = 'ERPOperationCode'
                

    /* retrieve resource last state change timestamp */
    SELECT @LastStateChangeTimestampAttributeETP = ISNULL(max(ETP.[EntityTypePropertyId]), 0)
    FROM [dbo].T_EntityType ET
    INNER JOIN [dbo].T_EntityTypeProperty ETP on ETP.EntityTypeId = ET.EntityTypeId
    WHERE ET.[Name] = N'Resource'             AND ETP.[Name] = N'LastStateChangeTimeStamp'


    /* retrieve material complete quantity */
    SELECT @CompletedQuantityAttributeETP = ISNULL(max(ETP.[EntityTypePropertyId]), 0)
    FROM [dbo].T_EntityType ET
    INNER JOIN [dbo].T_EntityTypeProperty ETP on ETP.EntityTypeId = ET.EntityTypeId
    WHERE ET.[Name] = N'Material' AND ETP.[Name] = N'CompletedQuantity'
                
    /* retrieve material order [Form] */
    SET @OrderMaterialForm = [dbo].F_GetConfigStringValue(N'/Cmf/Custom/MaterialTracking/OrderMaterialForm/', N'')
                
    /* get Eligible Resources */
    INSERT INTO #EligibleResources([FacilityId], [AreaId], [ResourceId])
    SELECT F.[FacilityId]
                    , A.[AreaId]
                    , R.[ResourceId]
    FROM [CoreDataModel].[T_Resource] R
    INNER JOIN [CoreDataModel].[T_Area] A on A.[AreaId] = R.[AreaId]
    INNER JOIN [CoreDataModel].[T_Facility] F on F.[FacilityId] = A.[FacilityId]
    LEFT JOIN [CoreDataModel].[T_SubResource] SR on SR.[TargetEntityId] = R.[ResourceId]
    WHERE R.[UniversalState] = 2                                   -- RESOURCE IS ACTIVE IN THE SYSTEM
                    AND SR.[SubResourceId] is NULL                              -- ENSURES RESOURCE HAS NO RELATIONS TO PARENT, BEING TOPMOST
                    AND R.[ProcessingType] = 0                                       -- 0 IS PROCESSING TYPE = PROCESS
                    AND R.[Name] LIKE @MaskResource                     -- CONSIDER RESOURCE [Name] FILTER
                    AND A.[Name] LIKE @MaskArea                                              -- CONSIDER AREA [Name] FILTER
                    AND F.[Name] LIKE @MaskFacility                           -- CONSIDER FACILITY [Name] FILTER


    -- UPDATE WITH STATE MODEL AND LAST STATE CHANGE ATTRIBUTE VALUE
    -- DO NOT FORCE STATE EXISTENCE FOR LISTING AS IT IS NOT MANDATORY IN MES
    -- DO NOT FORCE EXISTENCE OF LAST STATE CHANGE AS IT MAY NOT HAVE OCCURRED
    MERGE INTO #EligibleResources TRG
    USING
    (
                    SELECT R.[ResourceId]
                                    , R.[Name] [ResourceName]
                                    , SMSR.[Name] [StateModelStateName]
                                    , CONVERT(DATETIME, CASE ISNULL(RA.[Value], '') WHEN '' THEN SMSR.ModifiedOn ELSE RA.ModifiedOn END) [LastStateChangeTimeStamp]
                                    , R.[MainStateModelStateReason] [LineStateReason]
                    FROM #EligibleResources ER
                    INNER JOIN [CoreDataModel].[T_Resource] R on R.[ResourceId] = ER.[ResourceId]
                    LEFT JOIN [dbo].[T_StateModelState] AS SMSR on SMSR.[StateModelStateId] = R.[MainStateModelStateId] -- DO NOT FORCE STATE TO EXIST FOR LISTING
                    LEFT JOIN [CoreDataModel].T_ResourceAttribute RA on RA.[ResourceId] = R.[ResourceId] AND RA.[EntityTypePropertyId] = @LastStateChangeTimestampAttributeETP
    ) SRC on (TRG.[ResourceId] = SRC.[ResourceId])
    WHEN MATCHED THEN UPDATE SET TRG.[StateModelStateName] = SRC.[StateModelStateName]
                                                                                                                                    , TRG.[LastStateChangeTimeStamp] = SRC.[LastStateChangeTimeStamp]
                                                                                                                                    , TRG.[ResourceName] = SRC.[ResourceName]
                                                                                                                                    , TRG.[LineStateReason] = SRC.[LineStateReason];



    /* collect all Eligible Materials */
    ;WITH ELIGIBLE_MATERIALS AS
    (
                    SELECT M.[MaterialId]
                                    , ER.[AreaId]
                                    , ER.[ResourceId]
                                    , M.[ProductionOrderId]
                                    , M.[Name]
                                    , M.[PrimaryQuantity]
                                    , M.[TrackInDate]
                                    , M.[MainStateModelStateId]
                                    , SUBSTRING(M.[FlowPath],
                                                                                                                                    CASE CHARINDEX('/', REVERSE(M.[FlowPath]), CHARINDEX('/', REVERSE(M.[FlowPath]), 1) + 1)
                                                                                                                                    WHEN 0 THEN 1
                                                                                                                                    ELSE LEN(M.[FlowPath]) - CHARINDEX('/', REVERSE(M.[FlowPath]), CHARINDEX('/', REVERSE(M.[FlowPath]), 1) + 1) + 2
                                                                                                                                    END
                                                                                                                    , CASE CHARINDEX('/', REVERSE(M.[FlowPath]), CHARINDEX('/', REVERSE(M.[FlowPath]), 1) + 1)
                                                                                                                                    WHEN 0 THEN CHARINDEX('/', M.[FlowPath]) - 1
                                                                                                                                    ELSE CHARINDEX('/', REVERSE(M.[FlowPath]), CHARINDEX('/', REVERSE(M.[FlowPath]), 1) + 1) - CHARINDEX('/', REVERSE(M.[FlowPath]), 1) - 1
                                                                                                                                    END) [LeafFlowToken]
                                    , DENSE_RANK() OVER (PARTITION BY ER.[ResourceId] ORDER BY ISNULL(M.[TrackInDate], GETDATE()), MR.[Order]) [ResourceOrderRank]
                    FROM #EligibleResources ER
                    INNER JOIN [CoreDataModel].T_MaterialResource MR on MR.[TargetEntityId] = ER.[ResourceId]
                    INNER JOIN [CoreDataModel].T_Material M on M.[MaterialId] = MR.[SourceEntityId]
                    WHERE M.[SystemState] IN (1, 2)                                                                            -- CONSIDER MATERIALS WITH SYSTEM STATE = IN PROCESS, DISPATCHED
                                    AND M.[Form] = @OrderMaterialForm                                -- FILTER BY ORDER FORM
                                    AND M.[ParentMaterialId] IS NULL                                         -- CONSIDER ONLY TOP MOST MATERIALS
    )
    INSERT INTO #EligibleMaterials([MaterialId], [AreaId], [ResourceId], [FlowOperationCode], [ProductionOrderId], [MaterialName], [PrimaryQuantity], [TrackInDate], [MainStateModelStateId], [ResourceOrderRank])
    SELECT EM.[MaterialId]
                    , EM.[AreaId]
                    , EM.[ResourceId]
                    , FA.[Value]
                    , EM.[ProductionOrderId]
                    , EM.[Name]
                    , EM.[PrimaryQuantity]
                    , EM.[TrackInDate]
                    , EM.[MainStateModelStateId]
                    , EM.[ResourceOrderRank]
    FROM ELIGIBLE_MATERIALS EM
    INNER JOIN [CoreDataModel].T_Flow F ON F.[Name] =  LEFT(EM.[LeafFlowToken], CHARINDEX(':', EM.[LeafFlowToken], 1) - 1)
                    AND F.[Version] = 0  -- GET FLOW
    LEFT JOIN [CoreDataModel].T_FlowAttribute FA on FA.[FlowId] = F.[FlowId] 
                    AND FA.[EntityTypePropertyId] = @FlowERPOperationCodeETP -- GET ERP OPERATION CODE
                
    INSERT INTO #ResultData
    SELECT ISNULL(ER.[ResourceName], N'') AS [Line]
                    , ISNULL(EM.[MaterialName], N'') AS [MOName]
                    , [dbo].F_ConvertTimeFromUtc(EM.[TrackInDate]) AS [TrackInDate]
                    , POR.[ProjectedCycleTime]
                    , CASE ISNULL(SMSM.[Name], '') WHEN 'setup' THEN @ExpectedSetupTime ELSE 0 END AS [ExpectedSetupTime]
                    , ISNULL(MA.Value, 0) + ISNULL(EM.[PrimaryQuantity], 0) AS [ScheduledQuantity]
                    , ISNULL(MA.Value, 0) AS [CompletedQuantity]
                    , ISNULL(EM.[PrimaryQuantity], 0) AS [RemainingQuantity]
                    , ISNULL(ER.[StateModelStateName], N'') AS [LineState]
                    , ISNULL(ER.[LineStateReason], N'') AS [LineStateReason]
                    , ISNULL(ROUND(DATEDIFF(SECOND, ER.[LastStateChangeTimeStamp], @CurTimeStamp) / 60.0, 2), 0) AS [LineStateDuration]
                    , ISNULL(CONVERT(NVARCHAR, [dbo].F_ConvertTimeFromUtc( 
                                                                    CASE SMSM.[Name]
                                                                                    --TODO Setup calculation:
                                                                                    WHEN 'SETUP' THEN DATEADD(SECOND, @ExpectedSetupTime, @CurTimeStamp)
                                                                                    ELSE NULL
                                                                                    END
                                                                    ), 21), N'') [SetupEstimatedFinishTime] -- TODO: Material Setup Estimated Finish Time?
                                                                    , ISNULL(CONVERT(NVARCHAR, (
                                                                                    CASE ISNULL(POR.[ProjectedCycleTime], -1)
                                                                                                    WHEN -1 THEN NULL
                                                                                                    ELSE (
                                                                                                            CASE SMSM.[Name]
                                                                                                            --TODO Setup calculation:
                                                                                                            WHEN 'SETUP' THEN DATEADD(SECOND, @ExpectedSetupTime, @CurTimeStamp)
                                                                                                            ELSE DATEADD(SECOND, EM.[PrimaryQuantity] / ISNULL(POR.[ProjectedCycleTime], 1), @CurTimeStamp)
                                                                                                            END 
                                                                                                            )
                                                                                                    END
                                    ), 21), N'') AS [EstimatedMOFinishedTime] --Estimated MO Finished based on Cycle Tyme AND remaining quantity
                    , SMSM.[Name] AS [StateModelStateName]
                    , EM.[ResourceOrderRank]
    FROM #EligibleResources ER
    LEFT JOIN #EligibleMaterials EM on EM.[ResourceId] = ER.[ResourceId]
    LEFT JOIN [UserDataModel].[T_CustomPOOperationResource] POR on POR.[TargetEntityId] = EM.[ResourceId]                AND POR.[SourceEntityId] = EM.[ProductionOrderId]     AND POR.[OperationCode] = EM.[FlowOperationCode]
    LEFT JOIN [CoreDataModel].[T_MaterialAttribute] MA on MA.[MaterialId] = EM.[MaterialId] AND MA.[EntityTypePropertyId] = @CompletedQuantityAttributeETP
    LEFT JOIN [dbo].[T_StateModelState] SMSM on SMSM.[StateModelStateId] = EM.[MainStateModelStateId]

    /*--------------------------------------------------------*/
    /* select summary list, including all materials           */
    /*--------------------------------------------------------*/
    ;WITH LINE_DATA AS
    (
        SELECT RD.[Line]
            , RD.[LineState]
            , RD.[LineStateReason]
            , RD.[LineStateDuration]
            , CONVERT(NVARCHAR, DATEADD(SECOND, SUM(RD.[RemainingQuantity] / RD.[ProjectedCycleTime]), @CurTimeStamp), 21) [ProductionExpectedTime]
        FROM #EligibleResources ER
        LEFT JOIN #ResultData RD ON RD.[Line] = ER.[ResourceName]
        GROUP BY RD.[Line]
            , RD.[LineState]
            , RD.[LineStateReason]
            , RD.[LineStateDuration]
    ), LINE_CURRENT_ORDER_DATA AS
    (
        SELECT *
        FROM
        (
            SELECT [Line]
            , [RemainingQuantity] / [ProjectedCycleTime] AS [MORemainingTime]
            , [Name]
            , [ProjectedCycleTime]
            , [Name] [MOState]
            , [MOName]
            , [ScheduledQuantity]
            , [CompletedQuantity]
            , [RemainingQuantity]
            , [ExpectedSetupTime]
            , [SetupEstimatedFinishTime]
            , [EstimatedMOFinishedTime]
            , DENSE_RANK() OVER (PARTITION BY [Line] ORDER BY [TrackInDate] ASC, [MOName] ASC) [RankedOrder]
            FROM #ResultData
            WHERE [TrackInDate] IS NOT NULL
                            AND [ResourceOrderRank] = 1
        ) SRC WHERE SRC.[RankedOrder] = 1
    )
    SELECT LD.*, LCOD.[MOName] [CurrentOrder], LCOD.[MOState] [OrderState]
        , LCOD.[SetupEstimatedFinishTime] [EstimatedSetupCompletion]
        , LCOD.[EstimatedMOFinishedTime] [EstimatedOrderCompletion]
        , LCOD.[ScheduledQuantity]
        , LCOD.[CompletedQuantity]
        , LCOD.[RemainingQuantity]
    FROM LINE_DATA LD
    LEFT JOIN LINE_CURRENT_ORDER_DATA LCOD ON LCOD.[Line] = LD.[Line]
    ORDER BY [Line]
                                               
    /*--------------------------------------------------------*/
    /* SELECT complete list                                   */
    /*--------------------------------------------------------*/
    SELECT [Line]
        , [MOName]
        , [ScheduledQuantity]
        , [CompletedQuantity]
        , [RemainingQuantity]
        , [LineState]
        , [LineStateReason]
        , [LineStateDuration]
        , [SetupEstimatedFinishTime] as [EstimatedSetupCompletion]
		, [EstimatedMOFinishedTime] as [EstimatedOrderCompletion]
        , [Name]
    FROM #ResultData
    WHERE [Name] IS NOT NULL
    ORDER BY [Line], [ResourceOrderRank]
                
END
GO
