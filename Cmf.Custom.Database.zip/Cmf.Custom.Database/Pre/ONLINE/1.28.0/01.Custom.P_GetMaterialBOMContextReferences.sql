IF EXISTS (
		SELECT * 
			FROM SYSOBJECTS
			WHERE [id] = OBJECT_ID(N'Custom.P_GetMaterialBOMContextReferences') AND OBJECTPROPERTY([id], N'IsProcedure') = 1
		)
BEGIN
    DROP PROCEDURE [Custom].[P_GetMaterialBOMContextReferences]
END
GO

CREATE PROCEDURE [Custom].[P_GetMaterialBOMContextReferences]
	@Materials NVARCHAR(MAX) = NULL
AS
BEGIN
	
	SET NOCOUNT ON

	IF(OBJECT_ID(N'tempdb..#MaterialsToProcess') IS NOT NULL)
		DROP TABLE #MaterialsToProcess

	CREATE TABLE #MaterialsToProcess([MaterialId] BIGINT)

	DECLARE @InternalMaterialList NVARCHAR(MAX) = LTRIM(RTRIM(ISNULL(@Materials, N'')))
	IF(@InternalMaterialList <> N'')
	BEGIN
		INSERT INTO #MaterialsToProcess([MaterialId])
		SELECT DISTINCT CONVERT(BIGINT, A.SplitValue) FROM dbo.F_Split(@InternalMaterialList, N';') A
	END


	SELECT M.MaterialId, BC.*
	FROM #MaterialsToProcess SRC
	INNER JOIN [CoreDataModel].[T_Material] M ON M.[MaterialId] = SRC.[MaterialId]
	INNER JOIN [CoreDataModel].[T_ST_BOMContext] BC ON BC.[Material] = M.[Name]
	WHERE BC.[ChangeSetId] IS NULL

END
GO