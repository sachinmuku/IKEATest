/****** Object:  StoredProcedure [Custom].[P_ResolveCustomResourceStateReclassificationPermissionsForAllRolesOfUser]    Script Date: 23-Dec-19 16:03:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = 'Custom')
BEGIN
EXEC('CREATE SCHEMA Custom')
END
GO

IF EXISTS ( SELECT * 
            FROM   sysobjects 
            WHERE  id = object_id(N'[Custom].[P_ResolveCustomResourceStateReclassificationPermissionsForAllRolesOfUser]') 
                   and OBJECTPROPERTY(id, N'IsProcedure') = 1 )
BEGIN
    DROP PROCEDURE [Custom].[P_ResolveCustomResourceStateReclassificationPermissionsForAllRolesOfUser]
END
GO

CREATE PROCEDURE [Custom].[P_ResolveCustomResourceStateReclassificationPermissionsForAllRolesOfUser]
	@UserId BIGINT,
	@StateModelName nvarchar(256) = NULL,
	@StateModelStateName nvarchar(256) = NULL,
	@Reason nvarchar(256) = NULL
AS
BEGIN
	
	-- Declare Tables
	DECLARE @UserRoles TABLE (RoleId BIGINT, RoleName NVARCHAR(512));
	
	-- Get User Hierarchy of roles
	WITH UserRoles
	AS
	(
		SELECT R.RoleId, R.Name
		FROM Security.T_Role_User AS UR
		INNER JOIN Security.T_Role AS R
			ON R.RoleId = UR.RoleId
		WHERE UR.UserId = @UserId
	),
	ParentRoles(RoleId, Name, ChildRoleId) 
	AS 
	( 
		SELECT 
			R.RoleId, 
			R.Name, 
			UR.RoleId
		FROM UserRoles AS UR
		INNER JOIN Security.T_Role_Role RR 
			ON RR.ChildRoleId = UR.RoleId
		INNER JOIN Security.T_Role AS R 
			ON R.RoleId = RR.ParentRoleId
		UNION ALL
		SELECT 
			R.RoleId, 
			R.Name, 
			DR.RoleId
		FROM Security.T_Role R
		INNER JOIN Security.T_Role_Role RR 
			ON RR.ParentRoleId = R.RoleId 
		INNER JOIN ParentRoles DR 
			ON DR.RoleId = RR.ChildRoleId
	)
	INSERT INTO @UserRoles
	SELECT 
		RoleId, 
		Name
	FROM ParentRoles 
	UNION 
	SELECT 
		RoleId, 
		Name
	FROM UserRoles;

	-- Get all permissions for all the User Roles
	SELECT RolePermissions.*
	FROM @UserRoles AS UR
	CROSS APPLY
	(
		SELECT *
		FROM [UserDataModel].[F_ST_ResolveCustomResourceStateReclassificationPermissions] (0, UR.RoleName, @StateModelName, @StateModelStateName, @Reason)
	) AS RolePermissions

END
