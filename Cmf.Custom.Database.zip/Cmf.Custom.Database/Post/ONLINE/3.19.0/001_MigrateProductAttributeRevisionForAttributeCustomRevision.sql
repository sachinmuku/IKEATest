BEGIN TRY

       DECLARE @ServiceHistoryId BIGINT
       DECLARE @ModifiedBy NVARCHAR(64) = 'System'
       DECLARE @ModifiedOn DATETIME = GETUTCDATE()
	   DECLARE @ServiceName NVARCHAR(512) = N'Migrate Product Revision Attribute to CustomRevision Attribute'
	   
	   DECLARE @EntityTypeId BIGINT = (SELECT [EntityTypeId] FROM [dbo].[T_EntityType] Where [Name] = 'Product')
	   DECLARE @OldEntityTypePropertyId BIGINT = (SELECT [EntityTypePropertyId] FROM [dbo].[T_EntityTypeProperty] where EntityTypeId = @EntityTypeId and [Name] = 'Revision')
	   DECLARE @NewEntityTypePropertyId BIGINT = (SELECT [EntityTypePropertyId] FROM [dbo].[T_EntityTypeProperty] where EntityTypeId = @EntityTypeId and [Name] = 'CustomRevision')

       BEGIN TRANSACTION
	   
	   IF(NOT EXISTS (Select * FROM [CoreDataModel].[T_ProductAttribute] where [EntityTypePropertyId] = @NewEntityTypePropertyId)
		AND (SELECT PropertyType FROM [dbo].[T_EntityTypeProperty] where [EntityTypePropertyId] = @OldEntityTypePropertyId 
			and EntityTypeId = @EntityTypeId) = 0)
			BEGIN
				EXEC dbo.P_CreateServiceHistoryId -1, @ServiceName, @ModifiedBy, @ModifiedBy, @ServiceHistoryId OUT, @ModifiedBy, @ModifiedOn, NULL, NULL
			  
					  ;WITH BASE_DATA AS
					  (
						SELECT TEMP.[ProductId], TEMP.[Index], TEMP.[Value] AS [RevisionValue]
						FROM (
							SELECT P.[Name], P.[ProductId], PAOLD.[Index], PAOLD.[Value], row_number() OVER (PARTITION BY P.[Name] ORDER BY PAOLD.[ModifiedOn] DESC) AS RN
							FROM [CoreDataModel].[T_ProductAttribute] as PAOLD 
							INNER JOIN [CoreDataModel].[T_Product] as P ON PAOLD.[ProductId] = P.[ProductId]
							LEFT JOIN [CoreDataModel].[T_ProductAttribute] PANEW ON PANEW.[ProductId] = PAOLD.[ProductId] AND PANEW.[EntityTypePropertyId] = @NewEntityTypePropertyId
							WHERE PAOLD.[EntityTypePropertyId] = @OldEntityTypePropertyId
							AND ISNULL(PAOLD.[Value], N'') <> N''
							AND PANEW.[ProductId] IS NULL
							AND P.[UniversalState] <> 4
						) TEMP
						WHERE TEMP.RN=1
					  )
						Insert Into [CoreDataModel].[T_ProductAttribute] ([ProductId], [EntityTypePropertyId], [Name], [Index], [Value],[CreatedBy], [CreatedOn], [ModifiedBy], [ModifiedOn], [LastServiceHistoryId], [LastOperationHistorySeq])
						SELECT [ProductId], @NewEntityTypePropertyId, N'CustomRevision', [Index], [RevisionValue], @ModifiedBy, @ModifiedOn, @ModifiedBy, @ModifiedOn, @ServiceHistoryId, 1
						FROM BASE_DATA
              
					DELETE T_EntityTypeProperty where EntityTypeId = @EntityTypeId AND [EntityTypePropertyId] = @OldEntityTypePropertyId
					DELETE CoreDataModel.T_ProductAttribute WHERE [EntityTypePropertyId] = @OldEntityTypePropertyId	

				UPDATE [dbo].[T_ServiceHistory] SET [ServiceEndTime] = @ModifiedOn WHERE ServiceHistoryId = @ServiceHistoryId
			END
			  
       COMMIT TRANSACTION

END TRY
BEGIN CATCH

    ROLLBACK TRANSACTION
    SELECT ERROR_MESSAGE()

END CATCH