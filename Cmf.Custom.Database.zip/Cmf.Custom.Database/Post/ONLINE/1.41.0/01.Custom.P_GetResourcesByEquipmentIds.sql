SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = 'Custom')
BEGIN
EXEC('CREATE SCHEMA Custom')
END
GO

IF EXISTS ( SELECT * 
            FROM   sysobjects 
            WHERE  id = object_id(N'[Custom].[P_GetResourcesByEquipmentIds]') 
                   and OBJECTPROPERTY(id, N'IsProcedure') = 1 )
BEGIN
    DROP PROCEDURE [Custom].[P_GetResourcesByEquipmentIds]
END
GO

CREATE PROCEDURE [Custom].[P_GetResourcesByEquipmentIds]
(
    @EquipmentIds [dbo].TY_ParametersList READONLY -- One or more equipment Ids of the resources (only key will be set)
)
AS 
BEGIN

	-- Get all the resources that match the equipment Ids
	SELECT DISTINCT 
		R.[ResourceId], 
		R.[Name]
	FROM [CoreDataModel].[T_Resource] AS R
	INNER JOIN [CoreDataModel].[T_ResourceAttribute] AS RA 
		ON RA.[ResourceId] = R.[ResourceId] 
		AND RA.[Name] = 'ERPEquipmentIdentifiers'
	WHERE RA.[Value] IN 
		(
			SELECT [ParameterName] 
			FROM @EquipmentIds
		);

END;