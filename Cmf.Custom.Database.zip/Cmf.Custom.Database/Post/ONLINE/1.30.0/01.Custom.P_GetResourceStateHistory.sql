/****** Object:  StoredProcedure [Custom].[P_GetResourceStateHistory]    Script Date: 03-Jun-19 14:45:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = 'Custom')
BEGIN
EXEC('CREATE SCHEMA Custom')
END
GO

IF EXISTS ( SELECT * 
            FROM   sysobjects 
            WHERE  id = object_id(N'[Custom].[P_GetResourceStateHistory]') 
                   and OBJECTPROPERTY(id, N'IsProcedure') = 1 )
BEGIN
    DROP PROCEDURE [Custom].[P_GetResourceStateHistory]
END
GO

CREATE PROCEDURE [Custom].[P_GetResourceStateHistory]
	@UserId BIGINT,
	@ResourceId BIGINT	
AS
BEGIN
			
	-- Declare Variables
	DECLARE 
		@DateEnd DATETIME = GetUtcDate(),
		@DateStart DATETIME,
		@TimeFrame INT,
		@SystemName NVARCHAR(512) = dbo.F_GetSystemName();

	DECLARE 
		@ODSLink NVARCHAR(512) = 'cm' + @SystemName + 'ODSLink',
		@ODSDataBase NVARCHAR(512) = @SystemName + 'ODS';
		
	IF(OBJECT_ID(N'tempdb..#UserRoles') IS NOT NULL)
		DROP TABLE #UserRoles
		
	IF(OBJECT_ID(N'tempdb..#ResourceHistory') IS NOT NULL)
		DROP TABLE #ResourceHistory
		
	IF(OBJECT_ID(N'tempdb..#ResourceStartServiceIds') IS NOT NULL)
		DROP TABLE #ResourceStartServiceIds
		
	IF(OBJECT_ID(N'tempdb..#ResourceEndServiceIds') IS NOT NULL)
		DROP TABLE #ResourceEndServiceIds
		
	IF(OBJECT_ID(N'tempdb..#ResourceStateHistory') IS NOT NULL)
		DROP TABLE #ResourceStateHistory

	-- Declare Tables
	CREATE TABLE #UserRoles (RoleId BIGINT, RoleName NVARCHAR(512));
	CREATE TABLE #ResourceHistory (ServiceHistoryId BIGINT, OperationHistorySeq BIGINT, ModifiedOn DATETIME, MainStateModelId BIGINT, MainStateModelStateId BIGINT, MainStateModelStateReason NVARCHAR(512), RowNumber INT, Id INT);
	CREATE TABLE #ResourceStartServiceIds (ServiceHistoryId BIGINT, OperationHistorySeq BIGINT, ModifiedOn DATETIME, MainStateModelId BIGINT, MainStateModelStateId BIGINT, MainStateModelStateReason NVARCHAR(512), RowNumber INT, ID INT);
	CREATE TABLE #ResourceEndServiceIds (ServiceHistoryId BIGINT, OperationHistorySeq BIGINT, ModifiedOn DATETIME, MainStateModelId BIGINT, MainStateModelStateId BIGINT, MainStateModelStateReason NVARCHAR(512), RowNumber INT, ID INT);
	CREATE TABLE #ResourceStateHistory (StartServiceHistoryId BIGINT, StartOperationHistorySeq BIGINT, EndServiceHistoryId BIGINT, EndOperationHistorySeq BIGINT, StartModifiedOn DATETIME, EndModifiedOn DATETIME, MainStateModelId BIGINT, MainStateModelName NVARCHAR(512), MainStateModelStateId BIGINT, MainStateModelStateName NVARCHAR(512), MainStateModelStateReason NVARCHAR(512), ColorCode NVARCHAR(512));

	-- Get User Hierarchy of roles
	WITH UserRoles
	AS
	(
		SELECT R.RoleId, R.Name
		FROM Security.T_Role_User AS UR
		INNER JOIN Security.T_Role AS R
			ON R.RoleId = UR.RoleId
		WHERE UR.UserId = @UserId
	),
	ParentRoles(RoleId, Name, ChildRoleId) 
	AS 
	( 
		SELECT 
			R.RoleId, 
			R.Name, 
			UR.RoleId
		FROM UserRoles AS UR
		INNER JOIN Security.T_Role_Role RR 
			ON RR.ChildRoleId = UR.RoleId
		INNER JOIN Security.T_Role AS R 
			ON R.RoleId = RR.ParentRoleId
		UNION ALL
		SELECT 
			R.RoleId, 
			R.Name, 
			DR.RoleId
		FROM Security.T_Role R
		INNER JOIN Security.T_Role_Role RR 
			ON RR.ParentRoleId = R.RoleId 
		INNER JOIN ParentRoles DR 
			ON DR.RoleId = RR.ChildRoleId
	)
	INSERT INTO #UserRoles
	SELECT 
		RoleId, 
		Name
	FROM ParentRoles 
	UNION 
	SELECT 
		RoleId, 
		Name
	FROM UserRoles;

	-- Get the time frame
	SET @TimeFrame =
	(
		SELECT MAX(AR.Timeframe)
		FROM #UserRoles AS UR
		INNER JOIN UserDataModel.T_GT_CustomResourceStateReclassificationAllowedRoles AS AR
		ON UR.RoleName = AR.Role
	);

	SET @DateStart = DATEADD(HOUR, -(@TimeFrame), @DateEnd);

	DECLARE @Query NVARCHAR(MAX) = '
	WITH CTEResourceHistory AS
	(
	';

	-- Get Minimum and Maximum service history Id
	DECLARE @min BIGINT = (SELECT [dbo].[F_Part_GetMinServiceHistoryIdForDate] (@DateStart));
	DECLARE @max BIGINT = (SELECT [dbo].[F_Part_GetMaxServiceHistoryIdForDate] (@DateEnd));

	-- Allow the use of this functionality when the ODS link is not present
	IF EXISTS (SELECT * FROM sys.servers WHERE [NAME] = @ODSLink)
	BEGIN
		
		-- Get all the resource history in the given time frame in ODS System
		SET @Query = @Query + '
		SELECT 
			ServiceHistoryId,
			OperationHistorySeq,
			RH.ModifiedOn,
			RH.MainStateModelId,
			RH.MainStateModelStateId,
			RH.MainStateModelStateReason
		FROM ' + @ODSLink + '.' + @ODSDataBase + '.CoreDataModel.T_ResourceHistory AS RH
		WHERE RH.ResourceId = @ResourceId
			AND RH.ServiceHistoryId >= @min
			AND RH.ServiceHistoryId <= @max
			AND RH.ModifiedOn >= @DateStart
		UNION ';

	END;
	
	-- Get all the resource history in the given time frame in ODS System
	SET @Query = @Query + '
		SELECT 
			ServiceHistoryId,
			OperationHistorySeq,
			RH.ModifiedOn,
			RH.MainStateModelId,
			RH.MainStateModelStateId,
			RH.MainStateModelStateReason
		FROM CoreDataModel.T_ResourceHistory AS RH
		WHERE RH.ResourceId = @ResourceId
			AND RH.ServiceHistoryId >= @min
			AND RH.ServiceHistoryId <= @max
			AND RH.ModifiedOn >= @DateStart
	), 
	CTEResourceHistoryPreviousStates AS
	(
		SELECT *
			, Row_number() OVER (ORDER BY ModifiedOn) AS [RowNumber]
			, ISNULL(LAG(MainStateModelId, 1, -1) OVER (ORDER BY ServiceHistoryId, ModifiedOn, OperationHistorySeq), -1) PrevMainStateModelId
			, ISNULL(LAG(MainStateModelStateId, 1, -1) OVER (ORDER BY ServiceHistoryId, ModifiedOn, OperationHistorySeq), -1) PrevMainStateModelStateId
			, ISNULL(LAG(MainStateModelStateReason) OVER (ORDER BY ServiceHistoryId, ModifiedOn, OperationHistorySeq), N'''') PrevMainStateModelStateReason
		FROM CTEResourceHistory
	), 
	CTEResourceHistoryStateChanged AS
	(
		SELECT *
			, CASE WHEN (MainStateModelId <> PrevMainStateModelId OR MainStateModelStateId <> PrevMainStateModelStateId OR MainStateModelStateReason <> PrevMainStateModelStateReason)
				THEN [RowNumber] ELSE NULL
				END IsStateChanged
		FROM CTEResourceHistoryPreviousStates
	), 
	CTEResourceHistoryStateChangedWithGrouper AS
	(
		SELECT *
			, CASE WHEN [IsStateChanged] IS NOT NULL THEN [IsStateChanged]
				ELSE MAX([IsStateChanged]) OVER (ORDER BY [RowNumber] ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING)
				END [StateGrouper]
		FROM CTEResourceHistoryStateChanged
	)
	SELECT
		ServiceHistoryId, 
		OperationHistorySeq, 
		ModifiedOn, 
		MainStateModelId,
		MainStateModelStateId, 
		MainStateModelStateReason, 
		RowNumber, 
		[StateGrouper] AS Id
	FROM CTEResourceHistoryStateChangedWithGrouper';

	INSERT INTO #ResourceHistory
	EXECUTE sp_executesql @Query, N'@min BIGINT, @max BIGINT, @DateStart DATETIME, @ResourceId BIGINT', @min = @min, @max = @max, @DateStart = @DateStart, @ResourceId = @ResourceId;
	
	;WITH CTE_ResourceHistory
	AS
	(
		SELECT *,
			DENSE_RANK() OVER (PARTITION BY Id ORDER BY ModifiedOn ASC) AS [Rank]
		FROM #ResourceHistory AS R1
	)
	-- Get the last service Id before state changes
	INSERT INTO #ResourceStartServiceIds
	SELECT 
		r1.ServiceHistoryId,
		r1.OperationHistorySeq,
		r1.ModifiedOn,
		r1.MainStateModelId,
		r1.MainStateModelStateId,
		r1.MainStateModelStateReason, 
		r1.RowNumber,
		Row_number() OVER (ORDER BY r1.ModifiedOn) AS Id
	FROM CTE_ResourceHistory AS R1
	WHERE [Rank] = 1
	ORDER BY r1.ModifiedOn ASC;
	
	-- Get the first service history Id of the state
	INSERT INTO #ResourceEndServiceIds
	SELECT 
		r.ServiceHistoryId,
		r.OperationHistorySeq,
		r.ModifiedOn,
		r.MainStateModelId,
		r.MainStateModelStateId,
		r.MainStateModelStateReason, 
		sr.RowNumber,
		sr.Id - 1 AS Id
	FROM #ResourceHistory as r
	INNER JOIN #ResourceStartServiceIds as sr
		ON r.RowNumber = sr.RowNumber;
		 
	-- Get the Resource State History
	INSERT INTO #ResourceStateHistory
	SELECT
		R.ServiceHistoryId AS StartServiceHistoryId,
		R.OperationHistorySeq AS StartOperationHistorySeq,
		SR.ServiceHistoryId AS EndServiceHistoryId,
		SR.OperationHistorySeq AS EndOperationHistorySeq,
		R.ModifiedOn AS StartModifiedOn,
		SR.ModifiedOn AS EndModifiedOn,
		SM.StateModelId AS MainStateModelId,
		SM.Name AS MainStateModelName,
		SMS.StateModelStateId AS MainStateModelStateId,
		SMS.Name AS MainStateModelStateName,
		ISNULL(RSR.StateModelStateReason, R.MainStateModelStateReason) AS MainStateModelStateReason,
		ISNULL(RSCM.Color, '') as ColorCode
	FROM #ResourceStartServiceIds AS R
	LEFT JOIN #ResourceEndServiceIds AS SR
		ON R.Id = SR.Id
	LEFT JOIN UserDataModel.T_CustomResourceStateReclassification AS RSR
		ON RSR.ResourceId = @ResourceId
		AND RSR.ServiceHistoryIdStart = R.ServiceHistoryId
		AND RSR.OperationHistorySequenceStart = R.OperationHistorySeq
		AND RSR.ServiceHistoryIdEnd = SR.ServiceHistoryId
		AND RSR.OperationHistorySequenceEnd = SR.OperationHistorySeq
	INNER JOIN dbo.T_StateModel AS SM
		ON SM.StateModelId = ISNULL(RSR.StateModelId, R.MainStateModelId)
	INNER JOIN dbo.T_StateModelState AS SMS
		ON SMS.StateModelStateId = ISNULL(RSR.StateModelStateId, R.MainStateModelStateId)
	LEFT JOIN UserDataModel.T_GT_CustomResourceStateColorMapping AS RSCM
		ON UPPER(SMS.Name) LIKE UPPER(RSCM.ResourceState)
	ORDER BY R.ModifiedOn, SR.RowNumber;

	-- Get the Resource State History with User Permissions
	-- the mos recent state of the resource cannot be changed
	SELECT RSH.*,
	CASE WHEN RSH.EndServiceHistoryId IS NULL THEN 0
	ELSE
		(
			SELECT COUNT(1)
			FROM #UserRoles AS UR
			CROSS APPLY
			(
				SELECT *
				FROM [UserDataModel].[F_ST_ResolveCustomResourceStateReclassificationPermissions] (1, UR.RoleName, RSH.MainStateModelName, RSH.MainStateModelStateName, RSH.MainStateModelStateReason)
			) AS RolePermissions
		) 
	END AS AllowChange
	FROM #ResourceStateHistory AS RSH
	ORDER BY RSH.StartModifiedOn, RSH.EndModifiedOn;

END
