/****** Object:  StoredProcedure [Custom].[P_GetResourceStateHistory]    Script Date: 03-Jun-19 14:45:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = 'Custom')
BEGIN
EXEC('CREATE SCHEMA Custom')
END
GO

IF EXISTS ( SELECT * 
            FROM   sysobjects 
            WHERE  id = object_id(N'[Custom].[P_GetResourceStateHistoryForStopReclassification]') 
                   and OBJECTPROPERTY(id, N'IsProcedure') = 1 )
BEGIN
    DROP PROCEDURE [Custom].[P_GetResourceStateHistoryForStopReclassification]
END
GO

/**Create table type so that data can be filtered by attributes*/
IF TYPE_ID('[Custom].[GetResourceStateHistoryForStopReclassificationStateModelStateAttributeFiltersType]') IS NOT NULL
	DROP TYPE [Custom].[GetResourceStateHistoryForStopReclassificationStateModelStateAttributeFiltersType]

CREATE TYPE [Custom].[GetResourceStateHistoryForStopReclassificationStateModelStateAttributeFiltersType]
	AS TABLE
		( StateModelStateAttributeName NVARCHAR(256),
		  StateModelStateAttributeValue NVARCHAR(512));
GO

--The MicrostopFilter parameter can take 4 values:
-- 0 -> Display all stops, including those that have no threshold defined
-- 1 -> Display all stops, including those that have no threshold defined but excluding microstops
-- 2 -> Display only microstops
-- 3 -> Display only stops that have a duration longer than the defined threshold
CREATE PROCEDURE [Custom].[P_GetResourceStateHistoryForStopReclassification]
	@FromDate DATETIME,
	@ToDate DATETIME,
	@ResourceId BIGINT,
	@MicrostopFilter INT,
	@StateModelStateAttributeFilters [Custom].[GetResourceStateHistoryForStopReclassificationStateModelStateAttributeFiltersType] READONLY
AS
BEGIN
			
	-- Declare Variables
	DECLARE
		@SystemName NVARCHAR(512) = dbo.F_GetSystemName();

	DECLARE 
		@ODSLink NVARCHAR(512) = 'cm' + @SystemName + 'ODSLink',
		@ODSDataBase NVARCHAR(512) = @SystemName + 'ODS';

	IF(OBJECT_ID(N'tempdb..#ResourceHistory') IS NOT NULL)
		DROP TABLE #ResourceHistory
		
	IF(OBJECT_ID(N'tempdb..#ResourceStartServiceIds') IS NOT NULL)
		DROP TABLE #ResourceStartServiceIds
		
	IF(OBJECT_ID(N'tempdb..#ResourceEndServiceIds') IS NOT NULL)
		DROP TABLE #ResourceEndServiceIds
		
	IF(OBJECT_ID(N'tempdb..#ResourceStateHistory') IS NOT NULL)
		DROP TABLE #ResourceStateHistory

	IF(OBJECT_ID(N'tempdb..#ODSResourceStateHistory') IS NOT NULL)
		DROP TABLE #ODSResourceStateHistory

	IF(OBJECT_ID(N'tempdb..#ODSMaterialResourceHistory') IS NOT NULL)
		DROP TABLE #ODSMaterialResourceHistory

	IF(OBJECT_ID(N'tempdb..#ResourceStopStateHistory') IS NOT NULL)
		DROP TABLE #ResourceStopStateHistory

	-- Declare Tables
	CREATE TABLE #ResourceHistory (
		ResourceId BIGINT, 
		ServiceHistoryId BIGINT, 
		OperationHistorySeq BIGINT,
		ModifiedOn DATETIME, 
		MainStateModelId BIGINT,
		MainStateModelStateId BIGINT, 
		MainStateModelStateReason NVARCHAR(512),
		RowNumber INT, 
		Id INT
	);
	CREATE TABLE #ResourceStartServiceIds (
		ResourceId BIGINT, 
		ServiceHistoryId BIGINT, 
		OperationHistorySeq BIGINT, 
		ModifiedOn DATETIME, 
		MainStateModelId BIGINT, 
		MainStateModelStateId BIGINT, 
		MainStateModelStateReason NVARCHAR(512), 
		RowNumber INT, 
		ID INT
	);
	CREATE TABLE #ResourceEndServiceIds (
		ResourceId BIGINT, 
		ServiceHistoryId BIGINT, 
		OperationHistorySeq BIGINT, 
		ModifiedOn DATETIME, 
		MainStateModelId BIGINT, 
		MainStateModelStateId BIGINT, 
		MainStateModelStateReason NVARCHAR(512), 
		RowNumber INT,
		ID INT
	);
	CREATE TABLE #ODSResourceStateHistory (
		ResourceId BIGINT,
		ServiceHistoryId BIGINT, 
		OperationHistorySeq BIGINT, 
		ModifiedOn DATETIME, 
		MainStateModelId BIGINT,
		MainStateModelStateId BIGINT,
		MainStateModelStateReason NVARCHAR(512)
	);
	CREATE TABLE #ODSMaterialResourceHistory (
		ResourceId BIGINT, 
		MaterialId BIGINT, 
		[Order] DECIMAL, 
		ModifiedOn DATETIME
	);
	CREATE TABLE #ResourceStopStateHistory (
		ResourceId BIGINT, 
		StartServiceHistoryId BIGINT, 
		StartOperationHistorySeq BIGINT, 
		EndServiceHistoryId BIGINT, 
		EndOperationHistorySeq BIGINT, 
		StartModifiedOn DATETIME, 
		EndModifiedOn DATETIME, 
		MainStateModelId BIGINT, 
		MainStateModelName NVARCHAR(512), 
		MainStateModelStateId BIGINT, 
		MainStateModelStateName NVARCHAR(512),
		MainStateModelStateReason NVARCHAR(512),
		ProductName NVARCHAR(512),
		ColorCode NVARCHAR(512),
		Threshold INT
	);

	-- Get Minimum and Maximum service history Id
	DECLARE @minServiceHistoryId BIGINT = (SELECT [dbo].[F_Part_GetMinServiceHistoryIdForDate] (@FromDate));
	DECLARE @maxServiceHistoryId BIGINT = (SELECT [dbo].[F_Part_GetMaxServiceHistoryIdForDate] (@ToDate));

	-- Set all the resource history in the given time frame in ODS System if this exists
	IF EXISTS (SELECT * FROM sys.servers WHERE [NAME] = @ODSLink)
	BEGIN
		-- Get the name of the ODS ResourceHistory
		DECLARE @ODSResourceHistoryTableName NVARCHAR(512) = @ODSLink + '.' + @ODSDataBase + '.CoreDataModel.T_ResourceHistory';
		DECLARE @ODSMaterialResourceTableName NVARCHAR(512) = @ODSLink + '.' + @ODSDataBase + '.CoreDataModel.T_MaterialResource';
		DECLARE @ODSResourceHistoryQuery NVARCHAR(MAX);
		DECLARE @ODSMaterialResourceQuery NVARCHAR(MAX);

		SET @ODSResourceHistoryQuery = 
		'INSERT INTO #ODSResourceStateHistory
			SELECT
				RH.ResourceId,
				RH.ServiceHistoryId,
				RH.OperationHistorySeq,
				RH.ModifiedOn,
				RH.MainStateModelId,
				RH.MainStateModelStateId,
				RH.MainStateModelStateReason
			FROM ' + @ODSResourceHistoryTableName + ' AS RH
			WHERE RH.ServiceHistoryId >= @minServiceHistoryId
			AND RH.ServiceHistoryId <= @maxServiceHistoryId
			AND RH.ModifiedOn >= @FromDate
			AND RH.ModifiedOn <= @ToDate';

		SET @ODSMaterialResourceQuery = 
		'INSERT INTO #ODSMaterialResourceHistory
			SELECT 
				MR.TargetEntityId, 
				MR.SourceEntityId,
				MR.[Order],
				MR.ModifiedOn
			FROM ' + @ODSMaterialResourceTableName + ' as MR
			WHERE MR.ModifiedOn >= @FromDate
				AND MR.ModifiedOn <= @ToDate';
		
		IF @ResourceId IS NOT NULL
		BEGIN
			SET @ODSResourceHistoryQuery = @ODSResourceHistoryQuery	+ ' AND RH.ResourceId = @ResourceId';
			SET @ODSMaterialResourceQuery = @ODSMaterialResourceQuery + ' AND MR.TargetEntityId = @ResourceId';
		END

		EXECUTE sp_executesql @ODSResourceHistoryQuery, N'@minServiceHistoryId BIGINT, @maxServiceHistoryId BIGINT, @FromDate DATETIME, @ToDate DATETIME, @ResourceId BIGINT',
			@minServiceHistoryId = @minServiceHistoryId,
			@maxServiceHistoryId = @maxServiceHistoryId,
			@FromDate = @FromDate,
			@ToDate = @ToDate,
			@ResourceId = @ResourceId;

		EXECUTE sp_executesql @ODSMaterialResourceQuery, N'@FromDate DATETIME, @ToDate DATETIME, @ResourceId BIGINT',
			@FromDate = @FromDate,
			@ToDate = @ToDate,
			@ResourceId = @ResourceId;

	END;

	DECLARE @ResourceHistoryQuery NVARCHAR(MAX);

	SET @ResourceHistoryQuery = 
	'WITH CTEResourceHistory
	AS (
		SELECT 
			ResourceId,
			ServiceHistoryId,
			OperationHistorySeq,
			ModifiedOn,
			MainStateModelId,
			MainStateModelStateId,
			MainStateModelStateReason
		FROM #ODSResourceStateHistory
		UNION ALL
		SELECT
			RH.ResourceId,
			RH.ServiceHistoryId,
			RH.OperationHistorySeq,
			RH.ModifiedOn,
			RH.MainStateModelId,
			RH.MainStateModelStateId,
			RH.MainStateModelStateReason
		FROM CoreDataModel.T_ResourceHistory AS RH
		WHERE RH.ServiceHistoryId >= @minServiceHistoryId
			AND RH.ServiceHistoryId <= @maxServiceHistoryId
			AND RH.ModifiedOn >= @FromDate
			AND RH.ModifiedOn <= @ToDate'

	IF @ResourceId IS NOT NULL
		SET @ResourceHistoryQuery = @ResourceHistoryQuery + 
		'
		AND RH.ResourceId = @ResourceId'

	SET @ResourceHistoryQuery = @ResourceHistoryQuery + 
	'),
	CTEResourceHistoryPreviousStates AS
	(
		SELECT *
			, DENSE_RANK() OVER (PARTITION BY ResourceId ORDER BY ResourceId, ServiceHistoryId, ModifiedOn, OperationHistorySeq DESC) AS [RowNumber]
			, ISNULL(LAG(MainStateModelId, 1, -1) OVER (PARTITION BY ResourceId ORDER BY ResourceId, ServiceHistoryId, ModifiedOn, OperationHistorySeq DESC), -1) PrevMainStateModelId
			, ISNULL(LAG(MainStateModelStateId, 1, -1) OVER (PARTITION BY ResourceId ORDER BY ResourceId, ServiceHistoryId, ModifiedOn, OperationHistorySeq DESC), -1) PrevMainStateModelStateId
			, ISNULL(LAG(MainStateModelStateReason) OVER (PARTITION BY ResourceId ORDER BY ResourceId, ServiceHistoryId, ModifiedOn, OperationHistorySeq DESC), N'''') PrevMainStateModelStateReason
		FROM CTEResourceHistory
	), 
	CTEResourceHistoryStateChanged AS
	(
		SELECT *
			, CASE WHEN (MainStateModelId <> PrevMainStateModelId OR MainStateModelStateId <> PrevMainStateModelStateId OR MainStateModelStateReason <> PrevMainStateModelStateReason)
				THEN [RowNumber] ELSE NULL
				END IsStateChanged
		FROM CTEResourceHistoryPreviousStates
	), 
	CTEResourceHistoryStateChangedWithGrouper AS
	(
		SELECT *
			, CASE WHEN [IsStateChanged] IS NOT NULL THEN [IsStateChanged]
				ELSE MAX([IsStateChanged]) OVER (PARTITION BY ResourceId ORDER BY ResourceId, [RowNumber] ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING)
				END [StateGrouper]
		FROM CTEResourceHistoryStateChanged
	)

	INSERT INTO #ResourceHistory
	SELECT
		ResourceId,
		ServiceHistoryId, 
		OperationHistorySeq, 
		ModifiedOn, 
		MainStateModelId,
		MainStateModelStateId, 
		MainStateModelStateReason, 
		RowNumber, 
		StateGrouper AS Id
	FROM CTEResourceHistoryStateChangedWithGrouper';

		
	EXECUTE sp_executesql @ResourceHistoryQuery, N'@minServiceHistoryId BIGINT, @maxServiceHistoryId BIGINT, @FromDate DATETIME, @ToDate DATETIME, @ResourceId BIGINT', 
	@minServiceHistoryId = @minServiceHistoryId, @maxServiceHistoryId = @maxServiceHistoryId, 
	@FromDate = @FromDate, @ToDate = @ToDate, @ResourceId = @ResourceId

	;WITH CTE_ResourceHistory
	AS
	(
		SELECT *,
			DENSE_RANK() OVER (PARTITION BY ResourceId, Id ORDER BY ModifiedOn ASC) AS [Rank]
		FROM #ResourceHistory AS R1
	)

	-- Get the last service Id before state changes
	INSERT INTO #ResourceStartServiceIds
	SELECT
		r1.ResourceId,
		r1.ServiceHistoryId,
		r1.OperationHistorySeq,
		r1.ModifiedOn,
		r1.MainStateModelId,
		r1.MainStateModelStateId,
		r1.MainStateModelStateReason, 
		r1.RowNumber,
		Row_number() OVER (PARTITION BY r1.ResourceId ORDER BY r1.ModifiedOn) AS Id
	FROM CTE_ResourceHistory AS R1
	WHERE [Rank] = 1
	ORDER BY r1.ModifiedOn ASC;
	
	-- Get the first service history Id of the state
	INSERT INTO #ResourceEndServiceIds
	SELECT
		r.ResourceId,
		r.ServiceHistoryId,
		r.OperationHistorySeq,
		r.ModifiedOn,
		r.MainStateModelId,
		r.MainStateModelStateId,
		r.MainStateModelStateReason, 
		sr.RowNumber,
		sr.Id - 1 AS Id
	FROM #ResourceHistory as r
	INNER JOIN #ResourceStartServiceIds as sr
		ON r.RowNumber = sr.RowNumber
		AND r.ResourceId = sr.ResourceId;


	DECLARE @ResourceStopStateHistoryQuery NVARCHAR(MAX);

	SET @ResourceStopStateHistoryQuery = '
	WITH CTEReclassifications AS (
		SELECT
			DISTINCT
			REC.ResourceId,
			REC.ServiceHistoryIdStart,
			REC.OperationHistorySequenceStart,
			REC.ServiceHistoryIdEnd,
			REC.OperationHistorySequenceEnd,
			REC.StateModelId AS MainStateModelId,
			SM.Name AS MainStateModel,
			REC.StateModelStateId AS MainStateModelStateId,
			SMS.Name AS MainStateModelState,
			REC.StateModelStateReason AS MainStateModelStateReason
		FROM #ResourceHistory RH
		INNER JOIN UserDataModel.T_CustomResourceStateReclassification AS REC
			ON RH.ResourceId = REC.ResourceId
		INNER JOIN dbo.T_StateModelState AS SMS
			ON REC.StateModelStateId = SMS.StateModelStateId
		INNER JOIN dbo.T_StateModel AS SM
			ON SMS.StateModelId = SM.StateModelId
	)

	-- Get the Resource Stop State History
	INSERT INTO #ResourceStopStateHistory
	SELECT 
		R.ResourceId AS ResourceId,
		SS.ServiceHistoryId AS StartServiceHistoryId,
		SS.OperationHistorySeq AS StartOperationHistorySeq,
		ES.ServiceHistoryId AS EndServiceHistoryId,
		ES.OperationHistorySeq AS EndOperationHistorySeq,
		SS.ModifiedOn AS StartModifiedOn,
		ES.ModifiedOn AS EndModifiedOn,
		SM.StateModelId AS MainStateModelId,
		SM.Name AS MainStateModelName,
		SMS.StateModelStateId AS MainStateModelStateId,
		SMS.Name AS MainStateModelStateName,
		ISNULL(REC.MainStateModelStateReason, SS.MainStateModelStateReason) AS MainStateModelStateReason,
		ISNULL (RP.ProductName, '''') AS ProductName,
		ISNULL(RSCM.Color, '''') AS ColorCode,
		ISNULL(MST.Threshold, -1) AS Threshold
	FROM #ResourceStartServiceIds AS SS
	INNER JOIN #ResourceEndServiceIds AS ES 
		ON ES.ResourceId = SS.ResourceId AND SS.ID = ES.ID
	LEFT JOIN CTEReclassifications AS REC
		ON REC.ResourceID = SS.ResourceId
		AND REC.ServiceHistoryIdStart = SS.ServiceHistoryId
		AND REC.OperationHistorySequenceStart = SS.OperationHistorySeq
		AND REC.ServiceHistoryIdEnd = ES.ServiceHistoryId
		AND REC.OperationHistorySequenceEnd = ES.OperationHistorySeq
	INNER JOIN dbo.T_StateModel AS SM
		ON SM.StateModelId = ISNULL(REC.MainStateModelId, SS.MainStateModelId)
	INNER JOIN dbo.T_StateModelState AS SMS
		ON SMS.StateModelStateId = ISNULL(REC.MainStateModelStateId, SS.MainStateModelStateId)
	INNER JOIN UserDataModel.T_GT_CustomResourceStopStates RSS
		ON UPPER(RSS.StateModel) LIKE ISNULL(UPPER(REC.MainStateModel), UPPER(SM.Name))
		AND UPPER(RSS.StateModelState) LIKE ISNULL(UPPER(REC.MainStateModelState), UPPER(SMS.Name))
		AND UPPER(RSS.Reason) LIKE ISNULL(UPPER(REC.MainStateModelStateReason), UPPER(SS.MainStateModelStateReason))
		AND RSS.IsReclassifiable = 1 --only reclassifiable stops
	';

	IF EXISTS (SELECT * FROM @StateModelStateAttributeFilters)
		BEGIN

		SET @ResourceStopStateHistoryQuery = @ResourceStopStateHistoryQuery +
		'
		LEFT JOIN dbo.T_StateModelStateAttribute SMSA
			ON SMS.StateModelStateId = SMSA.StateModelStateId
		INNER JOIN @StateModelStateAttributeFilters AS AF
			ON UPPER(SMSA.Name) LIKE UPPER(AF.StateModelStateAttributeName)
			AND UPPER(SMSA.Value) LIKE UPPER(AF.StateModelStateAttributeValue)';
		END
	END


	SET @ResourceStopStateHistoryQuery = @ResourceStopStateHistoryQuery +
	'
	INNER JOIN CoreDataModel.T_Resource AS R
		ON R.ResourceId = SS.ResourceId
	INNER JOIN CoreDataModel.T_Area AS A
		ON A.AreaId = R.AreaId
	INNER JOIN CoreDataModel.T_Facility AS F
		ON F.FacilityId = A.FacilityId
	LEFT JOIN UserDataModel.T_GT_CustomResourceStateColorMapping AS RSCM
		ON UPPER(SMS.Name) LIKE UPPER(RSCM.ResourceState)
	OUTER APPLY (
		SELECT TOP 1 P.Name AS ProductName
		FROM (
			SELECT MR.TargetEntityId AS ResourceId, MR.SourceEntityId AS MaterialId, MR.[Order]
			FROM CoreDataModel.T_MaterialResource as MR
			WHERE MR.TargetEntityId = R.ResourceId
			UNION ALL
			SELECT ODSMR.ResourceId, ODSMR.MaterialId, ODSMR.[Order]
			FROM #ODSMaterialResourceHistory as ODSMR
			WHERE ODSMR.ResourceId = R.ResourceId
		) as MR
		INNER JOIN CoreDataModel.T_Material as M
			ON M.MaterialId = MR.MaterialId
		INNER JOIN T_StateModelState as SMS 
			ON M.MainStateModelStateId = SMS.StateModelStateId 
			AND SMS.Name NOT IN (''ABORTED'', ''COMPLETED'')
		INNER JOIN CoreDataModel.T_Product as P 
			ON M.ProductId = P.ProductId
		ORDER BY MR.[Order]
	) RP';


	IF @MicrostopFilter = 0 OR @MicrostopFilter = 1
		BEGIN

		SET @ResourceStopStateHistoryQuery = @ResourceStopStateHistoryQuery +
		'
		OUTER APPLY (SELECT Threshold FROM UserDataModel.F_ST_ResolveCustomMicrostopThreshold (1, F.Name, A.Name, R.Type, R.Name)) AS MST'
				
		--exclude microstops
		IF @MicrostopFilter = 1
			BEGIN

			SET @ResourceStopStateHistoryQuery = @ResourceStopStateHistoryQuery + 
			'
			WHERE MST.Threshold IS NULL OR DATEDIFF(SECOND, SS.ModifiedOn, ES.ModifiedOn) >= MST.Threshold'

			END
		END
	ELSE
		BEGIN
			IF @MicrostopFilter = 2 OR @MicrostopFilter = 3
				BEGIN

				SET @ResourceStopStateHistoryQuery = @ResourceStopStateHistoryQuery +
				'
				CROSS APPLY (SELECT Threshold FROM UserDataModel.F_ST_ResolveCustomMicrostopThreshold (1, F.Name, A.Name, R.Type, R.Name)) AS MST'

				--get microstops only
				IF @MicrostopFilter = 2
					SET @ResourceStopStateHistoryQuery = @ResourceStopStateHistoryQuery +
					'
					WHERE DATEDIFF(SECOND, SS.ModifiedOn, ES.ModifiedOn) < MST.Threshold'

				--get stops longer than threshold
				IF @MicrostopFilter = 3
					SET @ResourceStopStateHistoryQuery = @ResourceStopStateHistoryQuery +
						'
						WHERE DATEDIFF(SECOND, SS.ModifiedOn, ES.ModifiedOn) >= MST.Threshold'

				END
		END

	SET @ResourceStopStateHistoryQuery = @ResourceStopStateHistoryQuery +
	'
	ORDER BY SS.ModifiedOn, ES.RowNumber';

	EXECUTE sp_executesql @ResourceStopStateHistoryQuery, N'@StateModelStateAttributeFilters [Custom].[GetResourceStateHistoryForStopReclassificationStateModelStateAttributeFiltersType] READONLY', 
	@StateModelStateAttributeFilters = @StateModelStateAttributeFilters
	
	SELECT 
		RSSH.*, 
		ATT.[MainStateModelStateAttributes]
	--	,
	--	CASE WHEN RSSH.EndServiceHistoryId IS NULL THEN ''
	--	ELSE
	--	(
	--		SELECT STUFF((
	--			SELECT ';' + R.[Name]
	--		FROM Security.T_Role R
	--		CROSS APPLY(
	--			SELECT *
	--			FROM [UserDataModel].[F_ST_ResolveCustomResourceStateReclassificationPermissions] (1, R.[Name], RSSH.MainStateModelName, RSSH.MainStateModelStateName, RSSH.MainStateModelStateReason)
	--		) AS RolePermissions
	--			FOR XML PATH('')
	--		), 1, 1, '')
	--	) 
	--END AS AllowedRoles
	FROM #ResourceStopStateHistory RSSH
	CROSS APPLY (
		SELECT
		STUFF(
		(
		SELECT SMSA.[Name], SMSA.[Value]
		FROM dbo.T_StateModelStateAttribute SMSA
		WHERE SMSA.StateModelStateId = RSSH.MainStateModelStateId
		FOR JSON AUTO
	), 1, 0, '') [MainStateModelStateAttributes]) AS ATT

