DECLARE @UniversalState			INTEGER			 = 0 /*CREATED*/
DECLARE @OldServiceHistoryId	BIGINT			 = (SELECT [LastServiceHistoryId] FROM [dbo].[T_SmartTable] ST WHERE ST.[Name] = N'CustomAlarmTrackingConfiguration')
DECLARE @ModifiedBy				NVARCHAR(64)	 = N'System'
DECLARE @ModifiedOn				DATETIME		 = GETUTCDATE()
DECLARE @ServiceName			NVARCHAR(512)	 = (N'Make [Custom].[T_ST_CustomAlarmTrackingConfiguration] AlarmCode and Category columns keys')
DECLARE @BatchId				UNIQUEIDENTIFIER = NULL
DECLARE @ServiceHistoryId		BIGINT			 = 0
DECLARE @OperationHistorySeq	BIGINT			 = 0
DECLARE @TransactionCommited	BIT				 = 0

IF(EXISTS(
	SELECT *
	FROM [dbo].[T_SmartTable] ST
	INNER JOIN [dbo].[T_SmartTableProperty] STP ON STP.[SmartTableId] = ST.[SmartTableId]
	WHERE ST.[Name] = N'CustomAlarmTrackingConfiguration'
	AND STP.[Name] IN (N'AlarmCode', N'Category')
	AND STP.[IsKey] = 0
))
BEGIN TRY
	
	BEGIN TRANSACTION
	
	-- OPEN SERVICE HISTORY
	EXEC dbo.P_CreateServiceHistoryId -1, @ServiceName, @ModifiedBy, @ModifiedBy, @ServiceHistoryId OUT, @ModifiedBy, @ModifiedOn, NULL, NULL

	-- UPDATE ENTITY TYPE
	SET @OperationHistorySeq = @OperationHistorySeq + 1

	UPDATE STP SET STP.[IsKey] = 1
		, STP.[LastServiceHistoryId] = @ServiceHistoryId
		, STP.[LastOperationHistorySeq] = @OperationHistorySeq
		, STP.[ModifiedOn] = @ModifiedOn
		, STP.[ModifiedBy] = @ModifiedBy
		, STP.[UniversalState] = @UniversalState
	FROM [dbo].[T_SmartTable] ST
	INNER JOIN [dbo].[T_SmartTableProperty] STP ON STP.[SmartTableId] = ST.[SmartTableId]
	WHERE ST.[Name] = N'CustomAlarmTrackingConfiguration'
	AND STP.[Name] IN (N'AlarmCode', N'Category')
	AND STP.[IsKey] = 0

	-- CLOSE SERVICE HISTORY ID
	UPDATE [dbo].[T_ServiceHistory] SET [ServiceEndTime] = @ModifiedOn WHERE ServiceHistoryId = @ServiceHistoryId

	-- COMMIT TRANSACTION
	COMMIT TRANSACTION
	SET @TransactionCommited = 1

	PRINT 'Transaction Commited'
	BEGIN TRANSACTION
	SET @TransactionCommited = 0

	-- OPEN SERVICE HISTORY
	EXEC dbo.P_CreateServiceHistoryId -1, @ServiceName, @ModifiedBy, @ModifiedBy, @ServiceHistoryId OUT, @ModifiedBy, @ModifiedOn, NULL, NULL

	-- REGENERATE TABLE (MAKE CHANGES EFFECTIVE)
	SET @OperationHistorySeq = 1
	EXEC [dbo].[P_GenerateSmartTable] N'CustomAlarmTrackingConfiguration', @BatchId OUTPUT, @PrintScriptOnly = 0, @WithTriggers = 1, @UseCommandQueue = 0, @LastServiceHistoryId = @OldServiceHistoryId, @NewServiceHistoryId = @ServiceHistoryId, @NewOperationSequence = @OperationHistorySeq /* OperationHistorySeq */, @ModifiedOn = @ModifiedOn, @ModifiedBy = @ModifiedBy

	-- CLOSE SERVICE HISTORY ID
	UPDATE [dbo].[T_ServiceHistory] SET [ServiceEndTime] = @ModifiedOn WHERE ServiceHistoryId = @ServiceHistoryId

	COMMIT TRANSACTION
	SET @TransactionCommited = 1
	
END TRY
BEGIN CATCH
	
	IF(@TransactionCommited = 0)
		ROLLBACK

	DECLARE @ErrorMessage NVARCHAR(MAX)
	SET @ErrorMessage = ERROR_MESSAGE()
	PRINT @ErrorMessage
	
END CATCH