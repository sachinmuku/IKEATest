DECLARE @UniversalState			INTEGER				= 0 /*CREATED*/
DECLARE @OldServiceHistoryId	BIGINT				= (SELECT [LastServiceHistoryId] FROM [dbo].[T_GenericTable] ET WHERE ET.[Name] = N'T_GT_CustomManualDataPostingNotifications')
DECLARE @ModifiedBy				NVARCHAR(64)		= N'System'
DECLARE @ModifiedOn				DATETIME			= GETUTCDATE()
DECLARE @ServiceName			NVARCHAR(512)		= (N'Make T_GT_CustomManualDataPostingNotifications] [ConfigurationUID] Key column not mandatory')
DECLARE @BatchId				UNIQUEIDENTIFIER	= NULL
DECLARE @ServiceHistoryId		BIGINT				= 0
DECLARE @OperationHistorySeq	BIGINT				= 0
DECLARE @TransactionCommited	BIT					= 0

IF(EXISTS(
	SELECT *
	FROM [dbo].[T_GenericTable] GT
	INNER JOIN [dbo].[T_GenericTableProperty] GTP ON GTP.[GenericTableId] = GT.[GenericTableId]
	WHERE GT.[Name] = N'CustomManualDataPostingNotifications'
		AND GTP.[Name] IN (N'ConfigurationUID')
		AND GTP.[IsKey] = 1 AND GTP.[IsMandatory] = 1
))
BEGIN TRY

	BEGIN TRANSACTION

	-- OPEN SERVICE HISTORY
	EXEC dbo.P_CreateServiceHistoryId -1, @ServiceName, @ModifiedBy, @ModifiedBy, @ServiceHistoryId OUT, @ModifiedBy, @ModifiedOn, NULL, NULL

	-- UPDATE ENTITY TYPE
	SET @OperationHistorySeq = @OperationHistorySeq + 1

	UPDATE GTP SET GTP.[IsMandatory] = 0
		, GTP.[LastServiceHistoryId] = @ServiceHistoryId
		, GTP.[LastOperationHistorySeq] = @OperationHistorySeq
		, GTP.[ModifiedOn] = @ModifiedOn
		, GTP.[ModifiedBy] = @ModifiedBy
		, GTP.[UniversalState] = @UniversalState
	FROM [dbo].[T_GenericTable] GT
	INNER JOIN [dbo].[T_GenericTableProperty] GTP ON GTP.[GenericTableId] = GT.[GenericTableId]
	WHERE GT.[Name] = N'CustomManualDataPostingNotifications'
		AND GTP.[Name] IN (N'ConfigurationUID')
		AND GTP.[IsKey] = 1 and GTP.IsMandatory = 1

	-- CLOSE SERVICE HISTORY ID
	UPDATE [dbo].[T_ServiceHistory] SET [ServiceEndTime] = @ModifiedOn WHERE ServiceHistoryId = @ServiceHistoryId

	-- COMMIT TRANSACTION
	COMMIT TRANSACTION
	SET @TransactionCommited = 1

	PRINT 'Transaction Commited'
	BEGIN TRANSACTION
	SET @TransactionCommited = 0

	-- OPEN SERVICE HISTORY
	EXEC dbo.P_CreateServiceHistoryId -1, @ServiceName, @ModifiedBy, @ModifiedBy, @ServiceHistoryId OUT, @ModifiedBy, @ModifiedOn, NULL, NULL

	-- REGENERATE TABLE (MAKE CHANGES EFFECTIVE)
	SET @OperationHistorySeq = 1
	EXEC [dbo].[P_GenerateGenericTable] N'CustomManualDataPostingNotifications', @BatchId OUTPUT, @PrintScriptOnly = 0, @WithTriggers = 1, @UseCommandQueue = 0, @LastServiceHistoryId = @OldServiceHistoryId, @NewServiceHistoryId = @ServiceHistoryId, @NewOperationSequence = @OperationHistorySeq /* OperationHistorySeq */, @ModifiedOn = @ModifiedOn, @ModifiedBy = @ModifiedBy

	-- CLOSE SERVICE HISTORY ID
	UPDATE [dbo].[T_ServiceHistory] SET [ServiceEndTime] = @ModifiedOn WHERE ServiceHistoryId = @ServiceHistoryId

	COMMIT TRANSACTION
	SET @TransactionCommited = 1


END TRY
BEGIN CATCH
	
	IF(@TransactionCommited = 0)
		ROLLBACK

	DECLARE @ErrorMessage NVARCHAR(MAX)
	SET @ErrorMessage = ERROR_MESSAGE()
	PRINT @ErrorMessage

END CATCH
