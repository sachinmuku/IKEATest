/****** Object: Table [Custom].[FactProductSetupTime]   Script Date: 4/22/2020 4:13:08 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF (NOT EXISTS(SELECT * FROM sys.tables ST INNER JOIN sys.schemas SS ON SS.schema_id = ST.schema_id WHERE ST.name = 'FactProductSetupTime' AND SS.name = 'Custom'))
BEGIN
	CREATE TABLE [Custom].[FactProductSetupTime]
	(
		[ProductFromKey] BIGINT NOT NULL,
		[ProductToKey] BIGINT NOT NULL,
		[ResourceKey] BIGINT NOT NULL,
		[FacilityKey] BIGINT NOT NULL,
		[AreaKey] BIGINT NOT NULL,
		[MaterialKey] BIGINT NOT NULL,
		[ShiftKey] BIGINT NOT NULL,
		[DateKey] INT NOT NULL,
		[TimeKey] INT NOT NULL,
		[ServiceHistoryId] BIGINT NOT NULL,
		[LC1DateKey] INT,
		[LC1TimeKey] INT,
		[CalculatedSetupTime] DECIMAL(10,4),
		[ExpectedSetupTime] DECIMAL(10,4)
	) 

	ALTER TABLE [Custom].[FactProductSetupTime] ADD CONSTRAINT [PK_FactProductSetupTime] PRIMARY KEY CLUSTERED
	(
		[ProductFromKey] ASC, 
		[ProductToKey] ASC,
		[ResourceKey] ASC,
		[FacilityKey] ASC,
		[AreaKey] ASC,
		[MaterialKey] ASC,
		[ShiftKey] ASC,
		[TimeKey] ASC,
		[DateKey] ASC,
		[ServiceHistoryId] ASC
	)

	ALTER TABLE [Custom].[FactProductSetupTime]  WITH CHECK ADD CONSTRAINT [FK_FactProductSetupTime_DimProductFrom] FOREIGN KEY([ProductFromKey]) REFERENCES [dbo].[DimProduct] ([ProductKey])
	ALTER TABLE [Custom].[FactProductSetupTime]  WITH CHECK ADD CONSTRAINT [FK_FactProductSetupTime_DimProductTo] FOREIGN KEY([ProductToKey]) REFERENCES [dbo].[DimProduct] ([ProductKey])
	ALTER TABLE [Custom].[FactProductSetupTime]  WITH CHECK ADD CONSTRAINT [FK_FactProductSetupTime_DimResource] FOREIGN KEY([ResourceKey]) REFERENCES [dbo].[DimResource] ([ResourceKey])
	ALTER TABLE [Custom].[FactProductSetupTime]  WITH CHECK ADD CONSTRAINT [FK_FactProductSetupTime_DimFacility] FOREIGN KEY([FacilityKey]) REFERENCES [dbo].[DimFacility] ([FacilityKey])
	ALTER TABLE [Custom].[FactProductSetupTime]  WITH CHECK ADD CONSTRAINT [FK_FactProductSetupTime_DimArea] FOREIGN KEY([AreaKey]) REFERENCES [dbo].[DimArea] ([AreaKey])
	ALTER TABLE [Custom].[FactProductSetupTime]  WITH CHECK ADD CONSTRAINT [FK_FactProductSetupTime_DimMaterial] FOREIGN KEY([MaterialKey]) REFERENCES [dbo].[DimMaterial] ([MaterialKey])
	ALTER TABLE [Custom].[FactProductSetupTime]  WITH CHECK ADD CONSTRAINT [FK_FactProductSetupTime_DimShift] FOREIGN KEY([ShiftKey]) REFERENCES [dbo].[DimShift] ([ShiftKey])
	ALTER TABLE [Custom].[FactProductSetupTime]  WITH CHECK ADD CONSTRAINT [FK_FactProductSetupTime_DimDate] FOREIGN KEY([DateKey]) REFERENCES [dbo].[DimDate] ([DateKey])
	ALTER TABLE [Custom].[FactProductSetupTime]  WITH CHECK ADD CONSTRAINT [FK_FactProductSetupTime_DimTime] FOREIGN KEY([TimeKey]) REFERENCES [dbo].[DimTime] ([TimeKey])	
	ALTER TABLE [Custom].[FactProductSetupTime]  WITH CHECK ADD CONSTRAINT [FK_FactProductSetupTime_LC1DateKey] FOREIGN KEY([LC1DateKey]) REFERENCES [dbo].[DimDate] ([DateKey])
	ALTER TABLE [Custom].[FactProductSetupTime]  WITH CHECK ADD CONSTRAINT [FK_FactProductSetupTime_LC1TimeKey] FOREIGN KEY([LC1TimeKey]) REFERENCES [dbo].[DimTime] ([TimeKey])
		
	CREATE NONCLUSTERED INDEX [IDX_MaterialKey] ON [Custom].[FactProductSetupTime]
	(
		[DateKey] ASC,
		[MaterialKey] ASC
	)

	CREATE NONCLUSTERED INDEX [IDX_ResourceKey] ON [Custom].[FactProductSetupTime]
	(
		[DateKey] ASC,
		[ResourceKey] ASC
	)

	CREATE NONCLUSTERED INDEX [IDX_AreaKey] ON [Custom].[FactProductSetupTime]
	(
		[DateKey] ASC,
		[AreaKey] ASC
	)

	CREATE NONCLUSTERED INDEX [IDX_FacilityKey] ON [Custom].[FactProductSetupTime]
	(
		[DateKey] ASC,
		[FacilityKey] ASC
	)

	CREATE NONCLUSTERED INDEX [IDX_ShiftKey] ON [Custom].[FactProductSetupTime]
	(
		[DateKey] ASC,
		[ShiftKey] ASC
	)

END