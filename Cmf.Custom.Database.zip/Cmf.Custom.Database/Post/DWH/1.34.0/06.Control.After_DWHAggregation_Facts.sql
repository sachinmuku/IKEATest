IF EXISTS (SELECT * FROM SYSOBJECTS WHERE [id] = OBJECT_ID(N'Control.After_DWHAggregation_Facts') AND OBJECTPROPERTY([id], N'IsProcedure') = 1)
BEGIN
    DROP PROCEDURE [Control].[After_DWHAggregation_Facts] 
END
GO

CREATE PROCEDURE [Control].[After_DWHAggregation_Facts]
( 
	@InfServiceHistoryId bigint = NULL, 
	@SupServiceHistoryId bigint = NULL
)
WITH ENCRYPTION
AS
BEGIN

	-- Update FactResourceServiceTime With Reclassifications
	EXEC [Custom].[P_UpdateFactResourceServiceTimeWithReclassifications] @InfServiceHistoryId = @InfServiceHistoryId, @SupServiceHistoryId = @SupServiceHistoryId;
		
	-- Update FactMaterialProcessTime With Reclassifications
	EXEC [Custom].[P_UpdateFactMaterialProcessTimeWithReclassifications] @InfServiceHistoryId = @InfServiceHistoryId, @SupServiceHistoryId = @SupServiceHistoryId;

	-- Update FactProductSetupTime With setup time calculations
	EXEC [Custom].[P_LoadFactProductSetupTime] @InfServiceHistoryId = @InfServiceHistoryId, @SupServiceHistoryId = @SupServiceHistoryId;

END;