SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Olivério Sousa
-- Create date: 4/28/2020
-- Description:	SP to get the setup times of Product A to Product B
-- =============================================

DROP PROCEDURE IF EXISTS [Custom].[P_GetProductSetupTime];  
GO

-- The SetupTimeFilter parameter can take 3 values:
-- 0 -> Display all setup times
-- 1 -> Display only setup times when the products are different
-- 2 -> Display only setup times when the products are the same

CREATE PROCEDURE [Custom].[P_GetProductSetupTime]
	-- Add the parameters for the stored procedure here
	@ProductFromName NVARCHAR(MAX) = NULL,
	@ProductToName NVARCHAR(MAX) = NULL,
	@ResourceName NVARCHAR(MAX) = NULL,
	@FacilityName NVARCHAR(MAX) = NULL,
	@AreaName NVARCHAR(MAX) = NULL,
	@OrderName NVARCHAR(MAX) = NULL,
	@ShiftName NVARCHAR(MAX) = NULL,
	@ShowOnlyOvertime BIT = 0,
	@SetupTimeFilter TINYINT = 0,
	@StartDate DATETIME = NULL,
	@EndDate DATETIME = NULL
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- DECLARE VARIABLES
	DECLARE 
		@Delimiter NVARCHAR(1) = ',',
		@StartDateKey BIGINT = dbo.F_GetDateKeyFromDateTime(@StartDate),
		@EndDateKey BIGINT = dbo.F_GetDateKeyFromDateTime(@EndDate);

	/* Create temporary tables */

	-- Temporary table -> ProductFrom
	IF(OBJECT_ID('tempdb..#ProductFrom') IS NOT NULL) 
		DROP TABLE #ProductFrom;

	CREATE TABLE #ProductFrom
	(
		[Name] NVARCHAR(MAX)
	);

	IF(@ProductFromName IS NOT NULL)
	BEGIN
	  INSERT INTO #ProductFrom
	  SELECT item FROM [Datasets].[fnSplit](@ProductFromName, @Delimiter);
	END

	-- Temporary table -> ProductTo
	IF(OBJECT_ID('tempdb..#ProductTo') IS NOT NULL) 
		DROP TABLE #ProductTo;

	CREATE TABLE #ProductTo
	(
		[Name] NVARCHAR(MAX)
	);

	IF(@ProductToName IS NOT NULL)
	BEGIN
	  INSERT INTO #ProductTo 
	  SELECT item FROM [Datasets].[fnSplit](@ProductToName, @Delimiter);
	END

	-- Temporary table -> Resource
	IF(OBJECT_ID('tempdb..#Resource') IS NOT NULL) 
		DROP TABLE #Resource;

	CREATE TABLE #Resource
	(
		[Name] NVARCHAR(MAX)
	);

	IF(@ResourceName IS NOT NULL)
	BEGIN
	  INSERT INTO #Resource
	  SELECT item FROM [Datasets].[fnSplit](@ResourceName, @Delimiter);
	END

	-- Temporary table -> Facility
	IF(OBJECT_ID('tempdb..#Facility') IS NOT NULL) 
		DROP TABLE #Facility;

	CREATE TABLE #Facility
	(
		[Name] NVARCHAR(MAX)
	);

	IF(@FacilityName IS NOT NULL)
	BEGIN
	  INSERT INTO #Facility 
	  SELECT item FROM [Datasets].[fnSplit](@FacilityName, @Delimiter);
	END

	-- Temporary table -> Area
	IF(OBJECT_ID('tempdb..#Area') IS NOT NULL) 
		DROP TABLE #Area;

	CREATE TABLE #Area
	(
		[Name] NVARCHAR(MAX)
	);

	IF(@AreaName IS NOT NULL)
	BEGIN
	  INSERT INTO #Area 
	  SELECT item FROM [Datasets].[fnSplit](@AreaName, @Delimiter);
	END

	-- Temporary table -> Order
	IF(OBJECT_ID('tempdb..#Order') IS NOT NULL) 
		DROP TABLE #Order;
	
	CREATE TABLE #Order
	(
		[Name] NVARCHAR(MAX)
	);

	IF(@OrderName IS NOT NULL)
	BEGIN
	  INSERT INTO #Order 
	  SELECT item FROM [Datasets].[fnSplit](@OrderName, @Delimiter);
	END

	-- Temporary table -> ShiftDefinitionShift
	IF(OBJECT_ID('tempdb..#ShiftDefinitionShift') IS NOT NULL) 
		DROP TABLE #ShiftDefinitionShift;

	CREATE TABLE #ShiftDefinitionShift
	(
		[Name] NVARCHAR(MAX)
	);

	IF(@ShiftName IS NOT NULL)
	BEGIN
	  INSERT INTO #ShiftDefinitionShift 
	  SELECT item FROM [Datasets].[fnSplit](@ShiftName, @Delimiter);
	END

	-- Joins
	;WITH ProductSetupTimeCTE AS 
	(
		SELECT  DPFrom.ProductName as ProductNameFrom, 
				DPTo.ProductName as ProductNameTo,
				R.ResourceName,
				F.FacilityName,
				A.AreaName,
				PO.MaterialName as OrderName,
				S.ShiftDefinitionShiftName,
				D.DateKey,
				D.FullDateAlternateKey,
				T.Time24,
				FP.CalculatedSetupTime,
				FP.ExpectedSetupTime,
				FP.ExpectedSetupTime - FP.CalculatedSetupTime AS DifferenceSetupTime
		FROM [Custom].[FactProductSetupTime] FP
		INNER JOIN [dbo].[DimProduct] DPFrom ON DPFrom.ProductKey = FP.ProductFromKey
		INNER JOIN [dbo].[DimProduct] DPTo ON DPTo.ProductKey = FP.ProductToKey
		INNER JOIN [dbo].[DimResource] R ON R.ResourceKey = FP.ResourceKey
		INNER JOIN [dbo].[DimFacility] F ON F.FacilityKey = FP.FacilityKey
		INNER JOIN [dbo].[DimArea] A ON A.AreaKey = FP.AreaKey
		INNER JOIN [dbo].[DimMaterial] PO ON PO.MaterialKey = FP.MaterialKey
		INNER JOIN [dbo].[DimShift] S ON S.ShiftKey = FP.ShiftKey
		INNER JOIN [dbo].[DimDate] D ON D.DateKey = FP.DateKey
		INNER JOIN [dbo].[DimTime] T ON T.TimeKey = FP.TimeKey
		WHERE
				(@StartDateKey IS NULL OR FP.LC1DateKey >= @StartDateKey)
			AND (@EndDateKey IS NULL OR FP.LC1DateKey <= @EndDateKey)
			AND	(@SetupTimeFilter = 0 
				OR  (@SetupTimeFilter = 1 AND DPFrom.ProductName <> DPTo.ProductName)
				OR 	(@SetupTimeFilter = 2 AND DPFrom.ProductName = DPTo.ProductName))
	)

	SELECT *
	FROM ProductSetupTimeCTE
	WHERE
		    (@ProductFromName IS NULL OR EXISTS (SELECT [Name] from #ProductFrom T WHERE ProductNameFrom = T.[Name]))
		AND (@ProductToName IS NULL OR EXISTS (SELECT [Name] from #ProductTo T WHERE ProductNameTo = T.[Name]))
		AND (@ResourceName IS NULL OR EXISTS (SELECT [Name] from #Resource T WHERE ResourceName = T.[Name]))
		AND (@FacilityName IS NULL OR EXISTS (SELECT [Name] from #Facility T WHERE FacilityName = T.[Name]))
		AND (@AreaName IS NULL OR EXISTS (SELECT [Name] from #Area T WHERE AreaName = T.[Name]))
		AND (@OrderName IS NULL OR EXISTS (SELECT [Name] from #Order T WHERE OrderName = T.[Name]))
		AND (@ShiftName IS NULL OR EXISTS (SELECT [Name] from #ShiftDefinitionShift T WHERE ShiftDefinitionShiftName = T.[Name]))
		AND (@ShowOnlyOvertime IS NULL OR @ShowOnlyOvertime = 0 OR (@ShowOnlyOvertime = 1 AND DifferenceSetupTime < 0))
END
GO