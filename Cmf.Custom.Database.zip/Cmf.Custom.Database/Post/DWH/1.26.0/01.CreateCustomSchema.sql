IF(NOT EXISTS(SELECT * FROM [sys].[schemas] WHERE [name] = N'Custom'))
	EXEC sp_executeSQL N'CREATE SCHEMA [Custom]'
GO