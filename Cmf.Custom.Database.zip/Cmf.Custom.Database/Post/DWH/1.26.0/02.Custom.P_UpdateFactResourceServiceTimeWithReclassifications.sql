IF EXISTS (SELECT * 
FROM SYSOBJECTS
WHERE [id] = OBJECT_ID(N'Custom.P_UpdateFactResourceServiceTimeWithReclassifications') AND OBJECTPROPERTY([id], N'IsProcedure') = 1 )
BEGIN
    DROP PROCEDURE [Custom].[P_UpdateFactResourceServiceTimeWithReclassifications]
END
GO

CREATE PROCEDURE [Custom].[P_UpdateFactResourceServiceTimeWithReclassifications] 
( 
	@InfServiceHistoryId bigint = NULL, 
	@SupServiceHistoryId bigint = NULL, 
	@ResourceId bigint = NULL 
)
WITH ENCRYPTION
AS
BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET XACT_ABORT ON
	SET NOCOUNT ON

	DECLARE 
		@StartTranCount int, --Controls number of transactions
		@ErrorMessage nvarchar(max), 
		@ErrorSeverity int, 
		@ErrorState int;

	DECLARE 
		@TABLENAME VARCHAR(32) = 'FactResourceServiceTime',
		@PROCNAME VARCHAR(64) = (SELECT OBJECT_NAME(@@PROCID)),
		@CurrentDatetime DATETIME = GETUTCDATE(),
		@StatusMessage NVARCHAR(256),
		@IsOtheFilterApplied BIT = (SELECT CASE WHEN @ResourceId IS NOT NULL THEN 1 ELSE 0 END),
		@SystemName NVARCHAR(512) = dbo.F_GetSystemName();

	DECLARE 
		@MinServiceHistoryId BIGINT, 
		@MaxServiceHistoryId BIGINT,
		@ODSLink NVARCHAR(512) = 'cm' + @SystemName + 'ODSLink',
		@ODSDataBase NVARCHAR(512) = @SystemName + 'ODS';
		
	DECLARE 
		@MinServDateTime DATETIME, 
		@MaxServDateTime DATETIME;

	BEGIN TRY
		SELECT @StartTranCount = @@TRANCOUNT;

		IF (@StartTranCount = 0)
			BEGIN TRANSACTION;
	
		-- Execute Start Execution
		EXEC [Control].[P_StartExecution] @ProcedureName = @PROCNAME, 
											@MinServiceHistoryIdCalculated = @MinServiceHistoryId OUTPUT, 
											@MaxServiceHistoryIdCalculated = @MaxServiceHistoryId OUTPUT, 
											@InferiorServiceHistoryId = @InfServiceHistoryId, 
											@SuperiorServiceHistoryId = @SupServiceHistoryId, 
											@OtherFilters = @IsOtheFilterApplied;

		-- Get Minimum and Maximum Service History Dates
		SELECT 
			@MinServDateTime = MinServDateTime, 
			@MaxServDateTime = MaxServDateTime 
		FROM [dbo].[F_GetMinAndMaxServiceTime] (@MinServiceHistoryId, @MaxServiceHistoryId);		
		
		-- Get Date Keys
		DECLARE 
			@MinServDateKey INT = [dbo].[F_GetDateKeyFromDateTime] (@MinServDateTime), 
			@MaxServDateKey INT = [dbo].[F_GetDateKeyFromDateTime] (@MaxServDateTime);

		-- Get Date Keys Prunings
		DECLARE 
			@MinServDateKeyPruning INT = [dbo].[F_GetDateKeyFromDateTime](@MinServDateTime - 1),
			@MaxServDateKeyPruning INT = [dbo].[F_GetDateKeyFromDateTime](@MaxServDateTime + 1);
		
		IF(OBJECT_ID(N'tempdb..#ResourceStateReclassifications') IS NOT NULL)
			DROP TABLE #ResourceStateReclassifications;
			
		IF(OBJECT_ID(N'tempdb..#FactsReclassification') IS NOT NULL)
			DROP TABLE #FactsReclassification;

		CREATE TABLE #ResourceStateReclassifications
		(
			StartServiceHistoryId BIGINT,
			StartOperationHistorySeq BIGINT,
			EndServiceHistoryId BIGINT,
			EndOperationHistorySeq BIGINT,
			ResourceId BIGINT,
			StateModelId BIGINT,
			StateModelStateId BIGINT,
			StateModelStateReason NVARCHAR(512),
			ServiceHistoryId BIGINT,
			OperationHistorySeq BIGINT,
			ModifiedOn DATETIME,
			ModifiedBy VARCHAR(64)
		);
	
		-- Get Resource State Reclassification for the specific Service History Ids
		DECLARE @Query NVARCHAR(MAX) = '
		SELECT 
			[ServiceHistoryIdStart],
			[OperationHistorySequenceStart],
			[ServiceHistoryIdEnd],
			[OperationHistorySequenceEnd],
			[ResourceId],
			[StateModelId],
			[StateModelStateId],
			[StateModelStateReason],
			[ServiceHistoryId],
			[OperationHistorySeq],
			[ModifiedOn],
			[ModifiedBy]
		FROM 
		(
			SELECT
				[ServiceHistoryIdStart],
				[OperationHistorySequenceStart],
				[ServiceHistoryIdEnd],
				[OperationHistorySequenceEnd],
				[ResourceId],
				[StateModelId],
				[StateModelStateId],
				[StateModelStateReason],
				[ServiceHistoryId],
				[OperationHistorySeq],
				[ModifiedOn],
				[ModifiedBy],
				ROW_NUMBER() OVER (PARTITION BY [ResourceId], [ServiceHistoryIdStart], [OperationHistorySequenceStart], [ServiceHistoryIdEnd], [OperationHistorySequenceEnd] ORDER BY [ServiceHistoryId] DESC, [ModifiedOn] DESC, [OperationHistorySeq] DESC) AS RowNumber
			FROM ' + @ODSLink + '.' + @ODSDataBase + '.UserDataModel.T_CustomResourceStateReclassificationHistory 
			WHERE @ResourceId IS NULL 
				OR [ResourceId] = @ResourceId
		) AS ResourceStateReclassifications
		WHERE RowNumber = 1
			AND [ServiceHistoryIdEnd] BETWEEN @MinServiceHistoryId AND @MaxServiceHistoryId';
					
		INSERT INTO #ResourceStateReclassifications
		EXECUTE sp_executesql @Query, N'@MinServiceHistoryId BIGINT, @MaxServiceHistoryId BIGINT, @ResourceId BIGINT', @MinServiceHistoryId = @MinServiceHistoryId, @MaxServiceHistoryId = @MaxServiceHistoryId, @ResourceId = @ResourceId;
	
		-- Create Missing Chnage Reasons
		MERGE INTO [dbo].[DimResourceStateModelChangeReason] WITH(TABLOCK) TRG
		USING 
		( 
			SELECT [Constants].[F_GetUndefinedKeyName]() AS [MainStateModelStateReason]
				
			UNION
				
			SELECT SUBSTRING([StateModelStateReason], 1, 450) AS [MainStateModelStateReason]  /* More than this will lead to problems with the unique key index exceeding 900 bytes */
			FROM #ResourceStateReclassifications
			WHERE [StateModelStateReason] IS NOT NULL
		) SRC
		ON (TRG.[ResourceStateModelChangeReason] = SRC.[MainStateModelStateReason])
		WHEN NOT MATCHED THEN 
			INSERT 
			(
				[ResourceStateModelChangeReason]
				,[CreateTimestamp]
				,[UpdateTimestamp]
			)
			VALUES
			(
				SRC.[MainStateModelStateReason]
				,GETUTCDATE()
				,GETUTCDATE()
			);

		SET @StatusMessage = OBJECT_NAME(@@PROCID) + ': ' + cast(@@ROWCOUNT AS VARCHAR) + ' row(s) merged into [dbo].[DimResourceStateModelChangeReason]'
		RAISERROR (@StatusMessage, 0, 1) WITH NOWAIT;
		
		CREATE TABLE #FactsReclassification
		(
			[DateKey] [int] NOT NULL,
			[TimeKey] [int] NOT NULL,
			[ShiftKey] [bigint] NOT NULL,
			[ShiftDateKey] [int] NOT NULL,
			[AreaKey] [bigint] NOT NULL,
			[ResourceKey] [bigint] NOT NULL,
			[ServiceHistoryId] [bigint] NOT NULL,
			[OperationHistorySeq] [bigint] NOT NULL,
			[SubOperationSequence] [int] NOT NULL,
			[SEMI-E10] [nvarchar](512) NULL,
			[Basic] [nvarchar](512) NULL,
			[MainStateModelStateReason] [nvarchar](512) NULL,
			[ResourceStateModelKey] [bigint] NULL,
			[ResourceStateModelChangeReasonKey] [bigint] NULL,
			[PreviousBasic] [nvarchar](512) NULL,
			[Reclassification] [bit],
			CONSTRAINT [PK_TempFactResourceServiceTime] PRIMARY KEY CLUSTERED 
			(
				[DateKey] ASC,
				[TimeKey] ASC,
				[ShiftKey] ASC,
				[ShiftDateKey] ASC,
				[AreaKey] ASC,
				[ResourceKey] ASC,
				[ServiceHistoryId] ASC,
				[OperationHistorySeq] ASC,
				[SubOperationSequence] ASC
			)
		);
		
		-- Get Fact with reclassifications
		INSERT INTO #FactsReclassification
		SELECT
			FRST.[DateKey],
			FRST.[TimeKey],
			FRST.[ShiftKey],
			FRST.[ShiftDateKey],
			FRST.[AreaKey],
			FRST.[ResourceKey],
			FRST.[ServiceHistoryId],
			FRST.[OperationHistorySeq],
			FRST.[SubOperationSequence],
			DRSM.[StateModelStateSemiE10Value] AS [SEMI-E10],
			ISNULL(DRSM.[StateModelStateBasicValue], FRST.[Basic]) AS [Basic],
			RSR.[StateModelStateReason],
			DRSM.[ResourceStateModelKey],
			DRSMCR.[ResourceStateModelChangeReasonKey],
			LAG(ISNULL(DRSM.[StateModelStateBasicValue], FRST.[Basic]), 1, '') OVER (ORDER BY FRST.[ServiceHistoryId], FRST.[UTCOperationEndTime], FRST.[OperationHistorySeq]) AS Prev,
			CASE WHEN RSR.[ResourceId] IS NULL 
				THEN 0
				ELSE 1
			END [Reclassification]
		FROM dbo.FactResourceServiceTime AS FRST
		INNER JOIN dbo.DimResource AS DR
			ON DR.ResourceKey = FRST.ResourceKey
		LEFT JOIN #ResourceStateReclassifications AS RSR
			ON RSR.[ResourceId] = DR.[ResourceId]
			AND FRST.[ServiceHistoryId] BETWEEN RSR.[StartServiceHistoryId] AND RSR.[EndServiceHistoryId]
			AND 
			(
				FRST.[ServiceHistoryId] = RSR.[StartServiceHistoryId] AND FRST.[OperationHistorySeq] >= RSR.[StartOperationHistorySeq]
				OR FRST.[ServiceHistoryId] = RSR.[EndServiceHistoryId] AND FRST.OperationHistorySeq < RSR.[EndOperationHistorySeq]
				OR (FRST.[ServiceHistoryId] > RSR.[StartServiceHistoryId] AND FRST.ServiceHistoryId < RSR.[EndServiceHistoryId])
			)
		LEFT JOIN dbo.DimResourceStateModel AS DRSM
			ON DRSM.[StateModelId] = RSR.[StateModelId]
			AND DRSM.[StateModelStateId] = RSR.[StateModelStateId]
		LEFT JOIN dbo.DimResourceStateModelChangeReason AS DRSMCR
			ON DRSMCR.[ResourceStateModelChangeReason] = SUBSTRING(RSR.[StateModelStateReason], 1, 450)
		WHERE FRST.[ServiceHistoryId] BETWEEN @MinServiceHistoryId AND @MaxServiceHistoryId;

		-- Update the Fact Table with the reclassifications
		MERGE INTO dbo.FactResourceServiceTime AS FACT
		USING #FactsReclassification AS Reclassifications
		ON FACT.[DateKey] = Reclassifications.[DateKey]
			AND FACT.[TimeKey] = Reclassifications.[TimeKey]
			AND FACT.[ShiftKey] = Reclassifications.[ShiftKey]
			AND FACT.[ShiftDateKey] = Reclassifications.[ShiftDateKey]
			AND FACT.[AreaKey] = Reclassifications.[AreaKey]
			AND FACT.[ResourceKey] = Reclassifications.[ResourceKey]
			AND FACT.[ServiceHistoryId] = Reclassifications.[ServiceHistoryId]
			AND FACT.[OperationHistorySeq] = Reclassifications.[OperationHistorySeq]
			AND FACT.[SubOperationSequence] = Reclassifications.[SubOperationSequence]
			AND Reclassifications.[Reclassification] = 1
		WHEN MATCHED THEN
			UPDATE SET
				[SEMI-E10] = Reclassifications.[SEMI-E10],
				[Basic] = Reclassifications.[Basic],
				[MainStateModelStateReason] = Reclassifications.[MainStateModelStateReason],
				[ResourceStateModelKey] = Reclassifications.[ResourceStateModelKey],
				[ResourceStateModelChangeReasonKey] = Reclassifications.[ResourceStateModelChangeReasonKey],
				[UpToDownTransition] = CASE WHEN Reclassifications.[Basic] = 'UP' AND  Reclassifications.[PreviousBasic] IN ('Down','Nonscheduled') THEN 1 ELSE 0 END,
				[DownToUpTransition] = CASE WHEN Reclassifications.[Basic] IN ('Down','Nonscheduled') AND  Reclassifications.[PreviousBasic] = 'UP' THEN 1 ELSE 0 END;
				
		SET @StatusMessage = OBJECT_NAME(@@PROCID) + ': ' + cast(@@ROWCOUNT as varchar) + ' row(s) merged into [dbo].[FactResourceServiceTime]'
		RAISERROR (@StatusMessage, 0, 1) WITH NOWAIT;
		
		-- Execute Stop Execution
		EXEC [Control].[P_StopExecution] @ProcedureName = @PROCNAME, 
											@StatusMsg = @StatusMessage;

		-- If There was no transaction on the beginning of the exception, a new one was created and has to be committed.
		IF(@StartTranCount = 0)
			COMMIT TRANSACTION;			
		
	END TRY
	BEGIN CATCH
		IF XACT_STATE() <> 0 AND @starttrancount = 0 
			ROLLBACK TRANSACTION;

		EXEC Control.P_StopExecution @PROCNAME;

		SELECT 
			@ErrorMessage = ERROR_MESSAGE() + ' Line ' + CAST(ERROR_LINE() AS NVARCHAR(5)), 
			@ErrorSeverity = ERROR_SEVERITY(), 
			@ErrorState = ERROR_STATE();

		RAISERROR (@ErrorMessage, @ErrorSeverity, @ErrorState);

	END CATCH

END;