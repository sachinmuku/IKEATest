IF (EXISTS(SELECT * FROM sys.procedures SP INNER JOIN sys.schemas SS ON SS.schema_id = SP.schema_id WHERE SP.name = 'P_LoadFactProductSetupTime' AND SS.name = 'Custom'))
BEGIN
	DROP PROCEDURE [Custom].[P_LoadFactProductSetupTime]
END
GO

CREATE PROCEDURE [Custom].[P_LoadFactProductSetupTime]	
(
	@InfServiceHistoryId BIGINT		= NULL
	, @SupServiceHistoryId BIGINT	= NULL
	, @MaterialId BIGINT			= NULL
)
WITH ENCRYPTION
AS
BEGIN

	SET NOCOUNT ON
	
	-- TRANSACTION CONTROL VARIABLES
	DECLARE @StartTranCount					INTEGER
	
	-- ERROR HANDLING VARIABLES
	DECLARE @ErrorSeverity					INTEGER
	DECLARE @ErrorState						INTEGER
	DECLARE @ErrorMessage					NVARCHAR(MAX)
	
	-- EXECUTION CONTROL VARIABLES
	DECLARE @ProcedureName					NVARCHAR(64)	= OBJECT_NAME(@@PROCID)
	DECLARE @IsOtheFilterApplied			BIT				= (CASE WHEN @MaterialId IS NOT NULL THEN 1 ELSE 0 END)
	DECLARE @MinServiceHistoryId			BIGINT
	DECLARE @MaxServiceHistoryId			BIGINT
	DECLARE @InternalMinServiceHistoryId	BIGINT
	DECLARE @InternalMaxServiceHistoryId	BIGINT
	DECLARE @InternalMinDate				DATETIME
	DECLARE @InternalMaxDate				DATETIME
	DECLARE @MinServDateTime				DATETIME
	DECLARE	@MaxServDateTime				DATETIME
	DECLARE @MinServDateKey					INTEGER
	DECLARE @MaxServDateKey					INTEGER
	DECLARE @ApplyUDF						BIT				= 0
	DECLARE	@ConversionOffsetToLocal		INT				= 0
	DECLARE	@ConversionOffsetToUTC			INT				= 0
	DECLARE @TimeZone						NVARCHAR(255)	= [DateTimeUtil].[F_GetServerTimeZoneIdentifier]()
	DECLARE @LogMessage						NVARCHAR(MAX)	= N''
	DECLARE @LogMessageTemplateStart		NVARCHAR(MAX)	= @ProcedureName + N': %TaskName%'
	DECLARE @LogMessageTemplateEnd			NVARCHAR(MAX)	= REPLICATE(N' ', LEN(@ProcedureName) + 2) +  N'Task Completed in %ExecutionTime% second(s). Rows Affected: %RowsAffected%.'
	DECLARE @ExecutionControlTS				DATETIME
	DECLARE @ProcedureStart					DATETIME		= GETDATE()
	DECLARE @ExecutionTimeInSeconds			BIGINT			= 0
	DECLARE @RowsAffected					BIGINT			= 0
	DECLARE @LC1TimeZoneIdentifier			NVARCHAR(255)	= [Constants].[F_GetLC1TimeZoneIdentifier]()
	DECLARE @SqlStatement					NVARCHAR(MAX)	= N''
	
	-- FALLBACK KEYS
	DECLARE @UndefinedKey					BIGINT			= Constants.F_GetUndefinedKey()
	DECLARE @UndefinedProductKey			BIGINT			= (SELECT [ProductKey] FROM DimProduct WHERE [ProductId] = @UndefinedKey)
	DECLARE @UndefinedMaterialKey			BIGINT			= (SELECT [MaterialKey] FROM DimMaterial WHERE [MaterialId] = @UndefinedKey)
	
	BEGIN TRY

		-- GET CURRENT TRANSACTION COUNTER
		SELECT @StartTranCount = @@TRANCOUNT

		-- BEGIN A TRANSACTION IF EXECUTION IS NOT UNDER AN ALREADY RUNNING TRANSACTION
		IF @StartTranCount = 0
			BEGIN TRANSACTION
		
		-- LOG START OF EXECUTION
		EXEC Control.P_StartExecution @ProcedureName, @MinServiceHistoryIdCalculated = @MinServiceHistoryId OUTPUT, @MaxServiceHistoryIdCalculated = @MaxServiceHistoryId OUTPUT
									, @InferiorServiceHistoryId = @InfServiceHistoryId, @SuperiorServiceHistoryId = @SupServiceHistoryId, @OtherFilters = @IsOtheFilterApplied
		
		SELECT @MinServDateTime = [MinServDateTime], @MaxServDateTime = [MaxServDateTime] FROM [dbo].[F_GetMinAndMaxServiceTime](@MinServiceHistoryId, @MaxServiceHistoryId)

		SELECT @ApplyUDF = ApplyUDFCalculation, @ConversionOffsetToLocal = LocalConversionOffset, @ConversionOffsetToUTC = UTCConversionOffset
		FROM [DateTimeUtil].[F_GetLocalDateTimeProcessingType](@TimeZone, @MinServDateTime, @MaxServDateTime)

		-- DEFINE KEY INTERVALS
		SELECT @MinServDateTime = MinServDateTime, @MaxServDateTime = MaxServDateTime FROM [dbo].[F_GetMinAndMaxServiceTime](@MinServiceHistoryId, @MaxServiceHistoryId)
		SET @MinServDateKey = [dbo].[F_GetDateKeyFromDateTime](@MinServDateTime)
		SET @MaxServDateKey = [dbo].[F_GetDateKeyFromDateTime](@MaxServDateTime);
		
		IF(@MaxServiceHistoryId >= @MinServiceHistoryId)
		BEGIN
		
			

			-- TEMPORARY TABLE DECLARATIONS
			BEGIN
				SET @ExecutionControlTS = GETDATE()
				SET @LogMessage = REPLACE(@LogMessageTemplateStart, N'%TaskName%' , + N'Setting up temporary tables...')
				RAISERROR (@LogMessage, 0, 1) WITH NOWAIT

				-- TABLE #TargetMaterials
				BEGIN
					IF(OBJECT_ID('tempdb..#MaterialsToProcess') IS NOT NULL)
						DROP TABLE #MaterialsToProcess

					CREATE TABLE #MaterialsToProcess([MaterialId] BIGINT PRIMARY KEY, [MinServiceHistoryId] BIGINT, [MaxServiceHistoryId] BIGINT)
				END

				-- TABLE #ValidSetupStates
				BEGIN
					IF(OBJECT_ID('tempdb..#ValidSetupStates') IS NOT NULL)
						DROP TABLE #ValidSetupStates

					CREATE TABLE #ValidSetupStates([SetupStateName] NVARCHAR(MAX))
				END

				-- TABLE #MaterialsStateModelStates
				BEGIN
					IF(OBJECT_ID('tempdb..#MaterialsStateModelStates') IS NOT NULL)
						DROP TABLE #MaterialsStateModelStates

					  CREATE TABLE #MaterialsStateModelStates(
						[MaterialId]					BIGINT
						, [ModifiedOn]					DATETIME
						, [ServiceHistoryId]			BIGINT
						, [OperationHistorySeq]			BIGINT
						, [LastProcessedResourceId]		BIGINT
						, [ProductId]					BIGINT
						, [StateModelState]				NVARCHAR(MAX)
						, [FacilityId]					BIGINT
						, [AreaId]						BIGINT
						, [IsSetupBlock]				BIT
						, [MaterialHistoryOrder]		BIGINT
						, [StateBlockOrder]				BIGINT
						, [NextHistoryRecordTimeStamp]	DATETIME
						, PRIMARY KEY([MaterialId], [MaterialHistoryOrder])
					)

					CREATE INDEX IDX_LastProcessedResourceId ON #MaterialsStateModelStates([LastProcessedResourceId])
				END

				-- TABLE #MaterialSetupStateSummary
				BEGIN
					IF(OBJECT_ID('tempdb..#MaterialSetupStateSummary') IS NOT NULL)
						DROP TABLE #MaterialSetupStateSummary

					CREATE TABLE #MaterialSetupStateSummary
					(
						[MaterialId]					BIGINT
						, [EligibleProductId]			BIGINT
						, [EligibleFacilityId]			BIGINT
						, [EligibleAreaId]				BIGINT
						, [EligibleResourceId]			BIGINT
						, [ServiceHistoryId]			BIGINT
						, [InitialTimeStamp]			DATETIME
						, [LastKnownFinalTimeStamp]		DATETIME
						, [CalculateSetupTime]		AS	DATEDIFF(SECOND, [InitialTimeStamp], [LastKnownFinalTimeStamp])
					)

				END

				-- TABLE #MaterialsTransitions
				BEGIN
					IF(OBJECT_ID('tempdb..#MaterialsTransitions') IS NOT NULL)
						DROP TABLE #MaterialsTransitions

					CREATE TABLE #MaterialsTransitions(
						[MaterialId]			BIGINT
						, [ProductId]			BIGINT
						, [ServiceHistoryId]	BIGINT
						, [FacilityId]			BIGINT
						, [AreaId]				BIGINT
						, [ResourceId]			BIGINT
						, [FactTimeStamp]		DATETIME
						, [LC1FactTimeStamp]	DATETIME
						, [PreviousProductId]	BIGINT
						, [CalculatedSetupTime] DECIMAL(38,4)
						, [ExpectedSetupTime]	DECIMAL(38,4)
					)
				END

				-- TABLE #MaterialDimension
				BEGIN
					IF(OBJECT_ID('tempdb..#MaterialDimension') IS NOT NULL)
						DROP TABLE #MaterialDimension

					CREATE TABLE #MaterialDimension
					(
						[MaterialId] BIGINT
						, [MaterialKey] BIGINT
						, PRIMARY KEY([MaterialId], [MaterialKey])
					)
				END

				-- TABLE #ExpectedSetupTimes
				BEGIN

					IF(OBJECT_ID('tempdb..#ExpectedSetupTimes') IS NOT NULL)
						DROP TABLE #ExpectedSetupTimes

					CREATE TABLE #ExpectedSetupTimes
					(
						[ProductFromKey]		BIGINT
						, [ProductToKey]		BIGINT
						, [ResourceKey]			BIGINT
						, [FacilityKey]			BIGINT
						, [AreaKey]				BIGINT
						, [ExpectedSetupTime]	DECIMAL(10, 4)
					)
				END


				SET @ExecutionTimeInSeconds = DATEDIFF(SECOND, @ExecutionControlTS, GETDATE())
				SET @LogMessage = REPLACE(REPLACE(@LogMessageTemplateEnd, N'%ExecutionTime%', CONVERT(NVARCHAR, @ExecutionTimeInSeconds)), N'%RowsAffected%', N'N/A')
				RAISERROR(@LogMessage, 0, 1) WITH NOWAIT
			END


			-- COLLECT MATERIAL IDS
			BEGIN

				SET @ExecutionControlTS = GETDATE()
				SET @LogMessage = REPLACE(@LogMessageTemplateStart, N'%TaskName%', N'Collect Materials to be processed in current execution...')
				RAISERROR(@LogMessage, 0, 1) WITH NOWAIT

				IF(@MaterialId IS NULL)
				BEGIN
				
					INSERT INTO #MaterialsToProcess([MaterialId])
					SELECT DISTINCT MH.[MaterialId]
					FROM [Staging].[T_MaterialHistory] MH
					INNER JOIN [Staging].[ODS_T_Material] M ON M.[MaterialId] = MH.[MaterialId]
					WHERE M.Form IN (
							SELECT DISTINCT [ValueString]
							FROM [Staging].[ODS_T_Config]
							WHERE [ConfigPath] IN ('/Cmf/Custom/MaterialTracking/OrderMaterialForm/', '/Cmf/Custom/MaterialTracking/BatchMaterialForm/')
								AND ISNULL([ValueString], N'') <> N''
						)
				END
				ELSE
				BEGIN

					INSERT INTO #MaterialsToProcess([MaterialId]) VALUES (@MaterialId)

				END

				-- GET RANGE OF INTERNAL SERVICE HISTORY IDS TO CAPTURE FULL ELIGIBLE MATERIAL HISTORY
				SELECT @InternalMinDate = MIN(M.[CreatedOn]), @InternalMaxDate = MAX(M.[ModifiedOn])
				FROM #MaterialsToProcess MTP
				INNER JOIN [Staging].[ODS_T_Material] M ON M.[MaterialId] = MTP.[MaterialId]

				-- GET INTERNAL MIN AND MAX SERVICEHISTORYIDS
				SET @InternalMinServiceHistoryId = [dbo].[F_GetMinServiceHistoryIdForDate](@InternalMinDate)
				SET @InternalMaxServiceHistoryId = [dbo].[F_GetMaxServiceHistoryIdForDate](@InternalMaxDate)

				SET @RowsAffected = @@ROWCOUNT
				SET @ExecutionTimeInSeconds = DATEDIFF(SECOND, @ExecutionControlTS, GETDATE())
				SET @LogMessage = REPLACE(REPLACE(@LogMessageTemplateEnd, N'%ExecutionTime%', CONVERT(NVARCHAR, @ExecutionTimeInSeconds)), N'%RowsAffected%', CONVERT(NVARCHAR, @RowsAffected))
				RAISERROR(@LogMessage, 0, 1) WITH NOWAIT

			END

			-- COLLECT VALID SETUP STATES
			BEGIN

				SET @ExecutionControlTS = GETDATE()
				SET @LogMessage = REPLACE(@LogMessageTemplateStart, N'%TaskName%', N'Collect valid setup states from ODS generic table in current execution...')
				RAISERROR(@LogMessage, 0, 1) WITH NOWAIT

				INSERT INTO #ValidSetupStates ([SetupStateName])
				SELECT GT.[MaterialState] FROM [Custom].[ODS_T_GT_CustomMaterialStatesForSetupTime] GT

				SET @RowsAffected = @@ROWCOUNT
				SET @ExecutionTimeInSeconds = DATEDIFF(SECOND, @ExecutionControlTS, GETDATE())
				SET @LogMessage = REPLACE(REPLACE(@LogMessageTemplateEnd, N'%ExecutionTime%', CONVERT(NVARCHAR, @ExecutionTimeInSeconds)), N'%RowsAffected%', CONVERT(NVARCHAR, @RowsAffected))
				RAISERROR(@LogMessage, 0, 1) WITH NOWAIT

			END

			-- DELETE EXISTING FACTS FOR REBUILDING (ALL THE MATERIALS BEING PROCESSED)
			BEGIN
				SET @ExecutionControlTS = GETDATE()
				SET @LogMessage = REPLACE(@LogMessageTemplateStart, N'%TaskName%', N'Removing already existing facts...')
				RAISERROR(@LogMessage, 0, 1) WITH NOWAIT

				IF(@MaterialId IS NOT NULL)
				BEGIN
					DELETE FROM [Custom].[FactProductSetupTime]
					WHERE [MaterialKey] IN (SELECT DM.[MaterialKey] FROM DimMaterial DM WHERE DM.[MaterialId] = @MaterialId)
				END
				ELSE
				BEGIN
					DELETE FROM [Custom].[FactProductSetupTime]
					WHERE [MaterialKey] IN (SELECT DM.[MaterialKey] FROM DimMaterial DM INNER JOIN #MaterialsToProcess MTP ON DM.[MaterialId] = MTP.MaterialId)
				END


				      
				SET @RowsAffected = @@ROWCOUNT
				SET @ExecutionTimeInSeconds = DATEDIFF(SECOND, @ExecutionControlTS, GETDATE())
				SET @LogMessage = REPLACE(REPLACE(@LogMessageTemplateEnd, N'%ExecutionTime%', CONVERT(NVARCHAR, @ExecutionTimeInSeconds)), N'%RowsAffected%', CONVERT(NVARCHAR, @RowsAffected))
				RAISERROR(@LogMessage, 0, 1) WITH NOWAIT

			END


			-- GET ALL THE MATERIAL HISTORY AND RANK THEM BY RESOURCE, ORDERED BY SERVICEHISTORYID AND MODIFIEDDATE
			BEGIN

				SET @ExecutionControlTS = GETDATE()
				SET @LogMessage = REPLACE(@LogMessageTemplateStart, N'%TaskName%', N'Get data for processing...')
				RAISERROR(@LogMessage, 0, 1) WITH NOWAIT

				-- COLLECT ALL DATA FROM THE AFFECTED MATERIAL
				INSERT INTO #MaterialsStateModelStates([MaterialId], [ModifiedOn], [ServiceHistoryId], [OperationHistorySeq], [LastProcessedResourceId]
															, [ProductId], [StateModelState], [FacilityId], [AreaId], [MaterialHistoryOrder], [IsSetupBlock])
				SELECT MH.[MaterialId], MH.[ModifiedOn], MH.[ServiceHistoryId], MH.[OperationHistorySeq], MH.[LastProcessedResourceId], MH.[ProductId], SMS.[Name]
					, MH.[FacilityId], A.[AreaId]
					, DENSE_RANK() OVER (PARTITION BY MH.[MaterialId] ORDER BY MH.[ModifiedOn], MH.[ServiceHistoryId], MH.[OperationHistorySeq])
					, CASE WHEN VSS.[SetupStateName] IS NULL THEN 0 ELSE 1 END /* IsSetupBlock */
				FROM #MaterialsToProcess MTP
				INNER JOIN [Staging].[ODS_T_MaterialHistory] MH ON MH.[MaterialId] = MTP.[MaterialId]
				INNER JOIN [Staging].[ODS_T_StepArea] SA ON SA.[SourceEntityId] = MH.[StepId]
				INNER JOIN [Staging].[ODS_T_Area] A ON A.[AreaId] = SA.[TargetEntityId] AND A.[FacilityId] = MH.[FacilityId]
				LEFT JOIN [Staging].[ODS_T_StateModelState] SMS ON SMS.[StateModelStateId] = MH.[MainStateModelStateId]
				LEFT JOIN #ValidSetupStates VSS ON VSS.[SetupStateName] = SMS.[Name]
				-- MAKE USE OF PARTIONING FILTERING
				WHERE MH.[ServiceHistoryId] BETWEEN @InternalMinServiceHistoryId AND @InternalMaxServiceHistoryId

				-- UPDATE RECORDS MARKING STATE CONTEXT CHANGE, WHEN SWITCHING FROM SETUP STATE BLOCK TO NON SETUP STATE BLOCK AND VICE VERSA
				;WITH BASE_DATA AS
				(
					SELECT MSMST.[MaterialId], MSMST.[MaterialHistoryOrder]
						-- GET IF CURRENT RECORD IS MARKING THE START OF A NEW SETUP/NON SETUP BLOCK, TO BE USED IN PUTTING ALL RECORDS WITHIN SAME BLOCK AS ONE
						, CASE WHEN ISNULL((LAG(MSMST.[IsSetupBlock]) OVER (PARTITION BY MSMST.[MaterialId] ORDER BY MSMST.[MaterialHistoryOrder])), N'') <> MSMST.[IsSetupBlock]
							THEN [MaterialHistoryOrder]
							ELSE NULL
							END [SetupStateChangeMarker]
						-- GET NEXT HISTORY RECORD TIMESTAMP TO KNOW WHEN THE ACTUAL ONE FINISHES
						, ISNULL(LEAD(MSMST.[ModifiedOn]) OVER (PARTITION BY MSMST.[MaterialId] ORDER BY MSMST.[MaterialHistoryOrder]), GETUTCDATE()) [NextHistoryRecordTimeStamp]
					FROM #MaterialsStateModelStates MSMST
				)
				UPDATE TRG
				SET TRG.[StateBlockOrder] = BD.[SetupStateChangeMarker]
					, TRG.[NextHistoryRecordTimeStamp] = BD.[NextHistoryRecordTimeStamp]
				FROM #MaterialsStateModelStates TRG
				INNER JOIN BASE_DATA BD ON BD.[MaterialId] = TRG.[MaterialId]
					AND BD.[MaterialHistoryOrder] = TRG.[MaterialHistoryOrder]

				-- UPDATE ALL ROWS WITHIN SAME LOGICAL SETUP STATE BLOCK
				;WITH BASE_DATA AS
				(
					SELECT MSMST.[MaterialId], MSMST.[MaterialHistoryOrder]
						-- GET MAXIMUM SETUP BLOCK IDENTIFIER TO UPDATE THE ROW WITH ITS ACTUAL BLOCK NUMBER
						, MAX([StateBlockOrder]) OVER (PARTITION BY MSMST.[MaterialId] ORDER BY MSMST.[MaterialHistoryOrder] ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) [NewStateBlockOrder]
					FROM #MaterialsStateModelStates MSMST
				)
				UPDATE TRG
				SET TRG.[StateBlockOrder] = BD.[NewStateBlockOrder]					
				FROM #MaterialsStateModelStates TRG
				INNER JOIN BASE_DATA BD ON BD.[MaterialId] = TRG.[MaterialId]
					AND BD.[MaterialHistoryOrder] = TRG.[MaterialHistoryOrder]

				-- COLLECT DISTINCT FACTS PER SETUP BLOCK AND STORE THEM 
				-- CONSIDER FOR REPORTING EFFECTS LAST PRODUCT, FACILITY, ETC WITHIN SETUP STATE BLOCK
				INSERT INTO #MaterialSetupStateSummary([MaterialId], [EligibleProductId], [EligibleFacilityId], [EligibleAreaId], [EligibleResourceId], [ServiceHistoryId], [InitialTimeStamp], [LastKnownFinalTimeStamp])
				SELECT DISTINCT MSMST.[MaterialId]
					, LAST_VALUE(MSMST.[ProductId]) OVER (PARTITION BY MSMST.[MaterialId], MSMST.[StateBlockOrder] ORDER BY MSMST.[MaterialHistoryOrder]) [EligibleProductId]
					, LAST_VALUE(MSMST.[FacilityId]) OVER (PARTITION BY MSMST.[MaterialId], MSMST.[StateBlockOrder] ORDER BY MSMST.[MaterialHistoryOrder]) [EligibleFacilityId]
					, LAST_VALUE(MSMST.[AreaId]) OVER (PARTITION BY MSMST.[MaterialId], MSMST.[StateBlockOrder] ORDER BY MSMST.[MaterialHistoryOrder]) [EligibleAreaId]
					, LAST_VALUE(MSMST.[LastProcessedResourceId]) OVER (PARTITION BY MSMST.[MaterialId], MSMST.[StateBlockOrder] ORDER BY MSMST.[MaterialHistoryOrder]) [EligibleResourceId]
					, LAST_VALUE(MSMST.[ServiceHistoryId]) OVER (PARTITION BY MSMST.[MaterialId], MSMST.[StateBlockOrder] ORDER BY MSMST.[MaterialHistoryOrder] ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING) [ServiceHistoryId]
					, MIN(MSMST.[ModifiedOn]) OVER (PARTITION BY MSMST.[MaterialId], MSMST.[StateBlockOrder]) [InitialTimeStamp]
					, MAX(MSMST.[NextHistoryRecordTimeStamp]) OVER (PARTITION BY MSMST.[MaterialId], MSMST.[StateBlockOrder]) [LastKnownFinalTimeStamp]
				FROM #MaterialsStateModelStates MSMST
				WHERE MSMST.[IsSetupBlock] = 1

				SET @RowsAffected = @@ROWCOUNT
				SET @ExecutionTimeInSeconds = DATEDIFF(SECOND, @ExecutionControlTS, GETDATE())
				SET @LogMessage = REPLACE(REPLACE(@LogMessageTemplateEnd, N'%ExecutionTime%', CONVERT(NVARCHAR, @ExecutionTimeInSeconds)), N'%RowsAffected%', CONVERT(NVARCHAR, @RowsAffected))
				RAISERROR(@LogMessage, 0, 1) WITH NOWAIT
			END

			-- CROSS MATERIAL DATA TO GET THE ACTUAL AND NEXT STATES
			BEGIN
				SET @ExecutionControlTS = GETDATE()
				SET @LogMessage = REPLACE(@LogMessageTemplateStart, N'%TaskName%', N'Process data for determining material states...')
				RAISERROR(@LogMessage, 0, 1) WITH NOWAIT

				INSERT INTO #MaterialsTransitions ([MaterialId], [ProductId], [ServiceHistoryId], [FacilityId], [AreaId], [ResourceId], [FactTimeStamp], [LC1FactTimeStamp], [PreviousProductId], [CalculatedSetupTime])
				SELECT MSSM.[MaterialId]
					, MSSM.[EligibleProductId]
					, MSSM.[ServiceHistoryId]
					, MSSM.[EligibleFacilityId]
					, MSSM.[EligibleAreaId]
					, MSSM.[EligibleResourceId]
					, MSSM.[LastKnownFinalTimeStamp]
					, [DateTimeUtil].[UDF_ConvertUtcToLocalByTimezoneIdentifier] (@LC1TimeZoneIdentifier, MSSM.[LastKnownFinalTimeStamp])
					, LAG(MSSM.[EligibleProductId]) OVER(PARTITION BY MSSM.[EligibleResourceId] ORDER BY MSSM.[InitialTimeStamp]) [PreviousProductId]
					, MSSM.[CalculateSetupTime]
				FROM #MaterialSetupStateSummary AS MSSM

				SET @RowsAffected = @@ROWCOUNT
				SET @ExecutionTimeInSeconds = DATEDIFF(SECOND, @ExecutionControlTS, GETDATE())
				SET @LogMessage = REPLACE(REPLACE(@LogMessageTemplateEnd, N'%ExecutionTime%', CONVERT(NVARCHAR, @ExecutionTimeInSeconds)), N'%RowsAffected%', CONVERT(NVARCHAR, @RowsAffected))
				RAISERROR(@LogMessage, 0, 1) WITH NOWAIT

			END

			-- GET LATEST DIMENSION KEYS INVOLVED IN THE PROCESS
			-- SOME MATERIALS MAY BE GIVEN NEW MaterialKey WHEN CHANGING PRODUCTION ORDER FOR EXAMPLE
			BEGIN

				-- Material
				;WITH BASE_DATA AS
				(
					SELECT DISTINCT [MaterialId] FROM #MaterialsTransitions
				), DIMENSION_CROSSING AS
				(
					SELECT DM.[MaterialId]
						, DM.[MaterialKey]
						, DENSE_RANK() OVER (PARTITION BY DM.[MaterialId] ORDER BY DM.[UpdateTimeStamp] DESC, DM.[MaterialKey] DESC) IsLastKnownDimensionEntry
					FROM BASE_DATA BD
					INNER JOIN [dbo].[DimMaterial] DM ON DM.[MaterialId] = BD.[MaterialId]
				)
				INSERT INTO #MaterialDimension([MaterialId], [MaterialKey])
				SELECT DC.[MaterialId], DC.[MaterialKey] FROM DIMENSION_CROSSING DC
				WHERE DC.[IsLastKnownDimensionEntry] = 1
				UNION
				SELECT [MaterialId], [MaterialKey]
				FROM [dbo].[DimMaterial] 
				WHERE [MaterialId] = 0
			END

			-- FOR CASES WHERE PREVIOUS PRODUCT IS NOT DETERMINED WITHIN TEMP DATA, TRY TO EXTRACT FROM PREVIOUS FACTS
			BEGIN
				SET @ExecutionControlTS = GETDATE()
				SET @LogMessage = REPLACE(@LogMessageTemplateStart, N'%TaskName%', N'Update unknown previous product transitions if already in fact table...')
				RAISERROR(@LogMessage, 0, 1) WITH NOWAIT

				;WITH BASE_DATA AS
				(
					SELECT MT.[MaterialId], MT.[ServiceHistoryId], DR.[ResourceKey]
						, CAST(CONVERT(NVARCHAR(8), MT.[FactTimeStamp], 112) AS INTEGER) AS [DateKey]
						, DATEPART(HH, MT.[FactTimeStamp]) * (10000) + DATEPART(MI, MT.[FactTimeStamp]) * (100) + DATEPART(SS, MT.[FactTimeStamp]) [TimeKey]
					FROM #MaterialsTransitions MT
					INNER JOIN [dbo].[DimResource] DR ON DR.[ResourceId] = MT.[ResourceId]
					WHERE MT.[PreviousProductId] IS NULL
				), RESOURCE_LAST_KNOWN_FACT_BASE AS
				(
					SELECT BD.[MaterialId]
						, BD.[ServiceHistoryId]
						, DENSE_RANK() OVER (PARTITION BY FPST.[ResourceKey] ORDER BY FPST.[DateKey] DESC, FPST.[TimeKey], FPST.[ServiceHistoryId] DESC) [IsLastRecord]
						, DP.[ProductId]
					FROM BASE_DATA BD
					INNER JOIN [Custom].[FactProductSetupTime] FPST ON FPST.[ResourceKey] = BD.[ResourceKey]
					INNER JOIN [dbo].[DimProduct] DP ON DP.[ProductKey] = FPST.[ProductToKey]
					WHERE (
							(FPST.[DateKey] = BD.[DateKey] AND FPST.[TimeKey] < BD.[TimeKey])
							OR
							(FPST.[DateKey] < BD.[DateKey])
						)
				), RESOURCE_LAST_KNOWN_FACT AS
				(
					SELECT RLFFB.[MaterialId]
						, RLFFB.[ServiceHistoryId]
						, RLFFB.[ProductId]
					FROM RESOURCE_LAST_KNOWN_FACT_BASE RLFFB
					WHERE RLFFB.[IsLastRecord] = 1
					
				)
				UPDATE MT SET MT.[PreviousProductId] = RLKF.[ProductId]
				FROM RESOURCE_LAST_KNOWN_FACT RLKF
				INNER JOIN #MaterialsTransitions MT ON RLKF.[MaterialId] = MT.[MaterialId]
					AND RLKF.[ServiceHistoryId] = MT.[ServiceHistoryId]				

				SET @RowsAffected = @@ROWCOUNT
				SET @ExecutionTimeInSeconds = DATEDIFF(SECOND, @ExecutionControlTS, GETDATE())
				SET @LogMessage = REPLACE(REPLACE(@LogMessageTemplateEnd, N'%ExecutionTime%', CONVERT(NVARCHAR, @ExecutionTimeInSeconds)), N'%RowsAffected%', CONVERT(NVARCHAR, @RowsAffected))
				RAISERROR(@LogMessage, 0, 1) WITH NOWAIT

			END

			-- GENERATE FINAL DATA FOR FACTS
			BEGIN
				SET @ExecutionControlTS = GETDATE()
				SET @LogMessage = REPLACE(@LogMessageTemplateStart, N'%TaskName%', N'Merge Data Into [Custom].[FactProductSetupTime]...')
				RAISERROR(@LogMessage, 0, 1) WITH NOWAIT

				DECLARE @SystemName NVARCHAR(MAX) = [dbo].[F_GetSystemName]()
				DECLARE @OnlineLink NVARCHAR(MAX) = 'cm' + @SystemName + 'OnlineLink'

				-- COLLECT AND RESOLVE EXPECTED SETUP TIMES AND PUT THEM INTO AUXILIAR TABLE
				-- CANNOT USE FUNCTION TO RESOLVE DIRECTLY SO WE HAVE TO GO WITH A WORKAROUND
				BEGIN
					-- COLLECT DISTINCT KEYS FOR SETUP AND PREPARE RESOLVING SQL
					;WITH BASE_DATA AS
					(
						SELECT DISTINCT FROMPR.ProductKey AS [ProductFromKey]
							, TOPR.ProductKey AS [ProductToKey]
							, RES.ResourceKey
							, FAC.FacilityKey
							, AR.AreaKey
							, FAC.[FacilityName]
							, AR.[AreaName]
							, RES.[Type] [ResourceType]
							, RES.[ResourceName]
							, FROMPR.[ProductName] [FromProduct]
							, TOPR.[ProductName] [ToProduct]
						FROM #MaterialsTransitions FT
						INNER JOIN [dbo].[DimArea] AR ON AR.AreaId = FT.AreaId
						INNER JOIN [dbo].[DimProduct] FROMPR ON FROMPR.ProductId = ISNULL(FT.PreviousProductId, 0)
						INNER JOIN [dbo].[DimProduct] TOPR ON TOPR.ProductId = ISNULL(FT.ProductId, 0)
						INNER JOIN [dbo].[DimResource] RES ON RES.ResourceId = ISNULL(FT.ResourceId, 0)
						INNER JOIN [dbo].[DimFacility] FAC ON FAC.FacilityId = ISNULL(FT.FacilityId, 0)
					)
					SELECT DENSE_RANK() OVER(ORDER BY BD.[ProductFromKey], BD.[ProductToKey], BD.[ResourceKey], BD.[FacilityKey], BD.[AreaKey]) [RowNumber]
						, 'INSERT INTO #ExpectedSetupTimes([ProductFromKey], [ProductToKey], [ResourceKey], [FacilityKey], [AreaKey], [ExpectedSetupTime]) '
						+ 'SELECT ' + CONVERT(NVARCHAR, BD.[ProductFromKey]) 
								+ ', ' + CONVERT(NVARCHAR, BD.[ProductToKey]) 
								+ ', ' + CONVERT(NVARCHAR, BD.[ResourceKey]) 
								+ ', ' + CONVERT(NVARCHAR, BD.[FacilityKey]) 
								+ ', ' + CONVERT(NVARCHAR, BD.[AreaKey]) 
								+ ', [SetupTime] '
							+ 'FROM OPENQUERY(' + @OnlineLink 
								+ ', ''' + ('SELECT * FROM [' + @SystemName +'].[UserDataModel].[F_ST_ResolveCustomProductsTransitionSetupTimes](1,''''' 
									+ BD.[FacilityName] + ''''',''''' 
									+ BD.[AreaName] + ''''',''''' 
									+ BD.[ResourceType] + ''''',''''' 
									+ BD.[ResourceName] + ''''',''''' 
									+ BD.[FromProduct] + ''''',''''' 
									+ BD.[ToProduct] + ''''')'')') [QueryToExecute]
					INTO #FactProductSetupTimeTemp
					FROM BASE_DATA BD
				
					-- GO LINE BY LINE AND TRY TO OBTAIN ESTIMATED SETUP TIMES
					DECLARE @Iterator				BIGINT = 1
					DECLARE @RowCount				BIGINT = (SELECT COUNT(1) FROM #FactProductSetupTimeTemp)
					DECLARE @SqlStatementToExecute	NVARCHAR(MAX)
					WHILE(@Iterator <= @RowCount)
					BEGIN
						SELECT @SqlStatementToExecute = [QueryToExecute] FROM #FactProductSetupTimeTemp WHERE [RowNumber] = @Iterator
						EXEC sp_executesql @SqlStatementToExecute

						SET @Iterator = @Iterator + 1
					END

				END

				MERGE INTO [Custom].[FactProductSetupTime] TRG
				USING
				(
					SELECT FROMPR.ProductKey AS [ProductFromKey]
						, TOPR.ProductKey AS [ProductToKey]
						, RES.ResourceKey
						, FAC.FacilityKey
						, AR.AreaKey					
						, MAT.MaterialKey AS [MaterialKey]
						, SFT.ShiftKey
						, CAST(CONVERT(NVARCHAR(8), FT.[FactTimeStamp], 112) AS INTEGER) AS [DateKey]
						, DATEPART(HH, FT.[FactTimeStamp]) * (10000) + DATEPART(MI, FT.[FactTimeStamp]) * (100) + DATEPART(SS, FT.[FactTimeStamp]) [TimeKey]
						, FT.ServiceHistoryId
						, CAST(CONVERT(NVARCHAR(8), FT.[LC1FactTimeStamp], 112) AS INTEGER) [LC1DateKey]
						, DATEPART(HH, FT.[LC1FactTimeStamp]) * (10000) + DATEPART(MI, FT.[LC1FactTimeStamp]) * (100) + DATEPART(SS, FT.[LC1FactTimeStamp]) [LC1TimeKey]
						, FT.[CalculatedSetupTime]
						, EST.[ExpectedSetupTime]
					FROM #MaterialsTransitions FT
					INNER JOIN [dbo].[FactShift] SFT ON FT.[FactTimeStamp] BETWEEN SFT.StartDateTime AND SFT.EndDateTime
					INNER JOIN [dbo].[DimArea] AR ON AR.AreaKey = SFT.AreaKey AND AR.AreaId = FT.AreaId
					INNER JOIN [dbo].[DimProduct] FROMPR ON FROMPR.ProductId = ISNULL(FT.PreviousProductId, 0)
					INNER JOIN [dbo].[DimProduct] TOPR ON TOPR.ProductId = ISNULL(FT.ProductId, 0)
					INNER JOIN [dbo].[DimResource] RES ON RES.ResourceId = ISNULL(FT.ResourceId, 0)
					INNER JOIN [dbo].[DimFacility] FAC ON FAC.FacilityId = ISNULL(FT.FacilityId, 0)
					INNER JOIN #MaterialDimension MAT ON MAT.MaterialId = ISNULL(FT.MaterialId, 0)
					LEFT JOIN #ExpectedSetupTimes EST ON EST.[ProductFromKey] = FROMPR.ProductKey
						AND EST.[ProductToKey] = TOPR.[ProductKey]
						AND EST.[ResourceKey] = RES.[ResourceKey]
						AND EST.[AreaKey] = AR.[AreaKey]
						AND EST.[FacilityKey] = AR.[FacilityKey]

				) SRC ON (TRG.[MaterialKey] = SRC.[MaterialKey]
							AND TRG.[AreaKey] = SRC.[AreaKey]
							AND TRG.[ResourceKey] = SRC.[ResourceKey]
							AND TRG.[FacilityKey] = SRC.[FacilityKey]
							AND TRG.[ProductToKey] = SRC.[ProductToKey]
							AND TRG.[ProductFromKey] = SRC.[ProductFromKey]
							AND TRG.[MaterialKey] = SRC.[MaterialKey]
							AND TRG.[ServiceHistoryId] = SRC.[ServiceHistoryId]
							AND TRG.[DateKey] = SRC.[DateKey]
							AND SRC.[TimeKey] = SRC.[TimeKey]
							)
				WHEN NOT MATCHED THEN INSERT([ProductFromKey],[ProductToKey],[ResourceKey],[FacilityKey],[AreaKey],
																		 [MaterialKey],[ShiftKey],[DateKey],[TimeKey],[ServiceHistoryId],
																		 [LC1DateKey],[LC1TimeKey],[CalculatedSetupTime],[ExpectedSetupTime])
													VALUES(SRC.[ProductFromKey], SRC.[ProductToKey], SRC.[ResourceKey], SRC.[FacilityKey], SRC.[AreaKey],
																 SRC.[MaterialKey], SRC.[ShiftKey], SRC.[DateKey], SRC.[TimeKey], SRC.[ServiceHistoryId], 
																 SRC.[LC1DateKey], SRC.[LC1TimeKey], SRC.[CalculatedSetupTime], SRC.[ExpectedSetupTime]);

				SET @RowsAffected = @@ROWCOUNT
				SET @ExecutionTimeInSeconds = DATEDIFF(SECOND, @ExecutionControlTS, GETDATE())
				SET @LogMessage = REPLACE(REPLACE(@LogMessageTemplateEnd, N'%ExecutionTime%', CONVERT(NVARCHAR, @ExecutionTimeInSeconds)), N'%RowsAffected%', CONVERT(NVARCHAR, @RowsAffected))
				RAISERROR(@LogMessage, 0, 1) WITH NOWAIT
			END

		END
		ELSE
		BEGIN
			SET @RowsAffected = 0
		END

		SET @LogMessage = @ProcedureName + N': '  + CONVERT(NVARCHAR, @RowsAffected) + N' row(s) merged into [Custom].[FactProductSetupTime]'
		EXEC Control.P_StopExecution @ProcedureName, @LogMessage;
		
		IF @StartTranCount = 0
			COMMIT
	END TRY
	BEGIN CATCH

		-- ROLLBACK TRANSACTION IF EXECUTING AUTONOMOUSLY
		IF XACT_STATE() <> 0 AND @StartTranCount = 0 
			ROLLBACK TRANSACTION

		-- LOG STOPING OF EXECUTION
		EXEC Control.P_StopExecution @ProcedureName

		-- GET ERROR AND RE-RAISE IT
		SELECT @ErrorMessage = ERROR_MESSAGE() + ' Line ' + cast(ERROR_LINE() AS nvarchar(5)), @ErrorSeverity = ERROR_SEVERITY(), @ErrorState = ERROR_STATE();
		RAISERROR (@ErrorMessage, @ErrorSeverity, @ErrorState);

	END CATCH
END
GO
