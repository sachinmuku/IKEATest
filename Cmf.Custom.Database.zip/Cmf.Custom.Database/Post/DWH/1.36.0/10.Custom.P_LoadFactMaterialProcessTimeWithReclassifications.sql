IF EXISTS (SELECT * 
FROM SYSOBJECTS
WHERE [id] = OBJECT_ID(N'Custom.P_LoadFactMaterialProcessTimeWithReclassifications') AND OBJECTPROPERTY([id], N'IsProcedure') = 1 )
BEGIN
    DROP PROCEDURE [Custom].[P_LoadFactMaterialProcessTimeWithReclassifications]
END
GO

CREATE PROCEDURE [Custom].[P_LoadFactMaterialProcessTimeWithReclassifications] 
( 
	@InfServiceHistoryId bigint = NULL, 
	@SupServiceHistoryId bigint = NULL, 
	@ResourceId bigint = NULL 
)
WITH ENCRYPTION
AS
BEGIN

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET XACT_ABORT ON
	SET NOCOUNT ON

	DECLARE 
		@StartTranCount int, --Controls number of transactions
		@ErrorMessage nvarchar(max), 
		@ErrorSeverity int, 
		@ErrorState int;

	DECLARE 
		@TABLENAME VARCHAR(32) = 'FactMaterialProcessTime',
		@PROCNAME VARCHAR(64) = (SELECT OBJECT_NAME(@@PROCID)),
		@CurrentDatetime DATETIME = GETUTCDATE(),
		@StatusMessage NVARCHAR(256),
		@IsOtherFilterApplied BIT = (SELECT CASE WHEN @ResourceId IS NOT NULL THEN 1 ELSE 0 END),
		@SystemName NVARCHAR(512) = dbo.F_GetSystemName();

	DECLARE 
		@MinServiceHistoryId BIGINT, 
		@MaxServiceHistoryId BIGINT,
		@ODSLink NVARCHAR(512) = 'cm' + @SystemName + 'ODSLink',
		@ODSDataBase NVARCHAR(512) = @SystemName + 'ODS';
		
	DECLARE 
		@MinServDateTime DATETIME, 
		@MaxServDateTime DATETIME;

	BEGIN TRY
		SELECT @StartTranCount = @@TRANCOUNT;

		IF (@StartTranCount = 0)
			BEGIN TRANSACTION;
	
		-- Execute Start Execution
		EXEC [Control].[P_StartExecution] @ProcedureName = @PROCNAME, 
											@MinServiceHistoryIdCalculated = @MinServiceHistoryId OUTPUT, 
											@MaxServiceHistoryIdCalculated = @MaxServiceHistoryId OUTPUT, 
											@InferiorServiceHistoryId = @InfServiceHistoryId, 
											@SuperiorServiceHistoryId = @SupServiceHistoryId, 
											@OtherFilters = @IsOtherFilterApplied;

		-- Get Minimum and Maximum Service History Dates
		SELECT 
			@MinServDateTime = MinServDateTime, 
			@MaxServDateTime = MaxServDateTime 
		FROM [dbo].[F_GetMinAndMaxServiceTime] (@MinServiceHistoryId, @MaxServiceHistoryId);		
		
		-- Get Date Keys
		DECLARE 
			@MinServDateKey INT = [dbo].[F_GetDateKeyFromDateTime] (@MinServDateTime), 
			@MaxServDateKey INT = [dbo].[F_GetDateKeyFromDateTime] (@MaxServDateTime);

		-- Get Date Keys Prunings
		DECLARE 
			@MinServDateKeyPruning INT = [dbo].[F_GetDateKeyFromDateTime](@MinServDateTime - 1),
			@MaxServDateKeyPruning INT = [dbo].[F_GetDateKeyFromDateTime](@MaxServDateTime + 1);
		
		IF(OBJECT_ID(N'tempdb..#ResourceStateReclassifications') IS NOT NULL)
			DROP TABLE #ResourceStateReclassifications;
			
		IF(OBJECT_ID(N'tempdb..#FactsReclassification') IS NOT NULL)
			DROP TABLE #FactsReclassification;

		CREATE TABLE #ResourceStateReclassifications
		(
			StartServiceHistoryId BIGINT,
			StartOperationHistorySeq BIGINT,
			EndServiceHistoryId BIGINT,
			EndOperationHistorySeq BIGINT,
			ResourceId BIGINT,
			StateModelId BIGINT,
			StateModelStateId BIGINT,
			StateModelStateReason NVARCHAR(512),
			ServiceHistoryId BIGINT,
			OperationHistorySeq BIGINT,
			ModifiedOn DATETIME,
			ModifiedBy VARCHAR(64)
		);
	
		-- Get Resource State Reclassification for the specific Service History Ids
		DECLARE @Query NVARCHAR(MAX) = '
		SELECT 
			[ServiceHistoryIdStart],
			[OperationHistorySequenceStart],
			[ServiceHistoryIdEnd],
			[OperationHistorySequenceEnd],
			[ResourceId],
			[StateModelId],
			[StateModelStateId],
			[StateModelStateReason],
			[ServiceHistoryId],
			[OperationHistorySeq],
			[ModifiedOn],
			[ModifiedBy]
		FROM 
		(
			SELECT
				[ServiceHistoryIdStart],
				[OperationHistorySequenceStart],
				[ServiceHistoryIdEnd],
				[OperationHistorySequenceEnd],
				[ResourceId],
				[StateModelId],
				[StateModelStateId],
				[StateModelStateReason],
				[ServiceHistoryId],
				[OperationHistorySeq],
				[ModifiedOn],
				[ModifiedBy],
				ROW_NUMBER() OVER (PARTITION BY [ResourceId], [ServiceHistoryIdStart], [OperationHistorySequenceStart], [ServiceHistoryIdEnd], [OperationHistorySequenceEnd] ORDER BY [ServiceHistoryId] DESC, [ModifiedOn] DESC, [OperationHistorySeq] DESC) AS RowNumber
			FROM ' + @ODSLink + '.' + @ODSDataBase + '.UserDataModel.T_CustomResourceStateReclassificationHistory 
			WHERE @ResourceId IS NULL 
				OR [ResourceId] = @ResourceId
		) AS ResourceStateReclassifications
		WHERE RowNumber = 1
			AND [ServiceHistoryIdEnd] BETWEEN @MinServiceHistoryId AND @MaxServiceHistoryId';
					
		INSERT INTO #ResourceStateReclassifications
		EXECUTE sp_executesql @Query, N'@MinServiceHistoryId BIGINT, @MaxServiceHistoryId BIGINT, @ResourceId BIGINT', @MinServiceHistoryId = @MinServiceHistoryId, @MaxServiceHistoryId = @MaxServiceHistoryId, @ResourceId = @ResourceId;
	
		CREATE TABLE #FactsReclassification
		(
			[DateKey] [int] NOT NULL,
			[TimeKey] [int] NOT NULL,
			[ResourceKey] [bigint] NOT NULL,
			[MaterialKey] [bigint] NOT NULL,
			[AreaKey] [bigint] NOT NULL,
			[ProductKey] [bigint] NOT NULL,
			[FlowKey] [bigint] NOT NULL,
			[StepKey] [bigint] NOT NULL,
			[UTCParcelStartDateTime] [datetime] NOT NULL,
			[TrackOutServiceHistoryId] [bigint] NOT NULL,
			[SEMI-E10] [nvarchar](512) NULL,
			CONSTRAINT [PK_TempFactMaterialProcessTime] PRIMARY KEY CLUSTERED 
			(
				[DateKey] ASC,
				[TimeKey] ASC,
				[ResourceKey] ASC,
				[MaterialKey] ASC,
				[AreaKey] ASC,
				[ProductKey] ASC,
				[FlowKey] ASC,
				[StepKey] ASC,
				[UTCParcelStartDateTime] ASC,
				[TrackOutServiceHistoryId] ASC
			)
		);
		
		-- Get Fact with reclassifications
		INSERT INTO #FactsReclassification
		SELECT
			FMPT.[DateKey],
			FMPT.[TimeKey],
			FMPT.[ResourceKey],
			FMPT.[MaterialKey],
			FMPT.[AreaKey],
			FMPT.[ProductKey],
			FMPT.[FlowKey],
			FMPT.[StepKey],
			FMPT.[UTCParcelStartDateTime],
			FMPT.[TrackOutServiceHistoryId],
			DRSM.[StateModelStateSemiE10Value] AS [SEMI-E10]
		FROM dbo.FactMaterialProcessTime AS FMPT
		INNER JOIN dbo.DimResource AS DR
			ON DR.ResourceKey = FMPT.ResourceKey
		INNER JOIN #ResourceStateReclassifications AS RSR
			ON RSR.[ResourceId] = DR.[ResourceId]
			AND FMPT.[ServiceHistoryId] BETWEEN RSR.[StartServiceHistoryId] AND RSR.[EndServiceHistoryId]
			AND 
			(
				FMPT.[ServiceHistoryId] = RSR.[StartServiceHistoryId] AND FMPT.[OperationHistorySeq] >= RSR.[StartOperationHistorySeq]
				OR FMPT.[ServiceHistoryId] = RSR.[EndServiceHistoryId] AND FMPT.OperationHistorySeq < RSR.[EndOperationHistorySeq]
				OR (FMPT.[ServiceHistoryId] > RSR.[StartServiceHistoryId] AND FMPT.ServiceHistoryId < RSR.[EndServiceHistoryId])
			)
		INNER JOIN dbo.DimResourceStateModel AS DRSM
			ON DRSM.[StateModelId] = RSR.[StateModelId]
			AND DRSM.[StateModelStateId] = RSR.[StateModelStateId]
		WHERE FMPT.[ServiceHistoryId] BETWEEN @MinServiceHistoryId AND @MaxServiceHistoryId;

		-- Update the Fact Table with the reclassifications
		MERGE INTO dbo.FactMaterialProcessTime AS FACT
		USING #FactsReclassification AS Reclassifications
		ON FACT.[DateKey] = Reclassifications.[DateKey]
			AND FACT.[TimeKey] = Reclassifications.[TimeKey]
			AND FACT.[ResourceKey] = Reclassifications.[ResourceKey]
			AND FACT.[MaterialKey] = Reclassifications.[MaterialKey]
			AND FACT.[AreaKey] = Reclassifications.[AreaKey]
			AND FACT.[ProductKey] = Reclassifications.[ProductKey]
			AND FACT.[FlowKey] = Reclassifications.[FlowKey]
			AND FACT.[StepKey] = Reclassifications.[StepKey]
			AND FACT.[UTCParcelStartDateTime] = Reclassifications.[UTCParcelStartDateTime]
			AND FACT.[TrackOutServiceHistoryId] = Reclassifications.[TrackOutServiceHistoryId]
		WHEN MATCHED THEN
			UPDATE SET
				[SEMI-E10] = Reclassifications.[SEMI-E10];
				
		SET @StatusMessage = OBJECT_NAME(@@PROCID) + ': ' + cast(@@ROWCOUNT as varchar) + ' row(s) merged into [dbo].[FactMaterialProcessTime]'
		RAISERROR (@StatusMessage, 0, 1) WITH NOWAIT;
		
		-- Execute Stop Execution
		EXEC [Control].[P_StopExecution] @ProcedureName = @PROCNAME, 
											@StatusMsg = @StatusMessage;

		-- If There was no transaction on the beginning of the exception, a new one was created and has to be committed.
		IF(@StartTranCount = 0)
			COMMIT TRANSACTION;			
		
	END TRY
	BEGIN CATCH
		IF XACT_STATE() <> 0 AND @starttrancount = 0 
			ROLLBACK TRANSACTION;

		EXEC Control.P_StopExecution @PROCNAME;

		SELECT 
			@ErrorMessage = ERROR_MESSAGE() + ' Line ' + CAST(ERROR_LINE() AS NVARCHAR(5)), 
			@ErrorSeverity = ERROR_SEVERITY(), 
			@ErrorState = ERROR_STATE();

		RAISERROR (@ErrorMessage, @ErrorSeverity, @ErrorState);

	END CATCH

END;