SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF (NOT EXISTS(SELECT * FROM sys.tables ST INNER JOIN sys.schemas SS ON SS.schema_id = ST.schema_id WHERE ST.name = 'FactOrderCycleTime' AND SS.name = 'Custom'))
BEGIN

	CREATE TABLE [Custom].[FactOrderCycleTime]
	(
		-- KEYS
		[FacilityKey] BIGINT NOT NULL
		, [AreaKey] BIGINT NOT NULL
		, [ResourceKey] BIGINT NOT NULL
		, [ShiftKey] BIGINT NOT NULL
		, [DateKey] INT NOT NULL
		, [TimeKey] INT NOT NULL
		, [LC1DateKey] INT NOT NULL
		, [LC1TimeKey] INT NOT NULL
		, [MaterialKey] BIGINT NOT NULL
		, [RunNumber] INT NOT NULL
		, [ProductKey] BIGINT NOT NULL
		, [ServiceHistoryId] BIGINT NOT NULL
		-- VALUE COLUMNS
		, [QuantityProduced] DECIMAL(15, 8)
		, [ProcessingTime] DECIMAL(15, 8)
		, [ActualCycleTime] DECIMAL(15, 8)
		, [IdealCycleTime] DECIMAL(15, 8)
		, [SetPoint] DECIMAL(15, 8)
	)

	ALTER TABLE [Custom].[FactOrderCycleTime] ADD CONSTRAINT [PK_FactOrderCycleTime] PRIMARY KEY CLUSTERED
	(
		[FacilityKey] ASC
		, [AreaKey] ASC
		, [ResourceKey] ASC
		, [MaterialKey] ASC
		, [RunNumber] ASC
		, [ProductKey] ASC
		, [ShiftKey] ASC
		, [TimeKey] ASC
		, [DateKey] ASC
	)

	ALTER TABLE [Custom].[FactOrderCycleTime]  WITH CHECK ADD CONSTRAINT [FK_FactOrderCycleTime_DimFacility] FOREIGN KEY([FacilityKey]) REFERENCES [dbo].[DimFacility] ([FacilityKey])
	ALTER TABLE [Custom].[FactOrderCycleTime]  WITH CHECK ADD CONSTRAINT [FK_FactOrderCycleTime_DimArea] FOREIGN KEY([AreaKey]) REFERENCES [dbo].[DimArea] ([AreaKey])
	ALTER TABLE [Custom].[FactOrderCycleTime]  WITH CHECK ADD CONSTRAINT [FK_FactOrderCycleTime_DimResource] FOREIGN KEY([ResourceKey]) REFERENCES [dbo].[DimResource] ([ResourceKey])
	ALTER TABLE [Custom].[FactOrderCycleTime]  WITH CHECK ADD CONSTRAINT [FK_FactOrderCycleTime_DimMaterial] FOREIGN KEY([MaterialKey]) REFERENCES [dbo].[DimMaterial] ([MaterialKey])
	ALTER TABLE [Custom].[FactOrderCycleTime]  WITH CHECK ADD CONSTRAINT [FK_FactOrderCycleTime_DimProduct] FOREIGN KEY([ProductKey]) REFERENCES [dbo].[DimProduct] ([ProductKey])
	ALTER TABLE [Custom].[FactOrderCycleTime]  WITH CHECK ADD CONSTRAINT [FK_FactOrderCycleTime_DimShift] FOREIGN KEY([ShiftKey]) REFERENCES [dbo].[DimShift] ([ShiftKey])
	ALTER TABLE [Custom].[FactOrderCycleTime]  WITH CHECK ADD CONSTRAINT [FK_FactOrderCycleTime_DimDate] FOREIGN KEY([DateKey]) REFERENCES [dbo].[DimDate] ([DateKey])
	ALTER TABLE [Custom].[FactOrderCycleTime]  WITH CHECK ADD CONSTRAINT [FK_FactOrderCycleTime_DimTime] FOREIGN KEY([TimeKey]) REFERENCES [dbo].[DimTime] ([TimeKey])	
	ALTER TABLE [Custom].[FactOrderCycleTime]  WITH CHECK ADD CONSTRAINT [FK_FactOrderCycleTime_LC1DateKey] FOREIGN KEY([LC1DateKey]) REFERENCES [dbo].[DimDate] ([DateKey])
	ALTER TABLE [Custom].[FactOrderCycleTime]  WITH CHECK ADD CONSTRAINT [FK_FactOrderCycleTime_LC1TimeKey] FOREIGN KEY([LC1TimeKey]) REFERENCES [dbo].[DimTime] ([TimeKey])
		
	CREATE NONCLUSTERED INDEX [IDX_MaterialKey] ON [Custom].[FactOrderCycleTime]
	(
		[DateKey] ASC,
		[MaterialKey] ASC
	)

	CREATE NONCLUSTERED INDEX [IDX_ResourceKey] ON [Custom].[FactOrderCycleTime]
	(
		[DateKey] ASC,
		[ResourceKey] ASC
	)

	CREATE NONCLUSTERED INDEX [IDX_AreaKey] ON [Custom].[FactOrderCycleTime]
	(
		[DateKey] ASC,
		[AreaKey] ASC
	)

	CREATE NONCLUSTERED INDEX [IDX_FacilityKey] ON [Custom].[FactOrderCycleTime]
	(
		[DateKey] ASC,
		[FacilityKey] ASC
	)

	CREATE NONCLUSTERED INDEX [IDX_ShiftKey] ON [Custom].[FactOrderCycleTime]
	(
		[DateKey] ASC,
		[ShiftKey] ASC
	)

END