DELETE FROM [Control].[T_ExecutionControl] WHERE [ProcedureName] IN (N'P_UpdateFactMaterialProcessTimeWithReclassifications', N'P_UpdateFactResourceServiceTimeWithReclassifications')
GO

IF (EXISTS(SELECT * FROM sys.procedures SP INNER JOIN sys.schemas SS ON SS.schema_id = SP.schema_id WHERE SP.name = 'P_UpdateFactResourceServiceTimeWithReclassifications' AND SS.name = 'Custom'))
BEGIN
	DROP PROCEDURE [Custom].[P_UpdateFactResourceServiceTimeWithReclassifications]
END
GO

IF (EXISTS(SELECT * FROM sys.procedures SP INNER JOIN sys.schemas SS ON SS.schema_id = SP.schema_id WHERE SP.name = 'P_UpdateFactMaterialProcessTimeWithReclassifications' AND SS.name = 'Custom'))
BEGIN
	DROP PROCEDURE [Custom].[P_UpdateFactMaterialProcessTimeWithReclassifications]
END
GO

