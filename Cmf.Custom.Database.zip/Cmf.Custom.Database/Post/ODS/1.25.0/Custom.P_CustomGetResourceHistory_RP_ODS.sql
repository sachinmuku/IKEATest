/****** Object:  StoredProcedure [Custom].[P_CustomGetResourceHistory_RP_ODS] Script Date: 26-Dec-19 14:45:41 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = 'Custom')
BEGIN
EXEC('CREATE SCHEMA Custom')
END
GO

IF EXISTS ( SELECT * 
            FROM   sysobjects 
            WHERE  id = object_id(N'[Custom].[P_CustomGetResourceHistory_RP_ODS]') 
                   and OBJECTPROPERTY(id, N'IsProcedure') = 1 )
BEGIN
    DROP PROCEDURE [Custom].[P_CustomGetResourceHistory_RP_ODS]
END
GO

CREATE PROCEDURE [Custom].[P_CustomGetResourceHistory_RP_ODS]
		@ResourceName NVARCHAR(256),
		@ResourceId BIGINT,
		@DateStart DATETIME,
		@DateEnd DATETIME
AS
BEGIN
	SET NOCOUNT ON

	DECLARE @DateStartHost	DATETIME	= dbo.F_TimeLocalTimeToUTC(ISNULL(@DateStart, GETDATE() - 200));
	DECLARE @DateEndHost	DATETIME	= dbo.F_TimeLocalTimeToUTC(ISNULL(@DateEnd, GETDATE()));

	DECLARE @MinResourceServiceHistoryId bigint, @MaxResourceServiceHistoryId bigint;
	select @MinResourceServiceHistoryId = dbo.F_Part_GetMinServiceHistoryIdForDate(@DateStartHost), @MaxResourceServiceHistoryId = dbo.F_Part_GetMaxServiceHistoryIdForDate(@DateEndHost);
	
	DECLARE @ResourceEntityTypeId bigint = (SELECT entitytypeid FROM dbo.t_entitytype et WHERE et.NAME = 'Resource')

	DECLARE	@ResId BIGINT = @ResourceId;
	DECLARE @ResourceServiceHistoryId BIGINT = (SELECT LastServiceHistoryId FROM CoreDataModel.T_Resource WHERE ResourceId = @ResourceId)

	IF(@ResourceServiceHistoryId < @MinResourceServiceHistoryId)
	BEGIN
		SET @MinResourceServiceHistoryId = @ResourceServiceHistoryId;
		SET @MaxResourceServiceHistoryId = @ResourceServiceHistoryId + 1;
	END;

	IF ((@ResId IS NULL OR @ResId <= 0) AND @ResourceName IS NOT NULL) 
	BEGIN
		SELECT @ResId = ResourceId FROM CoreDataModel.T_Resource WHERE Name = @ResourceName

		IF (@ResId IS NULL OR @ResId <= 0) 
			RETURN;
	END;	
	
	IF(OBJECT_ID(N'tempdb..#ScopedResourceHistoryIds') IS NOT NULL)
		DROP TABLE #ScopedResourceHistoryIds;
		
	IF(OBJECT_ID(N'tempdb..#ResourceLogEventHistory') IS NOT NULL)
		DROP TABLE #ResourceLogEventHistory;		
		
	IF(OBJECT_ID(N'tempdb..#ResourceModelStates') IS NOT NULL)
		DROP TABLE #ResourceModelStates;
		
	IF(OBJECT_ID(N'tempdb..#ResourceStateReclassifications') IS NOT NULL)
		DROP TABLE #ResourceStateReclassifications;

	CREATE TABLE #ScopedResourceHistoryIds
	(
		ServiceHistoryId BIGINT,
		ResourceId BIGINT, 
		Name NVARCHAR(256),
		MainStateModelStateReason NVARCHAR(512),
		AreaId BIGINT, 
		ModifiedOn DATETIME, 
		ModifiedBy VARCHAR(64),
		SystemState INT,
		MainStateModelId BIGINT,
		MainStateModelStateId BIGINT,
		OperationHistorySeq BIGINT,
		OperationName VARCHAR(256),
		OldServiceHistoryId BIGINT,
		OldOperationHistorySeq BIGINT
	);
	
	CREATE TABLE #ResourceLogEventHistory
	(
		RowNumber BIGINT,
		ServiceHistoryId BIGINT,
		PreviousServiceHistoryId BIGINT,
		ResourceId BIGINT, 
		Name NVARCHAR(256),
		AreaId BIGINT,
		ModifiedOn DATETIME,
		ModifiedBy VARCHAR(64),
		SystemState INT,
		PreviousSystemState INT,
		MainStateModelId BIGINT,
		PreviousMainStateModelId BIGINT,
		MainStateModelStateId BIGINT,
		PreviousMainStateModelStateId BIGINT,
		OperationHistorySeq BIGINT,
		OperationName VARCHAR(256),
		MainStateModelStateReason NVARCHAR(512),
		NextServiceHistoryId BIGINT,
		NextMainStateModelId BIGINT,
		NextMainStateModelStateId BIGINT,
		NextModifiedOn DATETIME
	);
	
	CREATE TABLE #ResourceModelStates
	(
		RowNumber BIGINT,
		ResourceId BIGINT,
		Name NVARCHAR(256),
		AreaId BIGINT,
		SystemState INT,
		PreviousSystemState INT,
		StateName NVARCHAR(256),
		PreviousStateName NVARCHAR(256),
		NextStateName NVARCHAR(256),
		ModifiedOn DATETIME,
		NextModifiedOn DATETIME,
		ServiceHistoryId BIGINT,
		PreviousServiceHistoryId BIGINT,
		NextServiceHistoryId BIGINT,
		MainStateModelId BIGINT, 
		MainStateModelStateId BIGINT,
		PreviousMainStateModelId BIGINT,
		PreviousMainStateModelStateId BIGINT,
		ModifiedBy VARCHAR(64),
		MainStateModelStateReason NVARCHAR(512),
		OperationHistorySeq BIGINT
	);

	CREATE TABLE #ResourceStateReclassifications
	(
		StartServiceHistoryId BIGINT,
		StartOperationHistorySeq BIGINT,
		EndServiceHistoryId BIGINT,
		EndOperationHistorySeq BIGINT,
		ResourceId BIGINT,
		StateModelId BIGINT,
		StateModelStateId BIGINT,
		StateModelStateReason NVARCHAR(512),
		ServiceHistoryId BIGINT,
		OperationHistorySeq BIGINT,
		ModifiedOn DATETIME,
		ModifiedBy VARCHAR(64)
	);
	
	INSERT INTO #ResourceStateReclassifications
	SELECT 
		[ServiceHistoryIdStart],
		[OperationHistorySequenceStart],
		[ServiceHistoryIdEnd],
		[OperationHistorySequenceEnd],
		[ResourceId],
		[StateModelId],
		[StateModelStateId],
		[StateModelStateReason],
		[ServiceHistoryId],
		[OperationHistorySeq],
		[ModifiedOn],
		[ModifiedBy]
	FROM 
	(
		SELECT
			[ServiceHistoryIdStart],
			[OperationHistorySequenceStart],
			[ServiceHistoryIdEnd],
			[OperationHistorySequenceEnd],
			[ResourceId],
			[StateModelId],
			[StateModelStateId],
			[StateModelStateReason],
			[ServiceHistoryId],
			[OperationHistorySeq],
			[ModifiedOn],
			[ModifiedBy],
			ROW_NUMBER() OVER (PARTITION BY [ServiceHistoryIdStart], [OperationHistorySequenceStart], [ServiceHistoryIdEnd], [OperationHistorySequenceEnd] ORDER BY [ServiceHistoryId] DESC, [ModifiedOn] DESC, [OperationHistorySeq] DESC) AS RowNumber
		FROM UserDataModel.T_CustomResourceStateReclassificationHistory
		WHERE [ResourceId] = @ResId
	) AS ResourceStateReclassifications
	WHERE RowNumber = 1;

	INSERT INTO #ScopedResourceHistoryIds
	SELECT 
		RH.ServiceHistoryId,
		RH.ResourceId, 
		RH.Name,
		ISNULL(RSR.StateModelStateReason, RH.MainStateModelStateReason),
		RH.AreaId, 
		RH.ModifiedOn, 
		ISNULL(RSR.ModifiedBy, RH.ModifiedBy), 
		RH.SystemState,				
		ISNULL(RSR.StateModelId, RH.MainStateModelId),
		ISNULL(RSR.StateModelStateId, RH.MainStateModelStateId),
		RH.OperationHistorySeq,
		OH.OperationName,
		RH.OldServiceHistoryId,
		RH.OldOperationHistorySeq
	FROM CoreDataModel.T_ResourceHistory RH
	INNER JOIN dbo.T_OperationHistory OH 
		ON OH.ServiceHistoryId = RH.ServiceHistoryId 
		AND OH.OperationHistorySeq = RH.OperationHistorySeq
		AND OH.EntityId = RH.ResourceId
		AND OH.EntityTypeId = @ResourceEntityTypeId
		AND OH.ServiceHistoryId BETWEEN @MinResourceServiceHistoryId AND @MaxResourceServiceHistoryId
	-- Get the state reclassifications for the resource
	LEFT JOIN #ResourceStateReclassifications AS RSR
		ON RSR.ResourceId = RH.ResourceId
		AND RH.ServiceHistoryId BETWEEN RSR.StartServiceHistoryId AND RSR.EndServiceHistoryId
		AND 
		(
			RH.ServiceHistoryId = RSR.StartServiceHistoryId AND RH.OperationHistorySeq >= RSR.StartOperationHistorySeq
			OR RH.ServiceHistoryId = RSR.EndServiceHistoryId AND RH.OperationHistorySeq < RSR.EndOperationHistorySeq
			OR (RH.ServiceHistoryId > RSR.StartServiceHistoryId AND RH.ServiceHistoryId < RSR.EndServiceHistoryId)
		)
	WHERE RH.ServiceHistoryId BETWEEN @MinResourceServiceHistoryId AND @MaxResourceServiceHistoryId			 
	AND RH.ResourceId = @ResId
	AND 
	( 
		OH.OperationEndTime BETWEEN @DateStartHost AND @DateEndHost 
		OR @MinResourceServiceHistoryId = @ResourceServiceHistoryId
	);

	INSERT INTO #ResourceLogEventHistory
	SELECT 
		ROW_NUMBER() OVER(partition by RH.ResourceId ORDER BY RH.ServiceHistoryId, RH.OperationHistorySeq) AS RowNumber,	
		RH.ServiceHistoryId,
		LAG(RH.ServiceHistoryId, 1, -1) over (partition by RH.ResourceId ORDER BY RH.ServiceHistoryId, RH.OperationHistorySeq) AS PreviousServiceHistoryId,				
		RH.ResourceId, 
		RH.Name,
		RH.AreaId, 
		RH.ModifiedOn, 
		RH.ModifiedBy, 
		RH.SystemState,				
		LAG(RH.SystemState, 1, -1) OVER (PARTITION BY RH.ResourceId ORDER BY RH.ServiceHistoryId, RH.OperationHistorySeq) AS PreviousSystemState,
		RH.MainStateModelId,
		LAG(RH.MainStateModelId, 1, -1) OVER (PARTITION BY RH.ResourceId ORDER BY RH.ServiceHistoryId, RH.OperationHistorySeq) AS PreviousMainStateModelId,				
		RH.MainStateModelStateId,
		LAG(RH.MainStateModelStateId, 1, -1) OVER (PARTITION BY RH.ResourceId ORDER BY RH.ServiceHistoryId, RH.OperationHistorySeq) AS PreviousMainStateModelStateId,				
		RH.OperationHistorySeq,
		RH.OperationName,
		RH.MainStateModelStateReason,
		LEAD(ServiceHistoryId,1, -1) OVER (PARTITION BY RH.ResourceId ORDER BY ServiceHistoryId, OperationHistorySeq) AS NextServiceHistoryId,
		LEAD(RH.MainStateModelId, 1, -1) OVER (PARTITION BY RH.ResourceId ORDER BY ServiceHistoryId, OperationHistorySeq) AS NextMainStateModelId,
		LEAD(RH.MainStateModelStateId, 1, -1) OVER (PARTITION BY RH.ResourceId ORDER BY ServiceHistoryId, OperationHistorySeq) AS NextMainStateModelStateId,
		LEAD(RH.ModifiedOn) OVER (PARTITION BY RH.ResourceId ORDER BY ServiceHistoryId, OperationHistorySeq) AS NextModifiedOn
	FROM 
	(
		SELECT 
			RH.*,
			LAG(RH.ServiceHistoryId, 1, -1) OVER (PARTITION BY RH.ResourceId ORDER BY RH.ServiceHistoryId, RH.OperationHistorySeq) AS PreviousServiceHistoryId,				
			LAG(RH.MainStateModelStateReason, 1) OVER (PARTITION BY RH.ResourceId ORDER BY RH.ServiceHistoryId, RH.OperationHistorySeq) AS PreviousMainStateModelStateReason,
			LAG(RH.SystemState, 1, -1) OVER (PARTITION BY RH.ResourceId ORDER BY RH.ServiceHistoryId, RH.OperationHistorySeq) AS PreviousSystemState,
			LAG(RH.MainStateModelId, 1, -1) OVER (PARTITION BY RH.ResourceId ORDER BY RH.ServiceHistoryId, RH.OperationHistorySeq) AS PreviousMainStateModelId,				
			LAG(RH.MainStateModelStateId, 1, -1) OVER (PARTITION BY RH.ResourceId ORDER BY RH.ServiceHistoryId, RH.OperationHistorySeq) AS PreviousMainStateModelStateId			
		FROM 
		(
			SELECT 
				RH.ServiceHistoryId,
				RH.ResourceId, 
				RH.Name,
				RH.MainStateModelStateReason,
				RH.AreaId, 
				RH.ModifiedOn, 
				RH.ModifiedBy, 
				RH.SystemState,				
				RH.MainStateModelId,
				RH.MainStateModelStateId,
				RH.OperationHistorySeq,
				OH.OperationName
			FROM #ScopedResourceHistoryIds AS ORH
			INNER JOIN #ScopedResourceHistoryIds RH 
				ON ORH.ResourceId = RH.ResourceId 
				AND RH.ServiceHistoryId = ORH.OldServiceHistoryId 
				AND RH.OperationHistorySeq = ORH.OldOperationHistorySeq
			INNER JOIN dbo.T_OperationHistory OH 
				ON OH.ServiceHistoryId = RH.ServiceHistoryId 
				AND OH.OperationHistorySeq = RH.OperationHistorySeq
				AND OH.EntityId = RH.ResourceId
				AND OH.EntityTypeId = @ResourceEntityTypeId													

			UNION ALL

			SELECT 
				RH.ServiceHistoryId, 
				RH.ResourceId, 
				RH.Name, 
				RH.MainStateModelStateReason, 
				RH.AreaId, 
				RH.ModifiedOn, 
				RH.ModifiedBy, 
				RH.SystemState, 
				RH.MainStateModelId,
				RH.MainStateModelStateId, 
				RH.OperationHistorySeq, 
				RH.OperationName
			FROM #ScopedResourceHistoryIds AS RH
		) RH
		  
	) RH
	WHERE 
	(
		(RH.PreviousMainStateModelStateId <> RH.MainStateModelStateId)
		OR (RH.PreviousMainStateModelStateId = RH.MainStateModelStateId AND ISNULL(RH.MainStateModelStateReason, '<dummy>') <> ISNULL(RH.PreviousMainStateModelStateReason, '<dummy>'))
		OR (RH.PreviousSystemState <> RH.SystemState)
	);
	
	INSERT INTO #ResourceModelStates
	SELECT  
		RLEH.RowNumber,
		RLEH.ResourceId, 
		RLEH.Name,
		RLEH.AreaId,
		RLEH.SystemState,
		RLEH.PreviousSystemState,
		SMS.Name AS StateName,
		SMS_PREV.Name AS PreviousStateName,
		SMS_NEXT.Name AS NextStateName,
		RLEH.ModifiedOn,
		RLEH.NextModifiedOn,
		RLEH.ServiceHistoryId,
		RLEH.PreviousServiceHistoryId,
		ISNULL(RLEH.NextServiceHistoryId, CASE WHEN Res.LastServiceHistoryId <> RLEH.ServiceHistoryId THEN Res.LastServiceHistoryId ELSE NULL END ) AS NextServiceHistoryId,
		RLEH.MainStateModelId, 
		RLEH.MainStateModelStateId,
		RLEH.PreviousMainStateModelId,
		RLEH.PreviousMainStateModelStateId,
		RLEH.ModifiedBy,
		RLEH.MainStateModelStateReason,
		RLEH.OperationHistorySeq
	FROM #ResourceLogEventHistory RLEH
	INNER JOIN CoreDataModel.T_Resource AS Res 
		ON Res.ResourceId = RLEH.ResourceId
	LEFT OUTER JOIN dbo.T_StateModelState AS SMS 
		ON SMS.StateModelId = RLEH.MainStateModelId 
		AND SMS.StateModelStateId = RLEH.MainStateModelStateId
	LEFT OUTER JOIN dbo.T_StateModelState AS SMS_PREV 
		ON SMS_PREV.StateModelId = RLEH.PreviousMainStateModelId 
		AND SMS_PREV.StateModelStateId = RLEH.PreviousMainStateModelStateId
	LEFT OUTER JOIN dbo.T_StateModelState AS SMS_NEXT 
		ON SMS_NEXT.StateModelId = RLEH.NextMainStateModelId 
		AND SMS_NEXT.StateModelStateId = RLEH.NextMainStateModelStateId;

	SELECT 
		RMS.RowNumber, 
		RMS.ResourceId,
		RMS.Name AS [Resource], 
		RMS.MainStateModelStateReason,
		CASE WHEN RMS.NextServiceHistoryId = -1 
			THEN RSS.StateDescription
			ELSE RSS.StateDescription 
		END AS ResourceSystemState,
		CASE WHEN RMS.NextServiceHistoryId = -1 
			THEN RMS.SystemState
			ELSE SystemState 
		END AS ResourceSystemStateId,
		dbo.F_TimeUTCToLocalTime(TS.ServiceStartTime) AS StartDateTime,
		dbo.F_TimeUTCToLocalTime(ISNULL(TS_NM.ServiceStartTime, GetUTCDate())) AS EndDateTime,
		IsNull(SMT.Name, ISNULL(ISNULL(RMS.PreviousStateName, RSSPrev.StateDescription) + ' to ', '') + ISNULL(RMS.StateName, RSS.StateDescription)) AS Transition,
		RMS.PreviousStateName,
		ISNULL(RMS.StateName, RSS.StateDescription) AS StateName,
		RMS.NextStateName,
		RMS.ModifiedBy AS [User],
		RMS.PreviousServiceHistoryId,
		RMS.ServiceHistoryId,
		RMS.NextServiceHistoryId,
		DATEDIFF(SECOND, RMS.ModifiedOn, ISNULL(RMS.NextModifiedOn, GetUTCDate())) AS TimeAtState,
		TS.Notes AS [Comment],
		CASE WHEN RMS.NextServiceHistoryId = -1 
			THEN 1 
			ELSE 0 
		END AS IsLastRecord,
		CASE WHEN RMS.PreviousServiceHistoryId = -1 
			THEN 1 
			ELSE 0 
		END AS IsFirstRecord,
		--for ordering
		CONVERT(NVARCHAR, TS.ServiceStartTime, 121) AS [StrServiceStartTime],
		CONVERT(NVARCHAR, RMS.ModifiedOn, 121) AS [StrOperationStartTime],
		RMS.OperationHistorySeq
	FROM #ResourceModelStates AS RMS
	INNER JOIN dbo.T_ResourceSystemStates AS RSS
		ON RSS.StateId = RMS.SystemState
	LEFT OUTER JOIN dbo.T_ResourceSystemStates AS RSSPrev 
		ON RSSPrev.StateId = RMS.PreviousSystemState
	INNER JOIN dbo.T_ServiceHistory AS TS 
		ON TS.ServiceHistoryId = RMS.ServiceHistoryId
	LEFT JOIN dbo.T_ServiceHistory AS TS_NM
		ON TS_NM.ServiceHistoryId = RMS.NextServiceHistoryId
	LEFT OUTER JOIN dbo.T_StateModelTransition AS SMT 
		ON  SMT.StateModelId = RMS.MainStateModelId
		AND SMT.FromStateModelStateId = RMS.PreviousMainStateModelStateId
		AND SMT.ToStateModelStateId = RMS.MainStateModelStateId
	ORDER BY RowNumber DESC;

END;
GO
